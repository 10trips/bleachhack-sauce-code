/*    */ package org.spongepowered.asm.mixin.transformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MixinPreProcessorAccessor
/*    */   extends MixinPreProcessorInterface
/*    */ {
/*    */   public MixinPreProcessorAccessor(MixinInfo mixin, MixinInfo.MixinClassNode classNode) {
/* 35 */     super(mixin, classNode);
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\org\spongepowered\asm\mixin\transformer\MixinPreProcessorAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */