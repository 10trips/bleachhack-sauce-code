package org.spongepowered.asm.mixin.transformer.ext;

public interface IHotSwap {
  void registerMixinClass(String paramString);
  
  void registerTargetClass(String paramString, byte[] paramArrayOfbyte);
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\org\spongepowered\asm\mixin\transformer\ext\IHotSwap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */