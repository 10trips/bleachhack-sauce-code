package me.zero.alpine.listener;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class Listener<T> implements EventHook<T> {
  private final Class<T> target;
  
  private final EventHook<T> hook;
  
  private final Predicate<T>[] filters;
  
  private final byte priority;
  
  private static String[] llIIIlllIlIllI;
  
  private static Class[] llIIIlllIlIlll;
  
  private static final String[] llIIIlllIllIII;
  
  private static String[] llIIIlllIllIIl;
  
  private static final int[] llIIIlllIllIlI;
  
  @SafeVarargs
  public Listener(EventHook<T> lllllllllllllllIllIlIIIIllIIlIII, Predicate<T>... lllllllllllllllIllIlIIIIllIIIlll) {
    this(lllllllllllllllIllIlIIIIllIIlIII, llIIIlllIllIlI[0], lllllllllllllllIllIlIIIIllIIIlll);
  }
  
  @SafeVarargs
  public Listener(EventHook<T> lllllllllllllllIllIlIIIIllIIIlIl, byte lllllllllllllllIllIlIIIIllIIIlII, Predicate<T>... lllllllllllllllIllIlIIIIllIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield hook : Lme/zero/alpine/listener/EventHook;
    //   9: aload_0
    //   10: iload_2
    //   11: putfield priority : B
    //   14: aload_0
    //   15: ldc me/zero/alpine/listener/EventHook
    //   17: aload_1
    //   18: <illegal opcode> 0 : (Ljava/lang/Object;)Ljava/lang/Class;
    //   23: <illegal opcode> 1 : (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/Class;
    //   28: putfield target : Ljava/lang/Class;
    //   31: aload_0
    //   32: aload_3
    //   33: putfield filters : [Ljava/util/function/Predicate;
    //   36: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	37	0	lllllllllllllllIllIlIIIIllIIIllI	Lme/zero/alpine/listener/Listener;
    //   0	37	1	lllllllllllllllIllIlIIIIllIIIlIl	Lme/zero/alpine/listener/EventHook;
    //   0	37	2	lllllllllllllllIllIlIIIIllIIIlII	B
    //   0	37	3	lllllllllllllllIllIlIIIIllIIIIll	[Ljava/util/function/Predicate;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	37	0	lllllllllllllllIllIlIIIIllIIIllI	Lme/zero/alpine/listener/Listener<TT;>;
    //   0	37	1	lllllllllllllllIllIlIIIIllIIIlIl	Lme/zero/alpine/listener/EventHook<TT;>;
    //   0	37	3	lllllllllllllllIllIlIIIIllIIIIll	[Ljava/util/function/Predicate<TT;>;
  }
  
  public final Class<T> getTarget() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lme/zero/alpine/listener/Listener;)Ljava/lang/Class;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIIIllIIIIlI	Lme/zero/alpine/listener/Listener;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	7	0	lllllllllllllllIllIlIIIIllIIIIlI	Lme/zero/alpine/listener/Listener<TT;>;
  }
  
  public final byte getPriority() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lme/zero/alpine/listener/Listener;)B
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIIIllIIIIIl	Lme/zero/alpine/listener/Listener;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	7	0	lllllllllllllllIllIlIIIIllIIIIIl	Lme/zero/alpine/listener/Listener<TT;>;
  }
  
  public final void invoke(T lllllllllllllllIllIlIIIIlIlllllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/zero/alpine/listener/Listener;)[Ljava/util/function/Predicate;
    //   6: arraylength
    //   7: invokestatic lIIIIlIllIIIlIlI : (I)Z
    //   10: ifeq -> 78
    //   13: aload_0
    //   14: <illegal opcode> 4 : (Lme/zero/alpine/listener/Listener;)[Ljava/util/function/Predicate;
    //   19: astore_2
    //   20: aload_2
    //   21: arraylength
    //   22: istore_3
    //   23: getstatic me/zero/alpine/listener/Listener.llIIIlllIllIlI : [I
    //   26: iconst_1
    //   27: iaload
    //   28: istore #4
    //   30: iload #4
    //   32: iload_3
    //   33: invokestatic lIIIIlIllIIIlIll : (II)Z
    //   36: ifeq -> 78
    //   39: aload_2
    //   40: iload #4
    //   42: aaload
    //   43: astore #5
    //   45: aload #5
    //   47: aload_1
    //   48: <illegal opcode> 5 : (Ljava/util/function/Predicate;Ljava/lang/Object;)Z
    //   53: invokestatic lIIIIlIllIIIllII : (I)Z
    //   56: ifeq -> 60
    //   59: return
    //   60: iinc #4, 1
    //   63: ldc ''
    //   65: invokevirtual length : ()I
    //   68: pop
    //   69: ldc '   '
    //   71: invokevirtual length : ()I
    //   74: ifgt -> 30
    //   77: return
    //   78: aload_0
    //   79: <illegal opcode> 6 : (Lme/zero/alpine/listener/Listener;)Lme/zero/alpine/listener/EventHook;
    //   84: aload_1
    //   85: <illegal opcode> 7 : (Lme/zero/alpine/listener/EventHook;Ljava/lang/Object;)V
    //   90: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   45	15	5	lllllllllllllllIllIlIIIIllIIIIII	Ljava/util/function/Predicate;
    //   0	91	0	lllllllllllllllIllIlIIIIlIllllll	Lme/zero/alpine/listener/Listener;
    //   0	91	1	lllllllllllllllIllIlIIIIlIlllllI	Ljava/lang/Object;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   45	15	5	lllllllllllllllIllIlIIIIllIIIIII	Ljava/util/function/Predicate<TT;>;
    //   0	91	0	lllllllllllllllIllIlIIIIlIllllll	Lme/zero/alpine/listener/Listener<TT;>;
    //   0	91	1	lllllllllllllllIllIlIIIIlIlllllI	TT;
  }
  
  static {
    lIIIIlIllIIIlIIl();
    lIIIIlIllIIIlIII();
    lIIIIlIllIIIIlll();
    lIIIIlIllIIIIIll();
  }
  
  private static CallSite lIIIIlIllIIIIIlI(MethodHandles.Lookup lllllllllllllllIllIlIIIIlIllIlIl, String lllllllllllllllIllIlIIIIlIllIlII, MethodType lllllllllllllllIllIlIIIIlIllIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIIIlIlllIll = llIIIlllIlIllI[Integer.parseInt(lllllllllllllllIllIlIIIIlIllIlII)].split(llIIIlllIllIII[llIIIlllIllIlI[1]]);
      Class<?> lllllllllllllllIllIlIIIIlIlllIlI = Class.forName(lllllllllllllllIllIlIIIIlIlllIll[llIIIlllIllIlI[1]]);
      String lllllllllllllllIllIlIIIIlIlllIIl = lllllllllllllllIllIlIIIIlIlllIll[llIIIlllIllIlI[2]];
      MethodHandle lllllllllllllllIllIlIIIIlIlllIII = null;
      int lllllllllllllllIllIlIIIIlIllIlll = lllllllllllllllIllIlIIIIlIlllIll[llIIIlllIllIlI[0]].length();
      if (lIIIIlIllIIIllIl(lllllllllllllllIllIlIIIIlIllIlll, llIIIlllIllIlI[3])) {
        MethodType lllllllllllllllIllIlIIIIlIllllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIIIlIlllIll[llIIIlllIllIlI[3]], Listener.class.getClassLoader());
        if (lIIIIlIllIIIlllI(lllllllllllllllIllIlIIIIlIllIlll, llIIIlllIllIlI[3])) {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findVirtual(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllIl);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findStatic(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllIl);
        } 
        "".length();
        if (-((0x96 ^ 0x8B) << " ".length() << " ".length() ^ (0x15 ^ 0x12) << " ".length() << " ".length() << " ".length()) > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIIIlIllllII = llIIIlllIlIlll[Integer.parseInt(lllllllllllllllIllIlIIIIlIlllIll[llIIIlllIllIlI[3]])];
        if (lIIIIlIllIIIlllI(lllllllllllllllIllIlIIIIlIllIlll, llIIIlllIllIlI[0])) {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findGetter(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllII);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (lIIIIlIllIIIlllI(lllllllllllllllIllIlIIIIlIllIlll, llIIIlllIllIlI[4])) {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findStaticGetter(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllII);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else if (lIIIIlIllIIIlllI(lllllllllllllllIllIlIIIIlIllIlll, llIIIlllIllIlI[5])) {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findSetter(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllII);
          "".length();
          if ((0xA9 ^ 0xAC) <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIIlIlllIII = lllllllllllllllIllIlIIIIlIllIlIl.findStaticSetter(lllllllllllllllIllIlIIIIlIlllIlI, lllllllllllllllIllIlIIIIlIlllIIl, lllllllllllllllIllIlIIIIlIllllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIIIlIlllIII);
    } catch (Exception lllllllllllllllIllIlIIIIlIllIllI) {
      lllllllllllllllIllIlIIIIlIllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllIIIIIll() {
    llIIIlllIlIllI = new String[llIIIlllIllIlI[6]];
    llIIIlllIlIllI[llIIIlllIllIlI[5]] = llIIIlllIllIII[llIIIlllIllIlI[2]];
    llIIIlllIlIllI[llIIIlllIllIlI[7]] = llIIIlllIllIII[llIIIlllIllIlI[3]];
    llIIIlllIlIllI[llIIIlllIllIlI[4]] = llIIIlllIllIII[llIIIlllIllIlI[0]];
    llIIIlllIlIllI[llIIIlllIllIlI[0]] = llIIIlllIllIII[llIIIlllIllIlI[4]];
    llIIIlllIlIllI[llIIIlllIllIlI[3]] = llIIIlllIllIII[llIIIlllIllIlI[5]];
    llIIIlllIlIllI[llIIIlllIllIlI[8]] = llIIIlllIllIII[llIIIlllIllIlI[8]];
    llIIIlllIlIllI[llIIIlllIllIlI[2]] = llIIIlllIllIII[llIIIlllIllIlI[7]];
    llIIIlllIlIllI[llIIIlllIllIlI[1]] = llIIIlllIllIII[llIIIlllIllIlI[6]];
    llIIIlllIlIlll = new Class[llIIIlllIllIlI[4]];
    llIIIlllIlIlll[llIIIlllIllIlI[3]] = Class.class;
    llIIIlllIlIlll[llIIIlllIllIlI[2]] = byte.class;
    llIIIlllIlIlll[llIIIlllIllIlI[1]] = EventHook.class;
    llIIIlllIlIlll[llIIIlllIllIlI[0]] = Predicate[].class;
  }
  
  private static void lIIIIlIllIIIIlll() {
    llIIIlllIllIII = new String[llIIIlllIllIlI[9]];
    llIIIlllIllIII[llIIIlllIllIlI[1]] = lIIIIlIllIIIIlII(llIIIlllIllIIl[llIIIlllIllIlI[1]], llIIIlllIllIIl[llIIIlllIllIlI[2]]);
    llIIIlllIllIII[llIIIlllIllIlI[2]] = lIIIIlIllIIIIlII(llIIIlllIllIIl[llIIIlllIllIlI[3]], llIIIlllIllIIl[llIIIlllIllIlI[0]]);
    llIIIlllIllIII[llIIIlllIllIlI[3]] = lIIIIlIllIIIIlIl(llIIIlllIllIIl[llIIIlllIllIlI[4]], llIIIlllIllIIl[llIIIlllIllIlI[5]]);
    llIIIlllIllIII[llIIIlllIllIlI[0]] = lIIIIlIllIIIIlIl(llIIIlllIllIIl[llIIIlllIllIlI[8]], llIIIlllIllIIl[llIIIlllIllIlI[7]]);
    llIIIlllIllIII[llIIIlllIllIlI[4]] = lIIIIlIllIIIIlIl(llIIIlllIllIIl[llIIIlllIllIlI[6]], llIIIlllIllIIl[llIIIlllIllIlI[9]]);
    llIIIlllIllIII[llIIIlllIllIlI[5]] = lIIIIlIllIIIIlII(llIIIlllIllIIl[llIIIlllIllIlI[10]], llIIIlllIllIIl[llIIIlllIllIlI[11]]);
    llIIIlllIllIII[llIIIlllIllIlI[8]] = lIIIIlIllIIIIllI(llIIIlllIllIIl[llIIIlllIllIlI[12]], llIIIlllIllIIl[llIIIlllIllIlI[13]]);
    llIIIlllIllIII[llIIIlllIllIlI[7]] = lIIIIlIllIIIIlII("KgcWfCgrBgM6bDAbEjc2Kw0OIWwQGxI3ECERDT40IRBYICc3DQ4kJxYDFRMwIxcPNywwWEoeKCUUA30uJQwFfQEoAxEheQgIAyQjaw4DPCVrIQ4zMTdZSx4oJRQDfS4lDAV9ASgDESF5fkI=", "DbbRB");
    llIIIlllIllIII[llIIIlllIllIlI[6]] = lIIIIlIllIIIIlII("BhU0GUkAFSwfSSMWKB0EGE4lHRMvGCMLFFZcazQNDQIjVwsNGiVXJAAVMQtcVlRi", "ltBxg");
    llIIIlllIllIIl = null;
  }
  
  private static void lIIIIlIllIIIlIII() {
    String str = (new Exception()).getStackTrace()[llIIIlllIllIlI[1]].getFileName();
    llIIIlllIllIIl = str.substring(str.indexOf("ä") + llIIIlllIllIlI[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIllIIIIlIl(String lllllllllllllllIllIlIIIIlIlIllll, String lllllllllllllllIllIlIIIIlIlIlllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIlIllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIlIlIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIIlIllIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIIlIllIIIl.init(llIIIlllIllIlI[3], lllllllllllllllIllIlIIIIlIllIIlI);
      return new String(lllllllllllllllIllIlIIIIlIllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIlIllIIII) {
      lllllllllllllllIllIlIIIIlIllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIllIIIIllI(String lllllllllllllllIllIlIIIIlIlIlIlI, String lllllllllllllllIllIlIIIIlIlIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIlIlIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIlIlIlIIl.getBytes(StandardCharsets.UTF_8)), llIIIlllIllIlI[6]), "DES");
      Cipher lllllllllllllllIllIlIIIIlIlIllII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIlIlIllII.init(llIIIlllIllIlI[3], lllllllllllllllIllIlIIIIlIlIllIl);
      return new String(lllllllllllllllIllIlIIIIlIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIlIlIlIll) {
      lllllllllllllllIllIlIIIIlIlIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIllIIIIlII(String lllllllllllllllIllIlIIIIlIlIIlll, String lllllllllllllllIllIlIIIIlIlIIllI) {
    lllllllllllllllIllIlIIIIlIlIIlll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlIlIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIIIlIlIIlIl = new StringBuilder();
    char[] lllllllllllllllIllIlIIIIlIlIIlII = lllllllllllllllIllIlIIIIlIlIIllI.toCharArray();
    int lllllllllllllllIllIlIIIIlIlIIIll = llIIIlllIllIlI[1];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIIIlIlIIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlllIllIlI[1];
    while (lIIIIlIllIIIlIll(j, i)) {
      char lllllllllllllllIllIlIIIIlIlIlIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIIIlIlIIIll++;
      j++;
      "".length();
      if ("   ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIIIlIlIIlIl);
  }
  
  private static void lIIIIlIllIIIlIIl() {
    llIIIlllIllIlI = new int[14];
    llIIIlllIllIlI[0] = "   ".length();
    llIIIlllIllIlI[1] = (0x91 ^ 0x94) << " ".length() << " ".length() & ((0x5 ^ 0x0) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    llIIIlllIllIlI[2] = " ".length();
    llIIIlllIllIlI[3] = " ".length() << " ".length();
    llIIIlllIllIlI[4] = " ".length() << " ".length() << " ".length();
    llIIIlllIllIlI[5] = 0xD5 ^ 0xB2 ^ (0x42 ^ 0x73) << " ".length();
    llIIIlllIllIlI[6] = " ".length() << "   ".length();
    llIIIlllIllIlI[7] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0x83 ^ 0x94;
    llIIIlllIllIlI[8] = "   ".length() << " ".length();
    llIIIlllIllIlI[9] = 0x37 ^ 0x3E;
    llIIIlllIllIlI[10] = (24 + 13 - -19 + 77 ^ " ".length() << (0x3A ^ 0x3D)) << " ".length();
    llIIIlllIllIlI[11] = 170 + 96 - 110 + 27 ^ (0x20 ^ 0xF) << " ".length() << " ".length();
    llIIIlllIllIlI[12] = "   ".length() << " ".length() << " ".length();
    llIIIlllIllIlI[13] = 65 + 7 - -63 + 24 ^ (0x45 ^ 0xC) << " ".length();
  }
  
  private static boolean lIIIIlIllIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllIIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIllIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIllIIIllII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlIllIIIlIlI(int paramInt) {
    return (paramInt > 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\zero\alpine\listener\Listener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */