package me.zero.alpine.type;

public interface EventPriority {
  public static final byte HIGHEST;
  
  public static final byte HIGH;
  
  public static final byte MEDIUM;
  
  public static final byte LOW;
  
  public static final byte LOWEST = 0x25 ^ 0x20;
  
  public static final byte DEFAULT;
  
  static {
    HIGH = " ".length() << " ".length();
    LOW = " ".length() << " ".length() << " ".length();
    HIGHEST = " ".length();
    DEFAULT = "   ".length();
    MEDIUM = "   ".length();
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\zero\alpine\type\EventPriority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */