package me.zero.alpine.type;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Cancellable {
  private boolean cancelled;
  
  private static String[] llIIlIllllllII;
  
  private static Class[] llIIlIllllllIl;
  
  private static final String[] llIIlIlllllllI;
  
  private static String[] llIIlIllllllll;
  
  private static final int[] llIIllIIIIIIII;
  
  public final void cancel() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/zero/alpine/type/Cancellable.llIIllIIIIIIII : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lme/zero/alpine/type/Cancellable;Z)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIIIlllIIIlIlll	Lme/zero/alpine/type/Cancellable;
  }
  
  public final boolean isCancelled() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/zero/alpine/type/Cancellable;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIlllIIIlIllI	Lme/zero/alpine/type/Cancellable;
  }
  
  static {
    lIIIlIIIlIIIIIII();
    lIIIlIIIIlllllll();
    lIIIlIIIIllllllI();
    lIIIlIIIIllllIll();
  }
  
  private static CallSite lIIIlIIIIllllIlI(MethodHandles.Lookup lllllllllllllllIllIIIlllIIIIllIl, String lllllllllllllllIllIIIlllIIIIllII, MethodType lllllllllllllllIllIIIlllIIIIlIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIlllIIIlIIll = llIIlIllllllII[Integer.parseInt(lllllllllllllllIllIIIlllIIIIllII)].split(llIIlIlllllllI[llIIllIIIIIIII[1]]);
      Class<?> lllllllllllllllIllIIIlllIIIlIIlI = Class.forName(lllllllllllllllIllIIIlllIIIlIIll[llIIllIIIIIIII[1]]);
      String lllllllllllllllIllIIIlllIIIlIIIl = lllllllllllllllIllIIIlllIIIlIIll[llIIllIIIIIIII[0]];
      MethodHandle lllllllllllllllIllIIIlllIIIlIIII = null;
      int lllllllllllllllIllIIIlllIIIIllll = lllllllllllllllIllIIIlllIIIlIIll[llIIllIIIIIIII[2]].length();
      if (lIIIlIIIlIIIIIIl(lllllllllllllllIllIIIlllIIIIllll, llIIllIIIIIIII[3])) {
        MethodType lllllllllllllllIllIIIlllIIIlIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIlllIIIlIIll[llIIllIIIIIIII[3]], Cancellable.class.getClassLoader());
        if (lIIIlIIIlIIIIIlI(lllllllllllllllIllIIIlllIIIIllll, llIIllIIIIIIII[3])) {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findVirtual(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlIl);
          "".length();
          if ("   ".length() <= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findStatic(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlIl);
        } 
        "".length();
        if (((0x14 ^ 0xD ^ (0xBD ^ 0xB6) << " ".length()) & ((0x3 ^ 0x36) << " ".length() ^ 0xC6 ^ 0xA3 ^ -" ".length())) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIlllIIIlIlII = llIIlIllllllIl[Integer.parseInt(lllllllllllllllIllIIIlllIIIlIIll[llIIllIIIIIIII[3]])];
        if (lIIIlIIIlIIIIIlI(lllllllllllllllIllIIIlllIIIIllll, llIIllIIIIIIII[2])) {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findGetter(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlII);
          "".length();
          if (" ".length() << " ".length() <= -" ".length())
            return null; 
        } else if (lIIIlIIIlIIIIIlI(lllllllllllllllIllIIIlllIIIIllll, llIIllIIIIIIII[4])) {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findStaticGetter(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlII);
          "".length();
          if ((0x42 ^ 0x61 ^ (0x8B ^ 0x98) << " ".length()) <= 0)
            return null; 
        } else if (lIIIlIIIlIIIIIlI(lllllllllllllllIllIIIlllIIIIllll, llIIllIIIIIIII[5])) {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findSetter(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIIIlllIIIlIIII = lllllllllllllllIllIIIlllIIIIllIl.findStaticSetter(lllllllllllllllIllIIIlllIIIlIIlI, lllllllllllllllIllIIIlllIIIlIIIl, lllllllllllllllIllIIIlllIIIlIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIlllIIIlIIII);
    } catch (Exception lllllllllllllllIllIIIlllIIIIlllI) {
      lllllllllllllllIllIIIlllIIIIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIllllIll() {
    llIIlIllllllII = new String[llIIllIIIIIIII[3]];
    llIIlIllllllII[llIIllIIIIIIII[1]] = llIIlIlllllllI[llIIllIIIIIIII[0]];
    llIIlIllllllII[llIIllIIIIIIII[0]] = llIIlIlllllllI[llIIllIIIIIIII[3]];
    llIIlIllllllIl = new Class[llIIllIIIIIIII[0]];
    llIIlIllllllIl[llIIllIIIIIIII[1]] = boolean.class;
  }
  
  private static void lIIIlIIIIllllllI() {
    llIIlIlllllllI = new String[llIIllIIIIIIII[2]];
    llIIlIlllllllI[llIIllIIIIIIII[1]] = lIIIlIIIIlllllII(llIIlIllllllll[llIIllIIIIIIII[1]], llIIlIllllllll[llIIllIIIIIIII[0]]);
    llIIlIlllllllI[llIIllIIIIIIII[0]] = lIIIlIIIIlllllIl(llIIlIllllllll[llIIllIIIIIIII[3]], llIIlIllllllll[llIIllIIIIIIII[2]]);
    llIIlIlllllllI[llIIllIIIIIIII[3]] = lIIIlIIIIlllllIl(llIIlIllllllll[llIIllIIIIIIII[4]], llIIlIllllllll[llIIllIIIIIIII[5]]);
    llIIlIllllllll = null;
  }
  
  private static void lIIIlIIIIlllllll() {
    String str = (new Exception()).getStackTrace()[llIIllIIIIIIII[1]].getFileName();
    llIIlIllllllll = str.substring(str.indexOf("ä") + llIIllIIIIIIII[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIIlllllIl(String lllllllllllllllIllIIIlllIIIIlIIl, String lllllllllllllllIllIIIlllIIIIlIII) {
    lllllllllllllllIllIIIlllIIIIlIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIlllIIIIIlll = new StringBuilder();
    char[] lllllllllllllllIllIIIlllIIIIIllI = lllllllllllllllIllIIIlllIIIIlIII.toCharArray();
    int lllllllllllllllIllIIIlllIIIIIlIl = llIIllIIIIIIII[1];
    char[] arrayOfChar1 = lllllllllllllllIllIIIlllIIIIlIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIIIIIIII[1];
    while (lIIIlIIIlIIIIIll(j, i)) {
      char lllllllllllllllIllIIIlllIIIIlIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIlllIIIIIlIl++;
      j++;
      "".length();
      if (" ".length() == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIlllIIIIIlll);
  }
  
  private static String lIIIlIIIIlllllII(String lllllllllllllllIllIIIlllIIIIIIIl, String lllllllllllllllIllIIIlllIIIIIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIIIIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIIIIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIlllIIIIIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIlllIIIIIIll.init(llIIllIIIIIIII[3], lllllllllllllllIllIIIlllIIIIIlII);
      return new String(lllllllllllllllIllIIIlllIIIIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIIIIIIlI) {
      lllllllllllllllIllIIIlllIIIIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIlIIIIIII() {
    llIIllIIIIIIII = new int[6];
    llIIllIIIIIIII[0] = " ".length();
    llIIllIIIIIIII[1] = ((0xB2 ^ 0x85) << " ".length() << " ".length() ^ 65 + 154 - 138 + 76) & ((0x4C ^ 0x5B) << " ".length() << " ".length() ^ 0x83 ^ 0x9E ^ -" ".length());
    llIIllIIIIIIII[2] = "   ".length();
    llIIllIIIIIIII[3] = " ".length() << " ".length();
    llIIllIIIIIIII[4] = " ".length() << " ".length() << " ".length();
    llIIllIIIIIIII[5] = 0 + 64 - -32 + 91 ^ (0x18 ^ 0x47) << " ".length();
  }
  
  private static boolean lIIIlIIIlIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIlIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIlIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\zero\alpine\type\Cancellable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */