package me.stupitdog.bhp;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.player.EntityPlayer;

public class f100000000000000000000000 {
  private static String[] llIIlIIIIllllI;
  
  private static Class[] llIIlIIIIlllll;
  
  private static final String[] llIIlIIIlIIllI;
  
  private static String[] llIIlIIIlIIlll;
  
  private static final int[] llIIlIIIlIlIlI;
  
  private void renderSkeleton(EntityPlayer lllllllllllllllIllIIlllIlIlIIIIl, float[][] lllllllllllllllIllIIlllIlIlIIIII, Color lllllllllllllllIllIIlllIlIIlllll) {
    // Byte code:
    //   0: fconst_1
    //   1: fconst_1
    //   2: fconst_1
    //   3: fconst_1
    //   4: <illegal opcode> 0 : (FFFF)V
    //   9: <illegal opcode> 1 : ()V
    //   14: aload_3
    //   15: <illegal opcode> 2 : (Ljava/awt/Color;)I
    //   20: i2f
    //   21: ldc 255.0
    //   23: fdiv
    //   24: aload_3
    //   25: <illegal opcode> 3 : (Ljava/awt/Color;)I
    //   30: i2f
    //   31: ldc 255.0
    //   33: fdiv
    //   34: aload_3
    //   35: <illegal opcode> 4 : (Ljava/awt/Color;)I
    //   40: i2f
    //   41: ldc 255.0
    //   43: fdiv
    //   44: aload_3
    //   45: <illegal opcode> 5 : (Ljava/awt/Color;)I
    //   50: i2f
    //   51: ldc 255.0
    //   53: fdiv
    //   54: <illegal opcode> 0 : (FFFF)V
    //   59: aload_1
    //   60: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   65: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)F
    //   70: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;F)Lnet/minecraft/util/math/Vec3d;
    //   75: astore #4
    //   77: aload #4
    //   79: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   84: dstore #5
    //   86: aload #4
    //   88: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   93: dstore #7
    //   95: aload #4
    //   97: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   102: dstore #9
    //   104: dload #5
    //   106: dload #7
    //   108: dload #9
    //   110: <illegal opcode> 12 : (DDD)V
    //   115: aload_1
    //   116: <illegal opcode> 13 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   121: fneg
    //   122: fconst_0
    //   123: fconst_1
    //   124: fconst_0
    //   125: <illegal opcode> 14 : (FFFF)V
    //   130: dconst_0
    //   131: dconst_0
    //   132: aload_1
    //   133: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   138: invokestatic lIIIIllIIIllllIl : (I)Z
    //   141: ifeq -> 174
    //   144: ldc2_w -0.235
    //   147: ldc ''
    //   149: invokevirtual length : ()I
    //   152: pop
    //   153: ldc ' '
    //   155: invokevirtual length : ()I
    //   158: ldc ' '
    //   160: invokevirtual length : ()I
    //   163: ldc ' '
    //   165: invokevirtual length : ()I
    //   168: ishl
    //   169: ishl
    //   170: ifne -> 175
    //   173: return
    //   174: dconst_0
    //   175: <illegal opcode> 12 : (DDD)V
    //   180: aload_1
    //   181: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   186: invokestatic lIIIIllIIIllllIl : (I)Z
    //   189: ifeq -> 264
    //   192: ldc 0.6
    //   194: ldc ''
    //   196: invokevirtual length : ()I
    //   199: pop
    //   200: sipush #159
    //   203: sipush #190
    //   206: ixor
    //   207: sipush #189
    //   210: sipush #176
    //   213: ixor
    //   214: ldc ' '
    //   216: invokevirtual length : ()I
    //   219: ldc ' '
    //   221: invokevirtual length : ()I
    //   224: ishl
    //   225: ishl
    //   226: ixor
    //   227: sipush #185
    //   230: sipush #160
    //   233: ixor
    //   234: ldc '   '
    //   236: invokevirtual length : ()I
    //   239: ldc ' '
    //   241: invokevirtual length : ()I
    //   244: ldc ' '
    //   246: invokevirtual length : ()I
    //   249: ishl
    //   250: ishl
    //   251: ixor
    //   252: ldc ' '
    //   254: invokevirtual length : ()I
    //   257: ineg
    //   258: ixor
    //   259: iand
    //   260: ifeq -> 266
    //   263: return
    //   264: ldc 0.75
    //   266: fstore #11
    //   268: <illegal opcode> 1 : ()V
    //   273: ldc2_w -0.125
    //   276: fload #11
    //   278: f2d
    //   279: dconst_0
    //   280: <illegal opcode> 12 : (DDD)V
    //   285: aload_2
    //   286: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   289: iconst_0
    //   290: iaload
    //   291: aaload
    //   292: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   295: iconst_1
    //   296: iaload
    //   297: faload
    //   298: fconst_0
    //   299: invokestatic lIIIIllIIIllllII : (FF)I
    //   302: invokestatic lIIIIllIIIllllIl : (I)Z
    //   305: ifeq -> 332
    //   308: aload_2
    //   309: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   312: iconst_0
    //   313: iaload
    //   314: aaload
    //   315: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   318: iconst_1
    //   319: iaload
    //   320: faload
    //   321: ldc 57.295776
    //   323: fmul
    //   324: fconst_1
    //   325: fconst_0
    //   326: fconst_0
    //   327: <illegal opcode> 14 : (FFFF)V
    //   332: aload_2
    //   333: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   336: iconst_0
    //   337: iaload
    //   338: aaload
    //   339: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   342: iconst_2
    //   343: iaload
    //   344: faload
    //   345: fconst_0
    //   346: invokestatic lIIIIllIIIllllII : (FF)I
    //   349: invokestatic lIIIIllIIIllllIl : (I)Z
    //   352: ifeq -> 379
    //   355: aload_2
    //   356: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   359: iconst_0
    //   360: iaload
    //   361: aaload
    //   362: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   365: iconst_2
    //   366: iaload
    //   367: faload
    //   368: ldc 57.295776
    //   370: fmul
    //   371: fconst_0
    //   372: fconst_1
    //   373: fconst_0
    //   374: <illegal opcode> 14 : (FFFF)V
    //   379: aload_2
    //   380: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   383: iconst_0
    //   384: iaload
    //   385: aaload
    //   386: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   389: iconst_3
    //   390: iaload
    //   391: faload
    //   392: fconst_0
    //   393: invokestatic lIIIIllIIIllllII : (FF)I
    //   396: invokestatic lIIIIllIIIllllIl : (I)Z
    //   399: ifeq -> 426
    //   402: aload_2
    //   403: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   406: iconst_0
    //   407: iaload
    //   408: aaload
    //   409: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   412: iconst_3
    //   413: iaload
    //   414: faload
    //   415: ldc 57.295776
    //   417: fmul
    //   418: fconst_0
    //   419: fconst_0
    //   420: fconst_1
    //   421: <illegal opcode> 14 : (FFFF)V
    //   426: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   429: iconst_0
    //   430: iaload
    //   431: <illegal opcode> 16 : (I)V
    //   436: dconst_0
    //   437: dconst_0
    //   438: dconst_0
    //   439: <illegal opcode> 17 : (DDD)V
    //   444: dconst_0
    //   445: fload #11
    //   447: fneg
    //   448: f2d
    //   449: dconst_0
    //   450: <illegal opcode> 17 : (DDD)V
    //   455: <illegal opcode> 18 : ()V
    //   460: <illegal opcode> 19 : ()V
    //   465: <illegal opcode> 1 : ()V
    //   470: ldc2_w 0.125
    //   473: fload #11
    //   475: f2d
    //   476: dconst_0
    //   477: <illegal opcode> 12 : (DDD)V
    //   482: aload_2
    //   483: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   486: iconst_4
    //   487: iaload
    //   488: aaload
    //   489: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   492: iconst_1
    //   493: iaload
    //   494: faload
    //   495: fconst_0
    //   496: invokestatic lIIIIllIIIllllII : (FF)I
    //   499: invokestatic lIIIIllIIIllllIl : (I)Z
    //   502: ifeq -> 529
    //   505: aload_2
    //   506: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   509: iconst_4
    //   510: iaload
    //   511: aaload
    //   512: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   515: iconst_1
    //   516: iaload
    //   517: faload
    //   518: ldc 57.295776
    //   520: fmul
    //   521: fconst_1
    //   522: fconst_0
    //   523: fconst_0
    //   524: <illegal opcode> 14 : (FFFF)V
    //   529: aload_2
    //   530: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   533: iconst_4
    //   534: iaload
    //   535: aaload
    //   536: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   539: iconst_2
    //   540: iaload
    //   541: faload
    //   542: fconst_0
    //   543: invokestatic lIIIIllIIIllllII : (FF)I
    //   546: invokestatic lIIIIllIIIllllIl : (I)Z
    //   549: ifeq -> 576
    //   552: aload_2
    //   553: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   556: iconst_4
    //   557: iaload
    //   558: aaload
    //   559: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   562: iconst_2
    //   563: iaload
    //   564: faload
    //   565: ldc 57.295776
    //   567: fmul
    //   568: fconst_0
    //   569: fconst_1
    //   570: fconst_0
    //   571: <illegal opcode> 14 : (FFFF)V
    //   576: aload_2
    //   577: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   580: iconst_4
    //   581: iaload
    //   582: aaload
    //   583: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   586: iconst_3
    //   587: iaload
    //   588: faload
    //   589: fconst_0
    //   590: invokestatic lIIIIllIIIllllII : (FF)I
    //   593: invokestatic lIIIIllIIIllllIl : (I)Z
    //   596: ifeq -> 623
    //   599: aload_2
    //   600: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   603: iconst_4
    //   604: iaload
    //   605: aaload
    //   606: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   609: iconst_3
    //   610: iaload
    //   611: faload
    //   612: ldc 57.295776
    //   614: fmul
    //   615: fconst_0
    //   616: fconst_0
    //   617: fconst_1
    //   618: <illegal opcode> 14 : (FFFF)V
    //   623: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   626: iconst_0
    //   627: iaload
    //   628: <illegal opcode> 16 : (I)V
    //   633: dconst_0
    //   634: dconst_0
    //   635: dconst_0
    //   636: <illegal opcode> 17 : (DDD)V
    //   641: dconst_0
    //   642: fload #11
    //   644: fneg
    //   645: f2d
    //   646: dconst_0
    //   647: <illegal opcode> 17 : (DDD)V
    //   652: <illegal opcode> 18 : ()V
    //   657: <illegal opcode> 19 : ()V
    //   662: dconst_0
    //   663: dconst_0
    //   664: aload_1
    //   665: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   670: invokestatic lIIIIllIIIllllIl : (I)Z
    //   673: ifeq -> 695
    //   676: ldc2_w 0.25
    //   679: ldc ''
    //   681: invokevirtual length : ()I
    //   684: pop
    //   685: ldc ' '
    //   687: invokevirtual length : ()I
    //   690: ineg
    //   691: ifle -> 696
    //   694: return
    //   695: dconst_0
    //   696: <illegal opcode> 12 : (DDD)V
    //   701: <illegal opcode> 1 : ()V
    //   706: dconst_0
    //   707: dstore #12
    //   709: aload_1
    //   710: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   715: invokestatic lIIIIllIIIllllIl : (I)Z
    //   718: ifeq -> 726
    //   721: ldc2_w -0.05
    //   724: dstore #12
    //   726: dconst_0
    //   727: dload #12
    //   729: aload_1
    //   730: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   735: invokestatic lIIIIllIIIllllIl : (I)Z
    //   738: ifeq -> 776
    //   741: ldc2_w -0.01725
    //   744: ldc ''
    //   746: invokevirtual length : ()I
    //   749: pop
    //   750: ldc '   '
    //   752: invokevirtual length : ()I
    //   755: ldc ' '
    //   757: invokevirtual length : ()I
    //   760: ldc ' '
    //   762: invokevirtual length : ()I
    //   765: ldc ' '
    //   767: invokevirtual length : ()I
    //   770: ishl
    //   771: ishl
    //   772: if_icmplt -> 777
    //   775: return
    //   776: dconst_0
    //   777: <illegal opcode> 12 : (DDD)V
    //   782: <illegal opcode> 1 : ()V
    //   787: ldc2_w -0.375
    //   790: fload #11
    //   792: f2d
    //   793: ldc2_w 0.55
    //   796: dadd
    //   797: dconst_0
    //   798: <illegal opcode> 12 : (DDD)V
    //   803: aload_2
    //   804: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   807: iconst_2
    //   808: iaload
    //   809: aaload
    //   810: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   813: iconst_1
    //   814: iaload
    //   815: faload
    //   816: fconst_0
    //   817: invokestatic lIIIIllIIIllllII : (FF)I
    //   820: invokestatic lIIIIllIIIllllIl : (I)Z
    //   823: ifeq -> 850
    //   826: aload_2
    //   827: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   830: iconst_2
    //   831: iaload
    //   832: aaload
    //   833: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   836: iconst_1
    //   837: iaload
    //   838: faload
    //   839: ldc 57.295776
    //   841: fmul
    //   842: fconst_1
    //   843: fconst_0
    //   844: fconst_0
    //   845: <illegal opcode> 14 : (FFFF)V
    //   850: aload_2
    //   851: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   854: iconst_2
    //   855: iaload
    //   856: aaload
    //   857: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   860: iconst_2
    //   861: iaload
    //   862: faload
    //   863: fconst_0
    //   864: invokestatic lIIIIllIIIllllII : (FF)I
    //   867: invokestatic lIIIIllIIIllllIl : (I)Z
    //   870: ifeq -> 897
    //   873: aload_2
    //   874: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   877: iconst_2
    //   878: iaload
    //   879: aaload
    //   880: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   883: iconst_2
    //   884: iaload
    //   885: faload
    //   886: ldc 57.295776
    //   888: fmul
    //   889: fconst_0
    //   890: fconst_1
    //   891: fconst_0
    //   892: <illegal opcode> 14 : (FFFF)V
    //   897: aload_2
    //   898: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   901: iconst_2
    //   902: iaload
    //   903: aaload
    //   904: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   907: iconst_3
    //   908: iaload
    //   909: faload
    //   910: fconst_0
    //   911: invokestatic lIIIIllIIIllllII : (FF)I
    //   914: invokestatic lIIIIllIIIllllIl : (I)Z
    //   917: ifeq -> 945
    //   920: aload_2
    //   921: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   924: iconst_2
    //   925: iaload
    //   926: aaload
    //   927: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   930: iconst_3
    //   931: iaload
    //   932: faload
    //   933: fneg
    //   934: ldc 57.295776
    //   936: fmul
    //   937: fconst_0
    //   938: fconst_0
    //   939: fconst_1
    //   940: <illegal opcode> 14 : (FFFF)V
    //   945: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   948: iconst_0
    //   949: iaload
    //   950: <illegal opcode> 16 : (I)V
    //   955: dconst_0
    //   956: dconst_0
    //   957: dconst_0
    //   958: <illegal opcode> 17 : (DDD)V
    //   963: dconst_0
    //   964: ldc2_w -0.5
    //   967: dconst_0
    //   968: <illegal opcode> 17 : (DDD)V
    //   973: <illegal opcode> 18 : ()V
    //   978: <illegal opcode> 19 : ()V
    //   983: <illegal opcode> 1 : ()V
    //   988: ldc2_w 0.375
    //   991: fload #11
    //   993: f2d
    //   994: ldc2_w 0.55
    //   997: dadd
    //   998: dconst_0
    //   999: <illegal opcode> 12 : (DDD)V
    //   1004: aload_2
    //   1005: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1008: iconst_3
    //   1009: iaload
    //   1010: aaload
    //   1011: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1014: iconst_1
    //   1015: iaload
    //   1016: faload
    //   1017: fconst_0
    //   1018: invokestatic lIIIIllIIIllllII : (FF)I
    //   1021: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1024: ifeq -> 1051
    //   1027: aload_2
    //   1028: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1031: iconst_3
    //   1032: iaload
    //   1033: aaload
    //   1034: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1037: iconst_1
    //   1038: iaload
    //   1039: faload
    //   1040: ldc 57.295776
    //   1042: fmul
    //   1043: fconst_1
    //   1044: fconst_0
    //   1045: fconst_0
    //   1046: <illegal opcode> 14 : (FFFF)V
    //   1051: aload_2
    //   1052: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1055: iconst_3
    //   1056: iaload
    //   1057: aaload
    //   1058: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1061: iconst_2
    //   1062: iaload
    //   1063: faload
    //   1064: fconst_0
    //   1065: invokestatic lIIIIllIIIllllII : (FF)I
    //   1068: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1071: ifeq -> 1098
    //   1074: aload_2
    //   1075: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1078: iconst_3
    //   1079: iaload
    //   1080: aaload
    //   1081: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1084: iconst_2
    //   1085: iaload
    //   1086: faload
    //   1087: ldc 57.295776
    //   1089: fmul
    //   1090: fconst_0
    //   1091: fconst_1
    //   1092: fconst_0
    //   1093: <illegal opcode> 14 : (FFFF)V
    //   1098: aload_2
    //   1099: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1102: iconst_3
    //   1103: iaload
    //   1104: aaload
    //   1105: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1108: iconst_3
    //   1109: iaload
    //   1110: faload
    //   1111: fconst_0
    //   1112: invokestatic lIIIIllIIIllllII : (FF)I
    //   1115: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1118: ifeq -> 1146
    //   1121: aload_2
    //   1122: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1125: iconst_3
    //   1126: iaload
    //   1127: aaload
    //   1128: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1131: iconst_3
    //   1132: iaload
    //   1133: faload
    //   1134: fneg
    //   1135: ldc 57.295776
    //   1137: fmul
    //   1138: fconst_0
    //   1139: fconst_0
    //   1140: fconst_1
    //   1141: <illegal opcode> 14 : (FFFF)V
    //   1146: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1149: iconst_0
    //   1150: iaload
    //   1151: <illegal opcode> 16 : (I)V
    //   1156: dconst_0
    //   1157: dconst_0
    //   1158: dconst_0
    //   1159: <illegal opcode> 17 : (DDD)V
    //   1164: dconst_0
    //   1165: ldc2_w -0.5
    //   1168: dconst_0
    //   1169: <illegal opcode> 17 : (DDD)V
    //   1174: <illegal opcode> 18 : ()V
    //   1179: <illegal opcode> 19 : ()V
    //   1184: <illegal opcode> 1 : ()V
    //   1189: dconst_0
    //   1190: fload #11
    //   1192: f2d
    //   1193: ldc2_w 0.55
    //   1196: dadd
    //   1197: dconst_0
    //   1198: <illegal opcode> 12 : (DDD)V
    //   1203: aload_2
    //   1204: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1207: iconst_1
    //   1208: iaload
    //   1209: aaload
    //   1210: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1213: iconst_1
    //   1214: iaload
    //   1215: faload
    //   1216: fconst_0
    //   1217: invokestatic lIIIIllIIIllllII : (FF)I
    //   1220: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1223: ifeq -> 1250
    //   1226: aload_2
    //   1227: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1230: iconst_1
    //   1231: iaload
    //   1232: aaload
    //   1233: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1236: iconst_1
    //   1237: iaload
    //   1238: faload
    //   1239: ldc 57.295776
    //   1241: fmul
    //   1242: fconst_1
    //   1243: fconst_0
    //   1244: fconst_0
    //   1245: <illegal opcode> 14 : (FFFF)V
    //   1250: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1253: iconst_0
    //   1254: iaload
    //   1255: <illegal opcode> 16 : (I)V
    //   1260: dconst_0
    //   1261: dconst_0
    //   1262: dconst_0
    //   1263: <illegal opcode> 17 : (DDD)V
    //   1268: dconst_0
    //   1269: ldc2_w 0.3
    //   1272: dconst_0
    //   1273: <illegal opcode> 17 : (DDD)V
    //   1278: <illegal opcode> 18 : ()V
    //   1283: <illegal opcode> 19 : ()V
    //   1288: <illegal opcode> 19 : ()V
    //   1293: aload_1
    //   1294: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   1299: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1302: ifeq -> 1333
    //   1305: ldc 25.0
    //   1307: ldc ''
    //   1309: invokevirtual length : ()I
    //   1312: pop
    //   1313: ldc ' '
    //   1315: invokevirtual length : ()I
    //   1318: ldc ' '
    //   1320: invokevirtual length : ()I
    //   1323: ldc ' '
    //   1325: invokevirtual length : ()I
    //   1328: ishl
    //   1329: if_icmplt -> 1334
    //   1332: return
    //   1333: fconst_0
    //   1334: fconst_1
    //   1335: fconst_0
    //   1336: fconst_0
    //   1337: <illegal opcode> 14 : (FFFF)V
    //   1342: aload_1
    //   1343: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   1348: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1351: ifeq -> 1359
    //   1354: ldc2_w -0.16175
    //   1357: dstore #12
    //   1359: dconst_0
    //   1360: dload #12
    //   1362: aload_1
    //   1363: <illegal opcode> 15 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   1368: invokestatic lIIIIllIIIllllIl : (I)Z
    //   1371: ifeq -> 1392
    //   1374: ldc2_w -0.48025
    //   1377: ldc ''
    //   1379: invokevirtual length : ()I
    //   1382: pop
    //   1383: ldc '   '
    //   1385: invokevirtual length : ()I
    //   1388: ifgt -> 1393
    //   1391: return
    //   1392: dconst_0
    //   1393: <illegal opcode> 12 : (DDD)V
    //   1398: <illegal opcode> 1 : ()V
    //   1403: dconst_0
    //   1404: fload #11
    //   1406: f2d
    //   1407: dconst_0
    //   1408: <illegal opcode> 12 : (DDD)V
    //   1413: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1416: iconst_0
    //   1417: iaload
    //   1418: <illegal opcode> 16 : (I)V
    //   1423: ldc2_w -0.125
    //   1426: dconst_0
    //   1427: dconst_0
    //   1428: <illegal opcode> 17 : (DDD)V
    //   1433: ldc2_w 0.125
    //   1436: dconst_0
    //   1437: dconst_0
    //   1438: <illegal opcode> 17 : (DDD)V
    //   1443: <illegal opcode> 18 : ()V
    //   1448: <illegal opcode> 19 : ()V
    //   1453: <illegal opcode> 1 : ()V
    //   1458: dconst_0
    //   1459: fload #11
    //   1461: f2d
    //   1462: dconst_0
    //   1463: <illegal opcode> 12 : (DDD)V
    //   1468: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1471: iconst_0
    //   1472: iaload
    //   1473: <illegal opcode> 16 : (I)V
    //   1478: dconst_0
    //   1479: dconst_0
    //   1480: dconst_0
    //   1481: <illegal opcode> 17 : (DDD)V
    //   1486: dconst_0
    //   1487: ldc2_w 0.55
    //   1490: dconst_0
    //   1491: <illegal opcode> 17 : (DDD)V
    //   1496: <illegal opcode> 18 : ()V
    //   1501: <illegal opcode> 19 : ()V
    //   1506: <illegal opcode> 1 : ()V
    //   1511: dconst_0
    //   1512: fload #11
    //   1514: f2d
    //   1515: ldc2_w 0.55
    //   1518: dadd
    //   1519: dconst_0
    //   1520: <illegal opcode> 12 : (DDD)V
    //   1525: getstatic me/stupitdog/bhp/f100000000000000000000000.llIIlIIIlIlIlI : [I
    //   1528: iconst_0
    //   1529: iaload
    //   1530: <illegal opcode> 16 : (I)V
    //   1535: ldc2_w -0.375
    //   1538: dconst_0
    //   1539: dconst_0
    //   1540: <illegal opcode> 17 : (DDD)V
    //   1545: ldc2_w 0.375
    //   1548: dconst_0
    //   1549: dconst_0
    //   1550: <illegal opcode> 17 : (DDD)V
    //   1555: <illegal opcode> 18 : ()V
    //   1560: <illegal opcode> 19 : ()V
    //   1565: <illegal opcode> 19 : ()V
    //   1570: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1571	0	lllllllllllllllIllIIlllIlIlIIIlI	Lme/stupitdog/bhp/f100000000000000000000000;
    //   0	1571	1	lllllllllllllllIllIIlllIlIlIIIIl	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	1571	2	lllllllllllllllIllIIlllIlIlIIIII	[[F
    //   0	1571	3	lllllllllllllllIllIIlllIlIIlllll	Ljava/awt/Color;
    //   77	1494	4	lllllllllllllllIllIIlllIlIIllllI	Lnet/minecraft/util/math/Vec3d;
    //   86	1485	5	lllllllllllllllIllIIlllIlIIlllIl	D
    //   95	1476	7	lllllllllllllllIllIIlllIlIIlllII	D
    //   104	1467	9	lllllllllllllllIllIIlllIlIIllIll	D
    //   268	1303	11	lllllllllllllllIllIIlllIlIIllIlI	F
    //   709	862	12	lllllllllllllllIllIIlllIlIIllIIl	D
  }
  
  static {
    lIIIIllIIIlllIll();
    lIIIIllIIIlllIIl();
    lIIIIllIIIlllIII();
    lIIIIllIIIllIlII();
  }
  
  private static CallSite lIIIIllIIIlIIllI(MethodHandles.Lookup lllllllllllllllIllIIlllIlIIlIIII, String lllllllllllllllIllIIlllIlIIIllll, MethodType lllllllllllllllIllIIlllIlIIIlllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlllIlIIlIllI = llIIlIIIIllllI[Integer.parseInt(lllllllllllllllIllIIlllIlIIIllll)].split(llIIlIIIlIIllI[llIIlIIIlIlIlI[1]]);
      Class<?> lllllllllllllllIllIIlllIlIIlIlIl = Class.forName(lllllllllllllllIllIIlllIlIIlIllI[llIIlIIIlIlIlI[1]]);
      String lllllllllllllllIllIIlllIlIIlIlII = lllllllllllllllIllIIlllIlIIlIllI[llIIlIIIlIlIlI[2]];
      MethodHandle lllllllllllllllIllIIlllIlIIlIIll = null;
      int lllllllllllllllIllIIlllIlIIlIIlI = lllllllllllllllIllIIlllIlIIlIllI[llIIlIIIlIlIlI[0]].length();
      if (lIIIIllIIIlllllI(lllllllllllllllIllIIlllIlIIlIIlI, llIIlIIIlIlIlI[3])) {
        MethodType lllllllllllllllIllIIlllIlIIllIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlllIlIIlIllI[llIIlIIIlIlIlI[3]], f100000000000000000000000.class.getClassLoader());
        if (lIIIIllIIIllllll(lllllllllllllllIllIIlllIlIIlIIlI, llIIlIIIlIlIlI[3])) {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findVirtual(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIllIII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findStatic(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIllIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlllIlIIlIlll = llIIlIIIIlllll[Integer.parseInt(lllllllllllllllIllIIlllIlIIlIllI[llIIlIIIlIlIlI[3]])];
        if (lIIIIllIIIllllll(lllllllllllllllIllIIlllIlIIlIIlI, llIIlIIIlIlIlI[0])) {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findGetter(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIlIlll);
          "".length();
          if (" ".length() << " ".length() << " ".length() == " ".length() << " ".length())
            return null; 
        } else if (lIIIIllIIIllllll(lllllllllllllllIllIIlllIlIIlIIlI, llIIlIIIlIlIlI[4])) {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findStaticGetter(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIlIlll);
          "".length();
          if (("   ".length() << (0x9D ^ 0x98) & ("   ".length() << (0x57 ^ 0x52) ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (lIIIIllIIIllllll(lllllllllllllllIllIIlllIlIIlIIlI, llIIlIIIlIlIlI[5])) {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findSetter(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIlIlll);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlllIlIIlIIll = lllllllllllllllIllIIlllIlIIlIIII.findStaticSetter(lllllllllllllllIllIIlllIlIIlIlIl, lllllllllllllllIllIIlllIlIIlIlII, lllllllllllllllIllIIlllIlIIlIlll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlllIlIIlIIll);
    } catch (Exception lllllllllllllllIllIIlllIlIIlIIIl) {
      lllllllllllllllIllIIlllIlIIlIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIIllIlII() {
    llIIlIIIIllllI = new String[llIIlIIIlIlIlI[6]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[7]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[2]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[8]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[3]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[5]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[0]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[9]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[4]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[10]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[5]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[1]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[11]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[12]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[9]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[4]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[13]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[14]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[15]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[2]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[8]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[13]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[12]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[16]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[17]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[18]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[19]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[15]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[7]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[0]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[20]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[3]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[14]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[17]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[16]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[20]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[10]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[19]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[18]];
    llIIlIIIIllllI[llIIlIIIlIlIlI[11]] = llIIlIIIlIIllI[llIIlIIIlIlIlI[6]];
    llIIlIIIIlllll = new Class[llIIlIIIlIlIlI[3]];
    llIIlIIIIlllll[llIIlIIIlIlIlI[1]] = double.class;
    llIIlIIIIlllll[llIIlIIIlIlIlI[2]] = float.class;
  }
  
  private static void lIIIIllIIIlllIII() {
    llIIlIIIlIIllI = new String[llIIlIIIlIlIlI[21]];
    llIIlIIIlIIllI[llIIlIIIlIlIlI[1]] = lIIIIllIIIllIlIl(llIIlIIIlIIlll[llIIlIIIlIlIlI[1]], llIIlIIIlIIlll[llIIlIIIlIlIlI[2]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[2]] = lIIIIllIIIllIllI(llIIlIIIlIIlll[llIIlIIIlIlIlI[3]], llIIlIIIlIIlll[llIIlIIIlIlIlI[0]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[3]] = lIIIIllIIIllIlll(llIIlIIIlIIlll[llIIlIIIlIlIlI[4]], llIIlIIIlIIlll[llIIlIIIlIlIlI[5]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[0]] = lIIIIllIIIllIlll(llIIlIIIlIIlll[llIIlIIIlIlIlI[11]], llIIlIIIlIIlll[llIIlIIIlIlIlI[9]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[4]] = lIIIIllIIIllIlll(llIIlIIIlIIlll[llIIlIIIlIlIlI[13]], llIIlIIIlIIlll[llIIlIIIlIlIlI[15]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[5]] = lIIIIllIIIllIlll(llIIlIIIlIIlll[llIIlIIIlIlIlI[8]], llIIlIIIlIIlll[llIIlIIIlIlIlI[12]]);
    llIIlIIIlIIllI[llIIlIIIlIlIlI[11]] = lIIIIllIIIllIllI("voXued3bQsX2OvZ818h2MM9gyYpTIESMSwqQaiL5mD+vuyBqUfQcPU0ZPVEcgFvZKYDYX3jpJBSpR2+0BIDbM8UVuM/EtenS", "TYTur");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[9]] = lIIIIllIIIllIllI("5hAENHx92vE3d5kKpLI+o6YOtNen5/MqY1iK0+cVd9avZafU308h6ZBllcS2YOfiqcdiIZY36A4=", "UUxfZ");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[13]] = lIIIIllIIIllIlll("qRDSqOFI1GpLgCvPBzR1e0/fezKlL53DtZJv195S/EI=", "omxyV");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[15]] = lIIIIllIIIllIlll("0TiJoCcYlJfaAV60aITPwlm2bQ+dUWUh2+bmjtrOV4lsWKVrL5jKSeZ1JX2jUlcOfshiPRT+vb47cXRPI0iNOjSzU4PHGlPl", "xVWlk");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[8]] = lIIIIllIIIllIlll("AADs2n7T9v9fN2OSKhp7+I5e3+GCJkIkMzAE9AeH0pnfqEmGPqvWCIF6Jp2UqW71oFN7KKorTpcRlGbeavG3zsMtw6HiAp+Q", "HjNff");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[12]] = lIIIIllIIIllIlll("wTC5E70/79lOuXvMrJE5Ol2MJnluZTnBQb9wbn/DlBTCleiDvUhfdFLYMNm+i1TzKfhx5NuzrxMVJp8DFeP5qRuVX/bG4kwWmjC1LufmKX4HUtxBXgupy428N81PNJESz/iU5UVqXGce9TU2tmpv1A==", "gVshC");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[17]] = lIIIIllIIIllIllI("KGgBZ8Ac1+LjFHWsVRPpD+0Sv5CZCkdjJJLu8ZiSJ/WPTY3lpsKQjXdFGzKKPS76", "Nlobs");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[19]] = lIIIIllIIIllIlIl("CjINXD4NORwRIQUxDVwwCD4cHCdKJRwcNwElHAB9IzsqBjIQMjQTPQUwHABpAiIXEQxVYEBDYVUIP0h7TQFDUg==", "dWyrS");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[7]] = lIIIIllIIIllIlIl("BygxSQMAIyAEHAgrMUkbHSQpSQMIOS1JOAwudgNUDyQgCwo2endTW1kSJF1eU21lRw==", "iMEgn");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[20]] = lIIIIllIIIllIllI("RGl+0cNMblU8xzWm9BpbOEVcyeHQPoiCVhlUoMWqviY=", "cSmVf");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[14]] = lIIIIllIIIllIlIl("IA8iNX8rGSB6EiUCOyZrLQsgBjQuVHx9GHBOdA==", "JnTTQ");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[16]] = lIIIIllIIIllIlIl("Cw4mSAcMBTcFGAQNJkgJCQI3CB5LGTcIDgAZNxREIgcBEgsRDh8HBAQMNxRQAx48BTVUXGtXWVI0MFxCIS8WTzxfSw==", "ekRfj");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[10]] = lIIIIllIIIllIlIl("DxAVZB0IGwQpAgATFWQVDwEIPglPBQ0rCQQHTw8eFRwVMyANFBgvAlsTFCQTPkJReklSKgAsSklcO3BQQQ==", "auaJp");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[18]] = lIIIIllIIIllIlll("kozdo7gixpsNsLzOqM7qZkNAbMat76UasE+4Py3jOD9s1f06Oay/y23W4cSNuvJGCexuMqkXAUtZia9Lrn5WoA==", "DdQch");
    llIIlIIIlIIllI[llIIlIIIlIlIlI[6]] = lIIIIllIIIllIlIl("FiAZSQQRKwgEGxkjGUkKFCwICR1WCAQJDBs3DAEdQiMYCQonclxTWEgaFV1BUQkDAh1XKAQJDBs3DAEdVyYBDgwWMUIqABYgDhUIHjFWXUk=", "xEmgi");
    llIIlIIIlIIlll = null;
  }
  
  private static void lIIIIllIIIlllIIl() {
    String str = (new Exception()).getStackTrace()[llIIlIIIlIlIlI[1]].getFileName();
    llIIlIIIlIIlll = str.substring(str.indexOf("ä") + llIIlIIIlIlIlI[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIIIllIlIl(String lllllllllllllllIllIIlllIlIIIllII, String lllllllllllllllIllIIlllIlIIIlIll) {
    lllllllllllllllIllIIlllIlIIIllII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlllIlIIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlllIlIIIlIlI = new StringBuilder();
    char[] lllllllllllllllIllIIlllIlIIIlIIl = lllllllllllllllIllIIlllIlIIIlIll.toCharArray();
    int lllllllllllllllIllIIlllIlIIIlIII = llIIlIIIlIlIlI[1];
    char[] arrayOfChar1 = lllllllllllllllIllIIlllIlIIIllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIIlIlIlI[1];
    while (lIIIIllIIlIIIIII(j, i)) {
      char lllllllllllllllIllIIlllIlIIIllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlllIlIIIlIII++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlllIlIIIlIlI);
  }
  
  private static String lIIIIllIIIllIllI(String lllllllllllllllIllIIlllIlIIIIlII, String lllllllllllllllIllIIlllIlIIIIIll) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllIlIIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllIlIIIIIll.getBytes(StandardCharsets.UTF_8)), llIIlIIIlIlIlI[13]), "DES");
      Cipher lllllllllllllllIllIIlllIlIIIIllI = Cipher.getInstance("DES");
      lllllllllllllllIllIIlllIlIIIIllI.init(llIIlIIIlIlIlI[3], lllllllllllllllIllIIlllIlIIIIlll);
      return new String(lllllllllllllllIllIIlllIlIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllIlIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllIlIIIIlIl) {
      lllllllllllllllIllIIlllIlIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIIIllIlll(String lllllllllllllllIllIIlllIIlllllll, String lllllllllllllllIllIIlllIIllllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllIlIIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllIIllllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlllIlIIIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlllIlIIIIIIl.init(llIIlIIIlIlIlI[3], lllllllllllllllIllIIlllIlIIIIIlI);
      return new String(lllllllllllllllIllIIlllIlIIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllIIlllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllIlIIIIIII) {
      lllllllllllllllIllIIlllIlIIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIIlllIll() {
    llIIlIIIlIlIlI = new int[22];
    llIIlIIIlIlIlI[0] = "   ".length();
    llIIlIIIlIlIlI[1] = " ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF);
    llIIlIIIlIlIlI[2] = " ".length();
    llIIlIIIlIlIlI[3] = " ".length() << " ".length();
    llIIlIIIlIlIlI[4] = " ".length() << " ".length() << " ".length();
    llIIlIIIlIlIlI[5] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0xA7 ^ 0xB2;
    llIIlIIIlIlIlI[6] = (0x3B ^ 0x3E) << " ".length() << " ".length();
    llIIlIIIlIlIlI[7] = ((0x4E ^ 0x55) << " ".length() << " ".length() ^ 0x64 ^ 0xF) << " ".length();
    llIIlIIIlIlIlI[8] = ((0x9A ^ 0x89) << " ".length() << " ".length() ^ 0x5C ^ 0x15) << " ".length();
    llIIlIIIlIlIlI[9] = 0xAB ^ 0xAC;
    llIIlIIIlIlIlI[10] = (113 + 99 - 201 + 160 ^ (0xD1 ^ 0x80) << " ".length()) << " ".length();
    llIIlIIIlIlIlI[11] = "   ".length() << " ".length();
    llIIlIIIlIlIlI[12] = 0x15 ^ 0x1E;
    llIIlIIIlIlIlI[13] = " ".length() << "   ".length();
    llIIlIIIlIlIlI[14] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIIlIlIlI[15] = 0x45 ^ 0x78 ^ (0xB8 ^ 0xB5) << " ".length() << " ".length();
    llIIlIIIlIlIlI[16] = 0x66 ^ 0x77;
    llIIlIIIlIlIlI[17] = "   ".length() << " ".length() << " ".length();
    llIIlIIIlIlIlI[18] = 22 + 132 - 146 + 201 ^ (0x74 ^ 0x15) << " ".length();
    llIIlIIIlIlIlI[19] = "   ".length() << (0x1E ^ 0x1B) ^ 0x78 ^ 0x15;
    llIIlIIIlIlIlI[20] = 112 + 41 - 45 + 47 ^ (0x66 ^ 0x43) << " ".length() << " ".length();
    llIIlIIIlIlIlI[21] = 0x61 ^ 0x74;
  }
  
  private static boolean lIIIIllIIIllllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIIlIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIIIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIIIllllIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static int lIIIIllIIIllllII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */