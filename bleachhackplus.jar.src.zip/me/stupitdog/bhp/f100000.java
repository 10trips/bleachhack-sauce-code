package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;

public class f100000 extends au {
  @EventHandler
  private final Listener<f10000000000000000000000000000000000000> waterPushEventListener;
  
  @EventHandler
  private final Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
  
  private static String[] llIIIIllIIIlll;
  
  private static Class[] llIIIIllIIlIII;
  
  private static final String[] llIIIIllIIlIIl;
  
  private static String[] llIIIIllIIlIlI;
  
  private static final int[] llIIIIllIIlllI;
  
  public f100000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: putfield waterPushEventListener : Lme/zero/alpine/listener/Listener;
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   75: getstatic me/stupitdog/bhp/f100000.llIIIIllIIlllI : [I
    //   78: iconst_0
    //   79: iaload
    //   80: anewarray java/util/function/Predicate
    //   83: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   86: putfield pushListener : Lme/zero/alpine/listener/Listener;
    //   89: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	90	0	lllllllllllllllIllIllIIIlllIllIl	Lme/stupitdog/bhp/f100000;
  }
  
  static {
    lIIIIIlIllllIlIl();
    lIIIIIlIlllIlllI();
    lIIIIIlIlllIllIl();
    lIIIIIlIlllIlIIl();
  }
  
  private static CallSite lIIIIIlIlllIIlIl(MethodHandles.Lookup lllllllllllllllIllIllIIIlllIIIlI, String lllllllllllllllIllIllIIIlllIIIIl, MethodType lllllllllllllllIllIllIIIlllIIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIIlllIlIII = llIIIIllIIIlll[Integer.parseInt(lllllllllllllllIllIllIIIlllIIIIl)].split(llIIIIllIIlIIl[llIIIIllIIlllI[3]]);
      Class<?> lllllllllllllllIllIllIIIlllIIlll = Class.forName(lllllllllllllllIllIllIIIlllIlIII[llIIIIllIIlllI[0]]);
      String lllllllllllllllIllIllIIIlllIIllI = lllllllllllllllIllIllIIIlllIlIII[llIIIIllIIlllI[1]];
      MethodHandle lllllllllllllllIllIllIIIlllIIlIl = null;
      int lllllllllllllllIllIllIIIlllIIlII = lllllllllllllllIllIllIIIlllIlIII[llIIIIllIIlllI[3]].length();
      if (lIIIIIlIllllIlll(lllllllllllllllIllIllIIIlllIIlII, llIIIIllIIlllI[2])) {
        MethodType lllllllllllllllIllIllIIIlllIlIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIIlllIlIII[llIIIIllIIlllI[2]], f100000.class.getClassLoader());
        if (lIIIIIlIlllllIII(lllllllllllllllIllIllIIIlllIIlII, llIIIIllIIlllI[2])) {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findVirtual(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIlI);
          "".length();
          if (-(0xA6 ^ 0xA3) >= 0)
            return null; 
        } else {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findStatic(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIlI);
        } 
        "".length();
        if ("   ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIIlllIlIIl = llIIIIllIIlIII[Integer.parseInt(lllllllllllllllIllIllIIIlllIlIII[llIIIIllIIlllI[2]])];
        if (lIIIIIlIlllllIII(lllllllllllllllIllIllIIIlllIIlII, llIIIIllIIlllI[3])) {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findGetter(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIIl);
          "".length();
          if (-(0x4 ^ 0x3B ^ 0x28 ^ 0x13) > 0)
            return null; 
        } else if (lIIIIIlIlllllIII(lllllllllllllllIllIllIIIlllIIlII, llIIIIllIIlllI[4])) {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findStaticGetter(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIIl);
          "".length();
          if (((61 + 67 - 76 + 85 ^ (0x5B ^ 0x70) << " ".length() << " ".length()) & ((0x2F ^ 0x26) << " ".length() << " ".length() ^ " ".length() ^ -" ".length())) == "   ".length())
            return null; 
        } else if (lIIIIIlIlllllIII(lllllllllllllllIllIllIIIlllIIlII, llIIIIllIIlllI[5])) {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findSetter(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIIl);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIllIIIlllIIlIl = lllllllllllllllIllIllIIIlllIIIlI.findStaticSetter(lllllllllllllllIllIllIIIlllIIlll, lllllllllllllllIllIllIIIlllIIllI, lllllllllllllllIllIllIIIlllIlIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIIlllIIlIl);
    } catch (Exception lllllllllllllllIllIllIIIlllIIIll) {
      lllllllllllllllIllIllIIIlllIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlllIlIIl() {
    llIIIIllIIIlll = new String[llIIIIllIIlllI[3]];
    llIIIIllIIIlll[llIIIIllIIlllI[2]] = llIIIIllIIlIIl[llIIIIllIIlllI[4]];
    llIIIIllIIIlll[llIIIIllIIlllI[1]] = llIIIIllIIlIIl[llIIIIllIIlllI[5]];
    llIIIIllIIIlll[llIIIIllIIlllI[0]] = llIIIIllIIlIIl[llIIIIllIIlllI[6]];
    llIIIIllIIlIII = new Class[llIIIIllIIlllI[2]];
    llIIIIllIIlIII[llIIIIllIIlllI[1]] = Listener.class;
    llIIIIllIIlIII[llIIIIllIIlllI[0]] = f13.class;
  }
  
  private static void lIIIIIlIlllIllIl() {
    llIIIIllIIlIIl = new String[llIIIIllIIlllI[7]];
    llIIIIllIIlIIl[llIIIIllIIlllI[0]] = lIIIIIlIlllIlIlI(llIIIIllIIlIlI[llIIIIllIIlllI[0]], llIIIIllIIlIlI[llIIIIllIIlllI[1]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[1]] = lIIIIIlIlllIlIlI(llIIIIllIIlIlI[llIIIIllIIlllI[2]], llIIIIllIIlIlI[llIIIIllIIlllI[3]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[2]] = lIIIIIlIlllIllII(llIIIIllIIlIlI[llIIIIllIIlllI[4]], llIIIIllIIlIlI[llIIIIllIIlllI[5]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[3]] = lIIIIIlIlllIlIlI(llIIIIllIIlIlI[llIIIIllIIlllI[6]], llIIIIllIIlIlI[llIIIIllIIlllI[7]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[4]] = lIIIIIlIlllIlIlI(llIIIIllIIlIlI[llIIIIllIIlllI[8]], llIIIIllIIlIlI[llIIIIllIIlllI[9]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[5]] = lIIIIIlIlllIllII(llIIIIllIIlIlI[llIIIIllIIlllI[10]], llIIIIllIIlIlI[llIIIIllIIlllI[11]]);
    llIIIIllIIlIIl[llIIIIllIIlllI[6]] = lIIIIIlIlllIllII(llIIIIllIIlIlI[llIIIIllIIlllI[12]], llIIIIllIIlIlI[llIIIIllIIlllI[13]]);
    llIIIIllIIlIlI = null;
  }
  
  private static void lIIIIIlIlllIlllI() {
    String str = (new Exception()).getStackTrace()[llIIIIllIIlllI[0]].getFileName();
    llIIIIllIIlIlI = str.substring(str.indexOf("ä") + llIIIIllIIlllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIlllIllII(String lllllllllllllllIllIllIIIllIllllI, String lllllllllllllllIllIllIIIllIlllIl) {
    lllllllllllllllIllIllIIIllIllllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIllIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIIllIlllII = new StringBuilder();
    char[] lllllllllllllllIllIllIIIllIllIll = lllllllllllllllIllIllIIIllIlllIl.toCharArray();
    int lllllllllllllllIllIllIIIllIllIlI = llIIIIllIIlllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIIllIllllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIllIIlllI[0];
    while (lIIIIIlIlllllIll(j, i)) {
      char lllllllllllllllIllIllIIIllIlllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIIllIllIlI++;
      j++;
      "".length();
      if (-"  ".length() > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIIllIlllII);
  }
  
  private static String lIIIIIlIlllIlIlI(String lllllllllllllllIllIllIIIllIlIllI, String lllllllllllllllIllIllIIIllIlIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIllIllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIllIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIIllIllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIIllIllIII.init(llIIIIllIIlllI[2], lllllllllllllllIllIllIIIllIllIIl);
      return new String(lllllllllllllllIllIllIIIllIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIllIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIllIlIlll) {
      lllllllllllllllIllIllIIIllIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIllllIlIl() {
    llIIIIllIIlllI = new int[14];
    llIIIIllIIlllI[0] = (0x5D ^ 0x78) << " ".length() & ((0x3E ^ 0x1B) << " ".length() ^ 0xFFFFFFFF);
    llIIIIllIIlllI[1] = " ".length();
    llIIIIllIIlllI[2] = " ".length() << " ".length();
    llIIIIllIIlllI[3] = "   ".length();
    llIIIIllIIlllI[4] = " ".length() << " ".length() << " ".length();
    llIIIIllIIlllI[5] = 82 + 4 - 16 + 83 ^ (0x27 ^ 0x0) << " ".length() << " ".length();
    llIIIIllIIlllI[6] = "   ".length() << " ".length();
    llIIIIllIIlllI[7] = 0x4A ^ 0x4D;
    llIIIIllIIlllI[8] = " ".length() << "   ".length();
    llIIIIllIIlllI[9] = (0xB7 ^ 0x9A) << " ".length() ^ 0x21 ^ 0x72;
    llIIIIllIIlllI[10] = (0x98 ^ 0x9D) << " ".length();
    llIIIIllIIlllI[11] = (0x80 ^ 0x91) << "   ".length() ^ 50 + 9 - 18 + 90;
    llIIIIllIIlllI[12] = "   ".length() << " ".length() << " ".length();
    llIIIIllIIlllI[13] = 0x4D ^ 0x78 ^ (0x2E ^ 0x29) << "   ".length();
  }
  
  private static boolean lIIIIIlIlllllIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIlllllIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIllllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */