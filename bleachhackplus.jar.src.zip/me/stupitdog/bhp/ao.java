package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ao {
  private long current;
  
  private static String[] llIIIlIIIlllll;
  
  private static Class[] llIIIlIIlIIIII;
  
  private static final String[] llIIIlIIlIIIIl;
  
  private static String[] llIIIlIIlIIIlI;
  
  private static final int[] llIIIlIIlIIIll;
  
  public ao() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: <illegal opcode> 0 : ()J
    //   10: <illegal opcode> 1 : (Lme/stupitdog/bhp/ao;J)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIllIlIllIlIlIIlIl	Lme/stupitdog/bhp/ao;
  }
  
  public boolean hasReached(long lllllllllllllllIllIlIllIlIlIIIll) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()J
    //   5: aload_0
    //   6: <illegal opcode> 2 : (Lme/stupitdog/bhp/ao;)J
    //   11: lsub
    //   12: lload_1
    //   13: invokestatic lIIIIIllllIIIlII : (JJ)I
    //   16: invokestatic lIIIIIllllIIIlIl : (I)Z
    //   19: ifeq -> 78
    //   22: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   25: iconst_0
    //   26: iaload
    //   27: ldc ''
    //   29: invokevirtual length : ()I
    //   32: pop
    //   33: ldc ' '
    //   35: invokevirtual length : ()I
    //   38: ldc ' '
    //   40: invokevirtual length : ()I
    //   43: ishl
    //   44: ifgt -> 83
    //   47: ldc ' '
    //   49: invokevirtual length : ()I
    //   52: ldc '   '
    //   54: invokevirtual length : ()I
    //   57: ishl
    //   58: ldc ' '
    //   60: invokevirtual length : ()I
    //   63: ldc '   '
    //   65: invokevirtual length : ()I
    //   68: ishl
    //   69: ldc ' '
    //   71: invokevirtual length : ()I
    //   74: ineg
    //   75: ixor
    //   76: iand
    //   77: ireturn
    //   78: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   81: iconst_1
    //   82: iaload
    //   83: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	84	0	lllllllllllllllIllIlIllIlIlIIlII	Lme/stupitdog/bhp/ao;
    //   0	84	1	lllllllllllllllIllIlIllIlIlIIIll	J
  }
  
  public boolean hasReached(long lllllllllllllllIllIlIllIlIlIIIIl, boolean lllllllllllllllIllIlIllIlIlIIIII) {
    // Byte code:
    //   0: iload_3
    //   1: invokestatic lIIIIIllllIIIlll : (I)Z
    //   4: ifeq -> 13
    //   7: aload_0
    //   8: <illegal opcode> 3 : (Lme/stupitdog/bhp/ao;)V
    //   13: <illegal opcode> 0 : ()J
    //   18: aload_0
    //   19: <illegal opcode> 2 : (Lme/stupitdog/bhp/ao;)J
    //   24: lsub
    //   25: lload_1
    //   26: invokestatic lIIIIIllllIIIllI : (JJ)I
    //   29: invokestatic lIIIIIllllIIIlIl : (I)Z
    //   32: ifeq -> 71
    //   35: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   38: iconst_0
    //   39: iaload
    //   40: ldc ''
    //   42: invokevirtual length : ()I
    //   45: pop
    //   46: ldc '   '
    //   48: invokevirtual length : ()I
    //   51: ineg
    //   52: iflt -> 76
    //   55: bipush #107
    //   57: bipush #124
    //   59: ixor
    //   60: sipush #153
    //   63: sipush #142
    //   66: ixor
    //   67: iconst_m1
    //   68: ixor
    //   69: iand
    //   70: ireturn
    //   71: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   74: iconst_1
    //   75: iaload
    //   76: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIllIlIllIlIlIIIlI	Lme/stupitdog/bhp/ao;
    //   0	77	1	lllllllllllllllIllIlIllIlIlIIIIl	J
    //   0	77	3	lllllllllllllllIllIlIllIlIlIIIII	Z
  }
  
  public void reset() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : ()J
    //   6: <illegal opcode> 1 : (Lme/stupitdog/bhp/ao;J)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIllIlIIlllll	Lme/stupitdog/bhp/ao;
  }
  
  public long getTimePassed() {
    // Byte code:
    //   0: <illegal opcode> 0 : ()J
    //   5: aload_0
    //   6: <illegal opcode> 2 : (Lme/stupitdog/bhp/ao;)J
    //   11: lsub
    //   12: lreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIllIlIIllllI	Lme/stupitdog/bhp/ao;
  }
  
  public boolean sleep(long lllllllllllllllIllIlIllIlIIlllII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/ao;)J
    //   6: lload_1
    //   7: invokestatic lIIIIIllllIIlIII : (JJ)I
    //   10: invokestatic lIIIIIllllIIIlIl : (I)Z
    //   13: ifeq -> 28
    //   16: aload_0
    //   17: <illegal opcode> 3 : (Lme/stupitdog/bhp/ao;)V
    //   22: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   25: iconst_0
    //   26: iaload
    //   27: ireturn
    //   28: getstatic me/stupitdog/bhp/ao.llIIIlIIlIIIll : [I
    //   31: iconst_1
    //   32: iaload
    //   33: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	34	0	lllllllllllllllIllIlIllIlIIlllIl	Lme/stupitdog/bhp/ao;
    //   0	34	1	lllllllllllllllIllIlIllIlIIlllII	J
  }
  
  public long time() {
    // Byte code:
    //   0: <illegal opcode> 0 : ()J
    //   5: aload_0
    //   6: <illegal opcode> 2 : (Lme/stupitdog/bhp/ao;)J
    //   11: lsub
    //   12: lreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIllIlIIllIll	Lme/stupitdog/bhp/ao;
  }
  
  static {
    lIIIIIllllIIIIll();
    lIIIIIllllIIIIlI();
    lIIIIIllllIIIIIl();
    lIIIIIlllIlllllI();
  }
  
  private static CallSite lIIIIIlllIllllIl(MethodHandles.Lookup lllllllllllllllIllIlIllIlIIlIIlI, String lllllllllllllllIllIlIllIlIIlIIIl, MethodType lllllllllllllllIllIlIllIlIIlIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIllIlIIllIII = llIIIlIIIlllll[Integer.parseInt(lllllllllllllllIllIlIllIlIIlIIIl)].split(llIIIlIIlIIIIl[llIIIlIIlIIIll[1]]);
      Class<?> lllllllllllllllIllIlIllIlIIlIlll = Class.forName(lllllllllllllllIllIlIllIlIIllIII[llIIIlIIlIIIll[1]]);
      String lllllllllllllllIllIlIllIlIIlIllI = lllllllllllllllIllIlIllIlIIllIII[llIIIlIIlIIIll[0]];
      MethodHandle lllllllllllllllIllIlIllIlIIlIlIl = null;
      int lllllllllllllllIllIlIllIlIIlIlII = lllllllllllllllIllIlIllIlIIllIII[llIIIlIIlIIIll[2]].length();
      if (lIIIIIllllIIlIIl(lllllllllllllllIllIlIllIlIIlIlII, llIIIlIIlIIIll[3])) {
        MethodType lllllllllllllllIllIlIllIlIIllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIllIlIIllIII[llIIIlIIlIIIll[3]], ao.class.getClassLoader());
        if (lIIIIIllllIIlIlI(lllllllllllllllIllIlIllIlIIlIlII, llIIIlIIlIIIll[3])) {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findVirtual(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findStatic(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIlI);
        } 
        "".length();
        if ("   ".length() > "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIllIlIIllIIl = llIIIlIIlIIIII[Integer.parseInt(lllllllllllllllIllIlIllIlIIllIII[llIIIlIIlIIIll[3]])];
        if (lIIIIIllllIIlIlI(lllllllllllllllIllIlIllIlIIlIlII, llIIIlIIlIIIll[2])) {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findGetter(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIIl);
          "".length();
          if (((0x99 ^ 0x9E ^ (0x71 ^ 0x64) << " ".length()) << " ".length() & ((0x84 ^ 0x81 ^ (0x62 ^ 0x67) << "   ".length()) << " ".length() ^ -" ".length())) > " ".length())
            return null; 
        } else if (lIIIIIllllIIlIlI(lllllllllllllllIllIlIllIlIIlIlII, llIIIlIIlIIIll[4])) {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findStaticGetter(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIIl);
          "".length();
          if (" ".length() <= ((0x60 ^ 0x73) << " ".length() << " ".length() & ((0x5C ^ 0x4F) << " ".length() << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lIIIIIllllIIlIlI(lllllllllllllllIllIlIllIlIIlIlII, llIIIlIIlIIIll[5])) {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findSetter(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIllIlIIlIlIl = lllllllllllllllIllIlIllIlIIlIIlI.findStaticSetter(lllllllllllllllIllIlIllIlIIlIlll, lllllllllllllllIllIlIllIlIIlIllI, lllllllllllllllIllIlIllIlIIllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIllIlIIlIlIl);
    } catch (Exception lllllllllllllllIllIlIllIlIIlIIll) {
      lllllllllllllllIllIlIllIlIIlIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlllIlllllI() {
    llIIIlIIIlllll = new String[llIIIlIIlIIIll[5]];
    llIIIlIIIlllll[llIIIlIIlIIIll[3]] = llIIIlIIlIIIIl[llIIIlIIlIIIll[0]];
    llIIIlIIIlllll[llIIIlIIlIIIll[4]] = llIIIlIIlIIIIl[llIIIlIIlIIIll[3]];
    llIIIlIIIlllll[llIIIlIIlIIIll[1]] = llIIIlIIlIIIIl[llIIIlIIlIIIll[2]];
    llIIIlIIIlllll[llIIIlIIlIIIll[2]] = llIIIlIIlIIIIl[llIIIlIIlIIIll[4]];
    llIIIlIIIlllll[llIIIlIIlIIIll[0]] = llIIIlIIlIIIIl[llIIIlIIlIIIll[5]];
    llIIIlIIlIIIII = new Class[llIIIlIIlIIIll[0]];
    llIIIlIIlIIIII[llIIIlIIlIIIll[1]] = long.class;
  }
  
  private static void lIIIIIllllIIIIIl() {
    llIIIlIIlIIIIl = new String[llIIIlIIlIIIll[6]];
    llIIIlIIlIIIIl[llIIIlIIlIIIll[1]] = lIIIIIlllIllllll(llIIIlIIlIIIlI[llIIIlIIlIIIll[1]], llIIIlIIlIIIlI[llIIIlIIlIIIll[0]]);
    llIIIlIIlIIIIl[llIIIlIIlIIIll[0]] = lIIIIIlllIllllll(llIIIlIIlIIIlI[llIIIlIIlIIIll[3]], llIIIlIIlIIIlI[llIIIlIIlIIIll[2]]);
    llIIIlIIlIIIIl[llIIIlIIlIIIll[3]] = lIIIIIllllIIIIII(llIIIlIIlIIIlI[llIIIlIIlIIIll[4]], llIIIlIIlIIIlI[llIIIlIIlIIIll[5]]);
    llIIIlIIlIIIIl[llIIIlIIlIIIll[2]] = lIIIIIlllIllllll(llIIIlIIlIIIlI[llIIIlIIlIIIll[6]], llIIIlIIlIIIlI[llIIIlIIlIIIll[7]]);
    llIIIlIIlIIIIl[llIIIlIIlIIIll[4]] = lIIIIIllllIIIIII(llIIIlIIlIIIlI[llIIIlIIlIIIll[8]], llIIIlIIlIIIlI[llIIIlIIlIIIll[9]]);
    llIIIlIIlIIIIl[llIIIlIIlIIIll[5]] = lIIIIIllllIIIIII(llIIIlIIlIIIlI[llIIIlIIlIIIll[10]], llIIIlIIlIIIlI[llIIIlIIlIIIll[11]]);
    llIIIlIIlIIIlI = null;
  }
  
  private static void lIIIIIllllIIIIlI() {
    String str = (new Exception()).getStackTrace()[llIIIlIIlIIIll[1]].getFileName();
    llIIIlIIlIIIlI = str.substring(str.indexOf("ä") + llIIIlIIlIIIll[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIllllIIIIII(String lllllllllllllllIllIlIllIlIIIllII, String lllllllllllllllIllIlIllIlIIIlIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIllIlIIIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIllIlIIIlIll.getBytes(StandardCharsets.UTF_8)), llIIIlIIlIIIll[8]), "DES");
      Cipher lllllllllllllllIllIlIllIlIIIlllI = Cipher.getInstance("DES");
      lllllllllllllllIllIlIllIlIIIlllI.init(llIIIlIIlIIIll[3], lllllllllllllllIllIlIllIlIIIllll);
      return new String(lllllllllllllllIllIlIllIlIIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIllIlIIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIllIlIIIllIl) {
      lllllllllllllllIllIlIllIlIIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlllIllllll(String lllllllllllllllIllIlIllIlIIIlIIl, String lllllllllllllllIllIlIllIlIIIlIII) {
    lllllllllllllllIllIlIllIlIIIlIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIllIlIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIllIlIIIIlll = new StringBuilder();
    char[] lllllllllllllllIllIlIllIlIIIIllI = lllllllllllllllIllIlIllIlIIIlIII.toCharArray();
    int lllllllllllllllIllIlIllIlIIIIlIl = llIIIlIIlIIIll[1];
    char[] arrayOfChar1 = lllllllllllllllIllIlIllIlIIIlIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIIlIIIll[1];
    while (lIIIIIllllIIlIll(j, i)) {
      char lllllllllllllllIllIlIllIlIIIlIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIllIlIIIIlIl++;
      j++;
      "".length();
      if ((((0x4A ^ 0x1F) << " ".length() ^ 78 + 149 - 167 + 101) << " ".length() & (((0xA8 ^ 0x8D) << " ".length() << " ".length() ^ 145 + 141 - 228 + 101) << " ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIllIlIIIIlll);
  }
  
  private static void lIIIIIllllIIIIll() {
    llIIIlIIlIIIll = new int[12];
    llIIIlIIlIIIll[0] = " ".length();
    llIIIlIIlIIIll[1] = (0x60 ^ 0x71) & (0x72 ^ 0x63 ^ 0xFFFFFFFF);
    llIIIlIIlIIIll[2] = "   ".length();
    llIIIlIIlIIIll[3] = " ".length() << " ".length();
    llIIIlIIlIIIll[4] = " ".length() << " ".length() << " ".length();
    llIIIlIIlIIIll[5] = (0x2A ^ 0x35) << " ".length() << " ".length() ^ 0x26 ^ 0x5F;
    llIIIlIIlIIIll[6] = "   ".length() << " ".length();
    llIIIlIIlIIIll[7] = 0xB2 ^ 0xB5;
    llIIIlIIlIIIll[8] = " ".length() << "   ".length();
    llIIIlIIlIIIll[9] = (0x25 ^ 0x32) << " ".length() ^ 0xAE ^ 0x89;
    llIIIlIIlIIIll[10] = (0x4 ^ 0x1) << " ".length();
    llIIIlIIlIIIll[11] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0x30 ^ 0x2B;
  }
  
  private static boolean lIIIIIllllIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIllllIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllllIIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIllllIIIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIllllIIIlIl(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static int lIIIIIllllIIIlII(long paramLong1, long paramLong2) {
    return paramLong1 cmp paramLong2;
  }
  
  private static int lIIIIIllllIIIllI(long paramLong1, long paramLong2) {
    return paramLong1 cmp paramLong2;
  }
  
  private static int lIIIIIllllIIlIII(long paramLong1, long paramLong2) {
    return paramLong1 cmp paramLong2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ao.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */