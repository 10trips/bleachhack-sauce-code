package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.gui.FontRenderer;

public class af {
  private static String[] lIlllIIlIIllll;
  
  private static Class[] lIlllIIlIlIIII;
  
  private static final String[] lIlllIIlIlIlll;
  
  private static String[] lIlllIIlIllIII;
  
  private static final int[] lIlllIIlIllIIl;
  
  public static void drawStringWithShadow(String lllllllllllllllIlllIlllIIIIIllII, float lllllllllllllllIlllIlllIIIIIlIll, float lllllllllllllllIlllIlllIIIIIlIlI, int lllllllllllllllIlllIlllIIIIIlIIl) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   10: astore #4
    //   12: aload #4
    //   14: aload_0
    //   15: fload_1
    //   16: fload_2
    //   17: iload_3
    //   18: <illegal opcode> 2 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	30	0	lllllllllllllllIlllIlllIIIIIllII	Ljava/lang/String;
    //   0	30	1	lllllllllllllllIlllIlllIIIIIlIll	F
    //   0	30	2	lllllllllllllllIlllIlllIIIIIlIlI	F
    //   0	30	3	lllllllllllllllIlllIlllIIIIIlIIl	I
    //   12	18	4	lllllllllllllllIlllIlllIIIIIlIII	Lnet/minecraft/client/gui/FontRenderer;
  }
  
  public static void drawMultiColorString(String lllllllllllllllIlllIlllIIIIIIlll, String lllllllllllllllIlllIlllIIIIIIllI, int lllllllllllllllIlllIlllIIIIIIlIl, int lllllllllllllllIlllIlllIIIIIIlII, int lllllllllllllllIlllIlllIIIIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: i2f
    //   3: iload_3
    //   4: i2f
    //   5: new me/stupitdog/bhp/f01
    //   8: dup
    //   9: iload #4
    //   11: invokespecial <init> : (I)V
    //   14: <illegal opcode> 3 : (Ljava/lang/String;FFLme/stupitdog/bhp/f01;)F
    //   19: ldc ''
    //   21: invokevirtual length : ()I
    //   24: pop2
    //   25: aload_1
    //   26: iload_2
    //   27: aload_0
    //   28: <illegal opcode> 4 : (Ljava/lang/String;)I
    //   33: iadd
    //   34: <illegal opcode> 5 : ()Z
    //   39: invokestatic lllllIIIlIlIlIl : (I)Z
    //   42: ifeq -> 79
    //   45: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   48: iconst_0
    //   49: iaload
    //   50: ldc ''
    //   52: invokevirtual length : ()I
    //   55: pop
    //   56: bipush #19
    //   58: bipush #34
    //   60: ixor
    //   61: ldc ' '
    //   63: invokevirtual length : ()I
    //   66: ishl
    //   67: sipush #219
    //   70: sipush #188
    //   73: ixor
    //   74: ixor
    //   75: ifne -> 84
    //   78: return
    //   79: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   82: iconst_1
    //   83: iaload
    //   84: iadd
    //   85: i2f
    //   86: iload_3
    //   87: i2f
    //   88: new me/stupitdog/bhp/f01
    //   91: dup
    //   92: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   95: iconst_2
    //   96: iaload
    //   97: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   100: iconst_2
    //   101: iaload
    //   102: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   105: iconst_2
    //   106: iaload
    //   107: invokespecial <init> : (III)V
    //   110: <illegal opcode> 3 : (Ljava/lang/String;FFLme/stupitdog/bhp/f01;)F
    //   115: ldc ''
    //   117: invokevirtual length : ()I
    //   120: pop2
    //   121: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	122	0	lllllllllllllllIlllIlllIIIIIIlll	Ljava/lang/String;
    //   0	122	1	lllllllllllllllIlllIlllIIIIIIllI	Ljava/lang/String;
    //   0	122	2	lllllllllllllllIlllIlllIIIIIIlIl	I
    //   0	122	3	lllllllllllllllIlllIlllIIIIIIlII	I
    //   0	122	4	lllllllllllllllIlllIlllIIIIIIIll	I
  }
  
  public static void drawOutlineBox(int lllllllllllllllIlllIlllIIIIIIIlI, int lllllllllllllllIlllIlllIIIIIIIIl, int lllllllllllllllIlllIlllIIIIIIIII, int lllllllllllllllIlllIllIlllllllll, int lllllllllllllllIlllIllIllllllllI) {
    // Byte code:
    //   0: iload_0
    //   1: iload_1
    //   2: iload_2
    //   3: iload_3
    //   4: iload #4
    //   6: <illegal opcode> 6 : (IIIII)V
    //   11: iload_0
    //   12: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   15: iconst_0
    //   16: iaload
    //   17: isub
    //   18: iload_1
    //   19: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   22: iconst_0
    //   23: iaload
    //   24: isub
    //   25: iload_0
    //   26: iload_3
    //   27: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   30: iconst_0
    //   31: iaload
    //   32: iadd
    //   33: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   36: iconst_3
    //   37: iaload
    //   38: <illegal opcode> 6 : (IIIII)V
    //   43: iload_2
    //   44: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   47: iconst_0
    //   48: iaload
    //   49: iadd
    //   50: iload_1
    //   51: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: isub
    //   57: iload_2
    //   58: iload_3
    //   59: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   62: iconst_0
    //   63: iaload
    //   64: iadd
    //   65: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   68: iconst_3
    //   69: iaload
    //   70: <illegal opcode> 6 : (IIIII)V
    //   75: iload_0
    //   76: iload_1
    //   77: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   80: iconst_0
    //   81: iaload
    //   82: isub
    //   83: iload_2
    //   84: iload_1
    //   85: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   88: iconst_3
    //   89: iaload
    //   90: <illegal opcode> 6 : (IIIII)V
    //   95: iload_0
    //   96: iload_3
    //   97: iload_2
    //   98: iload_3
    //   99: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   102: iconst_0
    //   103: iaload
    //   104: iadd
    //   105: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   108: iconst_3
    //   109: iaload
    //   110: <illegal opcode> 6 : (IIIII)V
    //   115: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	116	0	lllllllllllllllIlllIlllIIIIIIIlI	I
    //   0	116	1	lllllllllllllllIlllIlllIIIIIIIIl	I
    //   0	116	2	lllllllllllllllIlllIlllIIIIIIIII	I
    //   0	116	3	lllllllllllllllIlllIllIlllllllll	I
    //   0	116	4	lllllllllllllllIlllIllIllllllllI	I
  }
  
  public static int rainbow() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   3: iconst_0
    //   4: iaload
    //   5: newarray float
    //   7: dup
    //   8: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   11: iconst_4
    //   12: iaload
    //   13: <illegal opcode> 7 : ()J
    //   18: ldc2_w 11520
    //   21: lrem
    //   22: l2f
    //   23: ldc 11520.0
    //   25: fdiv
    //   26: fastore
    //   27: astore_0
    //   28: aload_0
    //   29: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   32: iconst_4
    //   33: iaload
    //   34: faload
    //   35: fconst_1
    //   36: fconst_1
    //   37: <illegal opcode> 8 : (FFF)I
    //   42: istore_1
    //   43: iload_1
    //   44: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   47: iconst_5
    //   48: iaload
    //   49: ishr
    //   50: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   53: iconst_2
    //   54: iaload
    //   55: iand
    //   56: istore_2
    //   57: iload_1
    //   58: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   61: bipush #6
    //   63: iaload
    //   64: ishr
    //   65: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   68: iconst_2
    //   69: iaload
    //   70: iand
    //   71: istore_3
    //   72: iload_1
    //   73: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   76: iconst_2
    //   77: iaload
    //   78: iand
    //   79: istore #4
    //   81: new java/awt/Color
    //   84: dup
    //   85: iload_2
    //   86: iload_3
    //   87: iload #4
    //   89: getstatic me/stupitdog/bhp/af.lIlllIIlIllIIl : [I
    //   92: iconst_2
    //   93: iaload
    //   94: invokespecial <init> : (IIII)V
    //   97: astore #5
    //   99: aload #5
    //   101: <illegal opcode> 9 : (Ljava/awt/Color;)I
    //   106: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   28	79	0	lllllllllllllllIlllIllIlllllllIl	[F
    //   43	64	1	lllllllllllllllIlllIllIlllllllII	I
    //   57	50	2	lllllllllllllllIlllIllIllllllIll	I
    //   72	35	3	lllllllllllllllIlllIllIllllllIlI	I
    //   81	26	4	lllllllllllllllIlllIllIllllllIIl	I
    //   99	8	5	lllllllllllllllIlllIllIllllllIII	Ljava/awt/Color;
  }
  
  static {
    lllllIIIlIlIlII();
    lllllIIIlIlIIll();
    lllllIIIlIlIIlI();
    lllllIIIlIIlllI();
  }
  
  private static CallSite lllllIIIlIIlIlI(MethodHandles.Lookup lllllllllllllllIlllIllIllllIllll, String lllllllllllllllIlllIllIllllIlllI, MethodType lllllllllllllllIlllIllIllllIllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllIlllllIlIl = lIlllIIlIIllll[Integer.parseInt(lllllllllllllllIlllIllIllllIlllI)].split(lIlllIIlIlIlll[lIlllIIlIllIIl[4]]);
      Class<?> lllllllllllllllIlllIllIlllllIlII = Class.forName(lllllllllllllllIlllIllIlllllIlIl[lIlllIIlIllIIl[4]]);
      String lllllllllllllllIlllIllIlllllIIll = lllllllllllllllIlllIllIlllllIlIl[lIlllIIlIllIIl[0]];
      MethodHandle lllllllllllllllIlllIllIlllllIIlI = null;
      int lllllllllllllllIlllIllIlllllIIIl = lllllllllllllllIlllIllIlllllIlIl[lIlllIIlIllIIl[1]].length();
      if (lllllIIIlIlIllI(lllllllllllllllIlllIllIlllllIIIl, lIlllIIlIllIIl[7])) {
        MethodType lllllllllllllllIlllIllIlllllIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllIlllllIlIl[lIlllIIlIllIIl[7]], af.class.getClassLoader());
        if (lllllIIIlIlIlll(lllllllllllllllIlllIllIlllllIIIl, lIlllIIlIllIIl[7])) {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findVirtual(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIlll);
          "".length();
          if ((0x13 ^ 0x16) <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findStatic(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIlll);
        } 
        "".length();
        if (" ".length() >= " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllIlllllIllI = lIlllIIlIlIIII[Integer.parseInt(lllllllllllllllIlllIllIlllllIlIl[lIlllIIlIllIIl[7]])];
        if (lllllIIIlIlIlll(lllllllllllllllIlllIllIlllllIIIl, lIlllIIlIllIIl[1])) {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findGetter(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIllI);
          "".length();
          if (" ".length() > " ".length())
            return null; 
        } else if (lllllIIIlIlIlll(lllllllllllllllIlllIllIlllllIIIl, lIlllIIlIllIIl[8])) {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findStaticGetter(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIllI);
          "".length();
          if (" ".length() < -" ".length())
            return null; 
        } else if (lllllIIIlIlIlll(lllllllllllllllIlllIllIlllllIIIl, lIlllIIlIllIIl[9])) {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findSetter(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIllI);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIllIlllllIIlI = lllllllllllllllIlllIllIllllIllll.findStaticSetter(lllllllllllllllIlllIllIlllllIlII, lllllllllllllllIlllIllIlllllIIll, lllllllllllllllIlllIllIlllllIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllIlllllIIlI);
    } catch (Exception lllllllllllllllIlllIllIlllllIIII) {
      lllllllllllllllIlllIllIlllllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIlIIlllI() {
    lIlllIIlIIllll = new String[lIlllIIlIllIIl[10]];
    lIlllIIlIIllll[lIlllIIlIllIIl[4]] = lIlllIIlIlIlll[lIlllIIlIllIIl[0]];
    lIlllIIlIIllll[lIlllIIlIllIIl[11]] = lIlllIIlIlIlll[lIlllIIlIllIIl[7]];
    lIlllIIlIIllll[lIlllIIlIllIIl[7]] = lIlllIIlIlIlll[lIlllIIlIllIIl[1]];
    lIlllIIlIIllll[lIlllIIlIllIIl[6]] = lIlllIIlIlIlll[lIlllIIlIllIIl[8]];
    lIlllIIlIIllll[lIlllIIlIllIIl[8]] = lIlllIIlIlIlll[lIlllIIlIllIIl[9]];
    lIlllIIlIIllll[lIlllIIlIllIIl[12]] = lIlllIIlIlIlll[lIlllIIlIllIIl[13]];
    lIlllIIlIIllll[lIlllIIlIllIIl[1]] = lIlllIIlIlIlll[lIlllIIlIllIIl[11]];
    lIlllIIlIIllll[lIlllIIlIllIIl[13]] = lIlllIIlIlIlll[lIlllIIlIllIIl[6]];
    lIlllIIlIIllll[lIlllIIlIllIIl[0]] = lIlllIIlIlIlll[lIlllIIlIllIIl[12]];
    lIlllIIlIIllll[lIlllIIlIllIIl[9]] = lIlllIIlIlIlll[lIlllIIlIllIIl[10]];
    lIlllIIlIlIIII = new Class[lIlllIIlIllIIl[0]];
    lIlllIIlIlIIII[lIlllIIlIllIIl[4]] = FontRenderer.class;
  }
  
  private static void lllllIIIlIlIIlI() {
    lIlllIIlIlIlll = new String[lIlllIIlIllIIl[14]];
    lIlllIIlIlIlll[lIlllIIlIllIIl[4]] = lllllIIIlIIllll(lIlllIIlIllIII[lIlllIIlIllIIl[4]], lIlllIIlIllIII[lIlllIIlIllIIl[0]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[0]] = lllllIIIlIlIIII(lIlllIIlIllIII[lIlllIIlIllIIl[7]], lIlllIIlIllIII[lIlllIIlIllIIl[1]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[7]] = lllllIIIlIlIIII(lIlllIIlIllIII[lIlllIIlIllIIl[8]], lIlllIIlIllIII[lIlllIIlIllIIl[9]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[1]] = lllllIIIlIlIIII(lIlllIIlIllIII[lIlllIIlIllIIl[13]], lIlllIIlIllIII[lIlllIIlIllIIl[11]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[8]] = lllllIIIlIlIIIl(lIlllIIlIllIII[lIlllIIlIllIIl[6]], lIlllIIlIllIII[lIlllIIlIllIIl[12]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[9]] = lllllIIIlIIllll(lIlllIIlIllIII[lIlllIIlIllIIl[10]], lIlllIIlIllIII[lIlllIIlIllIIl[14]]);
    lIlllIIlIlIlll[lIlllIIlIllIIl[13]] = lllllIIIlIlIIIl("s9yDeL3frEmWfoM/+D/4zS3NmMh2jLmoJ4f3iDI0rwk=", "NCNmT");
    lIlllIIlIlIlll[lIlllIIlIllIIl[11]] = lllllIIIlIlIIIl("k5vKsdxTLHHKwT4tk33E4kJ15yFBqklsMFcOyeMCO+3qU5T3u42Mer1GdhlpMaC64KQWk4qT9NCU4cUvaGphZ9Ypo0MKYAgGnNj1eSSJO2ST1lOKByqfO8AtMTYb3DQB", "boBNG");
    lIlllIIlIlIlll[lIlllIIlIllIIl[6]] = lllllIIIlIIllll("HAEeYQMbCg8sHBMCHmENHg0PIRpcAx8mQDURA3UIBwoJEFlBU1l7MRNeQgYnOy0jZjhIRA==", "rdjOn");
    lIlllIIlIlIlll[lIlllIIlIllIIl[12]] = lllllIIIlIIllll("CgMbaz8NCAomIAUAG2sxCA8KKyZKKwYrNwcUDiMmXgAGID4AOVh0ZlJQMDVoVFxPZXI=", "dfoER");
    lIlllIIlIlIlll[lIlllIIlIllIIl[10]] = lllllIIIlIlIIII("FWg6RSO1xXr5JjBRFMgMMm44kR9qdiq2idByHaw+Md2oY3dKuSI7HQ==", "KJgdq");
    lIlllIIlIllIII = null;
  }
  
  private static void lllllIIIlIlIIll() {
    String str = (new Exception()).getStackTrace()[lIlllIIlIllIIl[4]].getFileName();
    lIlllIIlIllIII = str.substring(str.indexOf("ä") + lIlllIIlIllIIl[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIIlIlIIII(String lllllllllllllllIlllIllIllllIlIIl, String lllllllllllllllIlllIllIllllIlIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIllllIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIllllIlIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIllllIlIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIllllIlIll.init(lIlllIIlIllIIl[7], lllllllllllllllIlllIllIllllIllII);
      return new String(lllllllllllllllIlllIllIllllIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIllllIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIllllIlIlI) {
      lllllllllllllllIlllIllIllllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIIlIIllll(String lllllllllllllllIlllIllIllllIIllI, String lllllllllllllllIlllIllIllllIIlIl) {
    lllllllllllllllIlllIllIllllIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIllllIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIllllIIlII = new StringBuilder();
    char[] lllllllllllllllIlllIllIllllIIIll = lllllllllllllllIlllIllIllllIIlIl.toCharArray();
    int lllllllllllllllIlllIllIllllIIIlI = lIlllIIlIllIIl[4];
    char[] arrayOfChar1 = lllllllllllllllIlllIllIllllIIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlIllIIl[4];
    while (lllllIIIlIllIII(j, i)) {
      char lllllllllllllllIlllIllIllllIIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllIllllIIIlI++;
      j++;
      "".length();
      if (((0xCB ^ 0xAA) & (0x3 ^ 0x62 ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllIllllIIlII);
  }
  
  private static String lllllIIIlIlIIIl(String lllllllllllllllIlllIllIlllIllllI, String lllllllllllllllIlllIllIlllIlllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIllllIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIlllIlllIl.getBytes(StandardCharsets.UTF_8)), lIlllIIlIllIIl[6]), "DES");
      Cipher lllllllllllllllIlllIllIllllIIIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIllllIIIII.init(lIlllIIlIllIIl[7], lllllllllllllllIlllIllIllllIIIIl);
      return new String(lllllllllllllllIlllIllIllllIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIlllIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIlllIlllll) {
      lllllllllllllllIlllIllIlllIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIlIlIlII() {
    lIlllIIlIllIIl = new int[15];
    lIlllIIlIllIIl[0] = " ".length();
    lIlllIIlIllIIl[1] = "   ".length();
    lIlllIIlIllIIl[2] = 125 + 5 - -64 + 61;
    lIlllIIlIllIIl[3] = (2260115 + 2155186 - 2324742 + 631836 << " ".length()) + 248766864 + 148461356 - 316201840 + 511902181 - (43112243 + 27169771 - 47829686 + 52920775 << " ".length() << " ".length()) + (142998468 + 291861477 - 213294438 + 166897832 << " ".length());
    lIlllIIlIllIIl[4] = (0xA ^ 0x53) & (0x31 ^ 0x68 ^ 0xFFFFFFFF);
    lIlllIIlIllIIl[5] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIllIIl[6] = " ".length() << "   ".length();
    lIlllIIlIllIIl[7] = " ".length() << " ".length();
    lIlllIIlIllIIl[8] = " ".length() << " ".length() << " ".length();
    lIlllIIlIllIIl[9] = 0x3F ^ 0x3A;
    lIlllIIlIllIIl[10] = (51 + 108 - 114 + 90 ^ (0x59 ^ 0x18) << " ".length()) << " ".length();
    lIlllIIlIllIIl[11] = 0x27 ^ 0x20;
    lIlllIIlIllIIl[12] = 0x37 ^ 0x3E;
    lIlllIIlIllIIl[13] = "   ".length() << " ".length();
    lIlllIIlIllIIl[14] = 0xB1 ^ 0xBA;
  }
  
  private static boolean lllllIIIlIlIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIIlIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIIlIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIIlIlIlIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\af.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */