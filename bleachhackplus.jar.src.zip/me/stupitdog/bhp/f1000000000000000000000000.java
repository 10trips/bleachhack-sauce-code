package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class f1000000000000000000000000 extends au {
  f100000000000000000000.ColorSetting color;
  
  private static String[] lIllIIlllIlIII;
  
  private static Class[] lIllIIlllIlIIl;
  
  private static final String[] lIllIIllllIIlI;
  
  private static String[] lIllIIllllIIll;
  
  private static final int[] lIllIIlllllIll;
  
  public f1000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIllllIIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIllllIIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIllllIIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllllIIIIlIlIIIl	Lme/stupitdog/bhp/f1000000000000000000000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIllllIIlI : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: new me/stupitdog/bhp/f01
    //   14: dup
    //   15: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   18: iconst_4
    //   19: iaload
    //   20: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   23: iconst_4
    //   24: iaload
    //   25: getstatic me/stupitdog/bhp/f1000000000000000000000000.lIllIIlllllIll : [I
    //   28: iconst_4
    //   29: iaload
    //   30: invokespecial <init> : (III)V
    //   33: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1000000000000000000000000;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   38: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   43: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	44	0	lllllllllllllllIlllllIIIIlIlIIII	Lme/stupitdog/bhp/f1000000000000000000000000;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   5: aload_0
    //   6: <illegal opcode> 4 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllllIIIIlIIllll	Lme/stupitdog/bhp/f1000000000000000000000000;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   5: aload_0
    //   6: <illegal opcode> 5 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllllIIIIlIIlllI	Lme/stupitdog/bhp/f1000000000000000000000000;
  }
  
  @SubscribeEvent
  public void fogColour(EntityViewRenderEvent.FogColors lllllllllllllllIlllllIIIIlIIllII) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   7: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Lme/stupitdog/bhp/f01;
    //   12: <illegal opcode> 8 : (Lme/stupitdog/bhp/f01;)I
    //   17: i2f
    //   18: ldc 250.0
    //   20: fdiv
    //   21: <illegal opcode> 9 : (Lnet/minecraftforge/client/event/EntityViewRenderEvent$FogColors;F)V
    //   26: aload_1
    //   27: aload_0
    //   28: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   33: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Lme/stupitdog/bhp/f01;
    //   38: <illegal opcode> 10 : (Lme/stupitdog/bhp/f01;)I
    //   43: i2f
    //   44: ldc 250.0
    //   46: fdiv
    //   47: <illegal opcode> 11 : (Lnet/minecraftforge/client/event/EntityViewRenderEvent$FogColors;F)V
    //   52: aload_1
    //   53: aload_0
    //   54: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   59: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Lme/stupitdog/bhp/f01;
    //   64: <illegal opcode> 12 : (Lme/stupitdog/bhp/f01;)I
    //   69: i2f
    //   70: ldc 250.0
    //   72: fdiv
    //   73: <illegal opcode> 13 : (Lnet/minecraftforge/client/event/EntityViewRenderEvent$FogColors;F)V
    //   78: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	0	lllllllllllllllIlllllIIIIlIIllIl	Lme/stupitdog/bhp/f1000000000000000000000000;
    //   0	79	1	lllllllllllllllIlllllIIIIlIIllII	Lnet/minecraftforge/client/event/EntityViewRenderEvent$FogColors;
  }
  
  static {
    llllIIlIIIIIIll();
    llllIIIlllllIll();
    llllIIIlllllIlI();
    llllIIIllllIllI();
  }
  
  private static CallSite llllIIIllIllllI(MethodHandles.Lookup lllllllllllllllIlllllIIIIlIIIIll, String lllllllllllllllIlllllIIIIlIIIIlI, MethodType lllllllllllllllIlllllIIIIlIIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIIIIlIIlIIl = lIllIIlllIlIII[Integer.parseInt(lllllllllllllllIlllllIIIIlIIIIlI)].split(lIllIIllllIIlI[lIllIIlllllIll[5]]);
      Class<?> lllllllllllllllIlllllIIIIlIIlIII = Class.forName(lllllllllllllllIlllllIIIIlIIlIIl[lIllIIlllllIll[0]]);
      String lllllllllllllllIlllllIIIIlIIIlll = lllllllllllllllIlllllIIIIlIIlIIl[lIllIIlllllIll[1]];
      MethodHandle lllllllllllllllIlllllIIIIlIIIllI = null;
      int lllllllllllllllIlllllIIIIlIIIlIl = lllllllllllllllIlllllIIIIlIIlIIl[lIllIIlllllIll[3]].length();
      if (llllIIlIIIIIlII(lllllllllllllllIlllllIIIIlIIIlIl, lIllIIlllllIll[2])) {
        MethodType lllllllllllllllIlllllIIIIlIIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIIIIlIIlIIl[lIllIIlllllIll[2]], f1000000000000000000000000.class.getClassLoader());
        if (llllIIlIIIIIlIl(lllllllllllllllIlllllIIIIlIIIlIl, lIllIIlllllIll[2])) {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findVirtual(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findStatic(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIll);
        } 
        "".length();
        if (-(0xA7 ^ 0xA3) > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIIIIlIIlIlI = lIllIIlllIlIIl[Integer.parseInt(lllllllllllllllIlllllIIIIlIIlIIl[lIllIIlllllIll[2]])];
        if (llllIIlIIIIIlIl(lllllllllllllllIlllllIIIIlIIIlIl, lIllIIlllllIll[3])) {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findGetter(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIlI);
          "".length();
          if ((" ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ -" ".length())) > 0)
            return null; 
        } else if (llllIIlIIIIIlIl(lllllllllllllllIlllllIIIIlIIIlIl, lIllIIlllllIll[5])) {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findStaticGetter(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIlI);
          "".length();
          if (-(0x86 ^ 0xA5 ^ 0x93 ^ 0xB4) >= 0)
            return null; 
        } else if (llllIIlIIIIIlIl(lllllllllllllllIlllllIIIIlIIIlIl, lIllIIlllllIll[6])) {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findSetter(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIlI);
          "".length();
          if ("   ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIlllllIIIIlIIIllI = lllllllllllllllIlllllIIIIlIIIIll.findStaticSetter(lllllllllllllllIlllllIIIIlIIlIII, lllllllllllllllIlllllIIIIlIIIlll, lllllllllllllllIlllllIIIIlIIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIIIIlIIIllI);
    } catch (Exception lllllllllllllllIlllllIIIIlIIIlII) {
      lllllllllllllllIlllllIIIIlIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIllllIllI() {
    lIllIIlllIlIII = new String[lIllIIlllllIll[7]];
    lIllIIlllIlIII[lIllIIlllllIll[8]] = lIllIIllllIIlI[lIllIIlllllIll[6]];
    lIllIIlllIlIII[lIllIIlllllIll[9]] = lIllIIllllIIlI[lIllIIlllllIll[9]];
    lIllIIlllIlIII[lIllIIlllllIll[10]] = lIllIIllllIIlI[lIllIIlllllIll[11]];
    lIllIIlllIlIII[lIllIIlllllIll[1]] = lIllIIllllIIlI[lIllIIlllllIll[8]];
    lIllIIlllIlIII[lIllIIlllllIll[12]] = lIllIIllllIIlI[lIllIIlllllIll[13]];
    lIllIIlllIlIII[lIllIIlllllIll[13]] = lIllIIllllIIlI[lIllIIlllllIll[10]];
    lIllIIlllIlIII[lIllIIlllllIll[0]] = lIllIIllllIIlI[lIllIIlllllIll[14]];
    lIllIIlllIlIII[lIllIIlllllIll[2]] = lIllIIllllIIlI[lIllIIlllllIll[15]];
    lIllIIlllIlIII[lIllIIlllllIll[3]] = lIllIIllllIIlI[lIllIIlllllIll[12]];
    lIllIIlllIlIII[lIllIIlllllIll[15]] = lIllIIllllIIlI[lIllIIlllllIll[7]];
    lIllIIlllIlIII[lIllIIlllllIll[11]] = lIllIIllllIIlI[lIllIIlllllIll[16]];
    lIllIIlllIlIII[lIllIIlllllIll[6]] = lIllIIllllIIlI[lIllIIlllllIll[17]];
    lIllIIlllIlIII[lIllIIlllllIll[5]] = lIllIIllllIIlI[lIllIIlllllIll[18]];
    lIllIIlllIlIII[lIllIIlllllIll[14]] = lIllIIllllIIlI[lIllIIlllllIll[19]];
    lIllIIlllIlIIl = new Class[lIllIIlllllIll[3]];
    lIllIIlllIlIIl[lIllIIlllllIll[0]] = f13.class;
    lIllIIlllIlIIl[lIllIIlllllIll[1]] = f100000000000000000000.ColorSetting.class;
    lIllIIlllIlIIl[lIllIIlllllIll[2]] = EventBus.class;
  }
  
  private static void llllIIIlllllIlI() {
    lIllIIllllIIlI = new String[lIllIIlllllIll[20]];
    lIllIIllllIIlI[lIllIIlllllIll[0]] = llllIIIllllIlll(lIllIIllllIIll[lIllIIlllllIll[0]], lIllIIllllIIll[lIllIIlllllIll[1]]);
    lIllIIllllIIlI[lIllIIlllllIll[1]] = llllIIIlllllIII(lIllIIllllIIll[lIllIIlllllIll[2]], lIllIIllllIIll[lIllIIlllllIll[3]]);
    lIllIIllllIIlI[lIllIIlllllIll[2]] = llllIIIlllllIII(lIllIIllllIIll[lIllIIlllllIll[5]], lIllIIllllIIll[lIllIIlllllIll[6]]);
    lIllIIllllIIlI[lIllIIlllllIll[3]] = llllIIIlllllIIl(lIllIIllllIIll[lIllIIlllllIll[9]], lIllIIllllIIll[lIllIIlllllIll[11]]);
    lIllIIllllIIlI[lIllIIlllllIll[5]] = llllIIIlllllIIl(lIllIIllllIIll[lIllIIlllllIll[8]], lIllIIllllIIll[lIllIIlllllIll[13]]);
    lIllIIllllIIlI[lIllIIlllllIll[6]] = llllIIIlllllIII(lIllIIllllIIll[lIllIIlllllIll[10]], lIllIIllllIIll[lIllIIlllllIll[14]]);
    lIllIIllllIIlI[lIllIIlllllIll[9]] = llllIIIlllllIII(lIllIIllllIIll[lIllIIlllllIll[15]], lIllIIllllIIll[lIllIIlllllIll[12]]);
    lIllIIllllIIlI[lIllIIlllllIll[11]] = llllIIIlllllIIl(lIllIIllllIIll[lIllIIlllllIll[7]], lIllIIllllIIll[lIllIIlllllIll[16]]);
    lIllIIllllIIlI[lIllIIlllllIll[8]] = llllIIIlllllIIl("HWqvIiuy558/O+YR0XRbJxhVk4t0leAewDCc0NViDvPAMJzQ1WIO80e4sP5ZqKdXRkqTW+z1+VZtY5YeZNtEEE2EO+vtlyhBs3ma43IgO5HXA5yr8O5Q2XFv85BxH7tht9uaZBEa8HDt/g/eVRJjIUHB9wKc0dNmwDCc0NViDvPAMJzQ1WIO8yapjThskOhPKUNOhgmB0K76fT1+SNbLYQ==", "KPFEo");
    lIllIIllllIIlI[lIllIIlllllIll[13]] = llllIIIllllIlll("CDJUUHzRQlsNyMkWSdnvEOUf/TBYglK/K4nVrcVuQbQ2CbjqIbV2pwo91Zh6eBNU4hhDaNiZue/mm1CSWTnoSAoECff3DkTN58Vw0/pPRLA=", "fCzhC");
    lIllIIllllIIlI[lIllIIlllllIll[10]] = llllIIIlllllIIl("5sboeZ41U60jsbTiK0uykpBK2CDcphWFxu/2BDNgQRJ5BBtgyorTQEQoyYa3DjCAhZFyl13XTquMcLtEUpDNGYSkBYuxsQjeMZdbeZdUzP8=", "JTfbw");
    lIllIIllllIIlI[lIllIIlllllIll[14]] = llllIIIlllllIII("LyhFKjI3PQItIi0qRTsuMmMNaHV4Hy4XAgcfUWl8Ym1LeQ==", "BMkYF");
    lIllIIllllIIlI[lIllIIlllllIll[15]] = llllIIIlllllIIl("uTDYNrXwN57yAqGZ7+pZ0YhsfwUHG1Am6PY79nWmE13o9jv2daYTXVeC4dB8engUjkerg7QV9N7xf8SCakaIwQ==", "DDfnV");
    lIllIIllllIIlI[lIllIIlllllIll[12]] = llllIIIlllllIIl("PDJxpoA0jGB5FRtpQ0wr79kXM3esOf1JVVaFPSyXwh9aUcRmFzW9i7G1OHnNljQ7ZtYVcouX5nllurv8k6H5hw==", "ucuTe");
    lIllIIllllIIlI[lIllIIlllllIll[7]] = llllIIIlllllIII("FCJoOwUMNy88FRYgaCoZCWkgeEBDICM8MxUyI3JZUA58aFE=", "yGFHq");
    lIllIIllllIIlI[lIllIIlllllIll[16]] = llllIIIllllIlll("7XsetWRdgJHfNbhp12f41bZFoL8B8sAt3lRbxpI97UwpRTwPL51ZuKJkKaxJs6/5c9dDS5nOOjxvn8a8h6ROLvUhFzTGp+O8rqNx8+8XUNilEW4uiYBZH50VcqXEMvem", "Fsdns");
    lIllIIllllIIlI[lIllIIlllllIll[17]] = llllIIIlllllIII("PC4xRAQ7JSAJGzMtMQwGICwgRA8/J2sJBj8mKgRHNz0gBB06KisOBTc5ay8fNyUxKBwhcTAEGzcsLBkdNzl/QiU4KjMLRj4qKw1GHSkvDwomcGw8U3Jr", "RKEji");
    lIllIIllllIIlI[lIllIIlllllIll[18]] = llllIIIlllllIIl("+EEbhnAe3QX0zbpI6ZAQ432DM2UbZeU83uV5flP9D0V8QYyFmvynaAWcsh19aBqAdb4XVR1VdALJGl23rnQrIrQ8lmZyiHPdNK3KEuMPZEZRx9Kn+3q1WQ==", "hdxiZ");
    lIllIIllllIIlI[lIllIIlllllIll[19]] = llllIIIllllIlll("mUY7bst6qt1P7A65ManaqWU6P7k8SeJ56PBx6go41HUEkjIWILYp/wBQmDiBzTaK8pU6t8juagLVkAi+jdFLSQGHC1T8Cty1fLf2SYi6T24teQSKazgJ0Q==", "QhlUX");
    lIllIIllllIIll = null;
  }
  
  private static void llllIIIlllllIll() {
    String str = (new Exception()).getStackTrace()[lIllIIlllllIll[0]].getFileName();
    lIllIIllllIIll = str.substring(str.indexOf("ä") + lIllIIlllllIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIllllIlll(String lllllllllllllllIlllllIIIIIllllIl, String lllllllllllllllIlllllIIIIIllllII) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIIlIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIIIllllII.getBytes(StandardCharsets.UTF_8)), lIllIIlllllIll[8]), "DES");
      Cipher lllllllllllllllIlllllIIIIIllllll = Cipher.getInstance("DES");
      lllllllllllllllIlllllIIIIIllllll.init(lIllIIlllllIll[2], lllllllllllllllIlllllIIIIlIIIIII);
      return new String(lllllllllllllllIlllllIIIIIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIIIlllllI) {
      lllllllllllllllIlllllIIIIIlllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIlllllIII(String lllllllllllllllIlllllIIIIIlllIlI, String lllllllllllllllIlllllIIIIIlllIIl) {
    lllllllllllllllIlllllIIIIIlllIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIIlllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIIIIIlllIII = new StringBuilder();
    char[] lllllllllllllllIlllllIIIIIllIlll = lllllllllllllllIlllllIIIIIlllIIl.toCharArray();
    int lllllllllllllllIlllllIIIIIllIllI = lIllIIlllllIll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllllIIIIIlllIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIIlllllIll[0];
    while (llllIIlIIIIIllI(j, i)) {
      char lllllllllllllllIlllllIIIIIlllIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllllIIIIIllIllI++;
      j++;
      "".length();
      if ("   ".length() != "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllllIIIIIlllIII);
  }
  
  private static String llllIIIlllllIIl(String lllllllllllllllIlllllIIIIIllIIlI, String lllllllllllllllIlllllIIIIIllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIIIllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIIIllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIIIIIllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIIIIIllIlII.init(lIllIIlllllIll[2], lllllllllllllllIlllllIIIIIllIlIl);
      return new String(lllllllllllllllIlllllIIIIIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIIllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIIIllIIll) {
      lllllllllllllllIlllllIIIIIllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlIIIIIIll() {
    lIllIIlllllIll = new int[21];
    lIllIIlllllIll[0] = "   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ -" ".length());
    lIllIIlllllIll[1] = " ".length();
    lIllIIlllllIll[2] = " ".length() << " ".length();
    lIllIIlllllIll[3] = "   ".length();
    lIllIIlllllIll[4] = ((0x76 ^ 0x4F) << " ".length() << " ".length()) + 25 + 136 - 22 + 22 - 350 + 173 - 468 + 318 + 137 + 130 - 115 + 87;
    lIllIIlllllIll[5] = " ".length() << " ".length() << " ".length();
    lIllIIlllllIll[6] = 0x6D ^ 0x68;
    lIllIIlllllIll[7] = (0x96 ^ 0xBD ^ (0xA9 ^ 0xA2) << " ".length() << " ".length()) << " ".length();
    lIllIIlllllIll[8] = " ".length() << "   ".length();
    lIllIIlllllIll[9] = "   ".length() << " ".length();
    lIllIIlllllIll[10] = (0xA6 ^ 0xA3) << " ".length();
    lIllIIlllllIll[11] = 0xC3 ^ 0xC4;
    lIllIIlllllIll[12] = 0x89 ^ 0x84;
    lIllIIlllllIll[13] = 0x99 ^ 0x90;
    lIllIIlllllIll[14] = 93 + 132 - 180 + 104 ^ (0xC1 ^ 0x8E) << " ".length();
    lIllIIlllllIll[15] = "   ".length() << " ".length() << " ".length();
    lIllIIlllllIll[16] = 0x93 ^ 0x9C;
    lIllIIlllllIll[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIIlllllIll[18] = 0xAB ^ 0xBA;
    lIllIIlllllIll[19] = (0x5 ^ 0xC) << " ".length();
    lIllIIlllllIll[20] = "   ".length() << " ".length() << " ".length() ^ 0x93 ^ 0x8C;
  }
  
  private static boolean llllIIlIIIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIlIIIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIlIIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */