package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.TextFormatting;

public class as extends au {
  private boolean hasClicked;
  
  private static String[] llIIIlIllllllI;
  
  private static Class[] llIIIlIlllllll;
  
  private static final String[] llIIIllIlIIlII;
  
  private static String[] llIIIllIlIIlll;
  
  private static final int[] llIIIllIlIlIlI;
  
  public as() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   45: iconst_0
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/as;Z)V
    //   52: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	53	0	lllllllllllllllIllIlIIlIlIIIllll	Lme/stupitdog/bhp/as;
  }
  
  public void update() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   3: iconst_2
    //   4: iaload
    //   5: <illegal opcode> 2 : (I)Z
    //   10: invokestatic lIIIIlIlIIIIlIll : (I)Z
    //   13: ifeq -> 28
    //   16: aload_0
    //   17: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   20: iconst_0
    //   21: iaload
    //   22: <illegal opcode> 1 : (Lme/stupitdog/bhp/as;Z)V
    //   27: return
    //   28: aload_0
    //   29: <illegal opcode> 3 : (Lme/stupitdog/bhp/as;)Z
    //   34: invokestatic lIIIIlIlIIIIlIll : (I)Z
    //   37: ifeq -> 617
    //   40: aload_0
    //   41: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   44: iconst_1
    //   45: iaload
    //   46: <illegal opcode> 1 : (Lme/stupitdog/bhp/as;Z)V
    //   51: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   61: astore_1
    //   62: aload_1
    //   63: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   68: astore_2
    //   69: aload_1
    //   70: invokestatic lIIIIlIlIIIIllII : (Ljava/lang/Object;)Z
    //   73: ifeq -> 108
    //   76: aload_1
    //   77: <illegal opcode> 7 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/RayTraceResult$Type;
    //   82: <illegal opcode> 8 : ()Lnet/minecraft/util/math/RayTraceResult$Type;
    //   87: invokestatic lIIIIlIlIIIIllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   90: ifeq -> 108
    //   93: aload_1
    //   94: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   99: instanceof net/minecraft/entity/player/EntityPlayer
    //   102: invokestatic lIIIIlIlIIIIlIll : (I)Z
    //   105: ifeq -> 109
    //   108: return
    //   109: <illegal opcode> 9 : ()Lme/stupitdog/bhp/f9;
    //   114: <illegal opcode> 10 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   119: new java/lang/StringBuilder
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: aload_2
    //   127: <illegal opcode> 11 : (Lnet/minecraft/entity/Entity;)Ljava/util/UUID;
    //   132: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   137: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   140: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   143: iconst_3
    //   144: iaload
    //   145: aaload
    //   146: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: <illegal opcode> 14 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   156: <illegal opcode> 15 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)Z
    //   161: invokestatic lIIIIlIlIIIIlllI : (I)Z
    //   164: ifeq -> 438
    //   167: <illegal opcode> 9 : ()Lme/stupitdog/bhp/f9;
    //   172: <illegal opcode> 10 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   177: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   182: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   187: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   192: <illegal opcode> 16 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   197: <illegal opcode> 17 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)V
    //   202: new java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   212: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   215: iconst_4
    //   216: iaload
    //   217: aaload
    //   218: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: <illegal opcode> 18 : ()Lnet/minecraft/util/text/TextFormatting;
    //   228: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   233: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   238: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   243: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   248: <illegal opcode> 16 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   253: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: <illegal opcode> 19 : ()Lnet/minecraft/util/text/TextFormatting;
    //   263: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   268: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   271: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   274: iconst_5
    //   275: iaload
    //   276: aaload
    //   277: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: <illegal opcode> 14 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   287: <illegal opcode> 20 : (Ljava/lang/String;)V
    //   292: ldc ''
    //   294: invokevirtual length : ()I
    //   297: pop
    //   298: sipush #226
    //   301: sipush #151
    //   304: ixor
    //   305: ldc ' '
    //   307: invokevirtual length : ()I
    //   310: ldc '   '
    //   312: invokevirtual length : ()I
    //   315: ldc ' '
    //   317: invokevirtual length : ()I
    //   320: ishl
    //   321: ishl
    //   322: ixor
    //   323: sipush #235
    //   326: sipush #142
    //   329: ixor
    //   330: bipush #20
    //   332: bipush #17
    //   334: ixor
    //   335: ldc ' '
    //   337: invokevirtual length : ()I
    //   340: ldc ' '
    //   342: invokevirtual length : ()I
    //   345: ldc ' '
    //   347: invokevirtual length : ()I
    //   350: ishl
    //   351: ishl
    //   352: ishl
    //   353: ixor
    //   354: ldc ' '
    //   356: invokevirtual length : ()I
    //   359: ineg
    //   360: ixor
    //   361: iand
    //   362: bipush #66
    //   364: bipush #15
    //   366: iadd
    //   367: bipush #-39
    //   369: isub
    //   370: bipush #25
    //   372: iadd
    //   373: bipush #104
    //   375: bipush #77
    //   377: ixor
    //   378: ldc ' '
    //   380: invokevirtual length : ()I
    //   383: ldc ' '
    //   385: invokevirtual length : ()I
    //   388: ishl
    //   389: ishl
    //   390: ixor
    //   391: ldc '   '
    //   393: invokevirtual length : ()I
    //   396: ishl
    //   397: bipush #58
    //   399: bipush #27
    //   401: ixor
    //   402: bipush #106
    //   404: bipush #99
    //   406: ixor
    //   407: ldc ' '
    //   409: invokevirtual length : ()I
    //   412: ldc ' '
    //   414: invokevirtual length : ()I
    //   417: ishl
    //   418: ishl
    //   419: ixor
    //   420: ldc '   '
    //   422: invokevirtual length : ()I
    //   425: ishl
    //   426: ldc ' '
    //   428: invokevirtual length : ()I
    //   431: ineg
    //   432: ixor
    //   433: iand
    //   434: if_icmple -> 617
    //   437: return
    //   438: <illegal opcode> 9 : ()Lme/stupitdog/bhp/f9;
    //   443: <illegal opcode> 10 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   448: new java/lang/StringBuilder
    //   451: dup
    //   452: invokespecial <init> : ()V
    //   455: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   460: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   465: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   470: <illegal opcode> 11 : (Lnet/minecraft/entity/Entity;)Ljava/util/UUID;
    //   475: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   480: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   483: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   486: bipush #6
    //   488: iaload
    //   489: aaload
    //   490: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   495: <illegal opcode> 14 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   500: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   505: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   510: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   515: <illegal opcode> 16 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   520: <illegal opcode> 21 : (Lme/stupitdog/bhp/a;Ljava/lang/String;Ljava/lang/String;)V
    //   525: new java/lang/StringBuilder
    //   528: dup
    //   529: invokespecial <init> : ()V
    //   532: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   535: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   538: bipush #7
    //   540: iaload
    //   541: aaload
    //   542: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   547: <illegal opcode> 22 : ()Lnet/minecraft/util/text/TextFormatting;
    //   552: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   557: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   562: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   567: <illegal opcode> 6 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/entity/Entity;
    //   572: <illegal opcode> 16 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   577: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   582: <illegal opcode> 19 : ()Lnet/minecraft/util/text/TextFormatting;
    //   587: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   592: getstatic me/stupitdog/bhp/as.llIIIllIlIIlII : [Ljava/lang/String;
    //   595: getstatic me/stupitdog/bhp/as.llIIIllIlIlIlI : [I
    //   598: bipush #8
    //   600: iaload
    //   601: aaload
    //   602: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   607: <illegal opcode> 14 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   612: <illegal opcode> 20 : (Ljava/lang/String;)V
    //   617: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   62	555	1	lllllllllllllllIllIlIIlIlIIIlllI	Lnet/minecraft/util/math/RayTraceResult;
    //   69	548	2	lllllllllllllllIllIlIIlIlIIIllIl	Lnet/minecraft/entity/Entity;
    //   0	618	0	lllllllllllllllIllIlIIlIlIIIllII	Lme/stupitdog/bhp/as;
  }
  
  static {
    lIIIIlIlIIIIlIlI();
    lIIIIlIlIIIIIIII();
    lIIIIlIIllllllll();
    lIIIIlIIlllllIIl();
  }
  
  private static CallSite lIIIIlIIlIlIIIlI(MethodHandles.Lookup lllllllllllllllIllIlIIlIlIIIIIll, String lllllllllllllllIllIlIIlIlIIIIIlI, MethodType lllllllllllllllIllIlIIlIlIIIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIlIlIIIlIIl = llIIIlIllllllI[Integer.parseInt(lllllllllllllllIllIlIIlIlIIIIIlI)].split(llIIIllIlIIlII[llIIIllIlIlIlI[9]]);
      Class<?> lllllllllllllllIllIlIIlIlIIIlIII = Class.forName(lllllllllllllllIllIlIIlIlIIIlIIl[llIIIllIlIlIlI[0]]);
      String lllllllllllllllIllIlIIlIlIIIIlll = lllllllllllllllIllIlIIlIlIIIlIIl[llIIIllIlIlIlI[1]];
      MethodHandle lllllllllllllllIllIlIIlIlIIIIllI = null;
      int lllllllllllllllIllIlIIlIlIIIIlIl = lllllllllllllllIllIlIIlIlIIIlIIl[llIIIllIlIlIlI[3]].length();
      if (lIIIIlIlIIIIllll(lllllllllllllllIllIlIIlIlIIIIlIl, llIIIllIlIlIlI[2])) {
        MethodType lllllllllllllllIllIlIIlIlIIIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIlIlIIIlIIl[llIIIllIlIlIlI[2]], as.class.getClassLoader());
        if (lIIIIlIlIIIlIIII(lllllllllllllllIllIlIIlIlIIIIlIl, llIIIllIlIlIlI[2])) {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findVirtual(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIll);
          "".length();
          if (-" ".length() >= " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findStatic(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIll);
        } 
        "".length();
        if (" ".length() > "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIlIlIIIlIlI = llIIIlIlllllll[Integer.parseInt(lllllllllllllllIllIlIIlIlIIIlIIl[llIIIllIlIlIlI[2]])];
        if (lIIIIlIlIIIlIIII(lllllllllllllllIllIlIIlIlIIIIlIl, llIIIllIlIlIlI[3])) {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findGetter(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIlI);
          "".length();
          if (" ".length() > "   ".length())
            return null; 
        } else if (lIIIIlIlIIIlIIII(lllllllllllllllIllIlIIlIlIIIIlIl, llIIIllIlIlIlI[4])) {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findStaticGetter(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < ((3 + 4 - -74 + 82 ^ (0xFB ^ 0xA2) << " ".length()) & (0x26 ^ 0x7F ^ (0x4B ^ 0x42) << "   ".length() ^ -" ".length())))
            return null; 
        } else if (lIIIIlIlIIIlIIII(lllllllllllllllIllIlIIlIlIIIIlIl, llIIIllIlIlIlI[5])) {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findSetter(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIlI);
          "".length();
          if (" ".length() > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIlIlIIIIllI = lllllllllllllllIllIlIIlIlIIIIIll.findStaticSetter(lllllllllllllllIllIlIIlIlIIIlIII, lllllllllllllllIllIlIIlIlIIIIlll, lllllllllllllllIllIlIIlIlIIIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIlIlIIIIllI);
    } catch (Exception lllllllllllllllIllIlIIlIlIIIIlII) {
      lllllllllllllllIllIlIIlIlIIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIlllllIIl() {
    llIIIlIllllllI = new String[llIIIllIlIlIlI[10]];
    llIIIlIllllllI[llIIIllIlIlIlI[11]] = llIIIllIlIIlII[llIIIllIlIlIlI[12]];
    llIIIlIllllllI[llIIIllIlIlIlI[9]] = llIIIllIlIIlII[llIIIllIlIlIlI[13]];
    llIIIlIllllllI[llIIIllIlIlIlI[14]] = llIIIllIlIIlII[llIIIllIlIlIlI[15]];
    llIIIlIllllllI[llIIIllIlIlIlI[16]] = llIIIllIlIIlII[llIIIllIlIlIlI[14]];
    llIIIlIllllllI[llIIIllIlIlIlI[17]] = llIIIllIlIIlII[llIIIllIlIlIlI[18]];
    llIIIlIllllllI[llIIIllIlIlIlI[2]] = llIIIllIlIIlII[llIIIllIlIlIlI[19]];
    llIIIlIllllllI[llIIIllIlIlIlI[5]] = llIIIllIlIIlII[llIIIllIlIlIlI[17]];
    llIIIlIllllllI[llIIIllIlIlIlI[6]] = llIIIllIlIIlII[llIIIllIlIlIlI[20]];
    llIIIlIllllllI[llIIIllIlIlIlI[19]] = llIIIllIlIIlII[llIIIllIlIlIlI[21]];
    llIIIlIllllllI[llIIIllIlIlIlI[1]] = llIIIllIlIIlII[llIIIllIlIlIlI[16]];
    llIIIlIllllllI[llIIIllIlIlIlI[0]] = llIIIllIlIIlII[llIIIllIlIlIlI[11]];
    llIIIlIllllllI[llIIIllIlIlIlI[22]] = llIIIllIlIIlII[llIIIllIlIlIlI[23]];
    llIIIlIllllllI[llIIIllIlIlIlI[3]] = llIIIllIlIIlII[llIIIllIlIlIlI[22]];
    llIIIlIllllllI[llIIIllIlIlIlI[12]] = llIIIllIlIIlII[llIIIllIlIlIlI[10]];
    llIIIlIllllllI[llIIIllIlIlIlI[15]] = llIIIllIlIIlII[llIIIllIlIlIlI[24]];
    llIIIlIllllllI[llIIIllIlIlIlI[4]] = llIIIllIlIIlII[llIIIllIlIlIlI[25]];
    llIIIlIllllllI[llIIIllIlIlIlI[7]] = llIIIllIlIIlII[llIIIllIlIlIlI[26]];
    llIIIlIllllllI[llIIIllIlIlIlI[20]] = llIIIllIlIIlII[llIIIllIlIlIlI[27]];
    llIIIlIllllllI[llIIIllIlIlIlI[23]] = llIIIllIlIIlII[llIIIllIlIlIlI[28]];
    llIIIlIllllllI[llIIIllIlIlIlI[13]] = llIIIllIlIIlII[llIIIllIlIlIlI[29]];
    llIIIlIllllllI[llIIIllIlIlIlI[21]] = llIIIllIlIIlII[llIIIllIlIlIlI[30]];
    llIIIlIllllllI[llIIIllIlIlIlI[18]] = llIIIllIlIIlII[llIIIllIlIlIlI[31]];
    llIIIlIllllllI[llIIIllIlIlIlI[8]] = llIIIllIlIIlII[llIIIllIlIlIlI[32]];
    llIIIlIlllllll = new Class[llIIIllIlIlIlI[9]];
    llIIIlIlllllll[llIIIllIlIlIlI[8]] = TextFormatting.class;
    llIIIlIlllllll[llIIIllIlIlIlI[2]] = Minecraft.class;
    llIIIlIlllllll[llIIIllIlIlIlI[1]] = boolean.class;
    llIIIlIlllllll[llIIIllIlIlIlI[3]] = RayTraceResult.class;
    llIIIlIlllllll[llIIIllIlIlIlI[6]] = f9.class;
    llIIIlIlllllll[llIIIllIlIlIlI[7]] = a.class;
    llIIIlIlllllll[llIIIllIlIlIlI[5]] = RayTraceResult.Type.class;
    llIIIlIlllllll[llIIIllIlIlIlI[4]] = Entity.class;
    llIIIlIlllllll[llIIIllIlIlIlI[0]] = f13.class;
  }
  
  private static void lIIIIlIIllllllll() {
    llIIIllIlIIlII = new String[llIIIllIlIlIlI[33]];
    llIIIllIlIIlII[llIIIllIlIlIlI[0]] = lIIIIlIIlllllIlI(llIIIllIlIIlll[llIIIllIlIlIlI[0]], llIIIllIlIIlll[llIIIllIlIlIlI[1]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[1]] = lIIIIlIIlllllIll(llIIIllIlIIlll[llIIIllIlIlIlI[2]], llIIIllIlIIlll[llIIIllIlIlIlI[3]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[2]] = lIIIIlIIlllllIlI(llIIIllIlIIlll[llIIIllIlIlIlI[4]], llIIIllIlIIlll[llIIIllIlIlIlI[5]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[3]] = lIIIIlIIlllllIlI(llIIIllIlIIlll[llIIIllIlIlIlI[6]], llIIIllIlIIlll[llIIIllIlIlIlI[7]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[4]] = lIIIIlIIlllllIlI(llIIIllIlIIlll[llIIIllIlIlIlI[8]], llIIIllIlIIlll[llIIIllIlIlIlI[9]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[5]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[12]], llIIIllIlIIlll[llIIIllIlIlIlI[13]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[6]] = lIIIIlIIlllllIlI(llIIIllIlIIlll[llIIIllIlIlIlI[15]], llIIIllIlIIlll[llIIIllIlIlIlI[14]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[7]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[18]], llIIIllIlIIlll[llIIIllIlIlIlI[19]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[8]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[17]], llIIIllIlIIlll[llIIIllIlIlIlI[20]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[9]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[21]], llIIIllIlIIlll[llIIIllIlIlIlI[16]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[12]] = lIIIIlIIlllllIll(llIIIllIlIIlll[llIIIllIlIlIlI[11]], llIIIllIlIIlll[llIIIllIlIlIlI[23]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[13]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[22]], llIIIllIlIIlll[llIIIllIlIlIlI[10]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[15]] = lIIIIlIIllllllII(llIIIllIlIIlll[llIIIllIlIlIlI[24]], llIIIllIlIIlll[llIIIllIlIlIlI[25]]);
    llIIIllIlIIlII[llIIIllIlIlIlI[14]] = lIIIIlIIlllllIlI("PCoBdCg7IRA5NzMpAXQwJiYZdDE3NwF0ETc3ARwqICIULjE7IRJgFxccMA5/anVVemVy", "ROuZE");
    llIIIllIlIIlII[llIIIllIlIlIlI[18]] = lIIIIlIIlllllIlI("Fx08dwcQFi06GBgePHcPFwwhLRNXPSYtAw0Bcj8fFxsXblpJSH0GCSZCYHAmExk+OEUVGSY+RSoMOjAEHkNyeUo=", "yxHYj");
    llIIIllIlIIlII[llIIIllIlIlIlI[19]] = lIIIIlIIllllllII("ysdHL9FefOtu83NIi/JRkEPaWM7/Pbg+nm7T4iDXsaEB4wEphSujV3bqW65xA4ln", "VsLZc");
    llIIIllIlIIlII[llIIIllIlIlIlI[17]] = lIIIIlIIllllllII("24DziTQPp/wtGDY97BBQV+9iwGXzWz8cq2Q6YK1WQRbPfesKIcLCz6ECl08D/2cIlmgK1+0WMKg=", "PdDGK");
    llIIIllIlIIlII[llIIIllIlIlIlI[20]] = lIIIIlIIlllllIlI("IgEsfDolCj0xJS0CLHwiOA00fDotEDB8BS0dDCA2LwEKNyQ5CCxoMSUBNDYIe1ZrYm8TA2JmbWxEeA==", "LdXRW");
    llIIIllIlIIlII[llIIIllIlIlIlI[21]] = lIIIIlIIllllllII("5NC4jVJ9NQJKjYmOInFS7tfZL6thIp4Y80U02KzoYsWrwQk9jgkrJRItcDYKWTns6Dm5F7jpPdk=", "aulTw");
    llIIIllIlIIlII[llIIIllIlIlIlI[16]] = lIIIIlIIlllllIll("MYNtsIcUgf/vkGOJW0v1zG/DhEiznpqwqQeLirURDnAkv04OUllTPQ==", "uXFCg");
    llIIIllIlIIlII[llIIIllIlIlIlI[11]] = lIIIIlIIlllllIlI("CCxIGT0QOQ8eLQouSAghFWcAW3pfBC85Cl95XEppRWk=", "eIfjI");
    llIIIllIlIIlII[llIIIllIlIlIlI[23]] = lIIIIlIIllllllII("0RMgO3ORcVEGCxVXRS6Tw+dENGSoWFRomEkD6KVAc5Qdll5oHbHYDp/gKKkWbUkN5zlZdVmjDwg=", "SnJYI");
    llIIIllIlIIlII[llIIIllIlIlIlI[22]] = lIIIIlIIlllllIll("nL0RCTxDF+hEmH6bnr22tAo3jdK/PFuxEArBXLkWTclNFKBVdopqqQ==", "bjkKM");
    llIIIllIlIIlII[llIIIllIlIlIlI[10]] = lIIIIlIIlllllIll("TtkfeQgizluIvJjVd6mau/MgS62K7nCtHWXnZnCrUyNBqvJ0lHCJDA==", "mVYyr");
    llIIIllIlIIlII[llIIIllIlIlIlI[24]] = lIIIIlIIllllllII("MupsWa9GZHimC4U4WKalvklIIi2n5P/RWv6P20kEv13s3QSbj7ElgINhDgVt2a55qT/DJYDxWAPmJwjalOHDywubxmSst2F9i4YhfbuEfqs=", "oNziH");
    llIIIllIlIIlII[llIIIllIlIlIlI[25]] = lIIIIlIIlllllIll("fUNki2IWdkQrvW/7vtxLHl9gtX/tTCJCnTMh7JYSghY=", "ezLpC");
    llIIIllIlIIlII[llIIIllIlIlIlI[26]] = lIIIIlIIlllllIll("oX8Y0CsdN23WirWmNeRAbnCB5ZAZbpykJl4e+oEGWUr5GNOnk5dh4881lZyQJaM21qlEf/kZ4RnTlVTDiXHvgw==", "PWSJV");
    llIIIllIlIIlII[llIIIllIlIlIlI[27]] = lIIIIlIIllllllII("1JCsPS604X1yYW+gAmRANcZo8Z0Pz0gehnl8iPcPQe8H0n1JgXUT768oeDXZx1WAZnPpcRWluQo=", "nkuOH");
    llIIIllIlIIlII[llIIIllIlIlIlI[28]] = lIIIIlIIlllllIlI("DCJ2JDAUNzEjIA4gdjUsEWk5bSUFIx4lLQQpPG1sLS05ISVOKzk5I04ULCUtDyBjGy4AMTl4KAApP3gXFTUxOSNabg5tZEE=", "aGXWD");
    llIIIllIlIIlII[llIIIllIlIlIlI[29]] = lIIIIlIIlllllIll("BcsafaPS+X+ZbpLROKGyhmt0esX/p+8PWrzzzagYNzVY4u2XxN3ZRnDFwt1YIcQDlZruFnWse3Vrs6FdJj5LtGVLRGvE2q3B", "wiaAG");
    llIIIllIlIIlII[llIIIllIlIlIlI[30]] = lIIIIlIIllllllII("gR0SAXuiljE+ZmRdXyH1wD4usJS4gyBRXj3HxM57rIuJxWxGl7oQ2h19N/X5NO6e0uxADrwWysY=", "pkcKd");
    llIIIllIlIIlII[llIIIllIlIlIlI[31]] = lIIIIlIIlllllIlI("HA0bOH0aDQM+fSUYHzA9ES4YMD8SCR9jJxk/GSs6GAtXcXo6BgwvMlkADDc0WT8ZKzoYC1Zjc1Y=", "vlmYS");
    llIIIllIlIIlII[llIIIllIlIlIlI[32]] = lIIIIlIIllllllII("tarDE4Ma6xsUPFBypNxNv7PcB1HMGT76StbKmbgfS/uy5qo4qqKGr0OwNLn3NYPrEH9jYFf5NmIIzjGwp6zxTA==", "XeNjV");
    llIIIllIlIIlll = null;
  }
  
  private static void lIIIIlIlIIIIIIII() {
    String str = (new Exception()).getStackTrace()[llIIIllIlIlIlI[0]].getFileName();
    llIIIllIlIIlll = str.substring(str.indexOf("ä") + llIIIllIlIlIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIlllllIlI(String lllllllllllllllIllIlIIlIIlllllll, String lllllllllllllllIllIlIIlIIllllllI) {
    lllllllllllllllIllIlIIlIIlllllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIlIIlllllIl = new StringBuilder();
    char[] lllllllllllllllIllIlIIlIIlllllII = lllllllllllllllIllIlIIlIIllllllI.toCharArray();
    int lllllllllllllllIllIlIIlIIllllIll = llIIIllIlIlIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIlIIlllllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIlIlIlI[0];
    while (lIIIIlIlIIIlIIIl(j, i)) {
      char lllllllllllllllIllIlIIlIlIIIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIlIIllllIll++;
      j++;
      "".length();
      if (" ".length() << " ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIlIIlllllIl);
  }
  
  private static String lIIIIlIIllllllII(String lllllllllllllllIllIlIIlIIlllIlll, String lllllllllllllllIllIlIIlIIlllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlIIllllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIlllIllI.getBytes(StandardCharsets.UTF_8)), llIIIllIlIlIlI[8]), "DES");
      Cipher lllllllllllllllIllIlIIlIIllllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIlIIllllIIl.init(llIIIllIlIlIlI[2], lllllllllllllllIllIlIIlIIllllIlI);
      return new String(lllllllllllllllIllIlIIlIIllllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlIIllllIII) {
      lllllllllllllllIllIlIIlIIllllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIlllllIll(String lllllllllllllllIllIlIIlIIlllIIlI, String lllllllllllllllIllIlIIlIIlllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlIIlllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIlllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIlIIlllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIlIIlllIlII.init(llIIIllIlIlIlI[2], lllllllllllllllIllIlIIlIIlllIlIl);
      return new String(lllllllllllllllIllIlIIlIIlllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlIIlllIIll) {
      lllllllllllllllIllIlIIlIIlllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlIIIIlIlI() {
    llIIIllIlIlIlI = new int[34];
    llIIIllIlIlIlI[0] = (0x6 ^ 0x7B ^ (0x2B ^ 0x12) << " ".length()) & ((0x53 ^ 0x7E) << " ".length() << " ".length() ^ 7 + 16 - -9 + 155 ^ -" ".length());
    llIIIllIlIlIlI[1] = " ".length();
    llIIIllIlIlIlI[2] = " ".length() << " ".length();
    llIIIllIlIlIlI[3] = "   ".length();
    llIIIllIlIlIlI[4] = " ".length() << " ".length() << " ".length();
    llIIIllIlIlIlI[5] = 0x7C ^ 0x55 ^ (0xBC ^ 0xB7) << " ".length() << " ".length();
    llIIIllIlIlIlI[6] = "   ".length() << " ".length();
    llIIIllIlIlIlI[7] = 0x70 ^ 0x77;
    llIIIllIlIlIlI[8] = " ".length() << "   ".length();
    llIIIllIlIlIlI[9] = (0x7 ^ 0x28) << " ".length() ^ 0xE2 ^ 0xB5;
    llIIIllIlIlIlI[10] = " ".length() << (0x8A ^ 0x8D) ^ 45 + 6 - -84 + 16;
    llIIIllIlIlIlI[11] = (0x43 ^ 0x46) << " ".length() << " ".length();
    llIIIllIlIlIlI[12] = ((0x60 ^ 0x5B) << " ".length() ^ 0x24 ^ 0x57) << " ".length();
    llIIIllIlIlIlI[13] = 0xA7 ^ 0x98 ^ (0x2C ^ 0x21) << " ".length() << " ".length();
    llIIIllIlIlIlI[14] = (0xFC ^ 0xAB) << " ".length() ^ 83 + 7 - -21 + 52;
    llIIIllIlIlIlI[15] = "   ".length() << " ".length() << " ".length();
    llIIIllIlIlIlI[16] = (0x4E ^ 0x13) << " ".length() ^ 100 + 84 - 146 + 131;
    llIIIllIlIlIlI[17] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIlIlIlI[18] = ((0x6D ^ 0x7A) << " ".length() ^ 0x82 ^ 0xAB) << " ".length();
    llIIIllIlIlIlI[19] = 0x5 ^ 0xA;
    llIIIllIlIlIlI[20] = 0x61 ^ 0x70;
    llIIIllIlIlIlI[21] = (0x57 ^ 0x5E) << " ".length();
    llIIIllIlIlIlI[22] = (0x35 ^ 0x3E) << " ".length();
    llIIIllIlIlIlI[23] = "   ".length() << (0x98 ^ 0x9D) ^ 0x19 ^ 0x6C;
    llIIIllIlIlIlI[24] = "   ".length() << "   ".length();
    llIIIllIlIlIlI[25] = (0x3E ^ 0xD) << " ".length() ^ 87 + 7 - 68 + 101;
    llIIIllIlIlIlI[26] = (0x3C ^ 0xD ^ (0xB7 ^ 0xB8) << " ".length() << " ".length()) << " ".length();
    llIIIllIlIlIlI[27] = 0x12 ^ 0x51 ^ (0x47 ^ 0x4C) << "   ".length();
    llIIIllIlIlIlI[28] = (0x18 ^ 0x1F) << " ".length() << " ".length();
    llIIIllIlIlIlI[29] = 0xD9 ^ 0xC4;
    llIIIllIlIlIlI[30] = ((0x37 ^ 0x30) << "   ".length() ^ 0x5 ^ 0x32) << " ".length();
    llIIIllIlIlIlI[31] = 144 + 37 - 73 + 55 ^ (0xA8 ^ 0x87) << " ".length() << " ".length();
    llIIIllIlIlIlI[32] = " ".length() << (0x93 ^ 0x96);
    llIIIllIlIlIlI[33] = (0x86 ^ 0x8F) << " ".length() << " ".length() ^ 0xB5 ^ 0xB0;
  }
  
  private static boolean lIIIIlIlIIIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIlIIIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIlIIIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIlIIIIllII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIlIlIIIIllIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIlIlIIIIlllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlIlIIIIlIll(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\as.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */