package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;

public class f0e extends au {
  private static String[] lIllllllIlIlII;
  
  private static Class[] lIllllllIlIlIl;
  
  private static final String[] lIllllllllIlIl;
  
  private static String[] lIllllllllIllI;
  
  private static final int[] lIllllllllIlll;
  
  public f0e() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0e.lIllllllllIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0e.lIllllllllIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0e.lIllllllllIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlllllIIIlllII	Lme/stupitdog/bhp/f0e;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   10: invokestatic lIIIIIIIlIllIlIl : (Ljava/lang/Object;)Z
    //   13: ifeq -> 35
    //   16: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   26: instanceof net/minecraft/client/gui/inventory/GuiContainer
    //   29: invokestatic lIIIIIIIlIllIllI : (I)Z
    //   32: ifeq -> 315
    //   35: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   40: <illegal opcode> 3 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   45: <illegal opcode> 4 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   50: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   53: iconst_0
    //   54: iaload
    //   55: <illegal opcode> 5 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   60: <illegal opcode> 6 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   65: <illegal opcode> 7 : ()Lnet/minecraft/item/Item;
    //   70: invokestatic lIIIIIIIlIllIlll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   73: ifeq -> 315
    //   76: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   79: iconst_3
    //   80: iaload
    //   81: istore_1
    //   82: iload_1
    //   83: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   86: iconst_4
    //   87: iaload
    //   88: invokestatic lIIIIIIIlIlllIII : (II)Z
    //   91: ifeq -> 315
    //   94: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   99: <illegal opcode> 3 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   104: <illegal opcode> 4 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   109: iload_1
    //   110: <illegal opcode> 5 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   115: <illegal opcode> 6 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   120: <illegal opcode> 7 : ()Lnet/minecraft/item/Item;
    //   125: invokestatic lIIIIIIIlIlllIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   128: ifeq -> 256
    //   131: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   136: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   141: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   146: <illegal opcode> 3 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   151: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   156: <illegal opcode> 10 : (Lnet/minecraft/inventory/Container;)I
    //   161: iload_1
    //   162: getstatic me/stupitdog/bhp/f0e.lIllllllllIlll : [I
    //   165: iconst_0
    //   166: iaload
    //   167: <illegal opcode> 11 : ()Lnet/minecraft/inventory/ClickType;
    //   172: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   177: <illegal opcode> 3 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   182: <illegal opcode> 12 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   187: ldc ''
    //   189: invokevirtual length : ()I
    //   192: pop2
    //   193: ldc ''
    //   195: invokevirtual length : ()I
    //   198: pop
    //   199: sipush #166
    //   202: sipush #199
    //   205: ixor
    //   206: ldc ' '
    //   208: invokevirtual length : ()I
    //   211: ishl
    //   212: bipush #112
    //   214: bipush #89
    //   216: iadd
    //   217: sipush #164
    //   220: isub
    //   221: bipush #100
    //   223: iadd
    //   224: ixor
    //   225: bipush #59
    //   227: bipush #12
    //   229: ixor
    //   230: ldc ' '
    //   232: invokevirtual length : ()I
    //   235: ishl
    //   236: sipush #144
    //   239: sipush #181
    //   242: ixor
    //   243: ixor
    //   244: ldc ' '
    //   246: invokevirtual length : ()I
    //   249: ineg
    //   250: ixor
    //   251: iand
    //   252: ifeq -> 315
    //   255: return
    //   256: iinc #1, 1
    //   259: ldc ''
    //   261: invokevirtual length : ()I
    //   264: pop
    //   265: sipush #192
    //   268: sipush #181
    //   271: ixor
    //   272: sipush #197
    //   275: sipush #194
    //   278: ixor
    //   279: ldc '   '
    //   281: invokevirtual length : ()I
    //   284: ishl
    //   285: ixor
    //   286: bipush #29
    //   288: bipush #18
    //   290: ixor
    //   291: ldc '   '
    //   293: invokevirtual length : ()I
    //   296: ishl
    //   297: bipush #59
    //   299: bipush #14
    //   301: ixor
    //   302: ixor
    //   303: ldc ' '
    //   305: invokevirtual length : ()I
    //   308: ineg
    //   309: ixor
    //   310: iand
    //   311: ifeq -> 82
    //   314: return
    //   315: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   82	233	1	lllllllllllllllIllIlllllIIIllIll	I
    //   0	316	0	lllllllllllllllIllIlllllIIIllIlI	Lme/stupitdog/bhp/f0e;
  }
  
  static {
    lIIIIIIIlIllIlII();
    lIIIIIIIlIllIIll();
    lIIIIIIIlIllIIlI();
    lIIIIIIIlIlIlllI();
  }
  
  private static CallSite lIIIIIIIIlIlIIIl(MethodHandles.Lookup lllllllllllllllIllIlllllIIIlIIIl, String lllllllllllllllIllIlllllIIIlIIII, MethodType lllllllllllllllIllIlllllIIIIllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllllIIIlIlll = lIllllllIlIlII[Integer.parseInt(lllllllllllllllIllIlllllIIIlIIII)].split(lIllllllllIlIl[lIllllllllIlll[5]]);
      Class<?> lllllllllllllllIllIlllllIIIlIllI = Class.forName(lllllllllllllllIllIlllllIIIlIlll[lIllllllllIlll[0]]);
      String lllllllllllllllIllIlllllIIIlIlIl = lllllllllllllllIllIlllllIIIlIlll[lIllllllllIlll[1]];
      MethodHandle lllllllllllllllIllIlllllIIIlIlII = null;
      int lllllllllllllllIllIlllllIIIlIIll = lllllllllllllllIllIlllllIIIlIlll[lIllllllllIlll[5]].length();
      if (lIIIIIIIlIlllIlI(lllllllllllllllIllIlllllIIIlIIll, lIllllllllIlll[2])) {
        MethodType lllllllllllllllIllIlllllIIIllIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllllIIIlIlll[lIllllllllIlll[2]], f0e.class.getClassLoader());
        if (lIIIIIIIlIlllIll(lllllllllllllllIllIlllllIIIlIIll, lIllllllllIlll[2])) {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findVirtual(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIIl);
          "".length();
          if (" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findStatic(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIIl);
        } 
        "".length();
        if ((" ".length() << " ".length() & (" ".length() << " ".length() ^ -" ".length())) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllllIIIllIII = lIllllllIlIlIl[Integer.parseInt(lllllllllllllllIllIlllllIIIlIlll[lIllllllllIlll[2]])];
        if (lIIIIIIIlIlllIll(lllllllllllllllIllIlllllIIIlIIll, lIllllllllIlll[5])) {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findGetter(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIIlIlllIll(lllllllllllllllIllIlllllIIIlIIll, lIllllllllIlll[6])) {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findStaticGetter(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIII);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else if (lIIIIIIIlIlllIll(lllllllllllllllIllIlllllIIIlIIll, lIllllllllIlll[7])) {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findSetter(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIII);
          "".length();
          if (" ".length() << " ".length() > "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllllIIIlIlII = lllllllllllllllIllIlllllIIIlIIIl.findStaticSetter(lllllllllllllllIllIlllllIIIlIllI, lllllllllllllllIllIlllllIIIlIlIl, lllllllllllllllIllIlllllIIIllIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllllIIIlIlII);
    } catch (Exception lllllllllllllllIllIlllllIIIlIIlI) {
      lllllllllllllllIllIlllllIIIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIlIlIlllI() {
    lIllllllIlIlII = new String[lIllllllllIlll[8]];
    lIllllllIlIlII[lIllllllllIlll[9]] = lIllllllllIlIl[lIllllllllIlll[6]];
    lIllllllIlIlII[lIllllllllIlll[5]] = lIllllllllIlIl[lIllllllllIlll[7]];
    lIllllllIlIlII[lIllllllllIlll[10]] = lIllllllllIlIl[lIllllllllIlll[9]];
    lIllllllIlIlII[lIllllllllIlll[11]] = lIllllllllIlIl[lIllllllllIlll[11]];
    lIllllllIlIlII[lIllllllllIlll[12]] = lIllllllllIlIl[lIllllllllIlll[13]];
    lIllllllIlIlII[lIllllllllIlll[1]] = lIllllllllIlIl[lIllllllllIlll[3]];
    lIllllllIlIlII[lIllllllllIlll[2]] = lIllllllllIlIl[lIllllllllIlll[12]];
    lIllllllIlIlII[lIllllllllIlll[3]] = lIllllllllIlIl[lIllllllllIlll[14]];
    lIllllllIlIlII[lIllllllllIlll[6]] = lIllllllllIlIl[lIllllllllIlll[10]];
    lIllllllIlIlII[lIllllllllIlll[13]] = lIllllllllIlIl[lIllllllllIlll[8]];
    lIllllllIlIlII[lIllllllllIlll[0]] = lIllllllllIlIl[lIllllllllIlll[15]];
    lIllllllIlIlII[lIllllllllIlll[7]] = lIllllllllIlIl[lIllllllllIlll[16]];
    lIllllllIlIlII[lIllllllllIlll[14]] = lIllllllllIlIl[lIllllllllIlll[17]];
    lIllllllIlIlIl = new Class[lIllllllllIlll[12]];
    lIllllllIlIlIl[lIllllllllIlll[6]] = InventoryPlayer.class;
    lIllllllIlIlIl[lIllllllllIlll[3]] = ClickType.class;
    lIllllllIlIlIl[lIllllllllIlll[11]] = Container.class;
    lIllllllIlIlIl[lIllllllllIlll[0]] = f13.class;
    lIllllllIlIlIl[lIllllllllIlll[2]] = GuiScreen.class;
    lIllllllIlIlIl[lIllllllllIlll[9]] = PlayerControllerMP.class;
    lIllllllIlIlIl[lIllllllllIlll[5]] = EntityPlayerSP.class;
    lIllllllIlIlIl[lIllllllllIlll[7]] = Item.class;
    lIllllllIlIlIl[lIllllllllIlll[1]] = Minecraft.class;
    lIllllllIlIlIl[lIllllllllIlll[13]] = int.class;
  }
  
  private static void lIIIIIIIlIllIIlI() {
    lIllllllllIlIl = new String[lIllllllllIlll[18]];
    lIllllllllIlIl[lIllllllllIlll[0]] = lIIIIIIIlIlIllll(lIllllllllIllI[lIllllllllIlll[0]], lIllllllllIllI[lIllllllllIlll[1]]);
    lIllllllllIlIl[lIllllllllIlll[1]] = lIIIIIIIlIlIllll(lIllllllllIllI[lIllllllllIlll[2]], lIllllllllIllI[lIllllllllIlll[5]]);
    lIllllllllIlIl[lIllllllllIlll[2]] = lIIIIIIIlIllIIII(lIllllllllIllI[lIllllllllIlll[6]], lIllllllllIllI[lIllllllllIlll[7]]);
    lIllllllllIlIl[lIllllllllIlll[5]] = lIIIIIIIlIllIIIl(lIllllllllIllI[lIllllllllIlll[9]], lIllllllllIllI[lIllllllllIlll[11]]);
    lIllllllllIlIl[lIllllllllIlll[6]] = lIIIIIIIlIlIllll(lIllllllllIllI[lIllllllllIlll[13]], lIllllllllIllI[lIllllllllIlll[3]]);
    lIllllllllIlIl[lIllllllllIlll[7]] = lIIIIIIIlIlIllll(lIllllllllIllI[lIllllllllIlll[12]], lIllllllllIllI[lIllllllllIlll[14]]);
    lIllllllllIlIl[lIllllllllIlll[9]] = lIIIIIIIlIllIIII(lIllllllllIllI[lIllllllllIlll[10]], "kkIrY");
    lIllllllllIlIl[lIllllllllIlll[11]] = lIIIIIIIlIllIIIl("rUW55CfghHMnaDs+eOSihuyQUoxMn7m2lxrmC/H4TARTJoSVfyrURpGxYQ4pFeCV", "ppaQu");
    lIllllllllIlIl[lIllllllllIlll[13]] = lIIIIIIIlIlIllll("FhciewERHDM2HhkUInsFFgQzOxgXAC97LxccIjQFFhckbwoRFzoxM09HZ2BeJxFsbVZYUnY=", "xrVUl");
    lIllllllllIlIl[lIllllllllIlll[3]] = lIIIIIIIlIllIIIl("YBcREHLE4boDJJDwBUO4lTt+U+aEGUf8c+Ln6+8gwuY=", "XIpZY");
    lIllllllllIlIl[lIllllllllIlll[12]] = lIIIIIIIlIllIIIl("HaLWu/kitkZDzUrwJ+Mw573b5ltCyE2Fb1Sy7Zk5hCB1AFO/H+MsA62X+DYfjAgTQ+QUsQQQQi4=", "aUMQK");
    lIllllllllIlIl[lIllllllllIlll[14]] = lIIIIIIIlIllIIII("vR2xnSSvGgXTqfKeoeAMpdDsH+KD7XtwaFlbj2B8ac0t53Hng77c1i0bgGacGJZJSyuQIWQEYRhyp5TtejziYw==", "vZtAZ");
    lIllllllllIlIl[lIllllllllIlll[10]] = lIIIIIIIlIlIllll("JjQiWQwhPzMUEyk3IlkCJDgzGRVmNDgDCDwoeDIPPDgiDjEkMC8SExsBbBEILT0yKFZ5YWFGPioobENbaHF2", "HQVwa");
    lIllllllllIlIl[lIllllllllIlll[8]] = lIIIIIIIlIllIIII("Fi8745WfN74OK54xd9vXJEMxepNyTle7ALtAx453b70GajF4Uti9ipdmRjpjB0LBbY4jo4r6a7w=", "QuoQS");
    lIllllllllIlIl[lIllllllllIlll[15]] = lIIIIIIIlIlIllll("AARJAS0YEQ4GPQIGSRAxHU8BQ2pXIig/Gyw1XUJjTUFHUg==", "magrY");
    lIllllllllIlIl[lIllllllllIlll[16]] = lIIIIIIIlIllIIII("6dV5RHpQmoIQ5A3xpw8xMS6eHjTLR+QQ1tTjTGeRYbIFBnWRv8aIZPIcyVK1uLeN3wyxxXsKXB0B8SRaTvG7i+xaIUACuoIC6wydUYpwMlxV71BI0qP7Av5studaizaN", "goOkd");
    lIllllllllIlIl[lIllllllllIlll[17]] = lIIIIIIIlIlIllll("IhQyZBklHyMpBi0XMmQdIgcjJAAjAz9kNyAYJSEgNQEjcCcbMBZwTXZRZmpU", "LqFJt");
    lIllllllllIllI = null;
  }
  
  private static void lIIIIIIIlIllIIll() {
    String str = (new Exception()).getStackTrace()[lIllllllllIlll[0]].getFileName();
    lIllllllllIllI = str.substring(str.indexOf("ä") + lIllllllllIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIlIllIIII(String lllllllllllllllIllIlllllIIIIlIll, String lllllllllllllllIllIlllllIIIIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlllllIIIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllllIIIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllllIIIIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllllIIIIllIl.init(lIllllllllIlll[2], lllllllllllllllIllIlllllIIIIlllI);
      return new String(lllllllllllllllIllIlllllIIIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllllIIIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllllIIIIllII) {
      lllllllllllllllIllIlllllIIIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIlIlIllll(String lllllllllllllllIllIlllllIIIIlIII, String lllllllllllllllIllIlllllIIIIIlll) {
    lllllllllllllllIllIlllllIIIIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllllIIIIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllllIIIIIllI = new StringBuilder();
    char[] lllllllllllllllIllIlllllIIIIIlIl = lllllllllllllllIllIlllllIIIIIlll.toCharArray();
    int lllllllllllllllIllIlllllIIIIIlII = lIllllllllIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllllIIIIlIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllllllIlll[0];
    while (lIIIIIIIlIlllIII(j, i)) {
      char lllllllllllllllIllIlllllIIIIlIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllllIIIIIlII++;
      j++;
      "".length();
      if ((((0x0 ^ 0x69) << " ".length() ^ 126 + 52 - 76 + 41) & (16 + 30 - -61 + 130 ^ (0x2E ^ 0x25) << " ".length() << " ".length() << " ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllllIIIIIllI);
  }
  
  private static String lIIIIIIIlIllIIIl(String lllllllllllllllIllIlllllIIIIIIII, String lllllllllllllllIllIllllIllllllll) {
    try {
      SecretKeySpec lllllllllllllllIllIlllllIIIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIllllllll.getBytes(StandardCharsets.UTF_8)), lIllllllllIlll[13]), "DES");
      Cipher lllllllllllllllIllIlllllIIIIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIlllllIIIIIIlI.init(lIllllllllIlll[2], lllllllllllllllIllIlllllIIIIIIll);
      return new String(lllllllllllllllIllIlllllIIIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllllIIIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllllIIIIIIIl) {
      lllllllllllllllIllIlllllIIIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIlIllIlII() {
    lIllllllllIlll = new int[19];
    lIllllllllIlll[0] = (0x8F ^ 0xB4) & (0x5B ^ 0x60 ^ 0xFFFFFFFF);
    lIllllllllIlll[1] = " ".length();
    lIllllllllIlll[2] = " ".length() << " ".length();
    lIllllllllIlll[3] = 49 + 151 - 158 + 137 ^ (0x7A ^ 0x27) << " ".length();
    lIllllllllIlll[4] = (0x13 ^ 0x38) << " ".length() << " ".length() ^ 93 + 85 - 151 + 116;
    lIllllllllIlll[5] = "   ".length();
    lIllllllllIlll[6] = " ".length() << " ".length() << " ".length();
    lIllllllllIlll[7] = 157 + 30 - 77 + 53 ^ (0x7B ^ 0x28) << " ".length();
    lIllllllllIlll[8] = 0x2D ^ 0x18 ^ (0x82 ^ 0x85) << "   ".length();
    lIllllllllIlll[9] = "   ".length() << " ".length();
    lIllllllllIlll[10] = "   ".length() << " ".length() << " ".length();
    lIllllllllIlll[11] = 0x5C ^ 0x5B;
    lIllllllllIlll[12] = (0x65 ^ 0x60) << " ".length();
    lIllllllllIlll[13] = " ".length() << "   ".length();
    lIllllllllIlll[14] = (0x56 ^ 0x5F) << " ".length() << " ".length() ^ 0x20 ^ 0xF;
    lIllllllllIlll[15] = ((0x10 ^ 0x23) << " ".length() ^ 0x1A ^ 0x7B) << " ".length();
    lIllllllllIlll[16] = 84 + 39 - 118 + 148 ^ (0xD9 ^ 0x92) << " ".length();
    lIllllllllIlll[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllllllIlll[18] = (0x43 ^ 0x60) << " ".length() << " ".length() ^ 63 + 72 - 65 + 87;
  }
  
  private static boolean lIIIIIIIlIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIlIlllIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIlIlllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIlIllIlll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIIIlIllIlIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIIlIlllIIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIIIlIllIllI(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */