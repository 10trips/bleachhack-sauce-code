package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class f1000000000000000000000000000000000000 extends au {
  @EventHandler
  private final Listener<f100000000000.Receive> receiveListener;
  
  private static String[] lIllIlIIlIIllI;
  
  private static Class[] lIllIlIIlIIlll;
  
  private static final String[] lIllIlIIlIlIll;
  
  private static String[] lIllIlIIlIllll;
  
  private static final int[] lIllIlIIllIIII;
  
  public f1000000000000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIlIlIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIllIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIlIlIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIllIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIlIlIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIllIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIllIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000.lIllIlIIllIIII : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: putfield receiveListener : Lme/zero/alpine/listener/Listener;
    //   65: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	66	0	lllllllllllllllIllllIllIlIllIlIl	Lme/stupitdog/bhp/f1000000000000000000000000000000000000;
  }
  
  static {
    llllIIlIlllllIl();
    llllIIlIllllIII();
    llllIIlIlllIlll();
    llllIIlIlllIIII();
  }
  
  private static CallSite llllIIlIllIIIll(MethodHandles.Lookup lllllllllllllllIllllIllIlIlIlIll, String lllllllllllllllIllllIllIlIlIlIlI, MethodType lllllllllllllllIllllIllIlIlIlIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIllIlIllIIIl = lIllIlIIlIIllI[Integer.parseInt(lllllllllllllllIllllIllIlIlIlIlI)].split(lIllIlIIlIlIll[lIllIlIIllIIII[3]]);
      Class<?> lllllllllllllllIllllIllIlIllIIII = Class.forName(lllllllllllllllIllllIllIlIllIIIl[lIllIlIIllIIII[0]]);
      String lllllllllllllllIllllIllIlIlIllll = lllllllllllllllIllllIllIlIllIIIl[lIllIlIIllIIII[1]];
      MethodHandle lllllllllllllllIllllIllIlIlIlllI = null;
      int lllllllllllllllIllllIllIlIlIllIl = lllllllllllllllIllllIllIlIllIIIl[lIllIlIIllIIII[3]].length();
      if (llllIIllIIIIIII(lllllllllllllllIllllIllIlIlIllIl, lIllIlIIllIIII[2])) {
        MethodType lllllllllllllllIllllIllIlIllIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIllIlIllIIIl[lIllIlIIllIIII[2]], f1000000000000000000000000000000000000.class.getClassLoader());
        if (llllIIlIlllllll(lllllllllllllllIllllIllIlIlIllIl, lIllIlIIllIIII[2])) {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findVirtual(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIll);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findStatic(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIll);
        } 
        "".length();
        if (" ".length() == " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIllIlIllIIlI = lIllIlIIlIIlll[Integer.parseInt(lllllllllllllllIllllIllIlIllIIIl[lIllIlIIllIIII[2]])];
        if (llllIIlIlllllll(lllllllllllllllIllllIllIlIlIllIl, lIllIlIIllIIII[3])) {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findGetter(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (llllIIlIlllllll(lllllllllllllllIllllIllIlIlIllIl, lIllIlIIllIIII[4])) {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findStaticGetter(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIlI);
          "".length();
          if (((0x3B ^ 0x2C) << " ".length() & ((0xE ^ 0x19) << " ".length() ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (llllIIlIlllllll(lllllllllllllllIllllIllIlIlIllIl, lIllIlIIllIIII[5])) {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findSetter(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIllIlIlIlllI = lllllllllllllllIllllIllIlIlIlIll.findStaticSetter(lllllllllllllllIllllIllIlIllIIII, lllllllllllllllIllllIllIlIlIllll, lllllllllllllllIllllIllIlIllIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIllIlIlIlllI);
    } catch (Exception lllllllllllllllIllllIllIlIlIllII) {
      lllllllllllllllIllllIllIlIlIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlIlllIIII() {
    lIllIlIIlIIllI = new String[lIllIlIIllIIII[6]];
    lIllIlIIlIIllI[lIllIlIIllIIII[0]] = lIllIlIIlIlIll[lIllIlIIllIIII[4]];
    lIllIlIIlIIllI[lIllIlIIllIIII[1]] = lIllIlIIlIlIll[lIllIlIIllIIII[5]];
    lIllIlIIlIIllI[lIllIlIIllIIII[5]] = lIllIlIIlIlIll[lIllIlIIllIIII[7]];
    lIllIlIIlIIllI[lIllIlIIllIIII[4]] = lIllIlIIlIlIll[lIllIlIIllIIII[6]];
    lIllIlIIlIIllI[lIllIlIIllIIII[2]] = lIllIlIIlIlIll[lIllIlIIllIIII[8]];
    lIllIlIIlIIllI[lIllIlIIllIIII[7]] = lIllIlIIlIlIll[lIllIlIIllIIII[9]];
    lIllIlIIlIIllI[lIllIlIIllIIII[3]] = lIllIlIIlIlIll[lIllIlIIllIIII[10]];
    lIllIlIIlIIlll = new Class[lIllIlIIllIIII[4]];
    lIllIlIIlIIlll[lIllIlIIllIIII[1]] = Listener.class;
    lIllIlIIlIIlll[lIllIlIIllIIII[3]] = EntityPlayerSP.class;
    lIllIlIIlIIlll[lIllIlIIllIIII[2]] = Minecraft.class;
    lIllIlIIlIIlll[lIllIlIIllIIII[0]] = f13.class;
  }
  
  private static void llllIIlIlllIlll() {
    lIllIlIIlIlIll = new String[lIllIlIIllIIII[11]];
    lIllIlIIlIlIll[lIllIlIIllIIII[0]] = llllIIlIlllIIIl(lIllIlIIlIllll[lIllIlIIllIIII[0]], lIllIlIIlIllll[lIllIlIIllIIII[1]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[1]] = llllIIlIlllIIlI(lIllIlIIlIllll[lIllIlIIllIIII[2]], lIllIlIIlIllll[lIllIlIIllIIII[3]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[2]] = llllIIlIlllIIIl(lIllIlIIlIllll[lIllIlIIllIIII[4]], lIllIlIIlIllll[lIllIlIIllIIII[5]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[3]] = llllIIlIlllIlII(lIllIlIIlIllll[lIllIlIIllIIII[7]], lIllIlIIlIllll[lIllIlIIllIIII[6]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[4]] = llllIIlIlllIIlI(lIllIlIIlIllll[lIllIlIIllIIII[8]], lIllIlIIlIllll[lIllIlIIllIIII[9]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[5]] = llllIIlIlllIlII(lIllIlIIlIllll[lIllIlIIllIIII[10]], lIllIlIIlIllll[lIllIlIIllIIII[11]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[7]] = llllIIlIlllIIlI(lIllIlIIlIllll[lIllIlIIllIIII[12]], lIllIlIIlIllll[lIllIlIIllIIII[13]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[6]] = llllIIlIlllIIIl(lIllIlIIlIllll[lIllIlIIllIIII[14]], lIllIlIIlIllll[lIllIlIIllIIII[15]]);
    lIllIlIIlIlIll[lIllIlIIllIIII[8]] = llllIIlIlllIIIl("uKztNr4KDuPB1NeQtOzsoKCudxQDG0qqOwyiXQgrLC/EelIsy1YSWs0ZOHhn6VqHgdldRQDJQjWvo/4+PyjBuc9pCDqNb3yGMIImB3g33t4=", "EdZuV");
    lIllIlIIlIlIll[lIllIlIIllIIII[9]] = llllIIlIlllIlII("LzZCKTw3IwUuLC00QjggMn0Ka3hyY1xqeHJjXGp4ZgEJOS0rJQlgKyM9Dz8keHtFDHJicw==", "BSlZH");
    lIllIlIIlIlIll[lIllIlIIllIIII[10]] = llllIIlIlllIlII("Ij9WFBI6KhETAiA9VgUOP3QeVlZ/akhXVn9qSFdWf2pIV1Z/akhXVn9qSFdWf2pIV1Z/akhXVnU3G11UdXpYR0Y=", "OZxgf");
    lIllIlIIlIllll = null;
  }
  
  private static void llllIIlIllllIII() {
    String str = (new Exception()).getStackTrace()[lIllIlIIllIIII[0]].getFileName();
    lIllIlIIlIllll = str.substring(str.indexOf("ä") + lIllIlIIllIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIlIlllIIIl(String lllllllllllllllIllllIllIlIlIIlIl, String lllllllllllllllIllllIllIlIlIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllllIllIlIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIlIlIIlII.getBytes(StandardCharsets.UTF_8)), lIllIlIIllIIII[8]), "DES");
      Cipher lllllllllllllllIllllIllIlIlIIlll = Cipher.getInstance("DES");
      lllllllllllllllIllllIllIlIlIIlll.init(lIllIlIIllIIII[2], lllllllllllllllIllllIllIlIlIlIII);
      return new String(lllllllllllllllIllllIllIlIlIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIllIlIlIIllI) {
      lllllllllllllllIllllIllIlIlIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIlIlllIlII(String lllllllllllllllIllllIllIlIlIIIlI, String lllllllllllllllIllllIllIlIlIIIIl) {
    lllllllllllllllIllllIllIlIlIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIlIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIllIlIlIIIII = new StringBuilder();
    char[] lllllllllllllllIllllIllIlIIlllll = lllllllllllllllIllllIllIlIlIIIIl.toCharArray();
    int lllllllllllllllIllllIllIlIIllllI = lIllIlIIllIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIllIlIlIIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlIIllIIII[0];
    while (llllIIllIIIIIIl(j, i)) {
      char lllllllllllllllIllllIllIlIlIIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIllIlIIllllI++;
      j++;
      "".length();
      if (" ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIllIlIlIIIII);
  }
  
  private static String llllIIlIlllIIlI(String lllllllllllllllIllllIllIlIIllIlI, String lllllllllllllllIllllIllIlIIllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIllIlIIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIlIIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIllIlIIlllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIllIlIIlllII.init(lIllIlIIllIIII[2], lllllllllllllllIllllIllIlIIlllIl);
      return new String(lllllllllllllllIllllIllIlIIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIllIlIIllIll) {
      lllllllllllllllIllllIllIlIIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlIlllllIl() {
    lIllIlIIllIIII = new int[16];
    lIllIlIIllIIII[0] = (0x23 ^ 0x2A) << " ".length() << " ".length() & ((0x55 ^ 0x5C) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIllIlIIllIIII[1] = " ".length();
    lIllIlIIllIIII[2] = " ".length() << " ".length();
    lIllIlIIllIIII[3] = "   ".length();
    lIllIlIIllIIII[4] = " ".length() << " ".length() << " ".length();
    lIllIlIIllIIII[5] = 0x16 ^ 0x13;
    lIllIlIIllIIII[6] = 0x9A ^ 0x9D;
    lIllIlIIllIIII[7] = "   ".length() << " ".length();
    lIllIlIIllIIII[8] = " ".length() << "   ".length();
    lIllIlIIllIIII[9] = (0x7F ^ 0x54) << " ".length() << " ".length() ^ 156 + 9 - 101 + 101;
    lIllIlIIllIIII[10] = (0x62 ^ 0x67) << " ".length();
    lIllIlIIllIIII[11] = (0x39 ^ 0x3E) << " ".length() << " ".length() ^ 0x4A ^ 0x5D;
    lIllIlIIllIIII[12] = "   ".length() << " ".length() << " ".length();
    lIllIlIIllIIII[13] = (0x7F ^ 0x6A) << "   ".length() ^ 15 + 97 - 14 + 67;
    lIllIlIIllIIII[14] = (0x27 ^ 0x20) << " ".length();
    lIllIlIIllIIII[15] = 0xB6 ^ 0xB9;
  }
  
  private static boolean llllIIlIlllllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIllIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIllIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIIlIllllllI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */