package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ff extends fh {
  private static String[] lIllllIlIlIlII;
  
  private static Class[] lIllllIlIlIlIl;
  
  private static final String[] lIllllIlIlIllI;
  
  private static String[] lIllllIlIlIlll;
  
  private static final int[] lIllllIlIllIII;
  
  public ff() {
    super(lIllllIlIlIllI[lIllllIlIllIII[0]], lIllllIlIlIllI[lIllllIlIllIII[1]], lIllllIlIlIllI[lIllllIlIllIII[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIlllIIlIIllllIIlI) {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   5: iconst_1
    //   6: iaload
    //   7: invokestatic lllllllIIIlIlII : (II)Z
    //   10: ifeq -> 248
    //   13: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f9;
    //   18: aload_1
    //   19: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   22: iconst_1
    //   23: iaload
    //   24: aaload
    //   25: <illegal opcode> 1 : (Lme/stupitdog/bhp/f9;Ljava/lang/String;)V
    //   30: new java/lang/StringBuilder
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: getstatic me/stupitdog/bhp/ff.lIllllIlIlIllI : [Ljava/lang/String;
    //   40: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   43: iconst_3
    //   44: iaload
    //   45: aaload
    //   46: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: aload_1
    //   52: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   55: iconst_1
    //   56: iaload
    //   57: aaload
    //   58: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   68: <illegal opcode> 4 : (Ljava/lang/String;)V
    //   73: new java/lang/StringBuilder
    //   76: dup
    //   77: invokespecial <init> : ()V
    //   80: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f9;
    //   85: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Ljava/lang/String;
    //   90: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: getstatic me/stupitdog/bhp/ff.lIllllIlIlIllI : [Ljava/lang/String;
    //   98: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   101: iconst_4
    //   102: iaload
    //   103: aaload
    //   104: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   114: <illegal opcode> 6 : (Ljava/lang/String;)V
    //   119: ldc ''
    //   121: invokevirtual length : ()I
    //   124: pop
    //   125: ldc ' '
    //   127: invokevirtual length : ()I
    //   130: ldc ' '
    //   132: invokevirtual length : ()I
    //   135: ldc ' '
    //   137: invokevirtual length : ()I
    //   140: ishl
    //   141: ishl
    //   142: ldc ' '
    //   144: invokevirtual length : ()I
    //   147: ldc ' '
    //   149: invokevirtual length : ()I
    //   152: ldc ' '
    //   154: invokevirtual length : ()I
    //   157: ishl
    //   158: ishl
    //   159: if_icmpge -> 262
    //   162: return
    //   163: astore_2
    //   164: ldc ''
    //   166: invokevirtual length : ()I
    //   169: pop
    //   170: ldc ' '
    //   172: invokevirtual length : ()I
    //   175: ineg
    //   176: sipush #220
    //   179: sipush #137
    //   182: ixor
    //   183: bipush #100
    //   185: bipush #73
    //   187: ixor
    //   188: ldc ' '
    //   190: invokevirtual length : ()I
    //   193: ishl
    //   194: ixor
    //   195: ldc ' '
    //   197: invokevirtual length : ()I
    //   200: ldc ' '
    //   202: invokevirtual length : ()I
    //   205: ishl
    //   206: ishl
    //   207: bipush #11
    //   209: bipush #12
    //   211: ixor
    //   212: ldc ' '
    //   214: invokevirtual length : ()I
    //   217: ishl
    //   218: ldc ' '
    //   220: invokevirtual length : ()I
    //   223: ixor
    //   224: ldc ' '
    //   226: invokevirtual length : ()I
    //   229: ldc ' '
    //   231: invokevirtual length : ()I
    //   234: ishl
    //   235: ishl
    //   236: ldc ' '
    //   238: invokevirtual length : ()I
    //   241: ineg
    //   242: ixor
    //   243: iand
    //   244: if_icmpne -> 262
    //   247: return
    //   248: getstatic me/stupitdog/bhp/ff.lIllllIlIlIllI : [Ljava/lang/String;
    //   251: getstatic me/stupitdog/bhp/ff.lIllllIlIllIII : [I
    //   254: iconst_5
    //   255: iaload
    //   256: aaload
    //   257: <illegal opcode> 7 : (Ljava/lang/String;)V
    //   262: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	263	0	lllllllllllllllIlllIIlIIllllIIll	Lme/stupitdog/bhp/ff;
    //   0	263	1	lllllllllllllllIlllIIlIIllllIIlI	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   13	119	163	java/lang/Exception
  }
  
  static {
    lllllllIIIlIIll();
    lllllllIIIlIIlI();
    lllllllIIIlIIIl();
    lllllllIIIIllIl();
  }
  
  private static CallSite lllllllIIIIllII(MethodHandles.Lookup lllllllllllllllIlllIIlIIlllIlIIl, String lllllllllllllllIlllIIlIIlllIlIII, MethodType lllllllllllllllIlllIIlIIlllIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIIlllIllll = lIllllIlIlIlII[Integer.parseInt(lllllllllllllllIlllIIlIIlllIlIII)].split(lIllllIlIlIllI[lIllllIlIllIII[6]]);
      Class<?> lllllllllllllllIlllIIlIIlllIlllI = Class.forName(lllllllllllllllIlllIIlIIlllIllll[lIllllIlIllIII[0]]);
      String lllllllllllllllIlllIIlIIlllIllIl = lllllllllllllllIlllIIlIIlllIllll[lIllllIlIllIII[1]];
      MethodHandle lllllllllllllllIlllIIlIIlllIllII = null;
      int lllllllllllllllIlllIIlIIlllIlIll = lllllllllllllllIlllIIlIIlllIllll[lIllllIlIllIII[3]].length();
      if (lllllllIIIlIlIl(lllllllllllllllIlllIIlIIlllIlIll, lIllllIlIllIII[2])) {
        MethodType lllllllllllllllIlllIIlIIllllIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIIlllIllll[lIllllIlIllIII[2]], ff.class.getClassLoader());
        if (lllllllIIIlIllI(lllllllllllllllIlllIIlIIlllIlIll, lIllllIlIllIII[2])) {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findVirtual(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIIl);
          "".length();
          if (-" ".length() == " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findStatic(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIIl);
        } 
        "".length();
        if (" ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIIllllIIII = lIllllIlIlIlIl[Integer.parseInt(lllllllllllllllIlllIIlIIlllIllll[lIllllIlIllIII[2]])];
        if (lllllllIIIlIllI(lllllllllllllllIlllIIlIIlllIlIll, lIllllIlIllIII[3])) {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findGetter(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() == ((0xD0 ^ 0xC3) & (0x1D ^ 0xE ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllllIIIlIllI(lllllllllllllllIlllIIlIIlllIlIll, lIllllIlIllIII[4])) {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findStaticGetter(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIII);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (lllllllIIIlIllI(lllllllllllllllIlllIIlIIlllIlIll, lIllllIlIllIII[5])) {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findSetter(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIII);
          "".length();
          if (" ".length() << " ".length() == " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIIlllIllII = lllllllllllllllIlllIIlIIlllIlIIl.findStaticSetter(lllllllllllllllIlllIIlIIlllIlllI, lllllllllllllllIlllIIlIIlllIllIl, lllllllllllllllIlllIIlIIllllIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIIlllIllII);
    } catch (Exception lllllllllllllllIlllIIlIIlllIlIlI) {
      lllllllllllllllIlllIIlIIlllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIIIIllIl() {
    lIllllIlIlIlII = new String[lIllllIlIllIII[7]];
    lIllllIlIlIlII[lIllllIlIllIII[0]] = lIllllIlIlIllI[lIllllIlIllIII[8]];
    lIllllIlIlIlII[lIllllIlIllIII[6]] = lIllllIlIlIllI[lIllllIlIllIII[7]];
    lIllllIlIlIlII[lIllllIlIllIII[8]] = lIllllIlIlIllI[lIllllIlIllIII[9]];
    lIllllIlIlIlII[lIllllIlIllIII[1]] = lIllllIlIlIllI[lIllllIlIllIII[10]];
    lIllllIlIlIlII[lIllllIlIllIII[4]] = lIllllIlIlIllI[lIllllIlIllIII[11]];
    lIllllIlIlIlII[lIllllIlIllIII[5]] = lIllllIlIlIllI[lIllllIlIllIII[12]];
    lIllllIlIlIlII[lIllllIlIllIII[3]] = lIllllIlIlIllI[lIllllIlIllIII[13]];
    lIllllIlIlIlII[lIllllIlIllIII[2]] = lIllllIlIlIllI[lIllllIlIllIII[14]];
    lIllllIlIlIlIl = new Class[lIllllIlIllIII[2]];
    lIllllIlIlIlIl[lIllllIlIllIII[1]] = String.class;
    lIllllIlIlIlIl[lIllllIlIllIII[0]] = f9.class;
  }
  
  private static void lllllllIIIlIIIl() {
    lIllllIlIlIllI = new String[lIllllIlIllIII[15]];
    lIllllIlIlIllI[lIllllIlIllIII[0]] = lllllllIIIIlllI(lIllllIlIlIlll[lIllllIlIllIII[0]], lIllllIlIlIlll[lIllllIlIllIII[1]]);
    lIllllIlIlIllI[lIllllIlIllIII[1]] = lllllllIIIIllll(lIllllIlIlIlll[lIllllIlIllIII[2]], lIllllIlIlIlll[lIllllIlIllIII[3]]);
    lIllllIlIlIllI[lIllllIlIllIII[2]] = lllllllIIIlIIII(lIllllIlIlIlll[lIllllIlIllIII[4]], lIllllIlIlIlll[lIllllIlIllIII[5]]);
    lIllllIlIlIllI[lIllllIlIllIII[3]] = lllllllIIIIlllI(lIllllIlIlIlll[lIllllIlIllIII[6]], lIllllIlIlIlll[lIllllIlIllIII[8]]);
    lIllllIlIlIllI[lIllllIlIllIII[4]] = lllllllIIIlIIII(lIllllIlIlIlll[lIllllIlIllIII[7]], lIllllIlIlIlll[lIllllIlIllIII[9]]);
    lIllllIlIlIllI[lIllllIlIllIII[5]] = lllllllIIIIllll(lIllllIlIlIlll[lIllllIlIllIII[10]], lIllllIlIlIlll[lIllllIlIllIII[11]]);
    lIllllIlIlIllI[lIllllIlIllIII[6]] = lllllllIIIIlllI(lIllllIlIlIlll[lIllllIlIllIII[12]], lIllllIlIlIlll[lIllllIlIllIII[13]]);
    lIllllIlIlIllI[lIllllIlIllIII[8]] = lllllllIIIlIIII(lIllllIlIlIlll[lIllllIlIllIII[14]], lIllllIlIlIlll[lIllllIlIllIII[15]]);
    lIllllIlIlIllI[lIllllIlIllIII[7]] = lllllllIIIIlllI(lIllllIlIlIlll[lIllllIlIllIII[16]], lIllllIlIlIlll[lIllllIlIllIII[17]]);
    lIllllIlIlIllI[lIllllIlIllIII[9]] = lllllllIIIIlllI(lIllllIlIlIlll[lIllllIlIllIII[18]], lIllllIlIlIlll[lIllllIlIllIII[19]]);
    lIllllIlIlIllI[lIllllIlIllIII[10]] = lllllllIIIIlllI("CSGmK40uFkCmzoknbo7XlmdI1HxnJMd6rGWBANG6ZQDKeQEcDSvijQ==", "omtSs");
    lIllllIlIlIllI[lIllllIlIllIII[11]] = lllllllIIIlIIII("LBxKJQQ0CQ0iFC4eSjQYMVcFIkoyHAoyPTQVED88KBcBGwMmQ0waGiAPBXkcIBcDeSM1Cw04F3pQMmxQ", "AydVp");
    lIllllIlIlIllI[lIllllIlIllIII[12]] = lllllllIIIlIIII("HQZJMh8FEw41Dx8ESSMDAE0BeFETDw4kBQQNBiwOSlJdYUtQ", "pcgAk");
    lIllllIlIlIllI[lIllllIlIllIII[13]] = lllllllIIIIllll("TWiIJ2QtR2aNX+HLcyEnxS612JFfgb7ojJYXumZWxaAbIQ2pdnKHsw9PSSVt0+T0PwlECotCec3t0mmkAiykSg==", "ykFEX");
    lIllllIlIlIllI[lIllllIlIllIII[14]] = lllllllIIIlIIII("JCs4NHgiKyAyeB0+PDw4KQg7PDoqLzxvNz46KzsydGICPzc4K2E5NyAtYQYiPCMgMm1nBiQ0IC9lIjQ4KWUdISQnJCkXIycmKjAkdXBudQ==", "NJNUV");
    lIllllIlIlIlll = null;
  }
  
  private static void lllllllIIIlIIlI() {
    String str = (new Exception()).getStackTrace()[lIllllIlIllIII[0]].getFileName();
    lIllllIlIlIlll = str.substring(str.indexOf("ä") + lIllllIlIllIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIIIlIIII(String lllllllllllllllIlllIIlIIlllIIlIl, String lllllllllllllllIlllIIlIIlllIIlII) {
    lllllllllllllllIlllIIlIIlllIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIlllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIIlllIIIll = new StringBuilder();
    char[] lllllllllllllllIlllIIlIIlllIIIlI = lllllllllllllllIlllIIlIIlllIIlII.toCharArray();
    int lllllllllllllllIlllIIlIIlllIIIIl = lIllllIlIllIII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIIlllIIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlIllIII[0];
    while (lllllllIIIlIlll(j, i)) {
      char lllllllllllllllIlllIIlIIlllIIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIIlllIIIIl++;
      j++;
      "".length();
      if (" ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIIlllIIIll);
  }
  
  private static String lllllllIIIIlllI(String lllllllllllllllIlllIIlIIllIlllIl, String lllllllllllllllIlllIIlIIllIlllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIlllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIllIlllII.getBytes(StandardCharsets.UTF_8)), lIllllIlIllIII[7]), "DES");
      Cipher lllllllllllllllIlllIIlIIllIlllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIIllIlllll.init(lIllllIlIllIII[2], lllllllllllllllIlllIIlIIlllIIIII);
      return new String(lllllllllllllllIlllIIlIIllIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIllIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIllIllllI) {
      lllllllllllllllIlllIIlIIllIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIIIIllll(String lllllllllllllllIlllIIlIIllIllIII, String lllllllllllllllIlllIIlIIllIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIllIllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIllIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIIllIllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIIllIllIlI.init(lIllllIlIllIII[2], lllllllllllllllIlllIIlIIllIllIll);
      return new String(lllllllllllllllIlllIIlIIllIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIllIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIllIllIIl) {
      lllllllllllllllIlllIIlIIllIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIIIlIIll() {
    lIllllIlIllIII = new int[20];
    lIllllIlIllIII[0] = (0x9F ^ 0xB4) & (0xA9 ^ 0x82 ^ 0xFFFFFFFF);
    lIllllIlIllIII[1] = " ".length();
    lIllllIlIllIII[2] = " ".length() << " ".length();
    lIllllIlIllIII[3] = "   ".length();
    lIllllIlIllIII[4] = " ".length() << " ".length() << " ".length();
    lIllllIlIllIII[5] = 44 + 70 - -5 + 50 ^ (0x6D ^ 0x46) << " ".length() << " ".length();
    lIllllIlIllIII[6] = "   ".length() << " ".length();
    lIllllIlIllIII[7] = " ".length() << "   ".length();
    lIllllIlIllIII[8] = (0xAA ^ 0x9B) << " ".length() << " ".length() ^ 123 + 14 - 117 + 175;
    lIllllIlIllIII[9] = (0x1B ^ 0x3A) << " ".length() << " ".length() ^ 88 + 92 - 50 + 11;
    lIllllIlIllIII[10] = (0xA6 ^ 0xA3) << " ".length();
    lIllllIlIllIII[11] = (0x34 ^ 0x1F) << " ".length() ^ 0x9E ^ 0xC3;
    lIllllIlIllIII[12] = "   ".length() << " ".length() << " ".length();
    lIllllIlIllIII[13] = 0x2B ^ 0x26;
    lIllllIlIllIII[14] = (0xF ^ 0x8) << " ".length();
    lIllllIlIllIII[15] = 0x9E ^ 0x91;
    lIllllIlIllIII[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIlIllIII[17] = (0x7D ^ 0x76) << " ".length() << " ".length() ^ 0x87 ^ 0xBA;
    lIllllIlIllIII[18] = (0x5B ^ 0x52) << " ".length();
    lIllllIlIllIII[19] = (0x49 ^ 0x62) << " ".length() ^ 0x82 ^ 0xC7;
  }
  
  private static boolean lllllllIIIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIIIlIlll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIIIlIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllIIIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ff.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */