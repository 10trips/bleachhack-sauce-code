package me.stupitdog.bhp;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.CollapsibleContainer;
import com.lukflug.panelstudio.DraggableContainer;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.hud.HUDClickGUI;
import com.lukflug.panelstudio.mc12.MinecraftGUI;
import com.lukflug.panelstudio.mc12.MinecraftHUDGUI;
import com.lukflug.panelstudio.settings.AnimatedToggleable;
import com.lukflug.panelstudio.settings.Toggleable;
import com.lukflug.panelstudio.theme.DescriptionRenderer;
import com.lukflug.panelstudio.theme.Renderer;
import com.lukflug.panelstudio.theme.Theme;
import java.awt.Color;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fd extends MinecraftHUDGUI {
  public static final int WIDTH;
  
  public static final int HEIGHT;
  
  public static final int DISTANCE = lIlllIIlllIIIl[1];
  
  public static final int HUD_BORDER;
  
  private final Toggleable colorToggle;
  
  public final MinecraftGUI.GUIInterface guiInterface;
  
  private final Theme theme;
  
  public final HUDClickGUI gui;
  
  private static String[] lIlllIIllIllIl;
  
  private static Class[] lIlllIIllIlllI;
  
  private static final String[] lIlllIIllIllll;
  
  private static String[] lIlllIIlllIIII;
  
  private static final int[] lIlllIIlllIIIl;
  
  public fd() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new me/stupitdog/bhp/fd$1
    //   8: dup
    //   9: aload_0
    //   10: invokespecial <init> : (Lme/stupitdog/bhp/fd;)V
    //   13: putfield colorToggle : Lcom/lukflug/panelstudio/settings/Toggleable;
    //   16: aload_0
    //   17: new me/stupitdog/bhp/fd$2
    //   20: dup
    //   21: aload_0
    //   22: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   25: iconst_0
    //   26: iaload
    //   27: invokespecial <init> : (Lme/stupitdog/bhp/fd;Z)V
    //   30: putfield guiInterface : Lcom/lukflug/panelstudio/mc12/MinecraftGUI$GUIInterface;
    //   33: aload_0
    //   34: new com/lukflug/panelstudio/theme/GameSenseTheme
    //   37: dup
    //   38: new com/lukflug/panelstudio/theme/SettingsColorScheme
    //   41: dup
    //   42: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   47: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   52: <illegal opcode> 2 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   57: <illegal opcode> 3 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   62: <illegal opcode> 4 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   67: <illegal opcode> 5 : ()Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   72: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorSetting;Lcom/lukflug/panelstudio/settings/ColorSetting;Lcom/lukflug/panelstudio/settings/ColorSetting;Lcom/lukflug/panelstudio/settings/ColorSetting;Lcom/lukflug/panelstudio/settings/ColorSetting;Lcom/lukflug/panelstudio/settings/NumberSetting;)V
    //   75: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   78: iconst_1
    //   79: iaload
    //   80: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   83: iconst_2
    //   84: iaload
    //   85: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   88: iconst_1
    //   89: iaload
    //   90: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/ColorScheme;III)V
    //   93: putfield theme : Lcom/lukflug/panelstudio/theme/Theme;
    //   96: aload_0
    //   97: new me/stupitdog/bhp/fd$3
    //   100: dup
    //   101: aload_0
    //   102: aload_0
    //   103: <illegal opcode> 6 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/mc12/MinecraftGUI$GUIInterface;
    //   108: aconst_null
    //   109: invokespecial <init> : (Lme/stupitdog/bhp/fd;Lcom/lukflug/panelstudio/Interface;Lcom/lukflug/panelstudio/theme/DescriptionRenderer;)V
    //   112: putfield gui : Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   115: new java/awt/Point
    //   118: dup
    //   119: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   122: iconst_1
    //   123: iaload
    //   124: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   127: iconst_1
    //   128: iaload
    //   129: invokespecial <init> : (II)V
    //   132: astore_1
    //   133: <illegal opcode> 7 : ()[Lme/stupitdog/bhp/f13;
    //   138: astore_2
    //   139: aload_2
    //   140: arraylength
    //   141: istore_3
    //   142: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   145: iconst_3
    //   146: iaload
    //   147: istore #4
    //   149: iload #4
    //   151: iload_3
    //   152: invokestatic lllllIIlIlIlIlI : (II)Z
    //   155: ifeq -> 434
    //   158: aload_2
    //   159: iload #4
    //   161: aaload
    //   162: astore #5
    //   164: new me/stupitdog/bhp/fd$4
    //   167: dup
    //   168: aload_0
    //   169: new java/lang/StringBuilder
    //   172: dup
    //   173: invokespecial <init> : ()V
    //   176: aload #5
    //   178: <illegal opcode> 8 : (Lme/stupitdog/bhp/f13;)Ljava/lang/String;
    //   183: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   186: iconst_3
    //   187: iaload
    //   188: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   191: iconst_0
    //   192: iaload
    //   193: <illegal opcode> 9 : (Ljava/lang/String;II)Ljava/lang/String;
    //   198: <illegal opcode> 10 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: aload #5
    //   205: <illegal opcode> 8 : (Lme/stupitdog/bhp/f13;)Ljava/lang/String;
    //   210: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   213: iconst_0
    //   214: iaload
    //   215: <illegal opcode> 11 : (Ljava/lang/String;I)Ljava/lang/String;
    //   220: <illegal opcode> 12 : (Ljava/lang/String;)Ljava/lang/String;
    //   225: <illegal opcode> 10 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   230: <illegal opcode> 13 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   235: aconst_null
    //   236: aload_0
    //   237: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   242: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   247: new com/lukflug/panelstudio/settings/SimpleToggleable
    //   250: dup
    //   251: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   254: iconst_3
    //   255: iaload
    //   256: invokespecial <init> : (Z)V
    //   259: new com/lukflug/panelstudio/SettingsAnimation
    //   262: dup
    //   263: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   268: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/NumberSetting;)V
    //   271: aconst_null
    //   272: new java/awt/Point
    //   275: dup
    //   276: aload_1
    //   277: invokespecial <init> : (Ljava/awt/Point;)V
    //   280: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   283: iconst_4
    //   284: iaload
    //   285: invokespecial <init> : (Lme/stupitdog/bhp/fd;Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;Lcom/lukflug/panelstudio/Animation;Lcom/lukflug/panelstudio/settings/Toggleable;Ljava/awt/Point;I)V
    //   288: astore #6
    //   290: aload_0
    //   291: <illegal opcode> 17 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   296: aload #6
    //   298: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;Lcom/lukflug/panelstudio/FixedComponent;)V
    //   303: aload_1
    //   304: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   307: iconst_5
    //   308: iaload
    //   309: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   312: iconst_3
    //   313: iaload
    //   314: <illegal opcode> 19 : (Ljava/awt/Point;II)V
    //   319: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   324: <illegal opcode> 21 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   329: aload #5
    //   331: <illegal opcode> 22 : (Lme/stupitdog/bhp/av;Lme/stupitdog/bhp/f13;)Ljava/util/ArrayList;
    //   336: <illegal opcode> 23 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   341: astore #7
    //   343: aload #7
    //   345: <illegal opcode> 24 : (Ljava/util/Iterator;)Z
    //   350: invokestatic lllllIIlIlIlIll : (I)Z
    //   353: ifeq -> 419
    //   356: aload #7
    //   358: <illegal opcode> 25 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   363: checkcast me/stupitdog/bhp/au
    //   366: astore #8
    //   368: aload_0
    //   369: aload #6
    //   371: aload #8
    //   373: invokespecial addModule : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lme/stupitdog/bhp/au;)V
    //   376: ldc ''
    //   378: invokevirtual length : ()I
    //   381: pop
    //   382: ldc '   '
    //   384: invokevirtual length : ()I
    //   387: ldc '   '
    //   389: invokevirtual length : ()I
    //   392: sipush #150
    //   395: sipush #147
    //   398: ixor
    //   399: ishl
    //   400: ldc '   '
    //   402: invokevirtual length : ()I
    //   405: bipush #121
    //   407: bipush #124
    //   409: ixor
    //   410: ishl
    //   411: iconst_m1
    //   412: ixor
    //   413: iand
    //   414: if_icmpne -> 343
    //   417: aconst_null
    //   418: athrow
    //   419: iinc #4, 1
    //   422: ldc ''
    //   424: invokevirtual length : ()I
    //   427: pop
    //   428: aconst_null
    //   429: ifnull -> 149
    //   432: aconst_null
    //   433: athrow
    //   434: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   368	8	8	lllllllllllllllIlllIllIIllIlIIlI	Lme/stupitdog/bhp/au;
    //   290	129	6	lllllllllllllllIlllIllIIllIlIIIl	Lcom/lukflug/panelstudio/DraggableContainer;
    //   164	255	5	lllllllllllllllIlllIllIIllIlIIII	Lme/stupitdog/bhp/f13;
    //   0	435	0	lllllllllllllllIlllIllIIllIIllll	Lme/stupitdog/bhp/fd;
    //   133	302	1	lllllllllllllllIlllIllIIllIIlllI	Ljava/awt/Point;
  }
  
  private void addModule(CollapsibleContainer lllllllllllllllIlllIllIIllIIlIll, au lllllllllllllllIlllIllIIllIIlIlI) {
    // Byte code:
    //   0: new com/lukflug/panelstudio/CollapsibleContainer
    //   3: dup
    //   4: aload_2
    //   5: <illegal opcode> 26 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   10: aload_2
    //   11: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   16: aload_0
    //   17: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   22: <illegal opcode> 28 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   27: new com/lukflug/panelstudio/settings/SimpleToggleable
    //   30: dup
    //   31: getstatic me/stupitdog/bhp/fd.lIlllIIlllIIIl : [I
    //   34: iconst_3
    //   35: iaload
    //   36: invokespecial <init> : (Z)V
    //   39: new com/lukflug/panelstudio/SettingsAnimation
    //   42: dup
    //   43: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   48: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/NumberSetting;)V
    //   51: aload_2
    //   52: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;Lcom/lukflug/panelstudio/Animation;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   55: astore_3
    //   56: aload_1
    //   57: aload_3
    //   58: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   63: aload_3
    //   64: new me/stupitdog/bhp/f02
    //   67: dup
    //   68: aload_0
    //   69: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   74: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   79: aload_2
    //   80: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/KeybindSetting;)V
    //   83: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   88: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   93: <illegal opcode> 31 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   98: aload_2
    //   99: <illegal opcode> 32 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/au;)Ljava/util/List;
    //   104: <illegal opcode> 33 : (Ljava/util/List;)Ljava/util/Iterator;
    //   109: astore #4
    //   111: aload #4
    //   113: <illegal opcode> 24 : (Ljava/util/Iterator;)Z
    //   118: invokestatic lllllIIlIlIlIll : (I)Z
    //   121: ifeq -> 611
    //   124: aload #4
    //   126: <illegal opcode> 25 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   131: checkcast me/stupitdog/bhp/f100000000000000000000
    //   134: astore #5
    //   136: aload #5
    //   138: instanceof me/stupitdog/bhp/f100000000000000000000$Boolean
    //   141: invokestatic lllllIIlIlIlIll : (I)Z
    //   144: ifeq -> 204
    //   147: aload_3
    //   148: new com/lukflug/panelstudio/settings/BooleanComponent
    //   151: dup
    //   152: aload #5
    //   154: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000;)Ljava/lang/String;
    //   159: aconst_null
    //   160: aload_0
    //   161: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   166: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   171: aload #5
    //   173: checkcast me/stupitdog/bhp/f100000000000000000000$Boolean
    //   176: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   179: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   184: ldc ''
    //   186: invokevirtual length : ()I
    //   189: pop
    //   190: ldc '   '
    //   192: invokevirtual length : ()I
    //   195: ldc '   '
    //   197: invokevirtual length : ()I
    //   200: if_icmpeq -> 576
    //   203: return
    //   204: aload #5
    //   206: instanceof me/stupitdog/bhp/f100000000000000000000$Integer
    //   209: invokestatic lllllIIlIlIlIll : (I)Z
    //   212: ifeq -> 289
    //   215: aload_3
    //   216: new com/lukflug/panelstudio/settings/NumberComponent
    //   219: dup
    //   220: aload #5
    //   222: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000;)Ljava/lang/String;
    //   227: aconst_null
    //   228: aload_0
    //   229: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   234: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   239: aload #5
    //   241: checkcast me/stupitdog/bhp/f100000000000000000000$Integer
    //   244: aload #5
    //   246: checkcast me/stupitdog/bhp/f100000000000000000000$Integer
    //   249: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   254: i2d
    //   255: aload #5
    //   257: checkcast me/stupitdog/bhp/f100000000000000000000$Integer
    //   260: <illegal opcode> 36 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   265: i2d
    //   266: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/NumberSetting;DD)V
    //   269: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   274: ldc ''
    //   276: invokevirtual length : ()I
    //   279: pop
    //   280: ldc '   '
    //   282: invokevirtual length : ()I
    //   285: ifne -> 576
    //   288: return
    //   289: aload #5
    //   291: instanceof me/stupitdog/bhp/f100000000000000000000$Double
    //   294: invokestatic lllllIIlIlIlIll : (I)Z
    //   297: ifeq -> 451
    //   300: aload_3
    //   301: new com/lukflug/panelstudio/settings/NumberComponent
    //   304: dup
    //   305: aload #5
    //   307: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000;)Ljava/lang/String;
    //   312: aconst_null
    //   313: aload_0
    //   314: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   319: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   324: aload #5
    //   326: checkcast me/stupitdog/bhp/f100000000000000000000$Double
    //   329: aload #5
    //   331: checkcast me/stupitdog/bhp/f100000000000000000000$Double
    //   334: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   339: aload #5
    //   341: checkcast me/stupitdog/bhp/f100000000000000000000$Double
    //   344: <illegal opcode> 38 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   349: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/NumberSetting;DD)V
    //   352: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   357: ldc ''
    //   359: invokevirtual length : ()I
    //   362: pop
    //   363: ldc_w ' '
    //   366: invokevirtual length : ()I
    //   369: sipush #188
    //   372: sipush #181
    //   375: ixor
    //   376: ldc '   '
    //   378: invokevirtual length : ()I
    //   381: ishl
    //   382: ixor
    //   383: sipush #146
    //   386: sipush #159
    //   389: ixor
    //   390: ldc_w ' '
    //   393: invokevirtual length : ()I
    //   396: ishl
    //   397: sipush #201
    //   400: sipush #154
    //   403: ixor
    //   404: ixor
    //   405: ldc_w ' '
    //   408: invokevirtual length : ()I
    //   411: ineg
    //   412: ixor
    //   413: iand
    //   414: ldc '   '
    //   416: invokevirtual length : ()I
    //   419: ldc_w ' '
    //   422: invokevirtual length : ()I
    //   425: ishl
    //   426: ldc '   '
    //   428: invokevirtual length : ()I
    //   431: ldc_w ' '
    //   434: invokevirtual length : ()I
    //   437: ishl
    //   438: ldc_w ' '
    //   441: invokevirtual length : ()I
    //   444: ineg
    //   445: ixor
    //   446: iand
    //   447: if_icmpeq -> 576
    //   450: return
    //   451: aload #5
    //   453: instanceof me/stupitdog/bhp/f100000000000000000000$Mode
    //   456: invokestatic lllllIIlIlIlIll : (I)Z
    //   459: ifeq -> 523
    //   462: aload_3
    //   463: new com/lukflug/panelstudio/settings/EnumComponent
    //   466: dup
    //   467: aload #5
    //   469: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000;)Ljava/lang/String;
    //   474: aconst_null
    //   475: aload_0
    //   476: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   481: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   486: aload #5
    //   488: checkcast me/stupitdog/bhp/f100000000000000000000$Mode
    //   491: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/EnumSetting;)V
    //   494: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   499: ldc ''
    //   501: invokevirtual length : ()I
    //   504: pop
    //   505: ldc_w ' '
    //   508: invokevirtual length : ()I
    //   511: ineg
    //   512: ldc_w ' '
    //   515: invokevirtual length : ()I
    //   518: ineg
    //   519: if_icmpeq -> 576
    //   522: return
    //   523: aload #5
    //   525: instanceof me/stupitdog/bhp/f100000000000000000000$ColorSetting
    //   528: invokestatic lllllIIlIlIlIll : (I)Z
    //   531: ifeq -> 576
    //   534: aload_3
    //   535: new me/stupitdog/bhp/f10000000000000000000000000000000
    //   538: dup
    //   539: aload_0
    //   540: <illegal opcode> 14 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/theme/Theme;
    //   545: aload #5
    //   547: checkcast me/stupitdog/bhp/f100000000000000000000$ColorSetting
    //   550: aload_0
    //   551: <illegal opcode> 39 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   556: new com/lukflug/panelstudio/SettingsAnimation
    //   559: dup
    //   560: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   565: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/NumberSetting;)V
    //   568: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/Theme;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;Lcom/lukflug/panelstudio/settings/Toggleable;Lcom/lukflug/panelstudio/Animation;)V
    //   571: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/CollapsibleContainer;Lcom/lukflug/panelstudio/Component;)V
    //   576: ldc ''
    //   578: invokevirtual length : ()I
    //   581: pop
    //   582: bipush #99
    //   584: bipush #14
    //   586: iadd
    //   587: bipush #-35
    //   589: isub
    //   590: bipush #25
    //   592: iadd
    //   593: sipush #209
    //   596: sipush #196
    //   599: ixor
    //   600: ldc '   '
    //   602: invokevirtual length : ()I
    //   605: ishl
    //   606: ixor
    //   607: ifgt -> 111
    //   610: return
    //   611: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   136	440	5	lllllllllllllllIlllIllIIllIIllIl	Lme/stupitdog/bhp/f100000000000000000000;
    //   0	612	0	lllllllllllllllIlllIllIIllIIllII	Lme/stupitdog/bhp/fd;
    //   0	612	1	lllllllllllllllIlllIllIIllIIlIll	Lcom/lukflug/panelstudio/CollapsibleContainer;
    //   0	612	2	lllllllllllllllIlllIllIIllIIlIlI	Lme/stupitdog/bhp/au;
    //   56	556	3	lllllllllllllllIlllIllIIllIIlIIl	Lcom/lukflug/panelstudio/CollapsibleContainer;
  }
  
  protected HUDClickGUI getHUDGUI() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 17 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIllIIllIIlIII	Lme/stupitdog/bhp/fd;
  }
  
  protected MinecraftGUI.GUIInterface getInterface() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lme/stupitdog/bhp/fd;)Lcom/lukflug/panelstudio/mc12/MinecraftGUI$GUIInterface;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIllIIllIIIlll	Lme/stupitdog/bhp/fd;
  }
  
  protected int getScrollSpeed() {
    // Byte code:
    //   0: <illegal opcode> 40 : ()Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   5: <illegal opcode> 41 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   10: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	11	0	lllllllllllllllIlllIllIIllIIIllI	Lme/stupitdog/bhp/fd;
  }
  
  static {
    WIDTH = lIlllIIlllIIIl[4];
    HEIGHT = lIlllIIlllIIIl[1];
    HUD_BORDER = lIlllIIlllIIIl[2];
  }
  
  private static CallSite lllllIIlIIllllI(MethodHandles.Lookup lllllllllllllllIlllIllIIlIllllIl, String lllllllllllllllIlllIllIIlIllllII, MethodType lllllllllllllllIlllIllIIlIlllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllIIllIIIIll = lIlllIIllIllIl[Integer.parseInt(lllllllllllllllIlllIllIIlIllllII)].split(lIlllIIllIllll[lIlllIIlllIIIl[3]]);
      Class<?> lllllllllllllllIlllIllIIllIIIIlI = Class.forName(lllllllllllllllIlllIllIIllIIIIll[lIlllIIlllIIIl[3]]);
      String lllllllllllllllIlllIllIIllIIIIIl = lllllllllllllllIlllIllIIllIIIIll[lIlllIIlllIIIl[0]];
      MethodHandle lllllllllllllllIlllIllIIllIIIIII = null;
      int lllllllllllllllIlllIllIIlIllllll = lllllllllllllllIlllIllIIllIIIIll[lIlllIIlllIIIl[6]].length();
      if (lllllIIlIlIllII(lllllllllllllllIlllIllIIlIllllll, lIlllIIlllIIIl[2])) {
        MethodType lllllllllllllllIlllIllIIllIIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllIIllIIIIll[lIlllIIlllIIIl[2]], fd.class.getClassLoader());
        if (lllllIIlIlIllIl(lllllllllllllllIlllIllIIlIllllll, lIlllIIlllIIIl[2])) {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findVirtual(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findStatic(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlIl);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllIIllIIIlII = lIlllIIllIlllI[Integer.parseInt(lllllllllllllllIlllIllIIllIIIIll[lIlllIIlllIIIl[2]])];
        if (lllllIIlIlIllIl(lllllllllllllllIlllIllIIlIllllll, lIlllIIlllIIIl[6])) {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findGetter(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlII);
          "".length();
          if (" ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lllllIIlIlIllIl(lllllllllllllllIlllIllIIlIllllll, lIlllIIlllIIIl[7])) {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findStaticGetter(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlII);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (lllllIIlIlIllIl(lllllllllllllllIlllIllIIlIllllll, lIlllIIlllIIIl[8])) {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findSetter(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIllIIllIIIIII = lllllllllllllllIlllIllIIlIllllIl.findStaticSetter(lllllllllllllllIlllIllIIllIIIIlI, lllllllllllllllIlllIllIIllIIIIIl, lllllllllllllllIlllIllIIllIIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllIIllIIIIII);
    } catch (Exception lllllllllllllllIlllIllIIlIlllllI) {
      lllllllllllllllIlllIllIIlIlllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlIIlllll() {
    lIlllIIllIllIl = new String[lIlllIIlllIIIl[9]];
    lIlllIIllIllIl[lIlllIIlllIIIl[10]] = lIlllIIllIllll[lIlllIIlllIIIl[0]];
    lIlllIIllIllIl[lIlllIIlllIIIl[11]] = lIlllIIllIllll[lIlllIIlllIIIl[2]];
    lIlllIIllIllIl[lIlllIIlllIIIl[12]] = lIlllIIllIllll[lIlllIIlllIIIl[6]];
    lIlllIIllIllIl[lIlllIIlllIIIl[13]] = lIlllIIllIllll[lIlllIIlllIIIl[7]];
    lIlllIIllIllIl[lIlllIIlllIIIl[14]] = lIlllIIllIllll[lIlllIIlllIIIl[8]];
    lIlllIIllIllIl[lIlllIIlllIIIl[15]] = lIlllIIllIllll[lIlllIIlllIIIl[16]];
    lIlllIIllIllIl[lIlllIIlllIIIl[17]] = lIlllIIllIllll[lIlllIIlllIIIl[18]];
    lIlllIIllIllIl[lIlllIIlllIIIl[19]] = lIlllIIllIllll[lIlllIIlllIIIl[20]];
    lIlllIIllIllIl[lIlllIIlllIIIl[16]] = lIlllIIllIllll[lIlllIIlllIIIl[21]];
    lIlllIIllIllIl[lIlllIIlllIIIl[22]] = lIlllIIllIllll[lIlllIIlllIIIl[1]];
    lIlllIIllIllIl[lIlllIIlllIIIl[7]] = lIlllIIllIllll[lIlllIIlllIIIl[19]];
    lIlllIIllIllIl[lIlllIIlllIIIl[23]] = lIlllIIllIllll[lIlllIIlllIIIl[12]];
    lIlllIIllIllIl[lIlllIIlllIIIl[24]] = lIlllIIllIllll[lIlllIIlllIIIl[25]];
    lIlllIIllIllIl[lIlllIIlllIIIl[26]] = lIlllIIllIllll[lIlllIIlllIIIl[11]];
    lIlllIIllIllIl[lIlllIIlllIIIl[27]] = lIlllIIllIllll[lIlllIIlllIIIl[26]];
    lIlllIIllIllIl[lIlllIIlllIIIl[1]] = lIlllIIllIllll[lIlllIIlllIIIl[15]];
    lIlllIIllIllIl[lIlllIIlllIIIl[28]] = lIlllIIllIllll[lIlllIIlllIIIl[29]];
    lIlllIIllIllIl[lIlllIIlllIIIl[2]] = lIlllIIllIllll[lIlllIIlllIIIl[30]];
    lIlllIIllIllIl[lIlllIIlllIIIl[25]] = lIlllIIllIllll[lIlllIIlllIIIl[14]];
    lIlllIIllIllIl[lIlllIIlllIIIl[31]] = lIlllIIllIllll[lIlllIIlllIIIl[32]];
    lIlllIIllIllIl[lIlllIIlllIIIl[33]] = lIlllIIllIllll[lIlllIIlllIIIl[34]];
    lIlllIIllIllIl[lIlllIIlllIIIl[35]] = lIlllIIllIllll[lIlllIIlllIIIl[36]];
    lIlllIIllIllIl[lIlllIIlllIIIl[37]] = lIlllIIllIllll[lIlllIIlllIIIl[38]];
    lIlllIIllIllIl[lIlllIIlllIIIl[39]] = lIlllIIllIllll[lIlllIIlllIIIl[28]];
    lIlllIIllIllIl[lIlllIIlllIIIl[3]] = lIlllIIllIllll[lIlllIIlllIIIl[35]];
    lIlllIIllIllIl[lIlllIIlllIIIl[40]] = lIlllIIllIllll[lIlllIIlllIIIl[13]];
    lIlllIIllIllIl[lIlllIIlllIIIl[41]] = lIlllIIllIllll[lIlllIIlllIIIl[33]];
    lIlllIIllIllIl[lIlllIIlllIIIl[18]] = lIlllIIllIllll[lIlllIIlllIIIl[22]];
    lIlllIIllIllIl[lIlllIIlllIIIl[8]] = lIlllIIllIllll[lIlllIIlllIIIl[41]];
    lIlllIIllIllIl[lIlllIIlllIIIl[36]] = lIlllIIllIllll[lIlllIIlllIIIl[42]];
    lIlllIIllIllIl[lIlllIIlllIIIl[6]] = lIlllIIllIllll[lIlllIIlllIIIl[27]];
    lIlllIIllIllIl[lIlllIIlllIIIl[0]] = lIlllIIllIllll[lIlllIIlllIIIl[43]];
    lIlllIIllIllIl[lIlllIIlllIIIl[42]] = lIlllIIllIllll[lIlllIIlllIIIl[24]];
    lIlllIIllIllIl[lIlllIIlllIIIl[20]] = lIlllIIllIllll[lIlllIIlllIIIl[37]];
    lIlllIIllIllIl[lIlllIIlllIIIl[30]] = lIlllIIllIllll[lIlllIIlllIIIl[39]];
    lIlllIIllIllIl[lIlllIIlllIIIl[38]] = lIlllIIllIllll[lIlllIIlllIIIl[17]];
    lIlllIIllIllIl[lIlllIIlllIIIl[32]] = lIlllIIllIllll[lIlllIIlllIIIl[31]];
    lIlllIIllIllIl[lIlllIIlllIIIl[34]] = lIlllIIllIllll[lIlllIIlllIIIl[10]];
    lIlllIIllIllIl[lIlllIIlllIIIl[44]] = lIlllIIllIllll[lIlllIIlllIIIl[44]];
    lIlllIIllIllIl[lIlllIIlllIIIl[29]] = lIlllIIllIllll[lIlllIIlllIIIl[40]];
    lIlllIIllIllIl[lIlllIIlllIIIl[21]] = lIlllIIllIllll[lIlllIIlllIIIl[23]];
    lIlllIIllIllIl[lIlllIIlllIIIl[43]] = lIlllIIllIllll[lIlllIIlllIIIl[9]];
    lIlllIIllIlllI = new Class[lIlllIIlllIIIl[1]];
    lIlllIIllIlllI[lIlllIIlllIIIl[8]] = HUDClickGUI.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[16]] = f9.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[20]] = f1000000000000000000000.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[18]] = av.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[6]] = f100000000000000000000.Integer.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[21]] = int.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[0]] = MinecraftGUI.GUIInterface.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[3]] = Toggleable.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[2]] = f100000000000000000000.ColorSetting.class;
    lIlllIIllIlllI[lIlllIIlllIIIl[7]] = Theme.class;
  }
  
  private static void lllllIIlIlIIIll() {
    lIlllIIllIllll = new String[lIlllIIlllIIIl[45]];
    lIlllIIllIllll[lIlllIIlllIIIl[3]] = lllllIIlIlIIIII(lIlllIIlllIIII[lIlllIIlllIIIl[3]], lIlllIIlllIIII[lIlllIIlllIIIl[0]]);
    lIlllIIllIllll[lIlllIIlllIIIl[0]] = lllllIIlIlIIIII(lIlllIIlllIIII[lIlllIIlllIIIl[2]], lIlllIIlllIIII[lIlllIIlllIIIl[6]]);
    lIlllIIllIllll[lIlllIIlllIIIl[2]] = lllllIIlIlIIIII(lIlllIIlllIIII[lIlllIIlllIIIl[7]], lIlllIIlllIIII[lIlllIIlllIIIl[8]]);
    lIlllIIllIllll[lIlllIIlllIIIl[6]] = lllllIIlIlIIIIl(lIlllIIlllIIII[lIlllIIlllIIIl[16]], lIlllIIlllIIII[lIlllIIlllIIIl[18]]);
    lIlllIIllIllll[lIlllIIlllIIIl[7]] = lllllIIlIlIIIlI(lIlllIIlllIIII[lIlllIIlllIIIl[20]], lIlllIIlllIIII[lIlllIIlllIIIl[21]]);
    lIlllIIllIllll[lIlllIIlllIIIl[8]] = lllllIIlIlIIIII(lIlllIIlllIIII[lIlllIIlllIIIl[1]], lIlllIIlllIIII[lIlllIIlllIIIl[19]]);
    lIlllIIllIllll[lIlllIIlllIIIl[16]] = lllllIIlIlIIIlI(lIlllIIlllIIII[lIlllIIlllIIIl[12]], lIlllIIlllIIII[lIlllIIlllIIIl[25]]);
    lIlllIIllIllll[lIlllIIlllIIIl[18]] = lllllIIlIlIIIIl("Wu18ym3+hjhMXob1lkEBMfRyHIUf72gJrA5ZrVsA2H+hLeYoXL+VaHPT4tH0KuqCLfELV8mkRyLcebcKQtykYw==", "KStJZ");
    lIlllIIllIllll[lIlllIIlllIIIl[20]] = lllllIIlIlIIIlI("Phs5LWE4GyErYQcOPSUhM0A8OS0nDj0lITNAZwVmGBAuOi57Fi4iKHspOz4mOh10dm90", "TzOLO");
    lIlllIIllIllll[lIlllIIlllIIIl[21]] = lllllIIlIlIIIII("UD2pLPJO7JK2JHtCP6zy3nIo+MTu6m/3Q/dFxiiZCmmCe9+tetWq+Q==", "fqOBn");
    lIlllIIllIllll[lIlllIIlllIIIl[1]] = lllllIIlIlIIIlI("LCA+YyI6JDUhOyhhIywgKiMgOTsrJjxjOicqPihgGyc2ICt1KDY5DSAhJywnISohHyshKzY/Kz11e2QCLCA+YiI6JDUhOyhgIywgKiMgOTsrJjxiOicqPihhHSo9KSs9KiF2dG9v", "OOSMN");
    lIlllIIllIllll[lIlllIIlllIIIl[19]] = lllllIIlIlIIIII("AZX9iz6uMGjtuOv86YdQpjjDpy0CbnE0XTJpfIOsX3KpeIXb+gPo7Q==", "cromD");
    lIlllIIllIllll[lIlllIIlllIIIl[12]] = lllllIIlIlIIIlI("JARJNCU8EQ4zNSYGSSU5OU8BdmF5UVd3YXlRV3dheVFXd2F5UVd3dQAPEyI2LBNdIDQ9NwYrJCxbT24Yc0FH", "IagGQ");
    lIlllIIllIllll[lIlllIIlllIIIl[25]] = lllllIIlIlIIIlI("BSgxD1gaPS4CWCMgNBpMBj0iHBcbJjVUXkYFLQ8ADmYyGh8DZg4aEx0oMwEEVHNnTg==", "oIGnv");
    lIlllIIllIllll[lIlllIIlllIIIl[11]] = lllllIIlIlIIIIl("p1Yr+UaCkUYBuuQo3q1mQCdqUn7IV7HYqAcoozKDvM6TGlBUiq4V0eOIupfOsnWFxdWvN62VW3XzBUz4Ud694hvqpddl2pyXyN7eXzXgNaUUYGhU3SDi1O9ucg7lL2QI+ddBZTfYcWs=", "qrrLu");
    lIlllIIllIllll[lIlllIIlllIIIl[26]] = lllllIIlIlIIIIl("3BLjJoCiKPxBm7jzoyqGJsP1tJIUu/l1YQWC+txu7wRsWnCTlwg20A9iLtVYtcjn", "SBOSh");
    lIlllIIllIllll[lIlllIIlllIIIl[15]] = lllllIIlIlIIIIl("0si/1JIi8E3w2DbnWEYOcTCQFMv2a3zKHirIW1e/PrJu4w5VLJZvQ415SqZeAFIgESZkVX3kTCeEBXX46LL0RSKjgsdAppLcavP57RVVABE=", "MaiPt");
    lIlllIIllIllll[lIlllIIlllIIIl[29]] = lllllIIlIlIIIIl("B7ySl3NUTtrrfVY54ZfmuXcI6aWs4bRWAeucdjiu6Btv+XXvEljgtQ==", "fLEBT");
    lIlllIIllIllll[lIlllIIlllIIIl[30]] = lllllIIlIlIIIII("7x8DhNTb81L2AWf+b9+ULYn/u+JIuoWGAiqR4poMLsIfbkzhqTxP4IqPZ163a1alvehn4O06WiU=", "IdAWn");
    lIlllIIllIllll[lIlllIIlllIIIl[14]] = lllllIIlIlIIIII("+bul5SJ7xYX/AE5+GyDmS5NtUh1swIYbNAAJxeOEOa/acPWtYXYz7Eqp56UX+bOmfJGAWXmeMojzZydFAwwFOQ==", "wruVd");
    lIlllIIllIllll[lIlllIIlllIIIl[32]] = lllllIIlIlIIIII("CyStRDLKXiWiZchvoGHskdNpk4DgTzl13ET+xk5yFDcxWSxwZaPikoetVxaQv0dFPIpOZ670OgqEZW70JsQq5w==", "NISio");
    lIlllIIllIllll[lIlllIIlllIIIl[34]] = lllllIIlIlIIIlI("DA5pBRMUGy4CAw4MaRQPEUUmA10GDjMyAhIINR8XFQIoGF1JQgscBhcKaBoGDwxoJRMTAikRXFtLZw==", "akGvg");
    lIlllIIllIllll[lIlllIIlllIIIl[36]] = lllllIIlIlIIIlI("DwAEK3cQFRsmdywVFzg4EQ4AcDcAGQZwcUwtGCsvBE4eKzcCTj0oMwACBnFjRUE=", "earJY");
    lIlllIIllIllll[lIlllIIlllIIIl[38]] = lllllIIlIlIIIII("2/FCcDTxovjZM+Zk9z6C083cYsOOznH/s1C+m4vL9hzdwC7vycfnvMQrUaglCC+w0bY828qh+YXIMD88pjv/WzNiF4KLcuLl", "qnvGm");
    lIlllIIllIllll[lIlllIIlllIIIl[28]] = lllllIIlIlIIIII("Yc5pYNvqQgCF6BrM43fdlRy2TdLQAF/o2ks/lubkCkfI8RfwZMYBeuJ8xHokZ0u69mw2tGD0kxKYGrHKzNkULQ==", "RnDMM");
    lIlllIIllIllll[lIlllIIlllIIIl[35]] = lllllIIlIlIIIII("WOIlxTArjNZONuabCD8Fxj2AgJW1e0cnz99X0/xzF7coZaNwKjPm3g==", "QkBbA");
    lIlllIIllIllll[lIlllIIlllIIIl[13]] = lllllIIlIlIIIIl("+W/ciRkVSuNPfzRtk6tD0DdUW72KYKlYOoLJmMQ3BrwlkN6zA3B0Kg==", "Kwwkp");
    lIlllIIllIllll[lIlllIIlllIIIl[33]] = lllllIIlIlIIIII("JpQUqoj52Nf51yKMSdOZlWc81QnmpsAVqhXzEEP8Pg8yZZ1NY0zFy8HsPIjxi1Zga/P9z9G73h6mo8+hKUUBm5jbYoMlqPnvjznMEya9CMD+VvrdHLw4wuaowmSJsxZR3q2F4z1Osig=", "ADMvz");
    lIlllIIllIllll[lIlllIIlllIIIl[22]] = lllllIIlIlIIIlI("CCZLKg0QMwwtHQokSzsRFW0DaEpfNQQ1DAAwX3FQPg8IPFYWNxApEBEnCj5WBysVdh9UcF5jWQ==", "eCeYy");
    lIlllIIllIllll[lIlllIIlllIIIl[41]] = lllllIIlIlIIIlI("FT9LOh4NKgw9Dhc9SysCCHQDLFAXKgQqAwwjX3pQWHpFaQ==", "xZeIj");
    lIlllIIllIllll[lIlllIIlllIIIl[42]] = lllllIIlIlIIIlI("FBxeCzUMCRkMJRYeXhopCVcRDnseHAQ1Lh0MHB0yMBczGTUcHh8KOENRPBUkVgoEDTEQDRQXJlYbGAhuH0hDQ2g1ExEOIFYMBBEtVjgCCiAANRkLNUJDUFg=", "yypxA");
    lIlllIIllIllll[lIlllIIlllIIIl[27]] = lllllIIlIlIIIlI("GCBEEBAANQMXABoiRAEMBWsMBl4aMB4PDRsgKQwIGjdQUV5VZUpD", "uEjcd");
    lIlllIIllIllll[lIlllIIlllIIIl[43]] = lllllIIlIlIIIIl("03nD+6dN5eJ9YRKe58j1Se0R45iJbgntZvMlktrdOYEcrJpmwUd4O3RQvm1GrKU8", "uHwbA");
    lIlllIIllIllll[lIlllIIlllIIIl[24]] = lllllIIlIlIIIlI("IAUubSM2ASUvOiREMyIhJgYwNzonAyxtOysPLiZhFwImLip5DSY3DCwHMywhJgQ3ESotDiYxKjFQa2oDIAUubCM2ASUvOiRFMyIhJgYwNzonAyxsOysPLiZgEQ8tJyoxDzF4dWNK", "CjCCO");
    lIlllIIllIllll[lIlllIIlllIIIl[37]] = lllllIIlIlIIIII("o20dUBUXoRh+Dvb3g/0hKYDgwSN8PCbximkCpgo2gbwvpHtd//Dk6K/4/61ljH0BlGwfkHOpUUE=", "pszki");
    lIlllIIllIllll[lIlllIIlllIIIl[39]] = lllllIIlIlIIIIl("rR7P5M/+av96sxWcFEfeYIdH+ko+Mp1j+7u2/j2+fwHcCeEfyiHjddlVMXIJ9ISqRU7J49NsilU02Q1j38kio9MudFOckVRbd319kXtRPFbpJm3EyvQQoE5xzGKuBcurB8q34iWM9CU=", "jqthg");
    lIlllIIllIllll[lIlllIIlllIIIl[17]] = lllllIIlIlIIIIl("Fymb8I0YjCGgffNwx8DWbTexbNHYSJ2rB/s2SrrXnrDqpCAMsycKGDIAn+lvedmzvcaAGA4XjeQ=", "wVPrL");
    lIlllIIllIllll[lIlllIIlllIIIl[31]] = lllllIIlIlIIIII("5RvNewoTrRnkV2KCQuVSfLxGLLpOHbuWdIM8X1EKM0NrY3aThGfToQ==", "UeXXg");
    lIlllIIllIllll[lIlllIIlllIIIl[10]] = lllllIIlIlIIIIl("toof+zEotP3ELeDz2kFXfLwNtXf1gFRpK0hACe8MRgu8oLqKzAvxQw==", "qochz");
    lIlllIIllIllll[lIlllIIlllIIIl[44]] = lllllIIlIlIIIIl("8OdO9RmY3s934UyRaMgZwfajhehp/b0w/QvDxcP4PcaCaXUr5Bv2FQ==", "ZRsxt");
    lIlllIIllIllll[lIlllIIlllIIIl[40]] = lllllIIlIlIIIII("ds6M7hJD81cXMBO42iEXkEprQJ12vOA52JYfnfwuJRk=", "cTbxa");
    lIlllIIllIllll[lIlllIIlllIIIl[23]] = lllllIIlIlIIIIl("xpAh1kT1p7tEnZw1GRMug9hvBraJBhpNc/FkpyeDizKCUMX8mg54qv7gOAZZDKXA0vi7j/Opwe4=", "JGvXa");
    lIlllIIllIllll[lIlllIIlllIIIl[9]] = lllllIIlIlIIIII("/eHv7mfuscBtWjqa4DRPDdFgqoGxgDb2rxmVyZvqoQOvGZXJm+qhA1zHTZpLBWmPPltSSMabqVHsh9a4vUyK5jvp1Hvz9/lm10PLhYGx8xUzRkgnwp9K3ygHKGvAE7sI2KUdyQfA4NE=", "fXWTi");
    lIlllIIlllIIII = null;
  }
  
  private static void lllllIIlIlIIlII() {
    String str = (new Exception()).getStackTrace()[lIlllIIlllIIIl[3]].getFileName();
    lIlllIIlllIIII = str.substring(str.indexOf("ä") + lIlllIIlllIIIl[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIlIlIIIlI(String lllllllllllllllIlllIllIIlIlllIIl, String lllllllllllllllIlllIllIIlIlllIII) {
    lllllllllllllllIlllIllIIlIlllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIlllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIIlIllIlll = new StringBuilder();
    char[] lllllllllllllllIlllIllIIlIllIllI = lllllllllllllllIlllIllIIlIlllIII.toCharArray();
    int lllllllllllllllIlllIllIIlIllIlIl = lIlllIIlllIIIl[3];
    char[] arrayOfChar1 = lllllllllllllllIlllIllIIlIlllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlllIIIl[3];
    while (lllllIIlIlIlIlI(j, i)) {
      char lllllllllllllllIlllIllIIlIlllIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllIIlIllIlIl++;
      j++;
      "".length();
      if ((0x7B ^ 0x7E) == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllIIlIllIlll);
  }
  
  private static String lllllIIlIlIIIIl(String lllllllllllllllIlllIllIIlIllIIIl, String lllllllllllllllIlllIllIIlIllIIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIlIllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIlIllIIII.getBytes(StandardCharsets.UTF_8)), lIlllIIlllIIIl[20]), "DES");
      Cipher lllllllllllllllIlllIllIIlIllIIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIIlIllIIll.init(lIlllIIlllIIIl[2], lllllllllllllllIlllIllIIlIllIlII);
      return new String(lllllllllllllllIlllIllIIlIllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIlIllIIlI) {
      lllllllllllllllIlllIllIIlIllIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlIlIIIII(String lllllllllllllllIlllIllIIlIlIllII, String lllllllllllllllIlllIllIIlIlIlIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIlIlIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIlIlIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIIlIlIlllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIIlIlIlllI.init(lIlllIIlllIIIl[2], lllllllllllllllIlllIllIIlIlIllll);
      return new String(lllllllllllllllIlllIllIIlIlIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIlIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIlIlIllIl) {
      lllllllllllllllIlllIllIIlIlIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlIlIlIIl() {
    lIlllIIlllIIIl = new int[46];
    lIlllIIlllIIIl[0] = " ".length();
    lIlllIIlllIIIl[1] = (0x3D ^ 0x10 ^ (0xC3 ^ 0xC6) << "   ".length()) << " ".length();
    lIlllIIlllIIIl[2] = " ".length() << " ".length();
    lIlllIIlllIIIl[3] = (0x12 ^ 0x9) << " ".length() & ((0x77 ^ 0x6C) << " ".length() ^ 0xFFFFFFFF);
    lIlllIIlllIIIl[4] = (86 + 32 - 39 + 86 ^ (0x94 ^ 0xBB) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIlllIIIl[5] = ((0x35 ^ 0x24) << " ".length() << " ".length() ^ 0xD1 ^ 0xA2) << " ".length();
    lIlllIIlllIIIl[6] = "   ".length();
    lIlllIIlllIIIl[7] = " ".length() << " ".length() << " ".length();
    lIlllIIlllIIIl[8] = 0x48 ^ 0x4D;
    lIlllIIlllIIIl[9] = (0x5C ^ 0x49) << " ".length();
    lIlllIIlllIIIl[10] = ((0x41 ^ 0x6C) << " ".length() ^ 0x7 ^ 0x4E) << " ".length();
    lIlllIIlllIIIl[11] = ((0x83 ^ 0x8A) << "   ".length() ^ 0xEF ^ 0xA0) << " ".length();
    lIlllIIlllIIIl[12] = "   ".length() << " ".length() << " ".length();
    lIlllIIlllIIIl[13] = ((0x8B ^ 0xAE) << " ".length() ^ 0x5D ^ 0x1A) << " ".length();
    lIlllIIlllIIIl[14] = 0x45 ^ 0x56;
    lIlllIIlllIIIl[15] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlllIIIl[16] = "   ".length() << " ".length();
    lIlllIIlllIIIl[17] = ((0x70 ^ 0x67) << " ".length() ^ 0x86 ^ 0xA1) << " ".length() << " ".length();
    lIlllIIlllIIIl[18] = 0x9 ^ 0xE;
    lIlllIIlllIIIl[19] = 0xD0 ^ 0xBF ^ (0x69 ^ 0x70) << " ".length() << " ".length();
    lIlllIIlllIIIl[20] = " ".length() << "   ".length();
    lIlllIIlllIIIl[21] = (0x7D ^ 0x5A) << " ".length() ^ 0x7F ^ 0x38;
    lIlllIIlllIIIl[22] = (0x58 ^ 0x5F) << " ".length() << " ".length();
    lIlllIIlllIIIl[23] = (0x93 ^ 0x84) << "   ".length() ^ 74 + 99 - 49 + 21;
    lIlllIIlllIIIl[24] = 0xC5 ^ 0xA6 ^ (0xBC ^ 0x9D) << " ".length();
    lIlllIIlllIIIl[25] = 0x34 ^ 0xF ^ (0xA8 ^ 0xB3) << " ".length();
    lIlllIIlllIIIl[26] = 0x46 ^ 0x49;
    lIlllIIlllIIIl[27] = 0x44 ^ 0x7D ^ (0x9 ^ 0x1A) << " ".length();
    lIlllIIlllIIIl[28] = "   ".length() << "   ".length();
    lIlllIIlllIIIl[29] = 0xD2 ^ 0xC3;
    lIlllIIlllIIIl[30] = ((0x2F ^ 0x8) << " ".length() << " ".length() ^ 48 + 117 - 152 + 136) << " ".length();
    lIlllIIlllIIIl[31] = 0x4D ^ 0x4A ^ (0x59 ^ 0x48) << " ".length();
    lIlllIIlllIIIl[32] = (0x54 ^ 0x51) << " ".length() << " ".length();
    lIlllIIlllIIIl[33] = (0x98 ^ 0xB3) << " ".length() ^ 0xF2 ^ 0xBF;
    lIlllIIlllIIIl[34] = 0x9A ^ 0x8F;
    lIlllIIlllIIIl[35] = 0x83 ^ 0x9A;
    lIlllIIlllIIIl[36] = (0x2B ^ 0x20) << " ".length();
    lIlllIIlllIIIl[37] = (0x59 ^ 0x48) << " ".length();
    lIlllIIlllIIIl[38] = 0x5A ^ 0x4D;
    lIlllIIlllIIIl[39] = (0x76 ^ 0x5B) << " ".length() ^ 0xE0 ^ 0x99;
    lIlllIIlllIIIl[40] = (0x8B ^ 0x8E) << "   ".length();
    lIlllIIlllIIIl[41] = 0x9B ^ 0x86;
    lIlllIIlllIIIl[42] = (0x48 ^ 0x13 ^ (0x14 ^ 0x1) << " ".length() << " ".length()) << " ".length();
    lIlllIIlllIIIl[43] = " ".length() << ((0x78 ^ 0x77) << " ".length() << " ".length() ^ 0x88 ^ 0xB1);
    lIlllIIlllIIIl[44] = 51 + 42 - -23 + 73 ^ (0x2B ^ 0x66) << " ".length();
    lIlllIIlllIIIl[45] = 0xAE ^ 0x85;
  }
  
  private static boolean lllllIIlIlIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIlIlIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIlIlIllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIlIlIlIll(int paramInt) {
    return (paramInt != 0);
  }
  
  static {
    lllllIIlIlIlIIl();
    lllllIIlIlIIlII();
    lllllIIlIlIIIll();
    lllllIIlIIlllll();
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */