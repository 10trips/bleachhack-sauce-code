package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class fv extends au {
  private static String[] lIllIlllIIllII;
  
  private static Class[] lIllIlllIIllIl;
  
  private static final String[] lIllIllllIIlIl;
  
  private static String[] lIllIllllIIllI;
  
  private static final int[] lIllIllllIlIII;
  
  public fv() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fv.lIllIllllIIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fv.lIllIllllIIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fv.lIllIllllIIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllllIIIlIlIlIIII	Lme/stupitdog/bhp/fv;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   15: <illegal opcode> 4 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   20: instanceof net/minecraft/item/ItemExpBottle
    //   23: invokestatic llllIllIlIIllll : (I)Z
    //   26: ifeq -> 42
    //   29: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   34: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   37: iconst_0
    //   38: iaload
    //   39: putfield field_71467_ac : I
    //   42: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   47: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   52: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   57: <illegal opcode> 4 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   62: instanceof net/minecraft/item/ItemEndCrystal
    //   65: invokestatic llllIllIlIIllll : (I)Z
    //   68: ifeq -> 84
    //   71: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   76: getstatic me/stupitdog/bhp/fv.lIllIllllIlIII : [I
    //   79: iconst_0
    //   80: iaload
    //   81: putfield field_71467_ac : I
    //   84: ldc ''
    //   86: invokevirtual length : ()I
    //   89: pop
    //   90: aconst_null
    //   91: ifnull -> 96
    //   94: return
    //   95: astore_1
    //   96: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	97	0	lllllllllllllllIllllIIIlIlIIllll	Lme/stupitdog/bhp/fv;
    // Exception table:
    //   from	to	target	type
    //   0	84	95	java/lang/Exception
  }
  
  static {
    llllIllIlIIlllI();
    llllIllIlIIlIll();
    llllIllIlIIlIlI();
    llllIllIlIIIllI();
  }
  
  private static CallSite llllIllIIIlIlll(MethodHandles.Lookup lllllllllllllllIllllIIIlIlIIIllI, String lllllllllllllllIllllIIIlIlIIIlIl, MethodType lllllllllllllllIllllIIIlIlIIIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIIlIlIIllII = lIllIlllIIllII[Integer.parseInt(lllllllllllllllIllllIIIlIlIIIlIl)].split(lIllIllllIIlIl[lIllIllllIlIII[3]]);
      Class<?> lllllllllllllllIllllIIIlIlIIlIll = Class.forName(lllllllllllllllIllllIIIlIlIIllII[lIllIllllIlIII[0]]);
      String lllllllllllllllIllllIIIlIlIIlIlI = lllllllllllllllIllllIIIlIlIIllII[lIllIllllIlIII[1]];
      MethodHandle lllllllllllllllIllllIIIlIlIIlIIl = null;
      int lllllllllllllllIllllIIIlIlIIlIII = lllllllllllllllIllllIIIlIlIIllII[lIllIllllIlIII[3]].length();
      if (llllIllIlIlIIII(lllllllllllllllIllllIIIlIlIIlIII, lIllIllllIlIII[2])) {
        MethodType lllllllllllllllIllllIIIlIlIIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIIlIlIIllII[lIllIllllIlIII[2]], fv.class.getClassLoader());
        if (llllIllIlIlIIIl(lllllllllllllllIllllIIIlIlIIlIII, lIllIllllIlIII[2])) {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findVirtual(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIlllI);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findStatic(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIlllI);
        } 
        "".length();
        if ("   ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIIlIlIIllIl = lIllIlllIIllIl[Integer.parseInt(lllllllllllllllIllllIIIlIlIIllII[lIllIllllIlIII[2]])];
        if (llllIllIlIlIIIl(lllllllllllllllIllllIIIlIlIIlIII, lIllIllllIlIII[3])) {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findGetter(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIllIl);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else if (llllIllIlIlIIIl(lllllllllllllllIllllIIIlIlIIlIII, lIllIllllIlIII[4])) {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findStaticGetter(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else if (llllIllIlIlIIIl(lllllllllllllllIllllIIIlIlIIlIII, lIllIllllIlIII[5])) {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findSetter(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllllIIIlIlIIlIIl = lllllllllllllllIllllIIIlIlIIIllI.findStaticSetter(lllllllllllllllIllllIIIlIlIIlIll, lllllllllllllllIllllIIIlIlIIlIlI, lllllllllllllllIllllIIIlIlIIllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIIlIlIIlIIl);
    } catch (Exception lllllllllllllllIllllIIIlIlIIIlll) {
      lllllllllllllllIllllIIIlIlIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIlIIIllI() {
    lIllIlllIIllII = new String[lIllIllllIlIII[5]];
    lIllIlllIIllII[lIllIllllIlIII[3]] = lIllIllllIIlIl[lIllIllllIlIII[4]];
    lIllIlllIIllII[lIllIllllIlIII[4]] = lIllIllllIIlIl[lIllIllllIlIII[5]];
    lIllIlllIIllII[lIllIllllIlIII[2]] = lIllIllllIIlIl[lIllIllllIlIII[6]];
    lIllIlllIIllII[lIllIllllIlIII[1]] = lIllIllllIIlIl[lIllIllllIlIII[7]];
    lIllIlllIIllII[lIllIllllIlIII[0]] = lIllIllllIIlIl[lIllIllllIlIII[8]];
    lIllIlllIIllIl = new Class[lIllIllllIlIII[4]];
    lIllIlllIIllIl[lIllIllllIlIII[0]] = f13.class;
    lIllIlllIIllIl[lIllIllllIlIII[2]] = EntityPlayerSP.class;
    lIllIlllIIllIl[lIllIllllIlIII[1]] = Minecraft.class;
    lIllIlllIIllIl[lIllIllllIlIII[3]] = int.class;
  }
  
  private static void llllIllIlIIlIlI() {
    lIllIllllIIlIl = new String[lIllIllllIlIII[9]];
    lIllIllllIIlIl[lIllIllllIlIII[0]] = llllIllIlIIIlll(lIllIllllIIllI[lIllIllllIlIII[0]], lIllIllllIIllI[lIllIllllIlIII[1]]);
    lIllIllllIIlIl[lIllIllllIlIII[1]] = llllIllIlIIIlll(lIllIllllIIllI[lIllIllllIlIII[2]], lIllIllllIIllI[lIllIllllIlIII[3]]);
    lIllIllllIIlIl[lIllIllllIlIII[2]] = llllIllIlIIlIII(lIllIllllIIllI[lIllIllllIlIII[4]], lIllIllllIIllI[lIllIllllIlIII[5]]);
    lIllIllllIIlIl[lIllIllllIlIII[3]] = llllIllIlIIlIIl(lIllIllllIIllI[lIllIllllIlIII[6]], lIllIllllIIllI[lIllIllllIlIII[7]]);
    lIllIllllIIlIl[lIllIllllIlIII[4]] = llllIllIlIIlIIl(lIllIllllIIllI[lIllIllllIlIII[8]], lIllIllllIIllI[lIllIllllIlIII[9]]);
    lIllIllllIIlIl[lIllIllllIlIII[5]] = llllIllIlIIlIII(lIllIllllIIllI[lIllIllllIlIII[10]], lIllIllllIIllI[lIllIllllIlIII[11]]);
    lIllIllllIIlIl[lIllIllllIlIII[6]] = llllIllIlIIlIIl(lIllIllllIIllI[lIllIllllIlIII[12]], lIllIllllIIllI[lIllIllllIlIII[13]]);
    lIllIllllIIlIl[lIllIllllIlIII[7]] = llllIllIlIIIlll(lIllIllllIIllI[lIllIllllIlIII[14]], lIllIllllIIllI[lIllIllllIlIII[15]]);
    lIllIllllIIlIl[lIllIllllIlIII[8]] = llllIllIlIIlIIl("CyFcAwATNBsEEAkjXBIcFmoUQUdcFD4xLSMWSEBORmRSUA==", "fDrpt");
    lIllIllllIIllI = null;
  }
  
  private static void llllIllIlIIlIll() {
    String str = (new Exception()).getStackTrace()[lIllIllllIlIII[0]].getFileName();
    lIllIllllIIllI = str.substring(str.indexOf("ä") + lIllIllllIlIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllIlIIlIIl(String lllllllllllllllIllllIIIlIlIIIIlI, String lllllllllllllllIllllIIIlIlIIIIIl) {
    lllllllllllllllIllllIIIlIlIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIlIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIIlIlIIIIII = new StringBuilder();
    char[] lllllllllllllllIllllIIIlIIllllll = lllllllllllllllIllllIIIlIlIIIIIl.toCharArray();
    int lllllllllllllllIllllIIIlIIlllllI = lIllIllllIlIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIIlIlIIIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllllIlIII[0];
    while (llllIllIlIlIIlI(j, i)) {
      char lllllllllllllllIllllIIIlIlIIIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIIlIIlllllI++;
      j++;
      "".length();
      if (((0x95 ^ 0x8E) << " ".length() & ((0xB1 ^ 0xAA) << " ".length() ^ 0xFFFFFFFF)) >= " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIIlIlIIIIII);
  }
  
  private static String llllIllIlIIIlll(String lllllllllllllllIllllIIIlIIlllIlI, String lllllllllllllllIllllIIIlIIlllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIlIIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIIlIIllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIIlIIllllII.init(lIllIllllIlIII[2], lllllllllllllllIllllIIIlIIllllIl);
      return new String(lllllllllllllllIllllIIIlIIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIlIIlllIll) {
      lllllllllllllllIllllIIIlIIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllIlIIlIII(String lllllllllllllllIllllIIIlIIllIlIl, String lllllllllllllllIllllIIIlIIllIlII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIlIIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIIllIlII.getBytes(StandardCharsets.UTF_8)), lIllIllllIlIII[8]), "DES");
      Cipher lllllllllllllllIllllIIIlIIllIlll = Cipher.getInstance("DES");
      lllllllllllllllIllllIIIlIIllIlll.init(lIllIllllIlIII[2], lllllllllllllllIllllIIIlIIlllIII);
      return new String(lllllllllllllllIllllIIIlIIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIlIIllIllI) {
      lllllllllllllllIllllIIIlIIllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIlIIlllI() {
    lIllIllllIlIII = new int[16];
    lIllIllllIlIII[0] = (0x14 ^ 0x3D) << " ".length() & ((0x84 ^ 0xAD) << " ".length() ^ 0xFFFFFFFF);
    lIllIllllIlIII[1] = " ".length();
    lIllIllllIlIII[2] = " ".length() << " ".length();
    lIllIllllIlIII[3] = "   ".length();
    lIllIllllIlIII[4] = " ".length() << " ".length() << " ".length();
    lIllIllllIlIII[5] = (0x62 ^ 0x67) << " ".length() ^ 0x92 ^ 0x9D;
    lIllIllllIlIII[6] = "   ".length() << " ".length();
    lIllIllllIlIII[7] = 103 + 181 - 160 + 67 ^ (0x7E ^ 0x69) << "   ".length();
    lIllIllllIlIII[8] = " ".length() << "   ".length();
    lIllIllllIlIII[9] = (0xE2 ^ 0xB9) << " ".length() ^ 100 + 102 - 23 + 12;
    lIllIllllIlIII[10] = (0xB3 ^ 0x9A ^ (0x78 ^ 0x73) << " ".length() << " ".length()) << " ".length();
    lIllIllllIlIII[11] = 0x6 ^ 0xD;
    lIllIllllIlIII[12] = "   ".length() << " ".length() << " ".length();
    lIllIllllIlIII[13] = 0x5B ^ 0x56;
    lIllIllllIlIII[14] = (30 + 56 - -56 + 19 ^ (0xF5 ^ 0xA6) << " ".length()) << " ".length();
    lIllIllllIlIII[15] = 0xB9 ^ 0xB6;
  }
  
  private static boolean llllIllIlIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIllIlIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIllIlIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIllIlIIllll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */