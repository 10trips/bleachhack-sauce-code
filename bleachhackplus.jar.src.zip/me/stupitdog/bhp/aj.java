package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class aj extends au {
  private static ak holeUtil;
  
  f100000000000000000000.Mode placeMode;
  
  f100000000000000000000.Double range;
  
  private static String[] llIIIIllllIIIl;
  
  private static Class[] llIIIIllllIIlI;
  
  private static final String[] llIIIlIlllIIIl;
  
  private static String[] llIIIlIllllIlI;
  
  private static final int[] llIIIlIllllIll;
  
  public aj() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlIlIIIIIlllII	Lme/stupitdog/bhp/aj;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: aload_0
    //   52: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   58: iconst_5
    //   59: iaload
    //   60: aaload
    //   61: aload_1
    //   62: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   65: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   68: bipush #6
    //   70: iaload
    //   71: aaload
    //   72: <illegal opcode> 2 : (Lme/stupitdog/bhp/aj;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   77: <illegal opcode> 3 : (Lme/stupitdog/bhp/aj;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   82: aload_0
    //   83: aload_0
    //   84: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   87: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   90: bipush #7
    //   92: iaload
    //   93: aaload
    //   94: ldc2_w 4.4
    //   97: dconst_0
    //   98: ldc2_w 10.0
    //   101: <illegal opcode> 4 : (Lme/stupitdog/bhp/aj;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   106: <illegal opcode> 5 : (Lme/stupitdog/bhp/aj;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   111: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	112	0	lllllllllllllllIllIlIlIIIIIllIll	Lme/stupitdog/bhp/aj;
    //   8	104	1	lllllllllllllllIllIlIlIIIIIllIlI	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	104	1	lllllllllllllllIllIlIlIIIIIllIlI	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 6 : ()Lme/stupitdog/bhp/ak;
    //   5: <illegal opcode> 7 : (Lme/stupitdog/bhp/ak;)Ljava/util/List;
    //   10: astore_1
    //   11: <illegal opcode> 6 : ()Lme/stupitdog/bhp/ak;
    //   16: <illegal opcode> 8 : (Lme/stupitdog/bhp/ak;)Ljava/util/List;
    //   21: astore_2
    //   22: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   27: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   32: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   37: <illegal opcode> 12 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   42: istore_3
    //   43: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   46: iconst_0
    //   47: iaload
    //   48: istore #4
    //   50: iload #4
    //   52: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   55: bipush #8
    //   57: iaload
    //   58: invokestatic lIIIIlIIlIIlIllI : (II)Z
    //   61: ifeq -> 206
    //   64: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   69: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   74: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   79: iload #4
    //   81: <illegal opcode> 14 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   86: <illegal opcode> 15 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   91: astore #5
    //   93: aload #5
    //   95: instanceof net/minecraft/item/ItemBlock
    //   98: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   101: ifeq -> 150
    //   104: aload #5
    //   106: checkcast net/minecraft/item/ItemBlock
    //   109: <illegal opcode> 16 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   114: <illegal opcode> 17 : ()Lnet/minecraft/block/Block;
    //   119: <illegal opcode> 18 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   124: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   127: ifeq -> 150
    //   130: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   135: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   140: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   145: iload #4
    //   147: putfield field_70461_c : I
    //   150: iinc #4, 1
    //   153: ldc ''
    //   155: invokevirtual length : ()I
    //   158: pop
    //   159: ldc ' '
    //   161: invokevirtual length : ()I
    //   164: ineg
    //   165: bipush #102
    //   167: bipush #109
    //   169: ixor
    //   170: ldc ' '
    //   172: invokevirtual length : ()I
    //   175: ldc ' '
    //   177: invokevirtual length : ()I
    //   180: ishl
    //   181: ishl
    //   182: bipush #25
    //   184: bipush #18
    //   186: ixor
    //   187: ldc ' '
    //   189: invokevirtual length : ()I
    //   192: ldc ' '
    //   194: invokevirtual length : ()I
    //   197: ishl
    //   198: ishl
    //   199: iconst_m1
    //   200: ixor
    //   201: iand
    //   202: if_icmple -> 50
    //   205: return
    //   206: new java/util/ArrayList
    //   209: dup
    //   210: invokespecial <init> : ()V
    //   213: astore #4
    //   215: aload #4
    //   217: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   222: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   227: <illegal opcode> 20 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   232: <illegal opcode> 21 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   237: <illegal opcode> 22 : ()Ljava/util/stream/Collector;
    //   242: <illegal opcode> 23 : (Ljava/util/stream/Stream;Ljava/util/stream/Collector;)Ljava/lang/Object;
    //   247: checkcast java/util/Collection
    //   250: <illegal opcode> 24 : (Ljava/util/List;Ljava/util/Collection;)Z
    //   255: ldc ''
    //   257: invokevirtual length : ()I
    //   260: pop2
    //   261: aload_1
    //   262: <illegal opcode> 25 : (Ljava/util/List;)Ljava/util/Iterator;
    //   267: astore #5
    //   269: aload #5
    //   271: <illegal opcode> 26 : (Ljava/util/Iterator;)Z
    //   276: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   279: ifeq -> 492
    //   282: aload #5
    //   284: <illegal opcode> 27 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   289: checkcast net/minecraft/util/math/BlockPos
    //   292: astore #6
    //   294: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   299: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   304: aload #6
    //   306: <illegal opcode> 28 : (Lnet/minecraft/util/math/BlockPos;)I
    //   311: i2d
    //   312: aload #6
    //   314: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)I
    //   319: i2d
    //   320: aload #6
    //   322: <illegal opcode> 30 : (Lnet/minecraft/util/math/BlockPos;)I
    //   327: i2d
    //   328: <illegal opcode> 31 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)D
    //   333: aload_0
    //   334: <illegal opcode> 32 : (Lme/stupitdog/bhp/aj;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   339: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   344: invokestatic lIIIIlIIlIIlIlIl : (DD)I
    //   347: invokestatic lIIIIlIIlIIllIII : (I)Z
    //   350: ifeq -> 467
    //   353: aload_0
    //   354: aload #6
    //   356: invokespecial intersectsWithEntity : (Lnet/minecraft/util/math/BlockPos;)Z
    //   359: invokestatic lIIIIlIIlIIllIIl : (I)Z
    //   362: ifeq -> 467
    //   365: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   370: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   375: <illegal opcode> 34 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   380: new net/minecraft/network/play/client/CPacketEntityAction
    //   383: dup
    //   384: <illegal opcode> 35 : ()Lnet/minecraft/client/Minecraft;
    //   389: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   394: <illegal opcode> 36 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   399: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   402: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   407: aload_0
    //   408: new net/minecraft/util/math/BlockPos
    //   411: dup
    //   412: aload #6
    //   414: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   417: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumFacing;
    //   422: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   425: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   430: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   435: <illegal opcode> 34 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   440: new net/minecraft/network/play/client/CPacketEntityAction
    //   443: dup
    //   444: <illegal opcode> 35 : ()Lnet/minecraft/client/Minecraft;
    //   449: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   454: <illegal opcode> 39 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   459: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   462: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   467: ldc ''
    //   469: invokevirtual length : ()I
    //   472: pop
    //   473: sipush #242
    //   476: sipush #177
    //   479: ixor
    //   480: bipush #119
    //   482: bipush #52
    //   484: ixor
    //   485: iconst_m1
    //   486: ixor
    //   487: iand
    //   488: ifeq -> 269
    //   491: return
    //   492: aload_2
    //   493: <illegal opcode> 25 : (Ljava/util/List;)Ljava/util/Iterator;
    //   498: astore #5
    //   500: aload #5
    //   502: <illegal opcode> 26 : (Ljava/util/Iterator;)Z
    //   507: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   510: ifeq -> 714
    //   513: aload #5
    //   515: <illegal opcode> 27 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   520: checkcast net/minecraft/util/math/BlockPos
    //   523: astore #6
    //   525: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   530: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   535: aload #6
    //   537: <illegal opcode> 28 : (Lnet/minecraft/util/math/BlockPos;)I
    //   542: i2d
    //   543: aload #6
    //   545: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)I
    //   550: i2d
    //   551: aload #6
    //   553: <illegal opcode> 30 : (Lnet/minecraft/util/math/BlockPos;)I
    //   558: i2d
    //   559: <illegal opcode> 31 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)D
    //   564: aload_0
    //   565: <illegal opcode> 32 : (Lme/stupitdog/bhp/aj;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   570: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   575: invokestatic lIIIIlIIlIIlIlIl : (DD)I
    //   578: invokestatic lIIIIlIIlIIllIII : (I)Z
    //   581: ifeq -> 698
    //   584: aload_0
    //   585: aload #6
    //   587: invokespecial intersectsWithEntity : (Lnet/minecraft/util/math/BlockPos;)Z
    //   590: invokestatic lIIIIlIIlIIllIIl : (I)Z
    //   593: ifeq -> 698
    //   596: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   601: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   606: <illegal opcode> 34 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   611: new net/minecraft/network/play/client/CPacketEntityAction
    //   614: dup
    //   615: <illegal opcode> 35 : ()Lnet/minecraft/client/Minecraft;
    //   620: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   625: <illegal opcode> 36 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   630: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   633: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   638: aload_0
    //   639: new net/minecraft/util/math/BlockPos
    //   642: dup
    //   643: aload #6
    //   645: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   648: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumFacing;
    //   653: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   656: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   661: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   666: <illegal opcode> 34 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   671: new net/minecraft/network/play/client/CPacketEntityAction
    //   674: dup
    //   675: <illegal opcode> 35 : ()Lnet/minecraft/client/Minecraft;
    //   680: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   685: <illegal opcode> 39 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   690: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   693: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   698: ldc ''
    //   700: invokevirtual length : ()I
    //   703: pop
    //   704: ldc ' '
    //   706: invokevirtual length : ()I
    //   709: ineg
    //   710: iflt -> 500
    //   713: return
    //   714: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   719: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   724: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   729: iload_3
    //   730: putfield field_70461_c : I
    //   733: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   93	57	5	lllllllllllllllIllIlIlIIIIIllIIl	Lnet/minecraft/item/Item;
    //   50	156	4	lllllllllllllllIllIlIlIIIIIllIII	I
    //   294	173	6	lllllllllllllllIllIlIlIIIIIlIlll	Lnet/minecraft/util/math/BlockPos;
    //   525	173	6	lllllllllllllllIllIlIlIIIIIlIllI	Lnet/minecraft/util/math/BlockPos;
    //   0	734	0	lllllllllllllllIllIlIlIIIIIlIlIl	Lme/stupitdog/bhp/aj;
    //   11	723	1	lllllllllllllllIllIlIlIIIIIlIlII	Ljava/util/List;
    //   22	712	2	lllllllllllllllIllIlIlIIIIIlIIll	Ljava/util/List;
    //   43	691	3	lllllllllllllllIllIlIlIIIIIlIIlI	I
    //   215	519	4	lllllllllllllllIllIlIlIIIIIlIIIl	Ljava/util/List;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   11	723	1	lllllllllllllllIllIlIlIIIIIlIlII	Ljava/util/List<Lnet/minecraft/util/math/BlockPos;>;
    //   22	712	2	lllllllllllllllIllIlIlIIIIIlIIll	Ljava/util/List<Lnet/minecraft/util/math/BlockPos;>;
    //   215	519	4	lllllllllllllllIllIlIlIIIIIlIIIl	Ljava/util/List<Lnet/minecraft/entity/Entity;>;
  }
  
  private boolean intersectsWithEntity(BlockPos lllllllllllllllIllIlIlIIIIIIlllI) {
    // Byte code:
    //   0: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 40 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 25 : (Ljava/util/List;)Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: <illegal opcode> 26 : (Ljava/util/Iterator;)Z
    //   27: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   30: ifeq -> 179
    //   33: aload_2
    //   34: <illegal opcode> 27 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast net/minecraft/entity/Entity
    //   42: astore_3
    //   43: aload_3
    //   44: instanceof net/minecraft/entity/item/EntityItem
    //   47: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   50: ifeq -> 120
    //   53: ldc ''
    //   55: invokevirtual length : ()I
    //   58: pop
    //   59: bipush #70
    //   61: bipush #67
    //   63: ixor
    //   64: ldc_w '   '
    //   67: invokevirtual length : ()I
    //   70: ishl
    //   71: sipush #151
    //   74: sipush #146
    //   77: ixor
    //   78: ldc_w '   '
    //   81: invokevirtual length : ()I
    //   84: ishl
    //   85: iconst_m1
    //   86: ixor
    //   87: iand
    //   88: bipush #29
    //   90: bipush #124
    //   92: ixor
    //   93: sipush #214
    //   96: sipush #183
    //   99: ixor
    //   100: iconst_m1
    //   101: ixor
    //   102: iand
    //   103: if_icmpeq -> 21
    //   106: bipush #51
    //   108: bipush #32
    //   110: ixor
    //   111: bipush #69
    //   113: bipush #86
    //   115: ixor
    //   116: iconst_m1
    //   117: ixor
    //   118: iand
    //   119: ireturn
    //   120: new net/minecraft/util/math/AxisAlignedBB
    //   123: dup
    //   124: aload_1
    //   125: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   128: aload_3
    //   129: <illegal opcode> 41 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   134: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;Lnet/minecraft/util/math/AxisAlignedBB;)Z
    //   139: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   142: ifeq -> 151
    //   145: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   148: iconst_1
    //   149: iaload
    //   150: ireturn
    //   151: ldc ''
    //   153: invokevirtual length : ()I
    //   156: pop
    //   157: ldc ' '
    //   159: invokevirtual length : ()I
    //   162: ifge -> 21
    //   165: bipush #67
    //   167: bipush #20
    //   169: ixor
    //   170: bipush #16
    //   172: bipush #71
    //   174: ixor
    //   175: iconst_m1
    //   176: ixor
    //   177: iand
    //   178: ireturn
    //   179: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   182: iconst_0
    //   183: iaload
    //   184: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	108	3	lllllllllllllllIllIlIlIIIIIlIIII	Lnet/minecraft/entity/Entity;
    //   0	185	0	lllllllllllllllIllIlIlIIIIIIllll	Lme/stupitdog/bhp/aj;
    //   0	185	1	lllllllllllllllIllIlIlIIIIIIlllI	Lnet/minecraft/util/math/BlockPos;
  }
  
  private void placeBlock(BlockPos lllllllllllllllIllIlIlIIIIIIlIIl, EnumFacing lllllllllllllllIllIlIlIIIIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 43 : (Lme/stupitdog/bhp/aj;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 44 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: getstatic me/stupitdog/bhp/aj.llIIIlIlllIIIl : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/aj.llIIIlIllllIll : [I
    //   17: bipush #9
    //   19: iaload
    //   20: aaload
    //   21: <illegal opcode> 45 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   26: invokestatic lIIIIlIIlIIlIlll : (I)Z
    //   29: ifeq -> 71
    //   32: aload_1
    //   33: <illegal opcode> 46 : (Lnet/minecraft/util/math/BlockPos;)V
    //   38: ldc ''
    //   40: invokevirtual length : ()I
    //   43: pop
    //   44: ldc ' '
    //   46: invokevirtual length : ()I
    //   49: ldc ' '
    //   51: invokevirtual length : ()I
    //   54: ldc ' '
    //   56: invokevirtual length : ()I
    //   59: ishl
    //   60: ishl
    //   61: ldc_w '   '
    //   64: invokevirtual length : ()I
    //   67: if_icmpgt -> 209
    //   70: return
    //   71: aload_1
    //   72: aload_2
    //   73: <illegal opcode> 47 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   78: astore_3
    //   79: aload_2
    //   80: <illegal opcode> 48 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   85: astore #4
    //   87: new net/minecraft/util/math/Vec3d
    //   90: dup
    //   91: aload_3
    //   92: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   95: ldc2_w 0.5
    //   98: ldc2_w 0.5
    //   101: ldc2_w 0.5
    //   104: <illegal opcode> 49 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   109: new net/minecraft/util/math/Vec3d
    //   112: dup
    //   113: aload #4
    //   115: <illegal opcode> 50 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   120: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   123: ldc2_w 0.5
    //   126: <illegal opcode> 51 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   131: <illegal opcode> 52 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   136: astore #5
    //   138: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   143: <illegal opcode> 53 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   148: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   153: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   158: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   163: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   168: aload_3
    //   169: aload #4
    //   171: aload #5
    //   173: <illegal opcode> 54 : ()Lnet/minecraft/util/EnumHand;
    //   178: <illegal opcode> 55 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   183: ldc ''
    //   185: invokevirtual length : ()I
    //   188: pop2
    //   189: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   194: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   199: <illegal opcode> 54 : ()Lnet/minecraft/util/EnumHand;
    //   204: <illegal opcode> 56 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   209: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   79	130	3	lllllllllllllllIllIlIlIIIIIIllIl	Lnet/minecraft/util/math/BlockPos;
    //   87	122	4	lllllllllllllllIllIlIlIIIIIIllII	Lnet/minecraft/util/EnumFacing;
    //   138	71	5	lllllllllllllllIllIlIlIIIIIIlIll	Lnet/minecraft/util/math/Vec3d;
    //   0	210	0	lllllllllllllllIllIlIlIIIIIIlIlI	Lme/stupitdog/bhp/aj;
    //   0	210	1	lllllllllllllllIllIlIlIIIIIIlIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	210	2	lllllllllllllllIllIlIlIIIIIIlIII	Lnet/minecraft/util/EnumFacing;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIlIIlIIlIlII : ()V
    //   3: invokestatic lIIIIlIIlIIlIIll : ()V
    //   6: invokestatic lIIIIlIIlIIlIIlI : ()V
    //   9: invokestatic lIIIIlIIIllllllI : ()V
    //   12: new me/stupitdog/bhp/ak
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: <illegal opcode> 57 : (Lme/stupitdog/bhp/ak;)V
    //   24: return
  }
  
  private static CallSite lIIIIIllIlIlllIl(MethodHandles.Lookup lllllllllllllllIllIlIIllllllllll, String lllllllllllllllIllIlIIlllllllllI, MethodType lllllllllllllllIllIlIIllllllllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlIIIIIIIlIl = llIIIIllllIIIl[Integer.parseInt(lllllllllllllllIllIlIIlllllllllI)].split(llIIIlIlllIIIl[llIIIlIllllIll[8]]);
      Class<?> lllllllllllllllIllIlIlIIIIIIIlII = Class.forName(lllllllllllllllIllIlIlIIIIIIIlIl[llIIIlIllllIll[0]]);
      String lllllllllllllllIllIlIlIIIIIIIIll = lllllllllllllllIllIlIlIIIIIIIlIl[llIIIlIllllIll[1]];
      MethodHandle lllllllllllllllIllIlIlIIIIIIIIlI = null;
      int lllllllllllllllIllIlIlIIIIIIIIIl = lllllllllllllllIllIlIlIIIIIIIlIl[llIIIlIllllIll[3]].length();
      if (lIIIIlIIlIIllIlI(lllllllllllllllIllIlIlIIIIIIIIIl, llIIIlIllllIll[2])) {
        MethodType lllllllllllllllIllIlIlIIIIIIIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlIIIIIIIlIl[llIIIlIllllIll[2]], aj.class.getClassLoader());
        if (lIIIIlIIlIIllIll(lllllllllllllllIllIlIlIIIIIIIIIl, llIIIlIllllIll[2])) {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findVirtual(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIlll);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findStatic(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIlll);
        } 
        "".length();
        if (((160 + 103 - 178 + 82 ^ (0x34 ^ 0x71) << " ".length()) << " ".length() & ((0xA3 ^ 0xBA ^ (0x4A ^ 0x47) << " ".length() << " ".length()) << " ".length() ^ -" ".length())) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlIIIIIIIllI = llIIIIllllIIlI[Integer.parseInt(lllllllllllllllIllIlIlIIIIIIIlIl[llIIIlIllllIll[2]])];
        if (lIIIIlIIlIIllIll(lllllllllllllllIllIlIlIIIIIIIIIl, llIIIlIllllIll[3])) {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findGetter(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIllI);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (lIIIIlIIlIIllIll(lllllllllllllllIllIlIlIIIIIIIIIl, llIIIlIllllIll[4])) {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findStaticGetter(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIllI);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else if (lIIIIlIIlIIllIll(lllllllllllllllIllIlIlIIIIIIIIIl, llIIIlIllllIll[5])) {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findSetter(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIllI);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlIIIIIIIIlI = lllllllllllllllIllIlIIllllllllll.findStaticSetter(lllllllllllllllIllIlIlIIIIIIIlII, lllllllllllllllIllIlIlIIIIIIIIll, lllllllllllllllIllIlIlIIIIIIIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlIIIIIIIIlI);
    } catch (Exception lllllllllllllllIllIlIlIIIIIIIIII) {
      lllllllllllllllIllIlIlIIIIIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIIllllllI() {
    llIIIIllllIIIl = new String[llIIIlIllllIll[10]];
    llIIIIllllIIIl[llIIIlIllllIll[11]] = llIIIlIlllIIIl[llIIIlIllllIll[12]];
    llIIIIllllIIIl[llIIIlIllllIll[13]] = llIIIlIlllIIIl[llIIIlIllllIll[14]];
    llIIIIllllIIIl[llIIIlIllllIll[1]] = llIIIlIlllIIIl[llIIIlIllllIll[15]];
    llIIIIllllIIIl[llIIIlIllllIll[16]] = llIIIlIlllIIIl[llIIIlIllllIll[17]];
    llIIIIllllIIIl[llIIIlIllllIll[14]] = llIIIlIlllIIIl[llIIIlIllllIll[18]];
    llIIIIllllIIIl[llIIIlIllllIll[19]] = llIIIlIlllIIIl[llIIIlIllllIll[20]];
    llIIIIllllIIIl[llIIIlIllllIll[0]] = llIIIlIlllIIIl[llIIIlIllllIll[13]];
    llIIIIllllIIIl[llIIIlIllllIll[21]] = llIIIlIlllIIIl[llIIIlIllllIll[22]];
    llIIIIllllIIIl[llIIIlIllllIll[5]] = llIIIlIlllIIIl[llIIIlIllllIll[23]];
    llIIIIllllIIIl[llIIIlIllllIll[24]] = llIIIlIlllIIIl[llIIIlIllllIll[25]];
    llIIIIllllIIIl[llIIIlIllllIll[26]] = llIIIlIlllIIIl[llIIIlIllllIll[27]];
    llIIIIllllIIIl[llIIIlIllllIll[28]] = llIIIlIlllIIIl[llIIIlIllllIll[29]];
    llIIIIllllIIIl[llIIIlIllllIll[30]] = llIIIlIlllIIIl[llIIIlIllllIll[11]];
    llIIIIllllIIIl[llIIIlIllllIll[27]] = llIIIlIlllIIIl[llIIIlIllllIll[31]];
    llIIIIllllIIIl[llIIIlIllllIll[18]] = llIIIlIlllIIIl[llIIIlIllllIll[32]];
    llIIIIllllIIIl[llIIIlIllllIll[33]] = llIIIlIlllIIIl[llIIIlIllllIll[16]];
    llIIIIllllIIIl[llIIIlIllllIll[34]] = llIIIlIlllIIIl[llIIIlIllllIll[35]];
    llIIIIllllIIIl[llIIIlIllllIll[20]] = llIIIlIlllIIIl[llIIIlIllllIll[36]];
    llIIIIllllIIIl[llIIIlIllllIll[25]] = llIIIlIlllIIIl[llIIIlIllllIll[37]];
    llIIIIllllIIIl[llIIIlIllllIll[38]] = llIIIlIlllIIIl[llIIIlIllllIll[28]];
    llIIIIllllIIIl[llIIIlIllllIll[39]] = llIIIlIlllIIIl[llIIIlIllllIll[40]];
    llIIIIllllIIIl[llIIIlIllllIll[41]] = llIIIlIlllIIIl[llIIIlIllllIll[39]];
    llIIIIllllIIIl[llIIIlIllllIll[42]] = llIIIlIlllIIIl[llIIIlIllllIll[42]];
    llIIIIllllIIIl[llIIIlIllllIll[2]] = llIIIlIlllIIIl[llIIIlIllllIll[43]];
    llIIIIllllIIIl[llIIIlIllllIll[44]] = llIIIlIlllIIIl[llIIIlIllllIll[30]];
    llIIIIllllIIIl[llIIIlIllllIll[12]] = llIIIlIlllIIIl[llIIIlIllllIll[38]];
    llIIIIllllIIIl[llIIIlIllllIll[45]] = llIIIlIlllIIIl[llIIIlIllllIll[19]];
    llIIIIllllIIIl[llIIIlIllllIll[31]] = llIIIlIlllIIIl[llIIIlIllllIll[46]];
    llIIIIllllIIIl[llIIIlIllllIll[22]] = llIIIlIlllIIIl[llIIIlIllllIll[41]];
    llIIIIllllIIIl[llIIIlIllllIll[8]] = llIIIlIlllIIIl[llIIIlIllllIll[47]];
    llIIIIllllIIIl[llIIIlIllllIll[48]] = llIIIlIlllIIIl[llIIIlIllllIll[21]];
    llIIIIllllIIIl[llIIIlIllllIll[40]] = llIIIlIlllIIIl[llIIIlIllllIll[49]];
    llIIIIllllIIIl[llIIIlIllllIll[37]] = llIIIlIlllIIIl[llIIIlIllllIll[50]];
    llIIIIllllIIIl[llIIIlIllllIll[51]] = llIIIlIlllIIIl[llIIIlIllllIll[24]];
    llIIIIllllIIIl[llIIIlIllllIll[52]] = llIIIlIlllIIIl[llIIIlIllllIll[51]];
    llIIIIllllIIIl[llIIIlIllllIll[49]] = llIIIlIlllIIIl[llIIIlIllllIll[26]];
    llIIIIllllIIIl[llIIIlIllllIll[15]] = llIIIlIlllIIIl[llIIIlIllllIll[48]];
    llIIIIllllIIIl[llIIIlIllllIll[43]] = llIIIlIlllIIIl[llIIIlIllllIll[53]];
    llIIIIllllIIIl[llIIIlIllllIll[54]] = llIIIlIlllIIIl[llIIIlIllllIll[52]];
    llIIIIllllIIIl[llIIIlIllllIll[47]] = llIIIlIlllIIIl[llIIIlIllllIll[55]];
    llIIIIllllIIIl[llIIIlIllllIll[6]] = llIIIlIlllIIIl[llIIIlIllllIll[34]];
    llIIIIllllIIIl[llIIIlIllllIll[32]] = llIIIlIlllIIIl[llIIIlIllllIll[56]];
    llIIIIllllIIIl[llIIIlIllllIll[3]] = llIIIlIlllIIIl[llIIIlIllllIll[57]];
    llIIIIllllIIIl[llIIIlIllllIll[55]] = llIIIlIlllIIIl[llIIIlIllllIll[44]];
    llIIIIllllIIIl[llIIIlIllllIll[58]] = llIIIlIlllIIIl[llIIIlIllllIll[54]];
    llIIIIllllIIIl[llIIIlIllllIll[50]] = llIIIlIlllIIIl[llIIIlIllllIll[33]];
    llIIIIllllIIIl[llIIIlIllllIll[56]] = llIIIlIlllIIIl[llIIIlIllllIll[45]];
    llIIIIllllIIIl[llIIIlIllllIll[57]] = llIIIlIlllIIIl[llIIIlIllllIll[58]];
    llIIIIllllIIIl[llIIIlIllllIll[35]] = llIIIlIlllIIIl[llIIIlIllllIll[10]];
    llIIIIllllIIIl[llIIIlIllllIll[46]] = llIIIlIlllIIIl[llIIIlIllllIll[59]];
    llIIIIllllIIIl[llIIIlIllllIll[36]] = llIIIlIlllIIIl[llIIIlIllllIll[60]];
    llIIIIllllIIIl[llIIIlIllllIll[53]] = llIIIlIlllIIIl[llIIIlIllllIll[61]];
    llIIIIllllIIIl[llIIIlIllllIll[7]] = llIIIlIlllIIIl[llIIIlIllllIll[62]];
    llIIIIllllIIIl[llIIIlIllllIll[9]] = llIIIlIlllIIIl[llIIIlIllllIll[63]];
    llIIIIllllIIIl[llIIIlIllllIll[17]] = llIIIlIlllIIIl[llIIIlIllllIll[64]];
    llIIIIllllIIIl[llIIIlIllllIll[4]] = llIIIlIlllIIIl[llIIIlIllllIll[65]];
    llIIIIllllIIIl[llIIIlIllllIll[29]] = llIIIlIlllIIIl[llIIIlIllllIll[66]];
    llIIIIllllIIIl[llIIIlIllllIll[23]] = llIIIlIlllIIIl[llIIIlIllllIll[67]];
    llIIIIllllIIlI = new Class[llIIIlIllllIll[13]];
    llIIIIllllIIlI[llIIIlIllllIll[9]] = Block.class;
    llIIIIllllIIlI[llIIIlIllllIll[8]] = WorldClient.class;
    llIIIIllllIIlI[llIIIlIllllIll[4]] = Minecraft.class;
    llIIIIllllIIlI[llIIIlIllllIll[15]] = CPacketEntityAction.Action.class;
    llIIIIllllIIlI[llIIIlIllllIll[18]] = PlayerControllerMP.class;
    llIIIIllllIIlI[llIIIlIllllIll[17]] = EnumFacing.class;
    llIIIIllllIIlI[llIIIlIllllIll[1]] = f100000000000000000000.Mode.class;
    llIIIIllllIIlI[llIIIlIllllIll[2]] = f100000000000000000000.Double.class;
    llIIIIllllIIlI[llIIIlIllllIll[20]] = EnumHand.class;
    llIIIIllllIIlI[llIIIlIllllIll[6]] = InventoryPlayer.class;
    llIIIIllllIIlI[llIIIlIllllIll[7]] = int.class;
    llIIIIllllIIlI[llIIIlIllllIll[5]] = EntityPlayerSP.class;
    llIIIIllllIIlI[llIIIlIllllIll[12]] = List.class;
    llIIIIllllIIlI[llIIIlIllllIll[0]] = f13.class;
    llIIIIllllIIlI[llIIIlIllllIll[3]] = ak.class;
    llIIIIllllIIlI[llIIIlIllllIll[14]] = NetHandlerPlayClient.class;
  }
  
  private static void lIIIIlIIlIIlIIlI() {
    llIIIlIlllIIIl = new String[llIIIlIllllIll[68]];
    llIIIlIlllIIIl[llIIIlIllllIll[0]] = lIIIIlIIIlllllll(llIIIlIllllIlI[llIIIlIllllIll[0]], llIIIlIllllIlI[llIIIlIllllIll[1]]);
    llIIIlIlllIIIl[llIIIlIllllIll[1]] = lIIIIlIIlIIIIIII(llIIIlIllllIlI[llIIIlIllllIll[2]], llIIIlIllllIlI[llIIIlIllllIll[3]]);
    llIIIlIlllIIIl[llIIIlIllllIll[2]] = lIIIIlIIlIIIIIII(llIIIlIllllIlI[llIIIlIllllIll[4]], llIIIlIllllIlI[llIIIlIllllIll[5]]);
    llIIIlIlllIIIl[llIIIlIllllIll[3]] = lIIIIlIIlIIIIIII(llIIIlIllllIlI[llIIIlIllllIll[6]], llIIIlIllllIlI[llIIIlIllllIll[7]]);
    llIIIlIlllIIIl[llIIIlIllllIll[4]] = lIIIIlIIIlllllll(llIIIlIllllIlI[llIIIlIllllIll[9]], llIIIlIllllIlI[llIIIlIllllIll[8]]);
    llIIIlIlllIIIl[llIIIlIllllIll[5]] = lIIIIlIIlIIIIIIl(llIIIlIllllIlI[llIIIlIllllIll[12]], llIIIlIllllIlI[llIIIlIllllIll[14]]);
    llIIIlIlllIIIl[llIIIlIllllIll[6]] = lIIIIlIIlIIIIIII(llIIIlIllllIlI[llIIIlIllllIll[15]], llIIIlIllllIlI[llIIIlIllllIll[17]]);
    llIIIlIlllIIIl[llIIIlIllllIll[7]] = lIIIIlIIlIIIIIIl(llIIIlIllllIlI[llIIIlIllllIll[18]], llIIIlIllllIlI[llIIIlIllllIll[20]]);
    llIIIlIlllIIIl[llIIIlIllllIll[9]] = lIIIIlIIIlllllll(llIIIlIllllIlI[llIIIlIllllIll[13]], llIIIlIllllIlI[llIIIlIllllIll[22]]);
    llIIIlIlllIIIl[llIIIlIllllIll[8]] = lIIIIlIIlIIIIIII(llIIIlIllllIlI[llIIIlIllllIll[23]], llIIIlIllllIlI[llIIIlIllllIll[25]]);
    llIIIlIlllIIIl[llIIIlIllllIll[12]] = lIIIIlIIlIIIIIIl(llIIIlIllllIlI[llIIIlIllllIll[27]], llIIIlIllllIlI[llIIIlIllllIll[29]]);
    llIIIlIlllIIIl[llIIIlIllllIll[14]] = lIIIIlIIIlllllll(llIIIlIllllIlI[llIIIlIllllIll[11]], llIIIlIllllIlI[llIIIlIllllIll[31]]);
    llIIIlIlllIIIl[llIIIlIllllIll[15]] = lIIIIlIIlIIIIIIl(llIIIlIllllIlI[llIIIlIllllIll[32]], llIIIlIllllIlI[llIIIlIllllIll[16]]);
    llIIIlIlllIIIl[llIIIlIllllIll[17]] = lIIIIlIIlIIIIIIl("EDsSMUsPLg08SzYzFyRfEy4BIgQONRZqTVMWDjETG3URJAwWdS0kAAg7ED8XQWBEcA==", "zZdPe");
    llIIIlIlllIIIl[llIIIlIllllIll[18]] = lIIIIlIIIlllllll("sChXsixrSjxNe7OQMGHNG0atQIaxs1/fEFaobc0bCP029k7Q89t81CWjUZUgpqiq67vkb+9cNDjdDS5tEfvnug==", "QoNXK");
    llIIIlIlllIIIl[llIIIlIllllIll[20]] = lIIIIlIIIlllllll("hBlNoERc95J62XcV50Vd4lvRVyXcks/sCy4OK870IXYjUhxFCSPi36Xl2d5Z7/zN4ErAcDBVQ9jF+psKInptkaM4HeWMgtJ828E7UBJQa902rCCB37xygQ==", "snqwA");
    llIIIlIlllIIIl[llIIIlIllllIll[13]] = lIIIIlIIlIIIIIIl("OBBKJQEgBQ0iEToSSjQdJVsCZ0ZvNisbNxQhXmZPdVVEdg==", "UudVu");
    llIIIlIlllIIIl[llIIIlIllllIll[22]] = lIIIIlIIIlllllll("Xmkki6mr7kgKd5f8a7k6m763VjhnJVp9rOjI1yfNOvlJmhP59ZFkbiFT+wF1jajyC83sBixXpI1Vn54W2sTwbuHG/N1GRZib", "wBdjS");
    llIIIlIlllIIIl[llIIIlIllllIll[23]] = lIIIIlIIIlllllll("KXHlUsU5sp700JyXtMsXoNRCw48SGRD2b6UOI4vuj5zXisY/QuqoIQ==", "wBYQL");
    llIIIlIlllIIIl[llIIIlIllllIll[25]] = lIIIIlIIlIIIIIII("6Vxvwn+qfLPk6/hqFlcji6I/TVxUrpC3Z4kwmloRy+XwsE5Nwpv7MQ==", "FCvVq");
    llIIIlIlllIIIl[llIIIlIllllIll[27]] = lIIIIlIIlIIIIIIl("GAMiL1YeAzopViEWJicWFVgxPw0TDicHHxwNJis7ExExdFA+CDU4GV0ONSAfXTEgPBEcBW9nIkhCdA==", "rbTNx");
    llIIIlIlllIIIl[llIIIlIllllIll[29]] = lIIIIlIIlIIIIIII("gJlT8WEIvnJ3SHk+HQGbDvYQ0NKRqFjCuK3Z+tsVxBa2oG27d8p2AZRoXsGksqMmG7DWA0eM6Nk=", "RtAZc");
    llIIIlIlllIIIl[llIIIlIllllIll[11]] = lIIIIlIIlIIIIIII("8qSXiOC5uwQy6dLpA4FW1xTNWRU7DQrVqyWFRvoMvWFgyD6cap10mjbiftuLCrdG++w9PG5/Vdh7LN7lZXI9SA==", "RJkpg");
    llIIIlIlllIIIl[llIIIlIllllIll[31]] = lIIIIlIIlIIIIIIl("PBQmRx07HzcKAjMXJkcTPhg3BwR8HCcFBDsBPggJNwN8Ph8gHTYqHDsUPB1KNBg3BRQNRmFZQWIuO1NBYktySVA=", "RqRip");
    llIIIlIlllIIIl[llIIIlIllllIll[32]] = lIIIIlIIlIIIIIIl("JzMWQgwgOAcPEygwFkIEJyILGBhnJg4NGCwkTCUPPzMMGA47LzIAADAzEFYHPDgBM1Z5ZVJdPihsSiVIBTgHGE4kPwwJAjs3BBhOICIHAU4AIgcBMj03AQdac3ZC", "IVbla");
    llIIIlIlllIIIl[llIIIlIllllIll[16]] = lIIIIlIIIlllllll("/iBBqqJzBbTcebNG9kcWDKwneSpo6BNEEoe9kHG6CxyapqJX+mMMPnyegbpQP/dN6VUmzJKt+GV2+8642juZZwUZFX/duRiis2XfN2dixMgrxYCF5g5RyrsoTW2VdwJYIigH21k5Xo6Ww5My85qa10tO0bZOgz102sHVIwa0+Bt3jx0S+DONwRKHvZBxugsc4UatKdW9jAreKv232mMdnsxGlQDC3ZMSAUlyDru0CEC7dsOCUSU+LznmqXCkHyz0S07Rtk6DPXTCcBZY6xd3fPv8qcI6nWqhQCkgUPLDhECaHh3EEApR/xcF9Tf8QpDy/N0BzZ8z9wtBBCA60/moYMxGlQDC3ZMSAUlyDru0CEADqii9ZcCsd9SH8WoHaZJVs2XfN2dixMgZ+FBFKtNQu6rkeAiu3Gwo7P+Xush3QKXgMVe1lF+osw==", "vsHkJ");
    llIIIlIlllIIIl[llIIIlIllllIll[35]] = lIIIIlIIIlllllll("cAq0MvNbkjTohu6PhUt7ZNpTlyX4BDRVXaFe+ftv5VIBRfbj2SqpqzleoxLv3+8yvyU1afnaCiKX6LK0kxxKSilLIMO0t4bRcKttqIHgOOwUttHrWEFyLw==", "wENiP");
    llIIIlIlllIIIl[llIIIlIllllIll[36]] = lIIIIlIIIlllllll("ZqTPfSW3pHiPsFg6DYtfQdAQxn+34XRtRkdOwh5rMgrFvfyvUnGa17b5h9yNXv7WO1RIzgXR7FWD04Veiu3gu/S4BLc0dB8IKdJdGcudpYs=", "biIvl");
    llIIIlIlllIIIl[llIIIlIllllIll[37]] = lIIIIlIIlIIIIIII("rgx5iUHaWRn5cIM2+jqUy+63qGQdW78J/2CLUM+gkOkmMqrRr2eTWW/MzPJ3D7Gail7ktUp5ZhQ=", "tRLAp");
    llIIIlIlllIIIl[llIIIlIllllIll[28]] = lIIIIlIIlIIIIIII("GGwZUoYvd1sTihCegtP4PPh7aTVQbjmN0AWiZ3UhGUU=", "TocuU");
    llIIIlIlllIIIl[llIIIlIllllIll[40]] = lIIIIlIIlIIIIIII("8vvL+2iJBzrUY416lu8768uLJVQXdif4aI5wbrK/wtwhmMTH3cKheo74omUHGDq/Ey3vjuJqbeDp1yB0PPt1hz9T1zPQ6Fbe", "oUyeB");
    llIIIlIlllIIIl[llIIIlIllllIll[39]] = lIIIIlIIlIIIIIIl("IAsxQxgnACAOBy8IMUMAOgcpQzAgGygrFC0HKwpPCiESI09/XX9NVW5O", "NnEmu");
    llIIIlIlllIIIl[llIIIlIllllIll[42]] = lIIIIlIIIlllllll("NtMxKUK+/LljpXFRXoAE9TMvzDL8X6fS39WFZEzCNqk=", "dzFEh");
    llIIIlIlllIIIl[llIIIlIllllIll[43]] = lIIIIlIIlIIIIIIl("FQ1CGxsNGAUcCxcPQgoHCEYNAlUKDQsBHAwNHiUAHA1WQCMSCRoJQBQJAg9AKxweAQEfUyACDg4JQx0bEQRDJAYLHFckBRkeDUcDGQYLRzwMGgUGCENBIAUKVxsYHR8RHAgHCFcKBBhAHllcWF9IWFxYX0hYXFhfSFhcWF9IWEglABwNV1JPWA==", "xhlho");
    llIIIlIlllIIIl[llIIIlIllllIll[30]] = lIIIIlIIlIIIIIIl("LBESRCYrGgMJOSMSEkQoLh0DBD9sOQ8ELiEGBww/eBIPDycmK1Fbf3ZGOQhxc0BcSmti", "BtfjK");
    llIIIlIlllIIIl[llIIIlIllllIll[38]] = lIIIIlIIlIIIIIIl("CSEFfAMOKhQxHAYiBXwNCy0UPBpJCRg8CwQ2EDQaXSIYNwIDG0ZjWlR9LjVUUn5Rck4=", "gDqRn");
    llIIIlIlllIIIl[llIIIlIllllIll[19]] = lIIIIlIIIlllllll("ZqdXwWfsVO7yU8v03lvI+hQlO+wXb3L9ddlsJsLL2yormQb2eA2E1YG07PGkk807TcoRwBGFRxjCVZMTvtddTE3xyEGivK5RJ+GIwMmN2+LRs+FcCteOTtHA5aE1wv3R", "gboWD");
    llIIIlIlllIIIl[llIIIlIllllIll[46]] = lIIIIlIIIlllllll("wCN4GuxsaePqNmVfoIT39VL3Mg/EW0ZPS6zndZqabxU3aK6nffd28pd6g3nPfyrD7OYV0mUIfJUOviUSNwKKNXmoDeZcknLkXuMCAMZ1RP6CJ4FD4OTy0g==", "ymyzt");
    llIIIlIlllIIIl[llIIIlIllllIll[41]] = lIIIIlIIIlllllll("YmJVnehsJ9GJ+RIZ7ClOGOFpvl1XuvGFhN9FJ02UOWpBNi0AS9zi1IU85BVwGbsz", "nVvxe");
    llIIIlIlllIIIl[llIIIlIllllIll[47]] = lIIIIlIIlIIIIIIl("ISZlOjw5MyI9LCMkZSsgPG0qI3IhIHF9cmxja2k=", "LCKIH");
    llIIIlIlllIIIl[llIIIlIllllIll[21]] = lIIIIlIIlIIIIIIl("Kz9XABEzKhAHASk9VxENNnQfQ1N8KhUSBiMYFRwGLWBRPwsjLlYeDCg/GgEEIC5WBhEvNlYeBDIyVjEJKTkSIwo1YVAlX2Y=", "FZyse");
    llIIIlIlllIIIl[llIIIlIllllIll[49]] = lIIIIlIIlIIIIIII("vAGhvh1q9s/QhC3pGLTkl167YldmIb3Az7niYjcqB0T0Z7Xvdfkb79PO+7AGOmx4IY0MpQBADRM=", "QaagD");
    llIIIlIlllIIIl[llIIIlIllllIll[50]] = lIIIIlIIIlllllll("7WKkY+KRnKhzMrDJynP0wQfBBtTHHdj6pHpoqNA4zLMnJJK2UnqeDQkJLl7/NC7j6mzw/v0MSso=", "fakLx");
    llIIIlIlllIIIl[llIIIlIllllIll[24]] = lIIIIlIIlIIIIIII("0wUK+QbZTJcteywnchW6NEWoPBCA0Ckqpmw+pL5yXhXZPqjoz/I1+mmz0NxlY89eqBZgU29+GEQOdAmxZADHjsnP1fXXn8mYWifTcK7pVek=", "hvwdU");
    llIIIlIlllIIIl[llIIIlIllllIll[51]] = lIIIIlIIlIIIIIII("x4toZqNTKBDy4EDpGqXaXDkkcv99ZvUUSliS0m96qgNV9xvpJrPMXer9OzEb3pIt25yX+GW/mNhGna9qDcaT6/RFVT6NwXEmz/9X0ua0pdAmMjWBxzp2pg==", "LYzCk");
    llIIIlIlllIIIl[llIIIlIllllIll[26]] = lIIIIlIIlIIIIIII("aN5t7xiRkaw9o8HkgmPCLuDao8iPsxrCwPN97r2ypvDhte1oDVe0hV9F3izyI0VyPxHcL5IaU/sEhn7L+v5dB6YD3SPiCvhe8wPOmW3DKz+X1sHuowSqYA==", "qrrzU");
    llIIIlIlllIIIl[llIIIlIllllIll[48]] = lIIIIlIIlIIIIIII("U0/RcdquvJwSjgx7hXMfGzxS3rSNvT5TJKTWqeUJke5kifJGqY8ieJsSyNS6Nm2DU1BbxNxyqlrpwgphqxwGLA==", "RqNus");
    llIIIlIlllIIIl[llIIIlIllllIll[53]] = lIIIIlIIIlllllll("Pe9Y2ZMWnruOQgiGvQ54y0tQOHes59Fhg53KGRZEUUivefpKBYq0p2MsGbPWGIUt2nnNp/tGNvbbfGrkf31Tkw==", "ZbBGw");
    llIIIlIlllIIIl[llIIIlIllllIll[52]] = lIIIIlIIIlllllll("DWNNdRVGGi1yQkSj3Hx3xDuceEQ+7gbx3+uR3QlU11htB8bI2HF7uMfQF+197tns", "nVCsX");
    llIIIlIlllIIIl[llIIIlIllllIll[55]] = lIIIIlIIlIIIIIII("hEZvWW3rktEHBp90lWZzzy8NpxV45+zcazIdZzl8bElc0V/H3Ub+Eci46ezYs3fvRft/zwd9lLpeUOMLdyNh0mzKAeX5pERTcDGoy54gB3uynjQfWdo1Ng==", "eNvdB");
    llIIIlIlllIIIl[llIIIlIllllIll[34]] = lIIIIlIIlIIIIIII("yiyB9JG7Nusx2KNq9UmKrcD9Z26Kwcig50UAO0oOZ0/Juf0psWL8Hw==", "GGejB");
    llIIIlIlllIIIl[llIIIlIllllIll[56]] = lIIIIlIIlIIIIIII("3RH1oS8GZxY2UlPEYKgO5pJNeYsuJuXpYpxtfrlQXSugKRtpH4kl1MQJS11gB0IiVXH16xfrc40=", "jReKE");
    llIIIlIlllIIIl[llIIIlIllllIll[57]] = lIIIIlIIIlllllll("kMNgCafg8JVKhHR8Yx8Oi+FXr+Da2mZQxuRrlkHcfCtJ0Ft6Ta2s9A==", "FJvcL");
    llIIIlIlllIIIl[llIIIlIllllIll[44]] = lIIIIlIIIlllllll("U8UXh281qIhAoKhRNkALDCe0wxqgXTJ3KbUbU6LLUAye29UPpvRj/6zZJvtEf5yi1ZlsDMc4MzSp+tU3wFLzPajLaClKc+5DNWjnE1IJyYNsIFbPAyG6xw==", "byFuw");
    llIIIlIlllIIIl[llIIIlIllllIll[54]] = lIIIIlIIlIIIIIII("dzD9M+CebpnKk9a2JCIpKbbq+a2cPOEWmvnGJsoOkgRXKdiQVQk2NA==", "skgkr");
    llIIIlIlllIIIl[llIIIlIllllIll[33]] = lIIIIlIIlIIIIIIl("HxEYYR8YGgksABASGGEHBR0AYR8QAARhMwkdHw4eGBMCKhYzNlYpBx8XM3hAQkZaEBNLXCAhFwVbASYcFBceLhQFWxk7Gx1bAS4GGVstNxsCNQAmFR8RCA0wSl02dVJR", "qtlOr");
    llIIIlIlllIIIl[llIIIlIllllIll[45]] = lIIIIlIIIlllllll("OcTlgBwmgRO39+skM+BiFPoM6U2tny/3R0e+m0yYQEL4MGQtDpHwM5d5xVEmf+lnNX/jd6bQuIfvuq5k/9eY7Ov4N9U6OF14f6RqKUKeyOxbvujhyUH7dw==", "TgmBt");
    llIIIlIlllIIIl[llIIIlIllllIll[58]] = lIIIIlIIlIIIIIIl("PhA3fQg5GyYwFzETN30QJBwvfQgxASt9MzUWcDdfNgAtMDphQntkXWcqJmlNHBsmJ0o9HC02BiIUJSdKJQEqP0o9FDc7SgYQIGABa1wPPQAkWi46CzUWMTIDJFo2Jww8Wi4yEThaFTYGYxF4aUVw", "PuCSe");
    llIIIlIlllIIIl[llIIIlIllllIll[10]] = lIIIIlIIlIIIIIII("aUBW+9wXkOUkwYkOQapg3+8Suqo5duylKpuv1RLab1uQ1N57NOjAGA==", "BjfwR");
    llIIIlIlllIIIl[llIIIlIllllIll[59]] = lIIIIlIIlIIIIIIl("PiYiTSQ5LTMAOzElIk0qPCozDT1+LTMXPj8xPU0HNTceAic0LzMRGTwiLyAlOSY4F3M2NjgAFmF3YVFwZxw3WWEcLTMXZj0qOAYqIiIwF2Y+JiIUJiIoeTMoMygzF3J5FWxDaQ==", "PCVcI");
    llIIIlIlllIIIl[llIIIlIllllIll[60]] = lIIIIlIIlIIIIIIl("OQQ5O0smESY2SxoRKigEJwo9YAs2HTtgTXopJTsTMkojOws0SgA4DzYGO2Ffc0U=", "SeOZe");
    llIIIlIlllIIIl[llIIIlIllllIll[61]] = lIIIIlIIlIIIIIII("pf/f2sZp9toVikfHsTcii++Hid2gr0dabrqQ+uaaWYXQB+YpEz+DC1ewOKlftcxq2gRik0BbrQBNT5+YLMugeEn81ZCGfMTFXYxVl/7S363aBGKTQFutAE1Pn5gsy6B4Iit996ZrYL6U/ZwKVCh7duImn50obQIT", "tRTxg");
    llIIIlIlllIIIl[llIIIlIllllIll[62]] = lIIIIlIIlIIIIIIl("CRV3HxMRADAYAwsXdw4PFF44B10CGTcIKAYDMAgOBR4RAwsBA2NETigaOBoGSwUtBQtLPDAfE19KeUw=", "dpYlg");
    llIIIlIlllIIIl[llIIIlIllllIll[63]] = lIIIIlIIlIIIIIII("yd5mVyLJIbkXtYIY0uLHrlvjnAuzEfgH7QbQ+ZvDh9aFIEivx7tAIRwW85g4rElXsB7ZfnPbWfpKns9u5fONHg==", "RYkyZ");
    llIIIlIlllIIIl[llIIIlIllllIll[64]] = lIIIIlIIlIIIIIII("w0lGhYdz63iQ/KYCnTdd4ne66D3hjykFuid5LNAgFd1R7Vcd5TKM8xolO6/e40XJYlY/22X5x3KwpajSnGXSeMrLDJzHEFbvFwyFYT3Ow9KRvOc/X7OqhA==", "sBPUe");
    llIIIlIlllIIIl[llIIIlIllllIll[65]] = lIIIIlIIlIIIIIII("IGWm5Z1rOjlyz9C11NBdXkG3EgJs6V2Mcvla9+oykmuwtdgoCm2uYtFQFwSnYiaTOcwEY8h1i4kvIr9wag15H1rXBZaDsjYwxSB+ah2CCwSS9SFNhMGD0JL1IU2EwYPQJcUvqe3/jtHGJPSfQlIM/Q==", "wiGWz");
    llIIIlIlllIIIl[llIIIlIllllIll[66]] = lIIIIlIIlIIIIIII("Cxyu+IzqPm14nA+gw9usLdjtl8VEyq1aPGFyMBmaUUc3gT64PmkmBaRi/PRX4pbL6s+5NSMWOJw=", "yVPHZ");
    llIIIlIlllIIIl[llIIIlIllllIll[67]] = lIIIIlIIIlllllll("Xvmi5g6Rph7O3cwsqWBr2MOFD1SbKNFwkbfdRnHn8aXMftJPxpGN9s8gpVDlTOJsgXygub3+h8Y=", "PXzAJ");
    llIIIlIllllIlI = null;
  }
  
  private static void lIIIIlIIlIIlIIll() {
    String str = (new Exception()).getStackTrace()[llIIIlIllllIll[0]].getFileName();
    llIIIlIllllIlI = str.substring(str.indexOf("ä") + llIIIlIllllIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIlIIIIIII(String lllllllllllllllIllIlIIlllllllIIl, String lllllllllllllllIllIlIIlllllllIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIllllllllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlllllllIII.getBytes(StandardCharsets.UTF_8)), llIIIlIllllIll[9]), "DES");
      Cipher lllllllllllllllIllIlIIlllllllIll = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIlllllllIll.init(llIIIlIllllIll[2], lllllllllllllllIllIlIIllllllllII);
      return new String(lllllllllllllllIllIlIIlllllllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlllllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlllllllIlI) {
      lllllllllllllllIllIlIIlllllllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIlIIIIIIl(String lllllllllllllllIllIlIIllllllIllI, String lllllllllllllllIllIlIIllllllIlIl) {
    lllllllllllllllIllIlIIllllllIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIllllllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIllllllIlII = new StringBuilder();
    char[] lllllllllllllllIllIlIIllllllIIll = lllllllllllllllIllIlIIllllllIlIl.toCharArray();
    int lllllllllllllllIllIlIIllllllIIlI = llIIIlIllllIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIllllllIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIllllIll[0];
    while (lIIIIlIIlIIlIllI(j, i)) {
      char lllllllllllllllIllIlIIllllllIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIllllllIIlI++;
      j++;
      "".length();
      if ("   ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIllllllIlII);
  }
  
  private static String lIIIIlIIIlllllll(String lllllllllllllllIllIlIIlllllIlllI, String lllllllllllllllIllIlIIlllllIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIllllllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlllllIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIllllllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIllllllIIII.init(llIIIlIllllIll[2], lllllllllllllllIllIlIIllllllIIIl);
      return new String(lllllllllllllllIllIlIIllllllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlllllIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlllllIllll) {
      lllllllllllllllIllIlIIlllllIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIlIIlIlII() {
    llIIIlIllllIll = new int[69];
    llIIIlIllllIll[0] = ((0x34 ^ 0x57) << " ".length() ^ 155 + 67 - 78 + 21) & (0x6F ^ 0x62 ^ (0x9F ^ 0xA8) << " ".length() ^ -" ".length());
    llIIIlIllllIll[1] = " ".length();
    llIIIlIllllIll[2] = " ".length() << " ".length();
    llIIIlIllllIll[3] = "   ".length();
    llIIIlIllllIll[4] = " ".length() << " ".length() << " ".length();
    llIIIlIllllIll[5] = 29 + 103 - 32 + 53 ^ (0xB5 ^ 0x92) << " ".length() << " ".length();
    llIIIlIllllIll[6] = "   ".length() << " ".length();
    llIIIlIllllIll[7] = 0x96 ^ 0x91;
    llIIIlIllllIll[8] = 0x8A ^ 0x83;
    llIIIlIllllIll[9] = " ".length() << "   ".length();
    llIIIlIllllIll[10] = (0x8D ^ 0x90) << " ".length();
    llIIIlIllllIll[11] = (0x9E ^ 0x95) << " ".length();
    llIIIlIllllIll[12] = (0x15 ^ 0x56 ^ (0x12 ^ 0x31) << " ".length()) << " ".length();
    llIIIlIllllIll[13] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIlIllllIll[14] = 0x97 ^ 0x9C;
    llIIIlIllllIll[15] = "   ".length() << " ".length() << " ".length();
    llIIIlIllllIll[16] = 81 + 73 - 81 + 102 ^ (0x29 ^ 0x72) << " ".length();
    llIIIlIllllIll[17] = 0x20 ^ 0x51 ^ (0x9F ^ 0x80) << " ".length() << " ".length();
    llIIIlIllllIll[18] = (0xAA ^ 0xAD) << " ".length();
    llIIIlIllllIll[19] = ((0x23 ^ 0x3A) << "   ".length() ^ 153 + 65 - 194 + 169) << " ".length() << " ".length();
    llIIIlIllllIll[20] = (0xDD ^ 0x96) << " ".length() ^ 108 + 99 - 178 + 124;
    llIIIlIllllIll[21] = (0x5C ^ 0x3B ^ (0x86 ^ 0xB7) << " ".length()) << "   ".length();
    llIIIlIllllIll[22] = 0xCB ^ 0xAC ^ (0x38 ^ 0x3) << " ".length();
    llIIIlIllllIll[23] = (" ".length() << "   ".length() << " ".length() ^ 0x29 ^ 0x60) << " ".length();
    llIIIlIllllIll[24] = 0xB5 ^ 0x9E;
    llIIIlIllllIll[25] = 0xAC ^ 0xBF;
    llIIIlIllllIll[26] = (0x26 ^ 0x3D) << " ".length() ^ 0xDD ^ 0xC6;
    llIIIlIllllIll[27] = (0xA8 ^ 0xAD) << " ".length() << " ".length();
    llIIIlIllllIll[28] = 0x3C ^ 0x21;
    llIIIlIllllIll[29] = 0x48 ^ 0x7B ^ (0xD6 ^ 0xC5) << " ".length();
    llIIIlIllllIll[30] = (0x0 ^ 0x11) << " ".length();
    llIIIlIllllIll[31] = 0x5D ^ 0x4A;
    llIIIlIllllIll[32] = "   ".length() << "   ".length();
    llIIIlIllllIll[33] = 0xE ^ 0x39;
    llIIIlIllllIll[34] = (0x1F ^ 0x6) << " ".length();
    llIIIlIllllIll[35] = (0xF7 ^ 0xBE ^ (0x1A ^ 0xB) << " ".length() << " ".length()) << " ".length();
    llIIIlIllllIll[36] = 0x44 ^ 0x5F;
    llIIIlIllllIll[37] = ((0xBC ^ 0xAF) << " ".length() ^ 0x77 ^ 0x56) << " ".length() << " ".length();
    llIIIlIllllIll[38] = 0x12 ^ 0x31;
    llIIIlIllllIll[39] = 0x7 ^ 0x18;
    llIIIlIllllIll[40] = (0x13 ^ 0x1C) << " ".length();
    llIIIlIllllIll[41] = (155 + 165 - 173 + 26 ^ (0x41 ^ 0x1E) << " ".length()) << " ".length();
    llIIIlIllllIll[42] = " ".length() << (0x3E ^ 0x3B);
    llIIIlIllllIll[43] = 0x48 ^ 0x69;
    llIIIlIllllIll[44] = (0x46 ^ 0x41) << " ".length() ^ 0x6B ^ 0x50;
    llIIIlIllllIll[45] = (0x7B ^ 0x2E ^ (0x57 ^ 0x7E) << " ".length()) << "   ".length();
    llIIIlIllllIll[46] = (0xDE ^ 0x9B) << " ".length() ^ 63 + 163 - 183 + 132;
    llIIIlIllllIll[47] = 0x2F ^ 0x76 ^ (0xA5 ^ 0x9A) << " ".length();
    llIIIlIllllIll[48] = ((0xBC ^ 0x91) << " ".length() << " ".length() ^ 68 + 5 - 33 + 123) << " ".length();
    llIIIlIllllIll[49] = 0x2F ^ 0x6;
    llIIIlIllllIll[50] = (0xBF ^ 0xAA) << " ".length();
    llIIIlIllllIll[51] = (" ".length() << " ".length() ^ 0x14 ^ 0x1D) << " ".length() << " ".length();
    llIIIlIllllIll[52] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIlIllllIll[53] = 0x23 ^ 0xC;
    llIIIlIllllIll[54] = (0x21 ^ 0x3A) << " ".length();
    llIIIlIllllIll[55] = 0x3C ^ 0xD;
    llIIIlIllllIll[56] = 0x2B ^ 0x18;
    llIIIlIllllIll[57] = ((0x6D ^ 0x7C) << "   ".length() ^ 68 + 29 - 68 + 104) << " ".length() << " ".length();
    llIIIlIllllIll[58] = 34 + 95 - 117 + 139 ^ (0x4B ^ 0x1C) << " ".length();
    llIIIlIllllIll[59] = 0x86 ^ 0xBD;
    llIIIlIllllIll[60] = (0xA4 ^ 0xAB) << " ".length() << " ".length();
    llIIIlIllllIll[61] = (0x7A ^ 0x75) << " ".length() << " ".length() ^ " ".length();
    llIIIlIllllIll[62] = (0xFA ^ 0xA3 ^ (0x15 ^ 0x36) << " ".length()) << " ".length();
    llIIIlIllllIll[63] = 0x57 ^ 0x68;
    llIIIlIllllIll[64] = " ".length() << "   ".length() << " ".length();
    llIIIlIllllIll[65] = (0x59 ^ 0x2C) << " ".length() ^ 79 + 110 - 49 + 31;
    llIIIlIllllIll[66] = ((0x3A ^ 0x69) << " ".length() ^ 12 + 69 - -26 + 28) << " ".length();
    llIIIlIllllIll[67] = 0x0 ^ 0x43;
    llIIIlIllllIll[68] = ((0x3E ^ 0x19) << " ".length() ^ 0xE0 ^ 0xBF) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIlIIlIIllIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIlIIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIlIIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIIlIIlIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlIIlIIllIIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlIIlIIllIII(int paramInt) {
    return (paramInt < 0);
  }
  
  private static int lIIIIlIIlIIlIlIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\aj.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */