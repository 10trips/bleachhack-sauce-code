package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

public class f1000000 extends au {
  public f100000000000000000000.Boolean armor;
  
  f100000000000000000000.Boolean fire;
  
  f100000000000000000000.Boolean blind;
  
  f100000000000000000000.Boolean nausea;
  
  public static f100000000000000000000.Boolean hurtCam;
  
  public f100000000000000000000.Boolean noOverlay;
  
  f100000000000000000000.Boolean noBossBar;
  
  public f100000000000000000000.Boolean noSkylight;
  
  @EventHandler
  public Listener<RenderBlockOverlayEvent> blockOverlayEventListener;
  
  @EventHandler
  private final Listener<EntityViewRenderEvent.FogDensity> fogDensityListener;
  
  @EventHandler
  private final Listener<RenderBlockOverlayEvent> renderBlockOverlayEventListener;
  
  @EventHandler
  private final Listener<RenderGameOverlayEvent> renderGameOverlayEventListener;
  
  @EventHandler
  private final Listener<f09> bossbarEventListener;
  
  private static String[] lIllIlIIlIIIIl;
  
  private static Class[] lIllIlIIlIIIlI;
  
  private static final String[] lIllIlIlIlllIl;
  
  private static String[] lIllIlIllIIIII;
  
  private static final int[] lIllIlIllIIlII;
  
  public f1000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: aload_0
    //   47: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000;)Lme/zero/alpine/listener/EventHook;
    //   52: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   55: iconst_0
    //   56: iaload
    //   57: anewarray java/util/function/Predicate
    //   60: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   63: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1000000;Lme/zero/alpine/listener/Listener;)V
    //   68: aload_0
    //   69: new me/zero/alpine/listener/Listener
    //   72: dup
    //   73: aload_0
    //   74: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000;)Lme/zero/alpine/listener/EventHook;
    //   79: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   82: iconst_0
    //   83: iaload
    //   84: anewarray java/util/function/Predicate
    //   87: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   90: putfield fogDensityListener : Lme/zero/alpine/listener/Listener;
    //   93: aload_0
    //   94: new me/zero/alpine/listener/Listener
    //   97: dup
    //   98: aload_0
    //   99: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000;)Lme/zero/alpine/listener/EventHook;
    //   104: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   107: iconst_0
    //   108: iaload
    //   109: anewarray java/util/function/Predicate
    //   112: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   115: putfield renderBlockOverlayEventListener : Lme/zero/alpine/listener/Listener;
    //   118: aload_0
    //   119: new me/zero/alpine/listener/Listener
    //   122: dup
    //   123: aload_0
    //   124: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000;)Lme/zero/alpine/listener/EventHook;
    //   129: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   132: iconst_0
    //   133: iaload
    //   134: anewarray java/util/function/Predicate
    //   137: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   140: putfield renderGameOverlayEventListener : Lme/zero/alpine/listener/Listener;
    //   143: aload_0
    //   144: new me/zero/alpine/listener/Listener
    //   147: dup
    //   148: aload_0
    //   149: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000;)Lme/zero/alpine/listener/EventHook;
    //   154: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   157: iconst_0
    //   158: iaload
    //   159: anewarray java/util/function/Predicate
    //   162: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   165: putfield bossbarEventListener : Lme/zero/alpine/listener/Listener;
    //   168: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	169	0	lllllllllllllllIllllIlIlIIllllIl	Lme/stupitdog/bhp/f1000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   14: iconst_0
    //   15: iaload
    //   16: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   21: <illegal opcode> 3 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   26: aload_0
    //   27: aload_0
    //   28: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   34: iconst_4
    //   35: iaload
    //   36: aaload
    //   37: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   40: iconst_0
    //   41: iaload
    //   42: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   47: <illegal opcode> 4 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   52: aload_0
    //   53: aload_0
    //   54: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   57: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   60: iconst_5
    //   61: iaload
    //   62: aaload
    //   63: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   66: iconst_0
    //   67: iaload
    //   68: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   73: <illegal opcode> 5 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   78: aload_0
    //   79: aload_0
    //   80: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   83: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   86: bipush #6
    //   88: iaload
    //   89: aaload
    //   90: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   93: iconst_0
    //   94: iaload
    //   95: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   100: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   105: aload_0
    //   106: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   109: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   112: bipush #7
    //   114: iaload
    //   115: aaload
    //   116: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   119: iconst_0
    //   120: iaload
    //   121: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   126: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   131: aload_0
    //   132: aload_0
    //   133: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   136: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   139: bipush #8
    //   141: iaload
    //   142: aaload
    //   143: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   146: iconst_0
    //   147: iaload
    //   148: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   153: <illegal opcode> 8 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   158: aload_0
    //   159: aload_0
    //   160: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   163: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   166: bipush #9
    //   168: iaload
    //   169: aaload
    //   170: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   173: iconst_0
    //   174: iaload
    //   175: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   180: <illegal opcode> 9 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   185: aload_0
    //   186: aload_0
    //   187: getstatic me/stupitdog/bhp/f1000000.lIllIlIlIlllIl : [Ljava/lang/String;
    //   190: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   193: bipush #10
    //   195: iaload
    //   196: aaload
    //   197: getstatic me/stupitdog/bhp/f1000000.lIllIlIllIIlII : [I
    //   200: iconst_0
    //   201: iaload
    //   202: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   207: <illegal opcode> 10 : (Lme/stupitdog/bhp/f1000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   212: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	213	0	lllllllllllllllIllllIlIlIIllllII	Lme/stupitdog/bhp/f1000000;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 11 : (Lme/stupitdog/bhp/f1000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: invokestatic llllIlIIIIIIlII : (I)Z
    //   14: ifeq -> 63
    //   17: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 15 : ()Lnet/minecraft/potion/Potion;
    //   32: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   37: invokestatic llllIlIIIIIIlII : (I)Z
    //   40: ifeq -> 63
    //   43: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   48: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   53: <illegal opcode> 15 : ()Lnet/minecraft/potion/Potion;
    //   58: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)V
    //   63: aload_0
    //   64: <illegal opcode> 18 : (Lme/stupitdog/bhp/f1000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   69: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   74: invokestatic llllIlIIIIIIlII : (I)Z
    //   77: ifeq -> 126
    //   80: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   85: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   90: <illegal opcode> 19 : ()Lnet/minecraft/potion/Potion;
    //   95: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   100: invokestatic llllIlIIIIIIlII : (I)Z
    //   103: ifeq -> 126
    //   106: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   111: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   116: <illegal opcode> 19 : ()Lnet/minecraft/potion/Potion;
    //   121: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)V
    //   126: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	127	0	lllllllllllllllIllllIlIlIIlllIll	Lme/stupitdog/bhp/f1000000;
  }
  
  static {
    llllIlIIIIIIIll();
    llllIIllllIlIIl();
    llllIIllllIlIII();
    llllIIllllIIIlI();
  }
  
  private static CallSite llllIIlIlIlIlll(MethodHandles.Lookup lllllllllllllllIllllIlIlIIlIlIII, String lllllllllllllllIllllIlIlIIlIIlll, MethodType lllllllllllllllIllllIlIlIIlIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIlIlIIlIlllI = lIllIlIIlIIIIl[Integer.parseInt(lllllllllllllllIllllIlIlIIlIIlll)].split(lIllIlIlIlllIl[lIllIlIllIIlII[11]]);
      Class<?> lllllllllllllllIllllIlIlIIlIllIl = Class.forName(lllllllllllllllIllllIlIlIIlIlllI[lIllIlIllIIlII[0]]);
      String lllllllllllllllIllllIlIlIIlIllII = lllllllllllllllIllllIlIlIIlIlllI[lIllIlIllIIlII[1]];
      MethodHandle lllllllllllllllIllllIlIlIIlIlIll = null;
      int lllllllllllllllIllllIlIlIIlIlIlI = lllllllllllllllIllllIlIlIIlIlllI[lIllIlIllIIlII[3]].length();
      if (llllIlIIIIIIlll(lllllllllllllllIllllIlIlIIlIlIlI, lIllIlIllIIlII[2])) {
        MethodType lllllllllllllllIllllIlIlIIllIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlIlIIlIlllI[lIllIlIllIIlII[2]], f1000000.class.getClassLoader());
        if (llllIlIIIIIlIII(lllllllllllllllIllllIlIlIIlIlIlI, lIllIlIllIIlII[2])) {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findVirtual(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIllIIII);
          "".length();
          if (((0xD0 ^ 0xC5 ^ (0x28 ^ 0x13) << " ".length()) & ((0x18 ^ 0x1D) << " ".length() << " ".length() << " ".length() ^ 0x65 ^ 0x56 ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findStatic(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIllIIII);
        } 
        "".length();
        if ("   ".length() == " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIlIlIIlIllll = lIllIlIIlIIIlI[Integer.parseInt(lllllllllllllllIllllIlIlIIlIlllI[lIllIlIllIIlII[2]])];
        if (llllIlIIIIIlIII(lllllllllllllllIllllIlIlIIlIlIlI, lIllIlIllIIlII[3])) {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findGetter(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIlIllll);
          "".length();
          if (" ".length() == -" ".length())
            return null; 
        } else if (llllIlIIIIIlIII(lllllllllllllllIllllIlIlIIlIlIlI, lIllIlIllIIlII[4])) {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findStaticGetter(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIlIllll);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else if (llllIlIIIIIlIII(lllllllllllllllIllllIlIlIIlIlIlI, lIllIlIllIIlII[5])) {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findSetter(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIlIllll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllllIlIlIIlIlIll = lllllllllllllllIllllIlIlIIlIlIII.findStaticSetter(lllllllllllllllIllllIlIlIIlIllIl, lllllllllllllllIllllIlIlIIlIllII, lllllllllllllllIllllIlIlIIlIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIlIlIIlIlIll);
    } catch (Exception lllllllllllllllIllllIlIlIIlIlIIl) {
      lllllllllllllllIllllIlIlIIlIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIllllIIIlI() {
    lIllIlIIlIIIIl = new String[lIllIlIllIIlII[12]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[13]] = lIllIlIlIlllIl[lIllIlIllIIlII[14]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[15]] = lIllIlIlIlllIl[lIllIlIllIIlII[16]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[1]] = lIllIlIlIlllIl[lIllIlIllIIlII[17]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[18]] = lIllIlIlIlllIl[lIllIlIllIIlII[19]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[20]] = lIllIlIlIlllIl[lIllIlIllIIlII[20]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[3]] = lIllIlIlIlllIl[lIllIlIllIIlII[21]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[6]] = lIllIlIlIlllIl[lIllIlIllIIlII[22]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[4]] = lIllIlIlIlllIl[lIllIlIllIIlII[23]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[14]] = lIllIlIlIlllIl[lIllIlIllIIlII[24]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[25]] = lIllIlIlIlllIl[lIllIlIllIIlII[26]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[27]] = lIllIlIlIlllIl[lIllIlIllIIlII[28]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[29]] = lIllIlIlIlllIl[lIllIlIllIIlII[30]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[19]] = lIllIlIlIlllIl[lIllIlIllIIlII[13]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[31]] = lIllIlIlIlllIl[lIllIlIllIIlII[32]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[0]] = lIllIlIlIlllIl[lIllIlIllIIlII[25]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[16]] = lIllIlIlIlllIl[lIllIlIllIIlII[27]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[33]] = lIllIlIlIlllIl[lIllIlIllIIlII[34]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[35]] = lIllIlIlIlllIl[lIllIlIllIIlII[29]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[10]] = lIllIlIlIlllIl[lIllIlIllIIlII[36]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[7]] = lIllIlIlIlllIl[lIllIlIllIIlII[37]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[21]] = lIllIlIlIlllIl[lIllIlIllIIlII[35]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[24]] = lIllIlIlIlllIl[lIllIlIllIIlII[38]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[22]] = lIllIlIlIlllIl[lIllIlIllIIlII[31]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[2]] = lIllIlIlIlllIl[lIllIlIllIIlII[15]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[32]] = lIllIlIlIlllIl[lIllIlIllIIlII[33]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[39]] = lIllIlIlIlllIl[lIllIlIllIIlII[40]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[30]] = lIllIlIlIlllIl[lIllIlIllIIlII[41]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[34]] = lIllIlIlIlllIl[lIllIlIllIIlII[39]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[8]] = lIllIlIlIlllIl[lIllIlIllIIlII[18]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[38]] = lIllIlIlIlllIl[lIllIlIllIIlII[12]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[5]] = lIllIlIlIlllIl[lIllIlIllIIlII[42]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[26]] = lIllIlIlIlllIl[lIllIlIllIIlII[43]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[37]] = lIllIlIlIlllIl[lIllIlIllIIlII[44]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[11]] = lIllIlIlIlllIl[lIllIlIllIIlII[45]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[9]] = lIllIlIlIlllIl[lIllIlIllIIlII[46]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[23]] = lIllIlIlIlllIl[lIllIlIllIIlII[47]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[41]] = lIllIlIlIlllIl[lIllIlIllIIlII[48]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[36]] = lIllIlIlIlllIl[lIllIlIllIIlII[49]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[17]] = lIllIlIlIlllIl[lIllIlIllIIlII[50]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[28]] = lIllIlIlIlllIl[lIllIlIllIIlII[51]];
    lIllIlIIlIIIIl[lIllIlIllIIlII[40]] = lIllIlIlIlllIl[lIllIlIllIIlII[52]];
    lIllIlIIlIIIlI = new Class[lIllIlIllIIlII[9]];
    lIllIlIIlIIIlI[lIllIlIllIIlII[5]] = Potion.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[8]] = RenderBlockOverlayEvent.OverlayType.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[6]] = RenderGameOverlayEvent.ElementType.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[7]] = Material.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[3]] = Minecraft.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[2]] = f100000000000000000000.Boolean.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[0]] = f13.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[4]] = EntityPlayerSP.class;
    lIllIlIIlIIIlI[lIllIlIllIIlII[1]] = Listener.class;
  }
  
  private static void llllIIllllIlIII() {
    lIllIlIlIlllIl = new String[lIllIlIllIIlII[53]];
    lIllIlIlIlllIl[lIllIlIllIIlII[0]] = llllIIllllIIIll(lIllIlIllIIIII[lIllIlIllIIlII[0]], lIllIlIllIIIII[lIllIlIllIIlII[1]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[1]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[2]], lIllIlIllIIIII[lIllIlIllIIlII[3]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[2]] = llllIIllllIIlIl(lIllIlIllIIIII[lIllIlIllIIlII[4]], lIllIlIllIIIII[lIllIlIllIIlII[5]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[3]] = llllIIllllIIlIl(lIllIlIllIIIII[lIllIlIllIIlII[6]], lIllIlIllIIIII[lIllIlIllIIlII[7]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[4]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[8]], lIllIlIllIIIII[lIllIlIllIIlII[9]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[5]] = llllIIllllIIIll(lIllIlIllIIIII[lIllIlIllIIlII[10]], lIllIlIllIIIII[lIllIlIllIIlII[11]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[6]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[14]], lIllIlIllIIIII[lIllIlIllIIlII[16]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[7]] = llllIIllllIIIll(lIllIlIllIIIII[lIllIlIllIIlII[17]], lIllIlIllIIIII[lIllIlIllIIlII[19]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[8]] = llllIIllllIIIll(lIllIlIllIIIII[lIllIlIllIIlII[20]], lIllIlIllIIIII[lIllIlIllIIlII[21]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[9]] = llllIIllllIIlIl(lIllIlIllIIIII[lIllIlIllIIlII[22]], lIllIlIllIIIII[lIllIlIllIIlII[23]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[10]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[24]], lIllIlIllIIIII[lIllIlIllIIlII[26]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[11]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[28]], lIllIlIllIIIII[lIllIlIllIIlII[30]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[14]] = llllIIllllIIlIl(lIllIlIllIIIII[lIllIlIllIIlII[13]], lIllIlIllIIIII[lIllIlIllIIlII[32]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[16]] = llllIIllllIIlII(lIllIlIllIIIII[lIllIlIllIIlII[25]], lIllIlIllIIIII[lIllIlIllIIlII[27]]);
    lIllIlIlIlllIl[lIllIlIllIIlII[17]] = llllIIllllIIlII("HxVeMAYHABk3Fh0XXiEaAl4WckJCQEBzQkgSHCwRGT8GJgAeEQkGBBceBA8bAQQVLRcASkF5UlJQUGM=", "rppCr");
    lIllIlIlIlllIl[lIllIlIllIIlII[19]] = llllIIllllIIIll("/TJXEGi95cselWc4hCXqYdI/+M9YCwzqFWvrZcNe/W+FgmD3q+O4v4NXfBtipi9nB/O11h9VUAxJsd4aLjUCBPGGUTHMHz71vkjc1O1qNzQnAf8vz0XePQ==", "EOvln");
    lIllIlIlIlllIl[lIllIlIllIIlII[20]] = llllIIllllIIlII("NiggbCsxIzEhNDkrIGwlNCQxLDJ2KDo2Lyw0egcoLCQgOxY0LC0nNAsdbiQzNi4LdXZueWAdJ2JlGCwjLGI5Kyg9LiYjICxiJC0yMSI6bRY3OT0tKGNkDnhmeA==", "XMTBF");
    lIllIlIlIlllIl[lIllIlIllIIlII[21]] = llllIIllllIIIll("q2u3/2Ip48L2a3vDI6fnTZhpVlywh2VbccX7HXdL+Ac/SbNpxQAQ7Q==", "SnjAP");
    lIllIlIlIlllIl[lIllIlIllIIlII[22]] = llllIIllllIIIll("6xdP5q0giPLcDXUbten3AD6Pp2UmK8XD9dpuklvjicNsFrdo/WyfceJ+/kwawkpe", "RnmmP");
    lIllIlIlIlllIl[lIllIlIllIIlII[23]] = llllIIllllIIlII("KyJrPDgzNyw7KCkgay0kNmkjfnx2d3V/fHwhLD0pfHV/b2xmZ2U=", "FGEOL");
    lIllIlIlIlllIl[lIllIlIllIIlII[24]] = llllIIllllIIlII("OA1YGS4gGB8ePjoPWAgyJUYQW2plWEZaamVYRlpqZVhGWmplWEZafhcHGQY/NAZMDT8hPhcGLzBSXkMAb0hW", "UhvjZ");
    lIllIlIlIlllIl[lIllIlIllIIlII[26]] = llllIIllllIIlIl("r8plJf2O4X53YHcOREESmm73DKFrueMCHI3e74XEwiz7+xNTr1W3rpGwK31zg+u+TJiEmimkPq5ZN7GfCBpRdjcW+50avbrwDDGXa0FHvQ8=", "sIqpi");
    lIllIlIlIlllIl[lIllIlIllIIlII[28]] = llllIIllllIIIll("4Ehpcx2nN+wRM+s9/N/VP2oHamsqwNnAnSmLXLuFz9aPpFRrLsOtYr3Vt6wz0Fb7LjGNRJpC091ln9uyQIMhapd1YniSwgMbaJ8qU2tYruUGpF7/wH8o8g==", "iXfJS");
    lIllIlIlIlllIl[lIllIlIllIIlII[30]] = llllIIllllIIlII("OwcmYRw8DDcsAzQEJikeJwU3YRI5CzchBXsHJCofIUwXIQU8FisZGDAVACofMQcgCgcwDCZrNzoFFiofJgsmNksyByYcBTQWN3VZfC48KgV6DzshFDYQMykFegA+IBI+TSE7ECEHfQYzOQ0xJCIhAyYqSm9Ccg==", "UbROq");
    lIllIlIlIlllIl[lIllIlIllIIlII[13]] = llllIIllllIIIll("J6u67fep+iiwyxiPNIJkc9gY4OfwtFN5UoX8h5bDdY8x+ODrQQiG8vXLVQ9wTgoBR9WdWftfXvk=", "aaVup");
    lIllIlIlIlllIl[lIllIlIllIIlII[32]] = llllIIllllIIlIl("YYuX0H3zhdlIxks4mQBvyA5DSiTD36pRBi+gphJIPp7bLs1DBxU2tpe7isweABi056ElKMj/rZlW//UxBez5yNbx5E5v6ADCYy7xi5QJdwmRa4fmsd7k5g==", "iEFTJ");
    lIllIlIlIlllIl[lIllIlIllIIlII[25]] = llllIIllllIIIll("JCZbf+4amS2qE9neRvZUtFHYV1YQZylo2JdwSpX4kgy4C/kR2jwZgQ==", "YggkJ");
    lIllIlIlIlllIl[lIllIlIllIIlII[27]] = llllIIllllIIlIl("QfS8kt4VuuUSbr96IQ5SyUAu9tisfDpDlNcvNeCNKMmW1Fvr1oev7A==", "QIRSS");
    lIllIlIlIlllIl[lIllIlIllIIlII[34]] = llllIIllllIIlIl("/uhVY9AshOCKrBpyCAIJCx9b537dmXGGplG5omdyGaNz4Ps/uHqmjQ==", "EZIYg");
    lIllIlIlIlllIl[lIllIlIllIIlII[29]] = llllIIllllIIlII("Mic8B0s0JyQBSxckIAMGLHwvFxA5KjlcTRQsKxAEdyorCAJ3CSgMADsycU8/YmZq", "XFJfe");
    lIllIlIlIlllIl[lIllIlIllIIlII[36]] = llllIIllllIIIll("FKg2aN/49gmnGwlZJD7sn65Qtv6jKGTgj1BWFdjO3IBmtq7QdVzZ7uvuiqwng6CW", "qKlof");
    lIllIlIlIlllIl[lIllIlIllIIlII[37]] = llllIIllllIIlII("By1fCycfOBgMNwUvXxo7GmYXSWNaeEFIY1AgBAonKSkcQmFQaFFYc0po", "jHqxS");
    lIllIlIlIlllIl[lIllIlIllIIlII[35]] = llllIIllllIIlII("KyQmWxQsLzcWCyQnJlsaKSg3Gw1rJDwBEDE4fDAXMSgmDCkpICsQCxYRaBMMKyINREFxdGpMJiF7ejkXIDV9GBArJDEHGCM1fQUWMSg9G1YVLiYcFit6eyNDZWE=", "EARuy");
    lIllIlIlIlllIl[lIllIlIllIIlII[38]] = llllIIllllIIlIl("iwV+Cg7QENGDjxXQBVahNayAdKgEWvYkVNeXhJVzoSxDU/4gxHdKLk8Vh1jLrJk0", "dpGtz");
    lIllIlIlIlllIl[lIllIlIllIIlII[31]] = llllIIllllIIlII("CShrNDoRPSwzKgsqayUmFGMjdn5UfXV3fl4jJDI9ASx/dXREbWU=", "dMEGN");
    lIllIlIlIlllIl[lIllIlIllIIlII[15]] = llllIIllllIIIll("BfvuNgZAdAFt1ue6SQsZJ1Z4YqlEw4AMrWQF6mmSQcjeAE+PDP5Yuhx2bZpPp1Uii/qnP/VbcbA36+7LK1gM2NxGDge/JMo2/XdHtGWIdkpvahccrG3BrcX6MvOOcgzGfzpRxDLJfzKIFk6ZPj4ttfcI6/YAQY89", "AWWuv");
    lIllIlIlIlllIl[lIllIlIllIIlII[33]] = llllIIllllIIIll("R5amvsApGMSFSzoHox+kT2vdL/VuP+qS9ZLtsqVDiKwEAt0qeD+tJ9Czb0VTBUlmeQaKL8GW0kkYKfrGtLcmNO6neYPuSCuxLJVhE4j3hR2QuyDbqCDivb4nAcF7HKbMO4tuBndoWns=", "YrJcB");
    lIllIlIlIlllIl[lIllIlIllIIlII[40]] = llllIIllllIIIll("t8bIh3g3Y3PR3rBj3bi275KyMLo/Pqz2uWDjxfcNFBxCxImCJQTl1lqmECygLEIToeEljgssxfLHj/6mMvE8B8MZ8nwidLRRUS2DslyT6D8MA0NK3OeTrA==", "VFBVS");
    lIllIlIlIlllIl[lIllIlIllIIlII[41]] = llllIIllllIIlIl("L7jGwB1FcP6JtGqatstmWjh6FjqqF+zcLrbQqeHvHR1SpsnYvxmiaJax+t5JNz3UlcT7dzzBWffXNo8FHjUY8SdcHPpxtsH/ceJHfGN7Aj3anMDdoiQClber0ZRGCz/rgl2Vf1lBkArNHVCBArVRM0o7r1XoGWGvSGbsn5m7WG+jhqic+OnuHvrE16JUoLgO", "rdAQQ");
    lIllIlIlIlllIl[lIllIlIllIIlII[39]] = llllIIllllIIlIl("lPXxcq/CEOu3Qi5k5vTqQPy9S6GfKW4zEkvdmmdG71nS4+A3LvFElc6ITmDIfl1eKed0HWICDmrax9LbrdcqmbakuHSlcHuVioI7oo0BBQ8=", "xVCQN");
    lIllIlIlIlllIl[lIllIlIllIIlII[18]] = llllIIllllIIlIl("+T/vdfSGV4BzOTIwiOsWZS2LSWOlIaVsKuqOxvTI8OGzlfHAOkKsfjxv3XyhWY9u", "DNkOa");
    lIllIlIlIlllIl[lIllIlIllIIlII[12]] = llllIIllllIIlIl("ax3mlf1FuWPPV7ek3lsLpxKPvWHh0X8672s2LfyMdvMVcjpJLKwQx4tEv45MryQ3MkQY15wBn7JTDVcwUHEHGw==", "UaSXn");
    lIllIlIlIlllIl[lIllIlIllIIlII[42]] = llllIIllllIIlII("GihePDECPRk7IRgqXi0tB2MWfnVHfUB/dU0vHCYrE3dCdWVXbVBv", "wMpOE");
    lIllIlIlIlllIl[lIllIlIllIIlII[43]] = llllIIllllIIlIl("TANJ5JsreV/gZyKaXp0/OaKnAe5uPRI4vkqeKcj0d/mcWg9eoANucA==", "VangY");
    lIllIlIlIlllIl[lIllIlIllIIlII[44]] = llllIIllllIIlII("KgIQYiQtCQEvOyUBEGIrKAgHJ2cpBhApOy0GCGIEJRMBPiAlC14qICELABN4cVZRdH8bD157c2RHRGw=", "DgdLI");
    lIllIlIlIlllIl[lIllIlIllIIlII[45]] = llllIIllllIIlII("OhxpKyQiCS4sNDgeaTo4J1chaWBnSXdoYG0bKzE+M0N1YnB3WQ==", "WyGXP");
    lIllIlIlIlllIl[lIllIlIllIIlII[46]] = llllIIllllIIlIl("TeHphLqWShwEDWSF9jfLKKm1k2hF8G3WlgCVRTadBucSTxAFv0HqhjrbBY9CB/mC", "TJavV");
    lIllIlIlIlllIl[lIllIlIllIIlII[47]] = llllIIllllIIlII("KQ0OShUuBh8HCiYODkoRKQEOSjUoCj8CHiILDhdCIQEfCBwYX0xQS3Y3EV5NfUhaRFg=", "Ghzdx");
    lIllIlIlIlllIl[lIllIlIllIIlII[48]] = llllIIllllIIIll("/Kz4i5ud1ZmDug3ke3c1Waza5RCcsTyjzGF6eWR5dRfy089OUwdYau64Ws4+zHr3+mxhJmPgQ5j0wHhkV/9OVI4YldkeHXd+x7HVzADEGKA=", "aLUeh");
    lIllIlIlIlllIl[lIllIlIllIIlII[49]] = llllIIllllIIIll("M4vSE611JtsVEQS6Z8VXVF71skbbHmuG51dMpXnroZmuPOTDoR35KjKrR/nXfZcD6Gd4EQzYJAKrlrR2mojFgKrAM/Q4eKpUcIywpj97DzFY31NOXxTdZ5CrsW05L32sHGTD4fwVB04=", "TddQl");
    lIllIlIlIlllIl[lIllIlIllIIlII[50]] = llllIIllllIIlIl("lSjcsKCRWR7nMb7iQWz47D3dd/HsYXP14jadvLKJBBahGABi7BBdVH09hfTLvzEcPHeVVwuhv1g=", "PDgFr");
    lIllIlIlIlllIl[lIllIlIllIIlII[51]] = llllIIllllIIIll("iA8e2YImUOwZ2S2iJRhsn+R4In0aEK1iLP2BQcbLXrYQzvg/f2OPp2uPa9N0XrmO", "cCRWh");
    lIllIlIlIlllIl[lIllIlIllIIlII[52]] = llllIIllllIIlII("CTwkXxkONzUSBgY/JBcbFT41XxcLMDUfAEk8JhQaE3cCFBoDPCIzGAg6Oz4CAis8EA0iLzUfAF0+NQU7ETwiHRUeDSkBEV1xeT0aAi1/HB0JPDMDFQEtNh4GADx/EhgOPD4FWwIvNR8ASAs1HxACKxIdGwQyHwcRFTUxCDERPD4FUCgvNQMYBiAECAQCYmpRVA==", "gYPqt");
    lIllIlIllIIIII = null;
  }
  
  private static void llllIIllllIlIIl() {
    String str = (new Exception()).getStackTrace()[lIllIlIllIIlII[0]].getFileName();
    lIllIlIllIIIII = str.substring(str.indexOf("ä") + lIllIlIllIIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIllllIIlIl(String lllllllllllllllIllllIlIlIIlIIIlI, String lllllllllllllllIllllIlIlIIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIlIIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIlIIlIIIIl.getBytes(StandardCharsets.UTF_8)), lIllIlIllIIlII[8]), "DES");
      Cipher lllllllllllllllIllllIlIlIIlIIlII = Cipher.getInstance("DES");
      lllllllllllllllIllllIlIlIIlIIlII.init(lIllIlIllIIlII[2], lllllllllllllllIllllIlIlIIlIIlIl);
      return new String(lllllllllllllllIllllIlIlIIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIlIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIlIIlIIIll) {
      lllllllllllllllIllllIlIlIIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIllllIIlII(String lllllllllllllllIllllIlIlIIIlllll, String lllllllllllllllIllllIlIlIIIllllI) {
    lllllllllllllllIllllIlIlIIIlllll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIlIlIIIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIlIlIIIlllIl = new StringBuilder();
    char[] lllllllllllllllIllllIlIlIIIlllII = lllllllllllllllIllllIlIlIIIllllI.toCharArray();
    int lllllllllllllllIllllIlIlIIIllIll = lIllIlIllIIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIlIlIIIlllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlIllIIlII[0];
    while (llllIlIIIIIlIIl(j, i)) {
      char lllllllllllllllIllllIlIlIIlIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIlIlIIIllIll++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIlIlIIIlllIl);
  }
  
  private static String llllIIllllIIIll(String lllllllllllllllIllllIlIlIIIlIlll, String lllllllllllllllIllllIlIlIIIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIlIIIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIlIIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIlIlIIIllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIlIlIIIllIIl.init(lIllIlIllIIlII[2], lllllllllllllllIllllIlIlIIIllIlI);
      return new String(lllllllllllllllIllllIlIlIIIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIlIIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIlIIIllIII) {
      lllllllllllllllIllllIlIlIIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIIIIIIll() {
    lIllIlIllIIlII = new int[54];
    lIllIlIllIIlII[0] = ((0xCC ^ 0xA5) << " ".length() ^ 158 + 112 - 265 + 194) << " ".length() << " ".length() & ((170 + 117 - 263 + 157 ^ (0x86 ^ 0x83) << (0xBC ^ 0xB9)) << " ".length() << " ".length() ^ -" ".length());
    lIllIlIllIIlII[1] = " ".length();
    lIllIlIllIIlII[2] = " ".length() << " ".length();
    lIllIlIllIIlII[3] = "   ".length();
    lIllIlIllIIlII[4] = " ".length() << " ".length() << " ".length();
    lIllIlIllIIlII[5] = 0x21 ^ 0x24;
    lIllIlIllIIlII[6] = "   ".length() << " ".length();
    lIllIlIllIIlII[7] = 0xB6 ^ 0xB1;
    lIllIlIllIIlII[8] = " ".length() << "   ".length();
    lIllIlIllIIlII[9] = (0xB4 ^ 0xB9) << "   ".length() ^ 0x52 ^ 0x33;
    lIllIlIllIIlII[10] = (12 + 95 - -33 + 7 ^ (0x56 ^ 0x1D) << " ".length()) << " ".length();
    lIllIlIllIIlII[11] = 0x3A ^ 0x75 ^ (0xA3 ^ 0xB2) << " ".length() << " ".length();
    lIllIlIllIIlII[12] = (0x43 ^ 0x7E) << " ".length() ^ 0x3A ^ 0x69;
    lIllIlIllIIlII[13] = "   ".length() << "   ".length();
    lIllIlIllIIlII[14] = "   ".length() << " ".length() << " ".length();
    lIllIlIllIIlII[15] = 10 + 81 - -5 + 39 ^ (0x1A ^ 0x33) << " ".length() << " ".length();
    lIllIlIllIIlII[16] = 27 + 165 - 183 + 160 ^ (0x28 ^ 0x1) << " ".length() << " ".length();
    lIllIlIllIIlII[17] = ((0x81 ^ 0x96) << " ".length() << " ".length() ^ 0x56 ^ 0xD) << " ".length();
    lIllIlIllIIlII[18] = ((0xF1 ^ 0xAA) << " ".length() ^ 173 + 157 - 164 + 13) << "   ".length();
    lIllIlIllIIlII[19] = 0xA7 ^ 0xA8;
    lIllIlIllIIlII[20] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIlIllIIlII[21] = 0x5C ^ 0x4D;
    lIllIlIllIIlII[22] = (49 + 94 - 26 + 12 ^ (0x54 ^ 0x45) << "   ".length()) << " ".length();
    lIllIlIllIIlII[23] = (0x25 ^ 0x4C) << " ".length() ^ 109 + 145 - 186 + 125;
    lIllIlIllIIlII[24] = (0x11 ^ 0x14) << " ".length() << " ".length();
    lIllIlIllIIlII[25] = (0x33 ^ 0x3E) << " ".length();
    lIllIlIllIIlII[26] = 0x34 ^ 0x21;
    lIllIlIllIIlII[27] = 0x7C ^ 0x41 ^ (0x22 ^ 0x31) << " ".length();
    lIllIlIllIIlII[28] = ((0x58 ^ 0x15) << " ".length() ^ 41 + 53 - -16 + 35) << " ".length();
    lIllIlIllIIlII[29] = 0xC ^ 0x3B ^ (0x45 ^ 0x50) << " ".length();
    lIllIlIllIIlII[30] = 0x46 ^ 0xD ^ (0x45 ^ 0x52) << " ".length() << " ".length();
    lIllIlIllIIlII[31] = (0x3D ^ 0x2 ^ (0x55 ^ 0x42) << " ".length()) << " ".length();
    lIllIlIllIIlII[32] = 0x2F ^ 0x36;
    lIllIlIllIIlII[33] = ((0x62 ^ 0x71) << "   ".length() ^ 67 + 140 - 143 + 81) << " ".length() << " ".length();
    lIllIlIllIIlII[34] = ((0xF4 ^ 0xB9) << " ".length() ^ 10 + 3 - 1 + 145) << " ".length() << " ".length();
    lIllIlIllIIlII[35] = " ".length() << (0x17 ^ 0x12);
    lIllIlIllIIlII[36] = (0x2F ^ 0x20) << " ".length();
    lIllIlIllIIlII[37] = 0x11 ^ 0xE;
    lIllIlIllIIlII[38] = 0x9D ^ 0xBC;
    lIllIlIllIIlII[39] = (0xB8 ^ 0xAD) << " ".length() << " ".length() ^ 0x4D ^ 0x3E;
    lIllIlIllIIlII[40] = " ".length() << (0x7E ^ 0x79) ^ 53 + 144 - 188 + 156;
    lIllIlIllIIlII[41] = (0x12 ^ 0x5 ^ " ".length() << " ".length() << " ".length()) << " ".length();
    lIllIlIllIIlII[42] = (0xBB ^ 0xA6 ^ " ".length() << "   ".length()) << " ".length();
    lIllIlIllIIlII[43] = 0x2 ^ 0x29;
    lIllIlIllIIlII[44] = (0xF ^ 0x62 ^ (0x79 ^ 0x4A) << " ".length()) << " ".length() << " ".length();
    lIllIlIllIIlII[45] = (0x5A ^ 0x11) << " ".length() ^ 122 + 143 - 177 + 99;
    lIllIlIllIIlII[46] = (0x8C ^ 0x9B) << " ".length();
    lIllIlIllIIlII[47] = 0x6D ^ 0x42;
    lIllIlIllIIlII[48] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIllIlIllIIlII[49] = 110 + 104 - 135 + 92 ^ (0x1A ^ 0x57) << " ".length();
    lIllIlIllIIlII[50] = (91 + 121 - 200 + 157 ^ (0x25 ^ 0x2E) << " ".length() << " ".length() << " ".length()) << " ".length();
    lIllIlIllIIlII[51] = 0x0 ^ 0x33;
    lIllIlIllIIlII[52] = (0x7B ^ 0x48 ^ (0x85 ^ 0x9A) << " ".length()) << " ".length() << " ".length();
    lIllIlIllIIlII[53] = 0x32 ^ 0x2B ^ (0x8B ^ 0x80) << " ".length() << " ".length();
  }
  
  private static boolean llllIlIIIIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIIIIIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIIIIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIIIIIIllI(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllIlIIIIIIlII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllIlIIIIIIlIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */