package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.profiler.Profiler;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class fr extends au {
  public static f100000000000000000000.Mode mode;
  
  public static f100000000000000000000.Boolean player;
  
  public static f100000000000000000000.Boolean animal;
  
  public static f100000000000000000000.Boolean mob;
  
  public static f100000000000000000000.Boolean donkey;
  
  public static f100000000000000000000.ColorSetting plrColor;
  
  public static f100000000000000000000.ColorSetting animalColor;
  
  public static f100000000000000000000.ColorSetting mobColor;
  
  public static f100000000000000000000.ColorSetting donkeyColor;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private static String[] lIlllIIIllIIII;
  
  private static Class[] lIlllIIIllIIIl;
  
  private static final String[] lIlllIIIllIIlI;
  
  private static String[] lIlllIIIllIIll;
  
  private static final int[] lIlllIIIllIlIl;
  
  public fr() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/fr;Lme/zero/alpine/listener/Listener;)V
    //   67: new java/util/ArrayList
    //   70: dup
    //   71: invokespecial <init> : ()V
    //   74: astore_1
    //   75: aload_1
    //   76: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   79: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   82: iconst_3
    //   83: iaload
    //   84: aaload
    //   85: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   90: ldc ''
    //   92: invokevirtual length : ()I
    //   95: pop2
    //   96: aload_1
    //   97: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   100: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   103: iconst_4
    //   104: iaload
    //   105: aaload
    //   106: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   111: ldc ''
    //   113: invokevirtual length : ()I
    //   116: pop2
    //   117: aload_0
    //   118: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   121: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   124: iconst_5
    //   125: iaload
    //   126: aaload
    //   127: aload_1
    //   128: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   131: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   134: bipush #6
    //   136: iaload
    //   137: aaload
    //   138: <illegal opcode> 3 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   143: <illegal opcode> 4 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   148: aload_0
    //   149: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   152: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   155: bipush #7
    //   157: iaload
    //   158: aaload
    //   159: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   162: iconst_1
    //   163: iaload
    //   164: <illegal opcode> 5 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   169: <illegal opcode> 6 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   174: aload_0
    //   175: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   178: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   181: bipush #8
    //   183: iaload
    //   184: aaload
    //   185: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   188: iconst_1
    //   189: iaload
    //   190: <illegal opcode> 5 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   195: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   200: aload_0
    //   201: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   204: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   207: bipush #9
    //   209: iaload
    //   210: aaload
    //   211: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   214: iconst_1
    //   215: iaload
    //   216: <illegal opcode> 5 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   221: <illegal opcode> 8 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   226: aload_0
    //   227: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   230: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   233: bipush #10
    //   235: iaload
    //   236: aaload
    //   237: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   240: iconst_1
    //   241: iaload
    //   242: <illegal opcode> 5 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   247: <illegal opcode> 9 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   252: aload_0
    //   253: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   256: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   259: bipush #11
    //   261: iaload
    //   262: aaload
    //   263: new me/stupitdog/bhp/f01
    //   266: dup
    //   267: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   270: bipush #12
    //   272: iaload
    //   273: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   276: bipush #12
    //   278: iaload
    //   279: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   282: bipush #12
    //   284: iaload
    //   285: invokespecial <init> : (III)V
    //   288: <illegal opcode> 10 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   293: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   298: aload_0
    //   299: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   302: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   305: bipush #13
    //   307: iaload
    //   308: aaload
    //   309: new me/stupitdog/bhp/f01
    //   312: dup
    //   313: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   316: bipush #12
    //   318: iaload
    //   319: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   322: bipush #12
    //   324: iaload
    //   325: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   328: bipush #12
    //   330: iaload
    //   331: invokespecial <init> : (III)V
    //   334: <illegal opcode> 10 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   339: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   344: aload_0
    //   345: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   348: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   351: bipush #14
    //   353: iaload
    //   354: aaload
    //   355: new me/stupitdog/bhp/f01
    //   358: dup
    //   359: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   362: bipush #12
    //   364: iaload
    //   365: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   368: bipush #12
    //   370: iaload
    //   371: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   374: bipush #12
    //   376: iaload
    //   377: invokespecial <init> : (III)V
    //   380: <illegal opcode> 10 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   385: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   390: aload_0
    //   391: getstatic me/stupitdog/bhp/fr.lIlllIIIllIIlI : [Ljava/lang/String;
    //   394: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   397: bipush #15
    //   399: iaload
    //   400: aaload
    //   401: new me/stupitdog/bhp/f01
    //   404: dup
    //   405: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   408: bipush #12
    //   410: iaload
    //   411: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   414: bipush #12
    //   416: iaload
    //   417: getstatic me/stupitdog/bhp/fr.lIlllIIIllIlIl : [I
    //   420: bipush #12
    //   422: iaload
    //   423: invokespecial <init> : (III)V
    //   426: <illegal opcode> 10 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   431: <illegal opcode> 14 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   436: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	437	0	lllllllllllllllIlllIllllIlIlllll	Lme/stupitdog/bhp/fr;
    //   75	362	1	lllllllllllllllIlllIllllIlIllllI	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   75	362	1	lllllllllllllllIlllIllllIlIllllI	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 15 : ()Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 16 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: <illegal opcode> 17 : (Lme/stupitdog/bhp/fr;Ljava/lang/String;)V
    //   16: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIlllIllllIlIlllIl	Lme/stupitdog/bhp/fr;
  }
  
  static {
    llllIllllllllIl();
    llllIlllllllIIl();
    llllIlllllllIII();
    llllIllllllIlII();
  }
  
  private static CallSite llllIllllllIIll(MethodHandles.Lookup lllllllllllllllIlllIllllIlIlIIIl, String lllllllllllllllIlllIllllIlIlIIII, MethodType lllllllllllllllIlllIllllIlIIllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllllIlIlIlll = lIlllIIIllIIII[Integer.parseInt(lllllllllllllllIlllIllllIlIlIIII)].split(lIlllIIIllIIlI[lIlllIIIllIlIl[20]]);
      Class<?> lllllllllllllllIlllIllllIlIlIllI = Class.forName(lllllllllllllllIlllIllllIlIlIlll[lIlllIIIllIlIl[0]]);
      String lllllllllllllllIlllIllllIlIlIlIl = lllllllllllllllIlllIllllIlIlIlll[lIlllIIIllIlIl[1]];
      MethodHandle lllllllllllllllIlllIllllIlIlIlII = null;
      int lllllllllllllllIlllIllllIlIlIIll = lllllllllllllllIlllIllllIlIlIlll[lIlllIIIllIlIl[3]].length();
      if (lllllIIIIIIIIII(lllllllllllllllIlllIllllIlIlIIll, lIlllIIIllIlIl[2])) {
        MethodType lllllllllllllllIlllIllllIlIllIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllllIlIlIlll[lIlllIIIllIlIl[2]], fr.class.getClassLoader());
        if (lllllIIIIIIIIIl(lllllllllllllllIlllIllllIlIlIIll, lIlllIIIllIlIl[2])) {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findVirtual(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIIl);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findStatic(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIIl);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllllIlIllIII = lIlllIIIllIIIl[Integer.parseInt(lllllllllllllllIlllIllllIlIlIlll[lIlllIIIllIlIl[2]])];
        if (lllllIIIIIIIIIl(lllllllllllllllIlllIllllIlIlIIll, lIlllIIIllIlIl[3])) {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findGetter(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lllllIIIIIIIIIl(lllllllllllllllIlllIllllIlIlIIll, lIlllIIIllIlIl[4])) {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findStaticGetter(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIIIIIIIIIl(lllllllllllllllIlllIllllIlIlIIll, lIlllIIIllIlIl[5])) {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findSetter(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIII);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIllllIlIlIlII = lllllllllllllllIlllIllllIlIlIIIl.findStaticSetter(lllllllllllllllIlllIllllIlIlIllI, lllllllllllllllIlllIllllIlIlIlIl, lllllllllllllllIlllIllllIlIllIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllllIlIlIlII);
    } catch (Exception lllllllllllllllIlllIllllIlIlIIlI) {
      lllllllllllllllIlllIllllIlIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllllllIlII() {
    lIlllIIIllIIII = new String[lIlllIIIllIlIl[21]];
    lIlllIIIllIIII[lIlllIIIllIlIl[22]] = lIlllIIIllIIlI[lIlllIIIllIlIl[23]];
    lIlllIIIllIIII[lIlllIIIllIlIl[16]] = lIlllIIIllIIlI[lIlllIIIllIlIl[24]];
    lIlllIIIllIIII[lIlllIIIllIlIl[25]] = lIlllIIIllIIlI[lIlllIIIllIlIl[26]];
    lIlllIIIllIIII[lIlllIIIllIlIl[27]] = lIlllIIIllIIlI[lIlllIIIllIlIl[28]];
    lIlllIIIllIIII[lIlllIIIllIlIl[2]] = lIlllIIIllIIlI[lIlllIIIllIlIl[29]];
    lIlllIIIllIIII[lIlllIIIllIlIl[30]] = lIlllIIIllIIlI[lIlllIIIllIlIl[31]];
    lIlllIIIllIIII[lIlllIIIllIlIl[32]] = lIlllIIIllIIlI[lIlllIIIllIlIl[33]];
    lIlllIIIllIIII[lIlllIIIllIlIl[34]] = lIlllIIIllIIlI[lIlllIIIllIlIl[35]];
    lIlllIIIllIIII[lIlllIIIllIlIl[36]] = lIlllIIIllIIlI[lIlllIIIllIlIl[37]];
    lIlllIIIllIIII[lIlllIIIllIlIl[5]] = lIlllIIIllIIlI[lIlllIIIllIlIl[38]];
    lIlllIIIllIIII[lIlllIIIllIlIl[23]] = lIlllIIIllIIlI[lIlllIIIllIlIl[32]];
    lIlllIIIllIIII[lIlllIIIllIlIl[14]] = lIlllIIIllIIlI[lIlllIIIllIlIl[39]];
    lIlllIIIllIIII[lIlllIIIllIlIl[39]] = lIlllIIIllIIlI[lIlllIIIllIlIl[40]];
    lIlllIIIllIIII[lIlllIIIllIlIl[31]] = lIlllIIIllIIlI[lIlllIIIllIlIl[41]];
    lIlllIIIllIIII[lIlllIIIllIlIl[1]] = lIlllIIIllIIlI[lIlllIIIllIlIl[42]];
    lIlllIIIllIIII[lIlllIIIllIlIl[43]] = lIlllIIIllIIlI[lIlllIIIllIlIl[44]];
    lIlllIIIllIIII[lIlllIIIllIlIl[29]] = lIlllIIIllIIlI[lIlllIIIllIlIl[34]];
    lIlllIIIllIIII[lIlllIIIllIlIl[37]] = lIlllIIIllIIlI[lIlllIIIllIlIl[36]];
    lIlllIIIllIIII[lIlllIIIllIlIl[42]] = lIlllIIIllIIlI[lIlllIIIllIlIl[45]];
    lIlllIIIllIIII[lIlllIIIllIlIl[46]] = lIlllIIIllIIlI[lIlllIIIllIlIl[27]];
    lIlllIIIllIIII[lIlllIIIllIlIl[24]] = lIlllIIIllIIlI[lIlllIIIllIlIl[43]];
    lIlllIIIllIIII[lIlllIIIllIlIl[4]] = lIlllIIIllIIlI[lIlllIIIllIlIl[46]];
    lIlllIIIllIIII[lIlllIIIllIlIl[6]] = lIlllIIIllIIlI[lIlllIIIllIlIl[30]];
    lIlllIIIllIIII[lIlllIIIllIlIl[40]] = lIlllIIIllIIlI[lIlllIIIllIlIl[22]];
    lIlllIIIllIIII[lIlllIIIllIlIl[41]] = lIlllIIIllIIlI[lIlllIIIllIlIl[47]];
    lIlllIIIllIIII[lIlllIIIllIlIl[9]] = lIlllIIIllIIlI[lIlllIIIllIlIl[48]];
    lIlllIIIllIIII[lIlllIIIllIlIl[10]] = lIlllIIIllIIlI[lIlllIIIllIlIl[25]];
    lIlllIIIllIIII[lIlllIIIllIlIl[26]] = lIlllIIIllIIlI[lIlllIIIllIlIl[49]];
    lIlllIIIllIIII[lIlllIIIllIlIl[50]] = lIlllIIIllIIlI[lIlllIIIllIlIl[51]];
    lIlllIIIllIIII[lIlllIIIllIlIl[51]] = lIlllIIIllIIlI[lIlllIIIllIlIl[52]];
    lIlllIIIllIIII[lIlllIIIllIlIl[20]] = lIlllIIIllIIlI[lIlllIIIllIlIl[53]];
    lIlllIIIllIIII[lIlllIIIllIlIl[45]] = lIlllIIIllIIlI[lIlllIIIllIlIl[50]];
    lIlllIIIllIIII[lIlllIIIllIlIl[33]] = lIlllIIIllIIlI[lIlllIIIllIlIl[21]];
    lIlllIIIllIIII[lIlllIIIllIlIl[35]] = lIlllIIIllIIlI[lIlllIIIllIlIl[54]];
    lIlllIIIllIIII[lIlllIIIllIlIl[47]] = lIlllIIIllIIlI[lIlllIIIllIlIl[55]];
    lIlllIIIllIIII[lIlllIIIllIlIl[0]] = lIlllIIIllIIlI[lIlllIIIllIlIl[56]];
    lIlllIIIllIIII[lIlllIIIllIlIl[8]] = lIlllIIIllIIlI[lIlllIIIllIlIl[57]];
    lIlllIIIllIIII[lIlllIIIllIlIl[28]] = lIlllIIIllIIlI[lIlllIIIllIlIl[58]];
    lIlllIIIllIIII[lIlllIIIllIlIl[53]] = lIlllIIIllIIlI[lIlllIIIllIlIl[59]];
    lIlllIIIllIIII[lIlllIIIllIlIl[3]] = lIlllIIIllIIlI[lIlllIIIllIlIl[60]];
    lIlllIIIllIIII[lIlllIIIllIlIl[44]] = lIlllIIIllIIlI[lIlllIIIllIlIl[61]];
    lIlllIIIllIIII[lIlllIIIllIlIl[38]] = lIlllIIIllIIlI[lIlllIIIllIlIl[62]];
    lIlllIIIllIIII[lIlllIIIllIlIl[15]] = lIlllIIIllIIlI[lIlllIIIllIlIl[63]];
    lIlllIIIllIIII[lIlllIIIllIlIl[48]] = lIlllIIIllIIlI[lIlllIIIllIlIl[64]];
    lIlllIIIllIIII[lIlllIIIllIlIl[52]] = lIlllIIIllIIlI[lIlllIIIllIlIl[65]];
    lIlllIIIllIIII[lIlllIIIllIlIl[13]] = lIlllIIIllIIlI[lIlllIIIllIlIl[19]];
    lIlllIIIllIIII[lIlllIIIllIlIl[17]] = lIlllIIIllIIlI[lIlllIIIllIlIl[66]];
    lIlllIIIllIIII[lIlllIIIllIlIl[7]] = lIlllIIIllIIlI[lIlllIIIllIlIl[67]];
    lIlllIIIllIIII[lIlllIIIllIlIl[49]] = lIlllIIIllIIlI[lIlllIIIllIlIl[68]];
    lIlllIIIllIIII[lIlllIIIllIlIl[11]] = lIlllIIIllIIlI[lIlllIIIllIlIl[69]];
    lIlllIIIllIIIl = new Class[lIlllIIIllIlIl[10]];
    lIlllIIIllIIIl[lIlllIIIllIlIl[7]] = List.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[4]] = f100000000000000000000.ColorSetting.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[9]] = EntityPlayerSP.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[5]] = Minecraft.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[0]] = f13.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[1]] = Listener.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[8]] = Profiler.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[3]] = f100000000000000000000.Boolean.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[2]] = f100000000000000000000.Mode.class;
    lIlllIIIllIIIl[lIlllIIIllIlIl[6]] = WorldClient.class;
  }
  
  private static void llllIlllllllIII() {
    lIlllIIIllIIlI = new String[lIlllIIIllIlIl[70]];
    lIlllIIIllIIlI[lIlllIIIllIlIl[0]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[0]], lIlllIIIllIIll[lIlllIIIllIlIl[1]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[1]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[2]], lIlllIIIllIIll[lIlllIIIllIlIl[3]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[2]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[4]], lIlllIIIllIIll[lIlllIIIllIlIl[5]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[3]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[6]], lIlllIIIllIIll[lIlllIIIllIlIl[7]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[4]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[8]], lIlllIIIllIIll[lIlllIIIllIlIl[9]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[5]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[10]], lIlllIIIllIIll[lIlllIIIllIlIl[11]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[6]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[13]], lIlllIIIllIIll[lIlllIIIllIlIl[14]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[7]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[15]], lIlllIIIllIIll[lIlllIIIllIlIl[16]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[8]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[17]], lIlllIIIllIIll[lIlllIIIllIlIl[20]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[9]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[23]], lIlllIIIllIIll[lIlllIIIllIlIl[24]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[10]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[26]], lIlllIIIllIIll[lIlllIIIllIlIl[28]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[11]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[29]], lIlllIIIllIIll[lIlllIIIllIlIl[31]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[13]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[33]], lIlllIIIllIIll[lIlllIIIllIlIl[35]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[14]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[37]], lIlllIIIllIIll[lIlllIIIllIlIl[38]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[15]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[32]], lIlllIIIllIIll[lIlllIIIllIlIl[39]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[16]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[40]], lIlllIIIllIIll[lIlllIIIllIlIl[41]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[17]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[42]], lIlllIIIllIIll[lIlllIIIllIlIl[44]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[20]] = llllIllllllIlIl(lIlllIIIllIIll[lIlllIIIllIlIl[34]], lIlllIIIllIIll[lIlllIIIllIlIl[36]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[23]] = llllIllllllIllI(lIlllIIIllIIll[lIlllIIIllIlIl[45]], lIlllIIIllIIll[lIlllIIIllIlIl[27]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[24]] = llllIllllllIlll(lIlllIIIllIIll[lIlllIIIllIlIl[43]], lIlllIIIllIIll[lIlllIIIllIlIl[46]]);
    lIlllIIIllIIlI[lIlllIIIllIlIl[26]] = llllIllllllIlll("4vqLb+cMbrhbxPAORzbM0SOnSKH/WABeidBD5RB/o1mMrUuqMqbQBg==", "UfMFB");
    lIlllIIIllIIlI[lIlllIIIllIlIl[28]] = llllIllllllIllI("EyvEJNeVjjW/ofRfUijdvFEEcT3PqHdsSU/Djwc34ADESNhfM9HXiQykSENbNvz1vpCRikpgPaE46oOxEBySrA==", "eXEmq");
    lIlllIIIllIIlI[lIlllIIIllIlIl[29]] = llllIllllllIlIl("IjEUBEA9JAsJQAkiEAQXBDkREVQpNAZfRgQ6AxMPZzwDCwlnHwAPCyskWUw0cnBC", "HPben");
    lIlllIIIllIIlI[lIlllIIIllIlIl[31]] = llllIllllllIllI("FS0Gx+IpWLsQWN4kQU+380mhPhLv7UYsMbqoATPkZjNRD96KYtJXjiMhWvEAxW4lzV/QIWPWlMRKkb+PL8sfUJxJZmPxHh57DffsQA2rwv8iI4K09FkETM2QxMZixTKG", "RaoMu");
    lIlllIIIllIIlI[lIlllIIIllIlIl[33]] = llllIllllllIllI("O0bQY6mgLyGUfeQpNmRJ1Dj2xjBoQ2s7ZJGKz/oLg7M27w9bpiL3vD/QGNViBzIxin/pWzslc619RJfvCsn/wQHAJ1lykdau", "TAwEj");
    lIlllIIIllIIlI[lIlllIIIllIlIl[35]] = llllIllllllIlIl("Lz1kNjg3KCMxKC0/ZCckMnYsdX94Ki8pKSMrLwIAeHBjE3Zi", "BXJEL");
    lIlllIIIllIIlI[lIlllIIIllIlIl[37]] = llllIllllllIlll("nvvoX4zu+w2gtE2ADxg+q906QeLsoNLdlVvm2cyd3sXgf+5t7fkp8Q==", "UzLVv");
    lIlllIIIllIIlI[lIlllIIIllIlIl[38]] = llllIllllllIlIl("FCF0HxcMNDMYBxYjdA4LCWo8HlkLIT0FEA0hKC4MFig/DQ1DbBYGAg8ldQACFyN1PxcLLTQLWCNtFgEGVjcuGRMQMD4DBFYmMhxMH3VqXFNJdGpcU0l0alxTSXRqXFNJdH4uDBYoPw0NQn56TA==", "yDZlc");
    lIlllIIIllIIlI[lIlllIIIllIlIl[32]] = llllIllllllIlll("2eeWQboiJ5vkf488dPEnYimY79rRszXGy9EuPzWmceq89lvb/LTIXiXyTdGPNJ0K5Sen8Z9aXRJwdp/cuM9Hzg==", "uzpfb");
    lIlllIIIllIIlI[lIlllIIIllIlIl[39]] = llllIllllllIlll("LRBPomKR96yn8TXYqG5cJ3tgVA9xiqLVZBP3kPJa0HOwgGxSW4fF8w==", "rnnOA");
    lIlllIIIllIIlI[lIlllIIIllIlIl[40]] = llllIllllllIllI("hUmk3pN5ROoNsUU3SSG3CQqpHp0yAli0HOWexp36jLWmjeHFuwN1zbfKLbqovb9e+wbDOqIUrIkmI+nR/RSuIausy11EKaL1", "fKCyn");
    lIlllIIIllIIlI[lIlllIIIllIlIl[41]] = llllIllllllIlIl("IQUlCEQ+EDoFRDgQIQwLJkoAHRguBT5TDCIIJwwYcUwfAws9BXwcHiIIfA8fJQcnAAUlSwMbDy8NMAgeLl96JQAqEjJGHz8NP0YZPxY2CAdkNycbDyoJaFNKaw==", "KdSij");
    lIlllIIIllIIlI[lIlllIIIllIlIl[42]] = llllIllllllIllI("2dNkq0mi3Fh7w/spZZl3FQwAfhkswJnlrRUyDpp2MCvqyF8MBqWmtA==", "NBFaK");
    lIlllIIIllIIlI[lIlllIIIllIlIl[44]] = llllIllllllIlll("VcuCTdnf/JkLCV0oaS++cs+FyUkrL+2FXnsjfSgQ5dHzvOcZWXUcnFwfoZEwuw0G/BgSImZSnU9dMtN1H0s0ud4FC724/hhaxS57nnjwuReLhKtHT6QYuQ==", "XIKLT");
    lIlllIIIllIIlI[lIlllIIIllIlIl[34]] = llllIllllllIllI("uMF2y5pIKqN5z+aonLnAnNqrwTNqOiaB4nEB4pTvzdSGlI5fW5tVg8Tr9tK382mxgxwuwixZ2Rs=", "OabJr");
    lIlllIIIllIIlI[lIlllIIIllIlIl[36]] = llllIllllllIlll("ImNPlfx2KVjt+/U3m5CTxr8EHQPSHRnxCSdZE4kUs5kdfhB4UiY9wtRWBX9BUwT1xKovyg8xBtM/YVCpGek8Dn1unLI2sOaC", "XxraQ");
    lIlllIIIllIIlI[lIlllIIIllIlIl[45]] = llllIllllllIlIl("JQo4WQoiASkUFSoJOFkEJwYpGRNlHSkZAy4dKQVJDAMfAwY/CgEWCSoIKQVdLRoiFDh6WHVGVX0wJk1PYjl2Vw==", "KoLwg");
    lIlllIIIllIIlI[lIlllIIIllIlIl[27]] = llllIllllllIlll("aFwrtcixr6YnE5fSNZp3k5LNeHG23TeXnSCrQUHHkwzI03xGi8UtnQ==", "nHdvR");
    lIlllIIIllIIlI[lIlllIIIllIlIl[43]] = llllIllllllIlIl("DwNHHCEXFgAbMQ0BRw09EkgPHW8PBVNab0JGSU8=", "bfioU");
    lIlllIIIllIIlI[lIlllIIIllIlIl[46]] = llllIllllllIlIl("OQtjFAUhHiQTFTsJYwUZJEArFUs5ASkCS2ZUbUdRdE5t", "TnMgq");
    lIlllIIIllIIlI[lIlllIIIllIlIl[30]] = llllIllllllIllI("EzNd9eGhy+4J2peGNdkieromPOjPhwuPeGO6A0VYUh6pePnV3moZ+g==", "sGGeb");
    lIlllIIIllIIlI[lIlllIIIllIlIl[22]] = llllIllllllIllI("lVLae15P40Jc9kErtGRidYNmcjy3n+MeSmZfSPFRNN1U3iurSwyMWtTBCUw5T49TDBi89VTn+957USStPFUlrvwOBqRyXabt", "LENzS");
    lIlllIIIllIIlI[lIlllIIIllIlIl[47]] = llllIllllllIllI("2HB/SJ7rnfAayS9OFcE/pzudiSpP5yXomRJCMC31f0Gd0IRExwq0cf634e9OYuKNOybijyv6xKTRdD5or4bAAJ3dWujMGWyZ", "SdVrc");
    lIlllIIIllIIlI[lIlllIIIllIlIl[48]] = llllIllllllIllI("5Kg5blbMimImQ3EX4+x33QmAPnGlN/2IgPke/kxzyq3LNXUbTPa7WQ==", "AFVEw");
    lIlllIIIllIIlI[lIlllIIIllIlIl[25]] = llllIllllllIlll("HQqh5gn7y3ISc7GqMEbWUwhtHAEt2npEmvWqPsaRBgDoQjxd0C7pTT5miKwGwdBq8e6//OCYBtVf1RjNC6X6dK6GMmQ7+c6rIhq/XQsXBj6l86LjZfT9ptCkByqQUw1fVgTy5/XHQndWBPLn9cdCd9e3RuSKSS2kMGW8HEYP4og71md+S4Qy/A==", "lTSns");
    lIlllIIIllIIlI[lIlllIIIllIlIl[49]] = llllIllllllIlIl("NwkubCMwAj8hPDgKLmwtNQU/LDp3ITMsKzoeOyQ6YwozJyI9M21zem1dBSd0b1Z6Ym4=", "YlZBN");
    lIlllIIIllIIlI[lIlllIIIllIlIl[51]] = llllIllllllIllI("Lil41YEPRZzSM+nXRA0BS99uZJQRLOo8jTGWPkCsxOKvdAUd5nRzUoH4iVIR4VYl3G6kEyc819M=", "SvXbN");
    lIlllIIIllIIlI[lIlllIIIllIlIl[52]] = llllIllllllIllI("XIBNN+HouNk+1+OqEyN9MOOrbFq/uZvpG2erO1+xfu3olzCB6Y2CvQ==", "xxSxP");
    lIlllIIIllIIlI[lIlllIIIllIlIl[53]] = llllIllllllIlIl("KTxGOD0xKQE/LSs+RikhNHcOOXM3PBwJOyU6Ay49fnEkISgyOEcnKCo+Rxg9NjAGLHJtD1JraQ==", "DYhKI");
    lIlllIIIllIIlI[lIlllIIIllIlIl[50]] = llllIllllllIllI("iiOMBAbJeXL1xlNwE3xzhkQnWx5Qnrm7vxDdSl2RjGcH4/yDy29hwQ==", "jRZjL");
    lIlllIIIllIIlI[lIlllIIIllIlIl[21]] = llllIllllllIllI("rdjfRJVmmpPlbpt4rtUkYG8yO5Af74jg0i0J5SzGu50za+6WHN9w7IZiFtFQttF3crP8GQf4Gsjlc+Z1efE2IqYMfzg95ctE", "eHAIl");
    lIlllIIIllIIlI[lIlllIIIllIlIl[54]] = llllIllllllIllI("zPAcU4S9wVgWUSBDIyq0oNJHruAU9mDkR19pydIRhO/QvnPpZD1S6GJkJ1nLqDjgdkk5BTsPo+0=", "BLRcZ");
    lIlllIIIllIIlI[lIlllIIIllIlIl[55]] = llllIllllllIlIl("IwlINzk7HA8wKSELSCYlPkIAdH50CBQlOgwDHn5lAgIDMGIjBQghLjwNADBiOxgPKGIjDRIsYg8UDzcMIgUBKigqLiR/BAdFMH5t", "NlfDM");
    lIlllIIIllIIlI[lIlllIIIllIlIl[56]] = llllIllllllIllI("7UaC6w4cMhQ4PY/yEbYDmNznoCqixre3P5iOTG+V85x2UgY2Ul0qUg==", "TsiKd");
    lIlllIIIllIIlI[lIlllIIIllIlIl[57]] = llllIllllllIlll("iF4I74MaN1YdE58/OVDZle8UEOj9ajz4mncpBCJb/v0DK4w5LmeVcA==", "xGalx");
    lIlllIIIllIIlI[lIlllIIIllIlIl[58]] = llllIllllllIllI("rcCrG/32oaUnoVnQlJQ8h4MGtfKvlY9v5pH8x9rHUa+gwQUOEPdjM1O3YUINk19DgYB0x+YezHljZX1Oi/b/vPFs5YYgqFQk", "lhFKZ");
    lIlllIIIllIIlI[lIlllIIIllIlIl[59]] = llllIllllllIllI("mFx0RihwuoVbxfQEKOqwUlXAYBVhQUhQM49J1XniNPwRm5ED+c/F1w==", "cRaPH");
    lIlllIIIllIIlI[lIlllIIIllIlIl[60]] = llllIllllllIlll("daXEEDRl7fDBJkcLugue76hj4Cw1dbi2KUQEpRQhLlwz9jMGNhLdE+rT+WDgZMng3dWo+WB3C50ZA2v8XqKIbucYC7eJyQcGrMu+drvCzsJEKhgTwEXKiaX2vB+UxYswVGMJh9wG5ELipn/DxJVCgBy3W0spAaq+Mg+oKWb0hISwhrfYovVxoFoSSoBjw1VL", "LXSrn");
    lIlllIIIllIIlI[lIlllIIIllIlIl[61]] = llllIllllllIlll("LOqHp71adfPQBg1HxolzOdPIrAvxEjx8AhdoGwvztybnjE/U3wDPDZR0F9Qctt1V4Ey7qERyF6IVQq+RBBTdEpOByMJjPHei", "RmVBT");
    lIlllIIIllIIlI[lIlllIIIllIlIl[62]] = llllIllllllIlll("gxoG2DHGYmPCaNYYjAVwbiYxroDA3j/GSD/+jhcnGgo6NoBOjwABDFRcxG7l+9PvApuFgel8ri8epb4G2NfaulWDkQwyWTS+", "DrtlJ");
    lIlllIIIllIIlI[lIlllIIIllIlIl[63]] = llllIllllllIlIl("BgFvODUeFCg/JQQDbykpG0onOXsPCy8gJBInLicuGV51cWFLRGFrYQ==", "kdAKA");
    lIlllIIIllIIlI[lIlllIIIllIlIl[64]] = llllIllllllIlll("7wwLd/I8fkQx4Ei2TIY4ao2MLByMrW/97nlsa8alpPZ8k+gD2ZWgdw==", "CdZOs");
    lIlllIIIllIIlI[lIlllIIIllIlIl[65]] = llllIllllllIllI("58PNixbItPZCVcOAFh+SlkHN1ulvAX8KnSojMyMy/2gTv1/6FCoNYQ==", "FGBcS");
    lIlllIIIllIIlI[lIlllIIIllIlIl[19]] = llllIllllllIllI("OhwpfZg5Z0Nwp5B3/0jWCu3sdW71pmRr5i/PJpgtt+skk4V/ayW3Y8zFDZddcPBv", "niliS");
    lIlllIIIllIIlI[lIlllIIIllIlIl[66]] = llllIllllllIlll("uTU6VeJF/zChmQahTqqUA7NHVnpH8Ol71YtbM0lelX3vKBzpcelEbkpDMgpPeJsSbyORQ7lC8AoZEMG4/YDaGYhSE5Xp1ntRxVl+Kdg1UIM=", "gfEIb");
    lIlllIIIllIIlI[lIlllIIIllIlIl[67]] = llllIllllllIlll("8KS8z7B7O1kFR2EbDUrUdcPoUmMy9mu9Y51Nn8bIAKwijwJy9xOjpA==", "VJHXR");
    lIlllIIIllIIlI[lIlllIIIllIlIl[68]] = llllIllllllIlIl("Jx9CAjE/CgUFISUdQhMtOlQKA38nFQ5LdnBaTFFl", "JzlqE");
    lIlllIIIllIIlI[lIlllIIIllIlIl[69]] = llllIllllllIlll("vtZauaTBGaA57aWVqfowwAAM5i/TjbLzW0ObRz0X2LCmsQv4py0xeA==", "gclYH");
    lIlllIIIllIIll = null;
  }
  
  private static void llllIlllllllIIl() {
    String str = (new Exception()).getStackTrace()[lIlllIIIllIlIl[0]].getFileName();
    lIlllIIIllIIll = str.substring(str.indexOf("ä") + lIlllIIIllIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllllllIlll(String lllllllllllllllIlllIllllIlIIlIll, String lllllllllllllllIlllIllllIlIIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIllllIlIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllllIlIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllllIlIIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllllIlIIllIl.init(lIlllIIIllIlIl[2], lllllllllllllllIlllIllllIlIIlllI);
      return new String(lllllllllllllllIlllIllllIlIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllllIlIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllllIlIIllII) {
      lllllllllllllllIlllIllllIlIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllllllIllI(String lllllllllllllllIlllIllllIlIIIllI, String lllllllllllllllIlllIllllIlIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIllllIlIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllllIlIIIlIl.getBytes(StandardCharsets.UTF_8)), lIlllIIIllIlIl[8]), "DES");
      Cipher lllllllllllllllIlllIllllIlIIlIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIllllIlIIlIII.init(lIlllIIIllIlIl[2], lllllllllllllllIlllIllllIlIIlIIl);
      return new String(lllllllllllllllIlllIllllIlIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllllIlIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllllIlIIIlll) {
      lllllllllllllllIlllIllllIlIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllllllIlIl(String lllllllllllllllIlllIllllIlIIIIll, String lllllllllllllllIlllIllllIlIIIIlI) {
    lllllllllllllllIlllIllllIlIIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllllIlIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllllIlIIIIIl = new StringBuilder();
    char[] lllllllllllllllIlllIllllIlIIIIII = lllllllllllllllIlllIllllIlIIIIlI.toCharArray();
    int lllllllllllllllIlllIllllIIllllll = lIlllIIIllIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIllllIlIIIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIIllIlIl[0];
    while (lllllIIIIIIIIlI(j, i)) {
      char lllllllllllllllIlllIllllIlIIIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllllIIllllll++;
      j++;
      "".length();
      if (((69 + 115 - 111 + 54 ^ (0x64 ^ 0x69) << " ".length() << " ".length()) & ((0xBC ^ 0xBB) << (0x87 ^ 0x82) ^ 99 + 105 - 156 + 123 ^ -" ".length())) >= " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllllIlIIIIIl);
  }
  
  private static void llllIllllllllIl() {
    lIlllIIIllIlIl = new int[71];
    lIlllIIIllIlIl[0] = (0xD9 ^ 0x82) & (0x48 ^ 0x13 ^ 0xFFFFFFFF);
    lIlllIIIllIlIl[1] = " ".length();
    lIlllIIIllIlIl[2] = " ".length() << " ".length();
    lIlllIIIllIlIl[3] = "   ".length();
    lIlllIIIllIlIl[4] = " ".length() << " ".length() << " ".length();
    lIlllIIIllIlIl[5] = 0x6D ^ 0x68;
    lIlllIIIllIlIl[6] = "   ".length() << " ".length();
    lIlllIIIllIlIl[7] = 0x78 ^ 0x39 ^ (0x3E ^ 0x1D) << " ".length();
    lIlllIIIllIlIl[8] = " ".length() << "   ".length();
    lIlllIIIllIlIl[9] = (0xB ^ 0x4) << "   ".length() ^ 0xD0 ^ 0xA1;
    lIlllIIIllIlIl[10] = (0x59 ^ 0x5C) << " ".length();
    lIlllIIIllIlIl[11] = (0x1B ^ 0x16) << " ".length() ^ 0xAE ^ 0xBF;
    lIlllIIIllIlIl[12] = 136 + 42 - 11 + 26 + ((0xAA ^ 0xC7) << " ".length()) - 391 + 296 - 609 + 321 + 19 + 180 - 64 + 108;
    lIlllIIIllIlIl[13] = "   ".length() << " ".length() << " ".length();
    lIlllIIIllIlIl[14] = 0x32 ^ 0x3F;
    lIlllIIIllIlIl[15] = (0xB3 ^ 0xB4) << " ".length();
    lIlllIIIllIlIl[16] = 21 + 9 - -96 + 25 ^ (0xA ^ 0x19) << "   ".length();
    lIlllIIIllIlIl[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIIllIlIl[18] = (0x3B ^ 0x26) << " ".length() << "   ".length();
    lIlllIIIllIlIl[19] = 0x56 ^ 0x69;
    lIlllIIIllIlIl[20] = 0x51 ^ 0x40;
    lIlllIIIllIlIl[21] = (0x8B ^ 0x92) << " ".length();
    lIlllIIIllIlIl[22] = (0x38 ^ 0x3) << " ".length() << " ".length() ^ 139 + 170 - 233 + 121;
    lIlllIIIllIlIl[23] = (8 + 32 - -73 + 72 ^ (0x4E ^ 0x45) << " ".length() << " ".length() << " ".length()) << " ".length();
    lIlllIIIllIlIl[24] = 0x8 ^ 0x1B;
    lIlllIIIllIlIl[25] = ((0x91 ^ 0x9C) << "   ".length() ^ 0x9 ^ 0x6A) << " ".length() << " ".length();
    lIlllIIIllIlIl[26] = ((0x8C ^ 0x83) << " ".length() ^ 0x12 ^ 0x9) << " ".length() << " ".length();
    lIlllIIIllIlIl[27] = (0x1 ^ 0x56) << " ".length() ^ 64 + 97 - 41 + 19;
    lIlllIIIllIlIl[28] = (0x19 ^ 0x2) << " ".length() ^ 0x37 ^ 0x14;
    lIlllIIIllIlIl[29] = (0x6F ^ 0x64) << " ".length();
    lIlllIIIllIlIl[30] = ((0x5D ^ 0x58) << " ".length() ^ 0xCE ^ 0xC1) << "   ".length();
    lIlllIIIllIlIl[31] = 0x5E ^ 0x49;
    lIlllIIIllIlIl[32] = (0x79 ^ 0xE ^ (0x32 ^ 0x35) << " ".length() << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIIllIlIl[33] = "   ".length() << "   ".length();
    lIlllIIIllIlIl[34] = (0x2F ^ 0x3E) << " ".length();
    lIlllIIIllIlIl[35] = 0x15 ^ 0xC;
    lIlllIIIllIlIl[36] = 0xBE ^ 0x9D;
    lIlllIIIllIlIl[37] = (0x3A ^ 0x37) << " ".length();
    lIlllIIIllIlIl[38] = 0x3A ^ 0x21;
    lIlllIIIllIlIl[39] = 0x42 ^ 0x5F;
    lIlllIIIllIlIl[40] = (0x28 ^ 0x27) << " ".length();
    lIlllIIIllIlIl[41] = (0x54 ^ 0x45) << " ".length() ^ 0xA9 ^ 0x94;
    lIlllIIIllIlIl[42] = " ".length() << ((0x27 ^ 0xE) << " ".length() ^ 0xD ^ 0x5A);
    lIlllIIIllIlIl[43] = (0x11 ^ 0x2) << " ".length();
    lIlllIIIllIlIl[44] = (0x12 ^ 0xF) << " ".length() << " ".length() ^ 0x18 ^ 0x4D;
    lIlllIIIllIlIl[45] = (" ".length() << "   ".length() << " ".length() ^ 0x73 ^ 0x3A) << " ".length() << " ".length();
    lIlllIIIllIlIl[46] = 0x7D ^ 0x7A ^ " ".length() << (0x23 ^ 0x26);
    lIlllIIIllIlIl[47] = (0x12 ^ 0x7) << " ".length();
    lIlllIIIllIlIl[48] = 0x72 ^ 0x59;
    lIlllIIIllIlIl[49] = 0xB ^ 0x26;
    lIlllIIIllIlIl[50] = 0x41 ^ 0x70;
    lIlllIIIllIlIl[51] = (0xAB ^ 0xBC) << " ".length();
    lIlllIIIllIlIl[52] = (0x89 ^ 0xA4) << " ".length() << " ".length() ^ 143 + 71 - 193 + 134;
    lIlllIIIllIlIl[53] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIIllIlIl[54] = 0xAF ^ 0x9C;
    lIlllIIIllIlIl[55] = (0xED ^ 0xA0 ^ " ".length() << "   ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIIllIlIl[56] = " ".length() << (0x60 ^ 0x65) ^ 0x6B ^ 0x7E;
    lIlllIIIllIlIl[57] = (82 + 99 - 177 + 175 ^ (0x39 ^ 0x2C) << "   ".length()) << " ".length();
    lIlllIIIllIlIl[58] = 0x82 ^ 0xB5;
    lIlllIIIllIlIl[59] = ((0x87 ^ 0xA8) << " ".length() ^ 0xC3 ^ 0x9A) << "   ".length();
    lIlllIIIllIlIl[60] = 18 + 37 - -14 + 80 ^ (0x8C ^ 0xA7) << " ".length() << " ".length();
    lIlllIIIllIlIl[61] = ("   ".length() << " ".length() ^ 0x4D ^ 0x56) << " ".length();
    lIlllIIIllIlIl[62] = 0x5D ^ 0x66;
    lIlllIIIllIlIl[63] = (147 + 15 - 70 + 77 ^ (0xD3 ^ 0x80) << " ".length()) << " ".length() << " ".length();
    lIlllIIIllIlIl[64] = (0x76 ^ 0x7D) << " ".length() ^ 0x7F ^ 0x54;
    lIlllIIIllIlIl[65] = ((0xB0 ^ 0x85) << " ".length() ^ 0x3B ^ 0x4E) << " ".length();
    lIlllIIIllIlIl[66] = " ".length() << "   ".length() << " ".length();
    lIlllIIIllIlIl[67] = 0x16 ^ 0x57;
    lIlllIIIllIlIl[68] = (0x2F ^ 0xE) << " ".length();
    lIlllIIIllIlIl[69] = 0x7B ^ 0x38;
    lIlllIIIllIlIl[70] = (0x78 ^ 0x3F ^ (0x41 ^ 0x6A) << " ".length()) << " ".length() << " ".length();
  }
  
  private static boolean lllllIIIIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIIIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIIIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIllllllllll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean llllIlllllllllI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */