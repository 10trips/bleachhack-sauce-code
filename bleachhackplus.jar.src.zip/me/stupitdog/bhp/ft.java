package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;

public class ft {
  static final float[] ticks = new float[llIIIIlIIIIIIl[3]];
  
  private long last_update_tick;
  
  private int next_index;
  
  @EventHandler
  private final Listener<f100000000000.Receive> receiveListener;
  
  private static String[] llIIIIIlllIlIl;
  
  private static Class[] llIIIIIlllIllI;
  
  private static final String[] llIIIIIllllllI;
  
  private static String[] llIIIIIlllllll;
  
  private static final int[] llIIIIlIIIIIIl;
  
  public ft() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 0 : (Lme/stupitdog/bhp/ft;I)V
    //   15: aload_0
    //   16: new me/zero/alpine/listener/Listener
    //   19: dup
    //   20: aload_0
    //   21: <illegal opcode> invoke : (Lme/stupitdog/bhp/ft;)Lme/zero/alpine/listener/EventHook;
    //   26: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   29: iconst_0
    //   30: iaload
    //   31: anewarray java/util/function/Predicate
    //   34: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   37: putfield receiveListener : Lme/zero/alpine/listener/Listener;
    //   40: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   45: aload_0
    //   46: <illegal opcode> 2 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   51: aload_0
    //   52: <illegal opcode> 3 : (Lme/stupitdog/bhp/ft;)V
    //   57: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	58	0	lllllllllllllllIllIllIllIIIlIIII	Lme/stupitdog/bhp/ft;
  }
  
  @SubscribeEvent
  public void onInputUpdate(InputUpdateEvent lllllllllllllllIllIllIllIIIIlllI) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllIllIIIIllll	Lme/stupitdog/bhp/ft;
    //   0	12	1	lllllllllllllllIllIllIllIIIIlllI	Lnet/minecraftforge/client/event/InputUpdateEvent;
  }
  
  @SubscribeEvent
  public void onRender(RenderWorldLastEvent lllllllllllllllIllIllIllIIIIllII) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllIllIIIIllIl	Lme/stupitdog/bhp/ft;
    //   0	12	1	lllllllllllllllIllIllIllIIIIllII	Lnet/minecraftforge/client/event/RenderWorldLastEvent;
  }
  
  @SubscribeEvent
  public void onChat(ClientChatEvent lllllllllllllllIllIllIllIIIIlIlI) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllIllIIIIlIll	Lme/stupitdog/bhp/ft;
    //   0	12	1	lllllllllllllllIllIllIllIIIIlIlI	Lnet/minecraftforge/client/event/ClientChatEvent;
  }
  
  @SubscribeEvent
  public void renderBlockOverlay(RenderBlockOverlayEvent lllllllllllllllIllIllIllIIIIlIII) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllIllIIIIlIIl	Lme/stupitdog/bhp/ft;
    //   0	12	1	lllllllllllllllIllIllIllIIIIlIII	Lnet/minecraftforge/client/event/RenderBlockOverlayEvent;
  }
  
  @SubscribeEvent
  public void onPlayerPush(PlayerSPPushOutOfBlocksEvent lllllllllllllllIllIllIllIIIIIllI) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllIllIIIIIlll	Lme/stupitdog/bhp/ft;
    //   0	12	1	lllllllllllllllIllIllIllIIIIIllI	Lnet/minecraftforge/client/event/PlayerSPPushOutOfBlocksEvent;
  }
  
  @SubscribeEvent
  public void onRender(RenderGameOverlayEvent.Post lllllllllllllllIllIllIllIIIIIIll) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/zero/alpine/EventManager;
    //   5: aload_1
    //   6: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   11: aload_1
    //   12: <illegal opcode> 5 : (Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Post;)Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   17: <illegal opcode> 6 : ()Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   22: invokestatic lIIIIIlIIIlIlllI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   25: ifeq -> 110
    //   28: <illegal opcode> 7 : ()Lme/stupitdog/bhp/f9;
    //   33: <illegal opcode> 8 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   38: <illegal opcode> 9 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   43: <illegal opcode> 10 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   48: astore_2
    //   49: aload_2
    //   50: <illegal opcode> 11 : (Ljava/util/Iterator;)Z
    //   55: invokestatic lIIIIIlIIIlIllll : (I)Z
    //   58: ifeq -> 110
    //   61: aload_2
    //   62: <illegal opcode> 12 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   67: checkcast me/stupitdog/bhp/au
    //   70: astore_3
    //   71: aload_3
    //   72: <illegal opcode> 13 : (Lme/stupitdog/bhp/au;)Z
    //   77: invokestatic lIIIIIlIIIlIllll : (I)Z
    //   80: ifeq -> 89
    //   83: aload_3
    //   84: <illegal opcode> 14 : (Lme/stupitdog/bhp/au;)V
    //   89: ldc ''
    //   91: invokevirtual length : ()I
    //   94: pop
    //   95: ldc ' '
    //   97: invokevirtual length : ()I
    //   100: ineg
    //   101: ldc ' '
    //   103: invokevirtual length : ()I
    //   106: if_icmple -> 49
    //   109: return
    //   110: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   71	18	3	lllllllllllllllIllIllIllIIIIIlIl	Lme/stupitdog/bhp/au;
    //   0	111	0	lllllllllllllllIllIllIllIIIIIlII	Lme/stupitdog/bhp/ft;
    //   0	111	1	lllllllllllllllIllIllIllIIIIIIll	Lnet/minecraftforge/client/event/RenderGameOverlayEvent$Post;
  }
  
  @SubscribeEvent
  public void key(InputEvent.KeyInputEvent lllllllllllllllIllIllIllIIIIIIIl) {
    // Byte code:
    //   0: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIlIIIllIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 69
    //   16: <illegal opcode> 17 : ()Z
    //   21: invokestatic lIIIIIlIIIlIllll : (I)Z
    //   24: ifeq -> 69
    //   27: <illegal opcode> 18 : ()I
    //   32: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   35: iconst_1
    //   36: iaload
    //   37: invokestatic lIIIIIlIIIllIIIl : (II)Z
    //   40: ifeq -> 69
    //   43: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   48: new net/minecraft/client/gui/GuiChat
    //   51: dup
    //   52: getstatic me/stupitdog/bhp/ft.llIIIIIllllllI : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   58: iconst_0
    //   59: iaload
    //   60: aaload
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;Lnet/minecraft/client/gui/GuiScreen;)V
    //   69: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	70	0	lllllllllllllllIllIllIllIIIIIIlI	Lme/stupitdog/bhp/ft;
    //   0	70	1	lllllllllllllllIllIllIllIIIIIIIl	Lnet/minecraftforge/fml/common/gameevent/InputEvent$KeyInputEvent;
  }
  
  public float get_tick_rate() {
    // Byte code:
    //   0: fconst_0
    //   1: fstore_1
    //   2: fconst_0
    //   3: fstore_2
    //   4: <illegal opcode> 20 : ()[F
    //   9: astore_3
    //   10: aload_3
    //   11: arraylength
    //   12: istore #4
    //   14: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   17: iconst_0
    //   18: iaload
    //   19: istore #5
    //   21: iload #5
    //   23: iload #4
    //   25: invokestatic lIIIIIlIIIllIIll : (II)Z
    //   28: ifeq -> 78
    //   31: aload_3
    //   32: iload #5
    //   34: faload
    //   35: fstore #6
    //   37: fload #6
    //   39: fconst_0
    //   40: invokestatic lIIIIIlIIIllIIlI : (FF)I
    //   43: invokestatic lIIIIIlIIIllIlII : (I)Z
    //   46: ifeq -> 58
    //   49: fload_2
    //   50: fload #6
    //   52: fadd
    //   53: fstore_2
    //   54: fload_1
    //   55: fconst_1
    //   56: fadd
    //   57: fstore_1
    //   58: iinc #5, 1
    //   61: ldc ''
    //   63: invokevirtual length : ()I
    //   66: pop
    //   67: bipush #38
    //   69: bipush #35
    //   71: ixor
    //   72: ineg
    //   73: iflt -> 21
    //   76: fconst_0
    //   77: freturn
    //   78: fload_2
    //   79: fload_1
    //   80: fdiv
    //   81: fconst_0
    //   82: ldc_w 20.0
    //   85: <illegal opcode> 21 : (FFF)F
    //   90: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   37	21	6	lllllllllllllllIllIllIllIIIIIIII	F
    //   0	91	0	lllllllllllllllIllIllIlIllllllll	Lme/stupitdog/bhp/ft;
    //   2	89	1	lllllllllllllllIllIllIlIlllllllI	F
    //   4	87	2	lllllllllllllllIllIllIlIllllllIl	F
  }
  
  public void reset_tick() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/ft;I)V
    //   11: aload_0
    //   12: ldc2_w -1
    //   15: <illegal opcode> 22 : (Lme/stupitdog/bhp/ft;J)V
    //   20: <illegal opcode> 20 : ()[F
    //   25: fconst_0
    //   26: <illegal opcode> 23 : ([FF)V
    //   31: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	32	0	lllllllllllllllIllIllIlIllllllII	Lme/stupitdog/bhp/ft;
  }
  
  public void update_time() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 24 : (Lme/stupitdog/bhp/ft;)J
    //   6: ldc2_w -1
    //   9: invokestatic lIIIIIlIIIllIlIl : (JJ)I
    //   12: invokestatic lIIIIIlIIIlIllll : (I)Z
    //   15: ifeq -> 87
    //   18: <illegal opcode> 25 : ()J
    //   23: aload_0
    //   24: <illegal opcode> 24 : (Lme/stupitdog/bhp/ft;)J
    //   29: lsub
    //   30: l2f
    //   31: ldc_w 1000.0
    //   34: fdiv
    //   35: fstore_1
    //   36: <illegal opcode> 20 : ()[F
    //   41: aload_0
    //   42: <illegal opcode> 26 : (Lme/stupitdog/bhp/ft;)I
    //   47: <illegal opcode> 20 : ()[F
    //   52: arraylength
    //   53: irem
    //   54: ldc_w 20.0
    //   57: fload_1
    //   58: fdiv
    //   59: fconst_0
    //   60: ldc_w 20.0
    //   63: <illegal opcode> 21 : (FFF)F
    //   68: fastore
    //   69: aload_0
    //   70: dup
    //   71: <illegal opcode> 26 : (Lme/stupitdog/bhp/ft;)I
    //   76: getstatic me/stupitdog/bhp/ft.llIIIIlIIIIIIl : [I
    //   79: iconst_2
    //   80: iaload
    //   81: iadd
    //   82: <illegal opcode> 0 : (Lme/stupitdog/bhp/ft;I)V
    //   87: aload_0
    //   88: <illegal opcode> 25 : ()J
    //   93: <illegal opcode> 22 : (Lme/stupitdog/bhp/ft;J)V
    //   98: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   36	51	1	lllllllllllllllIllIllIlIlllllIll	F
    //   0	99	0	lllllllllllllllIllIllIlIlllllIlI	Lme/stupitdog/bhp/ft;
  }
  
  private static CallSite lIIIIIlIIIIIlllI(MethodHandles.Lookup lllllllllllllllIllIllIlIlllIllll, String lllllllllllllllIllIllIlIlllIlllI, MethodType lllllllllllllllIllIllIlIlllIllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIlIllllIlIl = llIIIIIlllIlIl[Integer.parseInt(lllllllllllllllIllIllIlIlllIlllI)].split(llIIIIIllllllI[llIIIIlIIIIIIl[2]]);
      Class<?> lllllllllllllllIllIllIlIllllIlII = Class.forName(lllllllllllllllIllIllIlIllllIlIl[llIIIIlIIIIIIl[0]]);
      String lllllllllllllllIllIllIlIllllIIll = lllllllllllllllIllIllIlIllllIlIl[llIIIIlIIIIIIl[2]];
      MethodHandle lllllllllllllllIllIllIlIllllIIlI = null;
      int lllllllllllllllIllIllIlIllllIIIl = lllllllllllllllIllIllIlIllllIlIl[llIIIIlIIIIIIl[4]].length();
      if (lIIIIIlIIIllIllI(lllllllllllllllIllIllIlIllllIIIl, llIIIIlIIIIIIl[5])) {
        MethodType lllllllllllllllIllIllIlIllllIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIlIllllIlIl[llIIIIlIIIIIIl[5]], ft.class.getClassLoader());
        if (lIIIIIlIIIllIIIl(lllllllllllllllIllIllIlIllllIIIl, llIIIIlIIIIIIl[5])) {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findVirtual(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIlll);
          "".length();
          if (" ".length() << " ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findStatic(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIlll);
        } 
        "".length();
        if (-(0x85 ^ 0xC4 ^ 0x6D ^ 0x28) > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIlIllllIllI = llIIIIIlllIllI[Integer.parseInt(lllllllllllllllIllIllIlIllllIlIl[llIIIIlIIIIIIl[5]])];
        if (lIIIIIlIIIllIIIl(lllllllllllllllIllIllIlIllllIIIl, llIIIIlIIIIIIl[4])) {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findGetter(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIllI);
          "".length();
          if (-(0x78 ^ 0x7C) > 0)
            return null; 
        } else if (lIIIIIlIIIllIIIl(lllllllllllllllIllIllIlIllllIIIl, llIIIIlIIIIIIl[6])) {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findStaticGetter(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIllI);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else if (lIIIIIlIIIllIIIl(lllllllllllllllIllIllIlIllllIIIl, llIIIIlIIIIIIl[7])) {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findSetter(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIllI);
          "".length();
          if (" ".length() << " ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIlIllllIIlI = lllllllllllllllIllIllIlIlllIllll.findStaticSetter(lllllllllllllllIllIllIlIllllIlII, lllllllllllllllIllIllIlIllllIIll, lllllllllllllllIllIllIlIllllIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIlIllllIIlI);
    } catch (Exception lllllllllllllllIllIllIlIllllIIII) {
      lllllllllllllllIllIllIlIllllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIIIlIIlIl() {
    llIIIIIlllIlIl = new String[llIIIIlIIIIIIl[8]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[9]] = llIIIIIllllllI[llIIIIlIIIIIIl[5]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[10]] = llIIIIIllllllI[llIIIIlIIIIIIl[4]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[11]] = llIIIIIllllllI[llIIIIlIIIIIIl[6]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[12]] = llIIIIIllllllI[llIIIIlIIIIIIl[7]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[13]] = llIIIIIllllllI[llIIIIlIIIIIIl[14]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[14]] = llIIIIIllllllI[llIIIIlIIIIIIl[15]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[16]] = llIIIIIllllllI[llIIIIlIIIIIIl[9]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[17]] = llIIIIIllllllI[llIIIIlIIIIIIl[18]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[19]] = llIIIIIllllllI[llIIIIlIIIIIIl[20]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[21]] = llIIIIIllllllI[llIIIIlIIIIIIl[12]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[15]] = llIIIIIllllllI[llIIIIlIIIIIIl[10]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[22]] = llIIIIIllllllI[llIIIIlIIIIIIl[23]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[20]] = llIIIIIllllllI[llIIIIlIIIIIIl[24]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[25]] = llIIIIIllllllI[llIIIIlIIIIIIl[26]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[24]] = llIIIIIllllllI[llIIIIlIIIIIIl[21]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[3]] = llIIIIIllllllI[llIIIIlIIIIIIl[27]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[28]] = llIIIIIllllllI[llIIIIlIIIIIIl[22]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[29]] = llIIIIIllllllI[llIIIIlIIIIIIl[13]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[23]] = llIIIIIllllllI[llIIIIlIIIIIIl[3]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[26]] = llIIIIIllllllI[llIIIIlIIIIIIl[25]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[4]] = llIIIIIllllllI[llIIIIlIIIIIIl[17]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[18]] = llIIIIIllllllI[llIIIIlIIIIIIl[29]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[2]] = llIIIIIllllllI[llIIIIlIIIIIIl[16]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[0]] = llIIIIIllllllI[llIIIIlIIIIIIl[28]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[7]] = llIIIIIllllllI[llIIIIlIIIIIIl[11]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[6]] = llIIIIIllllllI[llIIIIlIIIIIIl[19]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[27]] = llIIIIIllllllI[llIIIIlIIIIIIl[30]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[30]] = llIIIIIllllllI[llIIIIlIIIIIIl[8]];
    llIIIIIlllIlIl[llIIIIlIIIIIIl[5]] = llIIIIIllllllI[llIIIIlIIIIIIl[31]];
    llIIIIIlllIllI = new Class[llIIIIlIIIIIIl[20]];
    llIIIIIlllIllI[llIIIIlIIIIIIl[2]] = Listener.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[14]] = ArrayList.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[15]] = EntityPlayerSP.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[7]] = av.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[0]] = int.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[6]] = f9.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[4]] = RenderGameOverlayEvent.ElementType.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[9]] = float[].class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[5]] = EventManager.class;
    llIIIIIlllIllI[llIIIIlIIIIIIl[18]] = long.class;
  }
  
  private static void lIIIIIlIIIlIlIIl() {
    llIIIIIllllllI = new String[llIIIIlIIIIIIl[32]];
    llIIIIIllllllI[llIIIIlIIIIIIl[0]] = lIIIIIlIIIlIIllI(llIIIIIlllllll[llIIIIlIIIIIIl[0]], llIIIIIlllllll[llIIIIlIIIIIIl[2]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[2]] = lIIIIIlIIIlIIllI(llIIIIIlllllll[llIIIIlIIIIIIl[5]], llIIIIIlllllll[llIIIIlIIIIIIl[4]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[5]] = lIIIIIlIIIlIIlll(llIIIIIlllllll[llIIIIlIIIIIIl[6]], llIIIIIlllllll[llIIIIlIIIIIIl[7]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[4]] = lIIIIIlIIIlIIlll(llIIIIIlllllll[llIIIIlIIIIIIl[14]], llIIIIIlllllll[llIIIIlIIIIIIl[15]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[6]] = lIIIIIlIIIlIIlll(llIIIIIlllllll[llIIIIlIIIIIIl[9]], llIIIIIlllllll[llIIIIlIIIIIIl[18]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[7]] = lIIIIIlIIIlIIllI(llIIIIIlllllll[llIIIIlIIIIIIl[20]], llIIIIIlllllll[llIIIIlIIIIIIl[12]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[14]] = lIIIIIlIIIlIIllI(llIIIIIlllllll[llIIIIlIIIIIIl[10]], llIIIIIlllllll[llIIIIlIIIIIIl[23]]);
    llIIIIIllllllI[llIIIIlIIIIIIl[15]] = lIIIIIlIIIlIIlll("+MEdmNapzMtN1XpuUmGOZe0iIvr1cT0sysW2k+SnIz7qSvZ0o1HLe6nzjm9piF++TtyWCTNqFzwEeMPj7XBq5NAH9bCtWl/nToF+w4zi2eBLhgFyJo1KmQ==", "GbcAW");
    llIIIIIllllllI[llIIIIlIIIIIIl[9]] = lIIIIIlIIIlIIllI("CC5cPxcQOxs4BwosXC4LFWUUOFkJKgE4PBA7Fi0XABQGJQAOcUt2Q0Vr", "eKrLc");
    llIIIIIllllllI[llIIIIlIIIIIIl[18]] = lIIIIIlIIIlIlIII("wTPCSfrnawuBYcarBwddbIggA7Cgj4GtP8oWCfKw67SYwVIlaXAhU+av2xAh/5vA", "dBaan");
    llIIIIIllllllI[llIIIIlIIIIIIl[20]] = lIIIIIlIIIlIIlll("3RqnCSMYWUjixVgmIdcNc/2vZFT666ZIMrQX8QNm0kjLFgRWyldKYkpA/Uu2oWzk6kZPP85NwsaUEAwzZIzpbdrKWkEEwSA+PYmDtD52t9SAa5ocXHVCXA==", "cwDsi");
    llIIIIIllllllI[llIIIIlIIIIIIl[12]] = lIIIIIlIIIlIlIII("LpJ+66+mP+ZBqhkk9uvSuDRDNQYE4Kc9flhGJCHiFDPbNO+enFayzqSOAB3f5zhuCZROmLcuz1c=", "gZICy");
    llIIIIIllllllI[llIIIIlIIIIIIl[10]] = lIIIIIlIIIlIIllI("NQhYFxwtHR8QDDcKWAYAKEMQXVIxAwUQCTYOE15cYk1WREg=", "Xmvdh");
    llIIIIIllllllI[llIIIIlIIIIIIl[23]] = lIIIIIlIIIlIlIII("YBI6/cHI3oZ6L0RHNN5NUecYVz8LPSXhcHkaNVPqn2tSFT1iLW5zN94LGAHojiYl", "BrXvl");
    llIIIIIllllllI[llIIIIlIIIIIIl[24]] = lIIIIIlIIIlIIllI("LyY7KnowMyQnegQ1PyotCS4+P24sMyg5NTEoP3F8bAsnKiIkaDg/PSloBD8xNyY5JCZ+fW1r", "EGMKT");
    llIIIIIllllllI[llIIIIlIIIIIIl[26]] = lIIIIIlIIIlIIlll("Ghtf5SbckmGD2ES23/r0I/6XztOSQRJPbOD7uu+UCp6rkhlxcv3KoS2b+lNCLxzbRd+HHgZwfz/oVlhypx4euA==", "veRrC");
    llIIIIIllllllI[llIIIIlIIIIIIl[21]] = lIIIIIlIIIlIIlll("euOassA2AiSMBxRDdisrU3vFvHvil7GQ4AD0xJjNp+n5FirlOhdNlA==", "MvZjy");
    llIIIIIllllllI[llIIIIlIIIIIIl[27]] = lIIIIIlIIIlIlIII("WsotK0FOTY7/QLTYOcJVMT92EsWjwm5lMt0V89SPCoUbeN4p2l1XNA==", "MqFaq");
    llIIIIIllllllI[llIIIIlIIIIIIl[22]] = lIIIIIlIIIlIIlll("HqGimPsz+ch9F+Si50BHEPGB6e+40rUXSt02yRJTBSha8arBy9wK52tSVegYeSKa", "yTtcp");
    llIIIIIllllllI[llIIIIlIIIIIIl[13]] = lIIIIIlIIIlIlIII("5kZw3VGIHogoEwy1fKLdbBCQvfzqWzOPFZK7BEbt1eU=", "TlxZm");
    llIIIIIllllllI[llIIIIlIIIIIIl[3]] = lIIIIIlIIIlIlIII("3NJGnXFSb0jdUu7lkoAsyuRianxeSxF/13E/qtUMB5GQypiHlnVGsg==", "MjFQy");
    llIIIIIllllllI[llIIIIlIIIIIIl[25]] = lIIIIIlIIIlIIlll("cRnqXUUTC0SMJIz4RYZW5z99LKy9885Cq07Sn+kacsKG2ABP/6Kn2sBTLy9FMvLPYQtubeAHPtnFZ0sk47bDGGuEdTKvvSKbsr9x8pXap66vpuKr425d2Q==", "GZSNj");
    llIIIIIllllllI[llIIIIlIIIIIIl[17]] = lIIIIIlIIIlIlIII("kFpP55Wa7568/29mpikd/4xWfU2/uoiOqym4V3O4LPdFR8itQJ+lAA==", "kZTUS");
    llIIIIIllllllI[llIIIIlIIIIIIl[29]] = lIIIIIlIIIlIlIII("Hyl90+SFRV14R+GNf9KGtEzwhNtNu8y18A8ykYUAWb+klWBB8p1B1g==", "VuzEo");
    llIIIIIllllllI[llIIIIlIIIIIIl[16]] = lIIIIIlIIIlIIllI("BApDPTkcHwQ6KQYIQywlGUELd3csOSgAGTYtOB13W1VNbm1J", "iomNM");
    llIIIIIllllllI[llIIIIlIIIIIIl[28]] = lIIIIIlIIIlIIlll("JArJr5cPjCMBlXWBOUBgVuefziNLG5dC3BdhYC51tfFXtCSQ9MMMxQ==", "KTiVB");
    llIIIIIllllllI[llIIIIlIIIIIIl[11]] = lIIIIIlIIIlIlIII("36F4Ti7+7ESld3c0DG+sJlPxyDjWHdGku1jzJVTuKqy+8SwvEQZTqOdUXX3MxWcgzUvkDyegX0c+ks5kqpZxajNwqVwCvy8zJKNx+nSpMA/JBYDz7VVI1mPKzl0gbJxOohGhLqwldZ2GiKJI7ipFP26+8onZvb2tLfgnT4YhXwumwMy1qozYRtnlb0K+Di3w", "GNiks");
    llIIIIIllllllI[llIIIIlIIIIIIl[19]] = lIIIIIlIIIlIlIII("+8Xy2e86w3lcJGcaXNlIg4DgoaCj81qmd5MhWfyO/Fty2EiF8IlN2c8Q7uufIzODSU4jRTSqOqNSum4mG0c7gw==", "kRgYk");
    llIIIIIllllllI[llIIIIlIIIIIIl[30]] = lIIIIIlIIIlIIllI("PD8FaRUkJwUrVzojEjINfQYHPhs8LBAjQzQoFgIPNiMWDBwqHhYmDTZ3Sm4jaW0=", "SMbGy");
    llIIIIIllllllI[llIIIIlIIIIIIl[8]] = lIIIIIlIIIlIlIII("PGVJb9lmAa4NMZa1oRE+bXbqiWpcgEic0qBndT5cNIwkX0EbvL/5VQ==", "DSFXp");
    llIIIIIllllllI[llIIIIlIIIIIIl[31]] = lIIIIIlIIIlIlIII("idgnVZ1jlErqKTl5gHT/03JwpdWh6hc8Lpc2+FHiYdc0PRERxW2TOpGU9zfLf7f/v4CDCI7DBBFi6ZmGD6aVJQ==", "aOhDg");
    llIIIIIlllllll = null;
  }
  
  private static void lIIIIIlIIIlIlIlI() {
    String str = (new Exception()).getStackTrace()[llIIIIlIIIIIIl[0]].getFileName();
    llIIIIIlllllll = str.substring(str.indexOf("ä") + llIIIIlIIIIIIl[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIIIlIIllI(String lllllllllllllllIllIllIlIlllIlIll, String lllllllllllllllIllIllIlIlllIlIlI) {
    lllllllllllllllIllIllIlIlllIlIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIlIlllIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIlIlllIlIIl = new StringBuilder();
    char[] lllllllllllllllIllIllIlIlllIlIII = lllllllllllllllIllIllIlIlllIlIlI.toCharArray();
    int lllllllllllllllIllIllIlIlllIIlll = llIIIIlIIIIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIlIlllIlIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIlIIIIIIl[0];
    while (lIIIIIlIIIllIIll(j, i)) {
      char lllllllllllllllIllIllIlIlllIllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIlIlllIIlll++;
      j++;
      "".length();
      if (-"   ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIlIlllIlIIl);
  }
  
  private static String lIIIIIlIIIlIIlll(String lllllllllllllllIllIllIlIlllIIIll, String lllllllllllllllIllIllIlIlllIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIlIlllIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlIlllIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIlIlllIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIlIlllIIlIl.init(llIIIIlIIIIIIl[5], lllllllllllllllIllIllIlIlllIIllI);
      return new String(lllllllllllllllIllIllIlIlllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlIlllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIlIlllIIlII) {
      lllllllllllllllIllIllIlIlllIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIIIlIlIII(String lllllllllllllllIllIllIlIllIllllI, String lllllllllllllllIllIllIlIllIlllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIlIlllIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlIllIlllIl.getBytes(StandardCharsets.UTF_8)), llIIIIlIIIIIIl[9]), "DES");
      Cipher lllllllllllllllIllIllIlIlllIIIII = Cipher.getInstance("DES");
      lllllllllllllllIllIllIlIlllIIIII.init(llIIIIlIIIIIIl[5], lllllllllllllllIllIllIlIlllIIIIl);
      return new String(lllllllllllllllIllIllIlIlllIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlIllIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIlIllIlllll) {
      lllllllllllllllIllIllIlIllIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIIIlIllIl() {
    llIIIIlIIIIIIl = new int[33];
    llIIIIlIIIIIIl[0] = ((0xE2 ^ 0xC1) << " ".length() ^ 0x72 ^ 0x7D) & ((0xC ^ 0x33) << " ".length() << " ".length() ^ 35 + 82 - 98 + 162 ^ -" ".length());
    llIIIIlIIIIIIl[1] = 0x39 ^ 0x56 ^ (0x62 ^ 0x6B) << "   ".length();
    llIIIIlIIIIIIl[2] = " ".length();
    llIIIIlIIIIIIl[3] = (0x54 ^ 0x17 ^ (0x67 ^ 0x44) << " ".length()) << " ".length() << " ".length();
    llIIIIlIIIIIIl[4] = "   ".length();
    llIIIIlIIIIIIl[5] = " ".length() << " ".length();
    llIIIIlIIIIIIl[6] = " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIIl[7] = 0x45 ^ 0x40;
    llIIIIlIIIIIIl[8] = 0x36 ^ 0x2B;
    llIIIIlIIIIIIl[9] = " ".length() << "   ".length();
    llIIIIlIIIIIIl[10] = "   ".length() << " ".length() << " ".length();
    llIIIIlIIIIIIl[11] = (0x1 ^ 0xC) << " ".length();
    llIIIIlIIIIIIl[12] = 0xFF ^ 0xA4 ^ (0x85 ^ 0x80) << " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIIl[13] = (0xF5 ^ 0xB8) << " ".length() ^ 123 + 33 - 135 + 116;
    llIIIIlIIIIIIl[14] = "   ".length() << " ".length();
    llIIIIlIIIIIIl[15] = (0x16 ^ 0x11) << " ".length() << " ".length() ^ 0x4D ^ 0x56;
    llIIIIlIIIIIIl[16] = "   ".length() << "   ".length();
    llIIIIlIIIIIIl[17] = (0x98 ^ 0x93) << " ".length();
    llIIIIlIIIIIIl[18] = 0x8D ^ 0x84;
    llIIIIlIIIIIIl[19] = 0x90 ^ 0x8B;
    llIIIIlIIIIIIl[20] = ((0x3B ^ 0x18) << " ".length() << " ".length() ^ 115 + 60 - 120 + 82) << " ".length();
    llIIIIlIIIIIIl[21] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIIl[22] = (0xF ^ 0x6) << " ".length();
    llIIIIlIIIIIIl[23] = 0x17 ^ 0x1A;
    llIIIIlIIIIIIl[24] = ("   ".length() << " ".length() << " ".length() << " ".length() ^ 0x3A ^ 0xD) << " ".length();
    llIIIIlIIIIIIl[25] = 0x8E ^ 0xBD ^ (0x16 ^ 0x5) << " ".length();
    llIIIIlIIIIIIl[26] = 0x87 ^ 0x9C ^ (0x8B ^ 0x8E) << " ".length() << " ".length();
    llIIIIlIIIIIIl[27] = " ".length() << "   ".length() ^ 0xDF ^ 0xC6;
    llIIIIlIIIIIIl[28] = 0x66 ^ 0x7F;
    llIIIIlIIIIIIl[29] = " ".length() ^ (0x75 ^ 0x7E) << " ".length();
    llIIIIlIIIIIIl[30] = ((0x30 ^ 0x17) << " ".length() ^ 0x4B ^ 0x2) << " ".length() << " ".length();
    llIIIIlIIIIIIl[31] = (0xBC ^ 0xB3) << " ".length();
    llIIIIlIIIIIIl[32] = 0x7 ^ 0x66 ^ (0x18 ^ 0x27) << " ".length();
  }
  
  private static boolean lIIIIIlIIIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIIIllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlIIIlIlllI(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIlIIIllIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIlIIIlIllll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIlIIIllIlII(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lIIIIIlIIIllIIlI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIlIIIllIlIl(long paramLong1, long paramLong2) {
    return paramLong1 cmp paramLong2;
  }
  
  static {
    lIIIIIlIIIlIllIl();
    lIIIIIlIIIlIlIlI();
    lIIIIIlIIIlIlIIl();
    lIIIIIlIIIlIIlIl();
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */