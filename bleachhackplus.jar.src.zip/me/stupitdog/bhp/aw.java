package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovementInput;

public class aw {
  private static String[] llIIIlllIlllII;
  
  private static Class[] llIIIlllIlllIl;
  
  private static final String[] llIIlIIIIIIIlI;
  
  private static String[] llIIlIIIIIIIll;
  
  private static final int[] llIIlIIIIIIlII;
  
  public static boolean isMoving(EntityLivingBase lllllllllllllllIllIIlllllllIIlll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   6: fconst_0
    //   7: invokestatic lIIIIlIlllIllIII : (FF)I
    //   10: invokestatic lIIIIlIlllIllIIl : (I)Z
    //   13: ifeq -> 32
    //   16: aload_0
    //   17: <illegal opcode> 1 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   22: fconst_0
    //   23: invokestatic lIIIIlIlllIllIII : (FF)I
    //   26: invokestatic lIIIIlIlllIllIlI : (I)Z
    //   29: ifeq -> 133
    //   32: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   35: iconst_0
    //   36: iaload
    //   37: ldc ''
    //   39: invokevirtual length : ()I
    //   42: pop
    //   43: sipush #225
    //   46: sipush #198
    //   49: ixor
    //   50: ldc ' '
    //   52: invokevirtual length : ()I
    //   55: ishl
    //   56: bipush #85
    //   58: bipush #112
    //   60: ixor
    //   61: ldc ' '
    //   63: invokevirtual length : ()I
    //   66: ishl
    //   67: ixor
    //   68: ineg
    //   69: iflt -> 138
    //   72: sipush #179
    //   75: sipush #160
    //   78: ixor
    //   79: ldc '   '
    //   81: invokevirtual length : ()I
    //   84: ishl
    //   85: bipush #80
    //   87: bipush #37
    //   89: iadd
    //   90: bipush #-51
    //   92: isub
    //   93: bipush #9
    //   95: iadd
    //   96: ixor
    //   97: sipush #128
    //   100: sipush #135
    //   103: ixor
    //   104: ldc ' '
    //   106: invokevirtual length : ()I
    //   109: ldc ' '
    //   111: invokevirtual length : ()I
    //   114: ishl
    //   115: ishl
    //   116: sipush #244
    //   119: sipush #193
    //   122: ixor
    //   123: ixor
    //   124: ldc ' '
    //   126: invokevirtual length : ()I
    //   129: ineg
    //   130: ixor
    //   131: iand
    //   132: ireturn
    //   133: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   136: iconst_1
    //   137: iaload
    //   138: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	139	0	lllllllllllllllIllIIlllllllIIlll	Lnet/minecraft/entity/EntityLivingBase;
  }
  
  public static void setSpeed(EntityLivingBase lllllllllllllllIllIIlllllllIIllI, double lllllllllllllllIllIIlllllllIIlIl) {
    // Byte code:
    //   0: dload_1
    //   1: <illegal opcode> 2 : (D)[D
    //   6: astore_3
    //   7: aload_0
    //   8: aload_3
    //   9: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   12: iconst_1
    //   13: iaload
    //   14: daload
    //   15: putfield field_70159_w : D
    //   18: aload_0
    //   19: aload_3
    //   20: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   23: iconst_0
    //   24: iaload
    //   25: daload
    //   26: putfield field_70179_y : D
    //   29: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	30	0	lllllllllllllllIllIIlllllllIIllI	Lnet/minecraft/entity/EntityLivingBase;
    //   0	30	1	lllllllllllllllIllIIlllllllIIlIl	D
    //   7	23	3	lllllllllllllllIllIIlllllllIIlII	[D
  }
  
  public static double getBaseMoveSpeed() {
    // Byte code:
    //   0: ldc2_w 0.2873
    //   3: dstore_0
    //   4: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: invokestatic lIIIIlIlllIllIll : (Ljava/lang/Object;)Z
    //   17: ifeq -> 99
    //   20: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   25: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   30: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   33: iconst_0
    //   34: iaload
    //   35: <illegal opcode> 5 : (I)Lnet/minecraft/potion/Potion;
    //   40: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   45: invokestatic lIIIIlIlllIllIlI : (I)Z
    //   48: ifeq -> 99
    //   51: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   64: iconst_0
    //   65: iaload
    //   66: <illegal opcode> 5 : (I)Lnet/minecraft/potion/Potion;
    //   71: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;
    //   76: <illegal opcode> 8 : (Lnet/minecraft/potion/PotionEffect;)I
    //   81: istore_2
    //   82: dload_0
    //   83: dconst_1
    //   84: ldc2_w 0.2
    //   87: iload_2
    //   88: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   91: iconst_0
    //   92: iaload
    //   93: iadd
    //   94: i2d
    //   95: dmul
    //   96: dadd
    //   97: dmul
    //   98: dstore_0
    //   99: dload_0
    //   100: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   82	17	2	lllllllllllllllIllIIlllllllIIIll	I
    //   4	97	0	lllllllllllllllIllIIlllllllIIIlI	D
  }
  
  public static double[] forward(double lllllllllllllllIllIIlllllllIIIIl) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   15: <illegal opcode> 10 : (Lnet/minecraft/util/MovementInput;)F
    //   20: fstore_2
    //   21: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   26: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   31: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   36: <illegal opcode> 11 : (Lnet/minecraft/util/MovementInput;)F
    //   41: fstore_3
    //   42: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   47: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   52: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   57: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   62: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   67: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   72: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   77: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   82: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   87: fsub
    //   88: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   93: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)F
    //   98: fmul
    //   99: fadd
    //   100: fstore #4
    //   102: fload_2
    //   103: fconst_0
    //   104: invokestatic lIIIIlIlllIlllII : (FF)I
    //   107: invokestatic lIIIIlIlllIllIlI : (I)Z
    //   110: ifeq -> 331
    //   113: fload_3
    //   114: fconst_0
    //   115: invokestatic lIIIIlIlllIlllII : (FF)I
    //   118: invokestatic lIIIIlIlllIllllI : (I)Z
    //   121: ifeq -> 196
    //   124: fload #4
    //   126: fload_2
    //   127: fconst_0
    //   128: invokestatic lIIIIlIlllIlllII : (FF)I
    //   131: invokestatic lIIIIlIlllIllllI : (I)Z
    //   134: ifeq -> 159
    //   137: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   140: iconst_2
    //   141: iaload
    //   142: ldc ''
    //   144: invokevirtual length : ()I
    //   147: pop
    //   148: ldc '   '
    //   150: invokevirtual length : ()I
    //   153: ineg
    //   154: iflt -> 164
    //   157: aconst_null
    //   158: areturn
    //   159: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   162: iconst_3
    //   163: iaload
    //   164: i2f
    //   165: fadd
    //   166: fstore #4
    //   168: ldc ''
    //   170: invokevirtual length : ()I
    //   173: pop
    //   174: ldc ' '
    //   176: invokevirtual length : ()I
    //   179: ldc ' '
    //   181: invokevirtual length : ()I
    //   184: ldc ' '
    //   186: invokevirtual length : ()I
    //   189: ishl
    //   190: ishl
    //   191: ifge -> 280
    //   194: aconst_null
    //   195: areturn
    //   196: fload_3
    //   197: fconst_0
    //   198: invokestatic lIIIIlIlllIlllIl : (FF)I
    //   201: invokestatic lIIIIlIlllIlllll : (I)Z
    //   204: ifeq -> 280
    //   207: fload #4
    //   209: fload_2
    //   210: fconst_0
    //   211: invokestatic lIIIIlIlllIlllII : (FF)I
    //   214: invokestatic lIIIIlIlllIllllI : (I)Z
    //   217: ifeq -> 271
    //   220: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   223: iconst_3
    //   224: iaload
    //   225: ldc ''
    //   227: invokevirtual length : ()I
    //   230: pop
    //   231: sipush #173
    //   234: sipush #168
    //   237: ixor
    //   238: ldc ' '
    //   240: invokevirtual length : ()I
    //   243: ishl
    //   244: sipush #131
    //   247: sipush #134
    //   250: ixor
    //   251: ldc ' '
    //   253: invokevirtual length : ()I
    //   256: ishl
    //   257: iconst_m1
    //   258: ixor
    //   259: iand
    //   260: ldc ' '
    //   262: invokevirtual length : ()I
    //   265: ineg
    //   266: if_icmpge -> 276
    //   269: aconst_null
    //   270: areturn
    //   271: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   274: iconst_2
    //   275: iaload
    //   276: i2f
    //   277: fadd
    //   278: fstore #4
    //   280: fconst_0
    //   281: fstore_3
    //   282: fload_2
    //   283: fconst_0
    //   284: invokestatic lIIIIlIlllIlllII : (FF)I
    //   287: invokestatic lIIIIlIlllIllllI : (I)Z
    //   290: ifeq -> 317
    //   293: fconst_1
    //   294: fstore_2
    //   295: ldc ''
    //   297: invokevirtual length : ()I
    //   300: pop
    //   301: ldc ' '
    //   303: invokevirtual length : ()I
    //   306: ineg
    //   307: ldc '   '
    //   309: invokevirtual length : ()I
    //   312: if_icmpne -> 331
    //   315: aconst_null
    //   316: areturn
    //   317: fload_2
    //   318: fconst_0
    //   319: invokestatic lIIIIlIlllIlllIl : (FF)I
    //   322: invokestatic lIIIIlIlllIlllll : (I)Z
    //   325: ifeq -> 331
    //   328: ldc -1.0
    //   330: fstore_2
    //   331: fload #4
    //   333: ldc 90.0
    //   335: fadd
    //   336: f2d
    //   337: <illegal opcode> 15 : (D)D
    //   342: <illegal opcode> 16 : (D)D
    //   347: dstore #5
    //   349: fload #4
    //   351: ldc 90.0
    //   353: fadd
    //   354: f2d
    //   355: <illegal opcode> 15 : (D)D
    //   360: <illegal opcode> 17 : (D)D
    //   365: dstore #7
    //   367: fload_2
    //   368: f2d
    //   369: dload_0
    //   370: dmul
    //   371: dload #7
    //   373: dmul
    //   374: fload_3
    //   375: f2d
    //   376: dload_0
    //   377: dmul
    //   378: dload #5
    //   380: dmul
    //   381: dadd
    //   382: dstore #9
    //   384: fload_2
    //   385: f2d
    //   386: dload_0
    //   387: dmul
    //   388: dload #5
    //   390: dmul
    //   391: fload_3
    //   392: f2d
    //   393: dload_0
    //   394: dmul
    //   395: dload #7
    //   397: dmul
    //   398: dsub
    //   399: dstore #11
    //   401: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   404: iconst_4
    //   405: iaload
    //   406: newarray double
    //   408: dup
    //   409: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   412: iconst_1
    //   413: iaload
    //   414: dload #9
    //   416: dastore
    //   417: dup
    //   418: getstatic me/stupitdog/bhp/aw.llIIlIIIIIIlII : [I
    //   421: iconst_0
    //   422: iaload
    //   423: dload #11
    //   425: dastore
    //   426: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	427	0	lllllllllllllllIllIIlllllllIIIIl	D
    //   21	406	2	lllllllllllllllIllIIlllllllIIIII	F
    //   42	385	3	lllllllllllllllIllIIllllllIlllll	F
    //   102	325	4	lllllllllllllllIllIIllllllIllllI	F
    //   349	78	5	lllllllllllllllIllIIllllllIlllIl	D
    //   367	60	7	lllllllllllllllIllIIllllllIlllII	D
    //   384	43	9	lllllllllllllllIllIIllllllIllIll	D
    //   401	26	11	lllllllllllllllIllIIllllllIllIlI	D
  }
  
  static {
    lIIIIlIlllIlIlll();
    lIIIIlIlllIlIllI();
    lIIIIlIlllIlIlIl();
    lIIIIlIlllIlIIIl();
  }
  
  private static CallSite lIIIIlIllIIlIIll(MethodHandles.Lookup lllllllllllllllIllIIllllllIlIIIl, String lllllllllllllllIllIIllllllIlIIII, MethodType lllllllllllllllIllIIllllllIIllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllllllIlIlll = llIIIlllIlllII[Integer.parseInt(lllllllllllllllIllIIllllllIlIIII)].split(llIIlIIIIIIIlI[llIIlIIIIIIlII[1]]);
      Class<?> lllllllllllllllIllIIllllllIlIllI = Class.forName(lllllllllllllllIllIIllllllIlIlll[llIIlIIIIIIlII[1]]);
      String lllllllllllllllIllIIllllllIlIlIl = lllllllllllllllIllIIllllllIlIlll[llIIlIIIIIIlII[0]];
      MethodHandle lllllllllllllllIllIIllllllIlIlII = null;
      int lllllllllllllllIllIIllllllIlIIll = lllllllllllllllIllIIllllllIlIlll[llIIlIIIIIIlII[5]].length();
      if (lIIIIlIllllIIIII(lllllllllllllllIllIIllllllIlIIll, llIIlIIIIIIlII[4])) {
        MethodType lllllllllllllllIllIIllllllIllIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllllllIlIlll[llIIlIIIIIIlII[4]], aw.class.getClassLoader());
        if (lIIIIlIllllIIIIl(lllllllllllllllIllIIllllllIlIIll, llIIlIIIIIIlII[4])) {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findVirtual(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIIl);
          "".length();
          if (-"   ".length() > 0)
            return null; 
        } else {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findStatic(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIIl);
        } 
        "".length();
        if ("   ".length() <= " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllllllIllIII = llIIIlllIlllIl[Integer.parseInt(lllllllllllllllIllIIllllllIlIlll[llIIlIIIIIIlII[4]])];
        if (lIIIIlIllllIIIIl(lllllllllllllllIllIIllllllIlIIll, llIIlIIIIIIlII[5])) {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findGetter(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIII);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else if (lIIIIlIllllIIIIl(lllllllllllllllIllIIllllllIlIIll, llIIlIIIIIIlII[6])) {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findStaticGetter(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIII);
          "".length();
          if (" ".length() << " ".length() > " ".length() << " ".length())
            return null; 
        } else if (lIIIIlIllllIIIIl(lllllllllllllllIllIIllllllIlIIll, llIIlIIIIIIlII[7])) {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findSetter(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIllllllIlIlII = lllllllllllllllIllIIllllllIlIIIl.findStaticSetter(lllllllllllllllIllIIllllllIlIllI, lllllllllllllllIllIIllllllIlIlIl, lllllllllllllllIllIIllllllIllIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllllllIlIlII);
    } catch (Exception lllllllllllllllIllIIllllllIlIIlI) {
      lllllllllllllllIllIIllllllIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlllIlIIIl() {
    llIIIlllIlllII = new String[llIIlIIIIIIlII[8]];
    llIIIlllIlllII[llIIlIIIIIIlII[9]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[0]];
    llIIIlllIlllII[llIIlIIIIIIlII[10]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[4]];
    llIIIlllIlllII[llIIlIIIIIIlII[7]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[5]];
    llIIIlllIlllII[llIIlIIIIIIlII[11]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[6]];
    llIIIlllIlllII[llIIlIIIIIIlII[12]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[7]];
    llIIIlllIlllII[llIIlIIIIIIlII[6]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[13]];
    llIIIlllIlllII[llIIlIIIIIIlII[13]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[14]];
    llIIIlllIlllII[llIIlIIIIIIlII[15]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[16]];
    llIIIlllIlllII[llIIlIIIIIIlII[5]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[12]];
    llIIIlllIlllII[llIIlIIIIIIlII[17]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[15]];
    llIIIlllIlllII[llIIlIIIIIIlII[18]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[11]];
    llIIIlllIlllII[llIIlIIIIIIlII[14]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[9]];
    llIIIlllIlllII[llIIlIIIIIIlII[4]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[19]];
    llIIIlllIlllII[llIIlIIIIIIlII[16]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[17]];
    llIIIlllIlllII[llIIlIIIIIIlII[0]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[18]];
    llIIIlllIlllII[llIIlIIIIIIlII[20]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[10]];
    llIIIlllIlllII[llIIlIIIIIIlII[1]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[20]];
    llIIIlllIlllII[llIIlIIIIIIlII[19]] = llIIlIIIIIIIlI[llIIlIIIIIIlII[8]];
    llIIIlllIlllIl = new Class[llIIlIIIIIIlII[6]];
    llIIIlllIlllIl[llIIlIIIIIIlII[1]] = float.class;
    llIIIlllIlllIl[llIIlIIIIIIlII[4]] = EntityPlayerSP.class;
    llIIIlllIlllIl[llIIlIIIIIIlII[0]] = double.class;
    llIIIlllIlllIl[llIIlIIIIIIlII[5]] = MovementInput.class;
  }
  
  private static void lIIIIlIlllIlIlIl() {
    llIIlIIIIIIIlI = new String[llIIlIIIIIIlII[21]];
    llIIlIIIIIIIlI[llIIlIIIIIIlII[1]] = lIIIIlIlllIlIIlI(llIIlIIIIIIIll[llIIlIIIIIIlII[1]], llIIlIIIIIIIll[llIIlIIIIIIlII[0]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[0]] = lIIIIlIlllIlIIll(llIIlIIIIIIIll[llIIlIIIIIIlII[4]], llIIlIIIIIIIll[llIIlIIIIIIlII[5]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[4]] = lIIIIlIlllIlIlII(llIIlIIIIIIIll[llIIlIIIIIIlII[6]], llIIlIIIIIIIll[llIIlIIIIIIlII[7]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[5]] = lIIIIlIlllIlIIlI(llIIlIIIIIIIll[llIIlIIIIIIlII[13]], llIIlIIIIIIIll[llIIlIIIIIIlII[14]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[6]] = lIIIIlIlllIlIIlI(llIIlIIIIIIIll[llIIlIIIIIIlII[16]], llIIlIIIIIIIll[llIIlIIIIIIlII[12]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[7]] = lIIIIlIlllIlIIlI(llIIlIIIIIIIll[llIIlIIIIIIlII[15]], llIIlIIIIIIIll[llIIlIIIIIIlII[11]]);
    llIIlIIIIIIIlI[llIIlIIIIIIlII[13]] = lIIIIlIlllIlIIll("DKZuO736rNQRComqlNR0PkltoeSH5ahirEuQnNf5ad2LcIMN8R2+avIf7j6ew8lPqubpxCW+6+M=", "LejoA");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[14]] = lIIIIlIlllIlIlII("BgATSwIBCwIGHQkDE0sMBAwCCxtGAAkRBhwcSSABHAwTHD8EBB4AHTs1XQMaBgY4Ul9eUVM6DlJNKwsKHEoKDAENBhUECRxKFwobAQoJSj8HEQ4KAVNMPV9PSA==", "hegeo");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[16]] = lIIIIlIlllIlIlII("IgoTTzwlAQICIy0JE08kOAYLTxwjGQIMNCIbLg8hORtdBzgpAwM+YHVdX1JjEw1dUWtsT0c=", "LogaQ");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[12]] = lIIIIlIlllIlIIlI("LkGgi10YhRKvdvHcKdUxWiRlPpnsRZkMSKxdiL38P5zmDyMGKW+bIDz2u2EAJwk/kSE6N7t0FQ+MFFNZrNNLfcKloVYi1JKETKkV5L+/1QWCyTNYtNWpPQ==", "YiZZw");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[15]] = lIIIIlIlllIlIIlI("gy9dDFlfIw/GmasKi8RtDqv9Q4p8TEbZXE5J9W2wc8PoIKJ0ncIspCZ3SfpLZSv3faf1S0H1z2M=", "TKOtw");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[11]] = lIIIIlIlllIlIlII("BxssO0EBGzQ9QSAbLjJVGRUIOwsEGzQpVUU+cx5VTQ==", "mzZZo");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[9]] = lIIIIlIlllIlIIll("lWd5Dvm7aIle2iWHeAfqH0EVfMUdLoDzAQdwyFBx+wsKKPZYQ4lJly/DjuQRrDYVCfsXxb46zR7qDs7FU9FNm0UZsJnWm7vu9UPmGS/bckbDPKKEa3EZsoCyA6WsZDFg2Vou5CxlGsHtCx8DBPbQ8tRTBTTH4TVoT1zHK4CSCO0=", "bQwrC");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[19]] = lIIIIlIlllIlIIlI("F83zsD/B605b8hso/maqEmgM0UEaz451c4D+i4lry9Ak+pdQZa7oqA==", "cHvRw");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[17]] = lIIIIlIlllIlIIll("VFsLSnIKw1Nn5yO0a+o93ZhKQfc0Huj8VzVmgtzQvNdqK2qfvBhD9MCSz3jcxkAOtt/bBQf+lJw=", "jhhZI");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[18]] = lIIIIlIlllIlIlII("CTQAaykOPxEmNgY3AGshCSUdMT1JFBoxLRMoOCwyDj8TByUUNE4jLQI9EBpzV2ZEdxsFI051fkdxVA==", "gQtED");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[10]] = lIIIIlIlllIlIIlI("F7AzjIaMyQsww4C6T4osJcQ6wBk1DEbB5KxU0RhmSaI=", "tqbfU");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[20]] = lIIIIlIlllIlIIll("H0N9A7dGKLcIDBeWNIUFQP4CqNKMm8vd+9Oo3iG90mqplzY4E6tjGRB1Bm/RJxW0slMSG85ouP1wDOTrx/+Zeg==", "wOlpr");
    llIIlIIIIIIIlI[llIIlIIIIIIlII[8]] = lIIIIlIlllIlIlII("PgcZZys5DAgqNDEEGWclPAsIJzJ+BwM9LyQbQwwoJAsZMBY8AxQsNAMyVy8vNQ4JFnFgU1p+GSpYXXNmcEI=", "PbmIF");
    llIIlIIIIIIIll = null;
  }
  
  private static void lIIIIlIlllIlIllI() {
    String str = (new Exception()).getStackTrace()[llIIlIIIIIIlII[1]].getFileName();
    llIIlIIIIIIIll = str.substring(str.indexOf("ä") + llIIlIIIIIIlII[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIlllIlIlII(String lllllllllllllllIllIIllllllIIllIl, String lllllllllllllllIllIIllllllIIllII) {
    lllllllllllllllIllIIllllllIIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllllllIIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllllllIIlIll = new StringBuilder();
    char[] lllllllllllllllIllIIllllllIIlIlI = lllllllllllllllIllIIllllllIIllII.toCharArray();
    int lllllllllllllllIllIIllllllIIlIIl = llIIlIIIIIIlII[1];
    char[] arrayOfChar1 = lllllllllllllllIllIIllllllIIllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIIIIIlII[1];
    while (lIIIIlIllllIIIlI(j, i)) {
      char lllllllllllllllIllIIllllllIIlllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllllllIIlIIl++;
      j++;
      "".length();
      if (((0x91 ^ 0x98) << "   ".length() & ((0xA0 ^ 0xA9) << "   ".length() ^ 0xFFFFFFFF)) >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllllllIIlIll);
  }
  
  private static String lIIIIlIlllIlIIll(String lllllllllllllllIllIIllllllIIIlIl, String lllllllllllllllIllIIllllllIIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllIIllllllIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllllllIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllllllIIIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllllllIIIlll.init(llIIlIIIIIIlII[4], lllllllllllllllIllIIllllllIIlIII);
      return new String(lllllllllllllllIllIIllllllIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllllllIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllllllIIIllI) {
      lllllllllllllllIllIIllllllIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIlllIlIIlI(String lllllllllllllllIllIIllllllIIIIII, String lllllllllllllllIllIIlllllIllllll) {
    try {
      SecretKeySpec lllllllllllllllIllIIllllllIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIllllll.getBytes(StandardCharsets.UTF_8)), llIIlIIIIIIlII[16]), "DES");
      Cipher lllllllllllllllIllIIllllllIIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIIllllllIIIIlI.init(llIIlIIIIIIlII[4], lllllllllllllllIllIIllllllIIIIll);
      return new String(lllllllllllllllIllIIllllllIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllllllIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllllllIIIIIl) {
      lllllllllllllllIllIIllllllIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlllIlIlll() {
    llIIlIIIIIIlII = new int[22];
    llIIlIIIIIIlII[0] = " ".length();
    llIIlIIIIIIlII[1] = (0x44 ^ 0x1F ^ (0x76 ^ 0x51) << " ".length()) << " ".length() & (((0xB2 ^ 0x97) << " ".length() ^ 0xEB ^ 0xB4) << " ".length() ^ -" ".length());
    llIIlIIIIIIlII[2] = -(0x0 ^ 0x2D);
    llIIlIIIIIIlII[3] = 100 + 110 - 74 + 9 ^ (0xB3 ^ 0x9C) << " ".length() << " ".length();
    llIIlIIIIIIlII[4] = " ".length() << " ".length();
    llIIlIIIIIIlII[5] = "   ".length();
    llIIlIIIIIIlII[6] = " ".length() << " ".length() << " ".length();
    llIIlIIIIIIlII[7] = 0x4B ^ 0x4E;
    llIIlIIIIIIlII[8] = (0x8D ^ 0x84) << " ".length();
    llIIlIIIIIIlII[9] = "   ".length() << " ".length() << " ".length();
    llIIlIIIIIIlII[10] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIIIIIlII[11] = 0x3C ^ 0x37;
    llIIlIIIIIIlII[12] = (0x57 ^ 0x5C) << "   ".length() ^ 0x1B ^ 0x4A;
    llIIlIIIIIIlII[13] = "   ".length() << " ".length();
    llIIlIIIIIIlII[14] = 0x50 ^ 0x57;
    llIIlIIIIIIlII[15] = (0x50 ^ 0x55) << " ".length();
    llIIlIIIIIIlII[16] = " ".length() << "   ".length();
    llIIlIIIIIIlII[17] = (" ".length() << "   ".length() ^ 0x91 ^ 0x9E) << " ".length();
    llIIlIIIIIIlII[18] = (0x7E ^ 0x69) << "   ".length() ^ 29 + 10 - -42 + 102;
    llIIlIIIIIIlII[19] = 0x3 ^ 0xE;
    llIIlIIIIIIlII[20] = 0xAF ^ 0xBE;
    llIIlIIIIIIlII[21] = 0x10 ^ 0x3;
  }
  
  private static boolean lIIIIlIllllIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIllllIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIlllIllIll(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIlIlllIllIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlIlllIllIIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlIlllIlllll(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lIIIIlIlllIllllI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lIIIIlIlllIllIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIlIlllIlllII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIlIlllIlllIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\aw.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */