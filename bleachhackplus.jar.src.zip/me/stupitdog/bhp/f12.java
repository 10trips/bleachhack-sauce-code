package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class f12 {
  public static final Minecraft mc;
  
  private static String[] llIIlIIlIIIIIl;
  
  private static Class[] llIIlIIlIIIIlI;
  
  private static final String[] llIIlIlIlIlIll;
  
  private static String[] llIIlIlIlIllII;
  
  private static final int[] llIIlIlIlIllIl;
  
  public static boolean placeBlock(BlockPos lllllllllllllllIllIIlIlIIllIIIIl, EnumHand lllllllllllllllIllIIlIlIIllIIIII, boolean lllllllllllllllIllIIlIlIIlIlllll, boolean lllllllllllllllIllIIlIlIIlIllllI, boolean lllllllllllllllIllIIlIlIIlIlllIl) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore #5
    //   7: aload_0
    //   8: <illegal opcode> 0 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/EnumFacing;
    //   13: astore #6
    //   15: aload #6
    //   17: invokestatic lIIIIllllIIIlIII : (Ljava/lang/Object;)Z
    //   20: ifeq -> 26
    //   23: iload #4
    //   25: ireturn
    //   26: aload_0
    //   27: aload #6
    //   29: <illegal opcode> 1 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   34: astore #7
    //   36: aload #6
    //   38: <illegal opcode> 2 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   43: astore #8
    //   45: new net/minecraft/util/math/Vec3d
    //   48: dup
    //   49: aload #7
    //   51: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   54: ldc2_w 0.5
    //   57: ldc2_w 0.5
    //   60: ldc2_w 0.5
    //   63: <illegal opcode> 3 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   68: new net/minecraft/util/math/Vec3d
    //   71: dup
    //   72: aload #8
    //   74: <illegal opcode> 4 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   79: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   82: ldc2_w 0.5
    //   85: <illegal opcode> 5 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   90: <illegal opcode> 6 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   95: astore #9
    //   97: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   102: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   107: aload #7
    //   109: <illegal opcode> 9 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   114: <illegal opcode> 10 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   119: astore #10
    //   121: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   126: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   131: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   136: invokestatic lIIIIllllIIIlIIl : (I)Z
    //   139: ifeq -> 211
    //   142: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   147: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   152: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   157: new net/minecraft/network/play/client/CPacketEntityAction
    //   160: dup
    //   161: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   166: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   171: <illegal opcode> 14 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   176: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   179: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   184: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   189: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   194: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   197: iconst_1
    //   198: iaload
    //   199: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;Z)V
    //   204: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   207: iconst_1
    //   208: iaload
    //   209: istore #5
    //   211: iload_2
    //   212: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   215: ifeq -> 230
    //   218: aload #9
    //   220: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   223: iconst_1
    //   224: iaload
    //   225: <illegal opcode> 17 : (Lnet/minecraft/util/math/Vec3d;Z)V
    //   230: aload #7
    //   232: aload #9
    //   234: aload_1
    //   235: aload #8
    //   237: iload_3
    //   238: <illegal opcode> 18 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;Z)V
    //   243: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   248: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   253: <illegal opcode> 19 : ()Lnet/minecraft/util/EnumHand;
    //   258: <illegal opcode> 20 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   263: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   268: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   271: iconst_2
    //   272: iaload
    //   273: putfield field_71467_ac : I
    //   276: iload #5
    //   278: invokestatic lIIIIllllIIIlIIl : (I)Z
    //   281: ifeq -> 292
    //   284: iload #4
    //   286: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   289: ifeq -> 339
    //   292: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   295: iconst_1
    //   296: iaload
    //   297: ldc ''
    //   299: invokevirtual length : ()I
    //   302: pop
    //   303: bipush #32
    //   305: bipush #37
    //   307: ixor
    //   308: ifgt -> 344
    //   311: sipush #154
    //   314: sipush #181
    //   317: ixor
    //   318: ldc ' '
    //   320: invokevirtual length : ()I
    //   323: ishl
    //   324: bipush #56
    //   326: bipush #23
    //   328: ixor
    //   329: ldc ' '
    //   331: invokevirtual length : ()I
    //   334: ishl
    //   335: iconst_m1
    //   336: ixor
    //   337: iand
    //   338: ireturn
    //   339: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   342: iconst_0
    //   343: iaload
    //   344: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	345	0	lllllllllllllllIllIIlIlIIllIIIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	345	1	lllllllllllllllIllIIlIlIIllIIIII	Lnet/minecraft/util/EnumHand;
    //   0	345	2	lllllllllllllllIllIIlIlIIlIlllll	Z
    //   0	345	3	lllllllllllllllIllIIlIlIIlIllllI	Z
    //   0	345	4	lllllllllllllllIllIIlIlIIlIlllIl	Z
    //   7	338	5	lllllllllllllllIllIIlIlIIlIlllII	Z
    //   15	330	6	lllllllllllllllIllIIlIlIIlIllIll	Lnet/minecraft/util/EnumFacing;
    //   36	309	7	lllllllllllllllIllIIlIlIIlIllIlI	Lnet/minecraft/util/math/BlockPos;
    //   45	300	8	lllllllllllllllIllIIlIlIIlIllIIl	Lnet/minecraft/util/EnumFacing;
    //   97	248	9	lllllllllllllllIllIIlIlIIlIllIII	Lnet/minecraft/util/math/Vec3d;
    //   121	224	10	lllllllllllllllIllIIlIlIIlIlIlll	Lnet/minecraft/block/Block;
  }
  
  public static List<EnumFacing> getPossibleSides(BlockPos lllllllllllllllIllIIlIlIIlIlIIll) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: <illegal opcode> 21 : ()[Lnet/minecraft/util/EnumFacing;
    //   13: astore_2
    //   14: aload_2
    //   15: arraylength
    //   16: istore_3
    //   17: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   20: iconst_0
    //   21: iaload
    //   22: istore #4
    //   24: iload #4
    //   26: iload_3
    //   27: invokestatic lIIIIllllIIIlIll : (II)Z
    //   30: ifeq -> 170
    //   33: aload_2
    //   34: iload #4
    //   36: aaload
    //   37: astore #5
    //   39: aload_0
    //   40: aload #5
    //   42: <illegal opcode> 1 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   47: astore #6
    //   49: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   54: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   59: aload #6
    //   61: <illegal opcode> 9 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   66: <illegal opcode> 10 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   71: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   76: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   81: aload #6
    //   83: <illegal opcode> 9 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   88: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   91: iconst_0
    //   92: iaload
    //   93: <illegal opcode> 22 : (Lnet/minecraft/block/Block;Lnet/minecraft/block/state/IBlockState;Z)Z
    //   98: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   101: ifeq -> 155
    //   104: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   109: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   114: aload #6
    //   116: <illegal opcode> 9 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   121: astore #7
    //   123: aload #7
    //   125: <illegal opcode> 23 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/material/Material;
    //   130: <illegal opcode> 24 : (Lnet/minecraft/block/material/Material;)Z
    //   135: invokestatic lIIIIllllIIIlIIl : (I)Z
    //   138: ifeq -> 155
    //   141: aload_1
    //   142: aload #5
    //   144: <illegal opcode> 25 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   149: ldc ''
    //   151: invokevirtual length : ()I
    //   154: pop2
    //   155: iinc #4, 1
    //   158: ldc ''
    //   160: invokevirtual length : ()I
    //   163: pop
    //   164: aconst_null
    //   165: ifnull -> 24
    //   168: aconst_null
    //   169: areturn
    //   170: aload_1
    //   171: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   123	32	7	lllllllllllllllIllIIlIlIIlIlIllI	Lnet/minecraft/block/state/IBlockState;
    //   49	106	6	lllllllllllllllIllIIlIlIIlIlIlIl	Lnet/minecraft/util/math/BlockPos;
    //   39	116	5	lllllllllllllllIllIIlIlIIlIlIlII	Lnet/minecraft/util/EnumFacing;
    //   0	172	0	lllllllllllllllIllIIlIlIIlIlIIll	Lnet/minecraft/util/math/BlockPos;
    //   8	164	1	lllllllllllllllIllIIlIlIIlIlIIlI	Ljava/util/List;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	164	1	lllllllllllllllIllIIlIlIIlIlIIlI	Ljava/util/List<Lnet/minecraft/util/EnumFacing;>;
  }
  
  public static EnumFacing getFirstFacing(BlockPos lllllllllllllllIllIIlIlIIlIlIIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 26 : (Lnet/minecraft/util/math/BlockPos;)Ljava/util/List;
    //   6: <illegal opcode> 27 : (Ljava/util/List;)Ljava/util/Iterator;
    //   11: astore_1
    //   12: aload_1
    //   13: <illegal opcode> 28 : (Ljava/util/Iterator;)Z
    //   18: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   21: ifeq -> 36
    //   24: aload_1
    //   25: <illegal opcode> 29 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   30: checkcast net/minecraft/util/EnumFacing
    //   33: astore_2
    //   34: aload_2
    //   35: areturn
    //   36: aconst_null
    //   37: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   34	2	2	lllllllllllllllIllIIlIlIIlIlIIIl	Lnet/minecraft/util/EnumFacing;
    //   0	38	0	lllllllllllllllIllIIlIlIIlIlIIII	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static Vec3d getEyesPos() {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: <illegal opcode> 30 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   19: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 31 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   34: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   39: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   44: <illegal opcode> 32 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   49: f2d
    //   50: dadd
    //   51: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   66: invokespecial <init> : (DDD)V
    //   69: areturn
  }
  
  public static float[] getLegitRotations(Vec3d lllllllllllllllIllIIlIlIIlIIllll) {
    // Byte code:
    //   0: <illegal opcode> 34 : ()Lnet/minecraft/util/math/Vec3d;
    //   5: astore_1
    //   6: aload_0
    //   7: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   12: aload_1
    //   13: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   18: dsub
    //   19: dstore_2
    //   20: aload_0
    //   21: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   26: aload_1
    //   27: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   32: dsub
    //   33: dstore #4
    //   35: aload_0
    //   36: <illegal opcode> 37 : (Lnet/minecraft/util/math/Vec3d;)D
    //   41: aload_1
    //   42: <illegal opcode> 37 : (Lnet/minecraft/util/math/Vec3d;)D
    //   47: dsub
    //   48: dstore #6
    //   50: dload_2
    //   51: dload_2
    //   52: dmul
    //   53: dload #6
    //   55: dload #6
    //   57: dmul
    //   58: dadd
    //   59: <illegal opcode> 38 : (D)D
    //   64: dstore #8
    //   66: dload #6
    //   68: dload_2
    //   69: <illegal opcode> 39 : (DD)D
    //   74: <illegal opcode> 40 : (D)D
    //   79: d2f
    //   80: ldc_w 90.0
    //   83: fsub
    //   84: fstore #10
    //   86: dload #4
    //   88: dload #8
    //   90: <illegal opcode> 39 : (DD)D
    //   95: <illegal opcode> 40 : (D)D
    //   100: dneg
    //   101: d2f
    //   102: fstore #11
    //   104: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   107: iconst_3
    //   108: iaload
    //   109: newarray float
    //   111: dup
    //   112: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   115: iconst_0
    //   116: iaload
    //   117: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   122: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   127: <illegal opcode> 41 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   132: fload #10
    //   134: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   139: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   144: <illegal opcode> 41 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   149: fsub
    //   150: <illegal opcode> 42 : (F)F
    //   155: fadd
    //   156: fastore
    //   157: dup
    //   158: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   161: iconst_1
    //   162: iaload
    //   163: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   168: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   173: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   178: fload #11
    //   180: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   185: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   190: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   195: fsub
    //   196: <illegal opcode> 42 : (F)F
    //   201: fadd
    //   202: fastore
    //   203: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	204	0	lllllllllllllllIllIIlIlIIlIIllll	Lnet/minecraft/util/math/Vec3d;
    //   6	198	1	lllllllllllllllIllIIlIlIIlIIlllI	Lnet/minecraft/util/math/Vec3d;
    //   20	184	2	lllllllllllllllIllIIlIlIIlIIllIl	D
    //   35	169	4	lllllllllllllllIllIIlIlIIlIIllII	D
    //   50	154	6	lllllllllllllllIllIIlIlIIlIIlIll	D
    //   66	138	8	lllllllllllllllIllIIlIlIIlIIlIlI	D
    //   86	118	10	lllllllllllllllIllIIlIlIIlIIlIIl	F
    //   104	100	11	lllllllllllllllIllIIlIlIIlIIlIII	F
  }
  
  public static void faceVector(Vec3d lllllllllllllllIllIIlIlIIlIIIlll, boolean lllllllllllllllIllIIlIlIIlIIIllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 44 : (Lnet/minecraft/util/math/Vec3d;)[F
    //   6: astore_2
    //   7: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   12: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   17: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   22: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   25: dup
    //   26: aload_2
    //   27: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   30: iconst_0
    //   31: iaload
    //   32: faload
    //   33: iload_1
    //   34: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   37: ifeq -> 86
    //   40: aload_2
    //   41: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   44: iconst_1
    //   45: iaload
    //   46: faload
    //   47: f2i
    //   48: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   51: iconst_4
    //   52: iaload
    //   53: <illegal opcode> 45 : (II)I
    //   58: i2f
    //   59: ldc ''
    //   61: invokevirtual length : ()I
    //   64: pop
    //   65: bipush #59
    //   67: bipush #60
    //   69: ixor
    //   70: ldc ' '
    //   72: invokevirtual length : ()I
    //   75: ishl
    //   76: bipush #117
    //   78: bipush #126
    //   80: ixor
    //   81: ixor
    //   82: ifgt -> 93
    //   85: return
    //   86: aload_2
    //   87: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   90: iconst_1
    //   91: iaload
    //   92: faload
    //   93: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   98: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   103: <illegal opcode> 46 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   108: invokespecial <init> : (FFZ)V
    //   111: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   116: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	117	0	lllllllllllllllIllIIlIlIIlIIIlll	Lnet/minecraft/util/math/Vec3d;
    //   0	117	1	lllllllllllllllIllIIlIlIIlIIIllI	Z
    //   7	110	2	lllllllllllllllIllIIlIlIIlIIIlIl	[F
  }
  
  public static void rightClickBlock(BlockPos lllllllllllllllIllIIlIlIIlIIIIIl, Vec3d lllllllllllllllIllIIlIlIIlIIIIII, EnumHand lllllllllllllllIllIIlIlIIIllllll, EnumFacing lllllllllllllllIllIIlIlIIIlllllI, boolean lllllllllllllllIllIIlIlIIIllllIl) {
    // Byte code:
    //   0: iload #4
    //   2: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   5: ifeq -> 122
    //   8: aload_1
    //   9: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   14: aload_0
    //   15: <illegal opcode> 47 : (Lnet/minecraft/util/math/BlockPos;)I
    //   20: i2d
    //   21: dsub
    //   22: d2f
    //   23: fstore #5
    //   25: aload_1
    //   26: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   31: aload_0
    //   32: <illegal opcode> 48 : (Lnet/minecraft/util/math/BlockPos;)I
    //   37: i2d
    //   38: dsub
    //   39: d2f
    //   40: fstore #6
    //   42: aload_1
    //   43: <illegal opcode> 37 : (Lnet/minecraft/util/math/Vec3d;)D
    //   48: aload_0
    //   49: <illegal opcode> 49 : (Lnet/minecraft/util/math/BlockPos;)I
    //   54: i2d
    //   55: dsub
    //   56: d2f
    //   57: fstore #7
    //   59: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   64: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   69: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   74: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   77: dup
    //   78: aload_0
    //   79: aload_3
    //   80: aload_2
    //   81: fload #5
    //   83: fload #6
    //   85: fload #7
    //   87: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   90: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   95: ldc ''
    //   97: invokevirtual length : ()I
    //   100: pop
    //   101: ldc ' '
    //   103: invokevirtual length : ()I
    //   106: ldc ' '
    //   108: invokevirtual length : ()I
    //   111: ldc ' '
    //   113: invokevirtual length : ()I
    //   116: ishl
    //   117: ishl
    //   118: ifge -> 167
    //   121: return
    //   122: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   127: <illegal opcode> 50 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   132: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   137: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   142: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   147: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   152: aload_0
    //   153: aload_3
    //   154: aload_1
    //   155: aload_2
    //   156: <illegal opcode> 51 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   161: ldc ''
    //   163: invokevirtual length : ()I
    //   166: pop2
    //   167: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   172: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   177: <illegal opcode> 19 : ()Lnet/minecraft/util/EnumHand;
    //   182: <illegal opcode> 20 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   187: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   192: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   195: iconst_2
    //   196: iaload
    //   197: putfield field_71467_ac : I
    //   200: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   25	70	5	lllllllllllllllIllIIlIlIIlIIIlII	F
    //   42	53	6	lllllllllllllllIllIIlIlIIlIIIIll	F
    //   59	36	7	lllllllllllllllIllIIlIlIIlIIIIlI	F
    //   0	201	0	lllllllllllllllIllIIlIlIIlIIIIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	201	1	lllllllllllllllIllIIlIlIIlIIIIII	Lnet/minecraft/util/math/Vec3d;
    //   0	201	2	lllllllllllllllIllIIlIlIIIllllll	Lnet/minecraft/util/EnumHand;
    //   0	201	3	lllllllllllllllIllIIlIlIIIlllllI	Lnet/minecraft/util/EnumFacing;
    //   0	201	4	lllllllllllllllIllIIlIlIIIllllIl	Z
  }
  
  public static int findHotbarBlock(Class lllllllllllllllIllIIlIlIIIlllIIl) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore_1
    //   6: iload_1
    //   7: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   10: iconst_5
    //   11: iaload
    //   12: invokestatic lIIIIllllIIIlIll : (II)Z
    //   15: ifeq -> 273
    //   18: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   23: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   28: <illegal opcode> 52 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   33: iload_1
    //   34: <illegal opcode> 53 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   39: astore_2
    //   40: aload_2
    //   41: <illegal opcode> 54 : ()Lnet/minecraft/item/ItemStack;
    //   46: invokestatic lIIIIllllIIIllII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   49: ifeq -> 114
    //   52: ldc ''
    //   54: invokevirtual length : ()I
    //   57: pop
    //   58: bipush #112
    //   60: bipush #125
    //   62: ixor
    //   63: ldc ' '
    //   65: invokevirtual length : ()I
    //   68: ldc ' '
    //   70: invokevirtual length : ()I
    //   73: ishl
    //   74: ishl
    //   75: bipush #10
    //   77: bipush #7
    //   79: ixor
    //   80: ldc ' '
    //   82: invokevirtual length : ()I
    //   85: ldc ' '
    //   87: invokevirtual length : ()I
    //   90: ishl
    //   91: ishl
    //   92: iconst_m1
    //   93: ixor
    //   94: iand
    //   95: ifeq -> 179
    //   98: sipush #147
    //   101: sipush #198
    //   104: ixor
    //   105: bipush #83
    //   107: bipush #6
    //   109: ixor
    //   110: iconst_m1
    //   111: ixor
    //   112: iand
    //   113: ireturn
    //   114: aload_0
    //   115: aload_2
    //   116: <illegal opcode> 55 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   121: <illegal opcode> 56 : (Ljava/lang/Class;Ljava/lang/Object;)Z
    //   126: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   129: ifeq -> 134
    //   132: iload_1
    //   133: ireturn
    //   134: aload_2
    //   135: <illegal opcode> 55 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   140: instanceof net/minecraft/item/ItemBlock
    //   143: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   146: ifeq -> 179
    //   149: aload_2
    //   150: <illegal opcode> 55 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   155: checkcast net/minecraft/item/ItemBlock
    //   158: <illegal opcode> 57 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   163: astore_3
    //   164: aload_0
    //   165: aload_3
    //   166: <illegal opcode> 56 : (Ljava/lang/Class;Ljava/lang/Object;)Z
    //   171: invokestatic lIIIIllllIIIlIlI : (I)Z
    //   174: ifeq -> 179
    //   177: iload_1
    //   178: ireturn
    //   179: iinc #1, 1
    //   182: ldc ''
    //   184: invokevirtual length : ()I
    //   187: pop
    //   188: ldc ' '
    //   190: invokevirtual length : ()I
    //   193: ldc ' '
    //   195: invokevirtual length : ()I
    //   198: ldc ' '
    //   200: invokevirtual length : ()I
    //   203: ishl
    //   204: ishl
    //   205: sipush #201
    //   208: sipush #192
    //   211: ixor
    //   212: ldc ' '
    //   214: invokevirtual length : ()I
    //   217: ldc ' '
    //   219: invokevirtual length : ()I
    //   222: ishl
    //   223: ishl
    //   224: bipush #14
    //   226: bipush #7
    //   228: ixor
    //   229: ldc ' '
    //   231: invokevirtual length : ()I
    //   234: ldc ' '
    //   236: invokevirtual length : ()I
    //   239: ishl
    //   240: ishl
    //   241: iconst_m1
    //   242: ixor
    //   243: iand
    //   244: if_icmpgt -> 6
    //   247: bipush #65
    //   249: bipush #68
    //   251: ixor
    //   252: ldc ' '
    //   254: invokevirtual length : ()I
    //   257: ishl
    //   258: bipush #21
    //   260: bipush #16
    //   262: ixor
    //   263: ldc ' '
    //   265: invokevirtual length : ()I
    //   268: ishl
    //   269: iconst_m1
    //   270: ixor
    //   271: iand
    //   272: ireturn
    //   273: getstatic me/stupitdog/bhp/f12.llIIlIlIlIllIl : [I
    //   276: bipush #6
    //   278: iaload
    //   279: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   164	15	3	lllllllllllllllIllIIlIlIIIllllII	Lnet/minecraft/block/Block;
    //   40	139	2	lllllllllllllllIllIIlIlIIIlllIll	Lnet/minecraft/item/ItemStack;
    //   6	267	1	lllllllllllllllIllIIlIlIIIlllIlI	I
    //   0	280	0	lllllllllllllllIllIIlIlIIIlllIIl	Ljava/lang/Class;
  }
  
  public static void switchToSlot(int lllllllllllllllIllIIlIlIIIlllIII, boolean lllllllllllllllIllIIlIlIIIllIlll) {
    // Byte code:
    //   0: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   15: new net/minecraft/network/play/client/CPacketHeldItemChange
    //   18: dup
    //   19: iload_0
    //   20: invokespecial <init> : (I)V
    //   23: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   28: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   38: <illegal opcode> 52 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   43: iload_0
    //   44: putfield field_70461_c : I
    //   47: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 50 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   57: <illegal opcode> 58 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   62: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	63	0	lllllllllllllllIllIIlIlIIIlllIII	I
    //   0	63	1	lllllllllllllllIllIIlIlIIIllIlll	Z
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIllllIIIIlll : ()V
    //   3: invokestatic lIIIIllllIIIIllI : ()V
    //   6: invokestatic lIIIIllllIIIIlIl : ()V
    //   9: invokestatic lIIIIllllIIIIIIl : ()V
    //   12: <illegal opcode> 59 : ()Lnet/minecraft/client/Minecraft;
    //   17: putstatic me/stupitdog/bhp/f12.mc : Lnet/minecraft/client/Minecraft;
    //   20: return
  }
  
  private static CallSite lIIIIllIIlllIlIl(MethodHandles.Lookup lllllllllllllllIllIIlIlIIIlIlllI, String lllllllllllllllIllIIlIlIIIlIllIl, MethodType lllllllllllllllIllIIlIlIIIlIllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlIlIIIllIlII = llIIlIIlIIIIIl[Integer.parseInt(lllllllllllllllIllIIlIlIIIlIllIl)].split(llIIlIlIlIlIll[llIIlIlIlIllIl[0]]);
      Class<?> lllllllllllllllIllIIlIlIIIllIIll = Class.forName(lllllllllllllllIllIIlIlIIIllIlII[llIIlIlIlIllIl[0]]);
      String lllllllllllllllIllIIlIlIIIllIIlI = lllllllllllllllIllIIlIlIIIllIlII[llIIlIlIlIllIl[1]];
      MethodHandle lllllllllllllllIllIIlIlIIIllIIIl = null;
      int lllllllllllllllIllIIlIlIIIllIIII = lllllllllllllllIllIIlIlIIIllIlII[llIIlIlIlIllIl[7]].length();
      if (lIIIIllllIIIllIl(lllllllllllllllIllIIlIlIIIllIIII, llIIlIlIlIllIl[3])) {
        MethodType lllllllllllllllIllIIlIlIIIllIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlIlIIIllIlII[llIIlIlIlIllIl[3]], f12.class.getClassLoader());
        if (lIIIIllllIIIlllI(lllllllllllllllIllIIlIlIIIllIIII, llIIlIlIlIllIl[3])) {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findVirtual(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIllI);
          "".length();
          if (-(0x89 ^ 0x8D) > 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findStatic(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIllI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() == "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlIlIIIllIlIl = llIIlIIlIIIIlI[Integer.parseInt(lllllllllllllllIllIIlIlIIIllIlII[llIIlIlIlIllIl[3]])];
        if (lIIIIllllIIIlllI(lllllllllllllllIllIIlIlIIIllIIII, llIIlIlIlIllIl[7])) {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findGetter(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIlIl);
          "".length();
          if (" ".length() <= -" ".length())
            return null; 
        } else if (lIIIIllllIIIlllI(lllllllllllllllIllIIlIlIIIllIIII, llIIlIlIlIllIl[2])) {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findStaticGetter(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIlIl);
          "".length();
          if ("   ".length() < "   ".length())
            return null; 
        } else if (lIIIIllllIIIlllI(lllllllllllllllIllIIlIlIIIllIIII, llIIlIlIlIllIl[8])) {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findSetter(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIlIl);
          "".length();
          if (-("   ".length() << " ".length() << " ".length() << " ".length() ^ (0x9A ^ 0x97) << " ".length() << " ".length()) >= 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIlIIIllIIIl = lllllllllllllllIllIIlIlIIIlIlllI.findStaticSetter(lllllllllllllllIllIIlIlIIIllIIll, lllllllllllllllIllIIlIlIIIllIIlI, lllllllllllllllIllIIlIlIIIllIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlIlIIIllIIIl);
    } catch (Exception lllllllllllllllIllIIlIlIIIlIllll) {
      lllllllllllllllIllIIlIlIIIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllllIIIIIIl() {
    llIIlIIlIIIIIl = new String[llIIlIlIlIllIl[9]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[10]] = llIIlIlIlIlIll[llIIlIlIlIllIl[1]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[11]] = llIIlIlIlIlIll[llIIlIlIlIllIl[3]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[12]] = llIIlIlIlIlIll[llIIlIlIlIllIl[7]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[13]] = llIIlIlIlIlIll[llIIlIlIlIllIl[2]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[14]] = llIIlIlIlIlIll[llIIlIlIlIllIl[8]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[1]] = llIIlIlIlIlIll[llIIlIlIlIllIl[15]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[16]] = llIIlIlIlIlIll[llIIlIlIlIllIl[17]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[18]] = llIIlIlIlIlIll[llIIlIlIlIllIl[19]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[20]] = llIIlIlIlIlIll[llIIlIlIlIllIl[5]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[21]] = llIIlIlIlIlIll[llIIlIlIlIllIl[22]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[0]] = llIIlIlIlIlIll[llIIlIlIlIllIl[23]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[24]] = llIIlIlIlIlIll[llIIlIlIlIllIl[10]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[25]] = llIIlIlIlIlIll[llIIlIlIlIllIl[26]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[27]] = llIIlIlIlIlIll[llIIlIlIlIllIl[24]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[28]] = llIIlIlIlIlIll[llIIlIlIlIllIl[28]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[19]] = llIIlIlIlIlIll[llIIlIlIlIllIl[18]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[29]] = llIIlIlIlIlIll[llIIlIlIlIllIl[30]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[31]] = llIIlIlIlIlIll[llIIlIlIlIllIl[32]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[33]] = llIIlIlIlIlIll[llIIlIlIlIllIl[34]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[35]] = llIIlIlIlIlIll[llIIlIlIlIllIl[36]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[37]] = llIIlIlIlIlIll[llIIlIlIlIllIl[38]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[39]] = llIIlIlIlIlIll[llIIlIlIlIllIl[40]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[23]] = llIIlIlIlIlIll[llIIlIlIlIllIl[41]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[42]] = llIIlIlIlIlIll[llIIlIlIlIllIl[43]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[26]] = llIIlIlIlIlIll[llIIlIlIlIllIl[44]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[41]] = llIIlIlIlIlIll[llIIlIlIlIllIl[45]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[46]] = llIIlIlIlIlIll[llIIlIlIlIllIl[47]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[32]] = llIIlIlIlIlIll[llIIlIlIlIllIl[48]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[49]] = llIIlIlIlIlIll[llIIlIlIlIllIl[11]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[36]] = llIIlIlIlIlIll[llIIlIlIlIllIl[31]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[45]] = llIIlIlIlIlIll[llIIlIlIlIllIl[50]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[51]] = llIIlIlIlIlIll[llIIlIlIlIllIl[46]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[40]] = llIIlIlIlIlIll[llIIlIlIlIllIl[12]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[52]] = llIIlIlIlIlIll[llIIlIlIlIllIl[20]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[22]] = llIIlIlIlIlIll[llIIlIlIlIllIl[42]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[53]] = llIIlIlIlIlIll[llIIlIlIlIllIl[54]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[7]] = llIIlIlIlIlIll[llIIlIlIlIllIl[16]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[44]] = llIIlIlIlIlIll[llIIlIlIlIllIl[13]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[2]] = llIIlIlIlIlIll[llIIlIlIlIllIl[37]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[43]] = llIIlIlIlIlIll[llIIlIlIlIllIl[39]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[54]] = llIIlIlIlIlIll[llIIlIlIlIllIl[35]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[50]] = llIIlIlIlIlIll[llIIlIlIlIllIl[51]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[55]] = llIIlIlIlIlIll[llIIlIlIlIllIl[56]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[57]] = llIIlIlIlIlIll[llIIlIlIlIllIl[49]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[38]] = llIIlIlIlIlIll[llIIlIlIlIllIl[58]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[58]] = llIIlIlIlIlIll[llIIlIlIlIllIl[53]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[59]] = llIIlIlIlIlIll[llIIlIlIlIllIl[33]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[60]] = llIIlIlIlIlIll[llIIlIlIlIllIl[60]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[61]] = llIIlIlIlIlIll[llIIlIlIlIllIl[61]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[17]] = llIIlIlIlIlIll[llIIlIlIlIllIl[62]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[8]] = llIIlIlIlIlIll[llIIlIlIlIllIl[55]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[30]] = llIIlIlIlIlIll[llIIlIlIlIllIl[52]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[47]] = llIIlIlIlIlIll[llIIlIlIlIllIl[27]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[48]] = llIIlIlIlIlIll[llIIlIlIlIllIl[21]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[15]] = llIIlIlIlIlIll[llIIlIlIlIllIl[14]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[62]] = llIIlIlIlIlIll[llIIlIlIlIllIl[29]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[34]] = llIIlIlIlIlIll[llIIlIlIlIllIl[59]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[5]] = llIIlIlIlIlIll[llIIlIlIlIllIl[57]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[3]] = llIIlIlIlIlIll[llIIlIlIlIllIl[25]];
    llIIlIIlIIIIIl[llIIlIlIlIllIl[56]] = llIIlIlIlIlIll[llIIlIlIlIllIl[9]];
    llIIlIIlIIIIlI = new Class[llIIlIlIlIllIl[26]];
    llIIlIIlIIIIlI[llIIlIlIlIllIl[22]] = PlayerControllerMP.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[19]] = float.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[10]] = ItemStack.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[17]] = double.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[1]] = WorldClient.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[7]] = NetHandlerPlayClient.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[0]] = Minecraft.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[5]] = boolean.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[8]] = EnumHand.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[23]] = InventoryPlayer.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[15]] = int.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[2]] = CPacketEntityAction.Action.class;
    llIIlIIlIIIIlI[llIIlIlIlIllIl[3]] = EntityPlayerSP.class;
  }
  
  private static void lIIIIllllIIIIlIl() {
    llIIlIlIlIlIll = new String[llIIlIlIlIllIl[63]];
    llIIlIlIlIlIll[llIIlIlIlIllIl[0]] = lIIIIllllIIIIIlI(llIIlIlIlIllII[llIIlIlIlIllIl[0]], llIIlIlIlIllII[llIIlIlIlIllIl[1]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[1]] = lIIIIllllIIIIIll(llIIlIlIlIllII[llIIlIlIlIllIl[3]], llIIlIlIlIllII[llIIlIlIlIllIl[7]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[3]] = lIIIIllllIIIIIlI(llIIlIlIlIllII[llIIlIlIlIllIl[2]], llIIlIlIlIllII[llIIlIlIlIllIl[8]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[7]] = lIIIIllllIIIIIlI(llIIlIlIlIllII[llIIlIlIlIllIl[15]], llIIlIlIlIllII[llIIlIlIlIllIl[17]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[2]] = lIIIIllllIIIIIll(llIIlIlIlIllII[llIIlIlIlIllIl[19]], llIIlIlIlIllII[llIIlIlIlIllIl[5]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[8]] = lIIIIllllIIIIIlI(llIIlIlIlIllII[llIIlIlIlIllIl[22]], llIIlIlIlIllII[llIIlIlIlIllIl[23]]);
    llIIlIlIlIlIll[llIIlIlIlIllIl[15]] = lIIIIllllIIIIIll("hD5fzc44Ui+ylg99bywy/IUu4Ka2PXwx26c8v5Ca8L7UjNSf2zCCSRSiga18fxPzJquU0ZkCm4Yan5QFtG0nm04e37hIdiRkrcIowMBb+kYmq5TRmQKbhhqflAW0bSebZGjuolUpZ5PV4R5I1i/RUig5RMratsiB", "BSWnP");
    llIIlIlIlIlIll[llIIlIlIlIllIl[17]] = lIIIIllllIIIIIll("WBJkzqDBIjaqX08uX07Ht9yOQ1VR0m8pf37M8CsOXbftHR0FrhTeIz5z/Dw+u0mz+qCUSehgOGc=", "WfHVi");
    llIIlIlIlIlIll[llIIlIlIlIllIl[19]] = lIIIIllllIIIIIlI("CIpgN807z2NLIjmXMj7+obGZfHS6FxLfNxdgwo33uPfl8TsAsS174GGY2IXEpKZaej5rBObHYB1YDPyGn7hnaQ==", "QFgGs");
    llIIlIlIlIlIll[llIIlIlIlIllIl[5]] = lIIIIllllIIIIIlI("Liml8mG4BFipEvIRW5Dk/ZdrtIVX3QQtYkn9NRXqpERXyKBPqQgSToFH/YcvCSNwshT/HMuoS00C1jE0pF8yD4CEwsri2NPK", "lPOrX");
    llIIlIlIlIlIll[llIIlIlIlIllIl[22]] = lIIIIllllIIIIIll("XTTeVQQLLdM4LtljyeUcjSemzgDKhs/p7KnStFaa3mAQToEXbKH+IJqijK3UK9DIGW+nyuM83Hk=", "YTpRN");
    llIIlIlIlIlIll[llIIlIlIlIllIl[23]] = lIIIIllllIIIIIlI("jvNm3KkFuQz2OZdzJEiBKAd8M6OIOycOPl3lspzd0uVKMfhc7deKXDwH38slkDl8f6ZLqMDBl2LfYa8xuyzshgRG1HPsol5dr/VGEd70Pn2Bt+9Vxt0wGE5FtfAORJZSOOTd60QrTgw/tTWtBSPo6w==", "RsyFU");
    llIIlIlIlIlIll[llIIlIlIlIllIl[10]] = lIIIIllllIIIIIll("NHkvFjNEKtneGG5388iH66Mq9j75hqk17Um4KalFl2EVuTGoEOUZhMRud7cCOL1pFi2+gQNxCbGOjlyujscQE6ONhIrhy5dhVToUL78pXpaAikXKNYOs7w==", "UqcaT");
    llIIlIlIlIlIll[llIIlIlIlIllIl[26]] = lIIIIllllIIIIIll("3zlyDpXiZ4DJs85yJfObojhPs34H7KEko0amJ+VDdQAGyPf6mukSHV3D9FMmP1wPf4i67Be30XcXuQulNtJCUE51golmSfF+iM1GAbDptuOTMu7wx+xHxg==", "XdVUu");
    llIIlIlIlIlIll[llIIlIlIlIllIl[24]] = lIIIIllllIIIIlII("Fz8RWiQQNAAXOxg8EVosFy4MADBXKgkVMBwoSz0nDz8LACYLIzUYKAA/F04vDDQGK35JaVVFFhhgTT1gNTQAAGYUMwsRKgs7AwBmEC4AGWYwLgAZGg07Bh9yQ3pF", "yZetI");
    llIIlIlIlIlIll[llIIlIlIlIllIl[28]] = lIIIIllllIIIIlII("DCQ+VwULLy8aGgMnPlcLDigvFxxMLy8NHw0zIVcmBzUCGAYGLS8LOA4gMzoECyQkDVIENCQaN1N1fUtRVR4rQ0AuLy8NRw8oJBwLECAsDUcMJD4OBxAqZSkJASovDVNLF3BZSA==", "bAJyh");
    llIIlIlIlIlIll[llIIlIlIlIllIl[18]] = lIIIIllllIIIIIlI("cerNma2vRc+7pQa6ndT/N0YoSDzEdLZ+XMGLqPwCh3xW4n8swq8+HS6jHD48p7xpiiPGoGA+gcQ=", "jwpLO");
    llIIlIlIlIlIll[llIIlIlIlIllIl[30]] = lIIIIllllIIIIlII("DC4jLUoKLjsrSiUjND8XXCYmBQoVOzQiBwN1fQAOBzk0YwgHITJjKwQlMC8QXWYPdkRG", "fOULd");
    llIIlIlIlIlIll[llIIlIlIlIllIl[32]] = lIIIIllllIIIIIlI("H2fQOonAgRtJRgVgB86fFvP3WZyStjBE+TL++SOBicPpcbw1Qo7Oso5b2V+rLEKPu/rR2z75qrIjmHeRKqsSlA==", "jZglY");
    llIIlIlIlIlIll[llIIlIlIlIllIl[34]] = lIIIIllllIIIIIll("bid+jbdUHlT7Koy1n3Mnta82FtAiItmc5GoCbxJjqpdDRKElB8qN3VaUVcRwA/9LBsfrBd0no14=", "LqKsM");
    llIIlIlIlIlIll[llIIlIlIlIllIl[36]] = lIIIIllllIIIIIll("dhI4/OQink5ns3oiXJBWG61rd2zm6l+LHBItWiT0avZUH9iaTexG4aqnmCCZU31QQAKdZ7ht3b3RnhdJEBKGWg==", "kvJeP");
    llIIlIlIlIlIll[llIIlIlIlIllIl[38]] = lIIIIllllIIIIIlI("cmIh6l7YvBmr5EGur1PhUktb1RU+gJGYQcA2g5C2G9c=", "gUTAd");
    llIIlIlIlIlIll[llIIlIlIlIllIl[40]] = lIIIIllllIIIIlII("PiMsEWQ4IzQXZBkjLhhwIC0eFS0mJz8DcHwGczRwdA==", "TBZpJ");
    llIIlIlIlIlIll[llIIlIlIlIllIl[41]] = lIIIIllllIIIIIlI("bJz7VZVt2By2JXK4sG7NssptwHagRs1QvgBLztuYs8rltma7tZOmBOoW35bny/q/A0U3M/rLc2E=", "RzTdx");
    llIIlIlIlIlIll[llIIlIlIlIllIl[43]] = lIIIIllllIIIIIll("P4hFdv0C4ZJ/1Z5UGHB+R+EqzFeGy4pE9iYmS2m/3kAeaOLwZ2rGB4oEqCHfczg+EUpQusDfmbo=", "kNkBk");
    llIIlIlIlIlIll[llIIlIlIlIllIl[44]] = lIIIIllllIIIIlII("Cw4XTD4MBQYBIQQNF0wwCQIGDCdLDg0WOhESTSc9EQIXGwMJChoHITY7WQQ6AAcHPWRUWlRWDARRUFhzRUs=", "ekcbS");
    llIIlIlIlIlIll[llIIlIlIlIllIl[45]] = lIIIIllllIIIIIlI("DHK2EMe4HbiC3KNDMPISHlZ2Df0bVMj6yv/y1rlJ3EG5XZSEP43VD+pJfyg6BH3+s+2JMUy/F5v0EylOmv5DaEmekKjfIAT1kpFasZJqimKaoOdZ/N4yuLK/fueyrCtS4TH8npaf+c4=", "KlAzU");
    llIIlIlIlIlIll[llIIlIlIlIllIl[47]] = lIIIIllllIIIIlII("GxYXTzgcHQYCJxQVF082GRoGDyFbFg0VPAEKTSQ7ARoXGAUZEhoEJyYjWQcgGxA8VmVFR1Q+ME9bSidvVVM=", "uscaU");
    llIIlIlIlIlIll[llIIlIlIlIllIl[48]] = lIIIIllllIIIIlII("BR1KNg0dCA0xHQcfSicRGFYCdEtSCg0iERw7CCwaAzoIKhoDQkwJFw0MSygQBh0HNxgODEswDQEUSygYHBBLBxUHGw8VFhtDKCscHFcJLBcNGxYkHxxXETEQBFcJJA0AVzIgGlscXwkXDQxLKBAGHQc3GA4MSzANARRLABcdFSwkFwxDKCscHFcJLBcNGxYkHxxXETEQBFchKwwFPgUmEAYfXx9QPkJE", "hxdEy");
    llIIlIlIlIlIll[llIIlIlIlIllIl[11]] = lIIIIllllIIIIlII("GCJ4GBMANz8fAxogeAkPBWkwWlVPIDMfKxAgPx81GjM3Hw4aKSVRTzkpMx9IGC44DgQHJjAfSAAzPwdIGCYiA0gjIjVYA05uDS1dVQ==", "uGVkg");
    llIIlIlIlIlIll[llIIlIlIlIllIl[31]] = lIIIIllllIIIIlII("JzY1SAsgPSQFFCg1NUgFJTokCBJnNi8SDz0qbyMIPTo1HzYlMjgDFBoDewATJzAeV159ZXFfOShpaSoILCduCw8nNiIUBy8nbhMSID9uIwg8PgkHCC1oaDBcaXM=", "ISAff");
    llIIlIlIlIlIll[llIIlIlIlIllIl[50]] = lIIIIllllIIIIIlI("3USH4Y6MCMTp/ND3LIMjuIeR7q5reN1tJf+mDJ4T21C3G7+/uZ+NDeO0FPilHXPgI8TO2LBs8LUgQ+miACusQOOOuN2a4Vf+lpcjx0b3beb8YzFRR16r4KfjY+66j2tG", "BkwSP");
    llIIlIlIlIlIll[llIIlIlIlIllIl[46]] = lIIIIllllIIIIIlI("97Kx1ff2FQVWDm+p7Hy/EbrZXf6BjRt41JCsgG5THyQQlgV+qbCsD5SoEb/m2D0lKTedXE4Uy1M=", "ohevI");
    llIIlIlIlIlIll[llIIlIlIlIllIl[12]] = lIIIIllllIIIIIll("Z/EYRasTZPmDIY+NV781h8+u9H1BouBzmwGE9BakLq70B/BmlTC8d3mvFunPd9LdNUd0tPjYcZR2V6RQyhJHgNZuQj8nGaeohYUlRJosEYBo/ifg++h3Fw==", "fWVBA");
    llIIlIlIlIlIll[llIIlIlIlIllIl[20]] = lIIIIllllIIIIIll("1OqN3zPsngebNADB8AJNibItm2OyUW1SEzQIcGuavI4kToDhLRWOqCbUu1khgVGKb1E/Jr9MSr2Jjd9mz5NE4uNZgWBK6JPi", "aDFRb");
    llIIlIlIlIlIll[llIIlIlIlIllIl[42]] = lIIIIllllIIIIIlI("182YgTqoRcsW5Fn4YOIXNibboYukNcqLfN4L+sUyltuR+j8g6345TRpMmLZD8P0E0GJp0EiAmahYni2lZyd6liE694sVVY/2JcbmY6QApqOY+FfAfzCBlg==", "bjdHa");
    llIIlIlIlIlIll[llIIlIlIlIllIl[54]] = lIIIIllllIIIIlII("Dy82aCEIJCclPgAsNmgvDSMnKDhPLywyJRUzbAMiFSM2PxwNKzsjPjIaeCAlBCYmGXtRe3B0EyRwe3xsQWo=", "aJBFL");
    llIIlIlIlIlIll[llIIlIlIlIllIl[16]] = lIIIIllllIIIIIll("TdoD/ZJYELJRypX3rYWPJqVi5kFchARYzZR4tBwj9dOpXNp8HhJcHNY9PsWuhGmbcPDRH48vxRkbR6UODrVYel261ClVH2TfchU9dajDQSsbzHHTJNonLQ==", "QFOTC");
    llIIlIlIlIlIll[llIIlIlIlIllIl[13]] = lIIIIllllIIIIlII("DgMGAlgRFhkPWCgLAxdMBQYUWV4oCBEVF0sOEQ0RSy0SCRMHFktKLF5CUA==", "dbpcv");
    llIIlIlIlIlIll[llIIlIlIlIllIl[37]] = lIIIIllllIIIIIll("9ONl+tPaBaJN7KgR3Qf1mHzxhSMUUfXLBQpdeAdwV5DyLiFAn79j+btLTinBdffV1koCqzr3EqGrMfY0qDhT/Tvvjg3yjXHxkw5PSUwYVUtKL4YZy+hJtw==", "bBluD");
    llIIlIlIlIlIll[llIIlIlIlIllIl[39]] = lIIIIllllIIIIIlI("E70QP0LTAMAmNf462P8N+pQZAInArf4TSSK0cjr6Qd50MDYW+0Be1CGDEB7AmNO10ADXojZUKnjteho2x64mhg==", "pCdSO");
    llIIlIlIlIlIll[llIIlIlIlIllIl[35]] = lIIIIllllIIIIIll("Q0rAI4mWCg4xDr3h7MPDn+bEXBqZ7b1OzHbD3KBDg8DIyi6NzBOwFeJgYa6wvQGob2ALAhvEtKQ=", "fpOoN");
    llIIlIlIlIlIll[llIIlIlIlIllIl[51]] = lIIIIllllIIIIIlI("XbJVSb+xYSGDJ6fJ5eAsr/iijYDUWEa7Y5PtFbFnsjTuDbIfiEwYpXF49N0BYgy/EMqQuJ9iSimhnxQbg/UCeA==", "midxk");
    llIIlIlIlIlIll[llIIlIlIlIllIl[56]] = lIIIIllllIIIIIll("B1EkWb0eVxmARTRyv3VbVgjx6HH7iy0QrHiMt0gmKF3Ekf5AF7jt74+xmDsRbTbettzCaQskVBuL/SJqHmCYiLv28AR2zUWcengyRL8a78YqoTlapS4o6recwdqE1v4YfJEBTdl/7O7oXFWeB0NPKG8SPO05N5ypO1lbwYmQJPFC4iqgBA4pKax4jLdIJihd5wzZU+pv2JN+XaccIA2hwYHapAuQYDKj2lieZGAZZWC3PuVwQct0sNW8zLKFukdTbxI87Tk3nKlLlo1N42SWlXYHNLuXDgGwFe7bH9vcsdA6J9DsbqDfDXiMUgetO2hMJYrHTttGa5YykwgOh0cHd4HapAuQYDKj2lieZGAZZWCflZ3B1/77r/5vNkowpm/EengyRL8a78Z74JHMDq/PlYsSRoeBfFRhCLmX+Q0pxIF8VNcL5uPWdA==", "AMuZn");
    llIIlIlIlIlIll[llIIlIlIlIllIl[49]] = lIIIIllllIIIIlII("HCERSCEbKgAFPhMiEUgvHi0ACDhcKRAKOBs0CQc1FzZLNiATPQAUDx0qERQjHigAFAEifgMTIhEbUl57RHE6A3ZabTNcbFI=", "rDefL");
    llIIlIlIlIlIll[llIIlIlIlIllIl[58]] = lIIIIllllIIIIIlI("Z7voxkUjOUkgIgNLSr+A3VTikecfMH14xAW++riF9WEKauue7pCFst9n8X+C1TTZ3T4kgMU+hnCgmN42/w3x5L8lbc48ZaWm9DFTEhKytaI=", "RpRsD");
    llIIlIlIlIlIll[llIIlIlIlIllIl[53]] = lIIIIllllIIIIIll("iUL2F115tTsYKBW4sAJk9oyx+tx4xvdkMgWOvWMnmT71iRb9V8cX9L9QaJBW/tchH6ybMBAdrLnrVRH/bUF5lw==", "ZBIvB");
    llIIlIlIlIlIll[llIIlIlIlIllIl[33]] = lIIIIllllIIIIIll("CVkPqQbXRmoPZzx9vusMB9BoNBHY84U9Vl/0EWcAYK/tXJyoihLerepJt49ad41tHtUgaqX0JPSx1ed/VqGXAVppi01Tuy10jhf/RAlhuaA=", "Nitwi");
    llIIlIlIlIlIll[llIIlIlIlIllIl[60]] = lIIIIllllIIIIlII("LSQBQiwqLxAPMyInAUI0NygZQiwiNR1CAy8uFgcRLDJPCjQtIipddnR4QFoeLHtdRQh5YVU=", "CAulA");
    llIIlIlIlIlIll[llIIlIlIlIllIl[61]] = lIIIIllllIIIIIlI("tU7wDaoRmToaf20+44owHbCjk3e503zpfLAnQX54xGggl8d+XQDY8yorLYG/zm8j6MErR9SBdu8=", "DBPDo");
    llIIlIlIlIlIll[llIIlIlIlIllIl[62]] = lIIIIllllIIIIIll("5YLIAtDGXD2FFVm82URPLRn/VLUbESTIIzmj72xwM4c=", "gYGeu");
    llIIlIlIlIlIll[llIIlIlIlIllIl[55]] = lIIIIllllIIIIlII("JD8wYz0jNCEuIis8MGMlPjMoYz0rLixjBi85dylqLC8qLg97YnJ7Z3IFJXd4DnMIIzU+dSkkPi85Niw2PnUxOTkmdSksJCJ1EigzeT5/d3Bq", "JZDMP");
    llIIlIlIlIlIll[llIIlIlIlIllIl[52]] = lIIIIllllIIIIlII("ACBKICMYNQ0nMwIiSjE/HWsCYmVXIwUwMjsgByc4H39MHzkIMUs+PgMgByE2CzFLJiMEKUs+NhktSwUyDnYAaA1EE15z", "mEdSW");
    llIIlIlIlIlIll[llIIlIlIlIllIl[27]] = lIIIIllllIIIIlII("ADcuF30fIjEafSY/KwJpAyI9BDIeOSpMe0MaMhclC3ktAjoGeRECNhg3LBkhUWx4Vg==", "jVXvS");
    llIIlIlIlIlIll[llIIlIlIlIllIl[21]] = lIIIIllllIIIIIll("M9D2oCTPYiLVvIN6sr6Qb9D+v54cogWVa33GiyKLDTQThqc0oCsoyQ==", "kIwfH");
    llIIlIlIlIlIll[llIIlIlIlIllIl[14]] = lIIIIllllIIIIIll("GWFwjkGbH/y5VR0SYawqVNkfx1zT+ybiERIrmE40hp6Gy3AEOmBPdulliRlHhC+JADRrD0tlBEyBDaAyGcmqPOFn48KdNYpgwPEj29nlWFsANGsPS2UETIENoDIZyao84Wfjwp01imDOoW0x2o/umA==", "lyxSi");
    llIIlIlIlIlIll[llIIlIlIlIllIl[29]] = lIIIIllllIIIIIll("Qqlr8gmt3a7uH9rmMyWK/SCQ9D8mo6qOgms0CbUlGGfe29kzRcSQg3jdJJ2TqGpkVDHlj75eCzA=", "VsdBh");
    llIIlIlIlIlIll[llIIlIlIlIllIl[59]] = lIIIIllllIIIIIll("IAFR5H3j+WQKioB2N7Wo6gsqRZkIp4my93oTIlGN4KvlO9wAOeViCVhbOxQ9n7ep", "hwsAC");
    llIIlIlIlIlIll[llIIlIlIlIllIl[57]] = lIIIIllllIIIIIll("lp0+6ev5tYUMpesVwfSNOo2WbvzZYULHcq+i/6k1EX4JXebbqO+AqPmyR1wFHAzafH+UmXsYvNvD6/s/Y+uu7CWPXEU+K8fRfHJS+5g8nyBdKykM1kf8SZSb7O6YRknQon9G6nZQRFrmEEpRJRR8shfCNYU4MnoD/Dnj9Vj1Vbozfmn14GmWBV44IUSKhwI3", "JQNdg");
    llIIlIlIlIlIll[llIIlIlIlIllIl[25]] = lIIIIllllIIIIlII("LCYhVBwrLTAZAyMlIVQENio5VDQsNjg8ECEqOx1LJDY7GS5zdGNNQnYcMUBZaw87HwVtLjwUFCExNBwFbTYhEx1tBjsPHAQiNhMfJXhvWlE=", "BCUzq");
    llIIlIlIlIlIll[llIIlIlIlIllIl[9]] = lIIIIllllIIIIIlI("5e5+DFg9+BZfQJwBtoMC7rhiEvpFaXoLppZox2TrcKJMFK/IcMwNgjXeutFTYCN2TvYYKzbvIGWSERqThSZHDA==", "DkUtt");
    llIIlIlIlIllII = null;
  }
  
  private static void lIIIIllllIIIIllI() {
    String str = (new Exception()).getStackTrace()[llIIlIlIlIllIl[0]].getFileName();
    llIIlIlIlIllII = str.substring(str.indexOf("ä") + llIIlIlIlIllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllllIIIIlII(String lllllllllllllllIllIIlIlIIIlIlIlI, String lllllllllllllllIllIIlIlIIIlIlIIl) {
    lllllllllllllllIllIIlIlIIIlIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIIIlIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIlIIIlIlIII = new StringBuilder();
    char[] lllllllllllllllIllIIlIlIIIlIIlll = lllllllllllllllIllIIlIlIIIlIlIIl.toCharArray();
    int lllllllllllllllIllIIlIlIIIlIIllI = llIIlIlIlIllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlIlIIIlIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIlIlIllIl[0];
    while (lIIIIllllIIIlIll(j, i)) {
      char lllllllllllllllIllIIlIlIIIlIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlIlIIIlIIllI++;
      j++;
      "".length();
      if (" ".length() == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlIlIIIlIlIII);
  }
  
  private static String lIIIIllllIIIIIlI(String lllllllllllllllIllIIlIlIIIlIIIlI, String lllllllllllllllIllIIlIlIIIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIlIIIlIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIlIIIlIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIlIIIlIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIlIIIlIIlII.init(llIIlIlIlIllIl[3], lllllllllllllllIllIIlIlIIIlIIlIl);
      return new String(lllllllllllllllIllIIlIlIIIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIlIIIlIIIll) {
      lllllllllllllllIllIIlIlIIIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllllIIIIIll(String lllllllllllllllIllIIlIlIIIIlllIl, String lllllllllllllllIllIIlIlIIIIlllII) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIlIIIlIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIlIIIIlllII.getBytes(StandardCharsets.UTF_8)), llIIlIlIlIllIl[19]), "DES");
      Cipher lllllllllllllllIllIIlIlIIIIlllll = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIlIIIIlllll.init(llIIlIlIlIllIl[3], lllllllllllllllIllIIlIlIIIlIIIII);
      return new String(lllllllllllllllIllIIlIlIIIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIIIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIlIIIIllllI) {
      lllllllllllllllIllIIlIlIIIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllllIIIIlll() {
    llIIlIlIlIllIl = new int[64];
    llIIlIlIlIllIl[0] = (0x3E ^ 0xF) & (0x50 ^ 0x61 ^ 0xFFFFFFFF);
    llIIlIlIlIllIl[1] = " ".length();
    llIIlIlIlIllIl[2] = " ".length() << " ".length() << " ".length();
    llIIlIlIlIllIl[3] = " ".length() << " ".length();
    llIIlIlIlIllIl[4] = ((0x52 ^ 0x5B) << " ".length() << " ".length() ^ 0xB6 ^ 0xBF) << "   ".length();
    llIIlIlIlIllIl[5] = 0xCD ^ 0xA8 ^ (0xD8 ^ 0xC3) << " ".length() << " ".length();
    llIIlIlIlIllIl[6] = -" ".length();
    llIIlIlIlIllIl[7] = "   ".length();
    llIIlIlIlIllIl[8] = (0x5F ^ 0x8) << " ".length() ^ 35 + 98 - 52 + 90;
    llIIlIlIlIllIl[9] = (" ".length() << " ".length() ^ 0x45 ^ 0x48) << " ".length() << " ".length();
    llIIlIlIlIllIl[10] = "   ".length() << " ".length() << " ".length();
    llIIlIlIlIllIl[11] = 0x79 ^ 0x64;
    llIIlIlIlIllIl[12] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0x59 ^ 0x68;
    llIIlIlIlIllIl[13] = (0x7D ^ 0x6E) << " ".length();
    llIIlIlIlIllIl[14] = 67 + 91 - 88 + 89 ^ (0xA ^ 0x1F) << "   ".length();
    llIIlIlIlIllIl[15] = "   ".length() << " ".length();
    llIIlIlIlIllIl[16] = 0x72 ^ 0x57;
    llIIlIlIlIllIl[17] = 0x5D ^ 0x5A;
    llIIlIlIlIllIl[18] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIlIllIl[19] = " ".length() << "   ".length();
    llIIlIlIlIllIl[20] = (73 + 122 - 93 + 61 ^ (0x19 ^ 0x40) << " ".length()) << " ".length();
    llIIlIlIlIllIl[21] = (0x63 ^ 0x78) << " ".length();
    llIIlIlIlIllIl[22] = ("   ".length() << " ".length() << " ".length() << " ".length() ^ 0x28 ^ 0x1D) << " ".length();
    llIIlIlIlIllIl[23] = 0x55 ^ 0x5E;
    llIIlIlIlIllIl[24] = ((0x5E ^ 0x47) << " ".length() << " ".length() ^ 0x1F ^ 0x7C) << " ".length();
    llIIlIlIlIllIl[25] = 136 + 45 - 177 + 153 ^ (0x78 ^ 0x2B) << " ".length();
    llIIlIlIlIllIl[26] = (0x54 ^ 0x51) << " ".length() << " ".length() ^ 0xB3 ^ 0xAA;
    llIIlIlIlIllIl[27] = 0x4B ^ 0x7E;
    llIIlIlIlIllIl[28] = 0x27 ^ 0x28;
    llIIlIlIlIllIl[29] = (0x63 ^ 0x64) << "   ".length();
    llIIlIlIlIllIl[30] = 0x83 ^ 0x9C ^ (0x47 ^ 0x40) << " ".length();
    llIIlIlIlIllIl[31] = (0x8C ^ 0x83) << " ".length();
    llIIlIlIlIllIl[32] = ((0x8F ^ 0xBA) << " ".length() ^ 0x3A ^ 0x59) << " ".length();
    llIIlIlIlIllIl[33] = 0xA0 ^ 0x8F;
    llIIlIlIlIllIl[34] = 0x51 ^ 0x64 ^ (0x6 ^ 0x15) << " ".length();
    llIIlIlIlIllIl[35] = 0x38 ^ 0x11;
    llIIlIlIlIllIl[36] = (0x64 ^ 0x5F ^ (0x89 ^ 0x96) << " ".length()) << " ".length() << " ".length();
    llIIlIlIlIllIl[37] = 0xE3 ^ 0xC4;
    llIIlIlIlIllIl[38] = 185 + 126 - 237 + 115 ^ (0x6F ^ 0x7A) << "   ".length();
    llIIlIlIlIllIl[39] = (0x96 ^ 0x93) << "   ".length();
    llIIlIlIlIllIl[40] = (0x7C ^ 0x35 ^ (0x4B ^ 0x6A) << " ".length()) << " ".length();
    llIIlIlIlIllIl[41] = (0x7D ^ 0x5A) << " ".length() << " ".length() ^ 94 + 113 - 201 + 133;
    llIIlIlIlIllIl[42] = 0xA ^ 0x29;
    llIIlIlIlIllIl[43] = "   ".length() << "   ".length();
    llIIlIlIlIllIl[44] = 0x2D ^ 0x34;
    llIIlIlIlIllIl[45] = (0x48 ^ 0x45) << " ".length();
    llIIlIlIlIllIl[46] = " ".length() << (" ".length() << " ".length() << " ".length() << " ".length() ^ 0x2B ^ 0x3E);
    llIIlIlIlIllIl[47] = 0x11 ^ 0xA;
    llIIlIlIlIllIl[48] = (" ".length() ^ "   ".length() << " ".length()) << " ".length() << " ".length();
    llIIlIlIlIllIl[49] = (0x21 ^ 0x2A) << " ".length() << " ".length();
    llIIlIlIlIllIl[50] = 0x91 ^ 0xBE ^ "   ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIlIllIl[51] = (0x24 ^ 0x31) << " ".length();
    llIIlIlIlIllIl[52] = (0x80 ^ 0x8D) << " ".length() << " ".length();
    llIIlIlIlIllIl[53] = (165 + 35 - 44 + 23 ^ (0x42 ^ 0x6B) << " ".length() << " ".length()) << " ".length();
    llIIlIlIlIllIl[54] = (0x7D ^ 0x5A ^ (0x3C ^ 0x2B) << " ".length()) << " ".length() << " ".length();
    llIIlIlIlIllIl[55] = 0xB4 ^ 0x87;
    llIIlIlIlIllIl[56] = 0x77 ^ 0x5C;
    llIIlIlIlIllIl[57] = (0x2D ^ 0x30) << " ".length();
    llIIlIlIlIllIl[58] = 0xA0 ^ 0x8D;
    llIIlIlIlIllIl[59] = 0xAE ^ 0x97;
    llIIlIlIlIllIl[60] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIlIllIl[61] = 0x23 ^ 0x12;
    llIIlIlIlIllIl[62] = (42 + 163 - 170 + 146 ^ (0xAD ^ 0x86) << " ".length() << " ".length()) << " ".length();
    llIIlIlIlIllIl[63] = 0xAA ^ 0x97;
  }
  
  private static boolean lIIIIllllIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllllIIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllllIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllllIIIllII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIllllIIIlIII(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIllllIIIlIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIllllIIIlIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f12.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */