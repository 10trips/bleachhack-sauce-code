package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f1000000000000000000000 {
  private final List<f100000000000000000000> settings = new ArrayList<>();
  
  private static String[] lIlllIlIlIlIIl;
  
  private static Class[] lIlllIlIlIlIlI;
  
  private static final String[] lIlllIlIlIlIll;
  
  private static String[] lIlllIlIlIllII;
  
  private static final int[] lIlllIlIlIllIl;
  
  public List<f100000000000000000000> getSettings() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIlIlIlIIIllIl	Lme/stupitdog/bhp/f1000000000000000000000;
  }
  
  public void addSetting(f100000000000000000000 lllllllllllllllIlllIlIlIlIIIlIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: aload_1
    //   7: <illegal opcode> 1 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   12: ldc ''
    //   14: invokevirtual length : ()I
    //   17: pop2
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIlllIlIlIlIIIllII	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	19	1	lllllllllllllllIlllIlIlIlIIIlIll	Lme/stupitdog/bhp/f100000000000000000000;
  }
  
  public f100000000000000000000 getSettingByNameAndMod(String lllllllllllllllIlllIlIlIlIIIlIIl, au lllllllllllllllIlllIlIlIlIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: <illegal opcode> 2 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   11: aload_2
    //   12: <illegal opcode> test : (Lme/stupitdog/bhp/au;)Ljava/util/function/Predicate;
    //   17: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   22: aload_1
    //   23: <illegal opcode> test : (Ljava/lang/String;)Ljava/util/function/Predicate;
    //   28: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   33: <illegal opcode> 4 : (Ljava/util/stream/Stream;)Ljava/util/Optional;
    //   38: aconst_null
    //   39: <illegal opcode> 5 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: checkcast me/stupitdog/bhp/f100000000000000000000
    //   47: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	48	0	lllllllllllllllIlllIlIlIlIIIlIlI	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	48	1	lllllllllllllllIlllIlIlIlIIIlIIl	Ljava/lang/String;
    //   0	48	2	lllllllllllllllIlllIlIlIlIIIlIII	Lme/stupitdog/bhp/au;
  }
  
  public f100000000000000000000 getSettingByNameAndModConfig(String lllllllllllllllIlllIlIlIlIIIIllI, au lllllllllllllllIlllIlIlIlIIIIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: <illegal opcode> 2 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   11: aload_2
    //   12: <illegal opcode> test : (Lme/stupitdog/bhp/au;)Ljava/util/function/Predicate;
    //   17: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   22: aload_1
    //   23: <illegal opcode> test : (Ljava/lang/String;)Ljava/util/function/Predicate;
    //   28: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   33: <illegal opcode> 4 : (Ljava/util/stream/Stream;)Ljava/util/Optional;
    //   38: aconst_null
    //   39: <illegal opcode> 5 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: checkcast me/stupitdog/bhp/f100000000000000000000
    //   47: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	48	0	lllllllllllllllIlllIlIlIlIIIIlll	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	48	1	lllllllllllllllIlllIlIlIlIIIIllI	Ljava/lang/String;
    //   0	48	2	lllllllllllllllIlllIlIlIlIIIIlIl	Lme/stupitdog/bhp/au;
  }
  
  public List<f100000000000000000000> getSettingsForMod(au lllllllllllllllIlllIlIlIlIIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: <illegal opcode> 2 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   11: aload_1
    //   12: <illegal opcode> test : (Lme/stupitdog/bhp/au;)Ljava/util/function/Predicate;
    //   17: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   22: <illegal opcode> 6 : ()Ljava/util/stream/Collector;
    //   27: <illegal opcode> 7 : (Ljava/util/stream/Stream;Ljava/util/stream/Collector;)Ljava/lang/Object;
    //   32: checkcast java/util/List
    //   35: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	36	0	lllllllllllllllIlllIlIlIlIIIIlII	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	36	1	lllllllllllllllIlllIlIlIlIIIIIll	Lme/stupitdog/bhp/au;
  }
  
  public List<f100000000000000000000> getSettingsByCategory(f13 lllllllllllllllIlllIlIlIlIIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: <illegal opcode> 2 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   11: aload_1
    //   12: <illegal opcode> test : (Lme/stupitdog/bhp/f13;)Ljava/util/function/Predicate;
    //   17: <illegal opcode> 3 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   22: <illegal opcode> 6 : ()Ljava/util/stream/Collector;
    //   27: <illegal opcode> 7 : (Ljava/util/stream/Stream;Ljava/util/stream/Collector;)Ljava/lang/Object;
    //   32: checkcast java/util/List
    //   35: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	36	0	lllllllllllllllIlllIlIlIlIIIIIlI	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	36	1	lllllllllllllllIlllIlIlIlIIIIIIl	Lme/stupitdog/bhp/f13;
  }
  
  public f100000000000000000000 getSettingByName(String lllllllllllllllIlllIlIlIIllllllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 8 : (Lme/stupitdog/bhp/f1000000000000000000000;)Ljava/util/List;
    //   6: <illegal opcode> 9 : (Ljava/util/List;)Ljava/util/Iterator;
    //   11: astore_2
    //   12: aload_2
    //   13: <illegal opcode> 10 : (Ljava/util/Iterator;)Z
    //   18: invokestatic lllllIlIIlllllI : (I)Z
    //   21: ifeq -> 98
    //   24: aload_2
    //   25: <illegal opcode> 11 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   30: checkcast me/stupitdog/bhp/f100000000000000000000
    //   33: astore_3
    //   34: aload_3
    //   35: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000;)Ljava/lang/String;
    //   40: aload_1
    //   41: <illegal opcode> 13 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   46: invokestatic lllllIlIIlllllI : (I)Z
    //   49: ifeq -> 54
    //   52: aload_3
    //   53: areturn
    //   54: ldc ''
    //   56: invokevirtual length : ()I
    //   59: pop
    //   60: bipush #124
    //   62: bipush #99
    //   64: ixor
    //   65: ldc ' '
    //   67: invokevirtual length : ()I
    //   70: ishl
    //   71: sipush #164
    //   74: sipush #187
    //   77: ixor
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ishl
    //   84: iconst_m1
    //   85: ixor
    //   86: iand
    //   87: ldc ' '
    //   89: invokevirtual length : ()I
    //   92: ineg
    //   93: if_icmpgt -> 12
    //   96: aconst_null
    //   97: areturn
    //   98: aconst_null
    //   99: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   34	20	3	lllllllllllllllIlllIlIlIlIIIIIII	Lme/stupitdog/bhp/f100000000000000000000;
    //   0	100	0	lllllllllllllllIlllIlIlIIlllllll	Lme/stupitdog/bhp/f1000000000000000000000;
    //   0	100	1	lllllllllllllllIlllIlIlIIllllllI	Ljava/lang/String;
  }
  
  static {
    lllllIlIIllllIl();
    lllllIlIIllllII();
    lllllIlIIlllIll();
    lllllIlIIllIlll();
  }
  
  private static CallSite lllllIlIIllIllI(MethodHandles.Lookup lllllllllllllllIlllIlIlIIllIlIIl, String lllllllllllllllIlllIlIlIIllIlIII, MethodType lllllllllllllllIlllIlIlIIllIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIlIIllIllll = lIlllIlIlIlIIl[Integer.parseInt(lllllllllllllllIlllIlIlIIllIlIII)].split(lIlllIlIlIlIll[lIlllIlIlIllIl[0]]);
      Class<?> lllllllllllllllIlllIlIlIIllIlllI = Class.forName(lllllllllllllllIlllIlIlIIllIllll[lIlllIlIlIllIl[0]]);
      String lllllllllllllllIlllIlIlIIllIllIl = lllllllllllllllIlllIlIlIIllIllll[lIlllIlIlIllIl[1]];
      MethodHandle lllllllllllllllIlllIlIlIIllIllII = null;
      int lllllllllllllllIlllIlIlIIllIlIll = lllllllllllllllIlllIlIlIIllIllll[lIlllIlIlIllIl[2]].length();
      if (lllllIlIIllllll(lllllllllllllllIlllIlIlIIllIlIll, lIlllIlIlIllIl[3])) {
        MethodType lllllllllllllllIlllIlIlIIlllIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIlIIllIllll[lIlllIlIlIllIl[3]], f1000000000000000000000.class.getClassLoader());
        if (lllllIlIlIIIIII(lllllllllllllllIlllIlIlIIllIlIll, lIlllIlIlIllIl[3])) {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findVirtual(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIIl);
          "".length();
          if (-" ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findStatic(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIIl);
        } 
        "".length();
        if (-(0x2C ^ 0x28) >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIlIIlllIIII = lIlllIlIlIlIlI[Integer.parseInt(lllllllllllllllIlllIlIlIIllIllll[lIlllIlIlIllIl[3]])];
        if (lllllIlIlIIIIII(lllllllllllllllIlllIlIlIIllIlIll, lIlllIlIlIllIl[2])) {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findGetter(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIII);
          "".length();
          if (((153 + 38 - 43 + 47 ^ (0xB3 ^ 0xBA) << " ".length() << " ".length() << " ".length()) & (3 + 129 - -42 + 41 ^ (0x12 ^ 0x33) << " ".length() << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (lllllIlIlIIIIII(lllllllllllllllIlllIlIlIIllIlIll, lIlllIlIlIllIl[4])) {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findStaticGetter(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIII);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else if (lllllIlIlIIIIII(lllllllllllllllIlllIlIlIIllIlIll, lIlllIlIlIllIl[5])) {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findSetter(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIlIlIIllIllII = lllllllllllllllIlllIlIlIIllIlIIl.findStaticSetter(lllllllllllllllIlllIlIlIIllIlllI, lllllllllllllllIlllIlIlIIllIllIl, lllllllllllllllIlllIlIlIIlllIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIlIIllIllII);
    } catch (Exception lllllllllllllllIlllIlIlIIllIlIlI) {
      lllllllllllllllIlllIlIlIIllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlIIllIlll() {
    lIlllIlIlIlIIl = new String[lIlllIlIlIllIl[6]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[7]] = lIlllIlIlIlIll[lIlllIlIlIllIl[1]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[8]] = lIlllIlIlIlIll[lIlllIlIlIllIl[3]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[9]] = lIlllIlIlIlIll[lIlllIlIlIllIl[2]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[10]] = lIlllIlIlIlIll[lIlllIlIlIllIl[4]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[11]] = lIlllIlIlIlIll[lIlllIlIlIllIl[5]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[3]] = lIlllIlIlIlIll[lIlllIlIlIllIl[12]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[12]] = lIlllIlIlIlIll[lIlllIlIlIllIl[8]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[13]] = lIlllIlIlIlIll[lIlllIlIlIllIl[14]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[15]] = lIlllIlIlIlIll[lIlllIlIlIllIl[11]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[4]] = lIlllIlIlIlIll[lIlllIlIlIllIl[13]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[16]] = lIlllIlIlIlIll[lIlllIlIlIllIl[17]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[17]] = lIlllIlIlIlIll[lIlllIlIlIllIl[9]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[5]] = lIlllIlIlIlIll[lIlllIlIlIllIl[10]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[14]] = lIlllIlIlIlIll[lIlllIlIlIllIl[7]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[2]] = lIlllIlIlIlIll[lIlllIlIlIllIl[16]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[18]] = lIlllIlIlIlIll[lIlllIlIlIllIl[18]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[1]] = lIlllIlIlIlIll[lIlllIlIlIllIl[15]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[0]] = lIlllIlIlIlIll[lIlllIlIlIllIl[19]];
    lIlllIlIlIlIIl[lIlllIlIlIllIl[19]] = lIlllIlIlIlIll[lIlllIlIlIllIl[6]];
    lIlllIlIlIlIlI = new Class[lIlllIlIlIllIl[1]];
    lIlllIlIlIlIlI[lIlllIlIlIllIl[0]] = List.class;
  }
  
  private static void lllllIlIIlllIll() {
    lIlllIlIlIlIll = new String[lIlllIlIlIllIl[20]];
    lIlllIlIlIlIll[lIlllIlIlIllIl[0]] = lllllIlIIlllIII(lIlllIlIlIllII[lIlllIlIlIllIl[0]], lIlllIlIlIllII[lIlllIlIlIllIl[1]]);
    lIlllIlIlIlIll[lIlllIlIlIllIl[1]] = lllllIlIIlllIIl(lIlllIlIlIllII[lIlllIlIlIllIl[3]], lIlllIlIlIllII[lIlllIlIlIllIl[2]]);
    lIlllIlIlIlIll[lIlllIlIlIllIl[3]] = lllllIlIIlllIIl(lIlllIlIlIllII[lIlllIlIlIllIl[4]], lIlllIlIlIllII[lIlllIlIlIllIl[5]]);
    lIlllIlIlIlIll[lIlllIlIlIllIl[2]] = lllllIlIIlllIIl(lIlllIlIlIllII[lIlllIlIlIllIl[12]], lIlllIlIlIllII[lIlllIlIlIllIl[8]]);
    lIlllIlIlIlIll[lIlllIlIlIllIl[4]] = lllllIlIIlllIlI(lIlllIlIlIllII[lIlllIlIlIllIl[14]], lIlllIlIlIllII[lIlllIlIlIllIl[11]]);
    lIlllIlIlIlIll[lIlllIlIlIllIl[5]] = lllllIlIIlllIlI("iPeqCuqOMM02d5RSRJrdPrVu9MSVnQfhLDZbuU+BRlaCilIWghBvrEGrSFPwAdg0UCWSjmAMALw=", "sWQMT");
    lIlllIlIlIlIll[lIlllIlIlIllIl[12]] = lllllIlIIlllIlI("8xtrymVMi/Oml8pQYG5orniaTePnp6vAUjA8PDxvB35lDkh4CmmDvBeGtgO+Eb3PU7ea9bFJeB0=", "Qyxlg");
    lIlllIlIlIlIll[lIlllIlIlIllIl[8]] = lllllIlIIlllIIl("CnMzX6dXriBRE9kKBqVD0Vo71bbyRWyICGOYIqpWw8m0iF0/XrHTHozy9iPZGecHsTX7APBBmXjHfjFgDanJ2h8NX9K8ig11", "Avsbc");
    lIlllIlIlIlIll[lIlllIlIlIllIl[14]] = lllllIlIIlllIII("ICInE1g/NzgeWAM3NAAXPiwjSB4rMB8XDj55eVsscGNx", "JCQrv");
    lIlllIlIlIlIll[lIlllIlIlIllIl[11]] = lllllIlIIlllIIl("oV0YGY8hO3HthyEtSEv2Xzf7ABf9/wltXG3r+jTSK0O+MfxLbau0CnmI4m6ATBhiwMUIRVmvZpY=", "oVoKb");
    lIlllIlIlIlIll[lIlllIlIlIllIl[13]] = lllllIlIIlllIII("HDQDNngDIRw7eAUhBzI3G3smIyQTNBhtMB87ERE/BCYBbX5fGR82IBd6ACM/Gno6JyIfOhs2Ok1vVXc=", "vUuWV");
    lIlllIlIlIlIll[lIlllIlIlIllIl[17]] = lllllIlIIlllIII("IQ9FMCw5GgI3PCMNRSEwPEQNcmt2Dxo2OSAZUWsUJgsdIncgCwUkdwMIASY7OFFCGWJsSg==", "LjkCX");
    lIlllIlIlIlIll[lIlllIlIlIllIl[9]] = lllllIlIIlllIII("KBcSJlw3Ag0rXAsCATUTNhkWfRwnDhB9Wms6DiYEI1kIJhwlWSslGCcVEHxIYlY=", "BvdGr");
    lIlllIlIlIlIll[lIlllIlIlIllIl[10]] = lllllIlIIlllIII("MjEPAmQtJBAPZBcgDQolNjEVWSUqFRUQL2J4NQkrLjFWDys2N1YsKDI1GhdxcRwTAjw5fxUCJD9/NgEgPTMNWHB4cA==", "XPycJ");
    lIlllIlIlIlIll[lIlllIlIlIllIl[7]] = lllllIlIIlllIlI("+BFI4MmTAJMGHExk6NtZFLqzfMmdfwapk8FbPfO83hSTwVs987zeFE38v8Hi27e2v1kwSZW0+3vdgxazS30MLq3LAa1UQdeORhfjtPVYueo=", "MAhYC");
    lIlllIlIlIlIll[lIlllIlIlIllIl[16]] = lllllIlIIlllIII("LCokOXwzPzs0fDU/ID0zK2UBLCAjKj9iNC8nJj0gfGMeMjMwKn0tJi8nfT4nKCgmMT0oZAIqNyIiMTkmI3B7FDgnPTN3JzIiPnchMjk3OT9pGCYqNycmaWJyZg==", "FKRXR");
    lIlllIlIlIlIll[lIlllIlIlIllIl[18]] = lllllIlIIlllIII("BwtKNCQfHg0zNAUJSiU4GkACdmBaXlR3YFpeVHdgWl5Ud2BaXlR3ag0LEBcxGAsKM2pCRygqNUUdEDIgAxoAKDdFDAw3fwsbX31wSg==", "jndGP");
    lIlllIlIlIlIll[lIlllIlIlIllIl[15]] = lllllIlIIlllIlI("kW8e7x8WqYu1SwnQ66lr2TN7vpGzG5cLxwikwfpAhcxhjF+4WS9KeclkKmmO5ctS", "txVdF");
    lIlllIlIlIlIll[lIlllIlIlIllIl[19]] = lllllIlIIlllIIl("+b8CFYf4vlgxM0IWHO+DjydUgzmFTbDzr7GW55Jze2qvsZbnknN7alhh7AI2sJRgDvrmJofOIjg=", "GJMjY");
    lIlllIlIlIlIll[lIlllIlIlIllIl[6]] = lllllIlIIlllIIl("agOrPLm8StMHSnjTJ9ARdxENdkO4MyV7TRGcx13NbaUftGxBRtnX50pu5D2AOB9Pe2GA39AMtqxgV9TZpqRLY3j9yLqsaU8Up5R1nowYGC0=", "xhWRx");
    lIlllIlIlIllII = null;
  }
  
  private static void lllllIlIIllllII() {
    String str = (new Exception()).getStackTrace()[lIlllIlIlIllIl[0]].getFileName();
    lIlllIlIlIllII = str.substring(str.indexOf("ä") + lIlllIlIlIllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIlIIlllIII(String lllllllllllllllIlllIlIlIIllIIlIl, String lllllllllllllllIlllIlIlIIllIIlII) {
    lllllllllllllllIlllIlIlIIllIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIlIIllIIIll = new StringBuilder();
    char[] lllllllllllllllIlllIlIlIIllIIIlI = lllllllllllllllIlllIlIlIIllIIlII.toCharArray();
    int lllllllllllllllIlllIlIlIIllIIIIl = lIlllIlIlIllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIlIIllIIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIlIllIl[0];
    while (lllllIlIlIIIIIl(j, i)) {
      char lllllllllllllllIlllIlIlIIllIIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIlIIllIIIIl++;
      j++;
      "".length();
      if ((0x3F ^ 0x3A) <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIlIIllIIIll);
  }
  
  private static String lllllIlIIlllIlI(String lllllllllllllllIlllIlIlIIlIlllIl, String lllllllllllllllIlllIlIlIIlIlllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlIIllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIIlIlllII.getBytes(StandardCharsets.UTF_8)), lIlllIlIlIllIl[14]), "DES");
      Cipher lllllllllllllllIlllIlIlIIlIlllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIlIIlIlllll.init(lIlllIlIlIllIl[3], lllllllllllllllIlllIlIlIIllIIIII);
      return new String(lllllllllllllllIlllIlIlIIlIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIlIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlIIlIllllI) {
      lllllllllllllllIlllIlIlIIlIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlIIlllIIl(String lllllllllllllllIlllIlIlIIlIllIII, String lllllllllllllllIlllIlIlIIlIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlIIlIllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIIlIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIlIIlIllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIlIIlIllIlI.init(lIlllIlIlIllIl[3], lllllllllllllllIlllIlIlIIlIllIll);
      return new String(lllllllllllllllIlllIlIlIIlIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIlIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlIIlIllIIl) {
      lllllllllllllllIlllIlIlIIlIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlIIllllIl() {
    lIlllIlIlIllIl = new int[21];
    lIlllIlIlIllIl[0] = ("   ".length() << (0x7F ^ 0x7A) ^ 0x26 ^ 0x79) & ((0xCE ^ 0x9B) << " ".length() ^ 106 + 87 - 72 + 28 ^ -" ".length());
    lIlllIlIlIllIl[1] = " ".length();
    lIlllIlIlIllIl[2] = "   ".length();
    lIlllIlIlIllIl[3] = " ".length() << " ".length();
    lIlllIlIlIllIl[4] = " ".length() << " ".length() << " ".length();
    lIlllIlIlIllIl[5] = 0x6E ^ 0x6B;
    lIlllIlIlIllIl[6] = 0x93 ^ 0x80;
    lIlllIlIlIllIl[7] = (0x98 ^ 0x9F) << " ".length();
    lIlllIlIlIllIl[8] = 0x98 ^ 0x9F;
    lIlllIlIlIllIl[9] = "   ".length() << " ".length() << " ".length();
    lIlllIlIlIllIl[10] = 96 + 82 - 149 + 102 ^ (0x25 ^ 0x62) << " ".length();
    lIlllIlIlIllIl[11] = (0xA ^ 0x17) << " ".length() << " ".length() ^ 0x22 ^ 0x5F;
    lIlllIlIlIllIl[12] = "   ".length() << " ".length();
    lIlllIlIlIllIl[13] = (0x6B ^ 0x6E) << " ".length();
    lIlllIlIlIllIl[14] = " ".length() << "   ".length();
    lIlllIlIlIllIl[15] = 27 + 74 - -34 + 74 ^ "   ".length() << "   ".length() << " ".length();
    lIlllIlIlIllIl[16] = (0xB7 ^ 0xA0) << "   ".length() ^ 39 + 13 - -93 + 38;
    lIlllIlIlIllIl[17] = 85 + 113 - 102 + 39 ^ (0x8A ^ 0xA9) << " ".length() << " ".length();
    lIlllIlIlIllIl[18] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIlIllIl[19] = (0x98 ^ 0x91) << " ".length();
    lIlllIlIlIllIl[20] = (0x35 ^ 0x30) << " ".length() << " ".length();
  }
  
  private static boolean lllllIlIlIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIlIlIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIlIIllllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIlIIlllllI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */