package me.stupitdog.bhp;

import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.item.ItemStack;

public class f10000000000000000000000 extends au {
  private static String[] llIIIIIIlIllll;
  
  private static Class[] llIIIIIIllIIII;
  
  private static final String[] llIIIIIIllllIl;
  
  private static String[] llIIIIIlIIIllI;
  
  private static final int[] llIIIIIlIIlIII;
  
  public f10000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIIllllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIIllllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIIllllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlllIIllIIIIIl	Lme/stupitdog/bhp/f10000000000000000000000;
  }
  
  public static void renderShulkerPreview(ItemStack lllllllllllllllIllIlllIIlIllllIl, int lllllllllllllllIllIlllIIlIllllII, int lllllllllllllllIllIlllIIlIlllIll, int lllllllllllllllIllIlllIIlIlllIlI, int lllllllllllllllIllIlllIIlIlllIIl) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f01
    //   3: dup
    //   4: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   7: iconst_3
    //   8: iaload
    //   9: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   12: iconst_3
    //   13: iaload
    //   14: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   17: iconst_3
    //   18: iaload
    //   19: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   22: iconst_3
    //   23: iaload
    //   24: invokespecial <init> : (IIII)V
    //   27: astore #5
    //   29: new me/stupitdog/bhp/f01
    //   32: dup
    //   33: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   41: iconst_0
    //   42: iaload
    //   43: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   46: iconst_0
    //   47: iaload
    //   48: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   51: iconst_4
    //   52: iaload
    //   53: invokespecial <init> : (IIII)V
    //   56: astore #6
    //   58: iload_1
    //   59: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   62: iconst_1
    //   63: iaload
    //   64: iadd
    //   65: iload_2
    //   66: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   69: iconst_1
    //   70: iaload
    //   71: iadd
    //   72: iload_3
    //   73: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   76: iconst_2
    //   77: iaload
    //   78: isub
    //   79: iload #4
    //   81: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   84: iconst_2
    //   85: iaload
    //   86: isub
    //   87: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   90: iconst_5
    //   91: iaload
    //   92: aload #6
    //   94: <illegal opcode> 1 : (IIIIILme/stupitdog/bhp/f01;)V
    //   99: iload_1
    //   100: iload_2
    //   101: iload_3
    //   102: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   105: iconst_1
    //   106: iaload
    //   107: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   110: iconst_5
    //   111: iaload
    //   112: aload #5
    //   114: <illegal opcode> 1 : (IIIIILme/stupitdog/bhp/f01;)V
    //   119: iload_1
    //   120: iload_2
    //   121: iload #4
    //   123: iadd
    //   124: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   127: iconst_1
    //   128: iaload
    //   129: isub
    //   130: iload_3
    //   131: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   134: iconst_1
    //   135: iaload
    //   136: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   139: iconst_5
    //   140: iaload
    //   141: aload #5
    //   143: <illegal opcode> 1 : (IIIIILme/stupitdog/bhp/f01;)V
    //   148: iload_1
    //   149: iload_2
    //   150: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   153: iconst_1
    //   154: iaload
    //   155: iload #4
    //   157: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   160: iconst_5
    //   161: iaload
    //   162: aload #5
    //   164: <illegal opcode> 1 : (IIIIILme/stupitdog/bhp/f01;)V
    //   169: iload_1
    //   170: iload_3
    //   171: iadd
    //   172: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   175: iconst_1
    //   176: iaload
    //   177: isub
    //   178: iload_2
    //   179: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   182: iconst_1
    //   183: iaload
    //   184: iload #4
    //   186: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   189: iconst_5
    //   190: iaload
    //   191: aload #5
    //   193: <illegal opcode> 1 : (IIIIILme/stupitdog/bhp/f01;)V
    //   198: <illegal opcode> 2 : ()V
    //   203: aload_0
    //   204: <illegal opcode> 3 : (Lnet/minecraft/item/ItemStack;)Ljava/lang/String;
    //   209: iload_1
    //   210: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   213: bipush #6
    //   215: iaload
    //   216: iadd
    //   217: i2f
    //   218: iload_2
    //   219: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   222: bipush #6
    //   224: iaload
    //   225: iadd
    //   226: i2f
    //   227: new me/stupitdog/bhp/f01
    //   230: dup
    //   231: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   234: iconst_3
    //   235: iaload
    //   236: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   239: iconst_3
    //   240: iaload
    //   241: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   244: iconst_3
    //   245: iaload
    //   246: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   249: iconst_3
    //   250: iaload
    //   251: invokespecial <init> : (IIII)V
    //   254: <illegal opcode> 4 : (Ljava/lang/String;FFLme/stupitdog/bhp/f01;)F
    //   259: ldc ''
    //   261: invokevirtual length : ()I
    //   264: pop2
    //   265: <illegal opcode> 5 : ()V
    //   270: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   273: bipush #7
    //   275: iaload
    //   276: <illegal opcode> 6 : ()Lnet/minecraft/item/ItemStack;
    //   281: <illegal opcode> 7 : (ILjava/lang/Object;)Lnet/minecraft/util/NonNullList;
    //   286: astore #7
    //   288: aload_0
    //   289: <illegal opcode> 8 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagCompound;
    //   294: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIIllllIl : [Ljava/lang/String;
    //   297: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   300: bipush #6
    //   302: iaload
    //   303: aaload
    //   304: <illegal opcode> 9 : (Lnet/minecraft/nbt/NBTTagCompound;Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound;
    //   309: aload #7
    //   311: <illegal opcode> 10 : (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList;)V
    //   316: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   319: iconst_0
    //   320: iaload
    //   321: istore #8
    //   323: iload #8
    //   325: aload #7
    //   327: <illegal opcode> 11 : (Lnet/minecraft/util/NonNullList;)I
    //   332: invokestatic lIIIIIIllIIllllI : (II)Z
    //   335: ifeq -> 443
    //   338: iload_1
    //   339: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   342: iconst_1
    //   343: iaload
    //   344: iadd
    //   345: iload #8
    //   347: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   350: bipush #8
    //   352: iaload
    //   353: irem
    //   354: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   357: bipush #9
    //   359: iaload
    //   360: imul
    //   361: iadd
    //   362: istore #9
    //   364: iload_2
    //   365: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   368: bipush #10
    //   370: iaload
    //   371: iadd
    //   372: iload #8
    //   374: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   377: bipush #8
    //   379: iaload
    //   380: idiv
    //   381: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   384: iconst_1
    //   385: iaload
    //   386: isub
    //   387: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   390: bipush #9
    //   392: iaload
    //   393: imul
    //   394: iadd
    //   395: istore #10
    //   397: aload #7
    //   399: iload #8
    //   401: <illegal opcode> 12 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   406: checkcast net/minecraft/item/ItemStack
    //   409: new java/awt/Point
    //   412: dup
    //   413: iload #9
    //   415: iload #10
    //   417: invokespecial <init> : (II)V
    //   420: <illegal opcode> 13 : (Lnet/minecraft/item/ItemStack;Ljava/awt/Point;)V
    //   425: iinc #8, 1
    //   428: ldc ''
    //   430: invokevirtual length : ()I
    //   433: pop
    //   434: ldc ' '
    //   436: invokevirtual length : ()I
    //   439: ifne -> 323
    //   442: return
    //   443: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   364	61	9	lllllllllllllllIllIlllIIllIIIIII	I
    //   397	28	10	lllllllllllllllIllIlllIIlIllllll	I
    //   323	120	8	lllllllllllllllIllIlllIIlIlllllI	I
    //   0	444	0	lllllllllllllllIllIlllIIlIllllIl	Lnet/minecraft/item/ItemStack;
    //   0	444	1	lllllllllllllllIllIlllIIlIllllII	I
    //   0	444	2	lllllllllllllllIllIlllIIlIlllIll	I
    //   0	444	3	lllllllllllllllIllIlllIIlIlllIlI	I
    //   0	444	4	lllllllllllllllIllIlllIIlIlllIIl	I
    //   29	415	5	lllllllllllllllIllIlllIIlIlllIII	Lme/stupitdog/bhp/f01;
    //   58	386	6	lllllllllllllllIllIlllIIlIllIlll	Lme/stupitdog/bhp/f01;
    //   288	156	7	lllllllllllllllIllIlllIIlIllIllI	Lnet/minecraft/util/NonNullList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   288	156	7	lllllllllllllllIllIlllIIlIllIllI	Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;
  }
  
  public static void renderItem(ItemStack lllllllllllllllIllIlllIIlIllIlIl, Point lllllllllllllllIllIlllIIlIllIlII) {
    // Byte code:
    //   0: <illegal opcode> 14 : ()V
    //   5: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   8: iconst_1
    //   9: iaload
    //   10: <illegal opcode> 15 : (Z)V
    //   15: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   18: bipush #11
    //   20: iaload
    //   21: <illegal opcode> 16 : (I)V
    //   26: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   29: bipush #12
    //   31: iaload
    //   32: <illegal opcode> 17 : (I)V
    //   37: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   40: bipush #13
    //   42: iaload
    //   43: <illegal opcode> 18 : (I)V
    //   48: <illegal opcode> 19 : ()V
    //   53: <illegal opcode> 5 : ()V
    //   58: <illegal opcode> 20 : ()V
    //   63: <illegal opcode> 21 : ()V
    //   68: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   73: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   78: ldc -150.0
    //   80: putfield field_77023_b : F
    //   83: <illegal opcode> 24 : ()V
    //   88: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   93: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   98: aload_0
    //   99: aload_1
    //   100: <illegal opcode> 25 : (Ljava/awt/Point;)I
    //   105: aload_1
    //   106: <illegal opcode> 26 : (Ljava/awt/Point;)I
    //   111: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/RenderItem;Lnet/minecraft/item/ItemStack;II)V
    //   116: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   121: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   126: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   131: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   136: aload_0
    //   137: aload_1
    //   138: <illegal opcode> 25 : (Ljava/awt/Point;)I
    //   143: aload_1
    //   144: <illegal opcode> 26 : (Ljava/awt/Point;)I
    //   149: <illegal opcode> 29 : (Lnet/minecraft/client/renderer/RenderItem;Lnet/minecraft/client/gui/FontRenderer;Lnet/minecraft/item/ItemStack;II)V
    //   154: <illegal opcode> 30 : ()V
    //   159: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   164: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   169: fconst_0
    //   170: putfield field_77023_b : F
    //   173: <illegal opcode> 31 : ()V
    //   178: <illegal opcode> 2 : ()V
    //   183: getstatic me/stupitdog/bhp/f10000000000000000000000.llIIIIIlIIlIII : [I
    //   186: iconst_0
    //   187: iaload
    //   188: <illegal opcode> 15 : (Z)V
    //   193: <illegal opcode> 32 : ()V
    //   198: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	199	0	lllllllllllllllIllIlllIIlIllIlIl	Lnet/minecraft/item/ItemStack;
    //   0	199	1	lllllllllllllllIllIlllIIlIllIlII	Ljava/awt/Point;
  }
  
  static {
    lIIIIIIllIIlllIl();
    lIIIIIIllIIIlllI();
    lIIIIIIllIIIllIl();
    lIIIIIIlIlllllll();
  }
  
  private static CallSite lIIIIIIlIlIlIlll(MethodHandles.Lookup lllllllllllllllIllIlllIIlIlIlIll, String lllllllllllllllIllIlllIIlIlIlIlI, MethodType lllllllllllllllIllIlllIIlIlIlIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIIlIllIIIl = llIIIIIIlIllll[Integer.parseInt(lllllllllllllllIllIlllIIlIlIlIlI)].split(llIIIIIIllllIl[llIIIIIlIIlIII[14]]);
      Class<?> lllllllllllllllIllIlllIIlIllIIII = Class.forName(lllllllllllllllIllIlllIIlIllIIIl[llIIIIIlIIlIII[0]]);
      String lllllllllllllllIllIlllIIlIlIllll = lllllllllllllllIllIlllIIlIllIIIl[llIIIIIlIIlIII[1]];
      MethodHandle lllllllllllllllIllIlllIIlIlIlllI = null;
      int lllllllllllllllIllIlllIIlIlIllIl = lllllllllllllllIllIlllIIlIllIIIl[llIIIIIlIIlIII[6]].length();
      if (lIIIIIIllIIlllll(lllllllllllllllIllIlllIIlIlIllIl, llIIIIIlIIlIII[2])) {
        MethodType lllllllllllllllIllIlllIIlIllIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIIlIllIIIl[llIIIIIlIIlIII[2]], f10000000000000000000000.class.getClassLoader());
        if (lIIIIIIllIlIIIII(lllllllllllllllIllIlllIIlIlIllIl, llIIIIIlIIlIII[2])) {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findVirtual(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findStatic(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIll);
        } 
        "".length();
        if (" ".length() << " ".length() != " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIIlIllIIlI = llIIIIIIllIIII[Integer.parseInt(lllllllllllllllIllIlllIIlIllIIIl[llIIIIIlIIlIII[2]])];
        if (lIIIIIIllIlIIIII(lllllllllllllllIllIlllIIlIlIllIl, llIIIIIlIIlIII[6])) {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findGetter(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIlI);
          "".length();
          if (-((0x90 ^ 0x8B) << " ".length() << " ".length() ^ 0xD8 ^ 0xB1) >= 0)
            return null; 
        } else if (lIIIIIIllIlIIIII(lllllllllllllllIllIlllIIlIlIllIl, llIIIIIlIIlIII[14])) {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findStaticGetter(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIllIlIIIII(lllllllllllllllIllIlllIIlIlIllIl, llIIIIIlIIlIII[15])) {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findSetter(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIlI);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIlllIIlIlIlllI = lllllllllllllllIllIlllIIlIlIlIll.findStaticSetter(lllllllllllllllIllIlllIIlIllIIII, lllllllllllllllIllIlllIIlIlIllll, lllllllllllllllIllIlllIIlIllIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIIlIlIlllI);
    } catch (Exception lllllllllllllllIllIlllIIlIlIllII) {
      lllllllllllllllIllIlllIIlIlIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIlllllll() {
    llIIIIIIlIllll = new String[llIIIIIlIIlIII[16]];
    llIIIIIIlIllll[llIIIIIlIIlIII[17]] = llIIIIIIllllIl[llIIIIIlIIlIII[15]];
    llIIIIIIlIllll[llIIIIIlIIlIII[14]] = llIIIIIIllllIl[llIIIIIlIIlIII[18]];
    llIIIIIIlIllll[llIIIIIlIIlIII[19]] = llIIIIIIllllIl[llIIIIIlIIlIII[17]];
    llIIIIIIlIllll[llIIIIIlIIlIII[20]] = llIIIIIIllllIl[llIIIIIlIIlIII[21]];
    llIIIIIIlIllll[llIIIIIlIIlIII[7]] = llIIIIIIllllIl[llIIIIIlIIlIII[8]];
    llIIIIIIlIllll[llIIIIIlIIlIII[22]] = llIIIIIIllllIl[llIIIIIlIIlIII[23]];
    llIIIIIIlIllll[llIIIIIlIIlIII[6]] = llIIIIIIllllIl[llIIIIIlIIlIII[24]];
    llIIIIIIlIllll[llIIIIIlIIlIII[25]] = llIIIIIIllllIl[llIIIIIlIIlIII[26]];
    llIIIIIIlIllll[llIIIIIlIIlIII[1]] = llIIIIIIllllIl[llIIIIIlIIlIII[27]];
    llIIIIIIlIllll[llIIIIIlIIlIII[21]] = llIIIIIIllllIl[llIIIIIlIIlIII[28]];
    llIIIIIIlIllll[llIIIIIlIIlIII[29]] = llIIIIIIllllIl[llIIIIIlIIlIII[30]];
    llIIIIIIlIllll[llIIIIIlIIlIII[26]] = llIIIIIIllllIl[llIIIIIlIIlIII[31]];
    llIIIIIIlIllll[llIIIIIlIIlIII[23]] = llIIIIIIllllIl[llIIIIIlIIlIII[32]];
    llIIIIIIlIllll[llIIIIIlIIlIII[33]] = llIIIIIIllllIl[llIIIIIlIIlIII[9]];
    llIIIIIIlIllll[llIIIIIlIIlIII[24]] = llIIIIIIllllIl[llIIIIIlIIlIII[19]];
    llIIIIIIlIllll[llIIIIIlIIlIII[8]] = llIIIIIIllllIl[llIIIIIlIIlIII[34]];
    llIIIIIIlIllll[llIIIIIlIIlIII[32]] = llIIIIIIllllIl[llIIIIIlIIlIII[35]];
    llIIIIIIlIllll[llIIIIIlIIlIII[0]] = llIIIIIIllllIl[llIIIIIlIIlIII[36]];
    llIIIIIIlIllll[llIIIIIlIIlIII[37]] = llIIIIIIllllIl[llIIIIIlIIlIII[25]];
    llIIIIIIlIllll[llIIIIIlIIlIII[10]] = llIIIIIIllllIl[llIIIIIlIIlIII[29]];
    llIIIIIIlIllll[llIIIIIlIIlIII[28]] = llIIIIIIllllIl[llIIIIIlIIlIII[20]];
    llIIIIIIlIllll[llIIIIIlIIlIII[38]] = llIIIIIIllllIl[llIIIIIlIIlIII[33]];
    llIIIIIIlIllll[llIIIIIlIIlIII[15]] = llIIIIIIllllIl[llIIIIIlIIlIII[7]];
    llIIIIIIlIllll[llIIIIIlIIlIII[9]] = llIIIIIIllllIl[llIIIIIlIIlIII[37]];
    llIIIIIIlIllll[llIIIIIlIIlIII[18]] = llIIIIIIllllIl[llIIIIIlIIlIII[22]];
    llIIIIIIlIllll[llIIIIIlIIlIII[35]] = llIIIIIIllllIl[llIIIIIlIIlIII[38]];
    llIIIIIIlIllll[llIIIIIlIIlIII[36]] = llIIIIIIllllIl[llIIIIIlIIlIII[10]];
    llIIIIIIlIllll[llIIIIIlIIlIII[2]] = llIIIIIIllllIl[llIIIIIlIIlIII[39]];
    llIIIIIIlIllll[llIIIIIlIIlIII[39]] = llIIIIIIllllIl[llIIIIIlIIlIII[16]];
    llIIIIIIlIllll[llIIIIIlIIlIII[34]] = llIIIIIIllllIl[llIIIIIlIIlIII[40]];
    llIIIIIIlIllll[llIIIIIlIIlIII[31]] = llIIIIIIllllIl[llIIIIIlIIlIII[41]];
    llIIIIIIlIllll[llIIIIIlIIlIII[30]] = llIIIIIIllllIl[llIIIIIlIIlIII[42]];
    llIIIIIIlIllll[llIIIIIlIIlIII[27]] = llIIIIIIllllIl[llIIIIIlIIlIII[43]];
    llIIIIIIllIIII = new Class[llIIIIIlIIlIII[15]];
    llIIIIIIllIIII[llIIIIIlIIlIII[2]] = float.class;
    llIIIIIIllIIII[llIIIIIlIIlIII[14]] = FontRenderer.class;
    llIIIIIIllIIII[llIIIIIlIIlIII[6]] = int.class;
    llIIIIIIllIIII[llIIIIIlIIlIII[0]] = f13.class;
    llIIIIIIllIIII[llIIIIIlIIlIII[1]] = ItemStack.class;
  }
  
  private static void lIIIIIIllIIIllIl() {
    llIIIIIIllllIl = new String[llIIIIIlIIlIII[44]];
    llIIIIIIllllIl[llIIIIIlIIlIII[0]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[0]], llIIIIIlIIIllI[llIIIIIlIIlIII[1]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[1]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[2]], llIIIIIlIIIllI[llIIIIIlIIlIII[6]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[2]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[14]], llIIIIIlIIIllI[llIIIIIlIIlIII[15]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[6]] = lIIIIIIllIIIIIIl(llIIIIIlIIIllI[llIIIIIlIIlIII[18]], llIIIIIlIIIllI[llIIIIIlIIlIII[17]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[14]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[21]], llIIIIIlIIIllI[llIIIIIlIIlIII[8]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[15]] = lIIIIIIllIIIIIIl(llIIIIIlIIIllI[llIIIIIlIIlIII[23]], llIIIIIlIIIllI[llIIIIIlIIlIII[24]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[18]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[26]], llIIIIIlIIIllI[llIIIIIlIIlIII[27]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[17]] = lIIIIIIllIIIIIIl(llIIIIIlIIIllI[llIIIIIlIIlIII[28]], llIIIIIlIIIllI[llIIIIIlIIlIII[30]]);
    llIIIIIIllllIl[llIIIIIlIIlIII[21]] = lIIIIIIllIIIIIII(llIIIIIlIIIllI[llIIIIIlIIlIII[31]], "mYYXM");
    llIIIIIIllllIl[llIIIIIlIIlIII[8]] = lIIIIIIllIIIIIII("LgILLbgsngwlxNeqMv/gNkNHhJqUKOoN7k7qr+LZC/5ytn5rosXawGvm45hfJj2t6EkN18LJMPULdhDTOUwq4T/TWWU/ZmHxxUUj0PafRctrrdfqb2ZQ7I+z3DBGUm7N", "cRPJK");
    llIIIIIIllllIl[llIIIIIlIIlIII[23]] = lIIIIIIllIIIIIII("kMFcelpVvR+Pk+yrNuaQRekFHz0gXXOXNJbVMZj3ASivI8gtwRpszRrptn/YmOjeKYEYx2gQPsnypG617HWYOxAhdC9W7yKmBYiJ5lruG1jkUj2ewMVCD8UDKtXZtrEykOY4ScI4dJMH+qis0UgWDB2ZoPzjV4xFmwTbf55rdV7DRF2Iy3CUkQ==", "aKDfm");
    llIIIIIIllllIl[llIIIIIlIIlIII[24]] = lIIIIIIllIIIIIIl("yCFLqejmx5dran7HqsW/u+52ZZstXOkzYvQZAOci4FI2AfTT/Aqnx5fb2yGK6SJkJPyLwbcUC3MQfoQM113MF5ALCkJk1cZl", "AkRuD");
    llIIIIIIllllIl[llIIIIIlIIlIII[26]] = lIIIIIIllIIIIIIl("jElfwbLUsf2kuwqSdf0H7Tw6sytjQgSGXuXm5oo0OcmMwqI62IwBlzkhSfEnM9csQxd0Q+huDnTm+0KfHng9LpIBgjyUpndB/6SyKRpXy0o3mGqOfgIa7TQsfqbHJRx8", "DHBnB");
    llIIIIIIllllIl[llIIIIIlIIlIII[27]] = lIIIIIIllIIIIIIl("Q8h7pGC0VszLdCJqZIumJiNPFndSiJvTr6A5YLnX4j+YAoEGX9bbLKTvXOor9w/JS8yneldUl74qsDswVcTxheKgbG2rbTYgnEhJMi8KhPE4ksWGh8BuTQ==", "vqGNu");
    llIIIIIIllllIl[llIIIIIlIIlIII[28]] = lIIIIIIllIIIIIlI("KzMDfyEsOBIyPiQwA38lMTMafwUxMxoCOCQ1HGsqMDgUDntyb0BpEzVsX3gAKzMDfiEsOBIyPiQwA34iJyJYHw4RAhY2Dyo7Bz45KzJMa2xl", "EVwQL");
    llIIIIIIllllIl[llIIIIIlIIlIII[30]] = lIIIIIIllIIIIIlI("GCI6ewEfKSs2HhchOnsPGi4rOxhYNSs7CBM1KydCJCIgMQkEDys5HBM1dDMZGCQRYlhDdX4KD0xvZwNWVg==", "vGNUl");
    llIIIIIIllllIl[llIIIIIlIIlIII[31]] = lIIIIIIllIIIIIII("tojfZFDHzMAfp25MGYZJURwkJWAU59yqnIoSVnVAtk5bWKI6wpephO5oZSP6TBTUSQMFj7leEE8pq7caNgaSDA==", "zxWmJ");
    llIIIIIIllllIl[llIIIIIlIIlIII[32]] = lIIIIIIllIIIIIlI("BQ4EezkCBRU2JgoNBHs9BR0VOyAEGQl7HR8OHQYgCggbHTEHGxUnbg0eHjYLWlJBZ2xYNBJvfCcFFSF7BgIeMDcZChYhewUJBHoaKT8kNDMoBB0lOx4FFG4YBQ4EejkCBRU2JgoNBHohHwIcehoEBT4gOAcnGSYgUEImb3Q=", "kkpUT");
    llIIIIIIllllIl[llIIIIIlIIlIII[9]] = lIIIIIIllIIIIIlI("CxQYO3sAAhp0BQ4cAC5vGE9dYHVBVQ==", "aunZU");
    llIIIIIIllllIl[llIIIIIlIIlIII[19]] = lIIIIIIllIIIIIII("5FC4Ea7B3P+7wehK2sJN7jhGhIYyftuEQ7hAyhoXmzOEZQUm4iibu0i+GHNvMEw/", "PkVaI");
    llIIIIIIllllIl[llIIIIIlIIlIII[34]] = lIIIIIIllIIIIIII("87DDvwNzuNhRRkuBqITtp3AHvy9n2s4O1YKcKUFHKUlGhr7aUYPhdBZtbnP84MpD+Ue7+EEwvZK9z6JAHuHxdEZZ2wtZ5EqOLsgUCzLpoD2kJ6C85aBqMsnWiqsRXkB2SLw4KXG+vl0=", "MzBfR");
    llIIIIIIllllIl[llIIIIIlIIlIII[35]] = lIIIIIIllIIIIIIl("9P1C/FoKv0uf08mn+KlKjxY3BBDCc2SzU6yNXnPqqmtfbKwZpkGerQ==", "IjvfM");
    llIIIIIIllllIl[llIIIIIlIIlIII[36]] = lIIIIIIllIIIIIIl("q2X3k1pxU9DAPDnJ28EkzbNgBptV4FssO0k34eiQPf3HRMy6hUtBbw==", "BKgNe");
    llIIIIIIllllIl[llIIIIIlIIlIII[25]] = lIIIIIIllIIIIIII("Zh7X3TtcKkw53XcW3FYRlnnw/mfeXhCJjbRcFbWCB6Dpmv+NSSl56bxkzv2qdVSQZwNICWFyDoY=", "hdWfm");
    llIIIIIIllllIl[llIIIIIlIIlIII[29]] = lIIIIIIllIIIIIlI("PyAMXSw4Kx0QMzAjDF0iPSwdHTV/Nx0dJTQ3HQFvFikrByAlIDUSLzAiHQF7NzAWEB5gckFCc2AaPklpeBNCUw==", "QExsA");
    llIIIIIIllllIl[llIIIIIlIIlIII[20]] = lIIIIIIllIIIIIlI("BQklfggCAjQzFwoKJX4GBwU0PhFFHjQ+AQ4eNCJLLAACJAQfCRwxCwoLNCJfDRk/MzpaW2hgXFMzJmpNQjprcA==", "klQPe");
    llIIIIIIllllIl[llIIIIIlIIlIII[33]] = lIIIIIIllIIIIIII("/Z9AZMhOCVOz7ahbanvpeHnV7KWi0Y9uRMgcL0ISLQWlxmG8vmcUhqbLoDqSsu5uS8ptTjNrNzD+8h6Fn6YSSg==", "wNYYX");
    llIIIIIIllllIl[llIIIIIlIIlIII[7]] = lIIIIIIllIIIIIII("g4YZa38abdTJbus9owbqEEdW76NCsVtgE+OUbtBVwovJrHlOCgA0vb3EQaWXH9OuDuw89+uSDmJXE5x0sy6jGzlZ04wGlpGo", "SMFYC");
    llIIIIIIllllIl[llIIIIIlIIlIII[37]] = lIIIIIIllIIIIIIl("7zJiIWioXaaHIQi5tYeRrKxVFGrsSDeYE1CXNUTr24AnQTKJYryGWFfcSsMEz7qvLjPuDkeiC8KZpM5IUf3xmVULsa+B4uOd", "AqkHh");
    llIIIIIIllllIl[llIIIIIlIIlIII[22]] = lIIIIIIllIIIIIII("U7ZdXyFqaEwJpL73x8SGx1Pz9TJErtD5kAoTZZ5p0DT6Tts5vOsnJmuEI7ctrY/ILWVxp48zpw4=", "bNiBR");
    llIIIIIIllllIl[llIIIIIlIIlIII[38]] = lIIIIIIllIIIIIlI("AC0RRSAHJgAIPw8uEUUuAiEABTlAOgAFKQs6ABljKSQ2HywaLSgKIw8vABl3CD0LCBJff1xbdFoXIFFlRx5fSw==", "nHekM");
    llIIIIIIllllIl[llIIIIIlIIlIII[10]] = lIIIIIIllIIIIIII("ZtnCYp8KrkhoWd8eGGLPCWB++J7l1iOTCuk2HbwoUk0aym7pxAhe8K3aWHE6nZnwz+/WshogYnSc0gGO2ybMPEfCZqMzJxinFjlioe2s6LEGqf4CtHEKDg==", "KabFU");
    llIIIIIIllllIl[llIIIIIlIIlIII[39]] = lIIIIIIllIIIIIII("ITZNN8GdvAYFc8zbNokCxopGMNeudUSn8M0ynMp3aosGM9OebovMQULlNhfIpIT0BGWNoF0wMlPAslcYAzwAFQ4zJlQwFA1r", "CECDB");
    llIIIIIIllllIl[llIIIIIlIIlIII[16]] = lIIIIIIllIIIIIIl("7/OKvOHOPVn6GCEXQkNerQsyTFSee6g62PG1WrM08QpCKydUvMofk3aTC400xXCRtbRtz16jdrc=", "zhoik");
    llIIIIIIllllIl[llIIIIIlIIlIII[40]] = lIIIIIIllIIIIIlI("ISkfeQomIg40FS4qH3kEIyUOORNhPg45Ayo+DiVJCCA4IwY7KSY2CS4rDiVdKTkFNDh+e1JmVncTCG1PZhpRdw==", "OLkWg");
    llIIIIIIllllIl[llIIIIIlIIlIII[41]] = lIIIIIIllIIIIIlI("Gys+RRwDMz4HXhspPAUXGHceJ0FFYz4HIAEqMSoEACswCUpcEHA9SlQ=", "tYYkp");
    llIIIIIIllllIl[llIIIIIlIIlIII[42]] = lIIIIIIllIIIIIIl("+67id7Iyqxs2OwX4GbFo/NWiu7LaPzlkWS94HaEcW5nrw1omVy280wyeqGld2ohq7/wIq1sCNoBrCnX3SgSPovnNb1AU22/5", "aedIS");
    llIIIIIIllllIl[llIIIIIlIIlIII[43]] = lIIIIIIllIIIIIlI("HCdtGywEMiocPB4lbQowAWwlWWhBcnNYaEFyc1hoQXJzWGhBcnNYaEF4MQ02FScxISwUL3lAFB8nN0c1GCwmCyoQJDdHMQUnLkcRBScuOywQIShTFBsjNQl3EDU3RwgeKy0cY1gUeUg=", "qBChX");
    llIIIIIlIIIllI = null;
  }
  
  private static void lIIIIIIllIIIlllI() {
    String str = (new Exception()).getStackTrace()[llIIIIIlIIlIII[0]].getFileName();
    llIIIIIlIIIllI = str.substring(str.indexOf("ä") + llIIIIIlIIlIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIllIIIIIlI(String lllllllllllllllIllIlllIIlIlIIlll, String lllllllllllllllIllIlllIIlIlIIllI) {
    lllllllllllllllIllIlllIIlIlIIlll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIIlIlIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIIlIlIIlIl = new StringBuilder();
    char[] lllllllllllllllIllIlllIIlIlIIlII = lllllllllllllllIllIlllIIlIlIIllI.toCharArray();
    int lllllllllllllllIllIlllIIlIlIIIll = llIIIIIlIIlIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIIlIlIIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIlIIlIII[0];
    while (lIIIIIIllIIllllI(j, i)) {
      char lllllllllllllllIllIlllIIlIlIlIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIIlIlIIIll++;
      j++;
      "".length();
      if ((((0x4F ^ 0x62) << " ".length() << " ".length() ^ 56 + 153 - 45 + 3) << " ".length() & ((7 + 106 - -27 + 5 ^ (0x62 ^ 0x23) << " ".length()) << " ".length() ^ -" ".length())) > (((0x40 ^ 0x71) << " ".length() << " ".length() ^ 80 + 4 - -49 + 60) << " ".length() & ((0x8 ^ 0x69 ^ (0xDC ^ 0xC5) << " ".length() << " ".length()) << " ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIIlIlIIlIl);
  }
  
  private static String lIIIIIIllIIIIIII(String lllllllllllllllIllIlllIIlIIlllll, String lllllllllllllllIllIlllIIlIIllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIIlIlIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIIlIIllllI.getBytes(StandardCharsets.UTF_8)), llIIIIIlIIlIII[21]), "DES");
      Cipher lllllllllllllllIllIlllIIlIlIIIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIIlIlIIIIl.init(llIIIIIlIIlIII[2], lllllllllllllllIllIlllIIlIlIIIlI);
      return new String(lllllllllllllllIllIlllIIlIlIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIIlIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIIlIlIIIII) {
      lllllllllllllllIllIlllIIlIlIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIllIIIIIIl(String lllllllllllllllIllIlllIIlIIllIlI, String lllllllllllllllIllIlllIIlIIllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIIlIIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIIlIIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIIlIIlllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIIlIIlllII.init(llIIIIIlIIlIII[2], lllllllllllllllIllIlllIIlIIlllIl);
      return new String(lllllllllllllllIllIlllIIlIIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIIlIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIIlIIllIll) {
      lllllllllllllllIllIlllIIlIIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIllIIlllIl() {
    llIIIIIlIIlIII = new int[45];
    llIIIIIlIIlIII[0] = (0x8E ^ 0xAD) << " ".length() & ((0xA2 ^ 0x81) << " ".length() ^ 0xFFFFFFFF);
    llIIIIIlIIlIII[1] = " ".length();
    llIIIIIlIIlIII[2] = " ".length() << " ".length();
    llIIIIIlIIlIII[3] = (0x76 ^ 0x59) + ((0x3 ^ 0x30) << " ".length()) - -(0x2D ^ 0x6) + (0xA9 ^ 0x96);
    llIIIIIlIIlIII[4] = (0x66 ^ 0x25 ^ (0x83 ^ 0xAE) << " ".length()) << "   ".length();
    llIIIIIlIIlIII[5] = (0x2C ^ 0x51) << "   ".length();
    llIIIIIlIIlIII[6] = "   ".length();
    llIIIIIlIIlIII[7] = (0x76 ^ 0x6D) << " ".length() << " ".length() ^ 0x6B ^ 0x1C;
    llIIIIIlIIlIII[8] = 0x64 ^ 0x6D;
    llIIIIIlIIlIII[9] = (0x25 ^ 0x2C) << " ".length();
    llIIIIIlIIlIII[10] = 0x58 ^ 0x47;
    llIIIIIlIIlIII[11] = " ".length() << ((0x74 ^ 0x35) << " ".length() ^ 127 + 43 - 116 + 91);
    llIIIIIlIIlIII[12] = 1506 + 2254 - 2063 + 1392;
    llIIIIIlIIlIII[13] = " ".length() << " ".length() << "   ".length();
    llIIIIIlIIlIII[14] = " ".length() << " ".length() << " ".length();
    llIIIIIlIIlIII[15] = (0xF ^ 0x2) << " ".length() << " ".length() ^ 0x5E ^ 0x6F;
    llIIIIIlIIlIII[16] = (0x10 ^ 0x51) << " ".length() ^ 154 + 116 - 192 + 85;
    llIIIIIlIIlIII[17] = (0xEE ^ 0xAF) << " ".length() ^ 31 + 105 - 83 + 80;
    llIIIIIlIIlIII[18] = "   ".length() << " ".length();
    llIIIIIlIIlIII[19] = 0x3F ^ 0x2C;
    llIIIIIlIIlIII[20] = 0x51 ^ 0x32 ^ (0x18 ^ 0x25) << " ".length();
    llIIIIIlIIlIII[21] = " ".length() << "   ".length();
    llIIIIIlIIlIII[22] = " ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ 0xFFFFFFFF) ^ 0x5F ^ 0x42;
    llIIIIIlIIlIII[23] = (0xBE ^ 0xAD ^ (0xBD ^ 0xB6) << " ".length()) << " ".length();
    llIIIIIlIIlIII[24] = (0x1 ^ 0x8) << "   ".length() ^ 0xDF ^ 0x9C;
    llIIIIIlIIlIII[25] = 0xAB ^ 0xBC;
    llIIIIIlIIlIII[26] = "   ".length() << " ".length() << " ".length();
    llIIIIIlIIlIII[27] = (0x1E ^ 0x9) << " ".length() ^ 0xB0 ^ 0x93;
    llIIIIIlIIlIII[28] = (0x31 ^ 0x36) << " ".length();
    llIIIIIlIIlIII[29] = "   ".length() << "   ".length();
    llIIIIIlIIlIII[30] = 0x87 ^ 0xB8 ^ "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIIlIII[31] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIIlIII[32] = (0x90 ^ 0x85) << " ".length() << " ".length() ^ 0x82 ^ 0xC7;
    llIIIIIlIIlIII[33] = (7 + 71 - 36 + 87 ^ (0x2F ^ 0xC) << " ".length() << " ".length()) << " ".length();
    llIIIIIlIIlIII[34] = (0x98 ^ 0x9D) << " ".length() << " ".length();
    llIIIIIlIIlIII[35] = (0x28 ^ 0x3F) << " ".length() ^ 0x99 ^ 0xA2;
    llIIIIIlIIlIII[36] = (0x86 ^ 0x8D) << " ".length();
    llIIIIIlIIlIII[37] = (0x4C ^ 0x4B) << " ".length() << " ".length();
    llIIIIIlIIlIII[38] = (0xAF ^ 0xA0) << " ".length();
    llIIIIIlIIlIII[39] = " ".length() << (" ".length() << " ".length() ^ 0x71 ^ 0x76);
    llIIIIIlIIlIII[40] = (0x46 ^ 0x57) << " ".length();
    llIIIIIlIIlIII[41] = 0x17 ^ 0x38 ^ "   ".length() << " ".length() << " ".length();
    llIIIIIlIIlIII[42] = (0x1F ^ 0x16) << " ".length() << " ".length();
    llIIIIIlIIlIII[43] = 0x31 ^ 0x14;
    llIIIIIlIIlIII[44] = (0x96 ^ 0x85) << " ".length();
  }
  
  private static boolean lIIIIIIllIlIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIllIIllllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIllIIlllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */