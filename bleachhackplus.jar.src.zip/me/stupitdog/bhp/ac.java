package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ac extends au {
  private static String[] lIllllIlIllIIl;
  
  private static Class[] lIllllIlIllIlI;
  
  private static final String[] lIllllIlIllIll;
  
  private static String[] lIllllIlIlllII;
  
  private static final int[] lIllllIlIlllIl;
  
  public ac() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ac.lIllllIlIllIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/ac.lIllllIlIlllIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/ac.lIllllIlIllIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/ac.lIllllIlIlllIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/ac.lIllllIlIllIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/ac.lIllllIlIlllIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/ac.lIllllIlIlllIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIlIIllIlIllI	Lme/stupitdog/bhp/ac;
  }
  
  @SubscribeEvent
  public void onChat(ClientChatEvent lllllllllllllllIlllIIlIIllIlIlII) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lnet/minecraftforge/client/event/ClientChatEvent;)Ljava/lang/String;
    //   6: astore_2
    //   7: aload_1
    //   8: new java/lang/StringBuilder
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: getstatic me/stupitdog/bhp/ac.lIllllIlIllIll : [Ljava/lang/String;
    //   18: getstatic me/stupitdog/bhp/ac.lIllllIlIlllIl : [I
    //   21: iconst_3
    //   22: iaload
    //   23: aaload
    //   24: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: aload_2
    //   30: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   40: <illegal opcode> 4 : (Lnet/minecraftforge/client/event/ClientChatEvent;Ljava/lang/String;)V
    //   45: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	46	0	lllllllllllllllIlllIIlIIllIlIlIl	Lme/stupitdog/bhp/ac;
    //   0	46	1	lllllllllllllllIlllIIlIIllIlIlII	Lnet/minecraftforge/client/event/ClientChatEvent;
    //   7	39	2	lllllllllllllllIlllIIlIIllIlIIll	Ljava/lang/String;
  }
  
  static {
    lllllllIIIlllll();
    lllllllIIIllllI();
    lllllllIIIlllIl();
    lllllllIIIllIIl();
  }
  
  private static CallSite lllllllIIIllIII(MethodHandles.Lookup lllllllllllllllIlllIIlIIllIIlIlI, String lllllllllllllllIlllIIlIIllIIlIIl, MethodType lllllllllllllllIlllIIlIIllIIlIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIIllIlIIII = lIllllIlIllIIl[Integer.parseInt(lllllllllllllllIlllIIlIIllIIlIIl)].split(lIllllIlIllIll[lIllllIlIlllIl[4]]);
      Class<?> lllllllllllllllIlllIIlIIllIIllll = Class.forName(lllllllllllllllIlllIIlIIllIlIIII[lIllllIlIlllIl[0]]);
      String lllllllllllllllIlllIIlIIllIIlllI = lllllllllllllllIlllIIlIIllIlIIII[lIllllIlIlllIl[1]];
      MethodHandle lllllllllllllllIlllIIlIIllIIllIl = null;
      int lllllllllllllllIlllIIlIIllIIllII = lllllllllllllllIlllIIlIIllIlIIII[lIllllIlIlllIl[3]].length();
      if (lllllllIIlIIIII(lllllllllllllllIlllIIlIIllIIllII, lIllllIlIlllIl[2])) {
        MethodType lllllllllllllllIlllIIlIIllIlIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIIllIlIIII[lIllllIlIlllIl[2]], ac.class.getClassLoader());
        if (lllllllIIlIIIIl(lllllllllllllllIlllIIlIIllIIllII, lIllllIlIlllIl[2])) {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findVirtual(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIlI);
          "".length();
          if (-" ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findStatic(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIlI);
        } 
        "".length();
        if (" ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIIllIlIIIl = lIllllIlIllIlI[Integer.parseInt(lllllllllllllllIlllIIlIIllIlIIII[lIllllIlIlllIl[2]])];
        if (lllllllIIlIIIIl(lllllllllllllllIlllIIlIIllIIllII, lIllllIlIlllIl[3])) {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findGetter(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIIl);
          "".length();
          if (-((0x12 ^ 0x4D) << " ".length() ^ (0x74 ^ 0x29) << " ".length()) >= 0)
            return null; 
        } else if (lllllllIIlIIIIl(lllllllllllllllIlllIIlIIllIIllII, lIllllIlIlllIl[4])) {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findStaticGetter(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIIl);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (lllllllIIlIIIIl(lllllllllllllllIlllIIlIIllIIllII, lIllllIlIlllIl[5])) {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findSetter(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIIl);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIIllIIllIl = lllllllllllllllIlllIIlIIllIIlIlI.findStaticSetter(lllllllllllllllIlllIIlIIllIIllll, lllllllllllllllIlllIIlIIllIIlllI, lllllllllllllllIlllIIlIIllIlIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIIllIIllIl);
    } catch (Exception lllllllllllllllIlllIIlIIllIIlIll) {
      lllllllllllllllIlllIIlIIllIIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIIIllIIl() {
    lIllllIlIllIIl = new String[lIllllIlIlllIl[5]];
    lIllllIlIllIIl[lIllllIlIlllIl[2]] = lIllllIlIllIll[lIllllIlIlllIl[5]];
    lIllllIlIllIIl[lIllllIlIlllIl[3]] = lIllllIlIllIll[lIllllIlIlllIl[6]];
    lIllllIlIllIIl[lIllllIlIlllIl[0]] = lIllllIlIllIll[lIllllIlIlllIl[7]];
    lIllllIlIllIIl[lIllllIlIlllIl[1]] = lIllllIlIllIll[lIllllIlIlllIl[8]];
    lIllllIlIllIIl[lIllllIlIlllIl[4]] = lIllllIlIllIll[lIllllIlIlllIl[9]];
    lIllllIlIllIlI = new Class[lIllllIlIlllIl[1]];
    lIllllIlIllIlI[lIllllIlIlllIl[0]] = f13.class;
  }
  
  private static void lllllllIIIlllIl() {
    lIllllIlIllIll = new String[lIllllIlIlllIl[10]];
    lIllllIlIllIll[lIllllIlIlllIl[0]] = lllllllIIIllIlI(lIllllIlIlllII[lIllllIlIlllIl[0]], lIllllIlIlllII[lIllllIlIlllIl[1]]);
    lIllllIlIllIll[lIllllIlIlllIl[1]] = lllllllIIIllIlI(lIllllIlIlllII[lIllllIlIlllIl[2]], lIllllIlIlllII[lIllllIlIlllIl[3]]);
    lIllllIlIllIll[lIllllIlIlllIl[2]] = lllllllIIIllIll(lIllllIlIlllII[lIllllIlIlllIl[4]], lIllllIlIlllII[lIllllIlIlllIl[5]]);
    lIllllIlIllIll[lIllllIlIlllIl[3]] = lllllllIIIllIll(lIllllIlIlllII[lIllllIlIlllIl[6]], lIllllIlIlllII[lIllllIlIlllIl[7]]);
    lIllllIlIllIll[lIllllIlIlllIl[4]] = lllllllIIIlllII(lIllllIlIlllII[lIllllIlIlllIl[8]], lIllllIlIlllII[lIllllIlIlllIl[9]]);
    lIllllIlIllIll[lIllllIlIlllIl[5]] = lllllllIIIlllII(lIllllIlIlllII[lIllllIlIlllIl[10]], lIllllIlIlllII[lIllllIlIlllIl[11]]);
    lIllllIlIllIll[lIllllIlIlllIl[6]] = lllllllIIIlllII(lIllllIlIlllII[lIllllIlIlllIl[12]], lIllllIlIlllII[lIllllIlIlllIl[13]]);
    lIllllIlIllIll[lIllllIlIlllIl[7]] = lllllllIIIllIlI(lIllllIlIlllII[lIllllIlIlllIl[14]], lIllllIlIlllII[lIllllIlIlllIl[15]]);
    lIllllIlIllIll[lIllllIlIlllIl[8]] = lllllllIIIllIll(lIllllIlIlllII[lIllllIlIlllIl[16]], lIllllIlIlllII[lIllllIlIlllIl[17]]);
    lIllllIlIllIll[lIllllIlIlllIl[9]] = lllllllIIIlllII("vRgLqpZQuxpPO3+PgWierMGj6ErX1mEJt8OWpqyIsEC9+X6DKowmTN6kldRMakJgdETsgFutpKJA9xhr7vhH6aCt2PnCGyX11VRLb7r6vXcB+jo7za+/Iw==", "hXvlM");
    lIllllIlIlllII = null;
  }
  
  private static void lllllllIIIllllI() {
    String str = (new Exception()).getStackTrace()[lIllllIlIlllIl[0]].getFileName();
    lIllllIlIlllII = str.substring(str.indexOf("ä") + lIllllIlIlllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIIIllIll(String lllllllllllllllIlllIIlIIllIIIllI, String lllllllllllllllIlllIIlIIllIIIlIl) {
    lllllllllllllllIlllIIlIIllIIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIllIIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIIllIIIlII = new StringBuilder();
    char[] lllllllllllllllIlllIIlIIllIIIIll = lllllllllllllllIlllIIlIIllIIIlIl.toCharArray();
    int lllllllllllllllIlllIIlIIllIIIIlI = lIllllIlIlllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIIllIIIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlIlllIl[0];
    while (lllllllIIlIIIlI(j, i)) {
      char lllllllllllllllIlllIIlIIllIIIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIIllIIIIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIIllIIIlII);
  }
  
  private static String lllllllIIIlllII(String lllllllllllllllIlllIIlIIlIlllllI, String lllllllllllllllIlllIIlIIlIllllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIllIIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIlIllllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIIllIIIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIIllIIIIII.init(lIllllIlIlllIl[2], lllllllllllllllIlllIIlIIllIIIIIl);
      return new String(lllllllllllllllIlllIIlIIllIIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIlIlllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIlIllllll) {
      lllllllllllllllIlllIIlIIlIllllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIIIllIlI(String lllllllllllllllIlllIIlIIlIlllIIl, String lllllllllllllllIlllIIlIIlIlllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIlIllllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIlIlllIII.getBytes(StandardCharsets.UTF_8)), lIllllIlIlllIl[8]), "DES");
      Cipher lllllllllllllllIlllIIlIIlIlllIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIIlIlllIll.init(lIllllIlIlllIl[2], lllllllllllllllIlllIIlIIlIllllII);
      return new String(lllllllllllllllIlllIIlIIlIlllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIlIlllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIlIlllIlI) {
      lllllllllllllllIlllIIlIIlIlllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIIIlllll() {
    lIllllIlIlllIl = new int[18];
    lIllllIlIlllIl[0] = (0xC9 ^ 0x9E) & (0xD7 ^ 0x80 ^ 0xFFFFFFFF);
    lIllllIlIlllIl[1] = " ".length();
    lIllllIlIlllIl[2] = " ".length() << " ".length();
    lIllllIlIlllIl[3] = "   ".length();
    lIllllIlIlllIl[4] = " ".length() << " ".length() << " ".length();
    lIllllIlIlllIl[5] = 83 + 116 - 119 + 79 ^ (0x35 ^ 0x78) << " ".length();
    lIllllIlIlllIl[6] = "   ".length() << " ".length();
    lIllllIlIlllIl[7] = 0x58 ^ 0x5F;
    lIllllIlIlllIl[8] = " ".length() << "   ".length();
    lIllllIlIlllIl[9] = 0x71 ^ 0x62 ^ (0xB4 ^ 0xB9) << " ".length();
    lIllllIlIlllIl[10] = (0xB7 ^ 0xB2) << " ".length();
    lIllllIlIlllIl[11] = 0x93 ^ 0x98;
    lIllllIlIlllIl[12] = "   ".length() << " ".length() << " ".length();
    lIllllIlIlllIl[13] = 0x86 ^ 0xC1 ^ (0x99 ^ 0xBC) << " ".length();
    lIllllIlIlllIl[14] = (0x90 ^ 0xAD ^ (0x38 ^ 0x25) << " ".length()) << " ".length();
    lIllllIlIlllIl[15] = 0x6F ^ 0x7A ^ (0x86 ^ 0x8B) << " ".length();
    lIllllIlIlllIl[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIlIlllIl[17] = (0x63 ^ 0x20) << " ".length() ^ 38 + 99 - 135 + 149;
  }
  
  private static boolean lllllllIIlIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIIlIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIIlIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ac.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */