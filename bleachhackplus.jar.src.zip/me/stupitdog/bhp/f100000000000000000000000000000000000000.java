package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.world.World;

public class f100000000000000000000000000000000000000 {
  public static Minecraft mc;
  
  private static String[] lIlllIIIIlIIll;
  
  private static Class[] lIlllIIIIlIlII;
  
  private static final String[] lIlllIIIIlllll;
  
  private static String[] lIlllIIIlIIIII;
  
  private static final int[] lIlllIIIlIIIIl;
  
  public static Minecraft getMinecraft() {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   5: areturn
  }
  
  public static EntityPlayerSP getPlayer() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: areturn
  }
  
  public static World getWorld() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 3 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: areturn
  }
  
  static {
    // Byte code:
    //   0: invokestatic llllIllllIIllII : ()V
    //   3: invokestatic llllIllllIIlIll : ()V
    //   6: invokestatic llllIllllIIlIlI : ()V
    //   9: invokestatic llllIllllIIIllI : ()V
    //   12: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   17: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)V
    //   22: return
  }
  
  private static CallSite llllIlllIllIIIl(MethodHandles.Lookup lllllllllllllllIlllIlllllllIlIlI, String lllllllllllllllIlllIlllllllIlIIl, MethodType lllllllllllllllIlllIlllllllIlIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllllllllIIII = lIlllIIIIlIIll[Integer.parseInt(lllllllllllllllIlllIlllllllIlIIl)].split(lIlllIIIIlllll[lIlllIIIlIIIIl[0]]);
      Class<?> lllllllllllllllIlllIlllllllIllll = Class.forName(lllllllllllllllIlllIllllllllIIII[lIlllIIIlIIIIl[0]]);
      String lllllllllllllllIlllIlllllllIlllI = lllllllllllllllIlllIllllllllIIII[lIlllIIIlIIIIl[1]];
      MethodHandle lllllllllllllllIlllIlllllllIllIl = null;
      int lllllllllllllllIlllIlllllllIllII = lllllllllllllllIlllIllllllllIIII[lIlllIIIlIIIIl[2]].length();
      if (llllIllllIIllIl(lllllllllllllllIlllIlllllllIllII, lIlllIIIlIIIIl[3])) {
        MethodType lllllllllllllllIlllIllllllllIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllllllllIIII[lIlllIIIlIIIIl[3]], f100000000000000000000000000000000000000.class.getClassLoader());
        if (llllIllllIIlllI(lllllllllllllllIlllIlllllllIllII, lIlllIIIlIIIIl[3])) {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findVirtual(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIlI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findStatic(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIlI);
        } 
        "".length();
        if (-"  ".length() >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllllllllIIIl = lIlllIIIIlIlII[Integer.parseInt(lllllllllllllllIlllIllllllllIIII[lIlllIIIlIIIIl[3]])];
        if (llllIllllIIlllI(lllllllllllllllIlllIlllllllIllII, lIlllIIIlIIIIl[2])) {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findGetter(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIIl);
          "".length();
          if (null != null)
            return null; 
        } else if (llllIllllIIlllI(lllllllllllllllIlllIlllllllIllII, lIlllIIIlIIIIl[4])) {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findStaticGetter(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIIl);
          "".length();
          if (" ".length() == (((0x61 ^ 0x2A) << " ".length() ^ 160 + 41 - 129 + 89) & (0x61 ^ 0x4 ^ (0xA ^ 0x23) << " ".length() ^ -" ".length())))
            return null; 
        } else if (llllIllllIIlllI(lllllllllllllllIlllIlllllllIllII, lIlllIIIlIIIIl[5])) {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findSetter(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIIl);
          "".length();
          if (-((0x6F ^ 0x20) << " ".length() ^ 125 + 109 - 193 + 114) >= 0)
            return null; 
        } else {
          lllllllllllllllIlllIlllllllIllIl = lllllllllllllllIlllIlllllllIlIlI.findStaticSetter(lllllllllllllllIlllIlllllllIllll, lllllllllllllllIlllIlllllllIlllI, lllllllllllllllIlllIllllllllIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlllllllIllIl);
    } catch (Exception lllllllllllllllIlllIlllllllIlIll) {
      lllllllllllllllIlllIlllllllIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllllIIIllI() {
    lIlllIIIIlIIll = new String[lIlllIIIlIIIIl[5]];
    lIlllIIIIlIIll[lIlllIIIlIIIIl[1]] = lIlllIIIIlllll[lIlllIIIlIIIIl[1]];
    lIlllIIIIlIIll[lIlllIIIlIIIIl[0]] = lIlllIIIIlllll[lIlllIIIlIIIIl[3]];
    lIlllIIIIlIIll[lIlllIIIlIIIIl[2]] = lIlllIIIIlllll[lIlllIIIlIIIIl[2]];
    lIlllIIIIlIIll[lIlllIIIlIIIIl[3]] = lIlllIIIIlllll[lIlllIIIlIIIIl[4]];
    lIlllIIIIlIIll[lIlllIIIlIIIIl[4]] = lIlllIIIIlllll[lIlllIIIlIIIIl[5]];
    lIlllIIIIlIlII = new Class[lIlllIIIlIIIIl[2]];
    lIlllIIIIlIlII[lIlllIIIlIIIIl[1]] = WorldClient.class;
    lIlllIIIIlIlII[lIlllIIIlIIIIl[0]] = EntityPlayerSP.class;
    lIlllIIIIlIlII[lIlllIIIlIIIIl[3]] = Minecraft.class;
  }
  
  private static void llllIllllIIlIlI() {
    lIlllIIIIlllll = new String[lIlllIIIlIIIIl[6]];
    lIlllIIIIlllll[lIlllIIIlIIIIl[0]] = llllIllllIIIlll(lIlllIIIlIIIII[lIlllIIIlIIIIl[0]], lIlllIIIlIIIII[lIlllIIIlIIIIl[1]]);
    lIlllIIIIlllll[lIlllIIIlIIIIl[1]] = llllIllllIIlIII(lIlllIIIlIIIII[lIlllIIIlIIIIl[3]], lIlllIIIlIIIII[lIlllIIIlIIIIl[2]]);
    lIlllIIIIlllll[lIlllIIIlIIIIl[3]] = llllIllllIIlIIl(lIlllIIIlIIIII[lIlllIIIlIIIIl[4]], lIlllIIIlIIIII[lIlllIIIlIIIIl[5]]);
    lIlllIIIIlllll[lIlllIIIlIIIIl[2]] = llllIllllIIlIIl(lIlllIIIlIIIII[lIlllIIIlIIIIl[6]], lIlllIIIlIIIII[lIlllIIIlIIIIl[7]]);
    lIlllIIIIlllll[lIlllIIIlIIIIl[4]] = llllIllllIIlIIl(lIlllIIIlIIIII[lIlllIIIlIIIIl[8]], lIlllIIIlIIIII[lIlllIIIlIIIIl[9]]);
    lIlllIIIIlllll[lIlllIIIlIIIIl[5]] = llllIllllIIlIIl("a2BtvX1oOSf0rxabeIf6Q2zTrpSsiPQ/Wq6WyrcVaV5arpbKtxVpXlqulsq3FWleWq6WyrcVaV79+OWq8r7ooP3MtmxBxzeS", "pNOIE");
    lIlllIIIlIIIII = null;
  }
  
  private static void llllIllllIIlIll() {
    String str = (new Exception()).getStackTrace()[lIlllIIIlIIIIl[0]].getFileName();
    lIlllIIIlIIIII = str.substring(str.indexOf("ä") + lIlllIIIlIIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllllIIlIII(String lllllllllllllllIlllIlllllllIIlII, String lllllllllllllllIlllIlllllllIIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllllllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllllllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllllllIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllllllIIllI.init(lIlllIIIlIIIIl[3], lllllllllllllllIlllIlllllllIIlll);
      return new String(lllllllllllllllIlllIlllllllIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllllllIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllllllIIlIl) {
      lllllllllllllllIlllIlllllllIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllllIIIlll(String lllllllllllllllIlllIlllllllIIIIl, String lllllllllllllllIlllIlllllllIIIII) {
    lllllllllllllllIlllIlllllllIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlllllllIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllllllIlllll = new StringBuilder();
    char[] lllllllllllllllIlllIllllllIllllI = lllllllllllllllIlllIlllllllIIIII.toCharArray();
    int lllllllllllllllIlllIllllllIlllIl = lIlllIIIlIIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlllllllIIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIIlIIIIl[0];
    while (llllIllllIIllll(j, i)) {
      char lllllllllllllllIlllIlllllllIIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllllllIlllIl++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllllllIlllll);
  }
  
  private static String llllIllllIIlIIl(String lllllllllllllllIlllIllllllIllIIl, String lllllllllllllllIlllIllllllIllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIllllllIlllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllllllIllIII.getBytes(StandardCharsets.UTF_8)), lIlllIIIlIIIIl[8]), "DES");
      Cipher lllllllllllllllIlllIllllllIllIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIllllllIllIll.init(lIlllIIIlIIIIl[3], lllllllllllllllIlllIllllllIlllII);
      return new String(lllllllllllllllIlllIllllllIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllllllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllllllIllIlI) {
      lllllllllllllllIlllIllllllIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllllIIllII() {
    lIlllIIIlIIIIl = new int[10];
    lIlllIIIlIIIIl[0] = (0x15 ^ 0x1C) << " ".length() << " ".length() & ((0x4A ^ 0x43) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIlllIIIlIIIIl[1] = " ".length();
    lIlllIIIlIIIIl[2] = "   ".length();
    lIlllIIIlIIIIl[3] = " ".length() << " ".length();
    lIlllIIIlIIIIl[4] = " ".length() << " ".length() << " ".length();
    lIlllIIIlIIIIl[5] = (0x17 ^ 0x30) << " ".length() << " ".length() ^ 92 + 105 - 113 + 69;
    lIlllIIIlIIIIl[6] = "   ".length() << " ".length();
    lIlllIIIlIIIIl[7] = 0xCF ^ 0xC6 ^ (0x79 ^ 0x7E) << " ".length();
    lIlllIIIlIIIIl[8] = " ".length() << "   ".length();
    lIlllIIIlIIIIl[9] = 0x6D ^ 0x64;
  }
  
  private static boolean llllIllllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIllllIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIllllIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */