package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class fn extends au {
  private BlockPos placeTarget;
  
  private BlockPos newTarget;
  
  private BlockPos sidePos;
  
  private EnumFacing sideFacing;
  
  private EntityPlayer closestTarget;
  
  private int pistonSlot;
  
  private int redstoneSlot;
  
  private float rotVar;
  
  private boolean isSneaking;
  
  private int stage;
  
  f100000000000000000000.Mode placeMode;
  
  f100000000000000000000.Mode placeType;
  
  f100000000000000000000.Mode prefType;
  
  f100000000000000000000.Boolean render;
  
  f100000000000000000000.ColorSetting color;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private static String[] lIlllIlIIIllIl;
  
  private static Class[] lIlllIlIIIlllI;
  
  private static final String[] lIllllIIIIIlIl;
  
  private static String[] lIllllIIIIlIll;
  
  private static final int[] lIllllIIIIllII;
  
  public fn() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   45: iconst_3
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/fn;I)V
    //   52: aload_0
    //   53: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   56: iconst_3
    //   57: iaload
    //   58: <illegal opcode> 2 : (Lme/stupitdog/bhp/fn;I)V
    //   63: aload_0
    //   64: new me/zero/alpine/listener/Listener
    //   67: dup
    //   68: aload_0
    //   69: <illegal opcode> invoke : (Lme/stupitdog/bhp/fn;)Lme/zero/alpine/listener/EventHook;
    //   74: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   77: iconst_0
    //   78: iaload
    //   79: anewarray java/util/function/Predicate
    //   82: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   85: <illegal opcode> 3 : (Lme/stupitdog/bhp/fn;Lme/zero/alpine/listener/Listener;)V
    //   90: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	91	0	lllllllllllllllIlllIIlllIlIIIIIl	Lme/stupitdog/bhp/fn;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   15: iconst_4
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   36: iconst_5
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: new java/util/ArrayList
    //   53: dup
    //   54: invokespecial <init> : ()V
    //   57: astore_2
    //   58: aload_2
    //   59: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   62: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   65: bipush #6
    //   67: iaload
    //   68: aaload
    //   69: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   74: ldc ''
    //   76: invokevirtual length : ()I
    //   79: pop2
    //   80: aload_2
    //   81: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   84: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   87: bipush #7
    //   89: iaload
    //   90: aaload
    //   91: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   96: ldc ''
    //   98: invokevirtual length : ()I
    //   101: pop2
    //   102: aload_2
    //   103: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   106: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   109: bipush #8
    //   111: iaload
    //   112: aaload
    //   113: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   118: ldc ''
    //   120: invokevirtual length : ()I
    //   123: pop2
    //   124: new java/util/ArrayList
    //   127: dup
    //   128: invokespecial <init> : ()V
    //   131: astore_3
    //   132: aload_3
    //   133: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   136: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   139: bipush #9
    //   141: iaload
    //   142: aaload
    //   143: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   148: ldc ''
    //   150: invokevirtual length : ()I
    //   153: pop2
    //   154: aload_3
    //   155: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   158: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   161: bipush #10
    //   163: iaload
    //   164: aaload
    //   165: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   170: ldc ''
    //   172: invokevirtual length : ()I
    //   175: pop2
    //   176: aload_0
    //   177: aload_0
    //   178: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   181: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   184: bipush #11
    //   186: iaload
    //   187: aaload
    //   188: aload_1
    //   189: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   192: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   195: bipush #12
    //   197: iaload
    //   198: aaload
    //   199: <illegal opcode> 5 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   204: <illegal opcode> 6 : (Lme/stupitdog/bhp/fn;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   209: aload_0
    //   210: aload_0
    //   211: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   214: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   217: bipush #13
    //   219: iaload
    //   220: aaload
    //   221: aload_2
    //   222: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   225: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   228: bipush #14
    //   230: iaload
    //   231: aaload
    //   232: <illegal opcode> 5 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   237: <illegal opcode> 7 : (Lme/stupitdog/bhp/fn;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   242: aload_0
    //   243: aload_0
    //   244: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   247: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   250: bipush #15
    //   252: iaload
    //   253: aaload
    //   254: aload_3
    //   255: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   258: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   261: bipush #16
    //   263: iaload
    //   264: aaload
    //   265: <illegal opcode> 5 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   270: <illegal opcode> 8 : (Lme/stupitdog/bhp/fn;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   275: aload_0
    //   276: aload_0
    //   277: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   280: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   283: bipush #17
    //   285: iaload
    //   286: aaload
    //   287: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   290: iconst_1
    //   291: iaload
    //   292: <illegal opcode> 9 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   297: <illegal opcode> 10 : (Lme/stupitdog/bhp/fn;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   302: aload_0
    //   303: aload_0
    //   304: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   307: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   310: bipush #18
    //   312: iaload
    //   313: aaload
    //   314: new me/stupitdog/bhp/f01
    //   317: dup
    //   318: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   321: bipush #19
    //   323: iaload
    //   324: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   327: bipush #19
    //   329: iaload
    //   330: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   333: bipush #19
    //   335: iaload
    //   336: invokespecial <init> : (III)V
    //   339: <illegal opcode> 11 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   344: <illegal opcode> 12 : (Lme/stupitdog/bhp/fn;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   349: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	350	0	lllllllllllllllIlllIIlllIlIIIIII	Lme/stupitdog/bhp/fn;
    //   8	342	1	lllllllllllllllIlllIIlllIIllllll	Ljava/util/ArrayList;
    //   58	292	2	lllllllllllllllIlllIIlllIIlllllI	Ljava/util/ArrayList;
    //   132	218	3	lllllllllllllllIlllIIlllIIllllIl	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	342	1	lllllllllllllllIlllIIlllIIllllll	Ljava/util/ArrayList<Ljava/lang/String;>;
    //   58	292	2	lllllllllllllllIlllIIlllIIlllllI	Ljava/util/ArrayList<Ljava/lang/String;>;
    //   132	218	3	lllllllllllllllIlllIIlllIIllllIl	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 13 : (Lme/stupitdog/bhp/fn;I)V
    //   11: aload_0
    //   12: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   15: iconst_3
    //   16: iaload
    //   17: <illegal opcode> 1 : (Lme/stupitdog/bhp/fn;I)V
    //   22: aload_0
    //   23: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   26: iconst_3
    //   27: iaload
    //   28: <illegal opcode> 2 : (Lme/stupitdog/bhp/fn;I)V
    //   33: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: istore_1
    //   39: iload_1
    //   40: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   43: bipush #10
    //   45: iaload
    //   46: invokestatic llllllIIlIIllll : (II)Z
    //   49: ifeq -> 286
    //   52: aload_0
    //   53: <illegal opcode> 14 : (Lme/stupitdog/bhp/fn;)I
    //   58: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   61: iconst_3
    //   62: iaload
    //   63: invokestatic llllllIIlIlIIII : (II)Z
    //   66: ifeq -> 113
    //   69: aload_0
    //   70: <illegal opcode> 15 : (Lme/stupitdog/bhp/fn;)I
    //   75: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   78: iconst_3
    //   79: iaload
    //   80: invokestatic llllllIIlIlIIII : (II)Z
    //   83: ifeq -> 113
    //   86: ldc ''
    //   88: invokevirtual length : ()I
    //   91: pop
    //   92: ldc ' '
    //   94: invokevirtual length : ()I
    //   97: ldc ' '
    //   99: invokevirtual length : ()I
    //   102: ishl
    //   103: ldc ' '
    //   105: invokevirtual length : ()I
    //   108: ineg
    //   109: if_icmpgt -> 286
    //   112: return
    //   113: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   118: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   123: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   128: iload_1
    //   129: <illegal opcode> 19 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   134: astore_2
    //   135: aload_2
    //   136: <illegal opcode> 20 : ()Lnet/minecraft/item/ItemStack;
    //   141: invokestatic llllllIIlIlIIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   144: ifeq -> 263
    //   147: aload_2
    //   148: <illegal opcode> 21 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   153: instanceof net/minecraft/item/ItemBlock
    //   156: invokestatic llllllIIlIlIIlI : (I)Z
    //   159: ifeq -> 189
    //   162: ldc ''
    //   164: invokevirtual length : ()I
    //   167: pop
    //   168: ldc ' '
    //   170: invokevirtual length : ()I
    //   173: ldc ' '
    //   175: invokevirtual length : ()I
    //   178: ldc ' '
    //   180: invokevirtual length : ()I
    //   183: ishl
    //   184: ishl
    //   185: ifgt -> 263
    //   188: return
    //   189: aload_2
    //   190: <illegal opcode> 21 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   195: checkcast net/minecraft/item/ItemBlock
    //   198: <illegal opcode> 22 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   203: astore_3
    //   204: aload_3
    //   205: <illegal opcode> 23 : ()Lnet/minecraft/block/BlockPistonBase;
    //   210: invokestatic llllllIIlIlIIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   213: ifeq -> 244
    //   216: aload_0
    //   217: iload_1
    //   218: <illegal opcode> 1 : (Lme/stupitdog/bhp/fn;I)V
    //   223: ldc ''
    //   225: invokevirtual length : ()I
    //   228: pop
    //   229: ldc '   '
    //   231: invokevirtual length : ()I
    //   234: ldc ' '
    //   236: invokevirtual length : ()I
    //   239: ineg
    //   240: if_icmpge -> 263
    //   243: return
    //   244: aload_3
    //   245: <illegal opcode> 24 : ()Lnet/minecraft/block/Block;
    //   250: invokestatic llllllIIlIlIIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   253: ifeq -> 263
    //   256: aload_0
    //   257: iload_1
    //   258: <illegal opcode> 2 : (Lme/stupitdog/bhp/fn;I)V
    //   263: iinc #1, 1
    //   266: ldc ''
    //   268: invokevirtual length : ()I
    //   271: pop
    //   272: ldc '   '
    //   274: invokevirtual length : ()I
    //   277: ldc '   '
    //   279: invokevirtual length : ()I
    //   282: if_icmpeq -> 39
    //   285: return
    //   286: aload_0
    //   287: <illegal opcode> 14 : (Lme/stupitdog/bhp/fn;)I
    //   292: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   295: iconst_3
    //   296: iaload
    //   297: invokestatic llllllIIlIlIlII : (II)Z
    //   300: ifeq -> 325
    //   303: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   306: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   309: bipush #20
    //   311: iaload
    //   312: aaload
    //   313: <illegal opcode> 25 : (Ljava/lang/String;)V
    //   318: aload_0
    //   319: <illegal opcode> 26 : (Lme/stupitdog/bhp/fn;)V
    //   324: return
    //   325: aload_0
    //   326: <illegal opcode> 15 : (Lme/stupitdog/bhp/fn;)I
    //   331: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   334: iconst_3
    //   335: iaload
    //   336: invokestatic llllllIIlIlIlII : (II)Z
    //   339: ifeq -> 364
    //   342: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   345: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   348: bipush #21
    //   350: iaload
    //   351: aaload
    //   352: <illegal opcode> 25 : (Ljava/lang/String;)V
    //   357: aload_0
    //   358: <illegal opcode> 26 : (Lme/stupitdog/bhp/fn;)V
    //   363: return
    //   364: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   369: <illegal opcode> 27 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   374: invokestatic llllllIIlIlIlIl : (Ljava/lang/Object;)Z
    //   377: ifeq -> 427
    //   380: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   385: <illegal opcode> 27 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   390: <illegal opcode> 28 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   395: invokestatic llllllIIlIlIlIl : (Ljava/lang/Object;)Z
    //   398: ifeq -> 427
    //   401: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   406: <illegal opcode> 27 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   411: <illegal opcode> 28 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   416: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   421: invokestatic llllllIIlIlIllI : (Ljava/lang/Object;)Z
    //   424: ifeq -> 449
    //   427: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   430: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   433: bipush #22
    //   435: iaload
    //   436: aaload
    //   437: <illegal opcode> 25 : (Ljava/lang/String;)V
    //   442: aload_0
    //   443: <illegal opcode> 26 : (Lme/stupitdog/bhp/fn;)V
    //   448: return
    //   449: aload_0
    //   450: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   455: <illegal opcode> 27 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   460: <illegal opcode> 28 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   465: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   470: <illegal opcode> 30 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   475: aload_0
    //   476: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   479: iconst_1
    //   480: iaload
    //   481: <illegal opcode> 13 : (Lme/stupitdog/bhp/fn;I)V
    //   486: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   135	128	2	lllllllllllllllIlllIIlllIIllllII	Lnet/minecraft/item/ItemStack;
    //   204	59	3	lllllllllllllllIlllIIlllIIlllIll	Lnet/minecraft/block/Block;
    //   39	247	1	lllllllllllllllIlllIIlllIIlllIlI	I
    //   0	487	0	lllllllllllllllIlllIIlllIIlllIIl	Lme/stupitdog/bhp/fn;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 31 : (Lme/stupitdog/bhp/fn;)I
    //   6: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   9: iconst_1
    //   10: iaload
    //   11: invokestatic llllllIIlIlIlII : (II)Z
    //   14: ifeq -> 1290
    //   17: aload_0
    //   18: invokespecial findClosestTarget : ()V
    //   21: aload_0
    //   22: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   27: invokestatic llllllIIlIlIlIl : (Ljava/lang/Object;)Z
    //   30: ifeq -> 1290
    //   33: aload_0
    //   34: aload_0
    //   35: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   40: <illegal opcode> 33 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   45: <illegal opcode> 34 : (Lme/stupitdog/bhp/fn;Ljava/lang/String;)V
    //   50: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   53: iconst_0
    //   54: iaload
    //   55: istore_1
    //   56: new net/minecraft/util/math/BlockPos
    //   59: dup
    //   60: aload_0
    //   61: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   66: <illegal opcode> 35 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   71: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   74: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   77: iconst_1
    //   78: iaload
    //   79: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   82: iconst_1
    //   83: iaload
    //   84: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   87: iconst_0
    //   88: iaload
    //   89: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   94: astore_2
    //   95: aload_0
    //   96: aload_2
    //   97: aload_0
    //   98: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   103: <illegal opcode> 38 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Z
    //   108: invokestatic llllllIIlIlIlll : (I)Z
    //   111: ifeq -> 186
    //   114: iload_1
    //   115: invokestatic llllllIIlIlIIlI : (I)Z
    //   118: ifeq -> 186
    //   121: aload_0
    //   122: ldc_w -90.0
    //   125: <illegal opcode> 39 : (Lme/stupitdog/bhp/fn;F)V
    //   130: aload_0
    //   131: aload_0
    //   132: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   137: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   140: iconst_1
    //   141: iaload
    //   142: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   145: iconst_0
    //   146: iaload
    //   147: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   150: iconst_0
    //   151: iaload
    //   152: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   157: <illegal opcode> 40 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   162: aload_0
    //   163: <illegal opcode> 41 : ()Lnet/minecraft/util/EnumFacing;
    //   168: <illegal opcode> 42 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/EnumFacing;)V
    //   173: aload_0
    //   174: aload_2
    //   175: <illegal opcode> 43 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   180: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   183: iconst_1
    //   184: iaload
    //   185: istore_1
    //   186: new net/minecraft/util/math/BlockPos
    //   189: dup
    //   190: aload_0
    //   191: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   196: <illegal opcode> 35 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   201: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   204: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   207: iconst_3
    //   208: iaload
    //   209: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   212: iconst_1
    //   213: iaload
    //   214: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   217: iconst_0
    //   218: iaload
    //   219: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   224: astore_2
    //   225: aload_0
    //   226: aload_2
    //   227: aload_0
    //   228: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   233: <illegal opcode> 38 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Z
    //   238: invokestatic llllllIIlIlIlll : (I)Z
    //   241: ifeq -> 316
    //   244: iload_1
    //   245: invokestatic llllllIIlIlIIlI : (I)Z
    //   248: ifeq -> 316
    //   251: aload_0
    //   252: ldc_w 90.0
    //   255: <illegal opcode> 39 : (Lme/stupitdog/bhp/fn;F)V
    //   260: aload_0
    //   261: aload_0
    //   262: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   267: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   270: iconst_3
    //   271: iaload
    //   272: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   275: iconst_0
    //   276: iaload
    //   277: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   280: iconst_0
    //   281: iaload
    //   282: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   287: <illegal opcode> 40 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   292: aload_0
    //   293: <illegal opcode> 44 : ()Lnet/minecraft/util/EnumFacing;
    //   298: <illegal opcode> 42 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/EnumFacing;)V
    //   303: aload_0
    //   304: aload_2
    //   305: <illegal opcode> 43 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   310: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   313: iconst_1
    //   314: iaload
    //   315: istore_1
    //   316: new net/minecraft/util/math/BlockPos
    //   319: dup
    //   320: aload_0
    //   321: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   326: <illegal opcode> 35 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   331: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   334: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   337: iconst_0
    //   338: iaload
    //   339: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   342: iconst_1
    //   343: iaload
    //   344: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   347: iconst_1
    //   348: iaload
    //   349: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   354: astore_2
    //   355: aload_0
    //   356: aload_2
    //   357: aload_0
    //   358: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   363: <illegal opcode> 38 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Z
    //   368: invokestatic llllllIIlIlIlll : (I)Z
    //   371: ifeq -> 444
    //   374: iload_1
    //   375: invokestatic llllllIIlIlIIlI : (I)Z
    //   378: ifeq -> 444
    //   381: aload_0
    //   382: fconst_0
    //   383: <illegal opcode> 39 : (Lme/stupitdog/bhp/fn;F)V
    //   388: aload_0
    //   389: aload_0
    //   390: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   395: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   398: iconst_0
    //   399: iaload
    //   400: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   403: iconst_0
    //   404: iaload
    //   405: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   408: iconst_1
    //   409: iaload
    //   410: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   415: <illegal opcode> 40 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   420: aload_0
    //   421: <illegal opcode> 45 : ()Lnet/minecraft/util/EnumFacing;
    //   426: <illegal opcode> 42 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/EnumFacing;)V
    //   431: aload_0
    //   432: aload_2
    //   433: <illegal opcode> 43 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   438: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   441: iconst_1
    //   442: iaload
    //   443: istore_1
    //   444: new net/minecraft/util/math/BlockPos
    //   447: dup
    //   448: aload_0
    //   449: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   454: <illegal opcode> 35 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   459: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   462: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   465: iconst_0
    //   466: iaload
    //   467: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   470: iconst_1
    //   471: iaload
    //   472: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   475: iconst_3
    //   476: iaload
    //   477: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   482: astore_2
    //   483: aload_0
    //   484: aload_2
    //   485: aload_0
    //   486: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   491: <illegal opcode> 38 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Z
    //   496: invokestatic llllllIIlIlIlll : (I)Z
    //   499: ifeq -> 574
    //   502: iload_1
    //   503: invokestatic llllllIIlIlIIlI : (I)Z
    //   506: ifeq -> 574
    //   509: aload_0
    //   510: ldc_w 180.0
    //   513: <illegal opcode> 39 : (Lme/stupitdog/bhp/fn;F)V
    //   518: aload_0
    //   519: aload_0
    //   520: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   525: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   528: iconst_0
    //   529: iaload
    //   530: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   533: iconst_0
    //   534: iaload
    //   535: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   538: iconst_3
    //   539: iaload
    //   540: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   545: <illegal opcode> 40 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   550: aload_0
    //   551: <illegal opcode> 46 : ()Lnet/minecraft/util/EnumFacing;
    //   556: <illegal opcode> 42 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/EnumFacing;)V
    //   561: aload_0
    //   562: aload_2
    //   563: <illegal opcode> 43 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/util/math/BlockPos;)V
    //   568: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   571: iconst_1
    //   572: iaload
    //   573: istore_1
    //   574: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   579: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   584: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   589: aload_0
    //   590: <illegal opcode> 15 : (Lme/stupitdog/bhp/fn;)I
    //   595: putfield field_70461_c : I
    //   598: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   603: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   608: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   613: new net/minecraft/network/play/client/CPacketEntityAction
    //   616: dup
    //   617: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   622: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   627: <illegal opcode> 48 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   632: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   635: <illegal opcode> 49 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   640: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   645: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   650: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   655: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   658: dup
    //   659: aload_0
    //   660: <illegal opcode> 50 : (Lme/stupitdog/bhp/fn;)F
    //   665: fconst_0
    //   666: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   671: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   676: <illegal opcode> 51 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   681: invokespecial <init> : (FFZ)V
    //   684: <illegal opcode> 49 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   689: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   692: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   695: bipush #23
    //   697: iaload
    //   698: aaload
    //   699: <illegal opcode> 25 : (Ljava/lang/String;)V
    //   704: aload_0
    //   705: new net/minecraft/util/math/BlockPos
    //   708: dup
    //   709: aload_0
    //   710: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   715: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   718: <illegal opcode> 52 : ()Lnet/minecraft/util/EnumFacing;
    //   723: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   726: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   731: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   736: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   741: new net/minecraft/network/play/client/CPacketEntityAction
    //   744: dup
    //   745: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   750: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   755: <illegal opcode> 53 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   760: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   763: <illegal opcode> 49 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   768: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   771: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   774: bipush #24
    //   776: iaload
    //   777: aaload
    //   778: <illegal opcode> 25 : (Ljava/lang/String;)V
    //   783: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   788: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   793: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   798: aload_0
    //   799: <illegal opcode> 14 : (Lme/stupitdog/bhp/fn;)I
    //   804: putfield field_70461_c : I
    //   807: aload_0
    //   808: <illegal opcode> 54 : (Lme/stupitdog/bhp/fn;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   813: <illegal opcode> 55 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   818: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   821: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   824: bipush #25
    //   826: iaload
    //   827: aaload
    //   828: <illegal opcode> 56 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   833: invokestatic llllllIIlIlIlll : (I)Z
    //   836: ifeq -> 881
    //   839: aload_0
    //   840: new net/minecraft/util/math/BlockPos
    //   843: dup
    //   844: aload_0
    //   845: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   850: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   853: iconst_0
    //   854: iaload
    //   855: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   858: iconst_1
    //   859: iaload
    //   860: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   863: iconst_0
    //   864: iaload
    //   865: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   870: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   873: <illegal opcode> 52 : ()Lnet/minecraft/util/EnumFacing;
    //   878: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   881: aload_0
    //   882: <illegal opcode> 54 : (Lme/stupitdog/bhp/fn;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   887: <illegal opcode> 55 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   892: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   895: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   898: bipush #26
    //   900: iaload
    //   901: aaload
    //   902: <illegal opcode> 56 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   907: invokestatic llllllIIlIlIlll : (I)Z
    //   910: ifeq -> 936
    //   913: aload_0
    //   914: new net/minecraft/util/math/BlockPos
    //   917: dup
    //   918: aload_0
    //   919: <illegal opcode> 57 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   924: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   927: aload_0
    //   928: <illegal opcode> 58 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/EnumFacing;
    //   933: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   936: aload_0
    //   937: <illegal opcode> 54 : (Lme/stupitdog/bhp/fn;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   942: <illegal opcode> 55 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   947: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   950: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   953: bipush #27
    //   955: iaload
    //   956: aaload
    //   957: <illegal opcode> 56 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   962: invokestatic llllllIIlIlIlll : (I)Z
    //   965: ifeq -> 1279
    //   968: aload_0
    //   969: <illegal opcode> 59 : (Lme/stupitdog/bhp/fn;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   974: <illegal opcode> 55 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   979: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   982: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   985: bipush #28
    //   987: iaload
    //   988: aaload
    //   989: <illegal opcode> 56 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   994: invokestatic llllllIIlIlIlll : (I)Z
    //   997: ifeq -> 1166
    //   1000: aload_0
    //   1001: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1006: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1009: iconst_0
    //   1010: iaload
    //   1011: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1014: iconst_1
    //   1015: iaload
    //   1016: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1019: iconst_0
    //   1020: iaload
    //   1021: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   1026: <illegal opcode> 60 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   1031: invokestatic llllllIIlIlIlll : (I)Z
    //   1034: ifeq -> 1122
    //   1037: aload_0
    //   1038: aload_0
    //   1039: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1044: invokespecial intersectsWithEntity : (Lnet/minecraft/util/math/BlockPos;)Z
    //   1047: invokestatic llllllIIlIlIIlI : (I)Z
    //   1050: ifeq -> 1122
    //   1053: aload_0
    //   1054: new net/minecraft/util/math/BlockPos
    //   1057: dup
    //   1058: aload_0
    //   1059: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1064: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1067: iconst_0
    //   1068: iaload
    //   1069: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1072: iconst_1
    //   1073: iaload
    //   1074: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1077: iconst_0
    //   1078: iaload
    //   1079: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   1084: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   1087: <illegal opcode> 52 : ()Lnet/minecraft/util/EnumFacing;
    //   1092: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   1095: ldc ''
    //   1097: invokevirtual length : ()I
    //   1100: pop
    //   1101: sipush #172
    //   1104: sipush #151
    //   1107: ixor
    //   1108: sipush #130
    //   1111: sipush #185
    //   1114: ixor
    //   1115: iconst_m1
    //   1116: ixor
    //   1117: iand
    //   1118: ifeq -> 1279
    //   1121: return
    //   1122: aload_0
    //   1123: new net/minecraft/util/math/BlockPos
    //   1126: dup
    //   1127: aload_0
    //   1128: <illegal opcode> 57 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1133: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   1136: aload_0
    //   1137: <illegal opcode> 58 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/EnumFacing;
    //   1142: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   1145: ldc ''
    //   1147: invokevirtual length : ()I
    //   1150: pop
    //   1151: ldc ' '
    //   1153: invokevirtual length : ()I
    //   1156: ldc ' '
    //   1158: invokevirtual length : ()I
    //   1161: ishl
    //   1162: ifge -> 1279
    //   1165: return
    //   1166: aload_0
    //   1167: <illegal opcode> 57 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1172: <illegal opcode> 60 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   1177: invokestatic llllllIIlIlIlll : (I)Z
    //   1180: ifeq -> 1237
    //   1183: aload_0
    //   1184: aload_0
    //   1185: <illegal opcode> 57 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1190: invokespecial intersectsWithEntity : (Lnet/minecraft/util/math/BlockPos;)Z
    //   1193: invokestatic llllllIIlIlIIlI : (I)Z
    //   1196: ifeq -> 1237
    //   1199: aload_0
    //   1200: new net/minecraft/util/math/BlockPos
    //   1203: dup
    //   1204: aload_0
    //   1205: <illegal opcode> 57 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1210: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   1213: aload_0
    //   1214: <illegal opcode> 58 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/EnumFacing;
    //   1219: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   1222: ldc ''
    //   1224: invokevirtual length : ()I
    //   1227: pop
    //   1228: bipush #83
    //   1230: bipush #86
    //   1232: ixor
    //   1233: ifne -> 1279
    //   1236: return
    //   1237: aload_0
    //   1238: new net/minecraft/util/math/BlockPos
    //   1241: dup
    //   1242: aload_0
    //   1243: <illegal opcode> 37 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/util/math/BlockPos;
    //   1248: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1251: iconst_0
    //   1252: iaload
    //   1253: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1256: iconst_1
    //   1257: iaload
    //   1258: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1261: iconst_0
    //   1262: iaload
    //   1263: <illegal opcode> 36 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   1268: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   1271: <illegal opcode> 52 : ()Lnet/minecraft/util/EnumFacing;
    //   1276: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   1279: aload_0
    //   1280: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   1283: iconst_2
    //   1284: iaload
    //   1285: <illegal opcode> 13 : (Lme/stupitdog/bhp/fn;I)V
    //   1290: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   56	1234	1	lllllllllllllllIlllIIlllIIlllIII	Z
    //   95	1195	2	lllllllllllllllIlllIIlllIIllIlll	Lnet/minecraft/util/math/BlockPos;
    //   0	1291	0	lllllllllllllllIlllIIlllIIllIllI	Lme/stupitdog/bhp/fn;
  }
  
  private void placeBlock(BlockPos lllllllllllllllIlllIIlllIIllIIIl, EnumFacing lllllllllllllllIlllIIlllIIllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 61 : (Lme/stupitdog/bhp/fn;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 55 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: getstatic me/stupitdog/bhp/fn.lIllllIIIIIlIl : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   17: bipush #29
    //   19: iaload
    //   20: aaload
    //   21: <illegal opcode> 56 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   26: invokestatic llllllIIlIlIlll : (I)Z
    //   29: ifeq -> 54
    //   32: aload_1
    //   33: <illegal opcode> 62 : (Lnet/minecraft/util/math/BlockPos;)V
    //   38: ldc ''
    //   40: invokevirtual length : ()I
    //   43: pop
    //   44: ldc '   '
    //   46: invokevirtual length : ()I
    //   49: ineg
    //   50: ifle -> 257
    //   53: return
    //   54: aload_1
    //   55: aload_2
    //   56: <illegal opcode> 63 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   61: astore_3
    //   62: aload_2
    //   63: <illegal opcode> 64 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   68: astore #4
    //   70: aload_0
    //   71: <illegal opcode> 65 : (Lme/stupitdog/bhp/fn;)Z
    //   76: invokestatic llllllIIlIlIIlI : (I)Z
    //   79: ifeq -> 135
    //   82: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   87: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   92: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   97: new net/minecraft/network/play/client/CPacketEntityAction
    //   100: dup
    //   101: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   106: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   111: <illegal opcode> 48 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   116: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   119: <illegal opcode> 49 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   124: aload_0
    //   125: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   128: iconst_1
    //   129: iaload
    //   130: <illegal opcode> 66 : (Lme/stupitdog/bhp/fn;Z)V
    //   135: new net/minecraft/util/math/Vec3d
    //   138: dup
    //   139: aload_3
    //   140: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   143: ldc2_w 0.5
    //   146: ldc2_w 0.5
    //   149: ldc2_w 0.5
    //   152: <illegal opcode> 67 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   157: new net/minecraft/util/math/Vec3d
    //   160: dup
    //   161: aload #4
    //   163: <illegal opcode> 68 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   168: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   171: ldc2_w 0.5
    //   174: <illegal opcode> 69 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   179: <illegal opcode> 70 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   184: astore #5
    //   186: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   191: <illegal opcode> 71 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   196: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   201: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   206: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   211: <illegal opcode> 72 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   216: aload_3
    //   217: aload #4
    //   219: aload #5
    //   221: <illegal opcode> 73 : ()Lnet/minecraft/util/EnumHand;
    //   226: <illegal opcode> 74 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   231: ldc ''
    //   233: invokevirtual length : ()I
    //   236: pop2
    //   237: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   242: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   247: <illegal opcode> 73 : ()Lnet/minecraft/util/EnumHand;
    //   252: <illegal opcode> 75 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   257: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   62	195	3	lllllllllllllllIlllIIlllIIllIlIl	Lnet/minecraft/util/math/BlockPos;
    //   70	187	4	lllllllllllllllIlllIIlllIIllIlII	Lnet/minecraft/util/EnumFacing;
    //   186	71	5	lllllllllllllllIlllIIlllIIllIIll	Lnet/minecraft/util/math/Vec3d;
    //   0	258	0	lllllllllllllllIlllIIlllIIllIIlI	Lme/stupitdog/bhp/fn;
    //   0	258	1	lllllllllllllllIlllIIlllIIllIIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	258	2	lllllllllllllllIlllIIlllIIllIIII	Lnet/minecraft/util/EnumFacing;
  }
  
  private void findClosestTarget() {
    // Byte code:
    //   0: <illegal opcode> 76 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 72 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 77 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: astore_1
    //   16: aload_0
    //   17: aconst_null
    //   18: <illegal opcode> 78 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   23: aload_1
    //   24: <illegal opcode> 79 : (Ljava/util/List;)Ljava/util/Iterator;
    //   29: astore_2
    //   30: aload_2
    //   31: <illegal opcode> 80 : (Ljava/util/Iterator;)Z
    //   36: invokestatic llllllIIlIlIlll : (I)Z
    //   39: ifeq -> 415
    //   42: aload_2
    //   43: <illegal opcode> 81 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   48: checkcast net/minecraft/entity/player/EntityPlayer
    //   51: astore_3
    //   52: aload_3
    //   53: <illegal opcode> 76 : ()Lnet/minecraft/client/Minecraft;
    //   58: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   63: invokestatic llllllIIlIlIIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   66: ifeq -> 89
    //   69: ldc ''
    //   71: invokevirtual length : ()I
    //   74: pop
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ldc '   '
    //   82: invokevirtual length : ()I
    //   85: if_icmpne -> 30
    //   88: return
    //   89: aload_3
    //   90: <illegal opcode> 82 : (Lnet/minecraft/entity/Entity;)Z
    //   95: invokestatic llllllIIlIlIIlI : (I)Z
    //   98: ifeq -> 145
    //   101: ldc ''
    //   103: invokevirtual length : ()I
    //   106: pop
    //   107: ldc ' '
    //   109: invokevirtual length : ()I
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ldc ' '
    //   119: invokevirtual length : ()I
    //   122: ishl
    //   123: ishl
    //   124: ldc ' '
    //   126: invokevirtual length : ()I
    //   129: ldc ' '
    //   131: invokevirtual length : ()I
    //   134: ldc ' '
    //   136: invokevirtual length : ()I
    //   139: ishl
    //   140: ishl
    //   141: if_icmpge -> 30
    //   144: return
    //   145: aload_3
    //   146: <illegal opcode> 83 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   151: fconst_0
    //   152: invokestatic llllllIIlIllIII : (FF)I
    //   155: invokestatic llllllIIlIllIlI : (I)Z
    //   158: ifeq -> 181
    //   161: ldc ''
    //   163: invokevirtual length : ()I
    //   166: pop
    //   167: ldc ' '
    //   169: invokevirtual length : ()I
    //   172: ldc '   '
    //   174: invokevirtual length : ()I
    //   177: if_icmple -> 30
    //   180: return
    //   181: aload_0
    //   182: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   187: invokestatic llllllIIlIlIllI : (Ljava/lang/Object;)Z
    //   190: ifeq -> 257
    //   193: aload_0
    //   194: aload_3
    //   195: <illegal opcode> 78 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   200: ldc ''
    //   202: invokevirtual length : ()I
    //   205: pop
    //   206: ldc ' '
    //   208: invokevirtual length : ()I
    //   211: ldc ' '
    //   213: invokevirtual length : ()I
    //   216: ishl
    //   217: bipush #21
    //   219: iconst_2
    //   220: ixor
    //   221: ldc ' '
    //   223: invokevirtual length : ()I
    //   226: ldc ' '
    //   228: invokevirtual length : ()I
    //   231: ishl
    //   232: ishl
    //   233: bipush #120
    //   235: bipush #111
    //   237: ixor
    //   238: ldc ' '
    //   240: invokevirtual length : ()I
    //   243: ldc ' '
    //   245: invokevirtual length : ()I
    //   248: ishl
    //   249: ishl
    //   250: iconst_m1
    //   251: ixor
    //   252: iand
    //   253: if_icmpgt -> 388
    //   256: return
    //   257: <illegal opcode> 76 : ()Lnet/minecraft/client/Minecraft;
    //   262: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   267: aload_3
    //   268: <illegal opcode> 84 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;)F
    //   273: <illegal opcode> 76 : ()Lnet/minecraft/client/Minecraft;
    //   278: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   283: aload_0
    //   284: <illegal opcode> 32 : (Lme/stupitdog/bhp/fn;)Lnet/minecraft/entity/player/EntityPlayer;
    //   289: <illegal opcode> 84 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;)F
    //   294: invokestatic llllllIIlIllIIl : (FF)I
    //   297: invokestatic llllllIIlIllIll : (I)Z
    //   300: ifeq -> 381
    //   303: ldc ''
    //   305: invokevirtual length : ()I
    //   308: pop
    //   309: bipush #42
    //   311: bipush #125
    //   313: ixor
    //   314: ldc ' '
    //   316: invokevirtual length : ()I
    //   319: ishl
    //   320: bipush #65
    //   322: bipush #99
    //   324: iadd
    //   325: bipush #62
    //   327: isub
    //   328: bipush #27
    //   330: iadd
    //   331: ixor
    //   332: ldc ' '
    //   334: invokevirtual length : ()I
    //   337: ishl
    //   338: bipush #17
    //   340: bipush #71
    //   342: iadd
    //   343: bipush #9
    //   345: isub
    //   346: bipush #62
    //   348: iadd
    //   349: sipush #216
    //   352: sipush #137
    //   355: ixor
    //   356: ldc ' '
    //   358: invokevirtual length : ()I
    //   361: ishl
    //   362: ixor
    //   363: ldc ' '
    //   365: invokevirtual length : ()I
    //   368: ishl
    //   369: ldc ' '
    //   371: invokevirtual length : ()I
    //   374: ineg
    //   375: ixor
    //   376: iand
    //   377: ifle -> 30
    //   380: return
    //   381: aload_0
    //   382: aload_3
    //   383: <illegal opcode> 78 : (Lme/stupitdog/bhp/fn;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   388: ldc ''
    //   390: invokevirtual length : ()I
    //   393: pop
    //   394: sipush #158
    //   397: sipush #145
    //   400: ixor
    //   401: sipush #168
    //   404: sipush #167
    //   407: ixor
    //   408: iconst_m1
    //   409: ixor
    //   410: iand
    //   411: ifge -> 30
    //   414: return
    //   415: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   52	336	3	lllllllllllllllIlllIIlllIIlIllll	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	416	0	lllllllllllllllIlllIIlllIIlIlllI	Lme/stupitdog/bhp/fn;
    //   16	400	1	lllllllllllllllIlllIIlllIIlIllIl	Ljava/util/List;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   16	400	1	lllllllllllllllIlllIIlllIIlIllIl	Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;
  }
  
  public boolean isSamePos(BlockPos lllllllllllllllIlllIIlllIIlIlIll, BlockPos lllllllllllllllIlllIIlllIIlIlIlI) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 85 : (Lnet/minecraft/util/math/BlockPos;)I
    //   6: aload_2
    //   7: <illegal opcode> 85 : (Lnet/minecraft/util/math/BlockPos;)I
    //   12: invokestatic llllllIIlIlIlII : (II)Z
    //   15: ifeq -> 60
    //   18: aload_1
    //   19: <illegal opcode> 86 : (Lnet/minecraft/util/math/BlockPos;)I
    //   24: aload_2
    //   25: <illegal opcode> 86 : (Lnet/minecraft/util/math/BlockPos;)I
    //   30: invokestatic llllllIIlIlIlII : (II)Z
    //   33: ifeq -> 60
    //   36: aload_1
    //   37: <illegal opcode> 87 : (Lnet/minecraft/util/math/BlockPos;)I
    //   42: aload_2
    //   43: <illegal opcode> 87 : (Lnet/minecraft/util/math/BlockPos;)I
    //   48: invokestatic llllllIIlIlIlII : (II)Z
    //   51: ifeq -> 60
    //   54: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   57: iconst_1
    //   58: iaload
    //   59: ireturn
    //   60: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   63: iconst_0
    //   64: iaload
    //   65: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	66	0	lllllllllllllllIlllIIlllIIlIllII	Lme/stupitdog/bhp/fn;
    //   0	66	1	lllllllllllllllIlllIIlllIIlIlIll	Lnet/minecraft/util/math/BlockPos;
    //   0	66	2	lllllllllllllllIlllIIlllIIlIlIlI	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static boolean isLiving(Entity lllllllllllllllIlllIIlllIIlIlIIl) {
    return lllllllllllllllIlllIIlllIIlIlIIl instanceof net.minecraft.entity.EntityLivingBase;
  }
  
  private boolean intersectsWithEntity(BlockPos lllllllllllllllIlllIIlllIIlIIllI) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 72 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 88 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 79 : (Ljava/util/List;)Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: <illegal opcode> 80 : (Ljava/util/Iterator;)Z
    //   27: invokestatic llllllIIlIlIlll : (I)Z
    //   30: ifeq -> 414
    //   33: aload_2
    //   34: <illegal opcode> 81 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast net/minecraft/entity/Entity
    //   42: astore_3
    //   43: aload_3
    //   44: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   49: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   54: <illegal opcode> 89 : (Lnet/minecraft/entity/Entity;Ljava/lang/Object;)Z
    //   59: invokestatic llllllIIlIlIlll : (I)Z
    //   62: ifeq -> 254
    //   65: ldc ''
    //   67: invokevirtual length : ()I
    //   70: pop
    //   71: bipush #99
    //   73: bipush #82
    //   75: ixor
    //   76: ldc ' '
    //   78: invokevirtual length : ()I
    //   81: ldc ' '
    //   83: invokevirtual length : ()I
    //   86: ishl
    //   87: ishl
    //   88: bipush #37
    //   90: bipush #46
    //   92: iadd
    //   93: bipush #62
    //   95: isub
    //   96: bipush #126
    //   98: iadd
    //   99: ixor
    //   100: bipush #37
    //   102: bipush #44
    //   104: ixor
    //   105: ldc ' '
    //   107: invokevirtual length : ()I
    //   110: ldc ' '
    //   112: invokevirtual length : ()I
    //   115: ishl
    //   116: ishl
    //   117: bipush #85
    //   119: bipush #38
    //   121: ixor
    //   122: ixor
    //   123: ldc ' '
    //   125: invokevirtual length : ()I
    //   128: ineg
    //   129: ixor
    //   130: iand
    //   131: sipush #132
    //   134: sipush #145
    //   137: ixor
    //   138: ldc '   '
    //   140: invokevirtual length : ()I
    //   143: ishl
    //   144: bipush #57
    //   146: bipush #36
    //   148: iadd
    //   149: bipush #-32
    //   151: isub
    //   152: bipush #54
    //   154: iadd
    //   155: ixor
    //   156: bipush #27
    //   158: bipush #22
    //   160: ixor
    //   161: ldc '   '
    //   163: invokevirtual length : ()I
    //   166: ishl
    //   167: bipush #53
    //   169: bipush #70
    //   171: ixor
    //   172: ixor
    //   173: ldc ' '
    //   175: invokevirtual length : ()I
    //   178: ineg
    //   179: ixor
    //   180: iand
    //   181: if_icmpeq -> 21
    //   184: sipush #178
    //   187: sipush #187
    //   190: ixor
    //   191: ldc ' '
    //   193: invokevirtual length : ()I
    //   196: ldc ' '
    //   198: invokevirtual length : ()I
    //   201: ldc ' '
    //   203: invokevirtual length : ()I
    //   206: ishl
    //   207: ishl
    //   208: ishl
    //   209: sipush #170
    //   212: bipush #123
    //   214: iadd
    //   215: sipush #284
    //   218: isub
    //   219: sipush #170
    //   222: iadd
    //   223: ixor
    //   224: sipush #158
    //   227: sipush #163
    //   230: ixor
    //   231: sipush #207
    //   234: sipush #192
    //   237: ixor
    //   238: ldc ' '
    //   240: invokevirtual length : ()I
    //   243: ishl
    //   244: ixor
    //   245: ldc ' '
    //   247: invokevirtual length : ()I
    //   250: ineg
    //   251: ixor
    //   252: iand
    //   253: ireturn
    //   254: aload_3
    //   255: instanceof net/minecraft/entity/item/EntityItem
    //   258: invokestatic llllllIIlIlIlll : (I)Z
    //   261: ifeq -> 316
    //   264: ldc ''
    //   266: invokevirtual length : ()I
    //   269: pop
    //   270: ldc ' '
    //   272: invokevirtual length : ()I
    //   275: ldc ' '
    //   277: invokevirtual length : ()I
    //   280: ishl
    //   281: ldc ' '
    //   283: invokevirtual length : ()I
    //   286: ineg
    //   287: if_icmpge -> 21
    //   290: ldc '   '
    //   292: invokevirtual length : ()I
    //   295: bipush #59
    //   297: bipush #62
    //   299: ixor
    //   300: ishl
    //   301: ldc '   '
    //   303: invokevirtual length : ()I
    //   306: bipush #117
    //   308: bipush #112
    //   310: ixor
    //   311: ishl
    //   312: iconst_m1
    //   313: ixor
    //   314: iand
    //   315: ireturn
    //   316: new net/minecraft/util/math/AxisAlignedBB
    //   319: dup
    //   320: aload_1
    //   321: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   324: aload_3
    //   325: <illegal opcode> 90 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   330: <illegal opcode> 91 : (Lnet/minecraft/util/math/AxisAlignedBB;Lnet/minecraft/util/math/AxisAlignedBB;)Z
    //   335: invokestatic llllllIIlIlIlll : (I)Z
    //   338: ifeq -> 347
    //   341: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   344: iconst_1
    //   345: iaload
    //   346: ireturn
    //   347: ldc ''
    //   349: invokevirtual length : ()I
    //   352: pop
    //   353: ldc '   '
    //   355: invokevirtual length : ()I
    //   358: sipush #246
    //   361: sipush #181
    //   364: ixor
    //   365: bipush #44
    //   367: bipush #111
    //   369: ixor
    //   370: iconst_m1
    //   371: ixor
    //   372: iand
    //   373: if_icmpgt -> 21
    //   376: bipush #61
    //   378: bipush #56
    //   380: ixor
    //   381: ldc ' '
    //   383: invokevirtual length : ()I
    //   386: ldc ' '
    //   388: invokevirtual length : ()I
    //   391: ishl
    //   392: ishl
    //   393: bipush #99
    //   395: bipush #102
    //   397: ixor
    //   398: ldc ' '
    //   400: invokevirtual length : ()I
    //   403: ldc ' '
    //   405: invokevirtual length : ()I
    //   408: ishl
    //   409: ishl
    //   410: iconst_m1
    //   411: ixor
    //   412: iand
    //   413: ireturn
    //   414: getstatic me/stupitdog/bhp/fn.lIllllIIIIllII : [I
    //   417: iconst_0
    //   418: iaload
    //   419: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	304	3	lllllllllllllllIlllIIlllIIlIlIII	Lnet/minecraft/entity/Entity;
    //   0	420	0	lllllllllllllllIlllIIlllIIlIIlll	Lme/stupitdog/bhp/fn;
    //   0	420	1	lllllllllllllllIlllIIlllIIlIIllI	Lnet/minecraft/util/math/BlockPos;
  }
  
  static {
    llllllIIlIIlllI();
    llllllIIlIIlIII();
    llllllIIlIIIlll();
    llllllIIIllllII();
  }
  
  private static CallSite lllllIIlllIlIII(MethodHandles.Lookup lllllllllllllllIlllIIlllIIIllIll, String lllllllllllllllIlllIIlllIIIllIlI, MethodType lllllllllllllllIlllIIlllIIIllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlllIIlIIIIl = lIlllIlIIIllIl[Integer.parseInt(lllllllllllllllIlllIIlllIIIllIlI)].split(lIllllIIIIIlIl[lIllllIIIIllII[32]]);
      Class<?> lllllllllllllllIlllIIlllIIlIIIII = Class.forName(lllllllllllllllIlllIIlllIIlIIIIl[lIllllIIIIllII[0]]);
      String lllllllllllllllIlllIIlllIIIlllll = lllllllllllllllIlllIIlllIIlIIIIl[lIllllIIIIllII[1]];
      MethodHandle lllllllllllllllIlllIIlllIIIllllI = null;
      int lllllllllllllllIlllIIlllIIIlllIl = lllllllllllllllIlllIIlllIIlIIIIl[lIllllIIIIllII[4]].length();
      if (llllllIIlIlllII(lllllllllllllllIlllIIlllIIIlllIl, lIllllIIIIllII[2])) {
        MethodType lllllllllllllllIlllIIlllIIlIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlllIIlIIIIl[lIllllIIIIllII[2]], fn.class.getClassLoader());
        if (llllllIIlIlIlII(lllllllllllllllIlllIIlllIIIlllIl, lIllllIIIIllII[2])) {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findVirtual(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIll);
          "".length();
          if (((0xF2 ^ 0xA5) << " ".length() ^ 133 + 163 - 171 + 46) == 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findStatic(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIll);
        } 
        "".length();
        if ("   ".length() != "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlllIIlIIIlI = lIlllIlIIIlllI[Integer.parseInt(lllllllllllllllIlllIIlllIIlIIIIl[lIllllIIIIllII[2]])];
        if (llllllIIlIlIlII(lllllllllllllllIlllIIlllIIIlllIl, lIllllIIIIllII[4])) {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findGetter(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIlI);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (llllllIIlIlIlII(lllllllllllllllIlllIIlllIIIlllIl, lIllllIIIIllII[5])) {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findStaticGetter(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (llllllIIlIlIlII(lllllllllllllllIlllIIlllIIIlllIl, lIllllIIIIllII[6])) {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findSetter(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIlI);
          "".length();
          if (-" ".length() >= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlllIIIllllI = lllllllllllllllIlllIIlllIIIllIll.findStaticSetter(lllllllllllllllIlllIIlllIIlIIIII, lllllllllllllllIlllIIlllIIIlllll, lllllllllllllllIlllIIlllIIlIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlllIIIllllI);
    } catch (Exception lllllllllllllllIlllIIlllIIIlllII) {
      lllllllllllllllIlllIIlllIIIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIIllllII() {
    lIlllIlIIIllIl = new String[lIllllIIIIllII[33]];
    lIlllIlIIIllIl[lIllllIIIIllII[12]] = lIllllIIIIIlIl[lIllllIIIIllII[34]];
    lIlllIlIIIllIl[lIllllIIIIllII[35]] = lIllllIIIIIlIl[lIllllIIIIllII[36]];
    lIlllIlIIIllIl[lIllllIIIIllII[37]] = lIllllIIIIIlIl[lIllllIIIIllII[38]];
    lIlllIlIIIllIl[lIllllIIIIllII[39]] = lIllllIIIIIlIl[lIllllIIIIllII[39]];
    lIlllIlIIIllIl[lIllllIIIIllII[40]] = lIllllIIIIIlIl[lIllllIIIIllII[41]];
    lIlllIlIIIllIl[lIllllIIIIllII[42]] = lIllllIIIIIlIl[lIllllIIIIllII[43]];
    lIlllIlIIIllIl[lIllllIIIIllII[44]] = lIllllIIIIIlIl[lIllllIIIIllII[45]];
    lIlllIlIIIllIl[lIllllIIIIllII[46]] = lIllllIIIIIlIl[lIllllIIIIllII[47]];
    lIlllIlIIIllIl[lIllllIIIIllII[26]] = lIllllIIIIIlIl[lIllllIIIIllII[48]];
    lIlllIlIIIllIl[lIllllIIIIllII[15]] = lIllllIIIIIlIl[lIllllIIIIllII[49]];
    lIlllIlIIIllIl[lIllllIIIIllII[0]] = lIllllIIIIIlIl[lIllllIIIIllII[50]];
    lIlllIlIIIllIl[lIllllIIIIllII[29]] = lIllllIIIIIlIl[lIllllIIIIllII[51]];
    lIlllIlIIIllIl[lIllllIIIIllII[30]] = lIllllIIIIIlIl[lIllllIIIIllII[52]];
    lIlllIlIIIllIl[lIllllIIIIllII[34]] = lIllllIIIIIlIl[lIllllIIIIllII[53]];
    lIlllIlIIIllIl[lIllllIIIIllII[18]] = lIllllIIIIIlIl[lIllllIIIIllII[54]];
    lIlllIlIIIllIl[lIllllIIIIllII[55]] = lIllllIIIIIlIl[lIllllIIIIllII[56]];
    lIlllIlIIIllIl[lIllllIIIIllII[57]] = lIllllIIIIIlIl[lIllllIIIIllII[58]];
    lIlllIlIIIllIl[lIllllIIIIllII[54]] = lIllllIIIIIlIl[lIllllIIIIllII[59]];
    lIlllIlIIIllIl[lIllllIIIIllII[10]] = lIllllIIIIIlIl[lIllllIIIIllII[60]];
    lIlllIlIIIllIl[lIllllIIIIllII[61]] = lIllllIIIIIlIl[lIllllIIIIllII[61]];
    lIlllIlIIIllIl[lIllllIIIIllII[62]] = lIllllIIIIIlIl[lIllllIIIIllII[46]];
    lIlllIlIIIllIl[lIllllIIIIllII[63]] = lIllllIIIIIlIl[lIllllIIIIllII[63]];
    lIlllIlIIIllIl[lIllllIIIIllII[52]] = lIllllIIIIIlIl[lIllllIIIIllII[44]];
    lIlllIlIIIllIl[lIllllIIIIllII[38]] = lIllllIIIIIlIl[lIllllIIIIllII[64]];
    lIlllIlIIIllIl[lIllllIIIIllII[65]] = lIllllIIIIIlIl[lIllllIIIIllII[66]];
    lIlllIlIIIllIl[lIllllIIIIllII[67]] = lIllllIIIIIlIl[lIllllIIIIllII[55]];
    lIlllIlIIIllIl[lIllllIIIIllII[21]] = lIllllIIIIIlIl[lIllllIIIIllII[68]];
    lIlllIlIIIllIl[lIllllIIIIllII[51]] = lIllllIIIIIlIl[lIllllIIIIllII[69]];
    lIlllIlIIIllIl[lIllllIIIIllII[9]] = lIllllIIIIIlIl[lIllllIIIIllII[70]];
    lIlllIlIIIllIl[lIllllIIIIllII[47]] = lIllllIIIIIlIl[lIllllIIIIllII[37]];
    lIlllIlIIIllIl[lIllllIIIIllII[71]] = lIllllIIIIIlIl[lIllllIIIIllII[72]];
    lIlllIlIIIllIl[lIllllIIIIllII[68]] = lIllllIIIIIlIl[lIllllIIIIllII[73]];
    lIlllIlIIIllIl[lIllllIIIIllII[36]] = lIllllIIIIIlIl[lIllllIIIIllII[74]];
    lIlllIlIIIllIl[lIllllIIIIllII[75]] = lIllllIIIIIlIl[lIllllIIIIllII[76]];
    lIlllIlIIIllIl[lIllllIIIIllII[77]] = lIllllIIIIIlIl[lIllllIIIIllII[65]];
    lIlllIlIIIllIl[lIllllIIIIllII[78]] = lIllllIIIIIlIl[lIllllIIIIllII[62]];
    lIlllIlIIIllIl[lIllllIIIIllII[70]] = lIllllIIIIIlIl[lIllllIIIIllII[79]];
    lIlllIlIIIllIl[lIllllIIIIllII[32]] = lIllllIIIIIlIl[lIllllIIIIllII[80]];
    lIlllIlIIIllIl[lIllllIIIIllII[25]] = lIllllIIIIIlIl[lIllllIIIIllII[81]];
    lIlllIlIIIllIl[lIllllIIIIllII[82]] = lIllllIIIIIlIl[lIllllIIIIllII[75]];
    lIlllIlIIIllIl[lIllllIIIIllII[69]] = lIllllIIIIIlIl[lIllllIIIIllII[82]];
    lIlllIlIIIllIl[lIllllIIIIllII[83]] = lIllllIIIIIlIl[lIllllIIIIllII[84]];
    lIlllIlIIIllIl[lIllllIIIIllII[6]] = lIllllIIIIIlIl[lIllllIIIIllII[85]];
    lIlllIlIIIllIl[lIllllIIIIllII[58]] = lIllllIIIIIlIl[lIllllIIIIllII[86]];
    lIlllIlIIIllIl[lIllllIIIIllII[45]] = lIllllIIIIIlIl[lIllllIIIIllII[35]];
    lIlllIlIIIllIl[lIllllIIIIllII[80]] = lIllllIIIIIlIl[lIllllIIIIllII[87]];
    lIlllIlIIIllIl[lIllllIIIIllII[28]] = lIllllIIIIIlIl[lIllllIIIIllII[42]];
    lIlllIlIIIllIl[lIllllIIIIllII[88]] = lIllllIIIIIlIl[lIllllIIIIllII[89]];
    lIlllIlIIIllIl[lIllllIIIIllII[59]] = lIllllIIIIIlIl[lIllllIIIIllII[57]];
    lIlllIlIIIllIl[lIllllIIIIllII[90]] = lIllllIIIIIlIl[lIllllIIIIllII[91]];
    lIlllIlIIIllIl[lIllllIIIIllII[81]] = lIllllIIIIIlIl[lIllllIIIIllII[77]];
    lIlllIlIIIllIl[lIllllIIIIllII[17]] = lIllllIIIIIlIl[lIllllIIIIllII[92]];
    lIlllIlIIIllIl[lIllllIIIIllII[89]] = lIllllIIIIIlIl[lIllllIIIIllII[93]];
    lIlllIlIIIllIl[lIllllIIIIllII[94]] = lIllllIIIIIlIl[lIllllIIIIllII[95]];
    lIlllIlIIIllIl[lIllllIIIIllII[22]] = lIllllIIIIIlIl[lIllllIIIIllII[96]];
    lIlllIlIIIllIl[lIllllIIIIllII[66]] = lIllllIIIIIlIl[lIllllIIIIllII[97]];
    lIlllIlIIIllIl[lIllllIIIIllII[85]] = lIllllIIIIIlIl[lIllllIIIIllII[98]];
    lIlllIlIIIllIl[lIllllIIIIllII[43]] = lIllllIIIIIlIl[lIllllIIIIllII[83]];
    lIlllIlIIIllIl[lIllllIIIIllII[99]] = lIllllIIIIIlIl[lIllllIIIIllII[100]];
    lIlllIlIIIllIl[lIllllIIIIllII[4]] = lIllllIIIIIlIl[lIllllIIIIllII[88]];
    lIlllIlIIIllIl[lIllllIIIIllII[31]] = lIllllIIIIIlIl[lIllllIIIIllII[90]];
    lIlllIlIIIllIl[lIllllIIIIllII[24]] = lIllllIIIIIlIl[lIllllIIIIllII[94]];
    lIlllIlIIIllIl[lIllllIIIIllII[5]] = lIllllIIIIIlIl[lIllllIIIIllII[78]];
    lIlllIlIIIllIl[lIllllIIIIllII[49]] = lIllllIIIIIlIl[lIllllIIIIllII[67]];
    lIlllIlIIIllIl[lIllllIIIIllII[41]] = lIllllIIIIIlIl[lIllllIIIIllII[71]];
    lIlllIlIIIllIl[lIllllIIIIllII[53]] = lIllllIIIIIlIl[lIllllIIIIllII[101]];
    lIlllIlIIIllIl[lIllllIIIIllII[72]] = lIllllIIIIIlIl[lIllllIIIIllII[102]];
    lIlllIlIIIllIl[lIllllIIIIllII[103]] = lIllllIIIIIlIl[lIllllIIIIllII[104]];
    lIlllIlIIIllIl[lIllllIIIIllII[92]] = lIllllIIIIIlIl[lIllllIIIIllII[103]];
    lIlllIlIIIllIl[lIllllIIIIllII[91]] = lIllllIIIIIlIl[lIllllIIIIllII[99]];
    lIlllIlIIIllIl[lIllllIIIIllII[48]] = lIllllIIIIIlIl[lIllllIIIIllII[105]];
    lIlllIlIIIllIl[lIllllIIIIllII[2]] = lIllllIIIIIlIl[lIllllIIIIllII[40]];
    lIlllIlIIIllIl[lIllllIIIIllII[84]] = lIllllIIIIIlIl[lIllllIIIIllII[33]];
    lIlllIlIIIllIl[lIllllIIIIllII[73]] = lIllllIIIIIlIl[lIllllIIIIllII[106]];
    lIlllIlIIIllIl[lIllllIIIIllII[56]] = lIllllIIIIIlIl[lIllllIIIIllII[107]];
    lIlllIlIIIllIl[lIllllIIIIllII[98]] = lIllllIIIIIlIl[lIllllIIIIllII[108]];
    lIlllIlIIIllIl[lIllllIIIIllII[16]] = lIllllIIIIIlIl[lIllllIIIIllII[109]];
    lIlllIlIIIllIl[lIllllIIIIllII[76]] = lIllllIIIIIlIl[lIllllIIIIllII[110]];
    lIlllIlIIIllIl[lIllllIIIIllII[79]] = lIllllIIIIIlIl[lIllllIIIIllII[111]];
    lIlllIlIIIllIl[lIllllIIIIllII[102]] = lIllllIIIIIlIl[lIllllIIIIllII[112]];
    lIlllIlIIIllIl[lIllllIIIIllII[101]] = lIllllIIIIIlIl[lIllllIIIIllII[113]];
    lIlllIlIIIllIl[lIllllIIIIllII[93]] = lIllllIIIIIlIl[lIllllIIIIllII[114]];
    lIlllIlIIIllIl[lIllllIIIIllII[14]] = lIllllIIIIIlIl[lIllllIIIIllII[115]];
    lIlllIlIIIllIl[lIllllIIIIllII[86]] = lIllllIIIIIlIl[lIllllIIIIllII[116]];
    lIlllIlIIIllIl[lIllllIIIIllII[23]] = lIllllIIIIIlIl[lIllllIIIIllII[117]];
    lIlllIlIIIllIl[lIllllIIIIllII[50]] = lIllllIIIIIlIl[lIllllIIIIllII[118]];
    lIlllIlIIIllIl[lIllllIIIIllII[87]] = lIllllIIIIIlIl[lIllllIIIIllII[119]];
    lIlllIlIIIllIl[lIllllIIIIllII[64]] = lIllllIIIIIlIl[lIllllIIIIllII[120]];
    lIlllIlIIIllIl[lIllllIIIIllII[11]] = lIllllIIIIIlIl[lIllllIIIIllII[121]];
    lIlllIlIIIllIl[lIllllIIIIllII[100]] = lIllllIIIIIlIl[lIllllIIIIllII[122]];
    lIlllIlIIIllIl[lIllllIIIIllII[97]] = lIllllIIIIIlIl[lIllllIIIIllII[123]];
    lIlllIlIIIllIl[lIllllIIIIllII[104]] = lIllllIIIIIlIl[lIllllIIIIllII[124]];
    lIlllIlIIIllIl[lIllllIIIIllII[105]] = lIllllIIIIIlIl[lIllllIIIIllII[125]];
    lIlllIlIIIllIl[lIllllIIIIllII[20]] = lIllllIIIIIlIl[lIllllIIIIllII[126]];
    lIlllIlIIIllIl[lIllllIIIIllII[60]] = lIllllIIIIIlIl[lIllllIIIIllII[127]];
    lIlllIlIIIllIl[lIllllIIIIllII[1]] = lIllllIIIIIlIl[lIllllIIIIllII[128]];
    lIlllIlIIIllIl[lIllllIIIIllII[8]] = lIllllIIIIIlIl[lIllllIIIIllII[129]];
    lIlllIlIIIllIl[lIllllIIIIllII[74]] = lIllllIIIIIlIl[lIllllIIIIllII[130]];
    lIlllIlIIIllIl[lIllllIIIIllII[96]] = lIllllIIIIIlIl[lIllllIIIIllII[131]];
    lIlllIlIIIllIl[lIllllIIIIllII[7]] = lIllllIIIIIlIl[lIllllIIIIllII[132]];
    lIlllIlIIIllIl[lIllllIIIIllII[13]] = lIllllIIIIIlIl[lIllllIIIIllII[133]];
    lIlllIlIIIllIl[lIllllIIIIllII[27]] = lIllllIIIIIlIl[lIllllIIIIllII[134]];
    lIlllIlIIIllIl[lIllllIIIIllII[95]] = lIllllIIIIIlIl[lIllllIIIIllII[135]];
    lIlllIlIIIlllI = new Class[lIllllIIIIllII[26]];
    lIlllIlIIIlllI[lIllllIIIIllII[20]] = CPacketEntityAction.Action.class;
    lIlllIlIIIlllI[lIllllIIIIllII[17]] = EnumFacing.class;
    lIlllIlIIIlllI[lIllllIIIIllII[16]] = float.class;
    lIlllIlIIIlllI[lIllllIIIIllII[18]] = NetHandlerPlayClient.class;
    lIlllIlIIIlllI[lIllllIIIIllII[7]] = Minecraft.class;
    lIlllIlIIIlllI[lIllllIIIIllII[25]] = List.class;
    lIlllIlIIIlllI[lIllllIIIIllII[11]] = BlockPistonBase.class;
    lIlllIlIIIlllI[lIllllIIIIllII[9]] = InventoryPlayer.class;
    lIlllIlIIIlllI[lIllllIIIIllII[10]] = ItemStack.class;
    lIlllIlIIIlllI[lIllllIIIIllII[4]] = f100000000000000000000.Mode.class;
    lIlllIlIIIlllI[lIllllIIIIllII[22]] = PlayerControllerMP.class;
    lIlllIlIIIlllI[lIllllIIIIllII[2]] = Listener.class;
    lIlllIlIIIlllI[lIllllIIIIllII[0]] = f13.class;
    lIlllIlIIIlllI[lIllllIIIIllII[23]] = WorldClient.class;
    lIlllIlIIIlllI[lIllllIIIIllII[13]] = RayTraceResult.class;
    lIlllIlIIIlllI[lIllllIIIIllII[8]] = EntityPlayerSP.class;
    lIlllIlIIIlllI[lIllllIIIIllII[12]] = Block.class;
    lIlllIlIIIlllI[lIllllIIIIllII[6]] = f100000000000000000000.ColorSetting.class;
    lIlllIlIIIlllI[lIllllIIIIllII[1]] = int.class;
    lIlllIlIIIlllI[lIllllIIIIllII[14]] = BlockPos.class;
    lIlllIlIIIlllI[lIllllIIIIllII[15]] = EntityPlayer.class;
    lIlllIlIIIlllI[lIllllIIIIllII[24]] = EnumHand.class;
    lIlllIlIIIlllI[lIllllIIIIllII[5]] = f100000000000000000000.Boolean.class;
    lIlllIlIIIlllI[lIllllIIIIllII[21]] = boolean.class;
  }
  
  private static void llllllIIlIIIlll() {
    lIllllIIIIIlIl = new String[lIllllIIIIllII[136]];
    lIllllIIIIIlIl[lIllllIIIIllII[0]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[0]], lIllllIIIIlIll[lIllllIIIIllII[1]]);
    lIllllIIIIIlIl[lIllllIIIIllII[1]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[2]], lIllllIIIIlIll[lIllllIIIIllII[4]]);
    lIllllIIIIIlIl[lIllllIIIIllII[2]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[5]], lIllllIIIIlIll[lIllllIIIIllII[6]]);
    lIllllIIIIIlIl[lIllllIIIIllII[4]] = llllllIIIlllllI(lIllllIIIIlIll[lIllllIIIIllII[7]], lIllllIIIIlIll[lIllllIIIIllII[8]]);
    lIllllIIIIIlIl[lIllllIIIIllII[5]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[9]], lIllllIIIIlIll[lIllllIIIIllII[10]]);
    lIllllIIIIIlIl[lIllllIIIIllII[6]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[11]], lIllllIIIIlIll[lIllllIIIIllII[12]]);
    lIllllIIIIIlIl[lIllllIIIIllII[7]] = llllllIIIlllllI(lIllllIIIIlIll[lIllllIIIIllII[13]], lIllllIIIIlIll[lIllllIIIIllII[14]]);
    lIllllIIIIIlIl[lIllllIIIIllII[8]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[15]], lIllllIIIIlIll[lIllllIIIIllII[16]]);
    lIllllIIIIIlIl[lIllllIIIIllII[9]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[17]], lIllllIIIIlIll[lIllllIIIIllII[18]]);
    lIllllIIIIIlIl[lIllllIIIIllII[10]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[20]], lIllllIIIIlIll[lIllllIIIIllII[21]]);
    lIllllIIIIIlIl[lIllllIIIIllII[11]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[22]], lIllllIIIIlIll[lIllllIIIIllII[23]]);
    lIllllIIIIIlIl[lIllllIIIIllII[12]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[24]], lIllllIIIIlIll[lIllllIIIIllII[25]]);
    lIllllIIIIIlIl[lIllllIIIIllII[13]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[26]], lIllllIIIIlIll[lIllllIIIIllII[27]]);
    lIllllIIIIIlIl[lIllllIIIIllII[14]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[28]], lIllllIIIIlIll[lIllllIIIIllII[29]]);
    lIllllIIIIIlIl[lIllllIIIIllII[15]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[30]], lIllllIIIIlIll[lIllllIIIIllII[31]]);
    lIllllIIIIIlIl[lIllllIIIIllII[16]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[32]], lIllllIIIIlIll[lIllllIIIIllII[34]]);
    lIllllIIIIIlIl[lIllllIIIIllII[17]] = llllllIIIllllIl(lIllllIIIIlIll[lIllllIIIIllII[36]], lIllllIIIIlIll[lIllllIIIIllII[38]]);
    lIllllIIIIIlIl[lIllllIIIIllII[18]] = llllllIIIllllll(lIllllIIIIlIll[lIllllIIIIllII[39]], lIllllIIIIlIll[lIllllIIIIllII[41]]);
    lIllllIIIIIlIl[lIllllIIIIllII[20]] = llllllIIIlllllI(lIllllIIIIlIll[lIllllIIIIllII[43]], lIllllIIIIlIll[lIllllIIIIllII[45]]);
    lIllllIIIIIlIl[lIllllIIIIllII[21]] = llllllIIIlllllI(lIllllIIIIlIll[lIllllIIIIllII[47]], lIllllIIIIlIll[lIllllIIIIllII[48]]);
    lIllllIIIIIlIl[lIllllIIIIllII[22]] = llllllIIIllllIl("DFTzD+9RX79vdCRSS/rA9Kj57VeDOnf3jITubGAr6hQdSE+GfeGNkJtxThcLUzb4KLPZ3BrgosQ=", "cUcck");
    lIllllIIIIIlIl[lIllllIIIIllII[23]] = llllllIIIllllll("EiI5Cg8oEzodJGkXOQ4aIAkyTwkgFCEAF2dJ", "IgUoy");
    lIllllIIIIIlIl[lIllllIIIIllII[24]] = llllllIIIlllllI("oQgbJO5kei1Tvhg7fwvLbWR/25iKfLLFIxIBOgc/cpWgWhqL5wCSRQ==", "HKxKX");
    lIllllIIIIIlIl[lIllllIIIIllII[25]] = llllllIIIllllIl("FVrQbsq+fcc=", "nDDqE");
    lIllllIIIIIlIl[lIllllIIIIllII[26]] = llllllIIIllllIl("cZ9czaMODAM=", "qdcgM");
    lIllllIIIIIlIl[lIllllIIIIllII[27]] = llllllIIIllllll("LSE9DQ==", "lTIbp");
    lIllllIIIIIlIl[lIllllIIIIllII[28]] = llllllIIIllllIl("ITl2XlcXViY=", "iXgCk");
    lIllllIIIIIlIl[lIllllIIIIllII[29]] = llllllIIIllllIl("lIwID5f0HHI=", "VNKKF");
    lIllllIIIIIlIl[lIllllIIIIllII[30]] = llllllIIIllllll("Lgw2", "zcFWt");
    lIllllIIIIIlIl[lIllllIIIIllII[31]] = llllllIIIlllllI("G4ZonJqmnf8=", "AXIKx");
    lIllllIIIIIlIl[lIllllIIIIllII[32]] = llllllIIIlllllI("II/MTammONw=", "gchRE");
    lIllllIIIIIlIl[lIllllIIIIllII[34]] = llllllIIIllllIl("tliX2WSBznlWXCmDY/MN6HsyJr68Ox1qqStGE1i0aoHjzl8SeEIP+K81iyrkFQnkP+OG45OKsIMyvdOqN2/A5VjjzXcffZ2RfHkoKpLSmqlknn2ZM6cAAOTu+3BQK+bFgzbGZrnI6CWDNsZmucjoJWT5bVPY95M8ulifP2o47n0UwjN+2SLPcQ==", "Gkbwg");
    lIllllIIIIIlIl[lIllllIIIIllII[36]] = llllllIIIllllIl("vglHyHn+PaTGsF3QfTV0W6PlSAeH1lghRnfmTegYfSZ0OmEPNmgdSO05Cjr7IpzjoWir8TXAOrblSRkrxafRQgoTlx6zd1tSyxp6FjzKx3Zs1C73U830bdm7K1oQG4vq", "SArMv");
    lIllllIIIIIlIl[lIllllIIIIllII[38]] = llllllIIIllllIl("BW7atA3REplKJpqAPn3TMc1Nrwi4XCNbiX2yDeyFO9Vjj2xkxDc+OD+b6IBFavDoP8Va0PDZNBsDxUDXwUJ5/HGwGLZmdHaTZpuEm2cuupc=", "AAreN");
    lIllllIIIIIlIl[lIllllIIIIllII[39]] = llllllIIIllllll("CCxCIw4QOQUkHgouQjISFWcKPkAWLBgSCAQqBzUOX2EgOhsTKEM8GwsuQwMOFyACN0FMH1ZwWg==", "eIlPz");
    lIllllIIIIIlIl[lIllllIIIIllII[41]] = llllllIIIlllllI("hA46I/6thZ13UnP4cgGKO5DxTjEMVXBWG1VRV5/L2TVPBhG+4eTPXx/rRomn/duI0ahyS/ZMDwy5rurGJErpqbzblxSfQInduGi0SYS/vRiq4wFlR1mnzwydwTZ8rCWZ", "jtTuf");
    lIllllIIIIIlIl[lIllllIIIIllII[43]] = llllllIIIlllllI("Yk0Mp394yNytKaSTsshYB3pwgeTAw1QKfmRvA6ON7c4R8OnrwUuyvWTz2qh5dHkIF2x82MM7t4wsqLX4Z5aYCV43QEA6U5Tj", "xVMYG");
    lIllllIIIIIlIl[lIllllIIIIllII[45]] = llllllIIIlllllI("P3NplinmC69NpprRF4BLtXT7LZnUzIeCMIP9B9bZE3ufgv7jiWdchBsupoxb3RUoVlm8UgG+raw75kwQ8F6aDTADVdmBKcSNqeCqbpQl9qTo1Ljrq1WZyA==", "QWDJw");
    lIllllIIIIIlIl[lIllllIIIIllII[47]] = llllllIIIllllIl("vF3wCIom5Bsuh3pPTSKsUfL80rOR6yGgTAZ/g1N4J6CP2ahYXpejSHNZDtPg85ux9kr4Qf3IeYQyg7Cuuvcqvw==", "NYxfS");
    lIllllIIIIIlIl[lIllllIIIIllII[48]] = llllllIIIlllllI("swSCIrlcWvvScWWZdfxEyjujnb58p0dLMuVjoaGY4w86tCubC3x/2Dh0oKnaSBoBFnEmBYOmXEA=", "FfiVR");
    lIllllIIIIIlIl[lIllllIIIIllII[49]] = llllllIIIllllll("Gi9eJjsCOhkhKxgtXjcnB2QWO3UFLxQmOxgkFQYjGD5KZHVXalA=", "wJpUO");
    lIllllIIIIIlIl[lIllllIIIIllII[50]] = llllllIIIllllll("LjVcKxI2IBssAiw3XDoOM34UaVV5FSoIKgwZJgtcc2pSeEZj", "CPrXf");
    lIllllIIIIIlIl[lIllllIIIIllII[51]] = llllllIIIlllllI("VpqNXMhiH99C6cjaaFcrnpIhmntf/1rcHUyqpx/UKtbGHIfeEUy+FAqztJx+9JqcEgdw2GcgcKY=", "BEXOy");
    lIllllIIIIIlIl[lIllllIIIIllII[52]] = llllllIIIlllllI("KyYWHjWR4CWZP+kUvnNB6ATctYN2ptJhQQht+S2NwGIxnr1nVaH/WCEZUxgL29rg5OZf8IWBD1Br/2XYmG5WzpSYk6KUrrW1RWbJSc76lUHmVk0Wv7hyKmhkf7AAfHtQ", "nmlEw");
    lIllllIIIIIlIl[lIllllIIIIllII[53]] = llllllIIIllllll("JTFWKgY9JBEtFiczVjsaOHoeN0g7IBk+F3JlQnlSaA==", "HTxYr");
    lIllllIIIIIlIl[lIllllIIIIllII[54]] = llllllIIIlllllI("cgPu1e3sfr54uVw2thueLa7HRuzMF0p56Pvc3RcXXnGB/VcZHN8ihtM5BKvMjNi1SGaqgXRV2ao=", "ViLtQ");
    lIllllIIIIIlIl[lIllllIIIIllII[56]] = llllllIIIllllll("IAk5ElQmCSEUVBkcPRoULVIqAg8rBDw6HSQHPRY5KxsqSVIGAi4FG2UELh0dZTs7ARMkD3RaIHBIbw==", "JhOsz");
    lIllllIIIIIlIl[lIllllIIIIllII[58]] = llllllIIIlllllI("bDNchdyb3NtXu6nnL4T5TExpUPlN9hIcXfIUuemZ9wkjLt9kzQzOOApxShz28kqEkTI3FnDVkdY=", "uaXgN");
    lIllllIIIIIlIl[lIllllIIIIllII[59]] = llllllIIIllllIl("mhNTr5RMZDehzlKQm8tEbISK5sAy19scDAYEhdZU5io10Rms7WQxgzNdU1CY4UvL", "jUIgG");
    lIllllIIIIIlIl[lIllllIIIIllII[60]] = llllllIIIllllIl("6L9L8Js5pQpd9hMiLyD03CzfbzEf8h1GAv87yDB9IOT9GTvHrwI4Xx5FGFH2kdIukXWRskfu4Mlt+/bsGeipR3/Ez7TinmaJbfgwTv9LYwfzylZVK9mDzfPKVlUr2YPN7EDY/q09y/rwmksKSQgckg==", "ZOlIs");
    lIllllIIIIIlIl[lIllllIIIIllII[61]] = llllllIIIllllIl("R45d76ptOR+exKIZpPL1RP/d04rH6vx42KWPB/8Aplctdxqshu0fqg==", "WYRBo");
    lIllllIIIIIlIl[lIllllIIIIllII[46]] = llllllIIIllllIl("m0Skv10p2tLBoh3uN0EyoeNQFH8PmlNY3wvgjIbq2v6A8j20YKR77A==", "Adzki");
    lIllllIIIIIlIl[lIllllIIIIllII[63]] = llllllIIIllllll("BjI3WxUBOSYWCgkxN1sNHD4vWz0GIi4zGQs+LRJCLBgUO0JZYXlVWEh3", "hWCux");
    lIllllIIIIIlIl[lIllllIIIIllII[44]] = llllllIIIllllll("HgZkPjkGEyM5KRwEZC8lA00sI3cdBj0ZLAEELzl3QlBwbW1TQ2o=", "scJMM");
    lIllllIIIIIlIl[lIllllIIIIllII[64]] = llllllIIIlllllI("1O9k4BGrlkVzRCyaFlig12OCveqf8NGQNverjcWfCd7f5jd8OrJYulBzaezrCPWG20PFZrxdxMdu9ZgRY+YeywFtugaLnpejfZUH3NeHU1Q=", "KEUSi");
    lIllllIIIIIlIl[lIllllIIIIllII[66]] = llllllIIIllllIl("Ge5rNCy0/hZ7JQGovYL9q/CEVLt2ZdGwGjPkBRv4rJEt17+1ARhbKg==", "WkKIt");
    lIllllIIIIIlIl[lIllllIIIIllII[55]] = llllllIIIllllIl("L95S2pTJ2fKQyjDUAi8gZVV13lTGxCKh0OrQcOph2ZNPPyxt14k7iqgLtqazfGKlYRYIgWmUppxOci5irviHdg==", "UdmnJ");
    lIllllIIIIIlIl[lIllllIIIIllII[68]] = llllllIIIllllIl("ORNI+cMzWTdAxJH0gk2xh0/oEAsMygi2Mep8GdA4LOExIJH54H79UgIlDZ46yfLzsWjhaiLF9EeUl1qDjJ8cf+akBxDARP3qfjbYH/UUHEiARTO96Rj+EE+79FfDcMdx", "qGlmf");
    lIllllIIIIIlIl[lIllllIIIIllII[69]] = llllllIIIllllll("KDNmHSAwJiEaMCoxZgw8NXguAG42PywLEiQ1IQAzf2d+VHRldmhO", "EVHnT");
    lIllllIIIIIlIl[lIllllIIIIllII[70]] = llllllIIIlllllI("Vi1e5lc0lBB3ONsQsi53ZQys0FSM8Ie1JXsN8E8pbPjFAmxAxkVvhw==", "UwYLa");
    lIllllIIIIIlIl[lIllllIIIIllII[37]] = llllllIIIllllIl("WD0gySV2hhSEHlk6l2nv3E9EhcHxdExwZn1opV/EON/8FjK/S6sTJf9QetEIayd3JK+lvxt0Iii+saBQ7fr82loz4grBLamgMBuCEaOSrbi6mHYpoSROybu0QQK44c54FqbYV0hCbhqalNUHw/idww==", "SuBqa");
    lIllllIIIIIlIl[lIllllIIIIllII[72]] = llllllIIIllllll("CCRcASYQMRsGNgomXBA6FW8UQ2JVcUJCYlVxQkJiVXFCQmJVexUXPAAzEwY3JwNIWhgvC1s+PAA1XR87CyQRADMDNV0HJgwtXR8zESldMyoMMjMeOwIvFxYQJ3pIUg==", "eArrR");
    lIllllIIIIIlIl[lIllllIIIIllII[73]] = llllllIIIlllllI("ocKU22aeH3BpUEjSftrIq3KArdkd21AT6S+AytuFk/E5Cn31y61eTg==", "ZFjNy");
    lIllllIIIIIlIl[lIllllIIIIllII[74]] = llllllIIIllllIl("OBdpf4w4ma9etkqXUD2fiGzRSOKrz8i5bi8HPHWGK2iMnAR476ORfXmYcakW0GMe", "jJGrl");
    lIllllIIIIIlIl[lIllllIIIIllII[76]] = llllllIIIllllll("Bz0cShsANg0HBAg+HEoDHTEEShsILABKIAw7WwBMDy0GBylYb1BTTl4HDV5eJTYNEFkEMQYBFRs5DhBZHCwBCFkEORwMWT89C1cSUnEkChMddwUNGAw7GgUQHXcdEB8FdwUFAgF3PgEVWjxTXlZJ", "iXhdv");
    lIllllIIIIIlIl[lIllllIIIIllII[65]] = llllllIIIlllllI("VU5V9z420vhBdyczRJsfOjImFZHhww4czsEHuVpKrYoRDtu0aEQ+Rid3UbLB5o9A", "YkuHR");
    lIllllIIIIIlIl[lIllllIIIIllII[62]] = llllllIIIllllIl("k6MgCChqdlSiAryIwpJJlwtXdM6Bx2qs56qvf1mf34sMNGs1M0GyEA==", "mOjiz");
    lIllllIIIIIlIl[lIllllIIIIllII[79]] = llllllIIIllllIl("cjijVBbLfVX+rad5t9c6g0EeyWrXj8ld+X658qEqjQdZVK8lzXNb8Q==", "tWkIY");
    lIllllIIIIIlIl[lIllllIIIIllII[80]] = llllllIIIllllll("ByZWPz4fMxE4LgUkVi4iGm0eInAaLxkvLz4iCisvHnlJf3BKY1hsag==", "jCxLJ");
    lIllllIIIIIlIl[lIllllIIIIllII[81]] = llllllIIIllllll("JhUZWx4hHggWASkWGVsaJhkZWzEkHw4eAHIWBBAfLC9cQEN7Q1wqOXJBXU9TaFBN", "Hpmus");
    lIllllIIIIIlIl[lIllllIIIIllII[75]] = llllllIIIllllll("DD8MbAALNB0hHwM8DGwODjMdLBlMFxEsCAEoGSQZWDwRJwEGBU9zWVZoJyBXUGpCYk1C", "bZxBm");
    lIllllIIIIIlIl[lIllllIIIIllII[82]] = llllllIIIllllll("OClMNx0gPAswDTorTCYBJWIEKlMmJQYhLzQvCyoOb31Ufkl1bA==", "ULbDi");
    lIllllIIIIIlIl[lIllllIIIIllII[84]] = llllllIIIllllll("AB0OSSMHFh8EPA8eDkktAhEfCTpAFQ8LOgcIFgY3CwpUMCEcFB4kIgcdFBN0CBEfCyoxT0hed1gnHF18XUJaR24=", "nxzgN");
    lIllllIIIIIlIl[lIllllIIIIllII[85]] = llllllIIIllllIl("uINk95ZehYq8NTkcsZOnaqXxkLpU9S8RiPdzTwsC0hldibr93FeZOFO0f1HZC0eA0fASQDgKQu7P1dXEh1hIXag7Fi4PkipuoHRtI/iEL9vE1vrqKkJyYu9Gdroo5GRe8z6n2tXhrIFvg5Eap1NAP2P1G4xQm36mnWz3A138QQcwApdPSxTrwIToMvMaJQGI", "SzjQQ");
    lIllllIIIIIlIl[lIllllIIIIllII[86]] = llllllIIIllllll("KAA4RgAvCykLHycDOEYOKgwpBhloACIcBDIcYi0DMgw4ET0qBDUNHxU1dg4EIwkoN1p3VHtcMidffV9XZkVs", "FeLhm");
    lIllllIIIIIlIl[lIllllIIIIllII[35]] = llllllIIIllllll("NwlHKgEvHAAtETULRzsdKkIPN08qAAg6EA4NGz4QLlZYak96TEk=", "ZliYu");
    lIllllIIIIIlIl[lIllllIIIIllII[87]] = llllllIIIlllllI("11y2U0m1l4QMXv4L07ftRSWEmt4hglk3GDRqLmzNnC9aBDwZ8yfMHT4UMnLP7klDt7rDwL5lKy4rL7A3ep5yKh76cjgd8ybcnJow+geK07FkyCY2ZmgbhA==", "LPDuo");
    lIllllIIIIIlIl[lIllllIIIIllII[42]] = llllllIIIlllllI("1TzaGqWxDl3YTDfQ5MbGCmTEzbBgoe1rqaKbahdHsMw88hvdvl2g6g==", "xxgJR");
    lIllllIIIIIlIl[lIllllIIIIllII[89]] = llllllIIIllllIl("jC4oY/ehYfVa8yMRDXbJWSTY72iwbIIfCAFHwZxOV3BNz/jsi5PKp1S1FeEpFUMJfP5Due2QDbX/jlk+7d4ZI8F3mkSvSV1k8g+7MhN3h72VD/mzyHaG7w==", "coDpa");
    lIllllIIIIIlIl[lIllllIIIIllII[57]] = llllllIIIllllIl("WEXS1SSqzb3WjhgoHN+XNkm2/Oax4NXbwWQNTMMBU+fOe26M7Gun8+gFmx9/ySdiMOc0P5kXTscq3bbuu/udeeaxV9oTO3NXlNllqZgG32VYfETi7Ka0zQ==", "eKAWi");
    lIllllIIIIIlIl[lIllllIIIIllII[91]] = llllllIIIllllIl("Y6hEYh2va8RjTpH/fBc+PZATYaDEyL0DOFEQhg4mpghjPPcPwxzCYOQ8ip5cFrhDTm/g26NDykq+yCfPsHZ8Bxf5Uy/f6/TEBT8oh1mYRUGlitXxHnk0JvZpCtZMfrzQmzdJj1VgfM4=", "OAfvP");
    lIllllIIIIIlIl[lIllllIIIIllII[77]] = llllllIIIllllIl("OQy7pGLHNg/p9YAJewjiW7wYuwDIVzfJxJVt5n8MRI+KmYB2PtvngMQULy8eNfuMIxVHIHD+9odFDvU7LiVI28H1q9rW0SAorlQQ8av7qJHNVLMkWwGbHw==", "SqBFE");
    lIllllIIIIIlIl[lIllllIIIIllII[92]] = llllllIIIllllll("Fxx0BzoPCTMAKhUedBYmClc8GnQXGmBCdFpZelQ=", "zyZtN");
    lIllllIIIIIlIl[lIllllIIIIllII[93]] = llllllIIIllllll("FSdWBgMNMhEBExclVhcfCGweG00bLhcGEgs2LBQFHycMT0ZMeFhVV1hi", "xBxuw");
    lIllllIIIIIlIl[lIllllIIIIllII[95]] = llllllIIIlllllI("ihRGRazr/Nod6J79uE3/EzNn2ExMiDW5ZiX3WM/3h0RDqQqZ0WVR3g==", "YXKZv");
    lIllllIIIIIlIl[lIllllIIIIllII[96]] = llllllIIIllllll("Gx85QAIcFCgNHRQcOUAGAR8gQCYBHyA9GxQZJlQJHB8hCjBEQ31XXUIlLFRWT1ptTk8=", "uzMno");
    lIllllIIIIIlIl[lIllllIIIIllII[97]] = llllllIIIllllll("OwdLJAcjEgwjFzkFSzUbJkwDZkNmUlVnQ2ZSVWdDZlJVZ0NmUlVnVxsNATJJMQcRARI6FwBtW38uDzYFN00JNh0xTTYjAT8MAmxJdkI=", "VbeWs");
    lIllllIIIIIlIl[lIllllIIIIllII[98]] = llllllIIIllllIl("ryamJHAw+rlU1UI1kvSmFQXY0cHnwBuYTDglEM6RC273bATEpyzDvgCGmV4czlcw", "nRxvP");
    lIllllIIIIIlIl[lIllllIIIIllII[83]] = llllllIIIllllIl("9S2O/EDbVcpkUeGlgQplAB4q0Uf3L0t1mtFERiXPmQOqnbMDMdQPIcFwhCt05CRO7i0NW7tnm5WH2iZ2SFvAbX8e0Mis4zZ1TUquXokYi9h1m1PVXBKoqht+hK/B3kP9", "wNNXW");
    lIllllIIIIIlIl[lIllllIIIIllII[100]] = llllllIIIllllll("Jz1hOTM/KCY+IyU/YSgvOnYpenZwPyo+BSYtKnBvYxF1amc=", "JXOJG");
    lIllllIIIIIlIl[lIllllIIIIllII[88]] = llllllIIIllllIl("D4Mgo63tuoF7EOiqbR0yW3O5aJApUjMEvQUiVdAz4HtF/tfCo0pIUA==", "sRyJy");
    lIllllIIIIIlIl[lIllllIIIIllII[90]] = llllllIIIllllIl("5ApsrjZGirESjjeTESaad6l3Bbc5wNasu23dFWSHVVz2mUnLphqshtC/Xj7XXSCWv0HZS6wSRwG9OfQ4G4BU3ChLsMofQxai0ojIqT9EQw64oItC0jEg9g==", "oOxGs");
    lIllllIIIIIlIl[lIllllIIIIllII[94]] = llllllIIIllllll("OwEGRRQ8ChcICzQCBkUQIQEfRTAhAR8pFToHGVEfIAoRNEhiXUBZSgoASENQGQoXH1Y4DRwOGicFFB9WNwgdCBJ6Jh4EGj5fSEtZ", "Udrky");
    lIllllIIIIIlIl[lIllllIIIIllII[78]] = llllllIIIlllllI("QJ6R3q/TtYZpdpcPMsHmM9UaYeJoAEOXyt8aRM42a9R9oidhAi2i/v5a/qSE39Es19lv5lVEfEM=", "cUUcC");
    lIllllIIIIIlIl[lIllllIIIIllII[67]] = llllllIIIlllllI("0MIR8L1jMiSbPWsyfCN0nA7VaBQQSDAFVkC0nKT6wuk5xGklFl3Ccg==", "zssbf");
    lIllllIIIIIlIl[lIllllIIIIllII[71]] = llllllIIIllllll("DzAhRwoIOzAKFQAzIUcCDyE8HR5PJTkIHgQneywJFTwhEDcNNCwMFVszIAcEPmRiXVBYZAoNXUl8GQcCFXo4AAkENicIARV6IB0ODXo4CBMJegMMBFIxblNHQQ==", "aUUig");
    lIllllIIIIIlIl[lIllllIIIIllII[101]] = llllllIIIlllllI("oipdCClKJ2L6AApmWE1IBp7Be8jE3j0t06eIBv2WDR7jBZ6oafQD6BbH0Mpf69Vf", "PZoNi");
    lIllllIIIIIlIl[lIllllIIIIllII[102]] = llllllIIIllllIl("2fCaJp6sxp+H1lvQXMKLUrbvJ3oVjlDZMcTTWnz6ayzPJFVw7mk70Q==", "zjKcm");
    lIllllIIIIIlIl[lIllllIIIIllII[104]] = llllllIIIlllllI("fwbNOasMSxoFAAH//Y4JchXT3cC5ZhwN4XBicN9vuQnQMxqFXwx9UQ==", "IQgnQ");
    lIllllIIIIIlIl[lIllllIIIIllII[103]] = llllllIIIlllllI("sJJgw3EG/qWVpPanrMOOYfMgdvwTRNPUjKMhFV3D61ErvzTn9OSACKX4k1HxTAUB9e3qjh2I8ssxDSUPDG/pCQ==", "NbhQk");
    lIllllIIIIIlIl[lIllllIIIIllII[99]] = llllllIIIllllll("DC4MF1YTOxMaVi87HwQZEiAITBAHPDQTABJ1Ul8iXG9a", "fOzvx");
    lIllllIIIIIlIl[lIllllIIIIllII[105]] = llllllIIIllllIl("jWJljkSmoINJ7gb1PDdAS+QDdUXRcuRgEjQA+iCSd9pXhRwg9Z6mIg==", "wxYky");
    lIllllIIIIIlIl[lIllllIIIIllII[40]] = llllllIIIlllllI("yZAAyABWgh6hG/iP3mIuL3CI63iVCucJ62bwmKxcVVd2BvZFFt8TXUQUpGgpkgT2", "pgbpR");
    lIllllIIIIIlIl[lIllllIIIIllII[33]] = llllllIIIllllll("DT8iSxkKNDMGBgI8IksXDzMzCwBNFz8LEQAoNwMAWTw/ABgHBWFUQFdrCQBOUWtsRVRD", "cZVet");
    lIllllIIIIIlIl[lIllllIIIIllII[106]] = llllllIIIllllll("Kw1IBDUzGA8DJSkPSBUpNkYAR3d8GAoWIiMqChgiLVJOOy8jHEkaKCgNBQUgIBxJAjUvBEkaIDIASTUtKQsNJy41U08he2Y=", "FhfwA");
    lIllllIIIIIlIl[lIllllIIIIllII[107]] = llllllIIIllllll("HzUtZi8YPjwrMBA2LWY3BTk1ZgcfJTQOIxI5Ny94Ih8MHApLYW9yYlFweQ==", "qPYHB");
    lIllllIIIIIlIl[lIllllIIIIllII[108]] = llllllIIIllllIl("38CsAy4Ood5ORXOeJZEaNbIBZ78cGP0ZNGA15yPhTXLuz0VRGBnxVOgErDSt1aIBnN1/ZCqZeyc=", "XVSfK");
    lIllllIIIIIlIl[lIllllIIIIllII[109]] = llllllIIIllllIl("2VWkkuW3J9DMhi9nxhJB3aHEJUHSiQtWtuCO5zOaTqclcGjcU6kaOA==", "JXXHU");
    lIllllIIIIIlIl[lIllllIIIIllII[110]] = llllllIIIllllll("JAQcZz8jDw0qICsHHGcnPggEZxckFAUPMykIBi5oLBQGKg17Vl5+YX4+DHN6Yy0GLCZlDAEnNykTCS8mZRQcID5lJAY8PwwACyA8LVpSaXI=", "JahIR");
    lIllllIIIIIlIl[lIllllIIIIllII[111]] = llllllIIIlllllI("CtxV/0Cg/bxqcthyTb3aaPpkd3JrQ7tBUL2Y4s4GqOfWzz5r09XttRJghLTR/qHXwRLTHqyj/ogUiY0pHkHclyc/ZGfbz8nSezDfiqLMxugq0Kd2+zdGYQ==", "LLrOG");
    lIllllIIIIIlIl[lIllllIIIIllII[112]] = llllllIIIllllll("DyFgET4XNCcWLg0jYAAiEmooU3pSdH5SelJ0flJ6UnR+UnpSdH5SbiErIg04MSE6FiMMI3QFLxYSLw4/B35mSwYPIWERPhc0JxYuDSNhACISayhSe1l+bkI=", "bDNbJ");
    lIllllIIIIIlIl[lIllllIIIIllII[113]] = llllllIIIllllll("Kw5LPQ0zGww6HSkMSywRNkUDIEMlBAkhC3xeX25ZZg==", "FkeNy");
    lIllllIIIIIlIl[lIllllIIIIllII[114]] = llllllIIIllllll("GQ0cRBQeBg0JCxYOHEQcGRwBHgBZGAQLABIaRi8XAwEcEykbCREPC00OHQQaKFlZWkhDWzcLM01AQSxDV0g=", "whhjy");
    lIllllIIIIIlIl[lIllllIIIIllII[115]] = llllllIIIlllllI("Ygr8XequFjmdd9G+zXBginLsJM7TNjvMAjLKSFtoCnbwyw0OI3V9JQ==", "mqzqJ");
    lIllllIIIIIlIl[lIllllIIIIllII[116]] = llllllIIIllllIl("AzvgJYvL55tWrNpcFn2rCXgAnZrCASD4zuzggUrAGy/vtpCSFaeg83plToR2jyiRyic4Bto1vpQF9MFadgGx8qgzxN3kP112KKp3/CEkTtRy5mbEWh0b1K1iTBgFSZpienFPtO3AmtszbgZ07FUK/k4qwLZGCX3hR04b3Wh97rHYqJST9nPtg87s4IFKwBsvYid54bjpzFphd3FGAq3RbIJMe6qdHSIl/uM8A1+Ng5fBa+2KNzEwfiqeqg44Yv+cTirAtkYJfeG+ar84V06hnDehr1A7AMbmbZuQttMmIE2hge8L2G61qhouipFaurLB67PImRBPjNU5PZmVLR7YZoJMe6qdHSIl/uM8A1+Ng5enEyktMNx2JYPcmBjXLlQEKKp3/CEkTtSCYuyFctiSubWTPOQhP9TDOFXpPZU/NYA8bF5QZM3nng==", "uHkya");
    lIllllIIIIIlIl[lIllllIIIIllII[117]] = llllllIIIllllIl("SgY/d9Teg7kUJadSadFDnqUxIuEd0bmhTSu+h2X5ZePxzma9SRZRTYmX90mafG4SQkoF66ZlYh4QO33JoSCP1CJXwm/82JxGwH1hiN2Lu5w=", "CYmyO");
    lIllllIIIIIlIl[lIllllIIIIllII[118]] = llllllIIIllllll("CwYVajQMDQQnKwQFFWosEQoNahwLFgwCOAYKDyNjMiYyEGNUVVtkeUVD", "ecaDY");
    lIllllIIIIIlIl[lIllllIIIIllII[119]] = llllllIIIlllllI("ibSkC1BjHq+Bq2ZEda1NjWfW/nK3VkdT8j0kzCsDsmE=", "QiDLq");
    lIllllIIIIIlIl[lIllllIIIIllII[120]] = llllllIIIllllll("GAJJBDsAFw4DKxoASRUnBUkBGXUFCwYUKiEeFxJ1Rl1HV28=", "uggwO");
    lIllllIIIIIlIl[lIllllIIIIllII[121]] = llllllIIIllllll("CyZEIRETMwMmAQkkRDANFm0MPF8UJgQ2ABR5XmhFRmNKcg==", "fCjRe");
    lIllllIIIIIlIl[lIllllIIIIllII[122]] = llllllIIIllllIl("/Tf5kMDsQ/+9nGOlVzUawUZwyi5J2M4MDh5MS+j5JIkYxogxkOYRZWO8085/wM3J2U88QbBm73GDRTCx1Lktmg==", "expRY");
    lIllllIIIIIlIl[lIllllIIIIllII[123]] = llllllIIIllllll("FigXQyIRIwYOPRkrF0M6DCQPQyIZOQtDDRQiAAYfFz5ZCzoWLjxceE90VlsQF3dLRAZCbUM=", "xMcmO");
    lIllllIIIIIlIl[lIllllIIIIllII[124]] = llllllIIIllllll("NSNvMQItNig2EjchbyAeKGgnckdiISQ2JD0ie2pfEXxhYg==", "XFABv");
    lIllllIIIIIlIl[lIllllIIIIllII[125]] = llllllIIIlllllI("1Zv/yw77Wm2OGqKgaXhfv96Be6ZD1fCyhjTW/zr5fiLXvIfY4z7TvXtL54MaM9OIGZF8WSfMpLJ6GZz/i0MQ0V7AiwYvwyb43UnCKDaeGWeLmFwgbWm3IjKlKQ/tdFhJ", "huLQy");
    lIllllIIIIIlIl[lIllllIIIIllII[126]] = llllllIIIlllllI("yR6aIMcdkRNhHYYZac593gwgbEB3j1YM9cbBT1pU1znBjz8XYBY9LOWwMZa4CI6LFQ3WA+UEAl11+tv7s9gVlw==", "BMNVY");
    lIllllIIIIIlIl[lIllllIIIIllII[127]] = llllllIIIlllllI("PjFnaLaDYlbgSRcmRROQiAfDqLE3BTlgGRrIvfK3mBC94hLcgmfX7W60qkF4SdxIX89qocWZCiNQ8t3v1YqknMjJuumf9TM4vAoULuGZl5bDmlfBtt5Zv2EkJlFEuhOz7PfCX4kM1NE=", "izhTm");
    lIllllIIIIIlIl[lIllllIIIIllII[128]] = llllllIIIllllIl("G3IKBEupZmtbmj4lktD1nTwUnlZAeCvHz5RDfSuGoVhEOYEjPbb8tw==", "YlvYI");
    lIllllIIIIIlIl[lIllllIIIIllII[129]] = llllllIIIlllllI("QAFPuL1O5Gq/rdZkv9acvdqgjpOqnPdtk9vtq0DqMvS497oLsP0jiw==", "lyCTk");
    lIllllIIIIIlIl[lIllllIIIIllII[130]] = llllllIIIlllllI("k9WBjzfgQIulYcj9Ko395Hoz5oVT+pG/1+emWV3pUC5YFGsTkrzjaxKcnfWFEdcKEW/hXebisCqWDQoYogLCmNz3WVuZkgv5Cc1mOFS9lp4Rb+Fd5uKwKpYNChiiAsKYIKA8XqllD88SHec8FrXbq/pJyzz93rI+", "vkhHx");
    lIllllIIIIIlIl[lIllllIIIIllII[131]] = llllllIIIllllll("OicRXCA9LAARPzUkEVw4ICsJXCA1Ng1cDzgtBhkdOzFfFDg6ITpDemN7UEoSOnhNWwRuYkU=", "TBerM");
    lIllllIIIIIlIl[lIllllIIIIllII[132]] = llllllIIIllllll("NwF2PCUvFDE7NTUDdi05Kko+IWsqCDksNBcLPCpraV54b3F6RA==", "ZdXOQ");
    lIllllIIIIIlIl[lIllllIIIIllII[133]] = llllllIIIlllllI("b71RBrFkjYnD0jKjpC5L02n+9xepP0IL+at5FPJxb8BXBX0i7ZaFGQ==", "NRgDZ");
    lIllllIIIIIlIl[lIllllIIIIllII[134]] = llllllIIIllllll("LzZPJzc3IwggJy00TzYrMn0AIHkxNg8wDjc/FT0PKz0EGTAlaUkYKSMlAHsvIz0GexA2IQg6JHl6N25j", "BSaTC");
    lIllllIIIIIlIl[lIllllIIIIllII[135]] = llllllIIIlllllI("WvdANcofqaox8qrWA7Yhx1OlaY1dBT7UOfpr9hwaOxAR3z6AKAaNG2E6kJE3G+5tiFPrqhzLSaYhw/EDUBUvLuYBE4aF3EJgXfUxZQDJFR++14Dx2VD46JZuoVfiU6j9", "YwAxX");
    lIllllIIIIlIll = null;
  }
  
  private static void llllllIIlIIlIII() {
    String str = (new Exception()).getStackTrace()[lIllllIIIIllII[0]].getFileName();
    lIllllIIIIlIll = str.substring(str.indexOf("ä") + lIllllIIIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIIIllllIl(String lllllllllllllllIlllIIlllIIIlIlIl, String lllllllllllllllIlllIIlllIIIlIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlllIIIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlllIIIlIlII.getBytes(StandardCharsets.UTF_8)), lIllllIIIIllII[9]), "DES");
      Cipher lllllllllllllllIlllIIlllIIIlIlll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlllIIIlIlll.init(lIllllIIIIllII[2], lllllllllllllllIlllIIlllIIIllIII);
      return new String(lllllllllllllllIlllIIlllIIIlIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlllIIIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlllIIIlIllI) {
      lllllllllllllllIlllIIlllIIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIIllllll(String lllllllllllllllIlllIIlllIIIlIIlI, String lllllllllllllllIlllIIlllIIIlIIIl) {
    lllllllllllllllIlllIIlllIIIlIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlllIIIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlllIIIlIIII = new StringBuilder();
    char[] lllllllllllllllIlllIIlllIIIIllll = lllllllllllllllIlllIIlllIIIlIIIl.toCharArray();
    int lllllllllllllllIlllIIlllIIIIlllI = lIllllIIIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlllIIIlIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIIIllII[0];
    while (llllllIIlIIllll(j, i)) {
      char lllllllllllllllIlllIIlllIIIlIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlllIIIIlllI++;
      j++;
      "".length();
      if (((0x9A ^ 0x9F) << " ".length() & ((0xA9 ^ 0xAC) << " ".length() ^ 0xFFFFFFFF)) > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlllIIIlIIII);
  }
  
  private static String llllllIIIlllllI(String lllllllllllllllIlllIIlllIIIIlIlI, String lllllllllllllllIlllIIlllIIIIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlllIIIIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlllIIIIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlllIIIIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlllIIIIllII.init(lIllllIIIIllII[2], lllllllllllllllIlllIIlllIIIIllIl);
      return new String(lllllllllllllllIlllIIlllIIIIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlllIIIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlllIIIIlIll) {
      lllllllllllllllIlllIIlllIIIIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIlIIlllI() {
    lIllllIIIIllII = new int[137];
    lIllllIIIIllII[0] = (0x37 ^ 0x3A) << " ".length() << " ".length() & ((0xBE ^ 0xB3) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIllllIIIIllII[1] = " ".length();
    lIllllIIIIllII[2] = " ".length() << " ".length();
    lIllllIIIIllII[3] = -" ".length();
    lIllllIIIIllII[4] = "   ".length();
    lIllllIIIIllII[5] = " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[6] = 0xC1 ^ 0xC4;
    lIllllIIIIllII[7] = "   ".length() << " ".length();
    lIllllIIIIllII[8] = 0x3E ^ 0x59 ^ "   ".length() << (0xC3 ^ 0xC6);
    lIllllIIIIllII[9] = " ".length() << "   ".length();
    lIllllIIIIllII[10] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x47 ^ 0x7E;
    lIllllIIIIllII[11] = (0x95 ^ 0x90) << " ".length();
    lIllllIIIIllII[12] = 0xC5 ^ 0x84 ^ (0x4D ^ 0x68) << " ".length();
    lIllllIIIIllII[13] = "   ".length() << " ".length() << " ".length();
    lIllllIIIIllII[14] = (0x6A ^ 0x51) << " ".length() ^ 0x54 ^ 0x2F;
    lIllllIIIIllII[15] = (0x23 ^ 0x24) << " ".length();
    lIllllIIIIllII[16] = 57 + 57 - 87 + 132 ^ (0x70 ^ 0x79) << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[18] = 0x27 ^ 0x36;
    lIllllIIIIllII[19] = 165 + 204 - 174 + 60;
    lIllllIIIIllII[20] = (115 + 28 - -13 + 33 ^ (0x9A ^ 0xB7) << " ".length() << " ".length()) << " ".length();
    lIllllIIIIllII[21] = (0x3 ^ 0x2A) << " ".length() ^ 0xC8 ^ 0x89;
    lIllllIIIIllII[22] = (0xC4 ^ 0xC1) << " ".length() << " ".length();
    lIllllIIIIllII[23] = (0x70 ^ 0x7D) << " ".length() << " ".length() << " ".length() ^ 3 + 25 - -78 + 91;
    lIllllIIIIllII[24] = (0x79 ^ 0x72) << " ".length();
    lIllllIIIIllII[25] = 0x4 ^ 0x13;
    lIllllIIIIllII[26] = "   ".length() << "   ".length();
    lIllllIIIIllII[27] = (0xC6 ^ 0x87) << " ".length() ^ 110 + 134 - 167 + 78;
    lIllllIIIIllII[28] = (" ".length() << "   ".length() ^ 0x83 ^ 0x86) << " ".length();
    lIllllIIIIllII[29] = 0x16 ^ 0x19 ^ (0xA9 ^ 0xAC) << " ".length() << " ".length();
    lIllllIIIIllII[30] = (0x15 ^ 0x5C ^ (0x60 ^ 0x47) << " ".length()) << " ".length() << " ".length();
    lIllllIIIIllII[31] = 151 + 155 - 218 + 133 ^ "   ".length() << "   ".length() << " ".length();
    lIllllIIIIllII[32] = ((0xA ^ 0x25) << " ".length() ^ 0xED ^ 0xBC) << " ".length();
    lIllllIIIIllII[33] = 0x33 ^ 0x54;
    lIllllIIIIllII[34] = 0x63 ^ 0x7C;
    lIllllIIIIllII[35] = 0x2B ^ 0x60;
    lIllllIIIIllII[36] = " ".length() << (0x0 ^ 0x5);
    lIllllIIIIllII[37] = (0x7 ^ 0x8) << " ".length() << " ".length();
    lIllllIIIIllII[38] = 0x12 ^ 0x33;
    lIllllIIIIllII[39] = (0x9C ^ 0x8D) << " ".length();
    lIllllIIIIllII[40] = (13 + 110 - 22 + 68 ^ (0xD3 ^ 0x9E) << " ".length()) << " ".length();
    lIllllIIIIllII[41] = (0x66 ^ 0x7F) << " ".length() ^ 0x7F ^ 0x6E;
    lIllllIIIIllII[42] = 0xD6 ^ 0x9B;
    lIllllIIIIllII[43] = (0xAF ^ 0xA6) << " ".length() << " ".length();
    lIllllIIIIllII[44] = 0xB0 ^ 0x85;
    lIllllIIIIllII[45] = 0xB2 ^ 0xBB ^ (0xBD ^ 0xB6) << " ".length() << " ".length();
    lIllllIIIIllII[46] = 0x19 ^ 0x2A;
    lIllllIIIIllII[47] = (0x87 ^ 0x94) << " ".length();
    lIllllIIIIllII[48] = 0x25 ^ 0x2;
    lIllllIIIIllII[49] = ((0x7D ^ 0x30) << " ".length() ^ 62 + 63 - -3 + 31) << "   ".length();
    lIllllIIIIllII[50] = 0x81 ^ 0xA8;
    lIllllIIIIllII[51] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0x5D ^ 0x58) << " ".length();
    lIllllIIIIllII[52] = 0x41 ^ 0x6A;
    lIllllIIIIllII[53] = (0x65 ^ 0x62 ^ "   ".length() << " ".length() << " ".length()) << " ".length() << " ".length();
    lIllllIIIIllII[54] = 0x7F ^ 0x42 ^ " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[55] = (0xBC ^ 0xBB) << "   ".length();
    lIllllIIIIllII[56] = (0x5 ^ 0x12) << " ".length();
    lIllllIIIIllII[57] = 0x61 ^ 0x2E;
    lIllllIIIIllII[58] = (0xEE ^ 0x9B) << " ".length() ^ 162 + 5 - 81 + 111;
    lIllllIIIIllII[59] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[60] = 0x43 ^ 0x72;
    lIllllIIIIllII[61] = (0x59 ^ 0x40) << " ".length();
    lIllllIIIIllII[62] = ((0x8B ^ 0xAA) << " ".length() ^ 0xD4 ^ 0xB7) << " ".length();
    lIllllIIIIllII[63] = (0x78 ^ 0x75) << " ".length() << " ".length();
    lIllllIIIIllII[64] = ((0x66 ^ 0x47) << " ".length() ^ 0x42 ^ 0x1B) << " ".length();
    lIllllIIIIllII[65] = (0x14 ^ 0x3) << " ".length() ^ 0x54 ^ 0x3B;
    lIllllIIIIllII[66] = 0x3F ^ 0x8;
    lIllllIIIIllII[67] = (0x2E ^ 0x1) << " ".length();
    lIllllIIIIllII[68] = 0xBB ^ 0x82;
    lIllllIIIIllII[69] = ((0x37 ^ 0x2A) << " ".length() ^ 0x14 ^ 0x33) << " ".length();
    lIllllIIIIllII[70] = 0xB1 ^ 0xAC ^ (0x3E ^ 0x2D) << " ".length();
    lIllllIIIIllII[71] = 89 + 63 - 31 + 96 ^ (0xE2 ^ 0xA1) << " ".length();
    lIllllIIIIllII[72] = 0xF ^ 0x18 ^ (0x93 ^ 0x86) << " ".length();
    lIllllIIIIllII[73] = (0x9D ^ 0x82) << " ".length();
    lIllllIIIIllII[74] = 0x55 ^ 0x6A;
    lIllllIIIIllII[75] = (81 + 135 - 154 + 99 ^ (0x4B ^ 0xA) << " ".length()) << " ".length();
    lIllllIIIIllII[76] = " ".length() << "   ".length() << " ".length();
    lIllllIIIIllII[77] = 0x71 ^ 0x40 ^ "   ".length() << (0x8C ^ 0x89);
    lIllllIIIIllII[78] = 136 + 55 - 22 + 84 ^ (0x63 ^ 0x66) << (0x69 ^ 0x6C);
    lIllllIIIIllII[79] = (0x5A ^ 0x5F) << " ".length() << " ".length() ^ 0x73 ^ 0x24;
    lIllllIIIIllII[80] = (0x34 ^ 0x25) << " ".length() << " ".length();
    lIllllIIIIllII[81] = 0x38 ^ 0x7D;
    lIllllIIIIllII[82] = 0xF ^ 0x26 ^ (0x80 ^ 0xB7) << " ".length();
    lIllllIIIIllII[83] = (0x4D ^ 0x46) << "   ".length();
    lIllllIIIIllII[84] = (0x8C ^ 0x85) << "   ".length();
    lIllllIIIIllII[85] = 0x3C ^ 0x75;
    lIllllIIIIllII[86] = (0x9C ^ 0xB9) << " ".length();
    lIllllIIIIllII[87] = (0x1A ^ 0x9) << " ".length() << " ".length();
    lIllllIIIIllII[88] = (0xAC ^ 0x81) << " ".length();
    lIllllIIIIllII[89] = ((0x5B ^ 0x54) << "   ".length() ^ 0x60 ^ 0x3F) << " ".length();
    lIllllIIIIllII[90] = 0x5B ^ 0x0;
    lIllllIIIIllII[91] = (0x33 ^ 0x36) << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[92] = (61 + 58 - 92 + 110 ^ (0x9F ^ 0x9A) << (0x94 ^ 0x91)) << " ".length();
    lIllllIIIIllII[93] = 0x1D ^ 0x4E;
    lIllllIIIIllII[94] = (" ".length() << " ".length() << " ".length() ^ 0x2E ^ 0x3D) << " ".length() << " ".length();
    lIllllIIIIllII[95] = (0x38 ^ 0x2D) << " ".length() << " ".length();
    lIllllIIIIllII[96] = "   ".length() ^ (0x40 ^ 0x6B) << " ".length();
    lIllllIIIIllII[97] = (60 + 146 - 41 + 20 ^ (0xC1 ^ 0x88) << " ".length()) << " ".length();
    lIllllIIIIllII[98] = 0x49 ^ 0x1E;
    lIllllIIIIllII[99] = (111 + 75 - 168 + 111 ^ (0x72 ^ 0x61) << "   ".length()) << " ".length() << " ".length();
    lIllllIIIIllII[100] = 0xD2 ^ 0x8B;
    lIllllIIIIllII[101] = "   ".length() << (0x79 ^ 0x7C);
    lIllllIIIIllII[102] = (0xC ^ 0x13) << " ".length() ^ 0x58 ^ 0x7;
    lIllllIIIIllII[103] = 0x72 ^ 0x11;
    lIllllIIIIllII[104] = ((0x29 ^ 0x10) << " ".length() ^ 0x79 ^ 0x3A) << " ".length();
    lIllllIIIIllII[105] = 0xF1 ^ 0x94;
    lIllllIIIIllII[106] = (0x6C ^ 0x71 ^ " ".length() << " ".length() << " ".length() << " ".length()) << "   ".length();
    lIllllIIIIllII[107] = 0x68 ^ 0x1;
    lIllllIIIIllII[108] = (0x30 ^ 0x5) << " ".length();
    lIllllIIIIllII[109] = 0x52 ^ 0x39;
    lIllllIIIIllII[110] = (0x47 ^ 0x20 ^ (0x61 ^ 0x7E) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIllllIIIIllII[111] = 49 + 11 - 45 + 216 ^ (0x7E ^ 0x3B) << " ".length();
    lIllllIIIIllII[112] = ((0x8D ^ 0x88) << "   ".length() ^ 0x29 ^ 0x36) << " ".length();
    lIllllIIIIllII[113] = 0x39 ^ 0x16 ^ " ".length() << "   ".length() << " ".length();
    lIllllIIIIllII[114] = (0x41 ^ 0x74 ^ (0xB8 ^ 0xA1) << " ".length()) << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[115] = (0x54 ^ 0x69) << " ".length() << " ".length() ^ 108 + 96 - 107 + 36;
    lIllllIIIIllII[116] = (0x9B ^ 0x82 ^ " ".length() << (0x87 ^ 0x82)) << " ".length();
    lIllllIIIIllII[117] = 0xDD ^ 0xAE;
    lIllllIIIIllII[118] = (0x23 ^ 0x24 ^ (0x6 ^ 0xB) << " ".length()) << " ".length() << " ".length();
    lIllllIIIIllII[119] = 0x54 ^ 0x21;
    lIllllIIIIllII[120] = (0x4A ^ 0x71) << " ".length();
    lIllllIIIIllII[121] = 0x15 ^ 0x12 ^ (0x41 ^ 0x46) << " ".length() << " ".length() << " ".length();
    lIllllIIIIllII[122] = ((0x1F ^ 0x54) << " ".length() ^ 141 + 61 - 80 + 31) << "   ".length();
    lIllllIIIIllII[123] = 191 + 1 - 179 + 238 ^ (0xF5 ^ 0xB4) << " ".length();
    lIllllIIIIllII[124] = (0xAF ^ 0x92) << " ".length();
    lIllllIIIIllII[125] = (0x91 ^ 0x9E) << " ".length() << " ".length() ^ 0x24 ^ 0x63;
    lIllllIIIIllII[126] = (0x86 ^ 0x99) << " ".length() << " ".length();
    lIllllIIIIllII[127] = 0xEC ^ 0x91;
    lIllllIIIIllII[128] = (131 + 57 - 48 + 7 ^ (0xED ^ 0xC6) << " ".length() << " ".length()) << " ".length();
    lIllllIIIIllII[129] = (" ".length() << " ".length() << " ".length() << " ".length()) + (0x65 ^ 0x26) - ((0x5 ^ 0xC) << "   ".length()) + ((0x50 ^ 0x4D) << " ".length() << " ".length());
    lIllllIIIIllII[130] = " ".length() << ((0x5B ^ 0x54) << " ".length() ^ 0x1F ^ 0x6);
    lIllllIIIIllII[131] = ((0x4D ^ 0x7C) << " ".length()) + (0x7 ^ 0x18) - ((0x4 ^ 0x21) << " ".length()) + ((0x85 ^ 0xA0) << " ".length());
    lIllllIIIIllII[132] = (0x5D ^ 0x1C) << " ".length();
    lIllllIIIIllII[133] = ((0xBE ^ 0xA9) << " ".length()) + ((0x92 ^ 0xB7) << " ".length()) - ((0xA9 ^ 0x9C) << " ".length()) + (0xB0 ^ 0xC5);
    lIllllIIIIllII[134] = (0xB4 ^ 0x95) << " ".length() << " ".length();
    lIllllIIIIllII[135] = 90 + 25 - 44 + 58 + (0x53 ^ 0xE) - 203 + 94 - 169 + 77 + ((0xD9 ^ 0xC4) << " ".length() << " ".length());
    lIllllIIIIllII[136] = (0x98 ^ 0xA3 ^ (0xC8 ^ 0xC7) << "   ".length()) << " ".length();
  }
  
  private static boolean llllllIIlIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIIlIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIIlIlllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllIIlIlIIIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean llllllIIlIlIIll(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllllIIlIlIlIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllllIIlIlIllI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean llllllIIlIlIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllllIIlIlIIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean llllllIIlIllIll(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean llllllIIlIllIlI(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean llllllIIlIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int llllllIIlIllIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int llllllIIlIllIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */