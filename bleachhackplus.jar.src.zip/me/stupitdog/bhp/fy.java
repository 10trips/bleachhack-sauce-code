package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;

public class fy extends au {
  f100000000000000000000.Boolean cancelPackets;
  
  f100000000000000000000.Double speed;
  
  private double posX;
  
  private double posY;
  
  private double posZ;
  
  private float pitch;
  
  private float yaw;
  
  private EntityOtherPlayerMP clonedPlayer;
  
  private boolean isRidingEntity;
  
  private Entity ridingEntity;
  
  @EventHandler
  private final Listener<f10000000000000> moveListener;
  
  @EventHandler
  private final Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
  
  @EventHandler
  private final Listener<f100000000000.Send> sendListener;
  
  private static String[] llIIIlIIIIlIII;
  
  private static Class[] llIIIlIIIIlIIl;
  
  private static final String[] llIIIlllIllIll;
  
  private static String[] llIIIllllIIllI;
  
  private static final int[] llIIIllllIIlll;
  
  public fy() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fy.llIIIlllIllIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fy.llIIIlllIllIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fy.llIIIlllIllIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: putfield moveListener : Lme/zero/alpine/listener/Listener;
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   75: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   78: iconst_0
    //   79: iaload
    //   80: anewarray java/util/function/Predicate
    //   83: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   86: putfield pushListener : Lme/zero/alpine/listener/Listener;
    //   89: aload_0
    //   90: new me/zero/alpine/listener/Listener
    //   93: dup
    //   94: aload_0
    //   95: <illegal opcode> invoke : (Lme/stupitdog/bhp/fy;)Lme/zero/alpine/listener/EventHook;
    //   100: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   103: iconst_0
    //   104: iaload
    //   105: anewarray java/util/function/Predicate
    //   108: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   111: putfield sendListener : Lme/zero/alpine/listener/Listener;
    //   114: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	115	0	lllllllllllllllIllIlIIIIlIIllllI	Lme/stupitdog/bhp/fy;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/fy.llIIIlllIllIll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   14: iconst_1
    //   15: iaload
    //   16: <illegal opcode> 1 : (Lme/stupitdog/bhp/fy;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   21: <illegal opcode> 2 : (Lme/stupitdog/bhp/fy;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   26: aload_0
    //   27: aload_0
    //   28: getstatic me/stupitdog/bhp/fy.llIIIlllIllIll : [Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   34: iconst_4
    //   35: iaload
    //   36: aaload
    //   37: ldc2_w 10.0
    //   40: dconst_0
    //   41: ldc2_w 20.0
    //   44: <illegal opcode> 3 : (Lme/stupitdog/bhp/fy;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   49: <illegal opcode> 4 : (Lme/stupitdog/bhp/fy;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   54: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	55	0	lllllllllllllllIllIlIIIIlIIlllIl	Lme/stupitdog/bhp/fy;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIlIllIIllIIl : (Ljava/lang/Object;)Z
    //   13: ifeq -> 526
    //   16: aload_0
    //   17: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   32: invokestatic lIIIIlIllIIllIIl : (Ljava/lang/Object;)Z
    //   35: ifeq -> 89
    //   38: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   41: iconst_1
    //   42: iaload
    //   43: ldc ''
    //   45: invokevirtual length : ()I
    //   48: pop
    //   49: bipush #36
    //   51: bipush #41
    //   53: ixor
    //   54: ldc ' '
    //   56: invokevirtual length : ()I
    //   59: ldc ' '
    //   61: invokevirtual length : ()I
    //   64: ishl
    //   65: ishl
    //   66: iconst_0
    //   67: bipush #13
    //   69: ixor
    //   70: ldc ' '
    //   72: invokevirtual length : ()I
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ishl
    //   81: ishl
    //   82: iconst_m1
    //   83: ixor
    //   84: iand
    //   85: ifeq -> 94
    //   88: return
    //   89: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   92: iconst_0
    //   93: iaload
    //   94: <illegal opcode> 8 : (Lme/stupitdog/bhp/fy;Z)V
    //   99: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   104: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   109: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   114: invokestatic lIIIIlIllIIllIlI : (Ljava/lang/Object;)Z
    //   117: ifeq -> 262
    //   120: aload_0
    //   121: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   126: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   131: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   136: <illegal opcode> 10 : (Lme/stupitdog/bhp/fy;D)V
    //   141: aload_0
    //   142: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   147: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   152: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   157: <illegal opcode> 12 : (Lme/stupitdog/bhp/fy;D)V
    //   162: aload_0
    //   163: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   168: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   173: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   178: <illegal opcode> 14 : (Lme/stupitdog/bhp/fy;D)V
    //   183: ldc ''
    //   185: invokevirtual length : ()I
    //   188: pop
    //   189: bipush #85
    //   191: bipush #92
    //   193: ixor
    //   194: ldc ' '
    //   196: invokevirtual length : ()I
    //   199: ishl
    //   200: sipush #152
    //   203: sipush #141
    //   206: ixor
    //   207: ixor
    //   208: ldc '   '
    //   210: invokevirtual length : ()I
    //   213: ishl
    //   214: bipush #103
    //   216: bipush #98
    //   218: ixor
    //   219: ldc '   '
    //   221: invokevirtual length : ()I
    //   224: ishl
    //   225: sipush #186
    //   228: sipush #149
    //   231: ixor
    //   232: ixor
    //   233: ldc '   '
    //   235: invokevirtual length : ()I
    //   238: ishl
    //   239: ldc ' '
    //   241: invokevirtual length : ()I
    //   244: ineg
    //   245: ixor
    //   246: iand
    //   247: ldc ' '
    //   249: invokevirtual length : ()I
    //   252: ldc ' '
    //   254: invokevirtual length : ()I
    //   257: ishl
    //   258: if_icmplt -> 298
    //   261: return
    //   262: aload_0
    //   263: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   268: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   273: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   278: <illegal opcode> 15 : (Lme/stupitdog/bhp/fy;Lnet/minecraft/entity/Entity;)V
    //   283: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   288: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   293: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   298: aload_0
    //   299: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   304: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   309: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   314: <illegal opcode> 18 : (Lme/stupitdog/bhp/fy;F)V
    //   319: aload_0
    //   320: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   325: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   330: <illegal opcode> 19 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   335: <illegal opcode> 20 : (Lme/stupitdog/bhp/fy;F)V
    //   340: aload_0
    //   341: new net/minecraft/client/entity/EntityOtherPlayerMP
    //   344: dup
    //   345: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   350: <illegal opcode> 21 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   355: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   360: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Session;
    //   365: <illegal opcode> 23 : (Lnet/minecraft/util/Session;)Lcom/mojang/authlib/GameProfile;
    //   370: invokespecial <init> : (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
    //   373: <illegal opcode> 24 : (Lme/stupitdog/bhp/fy;Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   378: aload_0
    //   379: <illegal opcode> 25 : (Lme/stupitdog/bhp/fy;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   384: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   389: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   394: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;Lnet/minecraft/entity/Entity;)V
    //   399: aload_0
    //   400: <illegal opcode> 25 : (Lme/stupitdog/bhp/fy;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   405: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   410: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   415: <illegal opcode> 27 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   420: putfield field_70759_as : F
    //   423: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   428: <illegal opcode> 21 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   433: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   436: iconst_5
    //   437: iaload
    //   438: aload_0
    //   439: <illegal opcode> 25 : (Lme/stupitdog/bhp/fy;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   444: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;ILnet/minecraft/entity/Entity;)V
    //   449: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   454: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   459: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   464: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   467: iconst_1
    //   468: iaload
    //   469: putfield field_75100_b : Z
    //   472: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   477: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   482: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   487: aload_0
    //   488: <illegal opcode> 30 : (Lme/stupitdog/bhp/fy;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   493: <illegal opcode> 31 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   498: ldc2_w 100.0
    //   501: ddiv
    //   502: d2f
    //   503: <illegal opcode> 32 : (Lnet/minecraft/entity/player/PlayerCapabilities;F)V
    //   508: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   513: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   518: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   521: iconst_1
    //   522: iaload
    //   523: putfield field_70145_X : Z
    //   526: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	527	0	lllllllllllllllIllIlIIIIlIIlllII	Lme/stupitdog/bhp/fy;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: astore_1
    //   11: aload_1
    //   12: invokestatic lIIIIlIllIIllIIl : (Ljava/lang/Object;)Z
    //   15: ifeq -> 281
    //   18: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   23: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   28: aload_0
    //   29: <illegal opcode> 33 : (Lme/stupitdog/bhp/fy;)D
    //   34: aload_0
    //   35: <illegal opcode> 34 : (Lme/stupitdog/bhp/fy;)D
    //   40: aload_0
    //   41: <illegal opcode> 35 : (Lme/stupitdog/bhp/fy;)D
    //   46: aload_0
    //   47: <illegal opcode> 36 : (Lme/stupitdog/bhp/fy;)F
    //   52: aload_0
    //   53: <illegal opcode> 37 : (Lme/stupitdog/bhp/fy;)F
    //   58: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDDFF)V
    //   63: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   68: <illegal opcode> 21 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   73: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   76: iconst_5
    //   77: iaload
    //   78: <illegal opcode> 39 : (Lnet/minecraft/client/multiplayer/WorldClient;I)Lnet/minecraft/entity/Entity;
    //   83: ldc ''
    //   85: invokevirtual length : ()I
    //   88: pop2
    //   89: aload_0
    //   90: aconst_null
    //   91: <illegal opcode> 24 : (Lme/stupitdog/bhp/fy;Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   96: aload_0
    //   97: aload_0
    //   98: aload_0
    //   99: dconst_0
    //   100: dup2_x1
    //   101: <illegal opcode> 14 : (Lme/stupitdog/bhp/fy;D)V
    //   106: dup2_x1
    //   107: <illegal opcode> 12 : (Lme/stupitdog/bhp/fy;D)V
    //   112: <illegal opcode> 10 : (Lme/stupitdog/bhp/fy;D)V
    //   117: aload_0
    //   118: aload_0
    //   119: fconst_0
    //   120: dup_x1
    //   121: <illegal opcode> 20 : (Lme/stupitdog/bhp/fy;F)V
    //   126: <illegal opcode> 18 : (Lme/stupitdog/bhp/fy;F)V
    //   131: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   136: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   141: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   146: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   149: iconst_0
    //   150: iaload
    //   151: putfield field_75100_b : Z
    //   154: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   159: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   164: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   169: ldc_w 0.05
    //   172: <illegal opcode> 32 : (Lnet/minecraft/entity/player/PlayerCapabilities;F)V
    //   177: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   182: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   187: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   190: iconst_0
    //   191: iaload
    //   192: putfield field_70145_X : Z
    //   195: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   200: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   205: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   210: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   215: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   220: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   225: dconst_0
    //   226: dup2_x1
    //   227: putfield field_70179_y : D
    //   230: dup2_x1
    //   231: putfield field_70181_x : D
    //   234: putfield field_70159_w : D
    //   237: aload_0
    //   238: <illegal opcode> 40 : (Lme/stupitdog/bhp/fy;)Z
    //   243: invokestatic lIIIIlIllIIllIll : (I)Z
    //   246: ifeq -> 281
    //   249: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   254: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   259: aload_0
    //   260: <illegal opcode> 41 : (Lme/stupitdog/bhp/fy;)Lnet/minecraft/entity/Entity;
    //   265: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   268: iconst_1
    //   269: iaload
    //   270: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;Z)Z
    //   275: ldc ''
    //   277: invokevirtual length : ()I
    //   280: pop2
    //   281: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	282	0	lllllllllllllllIllIlIIIIlIIllIll	Lme/stupitdog/bhp/fy;
    //   11	271	1	lllllllllllllllIllIlIIIIlIIllIlI	Lnet/minecraft/entity/player/EntityPlayer;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   15: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   18: iconst_1
    //   19: iaload
    //   20: putfield field_75100_b : Z
    //   23: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   28: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   33: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   38: aload_0
    //   39: <illegal opcode> 30 : (Lme/stupitdog/bhp/fy;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   44: <illegal opcode> 31 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   49: ldc2_w 100.0
    //   52: ddiv
    //   53: d2f
    //   54: <illegal opcode> 32 : (Lnet/minecraft/entity/player/PlayerCapabilities;F)V
    //   59: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   64: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   69: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   72: iconst_1
    //   73: iaload
    //   74: putfield field_70145_X : Z
    //   77: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   82: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   87: getstatic me/stupitdog/bhp/fy.llIIIllllIIlll : [I
    //   90: iconst_0
    //   91: iaload
    //   92: putfield field_70122_E : Z
    //   95: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   100: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   105: fconst_0
    //   106: putfield field_70143_R : F
    //   109: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	110	0	lllllllllllllllIllIlIIIIlIIllIIl	Lme/stupitdog/bhp/fy;
  }
  
  static {
    lIIIIlIllIIllIII();
    lIIIIlIllIIlIlll();
    lIIIIlIllIIlIllI();
    lIIIIlIllIIIllll();
  }
  
  private static CallSite lIIIIIlllIIlIlll(MethodHandles.Lookup lllllllllllllllIllIlIIIIlIIIllII, String lllllllllllllllIllIlIIIIlIIIlIll, MethodType lllllllllllllllIllIlIIIIlIIIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIIIlIIlIIlI = llIIIlIIIIlIII[Integer.parseInt(lllllllllllllllIllIlIIIIlIIIlIll)].split(llIIIlllIllIll[llIIIllllIIlll[6]]);
      Class<?> lllllllllllllllIllIlIIIIlIIlIIIl = Class.forName(lllllllllllllllIllIlIIIIlIIlIIlI[llIIIllllIIlll[0]]);
      String lllllllllllllllIllIlIIIIlIIlIIII = lllllllllllllllIllIlIIIIlIIlIIlI[llIIIllllIIlll[1]];
      MethodHandle lllllllllllllllIllIlIIIIlIIIllll = null;
      int lllllllllllllllIllIlIIIIlIIIlllI = lllllllllllllllIllIlIIIIlIIlIIlI[llIIIllllIIlll[3]].length();
      if (lIIIIlIllIIlllIl(lllllllllllllllIllIlIIIIlIIIlllI, llIIIllllIIlll[2])) {
        MethodType lllllllllllllllIllIlIIIIlIIlIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIIIlIIlIIlI[llIIIllllIIlll[2]], fy.class.getClassLoader());
        if (lIIIIlIllIIllllI(lllllllllllllllIllIlIIIIlIIIlllI, llIIIllllIIlll[2])) {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findVirtual(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIlII);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findStatic(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIlII);
        } 
        "".length();
        if (" ".length() < -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIIIlIIlIIll = llIIIlIIIIlIIl[Integer.parseInt(lllllllllllllllIllIlIIIIlIIlIIlI[llIIIllllIIlll[2]])];
        if (lIIIIlIllIIllllI(lllllllllllllllIllIlIIIIlIIIlllI, llIIIllllIIlll[3])) {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findGetter(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIIll);
          "".length();
          if (" ".length() < -" ".length())
            return null; 
        } else if (lIIIIlIllIIllllI(lllllllllllllllIllIlIIIIlIIIlllI, llIIIllllIIlll[4])) {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findStaticGetter(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIIll);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIllIIllllI(lllllllllllllllIllIlIIIIlIIIlllI, llIIIllllIIlll[6])) {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findSetter(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIIll);
          "".length();
          if ("   ".length() < -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIIIlIIIllll = lllllllllllllllIllIlIIIIlIIIllII.findStaticSetter(lllllllllllllllIllIlIIIIlIIlIIIl, lllllllllllllllIllIlIIIIlIIlIIII, lllllllllllllllIllIlIIIIlIIlIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIIIlIIIllll);
    } catch (Exception lllllllllllllllIllIlIIIIlIIIllIl) {
      lllllllllllllllIllIlIIIIlIIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllIIIllll() {
    llIIIlIIIIlIII = new String[llIIIllllIIlll[7]];
    llIIIlIIIIlIII[llIIIllllIIlll[0]] = llIIIlllIllIll[llIIIllllIIlll[8]];
    llIIIlIIIIlIII[llIIIllllIIlll[9]] = llIIIlllIllIll[llIIIllllIIlll[10]];
    llIIIlIIIIlIII[llIIIllllIIlll[11]] = llIIIlllIllIll[llIIIllllIIlll[12]];
    llIIIlIIIIlIII[llIIIllllIIlll[13]] = llIIIlllIllIll[llIIIllllIIlll[14]];
    llIIIlIIIIlIII[llIIIllllIIlll[15]] = llIIIlllIllIll[llIIIllllIIlll[16]];
    llIIIlIIIIlIII[llIIIllllIIlll[17]] = llIIIlllIllIll[llIIIllllIIlll[13]];
    llIIIlIIIIlIII[llIIIllllIIlll[18]] = llIIIlllIllIll[llIIIllllIIlll[19]];
    llIIIlIIIIlIII[llIIIllllIIlll[20]] = llIIIlllIllIll[llIIIllllIIlll[21]];
    llIIIlIIIIlIII[llIIIllllIIlll[22]] = llIIIlllIllIll[llIIIllllIIlll[23]];
    llIIIlIIIIlIII[llIIIllllIIlll[24]] = llIIIlllIllIll[llIIIllllIIlll[25]];
    llIIIlIIIIlIII[llIIIllllIIlll[19]] = llIIIlllIllIll[llIIIllllIIlll[26]];
    llIIIlIIIIlIII[llIIIllllIIlll[27]] = llIIIlllIllIll[llIIIllllIIlll[17]];
    llIIIlIIIIlIII[llIIIllllIIlll[28]] = llIIIlllIllIll[llIIIllllIIlll[29]];
    llIIIlIIIIlIII[llIIIllllIIlll[25]] = llIIIlllIllIll[llIIIllllIIlll[30]];
    llIIIlIIIIlIII[llIIIllllIIlll[31]] = llIIIlllIllIll[llIIIllllIIlll[27]];
    llIIIlIIIIlIII[llIIIllllIIlll[4]] = llIIIlllIllIll[llIIIllllIIlll[32]];
    llIIIlIIIIlIII[llIIIllllIIlll[6]] = llIIIlllIllIll[llIIIllllIIlll[33]];
    llIIIlIIIIlIII[llIIIllllIIlll[34]] = llIIIlllIllIll[llIIIllllIIlll[35]];
    llIIIlIIIIlIII[llIIIllllIIlll[1]] = llIIIlllIllIll[llIIIllllIIlll[36]];
    llIIIlIIIIlIII[llIIIllllIIlll[23]] = llIIIlllIllIll[llIIIllllIIlll[37]];
    llIIIlIIIIlIII[llIIIllllIIlll[33]] = llIIIlllIllIll[llIIIllllIIlll[38]];
    llIIIlIIIIlIII[llIIIllllIIlll[39]] = llIIIlllIllIll[llIIIllllIIlll[11]];
    llIIIlIIIIlIII[llIIIllllIIlll[8]] = llIIIlllIllIll[llIIIllllIIlll[24]];
    llIIIlIIIIlIII[llIIIllllIIlll[26]] = llIIIlllIllIll[llIIIllllIIlll[9]];
    llIIIlIIIIlIII[llIIIllllIIlll[14]] = llIIIlllIllIll[llIIIllllIIlll[18]];
    llIIIlIIIIlIII[llIIIllllIIlll[38]] = llIIIlllIllIll[llIIIllllIIlll[28]];
    llIIIlIIIIlIII[llIIIllllIIlll[40]] = llIIIlllIllIll[llIIIllllIIlll[41]];
    llIIIlIIIIlIII[llIIIllllIIlll[3]] = llIIIlllIllIll[llIIIllllIIlll[42]];
    llIIIlIIIIlIII[llIIIllllIIlll[12]] = llIIIlllIllIll[llIIIllllIIlll[43]];
    llIIIlIIIIlIII[llIIIllllIIlll[32]] = llIIIlllIllIll[llIIIllllIIlll[34]];
    llIIIlIIIIlIII[llIIIllllIIlll[16]] = llIIIlllIllIll[llIIIllllIIlll[44]];
    llIIIlIIIIlIII[llIIIllllIIlll[2]] = llIIIlllIllIll[llIIIllllIIlll[45]];
    llIIIlIIIIlIII[llIIIllllIIlll[46]] = llIIIlllIllIll[llIIIllllIIlll[47]];
    llIIIlIIIIlIII[llIIIllllIIlll[47]] = llIIIlllIllIll[llIIIllllIIlll[31]];
    llIIIlIIIIlIII[llIIIllllIIlll[45]] = llIIIlllIllIll[llIIIllllIIlll[15]];
    llIIIlIIIIlIII[llIIIllllIIlll[48]] = llIIIlllIllIll[llIIIllllIIlll[22]];
    llIIIlIIIIlIII[llIIIllllIIlll[30]] = llIIIlllIllIll[llIIIllllIIlll[39]];
    llIIIlIIIIlIII[llIIIllllIIlll[41]] = llIIIlllIllIll[llIIIllllIIlll[40]];
    llIIIlIIIIlIII[llIIIllllIIlll[43]] = llIIIlllIllIll[llIIIllllIIlll[46]];
    llIIIlIIIIlIII[llIIIllllIIlll[37]] = llIIIlllIllIll[llIIIllllIIlll[20]];
    llIIIlIIIIlIII[llIIIllllIIlll[29]] = llIIIlllIllIll[llIIIllllIIlll[49]];
    llIIIlIIIIlIII[llIIIllllIIlll[21]] = llIIIlllIllIll[llIIIllllIIlll[48]];
    llIIIlIIIIlIII[llIIIllllIIlll[35]] = llIIIlllIllIll[llIIIllllIIlll[7]];
    llIIIlIIIIlIII[llIIIllllIIlll[10]] = llIIIlllIllIll[llIIIllllIIlll[50]];
    llIIIlIIIIlIII[llIIIllllIIlll[44]] = llIIIlllIllIll[llIIIllllIIlll[51]];
    llIIIlIIIIlIII[llIIIllllIIlll[36]] = llIIIlllIllIll[llIIIllllIIlll[52]];
    llIIIlIIIIlIII[llIIIllllIIlll[42]] = llIIIlllIllIll[llIIIllllIIlll[53]];
    llIIIlIIIIlIII[llIIIllllIIlll[49]] = llIIIlllIllIll[llIIIllllIIlll[54]];
    llIIIlIIIIlIIl = new Class[llIIIllllIIlll[21]];
    llIIIlIIIIlIIl[llIIIllllIIlll[13]] = EntityOtherPlayerMP.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[1]] = Listener.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[16]] = WorldClient.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[0]] = f13.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[4]] = Minecraft.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[19]] = PlayerCapabilities.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[8]] = boolean.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[10]] = double.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[12]] = Entity.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[3]] = f100000000000000000000.Double.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[14]] = float.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[2]] = f100000000000000000000.Boolean.class;
    llIIIlIIIIlIIl[llIIIllllIIlll[6]] = EntityPlayerSP.class;
  }
  
  private static void lIIIIlIllIIlIllI() {
    llIIIlllIllIll = new String[llIIIllllIIlll[55]];
    llIIIlllIllIll[llIIIllllIIlll[0]] = lIIIIlIllIIlIIII(llIIIllllIIllI[llIIIllllIIlll[0]], llIIIllllIIllI[llIIIllllIIlll[1]]);
    llIIIlllIllIll[llIIIllllIIlll[1]] = lIIIIlIllIIlIIIl(llIIIllllIIllI[llIIIllllIIlll[2]], llIIIllllIIllI[llIIIllllIIlll[3]]);
    llIIIlllIllIll[llIIIllllIIlll[2]] = lIIIIlIllIIlIIIl(llIIIllllIIllI[llIIIllllIIlll[4]], llIIIllllIIllI[llIIIllllIIlll[6]]);
    llIIIlllIllIll[llIIIllllIIlll[3]] = lIIIIlIllIIlIIlI(llIIIllllIIllI[llIIIllllIIlll[8]], llIIIllllIIllI[llIIIllllIIlll[10]]);
    llIIIlllIllIll[llIIIllllIIlll[4]] = lIIIIlIllIIlIIIl(llIIIllllIIllI[llIIIllllIIlll[12]], llIIIllllIIllI[llIIIllllIIlll[14]]);
    llIIIlllIllIll[llIIIllllIIlll[6]] = lIIIIlIllIIlIIlI(llIIIllllIIllI[llIIIllllIIlll[16]], llIIIllllIIllI[llIIIllllIIlll[13]]);
    llIIIlllIllIll[llIIIllllIIlll[8]] = lIIIIlIllIIlIIlI(llIIIllllIIllI[llIIIllllIIlll[19]], llIIIllllIIllI[llIIIllllIIlll[21]]);
    llIIIlllIllIll[llIIIllllIIlll[10]] = lIIIIlIllIIlIIII(llIIIllllIIllI[llIIIllllIIlll[23]], llIIIllllIIllI[llIIIllllIIlll[25]]);
    llIIIlllIllIll[llIIIllllIIlll[12]] = lIIIIlIllIIlIIII(llIIIllllIIllI[llIIIllllIIlll[26]], llIIIllllIIllI[llIIIllllIIlll[17]]);
    llIIIlllIllIll[llIIIllllIIlll[14]] = lIIIIlIllIIlIIlI(llIIIllllIIllI[llIIIllllIIlll[29]], llIIIllllIIllI[llIIIllllIIlll[30]]);
    llIIIlllIllIll[llIIIllllIIlll[16]] = lIIIIlIllIIlIIIl("7rLovLZxCZ7nbab3khQ3TDWGr3sD5QEjpO2qG5JgqEA6YPdiO9hbVtZKRJFlUF/K", "ITspv");
    llIIIlllIllIll[llIIIllllIIlll[13]] = lIIIIlIllIIlIIII("qF3MKKrHCLvgMTRbjbfsWEKytI03+kkqAZJtm28ZlWEMkqdB7p+AhgSRgXCycPpWpb8DXmqBiQ/8gZK9IRVd5g==", "mmFlr");
    llIIIlllIllIll[llIIIllllIIlll[19]] = lIIIIlIllIIlIIII("vfbiGctYVS00XACfYVvzu8m1g79Na5ffsb+JigNXCgI=", "oYGdd");
    llIIIlllIllIll[llIIIllllIIlll[21]] = lIIIIlIllIIlIIlI("JR9pNj09Ci4xLScdaSchOFQhdHl4Snd1eXhKd3V5eEp3dXl4Snd1bQoVKCksKRR9Iiw8LCYpPC1Ab2wTclpn", "HzGEI");
    llIIIlllIllIll[llIIIllllIIlll[23]] = lIIIIlIllIIlIIII("4nbSaXSO+P1X7K/tCV4vm7bH5SCbmOIxkIHaBGw07HnfMi/VuLewfw==", "zaCqy");
    llIIIlllIllIll[llIIIllllIIlll[25]] = lIIIIlIllIIlIIIl("B/VdVyoAWnAAhXqBIqVQzZ/+tJPPOXL/TZjF1HNj3rQOj3fbcs2AHyP+Kv7OR6O1VMS3mPMDZkLF0j0g2LXSKC049S9QJhV0Jdf2Y3ywBBQN2ATSvdh2pzyZQu/8/aCI", "TUldv");
    llIIIlllIllIll[llIIIllllIIlll[26]] = lIIIIlIllIIlIIIl("0DdfCvUr5OFeatV1Jh9vKx/f/2KtDspaVwlV3dOAbNBe4Lp+83As2A==", "rtIps");
    llIIIlllIllIll[llIIIllllIIlll[17]] = lIIIIlIllIIlIIIl("J7OH40BWUxdofNvGYAsEc4+ocr28klNPnHUv18BZ5gE=", "UIqVu");
    llIIIlllIllIll[llIIIllllIIlll[29]] = lIIIIlIllIIlIIII("PZw4iufJit+B33xLS3xbBRNM1eGlVnaQNbd6cvF6o5tmB8/jJaOO/pTmY6lgxBnhXDSdFy+6hcbq4vPaeDY6Tg==", "EcGNf");
    llIIIlllIllIll[llIIIllllIIlll[30]] = lIIIIlIllIIlIIlI("LwFcJTM3FBsiIy0DXDQvMkoUL30wDRY/KSUhHCIuNh1Ibn1iRFJ2Zw==", "BdrVG");
    llIIIlllIllIll[llIIIllllIIlll[27]] = lIIIIlIllIIlIIIl("ML8mkNU42gIRJT7muP/KBGzUnAeIWouRkl1Dp0M/fVCkPMp4dx96ekeYNPRt+8S0O6pZRWFNsgWA5lQyNVI1w9W3/p6yZ6p1kNu3Ec5bTvJa6hgfeoYXh+LgztBsdqeu", "bMogn");
    llIIIlllIllIll[llIIIllllIIlll[32]] = lIIIIlIllIIlIIlI("KidZECcyMh4XNyglWQE7N2wRGmk0MhIGN31xTUNzZ2JX", "GBwcS");
    llIIIlllIllIll[llIIIllllIIlll[33]] = lIIIIlIllIIlIIIl("TwQOvsZ2OGeDhCkPTs0NS17fniGzByicjjYRxRYPsnw=", "ISyAt");
    llIIIlllIllIll[llIIIllllIIlll[35]] = lIIIIlIllIIlIIlI("LAxBNT00GQYyLS4OQSQhMUcJP3MxBhwcc3ZTT2Zp", "AioFI");
    llIIIlllIllIll[llIIIllllIIlll[36]] = lIIIIlIllIIlIIII("ms39lKcwDRmjCyZIiLUupydeUG11817hRvE+zVObnwWdNTnYx3ATlhyZBzUjOh4pOGMF/+f26nGLN1eKP25/q+CqpM2dODYLyLpf3Lkzxr8vSHSYmzrMqS9IdJibOsyp4wexjaUjWykCDyCqFB3flg==", "tZxFT");
    llIIIlllIllIll[llIIIllllIIlll[37]] = lIIIIlIllIIlIIIl("JeK68e+70x/F8TC0FPXN3WQ10Yhsnx7HzQlIYA2ZdqZyFiJVfh/fvA==", "JZMFK");
    llIIIlllIllIll[llIIIllllIIlll[38]] = lIIIIlIllIIlIIIl("1bfVs9j5M6zNPEQZU345oIwiUfJ4cAF/SbDbPmUjHa4VmKGQTg1xJx5Fd2iWcxbr2LJnzYBDVh0BSofEjK/9xviAVDmr2dCTxSicDyXo3Is=", "aWsKa");
    llIIIlllIllIll[llIIIllllIIlll[11]] = lIIIIlIllIIlIIII("g/+N6J9fyRL2ld6gsEFNwD4KWPTWxcjNCCeihwCJAYm3CDRL5091XOEeT4uE8HH0THu6iBXw+wLMGlokc3bDBw9I7Ur3hKNykLkyel1oPcCSCxlFfVpdhmXKeCR9BEQf", "HtdlN");
    llIIIlllIllIll[llIIIllllIIlll[24]] = lIIIIlIllIIlIIlI("KxIZWAIsGQgVHSQRGVgMKR4IGBtrOgQYCiYFDBAbfxEEEwMhKFpHW3ZOMhFVcE1NVk8=", "Ewmvo");
    llIIIlllIllIll[llIIIllllIIlll[9]] = lIIIIlIllIIlIIII("gZn/RhZRe93HvLxLUCZryGnhMsoSkYaQg/vei40uXHwq7SJIGkdZ6bNYSUldm5mZM4+Fp+Vhj5CzD7biI76wyA==", "obVJe");
    llIIIlllIllIll[llIIIllllIIlll[18]] = lIIIIlIllIIlIIIl("OjfL6mtvbFst6BpSHbPmdCx89bvF3D6mWWMVRsYf9DTjqRxAqrKsB6zq64YsQAfLqK3wo/SCDSJbESI+rgQYgA==", "uJIqg");
    llIIIlllIllIll[llIIIllllIIlll[28]] = lIIIIlIllIIlIIII("Ek/qUwsg6D6r8MgKFaM7bjJ8mnpXW0z1P63r5HofLgs7n+MlPGiDTlBAvnLv6Kesyf/7mwufI1Gc6bMe5sOV9HfelGKShX156iM8Ydqh62lWLJo5zvnQhoJyhai8DU/LPaMxDtH7IwI=", "YnSkf");
    llIIIlllIllIll[llIIIllllIIlll[41]] = lIIIIlIllIIlIIlI("GAdlNBkAEiIzCRoFZSUFBUwtdl1FUnt3XUVSe3ddUTEuKQlPBS4zPRQBICIZT0piCwMQFmQqBBsHKDUMExZkKQgBFSQ1BloyKiQGEBZwfU1V", "ubKGm");
    llIIIlllIllIll[llIIIllllIIlll[42]] = lIIIIlIllIIlIIlI("PAhHOCUkHQA/NT4KRyk5IUMPMmsjCA4iIiUIGw8+JA8FLmt5IQMqJzBCBSo/NkI6PyM4Aw5wFRUpQAc8NEIaPyQhBB0vPjZCCyMhfgtYe2FhXVl7YWFdWXthYV1Ze2FhXVlvFT4YCyc0aldJaw==", "QmiKQ");
    llIIIlllIllIll[llIIIllllIIlll[43]] = lIIIIlIllIIlIIII("hH0WOZx6QXZk+SUyZ50bptAFY63DrJZwDABQ11n4FOjEVVjS63VHu7a5cKS32O06", "NMYiP");
    llIIIlllIllIll[llIIIllllIIlll[34]] = lIIIIlIllIIlIIIl("/u6lNhVvp+fVsvAcsQAzorb6moOlnUoqTxA5OLxCU6VvqYlYZNXYgsr+CcMwQU+mRG8Az/hGTpo=", "ZOkWN");
    llIIIlllIllIll[llIIIllllIIlll[44]] = lIIIIlIllIIlIIIl("ia4znEpJ8De0ufE7kRvd8eA0ZKHe8Ze9jo7+nwytbfzeO7hzbb9qcw==", "NoCQj");
    llIIIlllIllIll[llIIIllllIIlll[45]] = lIIIIlIllIIlIIIl("qUOdifdguvyMredBWvoH/yjVHX9CZVkbeVdC48WUNFRu5RPHR7mtZVY1JzKtzLyF", "QKjZC");
    llIIIlllIllIll[llIIIllllIIlll[47]] = lIIIIlIllIIlIIlI("NAB7PxAsFTw4ADYCey4MKUszNV46BDsvATU1NC8PPBEmdlZjRXVs", "YeULd");
    llIIIlllIllIll[llIIIllllIIlll[31]] = lIIIIlIllIIlIIlI("KSYEaz4uLRUmISYlBGswKyoVKydpJh4xOjM6XgA9MyoEPAMrIgkgIRQTSiMmKSAvcmN3e0AaMn1rNAEXAQVZE2lnYw==", "GCpES");
    llIIIlllIllIll[llIIIllllIIlll[15]] = lIIIIlIllIIlIIIl("UmCWYwVRS6bhfVUF8nYlwAkFltiV+t28mBPJuK+a95U=", "UyNXY");
    llIIIlllIllIll[llIIIllllIIlll[22]] = lIIIIlIllIIlIIlI("Bi4+aSMBJS8kPAktPiEhGiwvaS0EIi8pOkYuPCIgHGUaKy8RLjgUHjg+OS8BHT8FIQwEJCksPS09Lyk6UjgvMw0JJSkiIg0vcG8UQR1wZ24=", "hKJGN");
    llIIIlllIllIll[llIIIllllIIlll[39]] = lIIIIlIllIIlIIIl("TTIlRoelpHgBqNvStozbfzow8SpkbmIfww5SxZ5UFABqQyvafISgXgoMxm7g/+3jF6a5Geco08XvZHUaWV6N/A==", "WqTBe");
    llIIIlllIllIll[llIIIllllIIlll[40]] = lIIIIlIllIIlIIII("t/chWvBPHnJPptjAcoaQPzLdGCRMK/2dSjKumOheTL5Uin3xgovk+wtCYPfNOrgS7i4u6WOS5vbJ+K323YzM/6PZRlZfQlgH", "GSEJd");
    llIIIlllIllIll[llIIIllllIIlll[46]] = lIIIIlIllIIlIIlI("GRJvBAIBBygDEhsQbxUeBFknDkwEGDIuTENNYVdW", "twAwv");
    llIIIlllIllIll[llIIIllllIIlll[20]] = lIIIIlIllIIlIIIl("rVxqZZx1cUQZFYcuDBLRpLZ/timmLYe5Ud7q6DlcUt2LhIxalCQfzg==", "PHSOl");
    llIIIlllIllIll[llIIIllllIIlll[49]] = lIIIIlIllIIlIIII("eW9Zuv+b9zzuw/+4Pyc0G3NV1FmshW0MnUzXqnsamU4Rk85eR9jlSQ==", "jjJNJ");
    llIIIlllIllIll[llIIIllllIIlll[48]] = lIIIIlIllIIlIIIl("pXtfUmDEL6QmlC0+aiiRWdoSF4pQGsSOF7M8VNcccJsn63I7aZxIYxGmVEspvxgg/gaZdwgZTYFZIc/BgLj9xg==", "YdwQO");
    llIIIlllIllIll[llIIIllllIIlll[7]] = lIIIIlIllIIlIIlI("OAcSRzo/DAMKJTcEEkciIgsKRwQzERUAODhYABw5NT1XXW9kV1A2MmxKTyU0OQ9JBDg8AwgOeDcXEgE7PwBJLjY7BzYbODALCgxsbEJG", "VbfiW");
    llIIIlllIllIll[llIIIllllIIlll[50]] = lIIIIlIllIIlIIII("0Bf/6Jj3HzzRLgiaUw1ZMOD1GITQ1x2T5ATj7CasgvP8Eg7A1P2CJVA63TUj5j4XxfxXtpcfw7iW+6oM0FGerJNaFHtjWbvp/7Oj9/Xv+CsREelHjqL6GRXU0QVGQgdw", "mqOwu");
    llIIIlllIllIll[llIIIllllIIlll[51]] = lIIIIlIllIIlIIIl("Dw4X0Sy/leTF+dAeAieGSr7VD9klo48Y/WhT4U/0bxw=", "nZscI");
    llIIIlllIllIll[llIIIllllIIlll[52]] = lIIIIlIllIIlIIIl("7vYeYUvPEOI0tmEfCOya+te6VuwT99AUXmQHC/mSqEGm8u4e1Idnyiza4GOdSaAD", "FXllm");
    llIIIlllIllIll[llIIIllllIIlll[53]] = lIIIIlIllIIlIIIl("8WsSm9Sqw9eV41HPX6QQn9YkvIlIzvQkBhceaGKO8oI=", "iUYAP");
    llIIIlllIllIll[llIIIllllIIlll[54]] = lIIIIlIllIIlIIII("dcPz2o3mHwUr2kKfUwPXlDCRPPJFfEueeDS9bWLypgj+iD7leSOCh1JWSEpWmuyxRyCE0Trwczw=", "naODv");
    llIIIllllIIllI = null;
  }
  
  private static void lIIIIlIllIIlIlll() {
    String str = (new Exception()).getStackTrace()[llIIIllllIIlll[0]].getFileName();
    llIIIllllIIllI = str.substring(str.indexOf("ä") + llIIIllllIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIllIIlIIII(String lllllllllllllllIllIlIIIIlIIIIllI, String lllllllllllllllIllIlIIIIlIIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIlIIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIlIIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIIlIIIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIIlIIIlIII.init(llIIIllllIIlll[2], lllllllllllllllIllIlIIIIlIIIlIIl);
      return new String(lllllllllllllllIllIlIIIIlIIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIlIIIIlll) {
      lllllllllllllllIllIlIIIIlIIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIllIIlIIlI(String lllllllllllllllIllIlIIIIlIIIIIll, String lllllllllllllllIllIlIIIIlIIIIIlI) {
    lllllllllllllllIllIlIIIIlIIIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlIIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIIIlIIIIIIl = new StringBuilder();
    char[] lllllllllllllllIllIlIIIIlIIIIIII = lllllllllllllllIllIlIIIIlIIIIIlI.toCharArray();
    int lllllllllllllllIllIlIIIIIlllllll = llIIIllllIIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIIIlIIIIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllllIIlll[0];
    while (lIIIIlIllIIlllll(j, i)) {
      char lllllllllllllllIllIlIIIIlIIIIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIIIIlllllll++;
      j++;
      "".length();
      if (((67 + 65 - 111 + 160 ^ (0xE9 ^ 0xB0) << " ".length()) << "   ".length() & (((0x7D ^ 0x7A) << " ".length() << " ".length() << " ".length() ^ 0xF9 ^ 0x8E) << "   ".length() ^ -" ".length())) == -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIIIlIIIIIIl);
  }
  
  private static String lIIIIlIllIIlIIIl(String lllllllllllllllIllIlIIIIIllllIll, String lllllllllllllllIllIlIIIIIllllIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIIllllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIIllllIlI.getBytes(StandardCharsets.UTF_8)), llIIIllllIIlll[12]), "DES");
      Cipher lllllllllllllllIllIlIIIIIlllllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIIlllllIl.init(llIIIllllIIlll[2], lllllllllllllllIllIlIIIIIllllllI);
      return new String(lllllllllllllllIllIlIIIIIlllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIIllllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIIlllllII) {
      lllllllllllllllIllIlIIIIIlllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllIIllIII() {
    llIIIllllIIlll = new int[56];
    llIIIllllIIlll[0] = (0x16 ^ 0x9) << " ".length() & ((0xB0 ^ 0xAF) << " ".length() ^ 0xFFFFFFFF);
    llIIIllllIIlll[1] = " ".length();
    llIIIllllIIlll[2] = " ".length() << " ".length();
    llIIIllllIIlll[3] = "   ".length();
    llIIIllllIIlll[4] = " ".length() << " ".length() << " ".length();
    llIIIllllIIlll[5] = -(0xA7 ^ 0xC6 ^ 0x4A ^ 0x4F);
    llIIIllllIIlll[6] = (0x22 ^ 0x65) << " ".length() ^ 40 + 82 - 64 + 81;
    llIIIllllIIlll[7] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIllllIIlll[8] = "   ".length() << " ".length();
    llIIIllllIIlll[9] = 0x6D ^ 0x70;
    llIIIllllIIlll[10] = (0x9D ^ 0x8E) << " ".length() ^ 0xAC ^ 0x8D;
    llIIIllllIIlll[11] = 74 + 40 - -19 + 14 ^ (0x95 ^ 0x84) << "   ".length();
    llIIIllllIIlll[12] = " ".length() << "   ".length();
    llIIIllllIIlll[13] = (0x60 ^ 0x79) << " ".length() ^ 0x2A ^ 0x13;
    llIIIllllIIlll[14] = 0xE0 ^ 0x97 ^ (0x8A ^ 0xB5) << " ".length();
    llIIIllllIIlll[15] = (0x8 ^ 0xD) << "   ".length();
    llIIIllllIIlll[16] = ((0xB1 ^ 0xB6) << "   ".length() ^ 0x47 ^ 0x7A) << " ".length();
    llIIIllllIIlll[17] = 0xD3 ^ 0xC2;
    llIIIllllIIlll[18] = ((0x4 ^ 0xD) << " ".length() ^ 0x79 ^ 0x64) << " ".length();
    llIIIllllIIlll[19] = "   ".length() << " ".length() << " ".length();
    llIIIllllIIlll[20] = (0x45 ^ 0x7C) << " ".length() ^ 0xCA ^ 0x95;
    llIIIllllIIlll[21] = 0x49 ^ 0x44;
    llIIIllllIIlll[22] = 0x94 ^ 0xB7 ^ (0x99 ^ 0x9C) << " ".length();
    llIIIllllIIlll[23] = (0xBF ^ 0xB8) << " ".length();
    llIIIllllIIlll[24] = ((0x69 ^ 0x60) << " ".length() ^ 0x63 ^ 0x76) << " ".length() << " ".length();
    llIIIllllIIlll[25] = " ".length() << "   ".length() ^ 0x62 ^ 0x65;
    llIIIllllIIlll[26] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIllllIIlll[27] = (0x15 ^ 0x10) << " ".length() << " ".length();
    llIIIllllIIlll[28] = 3 + 125 - 32 + 57 ^ (0x16 ^ 0x55) << " ".length();
    llIIIllllIIlll[29] = (0x7 ^ 0xE) << " ".length();
    llIIIllllIIlll[30] = 0x7E ^ 0x6D;
    llIIIllllIIlll[31] = (0xC0 ^ 0x9B) << " ".length() ^ 102 + 125 - 165 + 83;
    llIIIllllIIlll[32] = 0x24 ^ 0x43 ^ (0x31 ^ 0x8) << " ".length();
    llIIIllllIIlll[33] = (0x3D ^ 0x36) << " ".length();
    llIIIllllIIlll[34] = 0xAE ^ 0x8D;
    llIIIllllIIlll[35] = 0x92 ^ 0x85;
    llIIIllllIIlll[36] = "   ".length() << "   ".length();
    llIIIllllIIlll[37] = 0x89 ^ 0x90;
    llIIIllllIIlll[38] = ((0x1E ^ 0x13) << " ".length() ^ 0x8D ^ 0x9A) << " ".length();
    llIIIllllIIlll[39] = ((0x19 ^ 0x1C) << (0x95 ^ 0x90) ^ 29 + 102 - 43 + 93) << " ".length();
    llIIIllllIIlll[40] = 0x75 ^ 0x5E;
    llIIIllllIIlll[41] = " ".length() << ((0x3C ^ 0x7) << " ".length() ^ 0x61 ^ 0x12);
    llIIIllllIIlll[42] = 0xCC ^ 0x81 ^ (0xDD ^ 0xC6) << " ".length() << " ".length();
    llIIIllllIIlll[43] = (0x88 ^ 0x97 ^ (0x12 ^ 0x15) << " ".length()) << " ".length();
    llIIIllllIIlll[44] = (0x86 ^ 0x8F) << " ".length() << " ".length();
    llIIIllllIIlll[45] = 0x79 ^ 0x4 ^ (0x20 ^ 0x2B) << "   ".length();
    llIIIllllIIlll[46] = (0x46 ^ 0x11 ^ (0x6 ^ 0x11) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIllllIIlll[47] = (0x38 ^ 0x2D ^ "   ".length() << " ".length()) << " ".length();
    llIIIllllIIlll[48] = (0x6 ^ 0x13) << "   ".length() ^ 26 + 26 - 50 + 133;
    llIIIllllIIlll[49] = ((0x3 ^ 0x10) << " ".length() ^ 0x8D ^ 0xBC) << " ".length();
    llIIIllllIIlll[50] = (0xCD ^ 0xC0) << "   ".length() ^ 0x15 ^ 0x4C;
    llIIIllllIIlll[51] = (146 + 144 - 95 + 28 ^ (0x49 ^ 0x2A) << " ".length()) << " ".length();
    llIIIllllIIlll[52] = 0x3 ^ 0x30;
    llIIIllllIIlll[53] = ((0x58 ^ 0xF) << " ".length() ^ 47 + 91 - 77 + 102) << " ".length() << " ".length();
    llIIIllllIIlll[54] = (0x2D ^ 0x26) << "   ".length() ^ 0xCD ^ 0xA0;
    llIIIllllIIlll[55] = (0x66 ^ 0x7D) << " ".length();
  }
  
  private static boolean lIIIIlIllIIllllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllIIlllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIllIIlllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIllIIllIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIlIllIIllIlI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIlIllIIllIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlIllIIlllII(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */