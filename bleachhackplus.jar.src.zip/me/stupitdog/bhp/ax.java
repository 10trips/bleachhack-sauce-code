package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.play.client.CPacketUseEntity;

public class ax extends au {
  @EventHandler
  private Listener<f100> onPacketEventSend;
  
  private static String[] llIIIIlllIIlll;
  
  private static Class[] llIIIIlllIlIII;
  
  private static final String[] llIIIIlllllIII;
  
  private static String[] llIIIlIIIIIIlI;
  
  private static final int[] llIIIlIIIIIlII;
  
  public ax() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ax.llIIIIlllllIII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/ax.llIIIlIIIIIlII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/ax.llIIIIlllllIII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/ax.llIIIlIIIIIlII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/ax.llIIIIlllllIII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/ax.llIIIlIIIIIlII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/ax.llIIIlIIIIIlII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/ax.llIIIlIIIIIlII : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/ax;Lme/zero/alpine/listener/Listener;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	68	0	lllllllllllllllIllIlIlllIllIIlIl	Lme/stupitdog/bhp/ax;
  }
  
  static {
    lIIIIIlllIIIIllI();
    lIIIIIllIlllllIl();
    lIIIIIllIllllIlI();
    lIIIIIllIllIlIII();
  }
  
  private static CallSite lIIIIIllIlIIlIll(MethodHandles.Lookup lllllllllllllllIllIlIlllIlIllIlI, String lllllllllllllllIllIlIlllIlIllIIl, MethodType lllllllllllllllIllIlIlllIlIllIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlllIllIIIII = llIIIIlllIIlll[Integer.parseInt(lllllllllllllllIllIlIlllIlIllIIl)].split(llIIIIlllllIII[llIIIlIIIIIlII[3]]);
      Class<?> lllllllllllllllIllIlIlllIlIlllll = Class.forName(lllllllllllllllIllIlIlllIllIIIII[llIIIlIIIIIlII[0]]);
      String lllllllllllllllIllIlIlllIlIllllI = lllllllllllllllIllIlIlllIllIIIII[llIIIlIIIIIlII[1]];
      MethodHandle lllllllllllllllIllIlIlllIlIlllIl = null;
      int lllllllllllllllIllIlIlllIlIlllII = lllllllllllllllIllIlIlllIllIIIII[llIIIlIIIIIlII[3]].length();
      if (lIIIIIlllIIIlIlI(lllllllllllllllIllIlIlllIlIlllII, llIIIlIIIIIlII[2])) {
        MethodType lllllllllllllllIllIlIlllIllIIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlllIllIIIII[llIIIlIIIIIlII[2]], ax.class.getClassLoader());
        if (lIIIIIlllIIIlIll(lllllllllllllllIllIlIlllIlIlllII, llIIIlIIIIIlII[2])) {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findVirtual(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIlI);
          "".length();
          if ((" ".length() << (0x78 ^ 0x7D) & (" ".length() << (0xAE ^ 0xAB) ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findStatic(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIlI);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlllIllIIIIl = llIIIIlllIlIII[Integer.parseInt(lllllllllllllllIllIlIlllIllIIIII[llIIIlIIIIIlII[2]])];
        if (lIIIIIlllIIIlIll(lllllllllllllllIllIlIlllIlIlllII, llIIIlIIIIIlII[3])) {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findGetter(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIIl);
          "".length();
          if (((" ".length() << " ".length() << " ".length() ^ 0xE ^ 0x23) & ((0x24 ^ 0x13) << " ".length() ^ 0x3A ^ 0x7D ^ -" ".length())) > ((138 + 203 - 291 + 167 ^ "   ".length() << "   ".length() << " ".length()) & (222 + 73 - 237 + 165 ^ (0x44 ^ 0x27) << " ".length() ^ -" ".length())))
            return null; 
        } else if (lIIIIIlllIIIlIll(lllllllllllllllIllIlIlllIlIlllII, llIIIlIIIIIlII[4])) {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findStaticGetter(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIIl);
          "".length();
          if (" ".length() << " ".length() == " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIlllIIIlIll(lllllllllllllllIllIlIlllIlIlllII, llIIIlIIIIIlII[5])) {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findSetter(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIIl);
          "".length();
          if (((0xDD ^ 0x9A) & (0xD8 ^ 0x9F ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlllIlIlllIl = lllllllllllllllIllIlIlllIlIllIlI.findStaticSetter(lllllllllllllllIllIlIlllIlIlllll, lllllllllllllllIllIlIlllIlIllllI, lllllllllllllllIllIlIlllIllIIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlllIlIlllIl);
    } catch (Exception lllllllllllllllIllIlIlllIlIllIll) {
      lllllllllllllllIllIlIlllIlIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIllIlIII() {
    llIIIIlllIIlll = new String[llIIIlIIIIIlII[6]];
    llIIIIlllIIlll[llIIIlIIIIIlII[2]] = llIIIIlllllIII[llIIIlIIIIIlII[4]];
    llIIIIlllIIlll[llIIIlIIIIIlII[4]] = llIIIIlllllIII[llIIIlIIIIIlII[5]];
    llIIIIlllIIlll[llIIIlIIIIIlII[7]] = llIIIIlllllIII[llIIIlIIIIIlII[7]];
    llIIIIlllIIlll[llIIIlIIIIIlII[1]] = llIIIIlllllIII[llIIIlIIIIIlII[8]];
    llIIIIlllIIlll[llIIIlIIIIIlII[0]] = llIIIIlllllIII[llIIIlIIIIIlII[9]];
    llIIIIlllIIlll[llIIIlIIIIIlII[5]] = llIIIIlllllIII[llIIIlIIIIIlII[6]];
    llIIIIlllIIlll[llIIIlIIIIIlII[9]] = llIIIIlllllIII[llIIIlIIIIIlII[10]];
    llIIIIlllIIlll[llIIIlIIIIIlII[3]] = llIIIIlllllIII[llIIIlIIIIIlII[11]];
    llIIIIlllIIlll[llIIIlIIIIIlII[8]] = llIIIIlllllIII[llIIIlIIIIIlII[12]];
    llIIIIlllIlIII = new Class[llIIIlIIIIIlII[5]];
    llIIIIlllIlIII[llIIIlIIIIIlII[3]] = WorldClient.class;
    llIIIIlllIlIII[llIIIlIIIIIlII[4]] = CPacketUseEntity.Action.class;
    llIIIIlllIlIII[llIIIlIIIIIlII[0]] = f13.class;
    llIIIIlllIlIII[llIIIlIIIIIlII[1]] = Listener.class;
    llIIIIlllIlIII[llIIIlIIIIIlII[2]] = Minecraft.class;
  }
  
  private static void lIIIIIllIllllIlI() {
    llIIIIlllllIII = new String[llIIIlIIIIIlII[13]];
    llIIIIlllllIII[llIIIlIIIIIlII[0]] = lIIIIIllIllIlIIl(llIIIlIIIIIIlI[llIIIlIIIIIlII[0]], llIIIlIIIIIIlI[llIIIlIIIIIlII[1]]);
    llIIIIlllllIII[llIIIlIIIIIlII[1]] = lIIIIIllIllIlIIl(llIIIlIIIIIIlI[llIIIlIIIIIlII[2]], llIIIlIIIIIIlI[llIIIlIIIIIlII[3]]);
    llIIIIlllllIII[llIIIlIIIIIlII[2]] = lIIIIIllIllIllII(llIIIlIIIIIIlI[llIIIlIIIIIlII[4]], llIIIlIIIIIIlI[llIIIlIIIIIlII[5]]);
    llIIIIlllllIII[llIIIlIIIIIlII[3]] = lIIIIIllIllIllII(llIIIlIIIIIIlI[llIIIlIIIIIlII[7]], llIIIlIIIIIIlI[llIIIlIIIIIlII[8]]);
    llIIIIlllllIII[llIIIlIIIIIlII[4]] = lIIIIIllIllIlIIl(llIIIlIIIIIIlI[llIIIlIIIIIlII[9]], llIIIlIIIIIIlI[llIIIlIIIIIlII[6]]);
    llIIIIlllllIII[llIIIlIIIIIlII[5]] = lIIIIIllIllIllIl(llIIIlIIIIIIlI[llIIIlIIIIIlII[10]], llIIIlIIIIIIlI[llIIIlIIIIIlII[11]]);
    llIIIIlllllIII[llIIIlIIIIIlII[7]] = lIIIIIllIllIllIl(llIIIlIIIIIIlI[llIIIlIIIIIlII[12]], llIIIlIIIIIIlI[llIIIlIIIIIlII[13]]);
    llIIIIlllllIII[llIIIlIIIIIlII[8]] = lIIIIIllIllIllIl("ida5aw7GNlDgFlbxMMemThXh8o5waCWGY/VPt3F1P1E+wl8vgNpFnQOdRaV4rHwh", "BRPZp");
    llIIIIlllllIII[llIIIlIIIIIlII[9]] = lIIIIIllIllIlIIl("qw13PI9wPZn8t2mE5YMfi27nyVOIruAlUxZ5Xv4qsIbUMQYgORABDQ==", "tPvIy");
    llIIIIlllllIII[llIIIlIIIIIlII[6]] = lIIIIIllIllIllII("HTM8ay8aOC0mMBIwPGssFiI/KjAYeDgpIwp4KykrFjg8awEjNysuJwcDOyAHHSIhMTtJMD0rISxnfHx3RWIXJHhbGiYgNlw7ISsnECQpIzZcISc3Lhd5HyowHzJzbA4dMzxqLxo4LSYwEjA8aicdIiExO1wTJjErBy9zf2JT", "sVHEB");
    llIIIIlllllIII[llIIIlIIIIIlII[10]] = lIIIIIllIllIlIIl("JK+bhUngQJ2+GhBMDodGGrkg8p4Qd1VGZxh2NSJhkUzQb/UTwFW9uw==", "NDTOB");
    llIIIIlllllIII[llIIIlIIIIIlII[11]] = lIIIIIllIllIllII("NC1lHTEsOCIaITYvZQwtKWYqFn80K3Fcf3loa04=", "YHKnE");
    llIIIIlllllIII[llIIIlIIIIIlII[12]] = lIIIIIllIllIlIIl("g0Pmaj+Fz9Eo/zka2/qHeMOVBdw3bYxNKHWdVQY8Xvdz9xnRtbZIMgB2YilYjXuDZ2yCDHg2V5SeP1x3YuLa5yOpbIYTD9ojT9/xzCfKAUg=", "gMqbJ");
    llIIIlIIIIIIlI = null;
  }
  
  private static void lIIIIIllIlllllIl() {
    String str = (new Exception()).getStackTrace()[llIIIlIIIIIlII[0]].getFileName();
    llIIIlIIIIIIlI = str.substring(str.indexOf("ä") + llIIIlIIIIIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIllIllIllIl(String lllllllllllllllIllIlIlllIlIlIlII, String lllllllllllllllIllIlIlllIlIlIIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlllIlIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIlIlIIll.getBytes(StandardCharsets.UTF_8)), llIIIlIIIIIlII[9]), "DES");
      Cipher lllllllllllllllIllIlIlllIlIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlllIlIlIllI.init(llIIIlIIIIIlII[2], lllllllllllllllIllIlIlllIlIlIlll);
      return new String(lllllllllllllllIllIlIlllIlIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlllIlIlIlIl) {
      lllllllllllllllIllIlIlllIlIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIllIllIllII(String lllllllllllllllIllIlIlllIlIlIIIl, String lllllllllllllllIllIlIlllIlIlIIII) {
    lllllllllllllllIllIlIlllIlIlIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlllIlIIllll = new StringBuilder();
    char[] lllllllllllllllIllIlIlllIlIIlllI = lllllllllllllllIllIlIlllIlIlIIII.toCharArray();
    int lllllllllllllllIllIlIlllIlIIllIl = llIIIlIIIIIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIlllIlIlIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIIIIIlII[0];
    while (lIIIIIlllIIIllIl(j, i)) {
      char lllllllllllllllIllIlIlllIlIlIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIlllIlIIllIl++;
      j++;
      "".length();
      if (-"  ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlllIlIIllll);
  }
  
  private static String lIIIIIllIllIlIIl(String lllllllllllllllIllIlIlllIlIIlIIl, String lllllllllllllllIllIlIlllIlIIlIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlllIlIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIlIIlIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlllIlIIlIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlllIlIIlIll.init(llIIIlIIIIIlII[2], lllllllllllllllIllIlIlllIlIIllII);
      return new String(lllllllllllllllIllIlIlllIlIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlllIlIIlIlI) {
      lllllllllllllllIllIlIlllIlIIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlllIIIIllI() {
    llIIIlIIIIIlII = new int[14];
    llIIIlIIIIIlII[0] = (195 + 100 - 148 + 106 ^ (0x75 ^ 0x5E) << " ".length() << " ".length()) & (0xBA ^ 0x95 ^ (0x29 ^ 0x16) << " ".length() ^ -" ".length());
    llIIIlIIIIIlII[1] = " ".length();
    llIIIlIIIIIlII[2] = " ".length() << " ".length();
    llIIIlIIIIIlII[3] = "   ".length();
    llIIIlIIIIIlII[4] = " ".length() << " ".length() << " ".length();
    llIIIlIIIIIlII[5] = (0x53 ^ 0x5A) << " ".length() ^ 0x28 ^ 0x3F;
    llIIIlIIIIIlII[6] = 0x84 ^ 0x8D;
    llIIIlIIIIIlII[7] = "   ".length() << " ".length();
    llIIIlIIIIIlII[8] = 0xBB ^ 0xBC;
    llIIIlIIIIIlII[9] = " ".length() << "   ".length();
    llIIIlIIIIIlII[10] = (0x99 ^ 0x9C) << " ".length();
    llIIIlIIIIIlII[11] = 0xA ^ 0x1;
    llIIIlIIIIIlII[12] = "   ".length() << " ".length() << " ".length();
    llIIIlIIIIIlII[13] = 0xBF ^ 0xB2;
  }
  
  private static boolean lIIIIIlllIIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlllIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlllIIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlllIIIlIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIlllIIIIlll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ax.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */