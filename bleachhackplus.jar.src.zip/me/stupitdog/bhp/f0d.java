package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.util.EnumHand;

public class f0d extends au {
  public ao timer;
  
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Boolean swordOnly;
  
  f100000000000000000000.Double range;
  
  f100000000000000000000.Boolean player;
  
  f100000000000000000000.Boolean mobs;
  
  f100000000000000000000.Boolean animals;
  
  private static String[] llIIIIIIllIIIl;
  
  private static Class[] llIIIIIIllIIlI;
  
  private static final String[] llIIIIlIllllIl;
  
  private static String[] llIIIIllIIlIll;
  
  private static final int[] llIIIIllIlIIII;
  
  public f0d() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/stupitdog/bhp/ao
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/ao;)V
    //   54: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	55	0	lllllllllllllllIllIllIIIlIllIIll	Lme/stupitdog/bhp/f0d;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: aload_0
    //   52: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   58: iconst_5
    //   59: iaload
    //   60: aaload
    //   61: aload_1
    //   62: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   65: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   68: bipush #6
    //   70: iaload
    //   71: aaload
    //   72: <illegal opcode> 3 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   77: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   82: aload_0
    //   83: aload_0
    //   84: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   87: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   90: bipush #7
    //   92: iaload
    //   93: aaload
    //   94: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   97: iconst_1
    //   98: iaload
    //   99: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   104: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   109: aload_0
    //   110: aload_0
    //   111: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   114: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   117: bipush #8
    //   119: iaload
    //   120: aaload
    //   121: ldc2_w 4.0
    //   124: dconst_1
    //   125: ldc2_w 6.0
    //   128: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   133: <illegal opcode> 8 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   138: aload_0
    //   139: aload_0
    //   140: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   143: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   146: bipush #9
    //   148: iaload
    //   149: aaload
    //   150: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   153: iconst_1
    //   154: iaload
    //   155: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   160: <illegal opcode> 9 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   165: aload_0
    //   166: aload_0
    //   167: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   170: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   173: bipush #10
    //   175: iaload
    //   176: aaload
    //   177: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   180: iconst_1
    //   181: iaload
    //   182: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   187: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   192: aload_0
    //   193: aload_0
    //   194: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   197: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   200: bipush #11
    //   202: iaload
    //   203: aaload
    //   204: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   207: iconst_1
    //   208: iaload
    //   209: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   214: <illegal opcode> 11 : (Lme/stupitdog/bhp/f0d;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   219: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	220	0	lllllllllllllllIllIllIIIlIllIIlI	Lme/stupitdog/bhp/f0d;
    //   8	212	1	lllllllllllllllIllIllIIIlIllIIIl	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	212	1	lllllllllllllllIllIllIIIlIllIIIl	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 14 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 15 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   20: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   25: <illegal opcode> 16 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   30: aload_0
    //   31: <illegal opcode> test : (Lme/stupitdog/bhp/f0d;)Ljava/util/function/Predicate;
    //   36: <illegal opcode> 16 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   41: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   46: <illegal opcode> 16 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   51: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   56: <illegal opcode> 17 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   61: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   66: <illegal opcode> 18 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   71: <illegal opcode> 19 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   76: aconst_null
    //   77: <illegal opcode> 20 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   82: checkcast net/minecraft/entity/Entity
    //   85: astore_1
    //   86: aload_0
    //   87: <illegal opcode> 21 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   92: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   97: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   100: ifeq -> 152
    //   103: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   108: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   113: <illegal opcode> 24 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   118: <illegal opcode> 25 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   123: <illegal opcode> 26 : ()Lnet/minecraft/item/Item;
    //   128: invokestatic lIIIIIllIIIIlIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   131: ifeq -> 159
    //   134: aload_0
    //   135: aload_1
    //   136: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0d;Lnet/minecraft/entity/Entity;)V
    //   141: ldc ''
    //   143: invokevirtual length : ()I
    //   146: pop
    //   147: aconst_null
    //   148: ifnull -> 159
    //   151: return
    //   152: aload_0
    //   153: aload_1
    //   154: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0d;Lnet/minecraft/entity/Entity;)V
    //   159: ldc ''
    //   161: invokevirtual length : ()I
    //   164: pop
    //   165: aconst_null
    //   166: ifnull -> 171
    //   169: return
    //   170: astore_1
    //   171: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   86	73	1	lllllllllllllllIllIllIIIlIllIIII	Lnet/minecraft/entity/Entity;
    //   0	172	0	lllllllllllllllIllIllIIIlIlIllll	Lme/stupitdog/bhp/f0d;
    // Exception table:
    //   from	to	target	type
    //   0	159	170	java/lang/Exception
  }
  
  public void doKa(Entity lllllllllllllllIllIllIIIlIlIllII) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic lIIIIIllIIIIlIIl : (Ljava/lang/Object;)Z
    //   4: ifeq -> 846
    //   7: aload_0
    //   8: aload_1
    //   9: <illegal opcode> 28 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   14: <illegal opcode> 29 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;)V
    //   19: aload_0
    //   20: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   25: <illegal opcode> 31 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   30: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   36: bipush #12
    //   38: iaload
    //   39: aaload
    //   40: <illegal opcode> 32 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   45: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   48: ifeq -> 430
    //   51: aload_1
    //   52: instanceof net/minecraft/entity/player/EntityPlayer
    //   55: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   58: ifeq -> 172
    //   61: aload_0
    //   62: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   67: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   72: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   75: ifeq -> 172
    //   78: aload_0
    //   79: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   84: ldc2_w 40
    //   87: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   92: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   95: ifeq -> 172
    //   98: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   103: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   108: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   113: new net/minecraft/network/play/client/CPacketUseEntity
    //   116: dup
    //   117: aload_1
    //   118: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   121: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   126: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   131: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   136: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   141: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   146: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   151: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   156: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   161: aload_0
    //   162: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   167: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   172: aload_1
    //   173: instanceof net/minecraft/entity/passive/EntityAnimal
    //   176: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   179: ifeq -> 293
    //   182: aload_0
    //   183: <illegal opcode> 42 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   188: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   193: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   196: ifeq -> 293
    //   199: aload_0
    //   200: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   205: ldc2_w 40
    //   208: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   213: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   216: ifeq -> 293
    //   219: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   224: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   229: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   234: new net/minecraft/network/play/client/CPacketUseEntity
    //   237: dup
    //   238: aload_1
    //   239: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   242: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   247: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   252: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   257: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   262: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   267: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   272: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   277: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   282: aload_0
    //   283: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   288: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   293: aload_1
    //   294: instanceof net/minecraft/entity/monster/EntityMob
    //   297: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   300: ifeq -> 862
    //   303: aload_0
    //   304: <illegal opcode> 43 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   309: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   314: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   317: ifeq -> 862
    //   320: aload_0
    //   321: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   326: ldc2_w 40
    //   329: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   334: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   337: ifeq -> 862
    //   340: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   345: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   350: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   355: new net/minecraft/network/play/client/CPacketUseEntity
    //   358: dup
    //   359: aload_1
    //   360: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   363: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   368: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   373: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   378: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   383: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   388: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   393: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   398: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   403: aload_0
    //   404: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   409: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   414: ldc ''
    //   416: invokevirtual length : ()I
    //   419: pop
    //   420: ldc_w ' '
    //   423: invokevirtual length : ()I
    //   426: ifne -> 862
    //   429: return
    //   430: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   435: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   440: <illegal opcode> 44 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   445: ldc_w 45.0
    //   448: fmul
    //   449: f2d
    //   450: dstore_2
    //   451: aload_1
    //   452: instanceof net/minecraft/entity/player/EntityPlayer
    //   455: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   458: ifeq -> 571
    //   461: aload_0
    //   462: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   467: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   472: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   475: ifeq -> 571
    //   478: aload_0
    //   479: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   484: dload_2
    //   485: d2l
    //   486: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   491: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   494: ifeq -> 571
    //   497: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   502: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   507: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   512: new net/minecraft/network/play/client/CPacketUseEntity
    //   515: dup
    //   516: aload_1
    //   517: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   520: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   525: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   530: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   535: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   540: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   545: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   550: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   555: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   560: aload_0
    //   561: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   566: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   571: aload_1
    //   572: instanceof net/minecraft/entity/passive/EntityAnimal
    //   575: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   578: ifeq -> 691
    //   581: aload_0
    //   582: <illegal opcode> 42 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   587: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   592: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   595: ifeq -> 691
    //   598: aload_0
    //   599: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   604: dload_2
    //   605: d2l
    //   606: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   611: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   614: ifeq -> 691
    //   617: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   622: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   627: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   632: new net/minecraft/network/play/client/CPacketUseEntity
    //   635: dup
    //   636: aload_1
    //   637: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   640: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   645: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   650: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   655: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   660: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   665: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   670: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   675: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   680: aload_0
    //   681: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   686: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   691: aload_1
    //   692: instanceof net/minecraft/entity/monster/EntityMob
    //   695: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   698: ifeq -> 811
    //   701: aload_0
    //   702: <illegal opcode> 43 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   707: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   712: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   715: ifeq -> 811
    //   718: aload_0
    //   719: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   724: dload_2
    //   725: d2l
    //   726: <illegal opcode> 35 : (Lme/stupitdog/bhp/ao;J)Z
    //   731: invokestatic lIIIIIllIIIIIlll : (I)Z
    //   734: ifeq -> 811
    //   737: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   742: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   747: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   752: new net/minecraft/network/play/client/CPacketUseEntity
    //   755: dup
    //   756: aload_1
    //   757: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   760: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   765: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   770: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   775: <illegal opcode> 38 : ()Lnet/minecraft/util/EnumHand;
    //   780: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   785: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   790: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   795: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   800: aload_0
    //   801: <illegal opcode> 34 : (Lme/stupitdog/bhp/f0d;)Lme/stupitdog/bhp/ao;
    //   806: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;)V
    //   811: ldc ''
    //   813: invokevirtual length : ()I
    //   816: pop
    //   817: bipush #114
    //   819: bipush #6
    //   821: iadd
    //   822: bipush #17
    //   824: isub
    //   825: bipush #24
    //   827: iadd
    //   828: bipush #127
    //   830: bipush #66
    //   832: ixor
    //   833: ldc_w ' '
    //   836: invokevirtual length : ()I
    //   839: ishl
    //   840: ixor
    //   841: ineg
    //   842: iflt -> 862
    //   845: return
    //   846: aload_0
    //   847: getstatic me/stupitdog/bhp/f0d.llIIIIlIllllIl : [Ljava/lang/String;
    //   850: getstatic me/stupitdog/bhp/f0d.llIIIIllIlIIII : [I
    //   853: bipush #13
    //   855: iaload
    //   856: aaload
    //   857: <illegal opcode> 29 : (Lme/stupitdog/bhp/f0d;Ljava/lang/String;)V
    //   862: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   451	360	2	lllllllllllllllIllIllIIIlIlIlllI	D
    //   0	863	0	lllllllllllllllIllIllIIIlIlIllIl	Lme/stupitdog/bhp/f0d;
    //   0	863	1	lllllllllllllllIllIllIIIlIlIllII	Lnet/minecraft/entity/Entity;
  }
  
  static {
    lIIIIIllIIIIIllI();
    lIIIIIlIllllIIII();
    lIIIIIlIlllIllll();
    lIIIIIlIllIIlIIl();
  }
  
  private static CallSite lIIIIIIlIlIllIII(MethodHandles.Lookup lllllllllllllllIllIllIIIlIIlllIl, String lllllllllllllllIllIllIIIlIIlllII, MethodType lllllllllllllllIllIllIIIlIIllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIIlIlIIIll = llIIIIIIllIIIl[Integer.parseInt(lllllllllllllllIllIllIIIlIIlllII)].split(llIIIIlIllllIl[llIIIIllIlIIII[14]]);
      Class<?> lllllllllllllllIllIllIIIlIlIIIlI = Class.forName(lllllllllllllllIllIllIIIlIlIIIll[llIIIIllIlIIII[0]]);
      String lllllllllllllllIllIllIIIlIlIIIIl = lllllllllllllllIllIllIIIlIlIIIll[llIIIIllIlIIII[1]];
      MethodHandle lllllllllllllllIllIllIIIlIlIIIII = null;
      int lllllllllllllllIllIllIIIlIIlllll = lllllllllllllllIllIllIIIlIlIIIll[llIIIIllIlIIII[3]].length();
      if (lIIIIIllIIIIllIl(lllllllllllllllIllIllIIIlIIlllll, llIIIIllIlIIII[2])) {
        MethodType lllllllllllllllIllIllIIIlIlIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIIlIlIIIll[llIIIIllIlIIII[2]], f0d.class.getClassLoader());
        if (lIIIIIllIIIIlllI(lllllllllllllllIllIllIIIlIIlllll, llIIIIllIlIIII[2])) {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findVirtual(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlIl);
          "".length();
          if (((0x4A ^ 0x1D ^ (0x91 ^ 0xB0) << " ".length()) & ((0x6F ^ 0x64) << " ".length() ^ "   ".length() ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findStatic(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlIl);
        } 
        "".length();
        if (-"   ".length() >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIIlIlIIlII = llIIIIIIllIIlI[Integer.parseInt(lllllllllllllllIllIllIIIlIlIIIll[llIIIIllIlIIII[2]])];
        if (lIIIIIllIIIIlllI(lllllllllllllllIllIllIIIlIIlllll, llIIIIllIlIIII[3])) {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findGetter(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlII);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else if (lIIIIIllIIIIlllI(lllllllllllllllIllIllIIIlIIlllll, llIIIIllIlIIII[4])) {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findStaticGetter(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlII);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else if (lIIIIIllIIIIlllI(lllllllllllllllIllIllIIIlIIlllll, llIIIIllIlIIII[5])) {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findSetter(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlII);
          "".length();
          if ("   ".length() == " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIIlIlIIIII = lllllllllllllllIllIllIIIlIIlllIl.findStaticSetter(lllllllllllllllIllIllIIIlIlIIIlI, lllllllllllllllIllIllIIIlIlIIIIl, lllllllllllllllIllIllIIIlIlIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIIlIlIIIII);
    } catch (Exception lllllllllllllllIllIllIIIlIIllllI) {
      lllllllllllllllIllIllIIIlIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIllIIlIIl() {
    llIIIIIIllIIIl = new String[llIIIIllIlIIII[15]];
    llIIIIIIllIIIl[llIIIIllIlIIII[16]] = llIIIIlIllllIl[llIIIIllIlIIII[17]];
    llIIIIIIllIIIl[llIIIIllIlIIII[18]] = llIIIIlIllllIl[llIIIIllIlIIII[19]];
    llIIIIIIllIIIl[llIIIIllIlIIII[20]] = llIIIIlIllllIl[llIIIIllIlIIII[21]];
    llIIIIIIllIIIl[llIIIIllIlIIII[22]] = llIIIIlIllllIl[llIIIIllIlIIII[23]];
    llIIIIIIllIIIl[llIIIIllIlIIII[9]] = llIIIIlIllllIl[llIIIIllIlIIII[24]];
    llIIIIIIllIIIl[llIIIIllIlIIII[23]] = llIIIIlIllllIl[llIIIIllIlIIII[25]];
    llIIIIIIllIIIl[llIIIIllIlIIII[24]] = llIIIIlIllllIl[llIIIIllIlIIII[26]];
    llIIIIIIllIIIl[llIIIIllIlIIII[27]] = llIIIIlIllllIl[llIIIIllIlIIII[28]];
    llIIIIIIllIIIl[llIIIIllIlIIII[5]] = llIIIIlIllllIl[llIIIIllIlIIII[29]];
    llIIIIIIllIIIl[llIIIIllIlIIII[11]] = llIIIIlIllllIl[llIIIIllIlIIII[30]];
    llIIIIIIllIIIl[llIIIIllIlIIII[31]] = llIIIIlIllllIl[llIIIIllIlIIII[18]];
    llIIIIIIllIIIl[llIIIIllIlIIII[3]] = llIIIIlIllllIl[llIIIIllIlIIII[32]];
    llIIIIIIllIIIl[llIIIIllIlIIII[33]] = llIIIIlIllllIl[llIIIIllIlIIII[34]];
    llIIIIIIllIIIl[llIIIIllIlIIII[10]] = llIIIIlIllllIl[llIIIIllIlIIII[27]];
    llIIIIIIllIIIl[llIIIIllIlIIII[35]] = llIIIIlIllllIl[llIIIIllIlIIII[36]];
    llIIIIIIllIIIl[llIIIIllIlIIII[25]] = llIIIIlIllllIl[llIIIIllIlIIII[35]];
    llIIIIIIllIIIl[llIIIIllIlIIII[28]] = llIIIIlIllllIl[llIIIIllIlIIII[37]];
    llIIIIIIllIIIl[llIIIIllIlIIII[17]] = llIIIIlIllllIl[llIIIIllIlIIII[38]];
    llIIIIIIllIIIl[llIIIIllIlIIII[39]] = llIIIIlIllllIl[llIIIIllIlIIII[40]];
    llIIIIIIllIIIl[llIIIIllIlIIII[41]] = llIIIIlIllllIl[llIIIIllIlIIII[42]];
    llIIIIIIllIIIl[llIIIIllIlIIII[12]] = llIIIIlIllllIl[llIIIIllIlIIII[39]];
    llIIIIIIllIIIl[llIIIIllIlIIII[4]] = llIIIIlIllllIl[llIIIIllIlIIII[43]];
    llIIIIIIllIIIl[llIIIIllIlIIII[1]] = llIIIIlIllllIl[llIIIIllIlIIII[44]];
    llIIIIIIllIIIl[llIIIIllIlIIII[45]] = llIIIIlIllllIl[llIIIIllIlIIII[46]];
    llIIIIIIllIIIl[llIIIIllIlIIII[2]] = llIIIIlIllllIl[llIIIIllIlIIII[41]];
    llIIIIIIllIIIl[llIIIIllIlIIII[47]] = llIIIIlIllllIl[llIIIIllIlIIII[47]];
    llIIIIIIllIIIl[llIIIIllIlIIII[38]] = llIIIIlIllllIl[llIIIIllIlIIII[20]];
    llIIIIIIllIIIl[llIIIIllIlIIII[0]] = llIIIIlIllllIl[llIIIIllIlIIII[45]];
    llIIIIIIllIIIl[llIIIIllIlIIII[40]] = llIIIIlIllllIl[llIIIIllIlIIII[31]];
    llIIIIIIllIIIl[llIIIIllIlIIII[48]] = llIIIIlIllllIl[llIIIIllIlIIII[49]];
    llIIIIIIllIIIl[llIIIIllIlIIII[13]] = llIIIIlIllllIl[llIIIIllIlIIII[50]];
    llIIIIIIllIIIl[llIIIIllIlIIII[36]] = llIIIIlIllllIl[llIIIIllIlIIII[22]];
    llIIIIIIllIIIl[llIIIIllIlIIII[42]] = llIIIIlIllllIl[llIIIIllIlIIII[33]];
    llIIIIIIllIIIl[llIIIIllIlIIII[19]] = llIIIIlIllllIl[llIIIIllIlIIII[16]];
    llIIIIIIllIIIl[llIIIIllIlIIII[7]] = llIIIIlIllllIl[llIIIIllIlIIII[48]];
    llIIIIIIllIIIl[llIIIIllIlIIII[32]] = llIIIIlIllllIl[llIIIIllIlIIII[15]];
    llIIIIIIllIIIl[llIIIIllIlIIII[21]] = llIIIIlIllllIl[llIIIIllIlIIII[51]];
    llIIIIIIllIIIl[llIIIIllIlIIII[29]] = llIIIIlIllllIl[llIIIIllIlIIII[52]];
    llIIIIIIllIIIl[llIIIIllIlIIII[6]] = llIIIIlIllllIl[llIIIIllIlIIII[53]];
    llIIIIIIllIIIl[llIIIIllIlIIII[34]] = llIIIIlIllllIl[llIIIIllIlIIII[54]];
    llIIIIIIllIIIl[llIIIIllIlIIII[30]] = llIIIIlIllllIl[llIIIIllIlIIII[55]];
    llIIIIIIllIIIl[llIIIIllIlIIII[43]] = llIIIIlIllllIl[llIIIIllIlIIII[56]];
    llIIIIIIllIIIl[llIIIIllIlIIII[26]] = llIIIIlIllllIl[llIIIIllIlIIII[57]];
    llIIIIIIllIIIl[llIIIIllIlIIII[8]] = llIIIIlIllllIl[llIIIIllIlIIII[58]];
    llIIIIIIllIIIl[llIIIIllIlIIII[37]] = llIIIIlIllllIl[llIIIIllIlIIII[59]];
    llIIIIIIllIIIl[llIIIIllIlIIII[46]] = llIIIIlIllllIl[llIIIIllIlIIII[60]];
    llIIIIIIllIIIl[llIIIIllIlIIII[14]] = llIIIIlIllllIl[llIIIIllIlIIII[61]];
    llIIIIIIllIIIl[llIIIIllIlIIII[49]] = llIIIIlIllllIl[llIIIIllIlIIII[62]];
    llIIIIIIllIIIl[llIIIIllIlIIII[50]] = llIIIIlIllllIl[llIIIIllIlIIII[63]];
    llIIIIIIllIIIl[llIIIIllIlIIII[44]] = llIIIIlIllllIl[llIIIIllIlIIII[64]];
    llIIIIIIllIIlI = new Class[llIIIIllIlIIII[12]];
    llIIIIIIllIIlI[llIIIIllIlIIII[3]] = f100000000000000000000.Boolean.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[11]] = EnumHand.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[10]] = NetHandlerPlayClient.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[5]] = Minecraft.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[1]] = ao.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[0]] = f13.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[2]] = f100000000000000000000.Mode.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[4]] = f100000000000000000000.Double.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[6]] = WorldClient.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[7]] = List.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[9]] = Item.class;
    llIIIIIIllIIlI[llIIIIllIlIIII[8]] = EntityPlayerSP.class;
  }
  
  private static void lIIIIIlIlllIllll() {
    llIIIIlIllllIl = new String[llIIIIllIlIIII[65]];
    llIIIIlIllllIl[llIIIIllIlIIII[0]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[0]], llIIIIllIIlIll[llIIIIllIlIIII[1]]);
    llIIIIlIllllIl[llIIIIllIlIIII[1]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[2]], llIIIIllIIlIll[llIIIIllIlIIII[3]]);
    llIIIIlIllllIl[llIIIIllIlIIII[2]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[4]], llIIIIllIIlIll[llIIIIllIlIIII[5]]);
    llIIIIlIllllIl[llIIIIllIlIIII[3]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[6]], llIIIIllIIlIll[llIIIIllIlIIII[7]]);
    llIIIIlIllllIl[llIIIIllIlIIII[4]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[8]], llIIIIllIIlIll[llIIIIllIlIIII[9]]);
    llIIIIlIllllIl[llIIIIllIlIIII[5]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[10]], llIIIIllIIlIll[llIIIIllIlIIII[11]]);
    llIIIIlIllllIl[llIIIIllIlIIII[6]] = lIIIIIlIllIIllll(llIIIIllIIlIll[llIIIIllIlIIII[12]], llIIIIllIIlIll[llIIIIllIlIIII[13]]);
    llIIIIlIllllIl[llIIIIllIlIIII[7]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[14]], llIIIIllIIlIll[llIIIIllIlIIII[17]]);
    llIIIIlIllllIl[llIIIIllIlIIII[8]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[19]], llIIIIllIIlIll[llIIIIllIlIIII[21]]);
    llIIIIlIllllIl[llIIIIllIlIIII[9]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[23]], llIIIIllIIlIll[llIIIIllIlIIII[24]]);
    llIIIIlIllllIl[llIIIIllIlIIII[10]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[25]], llIIIIllIIlIll[llIIIIllIlIIII[26]]);
    llIIIIlIllllIl[llIIIIllIlIIII[11]] = lIIIIIlIllIIllll(llIIIIllIIlIll[llIIIIllIlIIII[28]], llIIIIllIIlIll[llIIIIllIlIIII[29]]);
    llIIIIlIllllIl[llIIIIllIlIIII[12]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[30]], llIIIIllIIlIll[llIIIIllIlIIII[18]]);
    llIIIIlIllllIl[llIIIIllIlIIII[13]] = lIIIIIlIllIIllll(llIIIIllIIlIll[llIIIIllIlIIII[32]], llIIIIllIIlIll[llIIIIllIlIIII[34]]);
    llIIIIlIllllIl[llIIIIllIlIIII[14]] = lIIIIIlIllIIlIlI(llIIIIllIIlIll[llIIIIllIlIIII[27]], llIIIIllIIlIll[llIIIIllIlIIII[36]]);
    llIIIIlIllllIl[llIIIIllIlIIII[17]] = lIIIIIlIllIIllll(llIIIIllIIlIll[llIIIIllIlIIII[35]], llIIIIllIIlIll[llIIIIllIlIIII[37]]);
    llIIIIlIllllIl[llIIIIllIlIIII[19]] = lIIIIIlIllIIlIll(llIIIIllIIlIll[llIIIIllIlIIII[38]], llIIIIllIIlIll[llIIIIllIlIIII[40]]);
    llIIIIlIllllIl[llIIIIllIlIIII[21]] = lIIIIIlIllIIlIlI("uzqIVfUSKpjr9GMx6zeT4HteI4izbVL2UlHxPOkJP48GpTgh+2gYPQ==", "BNAVQ");
    llIIIIlIllllIl[llIIIIllIlIIII[23]] = lIIIIIlIllIIllll("MDs/OWc2Oyc/Zxw2Jjk9YCwoNDw/FS9iYRxzBTIoLDtmNCg0PWYeJTU7PWNzeg==", "ZZIXI");
    llIIIIlIllllIl[llIIIIllIlIIII[24]] = lIIIIIlIllIIllll("ARN0ChoZBjMNCgMRdBsGHFg8SQpWBjYYFwkEYEpUTFZ6WU4=", "lvZyn");
    llIIIIlIllllIl[llIIIIllIlIIII[25]] = lIIIIIlIllIIllll("Ii8eN009OgE6TQshBSYCOi8cORFyLQc7Eyk8ATgEcmYkPAI+L0cjFyEiRzAWJi0cPwwmYS4jDSs6ATkNc2ckPAI+L0cjFyEiRxUMJT4JJAI8IRptWWg=", "HNhVc");
    llIIIIlIllllIl[llIIIIllIlIIII[26]] = lIIIIIlIllIIlIlI("tWwyPLvNaRgdeaGhgSI98w7L9wzbSkU1cnguuU/ZS3fAu21ONtVdOQFw8lDrYwvHixntegLTO7M3y37VXElYn6sQsUYM0KZs+jhvzu/uEnY=", "Zfzkd");
    llIIIIlIllllIl[llIIIIllIlIIII[28]] = lIIIIIlIllIIlIll("gOBO1HUBwGDi6fCtieVULQthEtRCeBAxJVlqwCXO43AQmGnBSTibazxCP8U83OgHmG8pL37mf0x0Bawt1zNHIZmBnnxSqbRY", "oPbCh");
    llIIIIlIllllIl[llIIIIllIlIIII[29]] = lIIIIIlIllIIllll("CQZiGB8REyUfDwsEYgkDFE0qWw9eESkMAhcXKRkpCwwgDgoKWWQnAQUVLUQHBQ0rRDgQESUFDF85ZScGAUw/Hx4UCjgPBANMLgMbSwV9W1tUU3xbW1RTfFtbVFN8W1tUU3xPKQsMIA4KClh2S0s=", "dcLkk");
    llIIIIlIllllIl[llIIIIllIlIIII[30]] = lIIIIIlIllIIlIll("HQdC0xt4pkMiZPFDLcrkfb8qIqMxSmLCHK/TCMnKyoMjn/k5T9DT/A==", "EBWSL");
    llIIIIlIllllIl[llIIIIllIlIIII[18]] = lIIIIIlIllIIlIlI("Y7+ljaVxVWqcftN3g7njPsAo1eGYmgYGX8XboHoT/c4=", "Segmk");
    llIIIIlIllllIl[llIIIIllIlIIII[32]] = lIIIIIlIllIIllll("NBNXBxwsBhAADDYRVxYAKVgfRAxjBBwTASoCHAYlNhIcTkAVHBgCCXYaGBoPdiUNBgE3EUI4AjgAGFsdLR8VWyQwBQ1PJDMXDxVHNRcXE0cKAgsdBj5NUDgFPFkKAB0pHw0QBz5ZGxwYdhBIRFhpRklEWGlGSURYaUZJRFhpRklQJTYSHE9SeVY=", "Yvyth");
    llIIIIlIllllIl[llIIIIllIlIIII[34]] = lIIIIIlIllIIllll("PxAAZBc4GxEpCDATAGQZPRwRJA5/EBo+EyUMWg8UJRwAMyo9FA0vCAIlTiwPPxYrfUphQ0wVH2tdOCQfJVoZIxQ0FgYrHCVaESQOOAENZT8/AR0+A2pcMHBacQ==", "QutJz");
    llIIIIlIllllIl[llIIIIllIlIIII[27]] = lIIIIIlIllIIlIlI("94BHLrzXdE9775Cf80d9Mp+petMA1wgNhnSTlgfZfPf7Xaw7Q7qoJw==", "ApAYe");
    llIIIIlIllllIl[llIIIIllIlIIII[36]] = lIIIIIlIllIIlIll("Lj25B1vH54kli3UbX3q4irYmyC6NmIU2zf319iDwh4U=", "DdgEQ");
    llIIIIlIllllIl[llIIIIllIlIIII[35]] = lIIIIIlIllIIlIlI("TIp5Dbz/kdihn9Y8bvOHOajFIUg+gL3/I/behzhAibHJXKAlM+gxS/8pdmnMy7JhRLUKMzib+oEwPMit9ZlSjoSStQBH5WBb", "QbiIt");
    llIIIIlIllllIl[llIIIIllIlIIII[37]] = lIIIIIlIllIIlIll("XTY4ysGGuXMIpCl/oHJAyYlFwrueOpG27AAkjRe+ByEgujKCuH1e9Xsprx9E4Z6l6Gu43GNMS3hoZKfMBnknwg==", "KgGaQ");
    llIIIIlIllllIl[llIIIIllIlIIII[38]] = lIIIIIlIllIIlIll("cT4zwjeLKtcQ+4G/d+BxLYJeJm5C+CeT2aAEtW8lYxGbuOQJ+kkHgC1FpQU6zwr0DMurWLc7xRE=", "egyrx");
    llIIIIlIllllIl[llIIIIllIlIIII[40]] = lIIIIIlIllIIlIll("gx2y5tfSVwiZNHFLjP2SIrjo8mMhB4LsOy7pkKqjGe3NC/hO0epG+g==", "HDZzZ");
    llIIIIlIllllIl[llIIIIllIlIIII[42]] = lIIIIIlIllIIlIlI("tRG3QBxLle81UUk/sa5vZ+wA3yf48Vha2UnGpuhBxch+FIIjuGG5cqGijQaOVEORR9aAJeJZz4/mzeJAXRJDYdazKRLuT1CxPzlqIAPAWOjq0KzfV84EqQfRtjaYrjdG", "wATVm");
    llIIIIlIllllIl[llIIIIllIlIIII[39]] = lIIIIIlIllIIllll("HhJFKyEGBwIsMRwQRTo9A1kNaDFJGghiYElXS3h1", "swkXU");
    llIIIIlIllllIl[llIIIIllIlIIII[43]] = lIIIIIlIllIIlIll("BvE5nATVPSIod/YgRikoVff4sp9chUKENTqxHpizpP51pOPRydoH3Q==", "gMRmq");
    llIIIIlIllllIl[llIIIIllIlIIII[44]] = lIIIIIlIllIIlIlI("duDFxsX/xIYzcpKxn2fQL4FGN/jLQJUjhW+fcz5eTqtFgVcu535A+g==", "GkvuS");
    llIIIIlIllllIl[llIIIIllIlIIII[46]] = lIIIIIlIllIIlIll("p6SfJGDRXg7zuxOaIbP2hOcH4AKLuJk+Rr8vzm11sniTvIpdcRhPNA==", "IlsrC");
    llIIIIlIllllIl[llIIIIllIlIIII[41]] = lIIIIIlIllIIlIlI("AtZNgsdNc1P0J/2HZG6t6YSzMFJpt4I1m5PW3NEO3JOwHjPUfjfXsjRIv/ZpIuxwHUDBnePlQMQ=", "NBZNi");
    llIIIIlIllllIl[llIIIIllIlIIII[47]] = lIIIIIlIllIIlIll("SrQjsKL5trTxLFVyhfyB94T9XvtscbWx5tzsrrvy+LkUdiRg9zeekBKMu5us+nTmfC2Ff9YXBkQBsMFBusueGhQjt+NLdzK2", "MYgqE");
    llIIIIlIllllIl[llIIIIllIlIIII[20]] = lIIIIIlIllIIllll("IRAOAkknEBYESRgFCgoJLEsdEhIqHQsqACUeCgYkKgIdWU8HGxkVBmQdGQ0AZCIMEQ4lFkNKPXFRWA==", "Kqxcg");
    llIIIIlIllllIl[llIIIIllIlIIII[45]] = lIIIIIlIllIIlIlI("jsJ4XeWbTFUJa1ANPHHTwxOo2NOt2SjbLJ7c40pzojXgpddViraHMQ==", "Czxld");
    llIIIIlIllllIl[llIIIIllIlIIII[31]] = lIIIIIlIllIIlIlI("PuIqoAkgpQsw8Ahrono1Qsdmbl0Hx1kbkn0VRvrrBXpy+/nVoWEgxA==", "ffVbR");
    llIIIIlIllllIl[llIIIIllIlIIII[49]] = lIIIIIlIllIIllll("Hj9cNiEGKhsxMRw9XCc9A3QUdGVDakJ1ZUNqQnVlQ2pCdWVDakJ1cTc1Byc5FmAVICElOx4wMElyWwFvU3o=", "sZrEU");
    llIIIIlIllllIl[llIIIIllIlIIII[50]] = lIIIIIlIllIIllll("KCYeTxgvLQ8CByclHk8WKioPDwFoDgMPECUxCwcBfCUDBBkiHF1QQXJyNQRPcHlKQVU=", "FCjau");
    llIIIIlIllllIl[llIIIIllIlIIII[22]] = lIIIIIlIllIIllll("JjBXOTw+JRA+LCQyVyggO3sfeixxJhw+Cjk0GiEtP29RBiIqIxhlJCo7HmUbPycQJC9wfC9waGs=", "KUyJH");
    llIIIIlIllllIl[llIIIIllIlIIII[33]] = lIIIIIlIllIIllll("Bj96BREeKj0CAQQ9ehQNG3QyRgFRLj0bABlgZUxFS3o=", "kZTve");
    llIIIIlIllllIl[llIIIIllIlIIII[16]] = lIIIIIlIllIIlIll("NNIO58aDP3LbOpfTHo98ex7lWUAKXCkAMvfapOloPIvyDX+dbeQRw0f4hZlnBzFbotv/06ccubY/Bkz3+v626S992Sj1e138C0ZqiPzCNMnf+h/HTo9wUor5dT53xUj3", "qyjIh");
    llIIIIlIllllIl[llIIIIllIlIIII[48]] = lIIIIIlIllIIllll("NQNDCwUtFgQMFTcBQxoZKEgLSBViFAgfGCsSCAo1NxMPFBRiTiESEC4HQhQQNgFCKwUqDwMfShwiKVE9NQNCCwUtFgQMFTcBQhoZKEkLSUFoVl1IQWhWXUhBaFZdSEFoVl1IVRwJGBodPV1XWFE=", "Xfmxq");
    llIIIIlIllllIl[llIIIIllIlIIII[15]] = lIIIIIlIllIIlIlI("2JwPwU7Uze9CB5AjFzv9CYYsrvdK4k0IHjKUY2JqPcxM+bqJUxWLzwCciBvr/iAm", "OsHrp");
    llIIIIlIllllIl[llIIIIllIlIIII[51]] = lIIIIIlIllIIllll("BQcgMH4aEj89fhwSJDQxAkgFJSIKBztrPQ4WbHkcBQcgMH8aEj89fwkTODIkBgk4fhYaCDUlOQAIbXgcBQcgMH8aEj89fxwSJDQxAkkFJSIKBztqak9G", "ofVQP");
    llIIIIlIllllIl[llIIIIllIlIIII[52]] = lIIIIIlIllIIlIlI("YzbFj4A/17K54bntIqIcrRS7tegOHqA5Ar6xMOOAxYShMP37BwIZbzqYw6gNJtxImE8PXMSG9TU=", "WWGMe");
    llIIIIlIllllIl[llIIIIllIlIIII[53]] = lIIIIIlIllIIllll("KDN/AR0wJjgGDSoxfxABNXg3Qg1/JSYdGyEZPx4Qf2VrUklldnE=", "EVQri");
    llIIIIlIllllIl[llIIIIllIlIIII[54]] = lIIIIIlIllIIllll("CD9WODgQKhE/KAo9VikkFXQeeyhfPhcALV9yNCUpEXUVIiIAOQoqKhF1HSU4DC4BZAkLLhE/NV5zLnFsRQ==", "eZxKL");
    llIIIIlIllllIl[llIIIIllIlIIII[55]] = lIIIIIlIllIIlIll("7j4FiikdIXW81DkJPAdljesYCaUummX3GfU3kQpxxf3/v3U4KomtxMw37TBinkQvWAU04eTQljpEtH+1CelIiej5HMA8tdAYgTvU6gxYNC7EbA49DmtxhjNtSfTPKkvJ", "JwgbT");
    llIIIIlIllllIl[llIIIIllIlIIII[56]] = lIIIIIlIllIIlIll("HNafABNoEaXRHkHKP4UyulRNanARW+Zu7rke4e+OFWfI2WXy9ciL9Pn8H6SAW0B46tmsTYGFVxihDjlhaBQMxA==", "XSSKc");
    llIIIIlIllllIl[llIIIIllIlIIII[57]] = lIIIIIlIllIIlIll("0Vbhzm69aCmWlXA02OqMCeS+gkFcdm7pynDkTch5tYZNTTV3VkhErA==", "Wuawt");
    llIIIIlIllllIl[llIIIIllIlIIII[58]] = lIIIIIlIllIIlIll("W4ceNuN6Y+kMMKwhJPrN5h9T0r1GKFq4O+tisaob4xlkj76ueGcbsg==", "UHCFA");
    llIIIIlIllllIl[llIIIIllIlIIII[59]] = lIIIIIlIllIIlIll("eoByV0QfbA4zgzpYVPPx1jUbzJ/Kssl3QfvUsHHDwthBpkC5u+LScSp9pyvBunRJckKSEk7EjJhheKXvcuYQfzKv12JY/ViwpEo/6a9Szf8=", "OWQlQ");
    llIIIIlIllllIl[llIIIIllIlIIII[60]] = lIIIIIlIllIIlIlI("erT+J+hFMdVUcbBlb3afQYTJoqAi8Iqq/X+9rV7+xiCmMK5O3w0e59we7iFYAcms", "bGpsS");
    llIIIIlIllllIl[llIIIIllIlIIII[61]] = lIIIIIlIllIIlIlI("7RLx/F6zj58As3wYGvTHxL+12Bw6S+AFoiKDoUGFe4cyMsz2DZFxb1a29eGj/XsqSTthoOss4ULwaELJ4HsQqUzuCl1yUmWh", "umgGh");
    llIIIIlIllllIl[llIIIIllIlIIII[62]] = lIIIIIlIllIIlIll("2vqOKtZU3GKn+rEhtf2t51ruCf7qAbgFnh45ddK0LqbU5zi2yFnFiM1dwvBZLxQAeqBoL57dM85LT3QhopywWOZJl3AZRb3X", "WjiAK");
    llIIIIlIllllIl[llIIIIllIlIIII[63]] = lIIIIIlIllIIlIlI("nqa75sgZtxzmQf1KS9WZs2RgoV6YOebtwdROo8nj0pqz3B2dnmstTcBoWzL2iSfKncWf3okXnzybIW9/OFdomDh85YOfj+1nt6/RMG9LtKVZOXA9zxfjWN5VeDOAvNNw", "Gwvwq");
    llIIIIlIllllIl[llIIIIllIlIIII[64]] = lIIIIIlIllIIlIll("OxR15zuRNELmYvMnbpkrzZbgDTd4OJ51dobQP6sHTcuB9s15ApWQ6VEy6ywsu7xHkV7aahsE5dxT9x70D9y4r47/93jOgXR1e/sHY+hozzgi9sJ7uQAxT5tBYPORReWeCQp+H6NAFWQ=", "JauiI");
    llIIIIllIIlIll = null;
  }
  
  private static void lIIIIIlIllllIIII() {
    String str = (new Exception()).getStackTrace()[llIIIIllIlIIII[0]].getFileName();
    llIIIIllIIlIll = str.substring(str.indexOf("ä") + llIIIIllIlIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIllIIlIlI(String lllllllllllllllIllIllIIIlIIlIlll, String lllllllllllllllIllIllIIIlIIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIlIIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIlIIlIllI.getBytes(StandardCharsets.UTF_8)), llIIIIllIlIIII[8]), "DES");
      Cipher lllllllllllllllIllIllIIIlIIllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIIlIIllIIl.init(llIIIIllIlIIII[2], lllllllllllllllIllIllIIIlIIllIlI);
      return new String(lllllllllllllllIllIllIIIlIIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIlIIllIII) {
      lllllllllllllllIllIllIIIlIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIllIIllll(String lllllllllllllllIllIllIIIlIIlIlII, String lllllllllllllllIllIllIIIlIIlIIll) {
    lllllllllllllllIllIllIIIlIIlIlII = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIIlIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIIlIIlIIlI = new StringBuilder();
    char[] lllllllllllllllIllIllIIIlIIlIIIl = lllllllllllllllIllIllIIIlIIlIIll.toCharArray();
    int lllllllllllllllIllIllIIIlIIlIIII = llIIIIllIlIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIIlIIlIlII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIllIlIIII[0];
    while (lIIIIIllIIIlIlII(j, i)) {
      char lllllllllllllllIllIllIIIlIIlIlIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIIlIIlIIII++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIIlIIlIIlI);
  }
  
  private static String lIIIIIlIllIIlIll(String lllllllllllllllIllIllIIIlIIIllII, String lllllllllllllllIllIllIIIlIIIlIll) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIlIIIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIlIIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIIlIIIlllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIIlIIIlllI.init(llIIIIllIlIIII[2], lllllllllllllllIllIllIIIlIIIllll);
      return new String(lllllllllllllllIllIllIIIlIIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIlIIIllIl) {
      lllllllllllllllIllIllIIIlIIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIIIIIllI() {
    llIIIIllIlIIII = new int[66];
    llIIIIllIlIIII[0] = (12 + 23 - -44 + 62 ^ (0x19 ^ 0x38) << " ".length() << " ".length()) << " ".length() & ((" ".length() << " ".length() << " ".length() << " ".length() ^ 0x63 ^ 0x7A) << " ".length() ^ -" ".length());
    llIIIIllIlIIII[1] = " ".length();
    llIIIIllIlIIII[2] = " ".length() << " ".length();
    llIIIIllIlIIII[3] = "   ".length();
    llIIIIllIlIIII[4] = " ".length() << " ".length() << " ".length();
    llIIIIllIlIIII[5] = (0x48 ^ 0x5D) << "   ".length() ^ 68 + 148 - 104 + 61;
    llIIIIllIlIIII[6] = "   ".length() << " ".length();
    llIIIIllIlIIII[7] = (0xA5 ^ 0xB8) << " ".length() << " ".length() ^ 0x25 ^ 0x56;
    llIIIIllIlIIII[8] = " ".length() << "   ".length();
    llIIIIllIlIIII[9] = (0xE4 ^ 0xAD) << " ".length() ^ 41 + 91 - 40 + 63;
    llIIIIllIlIIII[10] = ((0xDF ^ 0x90) << " ".length() ^ 60 + 126 - 91 + 60) << " ".length();
    llIIIIllIlIIII[11] = 0xA4 ^ 0xAF;
    llIIIIllIlIIII[12] = "   ".length() << " ".length() << " ".length();
    llIIIIllIlIIII[13] = 0x8C ^ 0x81;
    llIIIIllIlIIII[14] = (0x30 ^ 0x37) << " ".length();
    llIIIIllIlIIII[15] = ((0xB1 ^ 0xA2) << "   ".length() ^ 75 + 93 - 134 + 95) << " ".length();
    llIIIIllIlIIII[16] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllIlIIII[17] = 17 + 167 - 61 + 46 ^ (0xC2 ^ 0x91) << " ".length();
    llIIIIllIlIIII[18] = 0xAF ^ 0xB6;
    llIIIIllIlIIII[19] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllIlIIII[20] = (0x6D ^ 0x70) << " ".length() << " ".length() ^ 0xF ^ 0x52;
    llIIIIllIlIIII[21] = 0x0 ^ 0x11;
    llIIIIllIlIIII[22] = (0x10 ^ 0x7) << " ".length();
    llIIIIllIlIIII[23] = (0x50 ^ 0x59) << " ".length();
    llIIIIllIlIIII[24] = 0x5B ^ 0x48;
    llIIIIllIlIIII[25] = (0x34 ^ 0x45 ^ (0x9A ^ 0x87) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIllIlIIII[26] = 0xB6 ^ 0xA3;
    llIIIIllIlIIII[27] = (0xAD ^ 0xAA) << " ".length() << " ".length();
    llIIIIllIlIIII[28] = (0x45 ^ 0x4E) << " ".length();
    llIIIIllIlIIII[29] = 0x1 ^ 0x16;
    llIIIIllIlIIII[30] = "   ".length() << "   ".length();
    llIIIIllIlIIII[31] = 0x8F ^ 0xA4;
    llIIIIllIlIIII[32] = (0x0 ^ 0x33 ^ (0x80 ^ 0x9F) << " ".length()) << " ".length();
    llIIIIllIlIIII[33] = 0xBD ^ 0xB8 ^ (0x4C ^ 0x59) << " ".length();
    llIIIIllIlIIII[34] = (0x3A ^ 0x31) << "   ".length() ^ 0x0 ^ 0x43;
    llIIIIllIlIIII[35] = (0xAF ^ 0xA0) << " ".length();
    llIIIIllIlIIII[36] = 0x58 ^ 0x2D ^ (0xA6 ^ 0xAB) << "   ".length();
    llIIIIllIlIIII[37] = (0xA3 ^ 0xAA) << " ".length() ^ 0x5E ^ 0x53;
    llIIIIllIlIIII[38] = " ".length() << (0x57 ^ 0x44 ^ (0x1D ^ 0x16) << " ".length());
    llIIIIllIlIIII[39] = 0x51 ^ 0x72;
    llIIIIllIlIIII[40] = (0x21 ^ 0x70) << " ".length() ^ 116 + 84 - 118 + 49;
    llIIIIllIlIIII[41] = 0x84 ^ 0xA3;
    llIIIIllIlIIII[42] = (0xA5 ^ 0xB4) << " ".length();
    llIIIIllIlIIII[43] = ((0x85 ^ 0xAC) << " ".length() ^ 0xED ^ 0xB6) << " ".length() << " ".length();
    llIIIIllIlIIII[44] = 0x9F ^ 0xBA;
    llIIIIllIlIIII[45] = (0xAE ^ 0xBB) << " ".length();
    llIIIIllIlIIII[46] = ((0x16 ^ 0x3D) << " ".length() << " ".length() ^ 168 + 168 - 300 + 155) << " ".length();
    llIIIIllIlIIII[47] = ((0x45 ^ 0x68) << " ".length() ^ 0x5B ^ 0x4) << "   ".length();
    llIIIIllIlIIII[48] = 0x6C ^ 0x5D;
    llIIIIllIlIIII[49] = ((0x8E ^ 0x85) << " ".length() << " ".length() ^ 0x56 ^ 0x71) << " ".length() << " ".length();
    llIIIIllIlIIII[50] = 0x26 ^ 0xB;
    llIIIIllIlIIII[51] = 0x46 ^ 0x75;
    llIIIIllIlIIII[52] = ((0x3F ^ 0x34) << "   ".length() ^ 0xD9 ^ 0x8C) << " ".length() << " ".length();
    llIIIIllIlIIII[53] = (0x79 ^ 0x70) << "   ".length() ^ 0x36 ^ 0x4B;
    llIIIIllIlIIII[54] = ((0x6C ^ 0x7B) << " ".length() << " ".length() ^ 0xFA ^ 0xBD) << " ".length();
    llIIIIllIlIIII[55] = 0xC9 ^ 0xC0 ^ (0x13 ^ 0xC) << " ".length();
    llIIIIllIlIIII[56] = (0xAC ^ 0xAB) << "   ".length();
    llIIIIllIlIIII[57] = (0x3D ^ 0x10) << " ".length() ^ 0x0 ^ 0x63;
    llIIIIllIlIIII[58] = (0x74 ^ 0x69) << " ".length();
    llIIIIllIlIIII[59] = 0xD6 ^ 0x93 ^ (0x90 ^ 0xAF) << " ".length();
    llIIIIllIlIIII[60] = (0x75 ^ 0x16 ^ (0x18 ^ 0x3) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIllIlIIII[61] = 0xF ^ 0x32;
    llIIIIllIlIIII[62] = ((0x14 ^ 0x41) << " ".length() ^ 165 + 36 - 149 + 129) << " ".length();
    llIIIIllIlIIII[63] = 0x66 ^ 0x59;
    llIIIIllIlIIII[64] = " ".length() << "   ".length() << " ".length();
    llIIIIllIlIIII[65] = 0xA6 ^ 0x99 ^ (0x5D ^ 0x62) << " ".length();
  }
  
  private static boolean lIIIIIllIIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIllIIIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllIIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIllIIIIlIlI(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIllIIIIlIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIllIIIIlIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIllIIIIIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIllIIIIllII(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static int lIIIIIllIIIIlIll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */