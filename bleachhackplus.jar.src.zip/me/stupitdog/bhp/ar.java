package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.Vec3d;

public class ar {
  private static String[] lIlllIIIIlllII;
  
  private static Class[] lIlllIIIIlllIl;
  
  private static final String[] lIlllIIllIIlII;
  
  private static String[] lIlllIIllIlIll;
  
  private static final int[] lIlllIIllIllII;
  
  public static Vec3d interpolateEntity(Entity lllllllllllllllIlllIllIlIIlllIII, float lllllllllllllllIlllIllIlIIllIlll) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 0 : (Lnet/minecraft/entity/Entity;)D
    //   10: aload_0
    //   11: <illegal opcode> 1 : (Lnet/minecraft/entity/Entity;)D
    //   16: aload_0
    //   17: <illegal opcode> 0 : (Lnet/minecraft/entity/Entity;)D
    //   22: dsub
    //   23: fload_1
    //   24: f2d
    //   25: dmul
    //   26: dadd
    //   27: aload_0
    //   28: <illegal opcode> 2 : (Lnet/minecraft/entity/Entity;)D
    //   33: aload_0
    //   34: <illegal opcode> 3 : (Lnet/minecraft/entity/Entity;)D
    //   39: aload_0
    //   40: <illegal opcode> 2 : (Lnet/minecraft/entity/Entity;)D
    //   45: dsub
    //   46: fload_1
    //   47: f2d
    //   48: dmul
    //   49: dadd
    //   50: aload_0
    //   51: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   56: aload_0
    //   57: <illegal opcode> 5 : (Lnet/minecraft/entity/Entity;)D
    //   62: aload_0
    //   63: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   68: dsub
    //   69: fload_1
    //   70: f2d
    //   71: dmul
    //   72: dadd
    //   73: invokespecial <init> : (DDD)V
    //   76: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIlllIllIlIIlllIII	Lnet/minecraft/entity/Entity;
    //   0	77	1	lllllllllllllllIlllIllIlIIllIlll	F
  }
  
  public static double radToDeg(double lllllllllllllllIlllIllIlIIllIllI) {
    return lllllllllllllllIlllIllIlIIllIllI * 57.295780181884766D;
  }
  
  public static double degToRad(double lllllllllllllllIlllIllIlIIllIlIl) {
    return lllllllllllllllIlllIllIlIIllIlIl * 0.01745329238474369D;
  }
  
  public static Vec3d direction(float lllllllllllllllIlllIllIlIIllIlII) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: fload_0
    //   5: ldc 90.0
    //   7: fadd
    //   8: f2d
    //   9: <illegal opcode> 6 : (D)D
    //   14: <illegal opcode> 7 : (D)D
    //   19: dconst_0
    //   20: fload_0
    //   21: ldc 90.0
    //   23: fadd
    //   24: f2d
    //   25: <illegal opcode> 6 : (D)D
    //   30: <illegal opcode> 8 : (D)D
    //   35: invokespecial <init> : (DDD)V
    //   38: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	39	0	lllllllllllllllIlllIllIlIIllIlII	F
  }
  
  public static float[] calcAngle(Vec3d lllllllllllllllIlllIllIlIIllIIll, Vec3d lllllllllllllllIlllIllIlIIllIIlI) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   6: aload_0
    //   7: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   12: dsub
    //   13: dstore_2
    //   14: aload_1
    //   15: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   20: aload_0
    //   21: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   26: dsub
    //   27: ldc2_w -1.0
    //   30: dmul
    //   31: dstore #4
    //   33: aload_1
    //   34: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   39: aload_0
    //   40: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   45: dsub
    //   46: dstore #6
    //   48: dload_2
    //   49: dload_2
    //   50: dmul
    //   51: dload #6
    //   53: dload #6
    //   55: dmul
    //   56: dadd
    //   57: <illegal opcode> 12 : (D)F
    //   62: f2d
    //   63: dstore #8
    //   65: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   68: iconst_0
    //   69: iaload
    //   70: newarray float
    //   72: dup
    //   73: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   76: iconst_1
    //   77: iaload
    //   78: dload #6
    //   80: dload_2
    //   81: <illegal opcode> 13 : (DD)D
    //   86: <illegal opcode> 14 : (D)D
    //   91: ldc2_w 90.0
    //   94: dsub
    //   95: <illegal opcode> 15 : (D)D
    //   100: d2f
    //   101: fastore
    //   102: dup
    //   103: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   106: iconst_2
    //   107: iaload
    //   108: dload #4
    //   110: dload #8
    //   112: <illegal opcode> 13 : (DD)D
    //   117: <illegal opcode> 14 : (D)D
    //   122: <illegal opcode> 15 : (D)D
    //   127: d2f
    //   128: fastore
    //   129: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	130	0	lllllllllllllllIlllIllIlIIllIIll	Lnet/minecraft/util/math/Vec3d;
    //   0	130	1	lllllllllllllllIlllIllIlIIllIIlI	Lnet/minecraft/util/math/Vec3d;
    //   14	116	2	lllllllllllllllIlllIllIlIIllIIIl	D
    //   33	97	4	lllllllllllllllIlllIllIlIIllIIII	D
    //   48	82	6	lllllllllllllllIlllIllIlIIlIllll	D
    //   65	65	8	lllllllllllllllIlllIllIlIIlIlllI	D
  }
  
  public static double[] directionSpeed(double lllllllllllllllIlllIllIlIIlIllIl) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   5: astore_2
    //   6: aload_2
    //   7: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   12: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   17: <illegal opcode> 19 : (Lnet/minecraft/util/MovementInput;)F
    //   22: fstore_3
    //   23: aload_2
    //   24: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   34: <illegal opcode> 20 : (Lnet/minecraft/util/MovementInput;)F
    //   39: fstore #4
    //   41: aload_2
    //   42: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   47: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   52: aload_2
    //   53: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   58: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   63: aload_2
    //   64: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   69: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   74: fsub
    //   75: aload_2
    //   76: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)F
    //   81: fmul
    //   82: fadd
    //   83: fstore #5
    //   85: fload_3
    //   86: fconst_0
    //   87: invokestatic lllllIIlIIIlIll : (FF)I
    //   90: invokestatic lllllIIlIIIllIl : (I)Z
    //   93: ifeq -> 316
    //   96: fload #4
    //   98: fconst_0
    //   99: invokestatic lllllIIlIIIlIll : (FF)I
    //   102: invokestatic lllllIIlIIIlllI : (I)Z
    //   105: ifeq -> 185
    //   108: fload #5
    //   110: fload_3
    //   111: fconst_0
    //   112: invokestatic lllllIIlIIIlIll : (FF)I
    //   115: invokestatic lllllIIlIIIlllI : (I)Z
    //   118: ifeq -> 149
    //   121: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   124: iconst_3
    //   125: iaload
    //   126: ldc ''
    //   128: invokevirtual length : ()I
    //   131: pop
    //   132: ldc ' '
    //   134: invokevirtual length : ()I
    //   137: ineg
    //   138: ldc ' '
    //   140: invokevirtual length : ()I
    //   143: ineg
    //   144: if_icmpeq -> 154
    //   147: aconst_null
    //   148: areturn
    //   149: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   152: iconst_4
    //   153: iaload
    //   154: i2f
    //   155: fadd
    //   156: fstore #5
    //   158: ldc ''
    //   160: invokevirtual length : ()I
    //   163: pop
    //   164: ldc ' '
    //   166: invokevirtual length : ()I
    //   169: ldc ' '
    //   171: invokevirtual length : ()I
    //   174: ishl
    //   175: ldc ' '
    //   177: invokevirtual length : ()I
    //   180: if_icmpge -> 253
    //   183: aconst_null
    //   184: areturn
    //   185: fload #4
    //   187: fconst_0
    //   188: invokestatic lllllIIlIIIllII : (FF)I
    //   191: invokestatic lllllIIlIIIllll : (I)Z
    //   194: ifeq -> 253
    //   197: fload #5
    //   199: fload_3
    //   200: fconst_0
    //   201: invokestatic lllllIIlIIIlIll : (FF)I
    //   204: invokestatic lllllIIlIIIlllI : (I)Z
    //   207: ifeq -> 244
    //   210: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   213: iconst_4
    //   214: iaload
    //   215: ldc ''
    //   217: invokevirtual length : ()I
    //   220: pop
    //   221: bipush #8
    //   223: bipush #53
    //   225: ixor
    //   226: bipush #112
    //   228: bipush #119
    //   230: ixor
    //   231: ldc '   '
    //   233: invokevirtual length : ()I
    //   236: ishl
    //   237: ixor
    //   238: ineg
    //   239: iflt -> 249
    //   242: aconst_null
    //   243: areturn
    //   244: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   247: iconst_3
    //   248: iaload
    //   249: i2f
    //   250: fadd
    //   251: fstore #5
    //   253: fconst_0
    //   254: fstore #4
    //   256: fload_3
    //   257: fconst_0
    //   258: invokestatic lllllIIlIIIlIll : (FF)I
    //   261: invokestatic lllllIIlIIIlllI : (I)Z
    //   264: ifeq -> 302
    //   267: fconst_1
    //   268: fstore_3
    //   269: ldc ''
    //   271: invokevirtual length : ()I
    //   274: pop
    //   275: ldc ' '
    //   277: invokevirtual length : ()I
    //   280: ldc ' '
    //   282: invokevirtual length : ()I
    //   285: ldc ' '
    //   287: invokevirtual length : ()I
    //   290: ishl
    //   291: ishl
    //   292: ldc ' '
    //   294: invokevirtual length : ()I
    //   297: if_icmpgt -> 316
    //   300: aconst_null
    //   301: areturn
    //   302: fload_3
    //   303: fconst_0
    //   304: invokestatic lllllIIlIIIllII : (FF)I
    //   307: invokestatic lllllIIlIIIllll : (I)Z
    //   310: ifeq -> 316
    //   313: ldc -1.0
    //   315: fstore_3
    //   316: fload #5
    //   318: ldc 90.0
    //   320: fadd
    //   321: f2d
    //   322: <illegal opcode> 24 : (D)D
    //   327: <illegal opcode> 8 : (D)D
    //   332: dstore #6
    //   334: fload #5
    //   336: ldc 90.0
    //   338: fadd
    //   339: f2d
    //   340: <illegal opcode> 24 : (D)D
    //   345: <illegal opcode> 7 : (D)D
    //   350: dstore #8
    //   352: fload_3
    //   353: f2d
    //   354: dload_0
    //   355: dmul
    //   356: dload #8
    //   358: dmul
    //   359: fload #4
    //   361: f2d
    //   362: dload_0
    //   363: dmul
    //   364: dload #6
    //   366: dmul
    //   367: dadd
    //   368: dstore #10
    //   370: fload_3
    //   371: f2d
    //   372: dload_0
    //   373: dmul
    //   374: dload #6
    //   376: dmul
    //   377: fload #4
    //   379: f2d
    //   380: dload_0
    //   381: dmul
    //   382: dload #8
    //   384: dmul
    //   385: dsub
    //   386: dstore #12
    //   388: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   391: iconst_0
    //   392: iaload
    //   393: newarray double
    //   395: dup
    //   396: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   399: iconst_1
    //   400: iaload
    //   401: dload #10
    //   403: dastore
    //   404: dup
    //   405: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   408: iconst_2
    //   409: iaload
    //   410: dload #12
    //   412: dastore
    //   413: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	414	0	lllllllllllllllIlllIllIlIIlIllIl	D
    //   6	408	2	lllllllllllllllIlllIllIlIIlIllII	Lnet/minecraft/client/Minecraft;
    //   23	391	3	lllllllllllllllIlllIllIlIIlIlIll	F
    //   41	373	4	lllllllllllllllIlllIllIlIIlIlIlI	F
    //   85	329	5	lllllllllllllllIlllIllIlIIlIlIIl	F
    //   334	80	6	lllllllllllllllIlllIllIlIIlIlIII	D
    //   352	62	8	lllllllllllllllIlllIllIlIIlIIlll	D
    //   370	44	10	lllllllllllllllIlllIllIlIIlIIllI	D
    //   388	26	12	lllllllllllllllIlllIllIlIIlIIlIl	D
  }
  
  public static double[] directionSpeedNoForward(double lllllllllllllllIlllIllIlIIlIIlII) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lnet/minecraft/client/Minecraft;
    //   5: astore_2
    //   6: fconst_1
    //   7: fstore_3
    //   8: aload_2
    //   9: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   14: <illegal opcode> 26 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   19: <illegal opcode> 27 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   24: invokestatic lllllIIlIIlIIlI : (I)Z
    //   27: ifeq -> 96
    //   30: aload_2
    //   31: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   36: <illegal opcode> 28 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   41: <illegal opcode> 27 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   46: invokestatic lllllIIlIIlIIlI : (I)Z
    //   49: ifeq -> 96
    //   52: aload_2
    //   53: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   58: <illegal opcode> 29 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   63: <illegal opcode> 27 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   68: invokestatic lllllIIlIIlIIlI : (I)Z
    //   71: ifeq -> 96
    //   74: aload_2
    //   75: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   80: <illegal opcode> 30 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   85: <illegal opcode> 27 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   90: invokestatic lllllIIlIIIllIl : (I)Z
    //   93: ifeq -> 113
    //   96: aload_2
    //   97: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   102: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   107: <illegal opcode> 19 : (Lnet/minecraft/util/MovementInput;)F
    //   112: fstore_3
    //   113: aload_2
    //   114: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   119: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   124: <illegal opcode> 20 : (Lnet/minecraft/util/MovementInput;)F
    //   129: fstore #4
    //   131: aload_2
    //   132: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   137: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   142: aload_2
    //   143: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   148: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   153: aload_2
    //   154: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   159: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   164: fsub
    //   165: aload_2
    //   166: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)F
    //   171: fmul
    //   172: fadd
    //   173: fstore #5
    //   175: fload_3
    //   176: fconst_0
    //   177: invokestatic lllllIIlIIlIIII : (FF)I
    //   180: invokestatic lllllIIlIIIllIl : (I)Z
    //   183: ifeq -> 430
    //   186: fload #4
    //   188: fconst_0
    //   189: invokestatic lllllIIlIIlIIII : (FF)I
    //   192: invokestatic lllllIIlIIIlllI : (I)Z
    //   195: ifeq -> 283
    //   198: fload #5
    //   200: fload_3
    //   201: fconst_0
    //   202: invokestatic lllllIIlIIlIIII : (FF)I
    //   205: invokestatic lllllIIlIIIlllI : (I)Z
    //   208: ifeq -> 252
    //   211: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   214: iconst_3
    //   215: iaload
    //   216: ldc ''
    //   218: invokevirtual length : ()I
    //   221: pop
    //   222: bipush #41
    //   224: bipush #62
    //   226: iadd
    //   227: bipush #92
    //   229: isub
    //   230: sipush #130
    //   233: iadd
    //   234: bipush #43
    //   236: bipush #58
    //   238: ixor
    //   239: ldc '   '
    //   241: invokevirtual length : ()I
    //   244: ishl
    //   245: ixor
    //   246: ineg
    //   247: iflt -> 257
    //   250: aconst_null
    //   251: areturn
    //   252: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   255: iconst_4
    //   256: iaload
    //   257: i2f
    //   258: fadd
    //   259: fstore #5
    //   261: ldc ''
    //   263: invokevirtual length : ()I
    //   266: pop
    //   267: ldc ' '
    //   269: invokevirtual length : ()I
    //   272: ldc ' '
    //   274: invokevirtual length : ()I
    //   277: ishl
    //   278: ifgt -> 355
    //   281: aconst_null
    //   282: areturn
    //   283: fload #4
    //   285: fconst_0
    //   286: invokestatic lllllIIlIIlIIIl : (FF)I
    //   289: invokestatic lllllIIlIIIllll : (I)Z
    //   292: ifeq -> 355
    //   295: fload #5
    //   297: fload_3
    //   298: fconst_0
    //   299: invokestatic lllllIIlIIlIIII : (FF)I
    //   302: invokestatic lllllIIlIIIlllI : (I)Z
    //   305: ifeq -> 346
    //   308: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   311: iconst_4
    //   312: iaload
    //   313: ldc ''
    //   315: invokevirtual length : ()I
    //   318: pop
    //   319: ldc '   '
    //   321: invokevirtual length : ()I
    //   324: ldc ' '
    //   326: invokevirtual length : ()I
    //   329: ldc ' '
    //   331: invokevirtual length : ()I
    //   334: ldc ' '
    //   336: invokevirtual length : ()I
    //   339: ishl
    //   340: ishl
    //   341: if_icmplt -> 351
    //   344: aconst_null
    //   345: areturn
    //   346: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   349: iconst_3
    //   350: iaload
    //   351: i2f
    //   352: fadd
    //   353: fstore #5
    //   355: fconst_0
    //   356: fstore #4
    //   358: fload_3
    //   359: fconst_0
    //   360: invokestatic lllllIIlIIlIIII : (FF)I
    //   363: invokestatic lllllIIlIIIlllI : (I)Z
    //   366: ifeq -> 416
    //   369: fconst_1
    //   370: fstore_3
    //   371: ldc ''
    //   373: invokevirtual length : ()I
    //   376: pop
    //   377: ldc ' '
    //   379: invokevirtual length : ()I
    //   382: ldc ' '
    //   384: invokevirtual length : ()I
    //   387: ldc ' '
    //   389: invokevirtual length : ()I
    //   392: ishl
    //   393: ishl
    //   394: ldc ' '
    //   396: invokevirtual length : ()I
    //   399: ldc ' '
    //   401: invokevirtual length : ()I
    //   404: ldc ' '
    //   406: invokevirtual length : ()I
    //   409: ishl
    //   410: ishl
    //   411: if_icmpeq -> 430
    //   414: aconst_null
    //   415: areturn
    //   416: fload_3
    //   417: fconst_0
    //   418: invokestatic lllllIIlIIlIIIl : (FF)I
    //   421: invokestatic lllllIIlIIIllll : (I)Z
    //   424: ifeq -> 430
    //   427: ldc -1.0
    //   429: fstore_3
    //   430: fload #5
    //   432: ldc 90.0
    //   434: fadd
    //   435: f2d
    //   436: <illegal opcode> 24 : (D)D
    //   441: <illegal opcode> 8 : (D)D
    //   446: dstore #6
    //   448: fload #5
    //   450: ldc 90.0
    //   452: fadd
    //   453: f2d
    //   454: <illegal opcode> 24 : (D)D
    //   459: <illegal opcode> 7 : (D)D
    //   464: dstore #8
    //   466: fload_3
    //   467: f2d
    //   468: dload_0
    //   469: dmul
    //   470: dload #8
    //   472: dmul
    //   473: fload #4
    //   475: f2d
    //   476: dload_0
    //   477: dmul
    //   478: dload #6
    //   480: dmul
    //   481: dadd
    //   482: dstore #10
    //   484: fload_3
    //   485: f2d
    //   486: dload_0
    //   487: dmul
    //   488: dload #6
    //   490: dmul
    //   491: fload #4
    //   493: f2d
    //   494: dload_0
    //   495: dmul
    //   496: dload #8
    //   498: dmul
    //   499: dsub
    //   500: dstore #12
    //   502: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   505: iconst_0
    //   506: iaload
    //   507: newarray double
    //   509: dup
    //   510: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   513: iconst_1
    //   514: iaload
    //   515: dload #10
    //   517: dastore
    //   518: dup
    //   519: getstatic me/stupitdog/bhp/ar.lIlllIIllIllII : [I
    //   522: iconst_2
    //   523: iaload
    //   524: dload #12
    //   526: dastore
    //   527: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	528	0	lllllllllllllllIlllIllIlIIlIIlII	D
    //   6	522	2	lllllllllllllllIlllIllIlIIlIIIll	Lnet/minecraft/client/Minecraft;
    //   8	520	3	lllllllllllllllIlllIllIlIIlIIIlI	F
    //   131	397	4	lllllllllllllllIlllIllIlIIlIIIIl	F
    //   175	353	5	lllllllllllllllIlllIllIlIIlIIIII	F
    //   448	80	6	lllllllllllllllIlllIllIlIIIlllll	D
    //   466	62	8	lllllllllllllllIlllIllIlIIIllllI	D
    //   484	44	10	lllllllllllllllIlllIllIlIIIlllIl	D
    //   502	26	12	lllllllllllllllIlllIllIlIIIlllII	D
  }
  
  public static Vec3d mult(Vec3d lllllllllllllllIlllIllIlIIIllIll, Vec3d lllllllllllllllIlllIllIlIIIllIlI) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   10: aload_1
    //   11: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   16: dmul
    //   17: aload_0
    //   18: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   23: aload_1
    //   24: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   29: dmul
    //   30: aload_0
    //   31: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   36: aload_1
    //   37: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   42: dmul
    //   43: invokespecial <init> : (DDD)V
    //   46: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIlllIllIlIIIllIll	Lnet/minecraft/util/math/Vec3d;
    //   0	47	1	lllllllllllllllIlllIllIlIIIllIlI	Lnet/minecraft/util/math/Vec3d;
  }
  
  public static Vec3d mult(Vec3d lllllllllllllllIlllIllIlIIIllIIl, float lllllllllllllllIlllIllIlIIIllIII) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   10: fload_1
    //   11: f2d
    //   12: dmul
    //   13: aload_0
    //   14: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   19: fload_1
    //   20: f2d
    //   21: dmul
    //   22: aload_0
    //   23: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   28: fload_1
    //   29: f2d
    //   30: dmul
    //   31: invokespecial <init> : (DDD)V
    //   34: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	35	0	lllllllllllllllIlllIllIlIIIllIIl	Lnet/minecraft/util/math/Vec3d;
    //   0	35	1	lllllllllllllllIlllIllIlIIIllIII	F
  }
  
  public static Vec3d div(Vec3d lllllllllllllllIlllIllIlIIIlIlll, Vec3d lllllllllllllllIlllIllIlIIIlIllI) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   10: aload_1
    //   11: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   16: ddiv
    //   17: aload_0
    //   18: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   23: aload_1
    //   24: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   29: ddiv
    //   30: aload_0
    //   31: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   36: aload_1
    //   37: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   42: ddiv
    //   43: invokespecial <init> : (DDD)V
    //   46: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIlllIllIlIIIlIlll	Lnet/minecraft/util/math/Vec3d;
    //   0	47	1	lllllllllllllllIlllIllIlIIIlIllI	Lnet/minecraft/util/math/Vec3d;
  }
  
  public static Vec3d div(Vec3d lllllllllllllllIlllIllIlIIIlIlIl, float lllllllllllllllIlllIllIlIIIlIlII) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   10: fload_1
    //   11: f2d
    //   12: ddiv
    //   13: aload_0
    //   14: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   19: fload_1
    //   20: f2d
    //   21: ddiv
    //   22: aload_0
    //   23: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   28: fload_1
    //   29: f2d
    //   30: ddiv
    //   31: invokespecial <init> : (DDD)V
    //   34: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	35	0	lllllllllllllllIlllIllIlIIIlIlIl	Lnet/minecraft/util/math/Vec3d;
    //   0	35	1	lllllllllllllllIlllIllIlIIIlIlII	F
  }
  
  public static double round(double lllllllllllllllIlllIllIlIIIlIIll, int lllllllllllllllIlllIllIlIIIlIIlI) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic lllllIIlIIIllll : (I)Z
    //   4: ifeq -> 9
    //   7: dload_0
    //   8: dreturn
    //   9: new java/math/BigDecimal
    //   12: dup
    //   13: dload_0
    //   14: invokespecial <init> : (D)V
    //   17: iload_2
    //   18: <illegal opcode> 31 : ()Ljava/math/RoundingMode;
    //   23: <illegal opcode> 32 : (Ljava/math/BigDecimal;ILjava/math/RoundingMode;)Ljava/math/BigDecimal;
    //   28: <illegal opcode> 33 : (Ljava/math/BigDecimal;)D
    //   33: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	34	0	lllllllllllllllIlllIllIlIIIlIIll	D
    //   0	34	2	lllllllllllllllIlllIllIlIIIlIIlI	I
  }
  
  public static float clamp(float lllllllllllllllIlllIllIlIIIlIIIl, float lllllllllllllllIlllIllIlIIIlIIII, float lllllllllllllllIlllIllIlIIIIllll) {
    if (lllllIIlIIlIlIl(lllllIIlIIlIIll(lllllllllllllllIlllIllIlIIIlIIIl, lllllllllllllllIlllIllIlIIIlIIII)))
      lllllllllllllllIlllIllIlIIIlIIIl = lllllllllllllllIlllIllIlIIIlIIII; 
    if (lllllIIlIIlIllI(lllllIIlIIlIlII(lllllllllllllllIlllIllIlIIIlIIIl, lllllllllllllllIlllIllIlIIIIllll)))
      lllllllllllllllIlllIllIlIIIlIIIl = lllllllllllllllIlllIllIlIIIIllll; 
    return lllllllllllllllIlllIllIlIIIlIIIl;
  }
  
  public static float wrap(float lllllllllllllllIlllIllIlIIIIlllI) {
    lllllllllllllllIlllIllIlIIIIlllI %= 360.0F;
    if (lllllIIlIIlIllI(lllllIIlIIlIlll(lllllllllllllllIlllIllIlIIIIlllI, 180.0F)))
      lllllllllllllllIlllIllIlIIIIlllI -= 360.0F; 
    if (lllllIIlIIIllll(lllllIIlIIllIII(lllllllllllllllIlllIllIlIIIIlllI, -180.0F)))
      lllllllllllllllIlllIllIlIIIIlllI += 360.0F; 
    return lllllllllllllllIlllIllIlIIIIlllI;
  }
  
  public static double map(double lllllllllllllllIlllIllIlIIIIllIl, double lllllllllllllllIlllIllIlIIIIllII, double lllllllllllllllIlllIllIlIIIIlIll, double lllllllllllllllIlllIllIlIIIIlIlI, double lllllllllllllllIlllIllIlIIIIlIIl) {
    lllllllllllllllIlllIllIlIIIIllIl = (lllllllllllllllIlllIllIlIIIIllIl - lllllllllllllllIlllIllIlIIIIllII) / (lllllllllllllllIlllIllIlIIIIlIll - lllllllllllllllIlllIllIlIIIIllII);
    return lllllllllllllllIlllIllIlIIIIlIlI + lllllllllllllllIlllIllIlIIIIllIl * (lllllllllllllllIlllIllIlIIIIlIIl - lllllllllllllllIlllIllIlIIIIlIlI);
  }
  
  public static double linear(double lllllllllllllllIlllIllIlIIIIlIII, double lllllllllllllllIlllIllIlIIIIIlll, double lllllllllllllllIlllIllIlIIIIIllI) {
    if (lllllIIlIIIllll(lllllIIlIIllIIl(lllllllllllllllIlllIllIlIIIIlIII, lllllllllllllllIlllIllIlIIIIIlll - lllllllllllllllIlllIllIlIIIIIllI))) {
      "".length();
      if (((0x53 ^ 0x6E ^ " ".length() << " ".length() << " ".length()) & (0xB1 ^ 0xA0 ^ (0xC3 ^ 0xC6) << "   ".length() ^ -" ".length())) == " ".length() << " ".length() << " ".length())
        return 0.0D; 
    } else if (lllllIIlIIIlllI(lllllIIlIIllIlI(lllllllllllllllIlllIllIlIIIIlIII, lllllllllllllllIlllIllIlIIIIIlll + lllllllllllllllIlllIllIlIIIIIllI))) {
      "".length();
      if (null != null)
        return 0.0D; 
    } else {
    
    } 
    return lllllllllllllllIlllIllIlIIIIIlll;
  }
  
  public static double parabolic(double lllllllllllllllIlllIllIlIIIIIlIl, double lllllllllllllllIlllIllIlIIIIIlII, double lllllllllllllllIlllIllIlIIIIIIll) {
    return lllllllllllllllIlllIllIlIIIIIlIl + (lllllllllllllllIlllIllIlIIIIIlII - lllllllllllllllIlllIllIlIIIIIlIl) / lllllllllllllllIlllIllIlIIIIIIll;
  }
  
  public static double getDistance(Vec3d lllllllllllllllIlllIllIlIIIIIIlI, double lllllllllllllllIlllIllIlIIIIIIIl, double lllllllllllllllIlllIllIlIIIIIIII, double lllllllllllllllIlllIllIIllllllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 9 : (Lnet/minecraft/util/math/Vec3d;)D
    //   6: dload_1
    //   7: dsub
    //   8: dstore #7
    //   10: aload_0
    //   11: <illegal opcode> 10 : (Lnet/minecraft/util/math/Vec3d;)D
    //   16: dload_3
    //   17: dsub
    //   18: dstore #9
    //   20: aload_0
    //   21: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   26: dload #5
    //   28: dsub
    //   29: dstore #11
    //   31: dload #7
    //   33: dload #7
    //   35: dmul
    //   36: dload #9
    //   38: dload #9
    //   40: dmul
    //   41: dadd
    //   42: dload #11
    //   44: dload #11
    //   46: dmul
    //   47: dadd
    //   48: <illegal opcode> 12 : (D)F
    //   53: f2d
    //   54: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	55	0	lllllllllllllllIlllIllIlIIIIIIlI	Lnet/minecraft/util/math/Vec3d;
    //   0	55	1	lllllllllllllllIlllIllIlIIIIIIIl	D
    //   0	55	3	lllllllllllllllIlllIllIlIIIIIIII	D
    //   0	55	5	lllllllllllllllIlllIllIIllllllll	D
    //   10	45	7	lllllllllllllllIlllIllIIlllllllI	D
    //   20	35	9	lllllllllllllllIlllIllIIllllllIl	D
    //   31	24	11	lllllllllllllllIlllIllIIllllllII	D
  }
  
  public static double[] calcIntersection(double[] lllllllllllllllIlllIllIIlllllIll, double[] lllllllllllllllIlllIllIIlllllIlI) {
    double lllllllllllllllIlllIllIIlllllIIl = lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[5]] - lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[2]];
    double lllllllllllllllIlllIllIIlllllIII = lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[1]] - lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[0]];
    double lllllllllllllllIlllIllIIllllIlll = lllllllllllllllIlllIllIIlllllIIl * lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[1]] + lllllllllllllllIlllIllIIlllllIII * lllllllllllllllIlllIllIIlllllIll[lIlllIIllIllII[2]];
    double lllllllllllllllIlllIllIIllllIllI = lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[5]] - lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[2]];
    double lllllllllllllllIlllIllIIllllIlIl = lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[1]] - lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[0]];
    double lllllllllllllllIlllIllIIllllIlII = lllllllllllllllIlllIllIIllllIllI * lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[1]] + lllllllllllllllIlllIllIIllllIlIl * lllllllllllllllIlllIllIIlllllIlI[lIlllIIllIllII[2]];
    double lllllllllllllllIlllIllIIllllIIll = lllllllllllllllIlllIllIIlllllIIl * lllllllllllllllIlllIllIIllllIlIl - lllllllllllllllIlllIllIIllllIllI * lllllllllllllllIlllIllIIlllllIII;
    (new double[lIlllIIllIllII[0]])[lIlllIIllIllII[1]] = (lllllllllllllllIlllIllIIllllIlIl * lllllllllllllllIlllIllIIllllIlll - lllllllllllllllIlllIllIIlllllIII * lllllllllllllllIlllIllIIllllIlII) / lllllllllllllllIlllIllIIllllIIll;
    (new double[lIlllIIllIllII[0]])[lIlllIIllIllII[2]] = (lllllllllllllllIlllIllIIlllllIIl * lllllllllllllllIlllIllIIllllIlII - lllllllllllllllIlllIllIIllllIllI * lllllllllllllllIlllIllIIllllIlll) / lllllllllllllllIlllIllIIllllIIll;
    return new double[lIlllIIllIllII[0]];
  }
  
  public static double calculateAngle(double lllllllllllllllIlllIllIIllllIIlI, double lllllllllllllllIlllIllIIllllIIIl, double lllllllllllllllIlllIllIIllllIIII, double lllllllllllllllIlllIllIIlllIllll) {
    // Byte code:
    //   0: dload #4
    //   2: dload_0
    //   3: dsub
    //   4: dload #6
    //   6: dload_2
    //   7: dsub
    //   8: <illegal opcode> 13 : (DD)D
    //   13: <illegal opcode> 14 : (D)D
    //   18: dstore #8
    //   20: dload #8
    //   22: dload #8
    //   24: dneg
    //   25: ldc2_w 360.0
    //   28: ddiv
    //   29: <illegal opcode> 34 : (D)D
    //   34: ldc2_w 360.0
    //   37: dmul
    //   38: dadd
    //   39: dstore #8
    //   41: dload #8
    //   43: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	44	0	lllllllllllllllIlllIllIIllllIIlI	D
    //   0	44	2	lllllllllllllllIlllIllIIllllIIIl	D
    //   0	44	4	lllllllllllllllIlllIllIIllllIIII	D
    //   0	44	6	lllllllllllllllIlllIllIIlllIllll	D
    //   20	24	8	lllllllllllllllIlllIllIIlllIlllI	D
  }
  
  static {
    lllllIIlIIIlIlI();
    lllllIIlIIIlIIl();
    lllllIIlIIIlIII();
    lllllIIlIIIIIIl();
  }
  
  private static CallSite llllIllllIIIIIl(MethodHandles.Lookup lllllllllllllllIlllIllIIlllIIlIl, String lllllllllllllllIlllIllIIlllIIlII, MethodType lllllllllllllllIlllIllIIlllIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllIIlllIlIll = lIlllIIIIlllII[Integer.parseInt(lllllllllllllllIlllIllIIlllIIlII)].split(lIlllIIllIIlII[lIlllIIllIllII[1]]);
      Class<?> lllllllllllllllIlllIllIIlllIlIlI = Class.forName(lllllllllllllllIlllIllIIlllIlIll[lIlllIIllIllII[1]]);
      String lllllllllllllllIlllIllIIlllIlIIl = lllllllllllllllIlllIllIIlllIlIll[lIlllIIllIllII[2]];
      MethodHandle lllllllllllllllIlllIllIIlllIlIII = null;
      int lllllllllllllllIlllIllIIlllIIlll = lllllllllllllllIlllIllIIlllIlIll[lIlllIIllIllII[5]].length();
      if (lllllIIlIIllIll(lllllllllllllllIlllIllIIlllIIlll, lIlllIIllIllII[0])) {
        MethodType lllllllllllllllIlllIllIIlllIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllIIlllIlIll[lIlllIIllIllII[0]], ar.class.getClassLoader());
        if (lllllIIlIIlllII(lllllllllllllllIlllIllIIlllIIlll, lIlllIIllIllII[0])) {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findVirtual(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findStatic(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllIl);
        } 
        "".length();
        if ("   ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllIIlllIllII = lIlllIIIIlllIl[Integer.parseInt(lllllllllllllllIlllIllIIlllIlIll[lIlllIIllIllII[0]])];
        if (lllllIIlIIlllII(lllllllllllllllIlllIllIIlllIIlll, lIlllIIllIllII[5])) {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findGetter(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllII);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else if (lllllIIlIIlllII(lllllllllllllllIlllIllIIlllIIlll, lIlllIIllIllII[6])) {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findStaticGetter(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllII);
          "".length();
          if ("   ".length() <= " ".length() << " ".length())
            return null; 
        } else if (lllllIIlIIlllII(lllllllllllllllIlllIllIIlllIIlll, lIlllIIllIllII[7])) {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findSetter(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllII);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIllIIlllIlIII = lllllllllllllllIlllIllIIlllIIlIl.findStaticSetter(lllllllllllllllIlllIllIIlllIlIlI, lllllllllllllllIlllIllIIlllIlIIl, lllllllllllllllIlllIllIIlllIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllIIlllIlIII);
    } catch (Exception lllllllllllllllIlllIllIIlllIIllI) {
      lllllllllllllllIlllIllIIlllIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlIIIIIIl() {
    lIlllIIIIlllII = new String[lIlllIIllIllII[8]];
    lIlllIIIIlllII[lIlllIIllIllII[9]] = lIlllIIllIIlII[lIlllIIllIllII[2]];
    lIlllIIIIlllII[lIlllIIllIllII[10]] = lIlllIIllIIlII[lIlllIIllIllII[0]];
    lIlllIIIIlllII[lIlllIIllIllII[11]] = lIlllIIllIIlII[lIlllIIllIllII[5]];
    lIlllIIIIlllII[lIlllIIllIllII[12]] = lIlllIIllIIlII[lIlllIIllIllII[6]];
    lIlllIIIIlllII[lIlllIIllIllII[13]] = lIlllIIllIIlII[lIlllIIllIllII[7]];
    lIlllIIIIlllII[lIlllIIllIllII[14]] = lIlllIIllIIlII[lIlllIIllIllII[15]];
    lIlllIIIIlllII[lIlllIIllIllII[0]] = lIlllIIllIIlII[lIlllIIllIllII[16]];
    lIlllIIIIlllII[lIlllIIllIllII[17]] = lIlllIIllIIlII[lIlllIIllIllII[18]];
    lIlllIIIIlllII[lIlllIIllIllII[19]] = lIlllIIllIIlII[lIlllIIllIllII[17]];
    lIlllIIIIlllII[lIlllIIllIllII[20]] = lIlllIIllIIlII[lIlllIIllIllII[21]];
    lIlllIIIIlllII[lIlllIIllIllII[22]] = lIlllIIllIIlII[lIlllIIllIllII[23]];
    lIlllIIIIlllII[lIlllIIllIllII[24]] = lIlllIIllIIlII[lIlllIIllIllII[25]];
    lIlllIIIIlllII[lIlllIIllIllII[26]] = lIlllIIllIIlII[lIlllIIllIllII[27]];
    lIlllIIIIlllII[lIlllIIllIllII[15]] = lIlllIIllIIlII[lIlllIIllIllII[28]];
    lIlllIIIIlllII[lIlllIIllIllII[18]] = lIlllIIllIIlII[lIlllIIllIllII[14]];
    lIlllIIIIlllII[lIlllIIllIllII[6]] = lIlllIIllIIlII[lIlllIIllIllII[22]];
    lIlllIIIIlllII[lIlllIIllIllII[29]] = lIlllIIllIIlII[lIlllIIllIllII[9]];
    lIlllIIIIlllII[lIlllIIllIllII[30]] = lIlllIIllIIlII[lIlllIIllIllII[19]];
    lIlllIIIIlllII[lIlllIIllIllII[31]] = lIlllIIllIIlII[lIlllIIllIllII[24]];
    lIlllIIIIlllII[lIlllIIllIllII[32]] = lIlllIIllIIlII[lIlllIIllIllII[13]];
    lIlllIIIIlllII[lIlllIIllIllII[25]] = lIlllIIllIIlII[lIlllIIllIllII[12]];
    lIlllIIIIlllII[lIlllIIllIllII[33]] = lIlllIIllIIlII[lIlllIIllIllII[34]];
    lIlllIIIIlllII[lIlllIIllIllII[35]] = lIlllIIllIIlII[lIlllIIllIllII[31]];
    lIlllIIIIlllII[lIlllIIllIllII[36]] = lIlllIIllIIlII[lIlllIIllIllII[26]];
    lIlllIIIIlllII[lIlllIIllIllII[21]] = lIlllIIllIIlII[lIlllIIllIllII[30]];
    lIlllIIIIlllII[lIlllIIllIllII[7]] = lIlllIIllIIlII[lIlllIIllIllII[32]];
    lIlllIIIIlllII[lIlllIIllIllII[1]] = lIlllIIllIIlII[lIlllIIllIllII[37]];
    lIlllIIIIlllII[lIlllIIllIllII[2]] = lIlllIIllIIlII[lIlllIIllIllII[10]];
    lIlllIIIIlllII[lIlllIIllIllII[34]] = lIlllIIllIIlII[lIlllIIllIllII[33]];
    lIlllIIIIlllII[lIlllIIllIllII[5]] = lIlllIIllIIlII[lIlllIIllIllII[11]];
    lIlllIIIIlllII[lIlllIIllIllII[23]] = lIlllIIllIIlII[lIlllIIllIllII[29]];
    lIlllIIIIlllII[lIlllIIllIllII[28]] = lIlllIIllIIlII[lIlllIIllIllII[20]];
    lIlllIIIIlllII[lIlllIIllIllII[37]] = lIlllIIllIIlII[lIlllIIllIllII[35]];
    lIlllIIIIlllII[lIlllIIllIllII[27]] = lIlllIIllIIlII[lIlllIIllIllII[36]];
    lIlllIIIIlllII[lIlllIIllIllII[16]] = lIlllIIllIIlII[lIlllIIllIllII[8]];
    lIlllIIIIlllIl = new Class[lIlllIIllIllII[16]];
    lIlllIIIIlllIl[lIlllIIllIllII[5]] = float.class;
    lIlllIIIIlllIl[lIlllIIllIllII[2]] = EntityPlayerSP.class;
    lIlllIIIIlllIl[lIlllIIllIllII[1]] = double.class;
    lIlllIIIIlllIl[lIlllIIllIllII[0]] = MovementInput.class;
    lIlllIIIIlllIl[lIlllIIllIllII[6]] = GameSettings.class;
    lIlllIIIIlllIl[lIlllIIllIllII[15]] = RoundingMode.class;
    lIlllIIIIlllIl[lIlllIIllIllII[7]] = KeyBinding.class;
  }
  
  private static void lllllIIlIIIlIII() {
    lIlllIIllIIlII = new String[lIlllIIllIllII[38]];
    lIlllIIllIIlII[lIlllIIllIllII[1]] = lllllIIlIIIIIlI(lIlllIIllIlIll[lIlllIIllIllII[1]], lIlllIIllIlIll[lIlllIIllIllII[2]]);
    lIlllIIllIIlII[lIlllIIllIllII[2]] = lllllIIlIIIIIll(lIlllIIllIlIll[lIlllIIllIllII[0]], lIlllIIllIlIll[lIlllIIllIllII[5]]);
    lIlllIIllIIlII[lIlllIIllIllII[0]] = lllllIIlIIIIIll(lIlllIIllIlIll[lIlllIIllIllII[6]], lIlllIIllIlIll[lIlllIIllIllII[7]]);
    lIlllIIllIIlII[lIlllIIllIllII[5]] = lllllIIlIIIIIlI(lIlllIIllIlIll[lIlllIIllIllII[15]], lIlllIIllIlIll[lIlllIIllIllII[16]]);
    lIlllIIllIIlII[lIlllIIllIllII[6]] = lllllIIlIIIIIll(lIlllIIllIlIll[lIlllIIllIllII[18]], lIlllIIllIlIll[lIlllIIllIllII[17]]);
    lIlllIIllIIlII[lIlllIIllIllII[7]] = lllllIIlIIIIIll(lIlllIIllIlIll[lIlllIIllIllII[21]], lIlllIIllIlIll[lIlllIIllIllII[23]]);
    lIlllIIllIIlII[lIlllIIllIllII[15]] = lllllIIlIIIIIlI("4MPRex4YgifrqgEmgafmqD9jbK5KPk56vMmkoPrgQgVGlsQ0iRpo8NlkNEMT6teHTCmX0wVJnwY=", "fOIIA");
    lIlllIIllIIlII[lIlllIIllIllII[16]] = lllllIIlIIIIIll("HSYmRAoaLTcJFRIlJkQCHTc7Hh5dBjweDgc6aAwOFi82NVBDcmFdOCd5YlBHU2M=", "sCRjg");
    lIlllIIllIIlII[lIlllIIllIllII[18]] = lllllIIlIIIIIlI("h7mvwcPDJGPt1m8dL5tgcCF/7RX4iNotXxqO6gBEXp0Ik55uHhXNQRw6bPcuN7XPlpaWQAadTSY=", "wKfQO");
    lIlllIIllIIlII[lIlllIIllIllII[17]] = lllllIIlIIIIIll("KBMzVwIvGCIaHScQM1cMKh8iFxtoEykNBjIPaTwBMh8zAD8qFz4cHRUmfR8GIxojJlh3R3JBMCRMdUNPZlY=", "FvGyo");
    lIlllIIllIIlII[lIlllIIllIllII[21]] = lllllIIlIIIIlIl("26aEgW82e52LW3bj+9f8Giip+D17YeRqgWmOVovkuLnKyg3LeZDmIGDAdClbZ6M3tieS7+WgGpIM17JSKMuY5JZmnALLA4MHaxhz7N1GcXYqIvG4YC/0Aw==", "iGEGy");
    lIlllIIllIIlII[lIlllIIllIllII[23]] = lllllIIlIIIIIll("JyIxfCIgKSAxPSghMXwsJS4gPDtnCiw8Kio1JDQ7cyEwPCwWcHRmfnkYPWhnYAsrNztmKiw8Kio1JDQ7ZiQpOyonM2ofJiciJiAuLzN+aG8=", "IGERO");
    lIlllIIllIIlII[lIlllIIllIllII[25]] = lllllIIlIIIIIll("LRUieSMqHjM0PCIWInk7Nxk6eQMsBjM6Ky0EHzk+NgRsMScmHDIIf3pCbmR8HBJsZHRjUHY=", "CpVWN");
    lIlllIIllIIlII[lIlllIIllIllII[27]] = lllllIIlIIIIIll("DCk8NkQKKSQwRCspPj9QEicYNg4PKSQkUE4MYxNQRg==", "fHJWj");
    lIlllIIllIIlII[lIlllIIllIllII[28]] = lllllIIlIIIIIlI("yGHzPFqmE08yyGDIxgFG1gr4FBjUVcaD76g1zydwnPbG0RA5kTUnqg==", "TQCEG");
    lIlllIIllIIlII[lIlllIIllIllII[14]] = lllllIIlIIIIlIl("oVN+X5zKgOzB/hpgGbB+PuR9PwO6Zdurw1Zc71omI6Y=", "PzJQs");
    lIlllIIllIIlII[lIlllIIllIllII[22]] = lllllIIlIIIIlIl("VTCdgcSf+Dxe0d90hBztWyazlfGmxn8tuthCt+wzqdxylVpSILXbTjc3mphvX1l0", "zdwek");
    lIlllIIllIIlII[lIlllIIllIllII[9]] = lllllIIlIIIIIll("Li0HDG8pLQUFbxYjBAMlLSIWIC4gKUslAAgKLjgRfnpLTWFkbA==", "DLqmA");
    lIlllIIllIIlII[lIlllIIllIllII[19]] = lllllIIlIIIIIll("BwIdQhUACQwPCggBHUIbBQ4MAgxHKgACHQoVCAoMUwEACRQNOF5dTF5TNhVCXV1JTFg=", "igilx");
    lIlllIIllIIlII[lIlllIIllIllII[24]] = lllllIIlIIIIIll("NgskZAIxADUpHTkIJGQMNAc1JBt2IzkkCjscMSwbYgglJAwHX2h+XmpfDysEYkZ5DFV4Tg==", "XnPJo");
    lIlllIIllIIlII[lIlllIIllIllII[13]] = lllllIIlIIIIIll("GxEMaCocGh0lNRQSDGgkGR0dKDNbBx0yMxwaHzVpMhUVIxQQAAwvKRIHQiAuEBgcGXBBR092GA1OTXxnVVQ=", "utxFG");
    lIlllIIllIIlII[lIlllIIllIllII[12]] = lllllIIlIIIIIlI("OgSQaGZhpL4J/H69ArvkHl/Q9nlE0JPTYUSSo9ZkOJqptpmu9Jry6ZX9nUcThHUm4c9isXl2kw8=", "jyNad");
    lIlllIIllIIlII[lIlllIIllIllII[34]] = lllllIIlIIIIIll("DQYeYwEKDQ8uHgIFHmMPDwoPIxhNEA85GAoNDT5CJAIHKD8GFx4kAgQQUCsFBg8OEltXUFx1MxpZX3dMQ0M=", "ccjMl");
    lIlllIIllIIlII[lIlllIIllIllII[31]] = lllllIIlIIIIIll("OA8YJFk/DxotWRAHCQESMQcDJBtoCgEwFT4LOCQbJwtUbV4WVE5l", "RnnEw");
    lIlllIIllIIlII[lIlllIIllIllII[26]] = lllllIIlIIIIlIl("pomlrGkbXTDTEiYCCR/9i+L1Nast2X27aJKMvpbtbPw=", "QDWSx");
    lIlllIIllIIlII[lIlllIIllIllII[30]] = lllllIIlIIIIIll("NgsXbS4xAAYgMTkIF202LAcPbS45GgttFT0NUCd5PgcGLycHWVF3d2AxAXlzYk5DYw==", "XncCC");
    lIlllIIllIIlII[lIlllIIllIllII[32]] = lllllIIlIIIIIlI("w0sqL3UeZBfuAf2+byTU+uZDJAel5bxX3lrLJJ5dSu+7RwdLZT17bllXrvDp41Kj", "EwgvC");
    lIlllIIllIIlII[lIlllIIllIllII[37]] = lllllIIlIIIIlIl("DDyr2m5WVqVYcbMuVkxOGmSu+zqHkrMWqy7yyapm/7PLcpOwAnMp5P+w202YJfmU", "MCbvN");
    lIlllIIllIIlII[lIlllIIllIllII[10]] = lllllIIlIIIIIlI("7PwoMl65qni48QMArJXqhBmCat3Ws0UvHmsvKRHh10ZhE9ts/qAkEg7kRncTZ31s", "KnQLj");
    lIlllIIllIIlII[lIlllIIllIllII[33]] = lllllIIlIIIIIll("KDU4RC8vPikJMCc2OEQhKjkpBDZoNSIeKzIpYi8sMjk4ExIqMTUPMBUAdgwrIzwoNXV2YXtdHTxqf1BiZnA=", "FPLjB");
    lIlllIIllIIlII[lIlllIIllIllII[11]] = lllllIIlIIIIIlI("Vp8VywOQlDVes16i40cisKi7fqL4gKeSuQz2ULkxbXxzE6eofQbkOdOf6AwUfRVF", "Gpedl");
    lIlllIIllIIlII[lIlllIIllIllII[29]] = lllllIIlIIIIlIl("me7Xzer6ivtt0vSa4USAk9fd3jT9kur9OB4+Gd7hgmr+MQIj00t13M/WDNWg7t3iBTdAfgyfRIQ=", "dQtKO");
    lIlllIIllIIlII[lIlllIIllIllII[20]] = lllllIIlIIIIIlI("zYlS80DNeiIeLWVa31V5dMgTMbQofd6qJ9GFpIi9VAQ=", "Eaoht");
    lIlllIIllIIlII[lIlllIIllIllII[35]] = lllllIIlIIIIIll("PDIHbzQ7ORYiKzMxB286Pj4WLy18JBY1LTs5FDJ3GTIKAzA8MxovPmgxBi86DWZGcG1kbywnY3p+KXt5cg==", "RWsAY");
    lIlllIIllIIlII[lIlllIIllIllII[36]] = lllllIIlIIIIIll("PBsjCG86GzsObxsbIQF7Nw40B3NsUhEtaBJAdQ==", "VzUiA");
    lIlllIIllIIlII[lIlllIIllIllII[8]] = lllllIIlIIIIIll("LDAVNGoqMA0yagswFz1+JT4Qb2wCeCdvZA==", "FQcUD");
    lIlllIIllIlIll = null;
  }
  
  private static void lllllIIlIIIlIIl() {
    String str = (new Exception()).getStackTrace()[lIlllIIllIllII[1]].getFileName();
    lIlllIIllIlIll = str.substring(str.indexOf("ä") + lIlllIIllIllII[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIlIIIIIlI(String lllllllllllllllIlllIllIIllIlllll, String lllllllllllllllIlllIllIIllIllllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIlllIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIllIllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIIlllIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIIlllIIIIl.init(lIlllIIllIllII[0], lllllllllllllllIlllIllIIlllIIIlI);
      return new String(lllllllllllllllIlllIllIIlllIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIllIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIlllIIIII) {
      lllllllllllllllIlllIllIIlllIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlIIIIlIl(String lllllllllllllllIlllIllIIllIllIlI, String lllllllllllllllIlllIllIIllIllIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIllIlllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIllIllIIl.getBytes(StandardCharsets.UTF_8)), lIlllIIllIllII[18]), "DES");
      Cipher lllllllllllllllIlllIllIIllIlllII = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIIllIlllII.init(lIlllIIllIllII[0], lllllllllllllllIlllIllIIllIlllIl);
      return new String(lllllllllllllllIlllIllIIllIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIllIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIllIllIll) {
      lllllllllllllllIlllIllIIllIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlIIIIIll(String lllllllllllllllIlllIllIIllIlIlll, String lllllllllllllllIlllIllIIllIlIllI) {
    lllllllllllllllIlllIllIIllIlIlll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIIllIlIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIIllIlIlIl = new StringBuilder();
    char[] lllllllllllllllIlllIllIIllIlIlII = lllllllllllllllIlllIllIIllIlIllI.toCharArray();
    int lllllllllllllllIlllIllIIllIlIIll = lIlllIIllIllII[1];
    char[] arrayOfChar1 = lllllllllllllllIlllIllIIllIlIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIllIllII[1];
    while (lllllIIlIIlllIl(j, i)) {
      char lllllllllllllllIlllIllIIllIllIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllIIllIlIIll++;
      j++;
      "".length();
      if (" ".length() >= " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllIIllIlIlIl);
  }
  
  private static void lllllIIlIIIlIlI() {
    lIlllIIllIllII = new int[39];
    lIlllIIllIllII[0] = " ".length() << " ".length();
    lIlllIIllIllII[1] = " ".length() << "   ".length() & (" ".length() << "   ".length() ^ -" ".length());
    lIlllIIllIllII[2] = " ".length();
    lIlllIIllIllII[3] = -(46 + 93 - 129 + 123 ^ (0x44 ^ 0x51) << "   ".length());
    lIlllIIllIllII[4] = (0x2E ^ 0x39) << "   ".length() ^ 115 + 54 - 153 + 133;
    lIlllIIllIllII[5] = "   ".length();
    lIlllIIllIllII[6] = " ".length() << " ".length() << " ".length();
    lIlllIIllIllII[7] = 0x71 ^ 0x74;
    lIlllIIllIllII[8] = 0xBC ^ 0x9F;
    lIlllIIllIllII[9] = 0x70 ^ 0x61;
    lIlllIIllIllII[10] = (0x1A ^ 0x4B ^ (0x53 ^ 0x78) << " ".length()) << " ".length() << " ".length();
    lIlllIIllIllII[11] = (0x54 ^ 0x5B) << " ".length();
    lIlllIIllIllII[12] = 0x98 ^ 0x8D;
    lIlllIIllIllII[13] = ((0x67 ^ 0x4) << " ".length() ^ 162 + 66 - 40 + 7) << " ".length() << " ".length();
    lIlllIIllIllII[14] = 0x4F ^ 0x40;
    lIlllIIllIllII[15] = "   ".length() << " ".length();
    lIlllIIllIllII[16] = 0x99 ^ 0x9E;
    lIlllIIllIllII[17] = (0x5 ^ 0x8) << "   ".length() ^ 0xFF ^ 0x9E;
    lIlllIIllIllII[18] = " ".length() << "   ".length();
    lIlllIIllIllII[19] = ((0xBE ^ 0x9D) << " ".length() ^ 0xC2 ^ 0x8D) << " ".length();
    lIlllIIllIllII[20] = " ".length() << (0x9D ^ 0x98);
    lIlllIIllIllII[21] = (102 + 108 - 49 + 38 ^ (0xDB ^ 0xBA) << " ".length()) << " ".length();
    lIlllIIllIllII[22] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIllIllII[23] = (0x7F ^ 0x66) << " ".length() << " ".length() ^ 0xDC ^ 0xB3;
    lIlllIIllIllII[24] = 0x17 ^ 0x12 ^ (0x63 ^ 0x68) << " ".length();
    lIlllIIllIllII[25] = "   ".length() << " ".length() << " ".length();
    lIlllIIllIllII[26] = "   ".length() << "   ".length();
    lIlllIIllIllII[27] = (0x28 ^ 0x23) << "   ".length() ^ 0x77 ^ 0x22;
    lIlllIIllIllII[28] = ((0x76 ^ 0x61) << "   ".length() ^ 11 + 116 - 25 + 89) << " ".length();
    lIlllIIllIllII[29] = 0x3A ^ 0x25;
    lIlllIIllIllII[30] = 0xAE ^ 0xB7;
    lIlllIIllIllII[31] = (0x2C ^ 0x29) << " ".length() << " ".length() << " ".length() ^ 0x68 ^ 0x2F;
    lIlllIIllIllII[32] = (11 + 72 - 11 + 57 ^ (0x32 ^ 0x11) << " ".length() << " ".length()) << " ".length();
    lIlllIIllIllII[33] = 0xA5 ^ 0xB8;
    lIlllIIllIllII[34] = (0xB5 ^ 0xBE) << " ".length();
    lIlllIIllIllII[35] = 0x6F ^ 0x52 ^ (0x8 ^ 0xF) << " ".length() << " ".length();
    lIlllIIllIllII[36] = (0xBA ^ 0xAB) << " ".length();
    lIlllIIllIllII[37] = 0x86 ^ 0x9D;
    lIlllIIllIllII[38] = ((0x0 ^ 0x43) << " ".length() ^ 89 + 15 - 12 + 51) << " ".length() << " ".length();
  }
  
  private static boolean lllllIIlIIlllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIlIIlllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIlIIllIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIlIIIllIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIIlIIlIIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIIlIIlIllI(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lllllIIlIIIllll(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lllllIIlIIlIlIl(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lllllIIlIIIlllI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllIIlIIIlIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIIllII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIlIIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIlIIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIlIlII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIlIIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIlIlll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIllIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlIIllIlI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIlIIllIIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */