package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.BlockHopper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

public class f2 extends au {
  private int hopperslot;
  
  private int shulkerslot;
  
  private boolean hopper;
  
  private boolean shulker;
  
  public ao timer;
  
  private static String[] lIlllllllIlIIl;
  
  private static Class[] lIlllllllIlIlI;
  
  private static final String[] llIIIIIIlllIIl;
  
  private static String[] llIIIIIIlllllI;
  
  private static final int[] llIIIIIlIIIlIl;
  
  public f2() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f2.llIIIIIIlllIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f2.llIIIIIIlllIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f2.llIIIIIIlllIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   45: iconst_3
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f2;I)V
    //   52: aload_0
    //   53: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   56: iconst_3
    //   57: iaload
    //   58: <illegal opcode> 2 : (Lme/stupitdog/bhp/f2;I)V
    //   63: aload_0
    //   64: new me/stupitdog/bhp/ao
    //   67: dup
    //   68: invokespecial <init> : ()V
    //   71: <illegal opcode> 3 : (Lme/stupitdog/bhp/f2;Lme/stupitdog/bhp/ao;)V
    //   76: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIllIlllIlIIIIIIll	Lme/stupitdog/bhp/f2;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   4: iconst_3
    //   5: iaload
    //   6: <illegal opcode> 1 : (Lme/stupitdog/bhp/f2;I)V
    //   11: aload_0
    //   12: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   15: iconst_3
    //   16: iaload
    //   17: <illegal opcode> 2 : (Lme/stupitdog/bhp/f2;I)V
    //   22: aload_0
    //   23: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   26: iconst_0
    //   27: iaload
    //   28: <illegal opcode> 4 : (Lme/stupitdog/bhp/f2;Z)V
    //   33: aload_0
    //   34: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   37: iconst_0
    //   38: iaload
    //   39: <illegal opcode> 5 : (Lme/stupitdog/bhp/f2;Z)V
    //   44: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   47: iconst_0
    //   48: iaload
    //   49: istore_1
    //   50: iload_1
    //   51: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   54: iconst_4
    //   55: iaload
    //   56: invokestatic lIIIIIIllIIlIIII : (II)Z
    //   59: ifeq -> 184
    //   62: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   67: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   72: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   77: iload_1
    //   78: <illegal opcode> 9 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   83: <illegal opcode> 10 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   88: astore_2
    //   89: aload_2
    //   90: instanceof net/minecraft/item/ItemShulkerBox
    //   93: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   96: ifeq -> 106
    //   99: aload_0
    //   100: iload_1
    //   101: <illegal opcode> 2 : (Lme/stupitdog/bhp/f2;I)V
    //   106: aload_2
    //   107: instanceof net/minecraft/item/ItemBlock
    //   110: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   113: ifeq -> 148
    //   116: aload_2
    //   117: checkcast net/minecraft/item/ItemBlock
    //   120: <illegal opcode> 11 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   125: <illegal opcode> 12 : ()Lnet/minecraft/block/BlockHopper;
    //   130: <illegal opcode> 13 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   135: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   138: ifeq -> 148
    //   141: aload_0
    //   142: iload_1
    //   143: <illegal opcode> 1 : (Lme/stupitdog/bhp/f2;I)V
    //   148: iinc #1, 1
    //   151: ldc ''
    //   153: invokevirtual length : ()I
    //   156: pop
    //   157: ldc ' '
    //   159: invokevirtual length : ()I
    //   162: ldc ' '
    //   164: invokevirtual length : ()I
    //   167: ldc ' '
    //   169: invokevirtual length : ()I
    //   172: ishl
    //   173: ishl
    //   174: ldc ' '
    //   176: invokevirtual length : ()I
    //   179: ineg
    //   180: if_icmpgt -> 50
    //   183: return
    //   184: aload_0
    //   185: <illegal opcode> 14 : (Lme/stupitdog/bhp/f2;)I
    //   190: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   193: iconst_3
    //   194: iaload
    //   195: invokestatic lIIIIIIllIIlIIlI : (II)Z
    //   198: ifeq -> 222
    //   201: getstatic me/stupitdog/bhp/f2.llIIIIIIlllIIl : [Ljava/lang/String;
    //   204: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   207: iconst_5
    //   208: iaload
    //   209: aaload
    //   210: <illegal opcode> 15 : (Ljava/lang/String;)V
    //   215: aload_0
    //   216: <illegal opcode> 16 : (Lme/stupitdog/bhp/f2;)V
    //   221: return
    //   222: aload_0
    //   223: <illegal opcode> 17 : (Lme/stupitdog/bhp/f2;)I
    //   228: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   231: iconst_3
    //   232: iaload
    //   233: invokestatic lIIIIIIllIIlIIlI : (II)Z
    //   236: ifeq -> 261
    //   239: getstatic me/stupitdog/bhp/f2.llIIIIIIlllIIl : [Ljava/lang/String;
    //   242: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   245: bipush #6
    //   247: iaload
    //   248: aaload
    //   249: <illegal opcode> 15 : (Ljava/lang/String;)V
    //   254: aload_0
    //   255: <illegal opcode> 16 : (Lme/stupitdog/bhp/f2;)V
    //   260: return
    //   261: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   266: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   271: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   276: aload_0
    //   277: <illegal opcode> 17 : (Lme/stupitdog/bhp/f2;)I
    //   282: putfield field_70461_c : I
    //   285: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   290: <illegal opcode> 18 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   295: <illegal opcode> 19 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   300: <illegal opcode> 20 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   305: <illegal opcode> 21 : (Lnet/minecraft/util/math/BlockPos;)V
    //   310: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   315: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   320: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   325: aload_0
    //   326: <illegal opcode> 14 : (Lme/stupitdog/bhp/f2;)I
    //   331: putfield field_70461_c : I
    //   334: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   339: <illegal opcode> 18 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   344: <illegal opcode> 19 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   349: <illegal opcode> 20 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   354: <illegal opcode> 20 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   359: <illegal opcode> 21 : (Lnet/minecraft/util/math/BlockPos;)V
    //   364: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   369: <illegal opcode> 18 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   374: <illegal opcode> 19 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   379: <illegal opcode> 20 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   384: <illegal opcode> 22 : (Lnet/minecraft/util/math/BlockPos;)V
    //   389: aload_0
    //   390: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   393: iconst_1
    //   394: iaload
    //   395: <illegal opcode> 5 : (Lme/stupitdog/bhp/f2;Z)V
    //   400: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   89	59	2	lllllllllllllllIllIlllIlIIIIIIlI	Lnet/minecraft/item/Item;
    //   50	134	1	lllllllllllllllIllIlllIlIIIIIIIl	I
    //   0	401	0	lllllllllllllllIllIlllIlIIIIIIII	Lme/stupitdog/bhp/f2;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 23 : (Lme/stupitdog/bhp/f2;)Z
    //   6: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   9: ifeq -> 441
    //   12: aload_0
    //   13: <illegal opcode> 24 : (Lme/stupitdog/bhp/f2;)Z
    //   18: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   21: ifeq -> 441
    //   24: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   29: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   34: instanceof net/minecraft/client/gui/GuiHopper
    //   37: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   40: ifeq -> 434
    //   43: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   48: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   53: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   58: <illegal opcode> 26 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/item/ItemStack;
    //   63: <illegal opcode> 10 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   68: instanceof net/minecraft/item/ItemSword
    //   71: invokestatic lIIIIIIllIIlIIll : (I)Z
    //   74: ifeq -> 186
    //   77: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   82: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   87: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   92: aload_0
    //   93: <illegal opcode> 14 : (Lme/stupitdog/bhp/f2;)I
    //   98: putfield field_70461_c : I
    //   101: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   106: <illegal opcode> 27 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   111: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   116: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   121: checkcast net/minecraft/client/gui/inventory/GuiContainer
    //   124: <illegal opcode> 28 : (Lnet/minecraft/client/gui/inventory/GuiContainer;)Lnet/minecraft/inventory/Container;
    //   129: <illegal opcode> 29 : (Lnet/minecraft/inventory/Container;)I
    //   134: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   137: iconst_0
    //   138: iaload
    //   139: aload_0
    //   140: <illegal opcode> 14 : (Lme/stupitdog/bhp/f2;)I
    //   145: <illegal opcode> 30 : ()Lnet/minecraft/inventory/ClickType;
    //   150: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   155: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   160: <illegal opcode> 31 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   165: ldc ''
    //   167: invokevirtual length : ()I
    //   170: pop2
    //   171: ldc ''
    //   173: invokevirtual length : ()I
    //   176: pop
    //   177: ldc ' '
    //   179: invokevirtual length : ()I
    //   182: ifge -> 441
    //   185: return
    //   186: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   191: <illegal opcode> 32 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   196: <illegal opcode> 33 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   201: <illegal opcode> 34 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   206: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   211: <illegal opcode> 35 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   216: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   221: <illegal opcode> 35 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   226: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   231: <illegal opcode> 35 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   236: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   241: <illegal opcode> 36 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   246: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   251: <illegal opcode> 37 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   256: <illegal opcode> 38 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   261: aconst_null
    //   262: <illegal opcode> 39 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   267: checkcast net/minecraft/entity/Entity
    //   270: astore_1
    //   271: aload_1
    //   272: invokestatic lIIIIIIllIIlIlII : (Ljava/lang/Object;)Z
    //   275: ifeq -> 372
    //   278: aload_0
    //   279: <illegal opcode> 40 : (Lme/stupitdog/bhp/f2;)Lme/stupitdog/bhp/ao;
    //   284: ldc2_w 40
    //   287: <illegal opcode> 41 : (Lme/stupitdog/bhp/ao;J)Z
    //   292: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   295: ifeq -> 372
    //   298: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   303: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   308: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   313: new net/minecraft/network/play/client/CPacketUseEntity
    //   316: dup
    //   317: aload_1
    //   318: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   321: <illegal opcode> 43 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   326: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   331: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   336: <illegal opcode> 44 : ()Lnet/minecraft/util/EnumHand;
    //   341: <illegal opcode> 45 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   346: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   351: <illegal opcode> 7 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   356: <illegal opcode> 46 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   361: aload_0
    //   362: <illegal opcode> 40 : (Lme/stupitdog/bhp/f2;)Lme/stupitdog/bhp/ao;
    //   367: <illegal opcode> 47 : (Lme/stupitdog/bhp/ao;)V
    //   372: ldc ''
    //   374: invokevirtual length : ()I
    //   377: pop
    //   378: ldc ' '
    //   380: invokevirtual length : ()I
    //   383: sipush #141
    //   386: sipush #196
    //   389: ixor
    //   390: iconst_0
    //   391: bipush #7
    //   393: ixor
    //   394: ldc ' '
    //   396: invokevirtual length : ()I
    //   399: ishl
    //   400: ixor
    //   401: sipush #131
    //   404: sipush #190
    //   407: ixor
    //   408: ldc ' '
    //   410: invokevirtual length : ()I
    //   413: ishl
    //   414: sipush #177
    //   417: sipush #140
    //   420: ixor
    //   421: ixor
    //   422: ldc ' '
    //   424: invokevirtual length : ()I
    //   427: ineg
    //   428: ixor
    //   429: iand
    //   430: if_icmpge -> 441
    //   433: return
    //   434: aload_0
    //   435: <illegal opcode> 16 : (Lme/stupitdog/bhp/f2;)V
    //   440: return
    //   441: <illegal opcode> 6 : ()Lnet/minecraft/client/Minecraft;
    //   446: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   451: instanceof net/minecraft/client/gui/GuiHopper
    //   454: invokestatic lIIIIIIllIIlIIIl : (I)Z
    //   457: ifeq -> 471
    //   460: aload_0
    //   461: getstatic me/stupitdog/bhp/f2.llIIIIIlIIIlIl : [I
    //   464: iconst_1
    //   465: iaload
    //   466: <illegal opcode> 4 : (Lme/stupitdog/bhp/f2;Z)V
    //   471: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   271	101	1	lllllllllllllllIllIlllIIllllllll	Lnet/minecraft/entity/Entity;
    //   0	472	0	lllllllllllllllIllIlllIIlllllllI	Lme/stupitdog/bhp/f2;
  }
  
  static {
    lIIIIIIllIIIllll();
    lIIIIIIllIIIIlII();
    lIIIIIIllIIIIIll();
    lIIIIIIlIlllIllI();
  }
  
  private static CallSite lIIIIIIIlIIIlIll(MethodHandles.Lookup lllllllllllllllIllIlllIIllllIIII, String lllllllllllllllIllIlllIIlllIllll, MethodType lllllllllllllllIllIlllIIlllIlllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIIllllIllI = lIlllllllIlIIl[Integer.parseInt(lllllllllllllllIllIlllIIlllIllll)].split(llIIIIIIlllIIl[llIIIIIlIIIlIl[7]]);
      Class<?> lllllllllllllllIllIlllIIllllIlIl = Class.forName(lllllllllllllllIllIlllIIllllIllI[llIIIIIlIIIlIl[0]]);
      String lllllllllllllllIllIlllIIllllIlII = lllllllllllllllIllIlllIIllllIllI[llIIIIIlIIIlIl[1]];
      MethodHandle lllllllllllllllIllIlllIIllllIIll = null;
      int lllllllllllllllIllIlllIIllllIIlI = lllllllllllllllIllIlllIIllllIllI[llIIIIIlIIIlIl[5]].length();
      if (lIIIIIIllIIllIII(lllllllllllllllIllIlllIIllllIIlI, llIIIIIlIIIlIl[2])) {
        MethodType lllllllllllllllIllIlllIIlllllIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIIllllIllI[llIIIIIlIIIlIl[2]], f2.class.getClassLoader());
        if (lIIIIIIllIIlIIlI(lllllllllllllllIllIlllIIllllIIlI, llIIIIIlIIIlIl[2])) {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findVirtual(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIlllllIII);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findStatic(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIlllllIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIIllllIlll = lIlllllllIlIlI[Integer.parseInt(lllllllllllllllIllIlllIIllllIllI[llIIIIIlIIIlIl[2]])];
        if (lIIIIIIllIIlIIlI(lllllllllllllllIllIlllIIllllIIlI, llIIIIIlIIIlIl[5])) {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findGetter(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIllllIlll);
          "".length();
          if (((0x5B ^ 0x42) & (0x41 ^ 0x58 ^ 0xFFFFFFFF)) >= " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIllIIlIIlI(lllllllllllllllIllIlllIIllllIIlI, llIIIIIlIIIlIl[6])) {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findStaticGetter(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIllllIlll);
          "".length();
          if (" ".length() << " ".length() << " ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIllIIlIIlI(lllllllllllllllIllIlllIIllllIIlI, llIIIIIlIIIlIl[7])) {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findSetter(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIllllIlll);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIlllIIllllIIll = lllllllllllllllIllIlllIIllllIIII.findStaticSetter(lllllllllllllllIllIlllIIllllIlIl, lllllllllllllllIllIlllIIllllIlII, lllllllllllllllIllIlllIIllllIlll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIIllllIIll);
    } catch (Exception lllllllllllllllIllIlllIIllllIIIl) {
      lllllllllllllllIllIlllIIllllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIlllIllI() {
    lIlllllllIlIIl = new String[llIIIIIlIIIlIl[8]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[9]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[10]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[6]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[11]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[12]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[13]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[14]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[4]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[15]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[16]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[17]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[18]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[5]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[19]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[20]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[21]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[22]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[17]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[23]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[24]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[25]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[26]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[27]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[28]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[0]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[29]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[28]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[30]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[31]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[32]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[33]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[34]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[35]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[31]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[16]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[36]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[37]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[38]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[30]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[39]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[40]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[41]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[4]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[42]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[7]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[43]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[1]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[44]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[19]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[12]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[45]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[46]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[18]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[23]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[47]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[48]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[49]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[20]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[36]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[40]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[10]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[50]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[46]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[47]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[11]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[45]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[24]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[9]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[50]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[22]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[2]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[49]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[38]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[33]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[51]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[37]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[41]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[51]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[34]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[15]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[43]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[35]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[21]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[25]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[52]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[52]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[32]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[14]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[44]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[27]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[29]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[8]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[13]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[53]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[26]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[54]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[42]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[55]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[48]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[56]];
    lIlllllllIlIIl[llIIIIIlIIIlIl[39]] = llIIIIIIlllIIl[llIIIIIlIIIlIl[57]];
    lIlllllllIlIlI = new Class[llIIIIIlIIIlIl[28]];
    lIlllllllIlIlI[llIIIIIlIIIlIl[4]] = GuiScreen.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[13]] = RayTraceResult.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[6]] = Minecraft.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[7]] = EntityPlayerSP.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[2]] = ao.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[10]] = InventoryPlayer.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[0]] = f13.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[26]] = EnumHand.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[19]] = ClickType.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[17]] = List.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[1]] = int.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[16]] = PlayerControllerMP.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[5]] = boolean.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[11]] = BlockHopper.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[24]] = NetHandlerPlayClient.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[21]] = WorldClient.class;
    lIlllllllIlIlI[llIIIIIlIIIlIl[18]] = Container.class;
  }
  
  private static void lIIIIIIllIIIIIll() {
    llIIIIIIlllIIl = new String[llIIIIIlIIIlIl[58]];
    llIIIIIIlllIIl[llIIIIIlIIIlIl[0]] = lIIIIIIlIlllIlll(llIIIIIIlllllI[llIIIIIlIIIlIl[0]], llIIIIIIlllllI[llIIIIIlIIIlIl[1]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[1]] = lIIIIIIlIllllIII(llIIIIIIlllllI[llIIIIIlIIIlIl[2]], llIIIIIIlllllI[llIIIIIlIIIlIl[5]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[2]] = lIIIIIIlIllllIII(llIIIIIIlllllI[llIIIIIlIIIlIl[6]], llIIIIIIlllllI[llIIIIIlIIIlIl[7]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[5]] = lIIIIIIlIlllIlll(llIIIIIIlllllI[llIIIIIlIIIlIl[10]], llIIIIIIlllllI[llIIIIIlIIIlIl[11]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[6]] = lIIIIIIlIlllIlll(llIIIIIIlllllI[llIIIIIlIIIlIl[13]], llIIIIIIlllllI[llIIIIIlIIIlIl[4]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[7]] = lIIIIIIlIllllIII(llIIIIIIlllllI[llIIIIIlIIIlIl[16]], llIIIIIIlllllI[llIIIIIlIIIlIl[18]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[10]] = lIIIIIIlIllllIIl(llIIIIIIlllllI[llIIIIIlIIIlIl[19]], llIIIIIIlllllI[llIIIIIlIIIlIl[21]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[11]] = lIIIIIIlIllllIIl(llIIIIIIlllllI[llIIIIIlIIIlIl[17]], llIIIIIIlllllI[llIIIIIlIIIlIl[24]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[13]] = lIIIIIIlIllllIIl(llIIIIIIlllllI[llIIIIIlIIIlIl[26]], llIIIIIIlllllI[llIIIIIlIIIlIl[28]]);
    llIIIIIIlllIIl[llIIIIIlIIIlIl[4]] = lIIIIIIlIllllIII("b8/8nlSSWgelHSUs06l9D6UHtHKxBGG3y3aN0e+qbRwn7ufoMRHfj+VLdmRMRG3T", "WPBNJ");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[16]] = lIIIIIIlIlllIlll("Ais1SQ8FICQEEA0oNUkBACckCRZCKy8TCxg3byIMGCc1HjIALzgCED8eewEXAi0eVlpYeHFePQ10aSsMCTpuCgsCKyIVAwo6bhIWBSJuIgwZIwkGDAh1aDFYTG4=", "lNAgb");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[18]] = lIIIIIIlIllllIII("+8OoQrYxdB3sIrBrJKavQY57f4GtzCUDluJ3/WWxfLw3zzOnH9xyIA==", "XouMs");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[19]] = lIIIIIIlIllllIII("B72nIBiWngV/e60SYW5jWxTMEN+tqPy8m9ftVuoyODoV3oxQAIt+0A==", "tSLbB");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[21]] = lIIIIIIlIllllIIl("duVBzESiC9son67YxUtmuAFqVWe26IKqgFl/cIUc4onCXPYrevj3zqfLrbofvEodPRgjndfaH9I=", "iAwaY");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[17]] = lIIIIIIlIllllIII("e3XSaKQxN33uV2wcd3IyNX1y3w42M282182+Cf5qm9U=", "BUInF");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[24]] = lIIIIIIlIllllIII("tEnx1shirrI/8lYqWXNVaWYj2HgJH7EAZAFS+5NU/JCm+UTyDPyjEHPA+cLwqefe289bJbIChD8=", "YhDWR");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[26]] = lIIIIIIlIllllIII("2BFqLkEphgmXvXshlgsAGET+y1R+QiVV5G3Ff/OUT7tc3Om5u2nCXQ==", "mDNWz");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[28]] = lIIIIIIlIllllIIl("0yo2Waw9PjutPIuc18WSHTmtLNV8TR2TXlUZ2r5KxuUKz381/naRAGxxkSTkA0IIMY+HSHlWP5nHgKzqyFDjSPOhS0XLu/jcZJkokKS6glMmOuqJIbVHIg159vD7aU3C", "RJBSa");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[29]] = lIIIIIIlIllllIIl("fO8XqsrOwk1rim0Fv0u5F2LTIloiYEPyqAFI4GSYUMKxfCsq8x4o9A==", "MlujG");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[30]] = lIIIIIIlIllllIIl("kAlLVAZwRGJZDyAk/yJzqWwDIwA1ZiEjUZwtIw+jlvlKmnXfhckrSA==", "qruYn");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[32]] = lIIIIIIlIlllIlll("OgRNHxkiEQoYCTgGTQ4FJ08FXFttDhMJAxUNDA8GbUkvAggjTg4FAzICEQ0LI04WGAQ7Tg4NGT9OIQACNAozAx5sSDVWTQ==", "Waclm");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[34]] = lIIIIIIlIllllIII("aPDmVnIgciDabge6FExYoADoJdkO0sERIFuNy+TdWxcg0TkImHDZ7r1ihJ4oZ5i7ZTrCIrTLiLWo9bvXir2jpw==", "qoMZS");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[31]] = lIIIIIIlIlllIlll("JDU/QAsjPi4NFCs2P0AFJjkuABJkNSUaDz4pZSsIPjk/FzYmMTILFBkAcQgTJDMUX15+aHlfOSkJcUZPHGprTg==", "JPKnf");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[36]] = lIIIIIIlIllllIIl("+UOwAgWOZIwWO7A/3x+n/q0RtiFdQ77BPTcJZvItt+QQ6+UiVRMa9B47oE3tSfbDu45SNgJPJqV8O0l9Zjt8AFrW5vDQK5MOTJfT0L/WA0w=", "thNan");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[38]] = lIIIIIIlIllllIIl("fr4WhuIk1e9xMNaTbvJdaIT+8fbJ40I/GnEwqaGVC1hZKcLW8nxTYsdRP2E9xI3hPJKj4SOMRF57b5a9cx4buHO7Zf0z909KVNI4CeC1OWl6mfiysKcWJQAWEKNMcx1p2R6KrBAOEh0=", "ESpmH");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[39]] = lIIIIIIlIllllIII("s3TK3uceY8ilk6heF8FrC/dLvcH9V1lnug76xHzkh9zv1CAzwv5Wy2Qn7K+oKh3UroU5B02OoyNRVg3KkPnkFcpScWblO8I6CFLkKo72O1arfOwdwY2nPcW3RRszHv2+", "zrhRy");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[41]] = lIIIIIIlIlllIlll("KQAYJW02FQcobTAVHCEiLk89MDEmAAN+JSoNGiExeUkiLiI1AEExNyoNQSI2LQIaLSwtTj42JicIDSU3JlpHCCkiFw9rNjcIAmswNxMLJS5sMho2JiIMVX5jYw==", "CanDC");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[42]] = lIIIIIIlIllllIII("DuhElV3+4DX5/lWhQFcDXBi2sH5ryioWKzgv4u/VCPYaFIR22Dv4zatdF1secD5d0NrOCOd3FN66MWN9R6Y1jbpEYmU+aPmo2qTmHBvCA+BrNtTtAEPHrUBeTPU90Bcf", "ZzIYn");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[43]] = lIIIIIIlIllllIII("v2qh8H8pS0HeyNnNs1JXlEzlUIXI35zf0gLSIPxoWbYiJqgSnp+7sQ==", "rrhjt");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[44]] = lIIIIIIlIllllIIl("PAtWHLWGLsyFFsBFIgTZOtZyOCqvlcjsSrm4NERknfO/Ydx/BGKlxg==", "XSeZJ");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[12]] = lIIIIIIlIllllIIl("ZNSESTJm1CUQ7Kkj6Zm2PaIWk+r6TaAyHVz7+D8/hhWO7Dt0frirO/lo+vKtj6GRJeAoFOMiXGk=", "kSzJc");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[46]] = lIIIIIIlIllllIII("2EKjH8cpF6u3kg6miwzjXmlkTLKHKERq8UBTx1T7JCLUB5gKphH0iiFZN3FAXvxKQXW0/82RkCX/CcAROc4Z7KKFPDymHi/LDKfXrY0Z94k=", "mLgkp");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[23]] = lIIIIIIlIllllIII("gJxy4NqnSh6+Y19yus5RVYCxXbuGB0mbNJEA7j0DdGWSAmy4EAD+CDlIZ6CIPnrfrMmQb5kiTNJdSXA3/jV/QgQyyGFiYe55HQ2Lyl4EyHE=", "fwLBh");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[48]] = lIIIIIIlIlllIlll("EjsYMGsNLgc9azs1AyEkCjsaPjdCOQE8NRkoBz8iQnIiOyQOO0EkMRE2QTcwFjkaOCoWdSgkKxsuBz4rQ3MiOyQOO0EkMRE2QRIqFSoPIyQMNRxqf1g=", "xZnQE");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[20]] = lIIIIIIlIlllIlll("LhJUKRk2BxMuCSwQVDgFM1kbNVcrFgkICCIUEj8JeV8wczd5V1o=", "CwzZm");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[40]] = lIIIIIIlIllllIIl("sLgeTuSrF8sjlGOasrXlPnZxTkRS407K+R1hazGrAHBZ0RZxUvn/1A==", "ZzPnR");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[50]] = lIIIIIIlIlllIlll("CjFlCxkSJCIMCQgzZRoFF3otSlcKN3FMV0d0a1g=", "gTKxm");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[47]] = lIIIIIIlIllllIIl("UE2QN7R1NPc+YgMT2/S80BW1e3QFzA7AGJaloU0s/dNe8/UOmofJ7+nhrN3M/vmvTeYEmQg78WwI4oAbJ1fBvYBT0bf4Z/wMGWbQj246FvJIud56tJ5BH65lMIS2Mb6upPIzug17PTED8WgcuEAyw3Jeb+ks/IoQFoja+Ut24Q62Ds7O2wZpQ7aJxdpBQ/tMswjxQ4C0rGkPRbLiXQvo2M4w6GQCGzvDP7yZ4zXQXTimFzON966Wug==", "xJVid");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[45]] = lIIIIIIlIllllIII("tMsHXGoV0ILMhUCSit0QI5dK0WceJPrZF8Gyl4LwnjeyR7MrSGxBblHj0IW+XX7DkAJR8l9yQ5k=", "GfnCK");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[9]] = lIIIIIIlIllllIIl("kDy6stft10+KsV5REBpg+HboDazpxqWhOJM56doVUL27eQC6lUVyF/LAzN2NT5SI0f5jmO872az88i4Xjpv/uFzpCy9W2mEm", "ZpSxO");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[22]] = lIIIIIIlIllllIIl("OqYOKpF4yqIvJ3n53lS/lwU1RrPqmI5c4fOQomx5rTITuxpA81j8RoC81nuXwRV2actkOwJl6poVOtBUz78abZa1V4q4ME/otLR32dXbQOMU4Waysdf68g==", "uzdvT");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[49]] = lIIIIIIlIllllIII("LiRAqgZmYplqmPaG3caVDZG/FK9WSCg75tgKTLeA9pscmcPFIQcrHg==", "jtqgL");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[33]] = lIIIIIIlIlllIlll("CT1eFQ4RKBkSHgs/XgQSFHYWVEAXMAUKEQEqSlVARHhQ", "dXpfz");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[37]] = lIIIIIIlIllllIII("KSgtpz+UdJr7I58nmMZY3Y8GOwX+dGjbpRCIrrlG+/sxlvgbB2jMXE0WjepNV7t9", "aNhxG");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[51]] = lIIIIIIlIlllIlll("DxYffTUIHQ4wKgAVH309DwcCJyFPAwcyIQQBRRo2FxYFJzcTCjs/ORgWGWk+FB0IDG9RR19rBwZJQ3oUDxYffDUIHQ4wKgAVH3wxFRYGfBEVFgYALAAQAGhiQVM=", "askSX");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[15]] = lIIIIIIlIllllIII("7+Hi6VEw6zoc3icyapCVV6X7oTUJFJTzqn1IcmnIll3RihZXrhb1o5d/JVN1x6QPuHsvRDXwdsInQuRTErgmq5oe+ivqcx7p", "uiQyM");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[35]] = lIIIIIIlIllllIII("1A20iwAAfJbasIMbGO7KUdTrHvVTDrT7O0BRRM1GQ950p1Z/qcDgaT+FtmNIg3XvjUKqx1Xrh/8JSNU4Y9gyvbvuRs0I01S/", "FuuUD");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[25]] = lIIIIIIlIllllIII("AM/v6pBqdfMaRuoREIAybjX/fYdCXAnMMH/KC0Pl5OjzQiiAJQIJV91ZvPJdCqRUCxFNvBoZdxU=", "YMezn");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[52]] = lIIIIIIlIllllIII("M7I5vaEVHQBb98NKH1l80xmuEUPOJmEGkqNYyoMGVS52d2XrJftFV7BxwQnc0Ply/5RXc4yljgx4O0KVpLGBFjoj8i+Ck4T0VmydpwaBzzTtBQu1vkWAujAfWX5z/b3h", "rnqNa");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[14]] = lIIIIIIlIllllIIl("ZsFg/stRpyAmw+gBAlBzXaGDHHj4a1f/Rb1mBSHQmga8HfRSIlOVo2BSICeT4f0SWbqX7zErt6dOK5Snmc9UvSipXCcCRUBDERq+2YhNMuiT4OtfV6Rkog==", "KdzgD");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[27]] = lIIIIIIlIllllIIl("YwqMK7PQInFurQUjG6Lc3Rndxp/U0cShS1Dm6VQQP6DlqvrR7AtZSJwKQgHW72bW5hBfwgLUaZ0=", "ZJfNV");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[8]] = lIIIIIIlIllllIII("Za33R48OocpXtfumJ/H5nJjSahygueDNrGX+RhS5Cpjvf5ehN3RdWyBwNRXkGYmpLoPyR6CNUkc=", "pcYvL");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[53]] = lIIIIIIlIlllIlll("BhQYfwwBHwkyEwkXGH8CBBgJPxVGFAIlCBwIQhQPHBgYKDEEEBU0EzshVjcIDR0IDlZZQVtgPgoIVmdbSFFM", "hqlQa");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[54]] = lIIIIIIlIllllIIl("vcdYpzLXejPqBaLRkPToK5GyESxG9/mpWNB6yYIIC4rWLPqaZ3CzLA==", "ZRCsr");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[55]] = lIIIIIIlIllllIIl("IgTWjJ7A4rIUkGRBRPRRsp+kSjU3PpHna15t5fEKxete6icHWLqz84l3AYcDmbVOTaFctQGFG/k=", "jGcJF");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[56]] = lIIIIIIlIllllIII("fDB86OioJaohNKn330j0T6AuaDekcTzRIdh96SWidgYeiPYspaYNhVVgQ67wjhNBLs2wjP7/y8+B3zTmkp86lVA6ND+h9pHJ", "CnWYx");
    llIIIIIIlllIIl[llIIIIIlIIIlIl[57]] = lIIIIIIlIllllIIl("i/B2aZFwPIf8brNfwYcvDsr/j7KoCx0sL01v6pNFw8M6obGHB0W2UOP/5eWMkmmkPkOWmIzd6gU=", "EdFSJ");
    llIIIIIIlllllI = null;
  }
  
  private static void lIIIIIIllIIIIlII() {
    String str = (new Exception()).getStackTrace()[llIIIIIlIIIlIl[0]].getFileName();
    llIIIIIIlllllI = str.substring(str.indexOf("ä") + llIIIIIlIIIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIlllIlll(String lllllllllllllllIllIlllIIlllIllII, String lllllllllllllllIllIlllIIlllIlIll) {
    lllllllllllllllIllIlllIIlllIllII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIIlllIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIIlllIlIlI = new StringBuilder();
    char[] lllllllllllllllIllIlllIIlllIlIIl = lllllllllllllllIllIlllIIlllIlIll.toCharArray();
    int lllllllllllllllIllIlllIIlllIlIII = llIIIIIlIIIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIIlllIllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIlIIIlIl[0];
    while (lIIIIIIllIIlIIII(j, i)) {
      char lllllllllllllllIllIlllIIlllIllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIIlllIlIII++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIIlllIlIlI);
  }
  
  private static String lIIIIIIlIllllIII(String lllllllllllllllIllIlllIIlllIIlII, String lllllllllllllllIllIlllIIlllIIIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIIlllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIIlllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIIlllIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIIlllIIllI.init(llIIIIIlIIIlIl[2], lllllllllllllllIllIlllIIlllIIlll);
      return new String(lllllllllllllllIllIlllIIlllIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIIlllIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIIlllIIlIl) {
      lllllllllllllllIllIlllIIlllIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIllllIIl(String lllllllllllllllIllIlllIIllIlllll, String lllllllllllllllIllIlllIIllIllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIIlllIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIIllIllllI.getBytes(StandardCharsets.UTF_8)), llIIIIIlIIIlIl[13]), "DES");
      Cipher lllllllllllllllIllIlllIIlllIIIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIIlllIIIIl.init(llIIIIIlIIIlIl[2], lllllllllllllllIllIlllIIlllIIIlI);
      return new String(lllllllllllllllIllIlllIIlllIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIIllIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIIlllIIIII) {
      lllllllllllllllIllIlllIIlllIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIllIIIllll() {
    llIIIIIlIIIlIl = new int[59];
    llIIIIIlIIIlIl[0] = (0x50 ^ 0x71) << " ".length() & ((0x49 ^ 0x68) << " ".length() ^ 0xFFFFFFFF);
    llIIIIIlIIIlIl[1] = " ".length();
    llIIIIIlIIIlIl[2] = " ".length() << " ".length();
    llIIIIIlIIIlIl[3] = -" ".length();
    llIIIIIlIIIlIl[4] = 0x1D ^ 0x14;
    llIIIIIlIIIlIl[5] = "   ".length();
    llIIIIIlIIIlIl[6] = " ".length() << " ".length() << " ".length();
    llIIIIIlIIIlIl[7] = 0x1E ^ 0x1B;
    llIIIIIlIIIlIl[8] = (0x18 ^ 0x13) << " ".length() << " ".length() ^ 0x6E ^ 0x71;
    llIIIIIlIIIlIl[9] = 0x34 ^ 0x61 ^ (0x53 ^ 0x6A) << " ".length();
    llIIIIIlIIIlIl[10] = "   ".length() << " ".length();
    llIIIIIlIIIlIl[11] = (0xD ^ 0x2) << "   ".length() ^ 72 + 124 - 182 + 113;
    llIIIIIlIIIlIl[12] = (0x5D ^ 0x56 ^ " ".length() << " ".length() << " ".length()) << " ".length();
    llIIIIIlIIIlIl[13] = " ".length() << "   ".length();
    llIIIIIlIIIlIl[14] = 0x4D ^ 0x70 ^ "   ".length() << " ".length() << " ".length();
    llIIIIIlIIIlIl[15] = 0xC2 ^ 0x95 ^ (0x94 ^ 0xA9) << " ".length();
    llIIIIIlIIIlIl[16] = (0xA8 ^ 0xAD) << " ".length();
    llIIIIIlIIIlIl[17] = ((0x3F ^ 0x32) << "   ".length() ^ 0x5E ^ 0x31) << " ".length();
    llIIIIIlIIIlIl[18] = 0x79 ^ 0x72;
    llIIIIIlIIIlIl[19] = "   ".length() << " ".length() << " ".length();
    llIIIIIlIIIlIl[20] = (0xEB ^ 0xC6 ^ (0x3 ^ 0xC) << " ".length() << " ".length()) << " ".length();
    llIIIIIlIIIlIl[21] = 0xC1 ^ 0xAA ^ (0x59 ^ 0x6A) << " ".length();
    llIIIIIlIIIlIl[22] = (0xE8 ^ 0x8B ^ (0x9E ^ 0xAD) << " ".length()) << "   ".length();
    llIIIIIlIIIlIl[23] = " ".length() << (0x16 ^ 0x13);
    llIIIIIlIIIlIl[24] = 0x49 ^ 0x46;
    llIIIIIlIIIlIl[25] = 120 + 177 - 245 + 181 ^ (0x39 ^ 0x5A) << " ".length();
    llIIIIIlIIIlIl[26] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIIIlIl[27] = (0x0 ^ 0x19) << " ".length();
    llIIIIIlIIIlIl[28] = (0x5E ^ 0x7D) << " ".length() ^ 0xC2 ^ 0x95;
    llIIIIIlIIIlIl[29] = ("   ".length() ^ (0x9D ^ 0x98) << " ".length()) << " ".length();
    llIIIIIlIIIlIl[30] = 0x34 ^ 0x7F ^ (0x63 ^ 0x68) << "   ".length();
    llIIIIIlIIIlIl[31] = (0x1E ^ 0x15) << " ".length();
    llIIIIIlIIIlIl[32] = ((0x49 ^ 0x76) << " ".length() ^ 0x6F ^ 0x14) << " ".length() << " ".length();
    llIIIIIlIIIlIl[33] = (0x87 ^ 0x92) << " ".length();
    llIIIIIlIIIlIl[34] = 0x2A ^ 0x3F;
    llIIIIIlIIIlIl[35] = (78 + 103 - 100 + 70 ^ " ".length() << (0x7B ^ 0x7C)) << " ".length();
    llIIIIIlIIIlIl[36] = 0x4B ^ 0x5C;
    llIIIIIlIIIlIl[37] = 0x26 ^ 0xD;
    llIIIIIlIIIlIl[38] = "   ".length() << "   ".length();
    llIIIIIlIIIlIl[39] = 0xFE ^ 0xB5 ^ (0x98 ^ 0xB1) << " ".length();
    llIIIIIlIIIlIl[40] = 102 + 23 - 12 + 30 ^ (0x3C ^ 0x17) << " ".length() << " ".length();
    llIIIIIlIIIlIl[41] = (97 + 162 - 93 + 15 ^ (0x41 ^ 0x56) << "   ".length()) << " ".length();
    llIIIIIlIIIlIl[42] = 0x9D ^ 0x86;
    llIIIIIlIIIlIl[43] = (0xB8 ^ 0xBF) << " ".length() << " ".length();
    llIIIIIlIIIlIl[44] = 0x37 ^ 0x24 ^ (0x73 ^ 0x74) << " ".length();
    llIIIIIlIIIlIl[45] = (56 + 146 - 171 + 126 ^ (0x68 ^ 0x2F) << " ".length()) << " ".length();
    llIIIIIlIIIlIl[46] = 0x8 ^ 0x17;
    llIIIIIlIIIlIl[47] = 0xBE ^ 0x9B;
    llIIIIIlIIIlIl[48] = (0x53 ^ 0x42) << " ".length() ^ "   ".length();
    llIIIIIlIIIlIl[49] = 0xA ^ 0x69 ^ (0xA5 ^ 0x80) << " ".length();
    llIIIIIlIIIlIl[50] = (0x2C ^ 0x25) << " ".length() << " ".length();
    llIIIIIlIIIlIl[51] = (0xF ^ 0x4) << " ".length() << " ".length();
    llIIIIIlIIIlIl[52] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIIIlIl[53] = (0xCD ^ 0x84 ^ (0x57 ^ 0x46) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIIlIIIlIl[54] = 0x16 ^ 0x23;
    llIIIIIlIIIlIl[55] = (157 + 72 - 131 + 73 ^ (0xF ^ 0x4) << " ".length() << " ".length() << " ".length()) << " ".length();
    llIIIIIlIIIlIl[56] = 0x1F ^ 0x28;
    llIIIIIlIIIlIl[57] = ((0xB2 ^ 0xB9) << " ".length() ^ 0x4A ^ 0x5B) << "   ".length();
    llIIIIIlIIIlIl[58] = 0x11 ^ 0x28;
  }
  
  private static boolean lIIIIIIllIIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIllIIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIllIIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIllIIlIlIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIIllIIlIlII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIllIIlIIIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIllIIlIIll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIllIIlIlll(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static int lIIIIIIllIIlIllI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */