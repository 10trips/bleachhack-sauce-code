package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;

public class aq extends au {
  f100000000000000000000.Double multiplier;
  
  f100000000000000000000.Boolean accelerationTimer;
  
  f100000000000000000000.Integer timerSpeed;
  
  f100000000000000000000.Boolean speedDetect;
  
  f100000000000000000000.Boolean jumpDetect;
  
  f100000000000000000000.Double extraY;
  
  private static int[] llIllII;
  
  private int currentState;
  
  private double prevDist;
  
  private double motionSpeed;
  
  private boolean attempting;
  
  private boolean doToggle;
  
  @EventHandler
  private final Listener<f10000000000000> playerMove;
  
  private static String[] lIlllIIIlIIllI;
  
  private static Class[] lIlllIIIlIIlll;
  
  private static final String[] lIlllIlIIIlIlI;
  
  private static String[] lIlllIlIIIlIll;
  
  private static final int[] lIlllIlIIIllII;
  
  public aq() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: aload_0
    //   47: <illegal opcode> invoke : (Lme/stupitdog/bhp/aq;)Lme/zero/alpine/listener/EventHook;
    //   52: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   55: iconst_0
    //   56: iaload
    //   57: anewarray java/util/function/Predicate
    //   60: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   63: putfield playerMove : Lme/zero/alpine/listener/Listener;
    //   66: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	67	0	lllllllllllllllIlllIlIlllIlIlIII	Lme/stupitdog/bhp/aq;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: ldc2_w 1.63
    //   14: dconst_0
    //   15: ldc2_w 10.0
    //   18: <illegal opcode> 1 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   23: <illegal opcode> 2 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   28: aload_0
    //   29: aload_0
    //   30: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   42: iconst_0
    //   43: iaload
    //   44: <illegal opcode> 3 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   49: <illegal opcode> 4 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   54: aload_0
    //   55: aload_0
    //   56: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   59: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   62: iconst_5
    //   63: iaload
    //   64: aaload
    //   65: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   68: iconst_1
    //   69: iaload
    //   70: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   73: iconst_0
    //   74: iaload
    //   75: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   78: bipush #6
    //   80: iaload
    //   81: <illegal opcode> 5 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   86: <illegal opcode> 6 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   91: aload_0
    //   92: aload_0
    //   93: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   96: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   99: bipush #7
    //   101: iaload
    //   102: aaload
    //   103: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   106: iconst_1
    //   107: iaload
    //   108: <illegal opcode> 3 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   113: <illegal opcode> 7 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   118: aload_0
    //   119: aload_0
    //   120: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   123: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   126: bipush #8
    //   128: iaload
    //   129: aaload
    //   130: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   133: iconst_1
    //   134: iaload
    //   135: <illegal opcode> 3 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   140: <illegal opcode> 8 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   145: aload_0
    //   146: aload_0
    //   147: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   150: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   153: bipush #9
    //   155: iaload
    //   156: aaload
    //   157: dconst_0
    //   158: dconst_0
    //   159: dconst_1
    //   160: <illegal opcode> 1 : (Lme/stupitdog/bhp/aq;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   165: <illegal opcode> 9 : (Lme/stupitdog/bhp/aq;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   170: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	171	0	lllllllllllllllIlllIlIlllIlIIlll	Lme/stupitdog/bhp/aq;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onEnable : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 10 : (Lme/stupitdog/bhp/aq;Z)V
    //   15: <illegal opcode> 11 : ()V
    //   20: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	21	0	lllllllllllllllIlllIlIlllIlIIllI	Lme/stupitdog/bhp/aq;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onDisable : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 12 : (Lme/stupitdog/bhp/aq;I)V
    //   15: aload_0
    //   16: dconst_0
    //   17: <illegal opcode> 13 : (Lme/stupitdog/bhp/aq;D)V
    //   22: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	23	0	lllllllllllllllIlllIlIlllIlIIlIl	Lme/stupitdog/bhp/aq;
  }
  
  private static int lIIlIIIIl(float lllllllllllllllIlllIlIlllIlIIlII, float lllllllllllllllIlllIlIlllIlIIIll) {
    float lllllllllllllllIlllIlIlllIlIIIlI;
    if (lllllIIllIlllII(lllllIIllIllIlI(lllllllllllllllIlllIlIlllIlIIIlI = lllllllllllllllIlllIlIlllIlIIlII - lllllllllllllllIlllIlIlllIlIIIll, 0.0F))) {
      "".length();
      if ("   ".length() == (" ".length() << " ".length() & (" ".length() << " ".length() ^ 0xFFFFFFFF)))
        return (0x60 ^ 0x35) & (0xF4 ^ 0xA1 ^ 0xFFFFFFFF); 
    } else if (lllllIIllIlllIl(lllllIIllIllIll(lllllllllllllllIlllIlIlllIlIIIlI, 0.0F))) {
      "".length();
      if (-(0x79 ^ 0x7C) >= 0)
        return " ".length() & (" ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlllIlIIIllII[1];
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   6: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   11: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   16: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   31: dsub
    //   32: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   37: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   42: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   47: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   62: dsub
    //   63: dmul
    //   64: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   69: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   74: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   79: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   84: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   89: <illegal opcode> 19 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   94: dsub
    //   95: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   100: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   105: <illegal opcode> 18 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   110: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   115: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   120: <illegal opcode> 19 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   125: dsub
    //   126: dmul
    //   127: dadd
    //   128: <illegal opcode> 20 : (D)D
    //   133: <illegal opcode> 21 : (Lme/stupitdog/bhp/aq;D)V
    //   138: aload_0
    //   139: <illegal opcode> 22 : (Lme/stupitdog/bhp/aq;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   144: <illegal opcode> 23 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   149: invokestatic lllllIIllIllllI : (I)Z
    //   152: ifeq -> 192
    //   155: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   158: iconst_1
    //   159: iaload
    //   160: ldc ''
    //   162: invokevirtual length : ()I
    //   165: pop
    //   166: ldc '   '
    //   168: invokevirtual length : ()I
    //   171: ldc ' '
    //   173: invokevirtual length : ()I
    //   176: ldc ' '
    //   178: invokevirtual length : ()I
    //   181: ldc ' '
    //   183: invokevirtual length : ()I
    //   186: ishl
    //   187: ishl
    //   188: if_icmplt -> 197
    //   191: return
    //   192: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   195: iconst_0
    //   196: iaload
    //   197: <illegal opcode> 24 : (I)Z
    //   202: invokestatic lllllIIllIllllI : (I)Z
    //   205: ifeq -> 252
    //   208: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   213: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   218: ldc 50.0
    //   220: aload_0
    //   221: <illegal opcode> 26 : (Lme/stupitdog/bhp/aq;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   226: <illegal opcode> 27 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   231: i2f
    //   232: fdiv
    //   233: putfield field_194149_e : F
    //   236: ldc ''
    //   238: invokevirtual length : ()I
    //   241: pop
    //   242: bipush #15
    //   244: bipush #11
    //   246: ixor
    //   247: ineg
    //   248: iflt -> 300
    //   251: return
    //   252: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   257: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   262: <illegal opcode> 28 : (Lnet/minecraft/util/Timer;)F
    //   267: ldc 50.0
    //   269: <illegal opcode> 29 : (FF)I
    //   274: <illegal opcode> 24 : (I)Z
    //   279: invokestatic lllllIIllIllllI : (I)Z
    //   282: ifeq -> 300
    //   285: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   290: <illegal opcode> 25 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   295: ldc 50.0
    //   297: putfield field_194149_e : F
    //   300: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	301	0	lllllllllllllllIlllIlIlllIlIIIIl	Lme/stupitdog/bhp/aq;
  }
  
  private static void lIIlIIIII() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   3: bipush #6
    //   5: iaload
    //   6: newarray int
    //   8: dup
    //   9: <illegal opcode> 30 : ([I)V
    //   14: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   17: iconst_0
    //   18: iaload
    //   19: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   22: iconst_0
    //   23: iaload
    //   24: iastore
    //   25: <illegal opcode> 31 : ()[I
    //   30: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   33: iconst_1
    //   34: iaload
    //   35: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   38: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   41: bipush #11
    //   43: iaload
    //   44: aaload
    //   45: <illegal opcode> 32 : (Ljava/lang/String;)I
    //   50: iastore
    //   51: <illegal opcode> 31 : ()[I
    //   56: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   59: iconst_2
    //   60: iaload
    //   61: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   64: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   67: bipush #6
    //   69: iaload
    //   70: aaload
    //   71: <illegal opcode> 32 : (Ljava/lang/String;)I
    //   76: iastore
    //   77: <illegal opcode> 31 : ()[I
    //   82: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   85: iconst_3
    //   86: iaload
    //   87: getstatic me/stupitdog/bhp/aq.lIlllIlIIIlIlI : [Ljava/lang/String;
    //   90: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   93: bipush #12
    //   95: iaload
    //   96: aaload
    //   97: <illegal opcode> 32 : (Ljava/lang/String;)I
    //   102: iastore
    //   103: <illegal opcode> 31 : ()[I
    //   108: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   111: iconst_4
    //   112: iaload
    //   113: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   116: bipush #6
    //   118: iaload
    //   119: iastore
    //   120: <illegal opcode> 31 : ()[I
    //   125: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   128: iconst_5
    //   129: iaload
    //   130: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   133: iconst_4
    //   134: iaload
    //   135: iastore
    //   136: <illegal opcode> 31 : ()[I
    //   141: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   144: bipush #7
    //   146: iaload
    //   147: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   150: iconst_5
    //   151: iaload
    //   152: iastore
    //   153: <illegal opcode> 31 : ()[I
    //   158: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   161: bipush #8
    //   163: iaload
    //   164: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   167: bipush #7
    //   169: iaload
    //   170: iastore
    //   171: <illegal opcode> 31 : ()[I
    //   176: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   179: bipush #9
    //   181: iaload
    //   182: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   185: bipush #8
    //   187: iaload
    //   188: iastore
    //   189: <illegal opcode> 31 : ()[I
    //   194: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   197: bipush #11
    //   199: iaload
    //   200: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   203: bipush #9
    //   205: iaload
    //   206: iastore
    //   207: return
  }
  
  private static int lIIlIIllI(float lllllllllllllllIlllIlIlllIlIIIII, float lllllllllllllllIlllIlIlllIIlllll) {
    float lllllllllllllllIlllIlIlllIIllllI;
    if (lllllIIllIlllII(lllllIIllIlllll(lllllllllllllllIlllIlIlllIIllllI = lllllllllllllllIlllIlIlllIlIIIII - lllllllllllllllIlllIlIlllIIlllll, 0.0F))) {
      "".length();
      if (null != null)
        return ((0x11 ^ 0x34) << " ".length() ^ 0xD8 ^ 0x95) << " ".length() << " ".length() & ((0x13 ^ 0x6A ^ (0x16 ^ 0x29) << " ".length()) << " ".length() << " ".length() ^ -" ".length()); 
    } else if (lllllIIllIlllIl(lllllIIlllIIIII(lllllllllllllllIlllIlIlllIIllllI, 0.0F))) {
      "".length();
      if (((163 + 76 - 137 + 73 ^ (0x15 ^ 0x3A) << " ".length() << " ".length()) << " ".length() & ((0x3F ^ 0x2C ^ (0x17 ^ 0xC) & (0x87 ^ 0x9C ^ 0xFFFFFFFF)) << " ".length() ^ -" ".length())) != 0)
        return ((0xBD ^ 0xB8) << "   ".length() ^ 0x9 ^ 0x2E) << " ".length() & ((" ".length() << " ".length() ^ 0x43 ^ 0x4E) << " ".length() ^ -" ".length()); 
    } else {
    
    } 
    return lIlllIlIIIllII[1];
  }
  
  private static boolean lIIlIlIII(int lllllllllllllllIlllIlIlllIIlllIl) {
    if (lllllIIlllIIIIl(lllllllllllllllIlllIlIlllIIlllIl)) {
      "".length();
      if (" ".length() < " ".length())
        return (0x44 ^ 0x49) << " ".length() & ((0x2A ^ 0x27) << " ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlllIlIIIllII[0];
  }
  
  private static boolean lIIlIlIIl(int lllllllllllllllIlllIlIlllIIlllII) {
    if (lllllIIlllIIIlI(lllllllllllllllIlllIlIlllIIlllII)) {
      "".length();
      if (((0x36 ^ 0xF ^ "   ".length() << " ".length() << " ".length() << " ".length()) << "   ".length() & (("   ".length() << " ".length() << " ".length() ^ 0x95 ^ 0x90) << "   ".length() ^ -" ".length())) != ((" ".length() << (0x2 ^ 0x7) ^ 0x9C ^ 0xAF) << " ".length() & ((0x8D ^ 0xC6 ^ (0xB5 ^ 0xBE) << "   ".length()) << " ".length() ^ -" ".length())))
        return ((0x4C ^ 0x61) << " ".length() ^ "   ".length()) & (0x19 ^ 0x2A ^ (0xA6 ^ 0x93) << " ".length() ^ -" ".length()); 
    } else {
    
    } 
    return lIlllIlIIIllII[0];
  }
  
  private double getBaseMotionSpeed() {
    // Byte code:
    //   0: ldc2_w 0.272
    //   3: aload_0
    //   4: <illegal opcode> 33 : (Lme/stupitdog/bhp/aq;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   9: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   14: dmul
    //   15: dstore_1
    //   16: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 35 : ()Lnet/minecraft/potion/Potion;
    //   31: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   36: invokestatic lllllIIllIllllI : (I)Z
    //   39: ifeq -> 68
    //   42: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   45: iconst_1
    //   46: iaload
    //   47: ldc ''
    //   49: invokevirtual length : ()I
    //   52: pop
    //   53: ldc '   '
    //   55: invokevirtual length : ()I
    //   58: ldc '   '
    //   60: invokevirtual length : ()I
    //   63: if_icmpge -> 73
    //   66: dconst_0
    //   67: dreturn
    //   68: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   71: iconst_0
    //   72: iaload
    //   73: <illegal opcode> 24 : (I)Z
    //   78: invokestatic lllllIIllIllllI : (I)Z
    //   81: ifeq -> 249
    //   84: aload_0
    //   85: <illegal opcode> 37 : (Lme/stupitdog/bhp/aq;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   90: <illegal opcode> 23 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   95: invokestatic lllllIIllIllllI : (I)Z
    //   98: ifeq -> 188
    //   101: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   104: iconst_1
    //   105: iaload
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: bipush #27
    //   119: bipush #28
    //   121: ixor
    //   122: ldc '   '
    //   124: invokevirtual length : ()I
    //   127: ldc ' '
    //   129: invokevirtual length : ()I
    //   132: ldc ' '
    //   134: invokevirtual length : ()I
    //   137: ishl
    //   138: ishl
    //   139: ixor
    //   140: ldc ' '
    //   142: invokevirtual length : ()I
    //   145: ishl
    //   146: bipush #121
    //   148: bipush #85
    //   150: iadd
    //   151: bipush #14
    //   153: isub
    //   154: bipush #9
    //   156: iadd
    //   157: bipush #121
    //   159: bipush #24
    //   161: ixor
    //   162: ldc ' '
    //   164: invokevirtual length : ()I
    //   167: ishl
    //   168: ixor
    //   169: ldc ' '
    //   171: invokevirtual length : ()I
    //   174: ishl
    //   175: ldc ' '
    //   177: invokevirtual length : ()I
    //   180: ineg
    //   181: ixor
    //   182: iand
    //   183: if_icmpgt -> 193
    //   186: dconst_0
    //   187: dreturn
    //   188: getstatic me/stupitdog/bhp/aq.lIlllIlIIIllII : [I
    //   191: iconst_0
    //   192: iaload
    //   193: <illegal opcode> 24 : (I)Z
    //   198: invokestatic lllllIIllIllllI : (I)Z
    //   201: ifeq -> 249
    //   204: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   209: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   214: <illegal opcode> 35 : ()Lnet/minecraft/potion/Potion;
    //   219: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;
    //   224: <illegal opcode> 39 : (Ljava/lang/Object;)Ljava/lang/Object;
    //   229: checkcast net/minecraft/potion/PotionEffect
    //   232: <illegal opcode> 40 : (Lnet/minecraft/potion/PotionEffect;)I
    //   237: istore_3
    //   238: dload_1
    //   239: dconst_1
    //   240: ldc2_w 0.2
    //   243: iload_3
    //   244: i2d
    //   245: dmul
    //   246: dadd
    //   247: dmul
    //   248: dstore_1
    //   249: dload_1
    //   250: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   238	11	3	lllllllllllllllIlllIlIlllIIllIll	I
    //   0	251	0	lllllllllllllllIlllIlIlllIIllIlI	Lme/stupitdog/bhp/aq;
    //   16	235	1	lllllllllllllllIlllIlIlllIIllIIl	D
  }
  
  private static int lIIlIIlll(double lllllllllllllllIlllIlIlllIIllIII, double lllllllllllllllIlllIlIlllIIlIlll) {
    double lllllllllllllllIlllIlIlllIIlIllI;
    if (lllllIIllIlllII(lllllIIlllIIIll(lllllllllllllllIlllIlIlllIIlIllI = lllllllllllllllIlllIlIlllIIllIII - lllllllllllllllIlllIlIlllIIlIlll, 0.0D))) {
      "".length();
      if ((" ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length())
        return (0xB3 ^ 0x90) << " ".length() & ((0x39 ^ 0x1A) << " ".length() ^ 0xFFFFFFFF); 
    } else if (lllllIIllIlllIl(lllllIIlllIIlII(lllllllllllllllIlllIlIlllIIlIllI, 0.0D))) {
      "".length();
      if (" ".length() <= 0)
        return (0x10 ^ 0x1F) << " ".length() & ((0x3A ^ 0x35) << " ".length() ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlllIlIIIllII[1];
  }
  
  private static boolean lIIlIIlII(int lllllllllllllllIlllIlIlllIIlIlIl) {
    if (lllllIIllIllllI(lllllllllllllllIlllIlIlllIIlIlIl)) {
      "".length();
      if (" ".length() << " ".length() << " ".length() == 0)
        return " ".length() << " ".length() & (" ".length() << " ".length() ^ -" ".length()); 
    } else {
    
    } 
    return lIlllIlIIIllII[0];
  }
  
  private static boolean lIIlIIlIl(int lllllllllllllllIlllIlIlllIIlIlII) {
    if (lllllIIllIlllII(lllllllllllllllIlllIlIlllIIlIlII)) {
      "".length();
      if ("   ".length() < ((20 + 17 - -10 + 104 ^ (0xB3 ^ 0x94) << " ".length() << " ".length()) & (0x48 ^ 0x65 ^ (0x23 ^ 0x30) << " ".length() ^ -" ".length())))
        return (4 + 129 - 47 + 57 ^ (0x7 ^ 0x20) << " ".length() << " ".length()) << " ".length() & ((0x9C ^ 0x9B ^ (0x71 ^ 0x74) << " ".length() << " ".length()) << " ".length() ^ -" ".length()); 
    } else {
    
    } 
    return lIlllIlIIIllII[0];
  }
  
  static {
    lllllIIllIllIIl();
    lllllIIllIllIII();
    lllllIIllIlIlll();
    lllllIIllIlIIll();
  }
  
  private static CallSite llllIllllIllIlI(MethodHandles.Lookup lllllllllllllllIlllIlIlllIIIIlII, String lllllllllllllllIlllIlIlllIIIIIll, MethodType lllllllllllllllIlllIlIlllIIIIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIlllIIIlIlI = lIlllIIIlIIllI[Integer.parseInt(lllllllllllllllIlllIlIlllIIIIIll)].split(lIlllIlIIIlIlI[lIlllIlIIIllII[13]]);
      Class<?> lllllllllllllllIlllIlIlllIIIlIIl = Class.forName(lllllllllllllllIlllIlIlllIIIlIlI[lIlllIlIIIllII[0]]);
      String lllllllllllllllIlllIlIlllIIIlIII = lllllllllllllllIlllIlIlllIIIlIlI[lIlllIlIIIllII[1]];
      MethodHandle lllllllllllllllIlllIlIlllIIIIlll = null;
      int lllllllllllllllIlllIlIlllIIIIllI = lllllllllllllllIlllIlIlllIIIlIlI[lIlllIlIIIllII[3]].length();
      if (lllllIIlllIIlIl(lllllllllllllllIlllIlIlllIIIIllI, lIlllIlIIIllII[2])) {
        MethodType lllllllllllllllIlllIlIlllIIIllII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIlllIIIlIlI[lIlllIlIIIllII[2]], aq.class.getClassLoader());
        if (lllllIIlllIIllI(lllllllllllllllIlllIlIlllIIIIllI, lIlllIlIIIllII[2])) {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findVirtual(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIllII);
          "".length();
          if ("   ".length() > "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findStatic(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIllII);
        } 
        "".length();
        if (-"  ".length() > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIlllIIIlIll = lIlllIIIlIIlll[Integer.parseInt(lllllllllllllllIlllIlIlllIIIlIlI[lIlllIlIIIllII[2]])];
        if (lllllIIlllIIllI(lllllllllllllllIlllIlIlllIIIIllI, lIlllIlIIIllII[3])) {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findGetter(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIlIll);
          "".length();
          if (((52 + 117 - 144 + 228 ^ (0xED ^ 0xB4) << " ".length()) & (171 + 84 - 250 + 236 ^ (0x50 ^ 0xF) << " ".length() ^ -" ".length())) != (((0x16 ^ 0x11) << " ".length() << " ".length() ^ 0x2F ^ 0x60) & (0xED ^ 0xA2 ^ (0xBA ^ 0xBD) << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else if (lllllIIlllIIllI(lllllllllllllllIlllIlIlllIIIIllI, lIlllIlIIIllII[4])) {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findStaticGetter(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIlIll);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIIlllIIllI(lllllllllllllllIlllIlIlllIIIIllI, lIlllIlIIIllII[5])) {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findSetter(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIlIll);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIlllIIIIlll = lllllllllllllllIlllIlIlllIIIIlII.findStaticSetter(lllllllllllllllIlllIlIlllIIIlIIl, lllllllllllllllIlllIlIlllIIIlIII, lllllllllllllllIlllIlIlllIIIlIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIlllIIIIlll);
    } catch (Exception lllllllllllllllIlllIlIlllIIIIlIl) {
      lllllllllllllllIlllIlIlllIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIllIlIIll() {
    lIlllIIIlIIllI = new String[lIlllIlIIIllII[14]];
    lIlllIIIlIIllI[lIlllIlIIIllII[15]] = lIlllIlIIIlIlI[lIlllIlIIIllII[16]];
    lIlllIIIlIIllI[lIlllIlIIIllII[17]] = lIlllIlIIIlIlI[lIlllIlIIIllII[18]];
    lIlllIIIlIIllI[lIlllIlIIIllII[19]] = lIlllIlIIIlIlI[lIlllIlIIIllII[20]];
    lIlllIIIlIIllI[lIlllIlIIIllII[21]] = lIlllIlIIIlIlI[lIlllIlIIIllII[22]];
    lIlllIIIlIIllI[lIlllIlIIIllII[0]] = lIlllIlIIIlIlI[lIlllIlIIIllII[23]];
    lIlllIIIlIIllI[lIlllIlIIIllII[8]] = lIlllIlIIIlIlI[lIlllIlIIIllII[24]];
    lIlllIIIlIIllI[lIlllIlIIIllII[25]] = lIlllIlIIIlIlI[lIlllIlIIIllII[26]];
    lIlllIIIlIIllI[lIlllIlIIIllII[27]] = lIlllIlIIIlIlI[lIlllIlIIIllII[28]];
    lIlllIIIlIIllI[lIlllIlIIIllII[29]] = lIlllIlIIIlIlI[lIlllIlIIIllII[30]];
    lIlllIIIlIIllI[lIlllIlIIIllII[31]] = lIlllIlIIIlIlI[lIlllIlIIIllII[32]];
    lIlllIIIlIIllI[lIlllIlIIIllII[33]] = lIlllIlIIIlIlI[lIlllIlIIIllII[34]];
    lIlllIIIlIIllI[lIlllIlIIIllII[11]] = lIlllIlIIIlIlI[lIlllIlIIIllII[35]];
    lIlllIIIlIIllI[lIlllIlIIIllII[36]] = lIlllIlIIIlIlI[lIlllIlIIIllII[37]];
    lIlllIIIlIIllI[lIlllIlIIIllII[38]] = lIlllIlIIIlIlI[lIlllIlIIIllII[39]];
    lIlllIIIlIIllI[lIlllIlIIIllII[40]] = lIlllIlIIIlIlI[lIlllIlIIIllII[27]];
    lIlllIIIlIIllI[lIlllIlIIIllII[41]] = lIlllIlIIIlIlI[lIlllIlIIIllII[42]];
    lIlllIIIlIIllI[lIlllIlIIIllII[43]] = lIlllIlIIIlIlI[lIlllIlIIIllII[44]];
    lIlllIIIlIIllI[lIlllIlIIIllII[45]] = lIlllIlIIIlIlI[lIlllIlIIIllII[46]];
    lIlllIIIlIIllI[lIlllIlIIIllII[47]] = lIlllIlIIIlIlI[lIlllIlIIIllII[31]];
    lIlllIIIlIIllI[lIlllIlIIIllII[32]] = lIlllIlIIIlIlI[lIlllIlIIIllII[48]];
    lIlllIIIlIIllI[lIlllIlIIIllII[20]] = lIlllIlIIIlIlI[lIlllIlIIIllII[33]];
    lIlllIIIlIIllI[lIlllIlIIIllII[48]] = lIlllIlIIIlIlI[lIlllIlIIIllII[49]];
    lIlllIIIlIIllI[lIlllIlIIIllII[26]] = lIlllIlIIIlIlI[lIlllIlIIIllII[50]];
    lIlllIIIlIIllI[lIlllIlIIIllII[51]] = lIlllIlIIIlIlI[lIlllIlIIIllII[52]];
    lIlllIIIlIIllI[lIlllIlIIIllII[53]] = lIlllIlIIIlIlI[lIlllIlIIIllII[51]];
    lIlllIIIlIIllI[lIlllIlIIIllII[34]] = lIlllIlIIIlIlI[lIlllIlIIIllII[54]];
    lIlllIIIlIIllI[lIlllIlIIIllII[28]] = lIlllIlIIIlIlI[lIlllIlIIIllII[43]];
    lIlllIIIlIIllI[lIlllIlIIIllII[2]] = lIlllIlIIIlIlI[lIlllIlIIIllII[38]];
    lIlllIIIlIIllI[lIlllIlIIIllII[55]] = lIlllIlIIIlIlI[lIlllIlIIIllII[56]];
    lIlllIIIlIIllI[lIlllIlIIIllII[57]] = lIlllIlIIIlIlI[lIlllIlIIIllII[40]];
    lIlllIIIlIIllI[lIlllIlIIIllII[58]] = lIlllIlIIIlIlI[lIlllIlIIIllII[59]];
    lIlllIIIlIIllI[lIlllIlIIIllII[54]] = lIlllIlIIIlIlI[lIlllIlIIIllII[15]];
    lIlllIIIlIIllI[lIlllIlIIIllII[60]] = lIlllIlIIIlIlI[lIlllIlIIIllII[61]];
    lIlllIIIlIIllI[lIlllIlIIIllII[7]] = lIlllIlIIIlIlI[lIlllIlIIIllII[29]];
    lIlllIIIlIIllI[lIlllIlIIIllII[13]] = lIlllIlIIIlIlI[lIlllIlIIIllII[55]];
    lIlllIIIlIIllI[lIlllIlIIIllII[62]] = lIlllIlIIIlIlI[lIlllIlIIIllII[58]];
    lIlllIIIlIIllI[lIlllIlIIIllII[46]] = lIlllIlIIIlIlI[lIlllIlIIIllII[63]];
    lIlllIIIlIIllI[lIlllIlIIIllII[64]] = lIlllIlIIIlIlI[lIlllIlIIIllII[65]];
    lIlllIIIlIIllI[lIlllIlIIIllII[50]] = lIlllIlIIIlIlI[lIlllIlIIIllII[66]];
    lIlllIIIlIIllI[lIlllIlIIIllII[67]] = lIlllIlIIIlIlI[lIlllIlIIIllII[62]];
    lIlllIIIlIIllI[lIlllIlIIIllII[5]] = lIlllIlIIIlIlI[lIlllIlIIIllII[68]];
    lIlllIIIlIIllI[lIlllIlIIIllII[44]] = lIlllIlIIIlIlI[lIlllIlIIIllII[57]];
    lIlllIIIlIIllI[lIlllIlIIIllII[52]] = lIlllIlIIIlIlI[lIlllIlIIIllII[67]];
    lIlllIIIlIIllI[lIlllIlIIIllII[59]] = lIlllIlIIIlIlI[lIlllIlIIIllII[47]];
    lIlllIIIlIIllI[lIlllIlIIIllII[39]] = lIlllIlIIIlIlI[lIlllIlIIIllII[69]];
    lIlllIIIlIIllI[lIlllIlIIIllII[42]] = lIlllIlIIIlIlI[lIlllIlIIIllII[17]];
    lIlllIIIlIIllI[lIlllIlIIIllII[35]] = lIlllIlIIIlIlI[lIlllIlIIIllII[41]];
    lIlllIIIlIIllI[lIlllIlIIIllII[49]] = lIlllIlIIIlIlI[lIlllIlIIIllII[25]];
    lIlllIIIlIIllI[lIlllIlIIIllII[12]] = lIlllIlIIIlIlI[lIlllIlIIIllII[70]];
    lIlllIIIlIIllI[lIlllIlIIIllII[68]] = lIlllIlIIIlIlI[lIlllIlIIIllII[71]];
    lIlllIIIlIIllI[lIlllIlIIIllII[56]] = lIlllIlIIIlIlI[lIlllIlIIIllII[19]];
    lIlllIIIlIIllI[lIlllIlIIIllII[4]] = lIlllIlIIIlIlI[lIlllIlIIIllII[36]];
    lIlllIIIlIIllI[lIlllIlIIIllII[71]] = lIlllIlIIIlIlI[lIlllIlIIIllII[45]];
    lIlllIIIlIIllI[lIlllIlIIIllII[30]] = lIlllIlIIIlIlI[lIlllIlIIIllII[72]];
    lIlllIIIlIIllI[lIlllIlIIIllII[70]] = lIlllIlIIIlIlI[lIlllIlIIIllII[73]];
    lIlllIIIlIIllI[lIlllIlIIIllII[18]] = lIlllIlIIIlIlI[lIlllIlIIIllII[60]];
    lIlllIIIlIIllI[lIlllIlIIIllII[66]] = lIlllIlIIIlIlI[lIlllIlIIIllII[74]];
    lIlllIIIlIIllI[lIlllIlIIIllII[61]] = lIlllIlIIIlIlI[lIlllIlIIIllII[64]];
    lIlllIIIlIIllI[lIlllIlIIIllII[24]] = lIlllIlIIIlIlI[lIlllIlIIIllII[53]];
    lIlllIIIlIIllI[lIlllIlIIIllII[72]] = lIlllIlIIIlIlI[lIlllIlIIIllII[21]];
    lIlllIIIlIIllI[lIlllIlIIIllII[73]] = lIlllIlIIIlIlI[lIlllIlIIIllII[14]];
    lIlllIIIlIIllI[lIlllIlIIIllII[1]] = lIlllIlIIIlIlI[lIlllIlIIIllII[75]];
    lIlllIIIlIIllI[lIlllIlIIIllII[37]] = lIlllIlIIIlIlI[lIlllIlIIIllII[76]];
    lIlllIIIlIIllI[lIlllIlIIIllII[6]] = lIlllIlIIIlIlI[lIlllIlIIIllII[77]];
    lIlllIIIlIIllI[lIlllIlIIIllII[74]] = lIlllIlIIIlIlI[lIlllIlIIIllII[78]];
    lIlllIIIlIIllI[lIlllIlIIIllII[69]] = lIlllIlIIIlIlI[lIlllIlIIIllII[79]];
    lIlllIIIlIIllI[lIlllIlIIIllII[65]] = lIlllIlIIIlIlI[lIlllIlIIIllII[80]];
    lIlllIIIlIIllI[lIlllIlIIIllII[23]] = lIlllIlIIIlIlI[lIlllIlIIIllII[81]];
    lIlllIIIlIIllI[lIlllIlIIIllII[22]] = lIlllIlIIIlIlI[lIlllIlIIIllII[82]];
    lIlllIIIlIIllI[lIlllIlIIIllII[16]] = lIlllIlIIIlIlI[lIlllIlIIIllII[83]];
    lIlllIIIlIIllI[lIlllIlIIIllII[9]] = lIlllIlIIIlIlI[lIlllIlIIIllII[84]];
    lIlllIIIlIIllI[lIlllIlIIIllII[3]] = lIlllIlIIIlIlI[lIlllIlIIIllII[85]];
    lIlllIIIlIIllI[lIlllIlIIIllII[63]] = lIlllIlIIIlIlI[lIlllIlIIIllII[86]];
    lIlllIIIlIIlll = new Class[lIlllIlIIIllII[22]];
    lIlllIIIlIIlll[lIlllIlIIIllII[8]] = double.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[4]] = f100000000000000000000.Integer.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[18]] = WorldClient.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[3]] = f100000000000000000000.Boolean.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[0]] = f13.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[1]] = Listener.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[2]] = f100000000000000000000.Double.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[16]] = Potion.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[7]] = int.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[5]] = boolean.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[11]] = EntityPlayerSP.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[6]] = Timer.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[12]] = float.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[9]] = Minecraft.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[20]] = MovementInput.class;
    lIlllIIIlIIlll[lIlllIlIIIllII[13]] = int[].class;
  }
  
  private static void lllllIIllIlIlll() {
    lIlllIlIIIlIlI = new String[lIlllIlIIIllII[87]];
    lIlllIlIIIlIlI[lIlllIlIIIllII[0]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[0]], lIlllIlIIIlIll[lIlllIlIIIllII[1]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[1]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[2]], lIlllIlIIIlIll[lIlllIlIIIllII[3]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[2]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[4]], lIlllIlIIIlIll[lIlllIlIIIllII[5]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[3]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[7]], lIlllIlIIIlIll[lIlllIlIIIllII[8]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[4]] = lllllIIllIlIlIl(lIlllIlIIIlIll[lIlllIlIIIllII[9]], lIlllIlIIIlIll[lIlllIlIIIllII[11]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[5]] = lllllIIllIlIllI(lIlllIlIIIlIll[lIlllIlIIIllII[6]], lIlllIlIIIlIll[lIlllIlIIIllII[12]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[7]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[13]], lIlllIlIIIlIll[lIlllIlIIIllII[16]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[8]] = lllllIIllIlIlIl(lIlllIlIIIlIll[lIlllIlIIIllII[18]], lIlllIlIIIlIll[lIlllIlIIIllII[20]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[9]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[22]], lIlllIlIIIlIll[lIlllIlIIIllII[23]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[11]] = lllllIIllIlIllI(lIlllIlIIIlIll[lIlllIlIIIllII[24]], lIlllIlIIIlIll[lIlllIlIIIllII[26]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[6]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[28]], lIlllIlIIIlIll[lIlllIlIIIllII[30]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[12]] = lllllIIllIlIlIl(lIlllIlIIIlIll[lIlllIlIIIllII[32]], lIlllIlIIIlIll[lIlllIlIIIllII[34]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[13]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[35]], lIlllIlIIIlIll[lIlllIlIIIllII[37]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[16]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[39]], lIlllIlIIIlIll[lIlllIlIIIllII[27]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[18]] = lllllIIllIlIlII(lIlllIlIIIlIll[lIlllIlIIIllII[42]], lIlllIlIIIlIll[lIlllIlIIIllII[44]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[20]] = lllllIIllIlIlIl(lIlllIlIIIlIll[lIlllIlIIIllII[46]], lIlllIlIIIlIll[lIlllIlIIIllII[31]]);
    lIlllIlIIIlIlI[lIlllIlIIIllII[22]] = lllllIIllIlIllI("rlvNELOvRk2Z9ayCrT5iKxwrzBIC0xR2Dks4WTQ+G5k=", "exdXf");
    lIlllIlIIIlIlI[lIlllIlIIIllII[23]] = lllllIIllIlIlIl("EoHHXEOrjfqJW+zzIdiZGKU3WNzvBbQQXkxyJDy3FieMH/zPXpl85g==", "PawgE");
    lIlllIlIIIlIlI[lIlllIlIIIllII[24]] = lllllIIllIlIlII("BS1AGjIdOAcdIgcvQAsuGGYPGHwbOAsMIiwtGgwlHHJdU2ZIaE5J", "hHniF");
    lIlllIlIIIlIlI[lIlllIlIIIllII[26]] = lllllIIllIlIllI("wK0ZKC9y9FUnbzCzyCS+dRBO/61QPEsrkL2xJ+DmGOO8vkHPEEn5LJMWPkPFw3/Rn8ACA/34a/lXiAzuu7Fo+w==", "FWlqk");
    lIlllIlIIIlIlI[lIlllIlIIIllII[28]] = lllllIIllIlIlII("IjxJCjo6KQ4NKiA+SRsmP3cBSH5/aVdJfn9pV0l+f2lXSX5/aVdJagY3ExwpKitdHis7DwYVOypjT1AHdXlH", "OYgyN");
    lIlllIlIIIlIlI[lIlllIlIIIllII[30]] = lllllIIllIlIllI("w7vvlaN6a0qkYPkq5Z0KCcwFA9r9q7twkuDP9xhsw3XRwFNOLVah7YZNgYfv2BNlRQpdEkB3bwPLcbThZFSuQ/LRyqNQu4kJ", "sAUSp");
    lIlllIlIIIlIlI[lIlllIlIIIllII[32]] = lllllIIllIlIlIl("L8BRsKxA5krOnr2jTybEfvJvd+y6ILbOX3e2Y90Tp4p9UFNcjb/LFw==", "xWzOe");
    lIlllIlIIIlIlI[lIlllIlIIIllII[34]] = lllllIIllIlIlII("Gx1NKQQDCAouFBkfTTgYBlYCK0obDQ8uGQYUCj8CTEpZelBW", "vxcZp");
    lIlllIlIIIlIlI[lIlllIlIIIllII[35]] = lllllIIllIlIllI("B3bk+9Rv6+aFw9ZGiGvDOV3sbhoKCsYAiHZ68QJvJVn+mUEh37g1Ng==", "tCVPw");
    lIlllIlIIIlIlI[lIlllIlIIIllII[37]] = lllllIIllIlIllI("zLCg5HISy0z9LkkZTCnDuOWjoCMFr0Xi4/9Xop8bwUWC/+lLoiINRIpu2bK1Zd47yNcepZiCv/M=", "YVbNi");
    lIlllIlIIIlIlI[lIlllIlIIIllII[39]] = lllllIIllIlIlII("DQsFYBQKABQtCwIIBWAJDBoYIRdNPh46EAwANCgfBg0FdB8WABIRTlVaRHYmAFRZZzBZTlE=", "cnqNy");
    lIlllIlIIIlIlI[lIlllIlIIIllII[27]] = lllllIIllIlIlII("PTR9GyclITocNz82fQo7IH8yGWk1KScaMglrYVJzcHE=", "PQShS");
    lIlllIlIIIlIlI[lIlllIlIIIllII[42]] = lllllIIllIlIlII("HRB5BTYFBT4CJh8SeRQqAFs2B3gcPB4aCxw8Hj94WDx+LHhQ", "puWvB");
    lIlllIlIIIlIlI[lIlllIlIIIllII[44]] = lllllIIllIlIlIl("G7y6CxVfPcTfxOuplO0+4AIWieim3Kpr/kIRZ8zfXIYLDFafTRCFPccsLWl4905NMoT0WeiTQ55wDkumuj7LlXkXMrli4ytU/yU7izMTiXY=", "BWvpi");
    lIlllIlIIIlIlI[lIlllIlIIIllII[46]] = lllllIIllIlIlII("JwYOTQkgDR8AFigFDk0RPQoWTSkmFR8OAScXMw0UPBdABQ0sDx48U3FaSlE7KFlLUl5pQ1o=", "Iczcd");
    lIlllIlIIIlIlI[lIlllIlIIIllII[31]] = lllllIIllIlIllI("z36iJjREl5F2VAp9X78iCkRH+8aSznyzN6J/oRmy+EPacWL7Y9BYlNw5rQQg9yLwI1vlj7lmtE6UEoYq/gbUGWusjV8SFLno4cOyNItYT/P3bKJ5x2i+jer++SA9dFytJo4mtHv1tiw=", "QOYfk");
    lIlllIlIIIlIlI[lIlllIlIIIllII[48]] = lllllIIllIlIlII("NSh/IRktPTgmCTcqfzAFKGMwI1c5LjI3AT0/MCYENyMFOwA9P2thV3htcQ==", "XMQRm");
    lIlllIlIIIlIlI[lIlllIlIIIllII[33]] = lllllIIllIlIlIl("++6qn21GqsvvzPlxKdm42WGDytuKQ65gzZ/7DQj6opgSLsznuJX93rTYP8zSMhIix8a4KtWX8Kc=", "sHeTc");
    lIlllIlIIIlIlI[lIlllIlIIIllII[49]] = lllllIIllIlIlII("AgcjCGQEBzsOZDsSJwAkD1w5DCQPEj1TYkEvb0lq", "hfUiJ");
    lIlllIlIIIlIlI[lIlllIlIIIllII[50]] = lllllIIllIlIlII("FzE3ajkQOiYnJhgyN2o3FT0mKiBXMS0wPQ0tbQE6DT03PQQVNTohJioEeSI9HDgnG2NJZXVyCwpudH50WXQ=", "yTCDT");
    lIlllIlIIIlIlI[lIlllIlIIIllII[52]] = lllllIIllIlIlIl("t5FHEo0nJ7n++UTHPcFYozbMhfrlvTKMvbYDV1PURg7d/9uCK+basg==", "qAPmP");
    lIlllIlIIIlIlI[lIlllIlIIIllII[51]] = lllllIIllIlIllI("e1pfPxmhZoox1qaYz3E4jKbQFq5UUEczrWYawamhbiw=", "IyGrl");
    lIlllIlIIIlIlI[lIlllIlIIIllII[54]] = lllllIIllIlIllI("XCfA0+q32M7ZWh6b1tdPDVIF/SszZX4YWi6dpKwDv6PnOYSSq7NaMDWZU1Bncb1M0m+EtdSKv+0weuG6eHMwmQ==", "epXRK");
    lIlllIlIIIlIlI[lIlllIlIIIllII[43]] = lllllIIllIlIlII("GTsXFUIfOw8TQj47FRxWACsTAFZbHkgwVlM=", "sZatl");
    lIlllIlIIIlIlI[lIlllIlIIIllII[38]] = lllllIIllIlIlII("OxZFKjgjAwItKDkURTskJl0KKHY7BgctJSYfAjw+bEFReWx2U0s=", "VskYL");
    lIlllIlIIIlIlI[lIlllIlIIIllII[56]] = lllllIIllIlIlIl("pKxALnDxd+stuWDRxdWnXtm6wy3PHPI5I6AHfCM7mhkLwJj2Fs3rZI5hYF3KnKiO3Qvcpxbr+KgPs9DE2iT/gw==", "xgSCB");
    lIlllIlIIIlIlI[lIlllIlIIIllII[40]] = lllllIIllIlIlII("KhMtXwQtGDwSGyUQLV8KKB88Hx1qEzcFADAPdzQHMB8tCDkoFyAUGxcmYxccKhUGQF5wTmhCNiUnY1lACBg8BUYpHzcUCjYXPwVGMQIwHUYpFy0ZRgUOMAIoKB8+HwwgNBtKU2RW", "DvYqi");
    lIlllIlIIIlIlI[lIlllIlIIIllII[59]] = lllllIIllIlIlIl("/Uu3CcOGtFnYZUDb19XTMmuEnX72jziGbYf88boUnNJ3brg/cARbkp6apVflAe1SGBXSIgZnnFU=", "DAcDi");
    lIlllIlIIIlIlI[lIlllIlIIIllII[15]] = lllllIIllIlIlIl("EVD4tA6/Kvj/k1WT+A/PbVTgde+oneLAUlHZRvOImW0kdDWkLqgd3rwUMcONHz4HycgN2VyjDEjhb+mgGJdGUvN3xZcRQNcz/KIcEYeJiVGisWCiwDEQfvAD5t7Z850qpaXafSzC0aEIzdN6jGfwk9NpcuMQ+ATLMFXG5us5I2I=", "Ssqed");
    lIlllIlIIIlIlI[lIlllIlIIIllII[61]] = lllllIIllIlIlIl("bjjPuiB2EcJfRNdaW/sq4u8NFPENha49BR3MCtZFSKfJHKwasl4WbmXrbeXVC+md", "bNiHa");
    lIlllIlIIIlIlI[lIlllIlIIIllII[29]] = lllllIIllIlIlII("KihUKjYyPRMtJigqVDsqN2MbKHgzJBc8MBQ9HzwmfXlAeWJnbVo=", "GMzYB");
    lIlllIlIIIlIlI[lIlllIlIIIllII[55]] = lllllIIllIlIlIl("Y2hdmFviUdJzYWqIA/m9DvAduv09jAFGfKTmrvUe/8JEJ0RW5K8Gh9Vg2yXRe5mC", "zPsOw");
    lIlllIlIIIlIlI[lIlllIlIIIllII[58]] = lllllIIllIlIlII("NyNMJxIvNgsgAjUhTDYOKmgDJVwqNAciIjM1Fm5RYGZCdA==", "ZFbTf");
    lIlllIlIIIlIlI[lIlllIlIIIllII[63]] = lllllIIllIlIllI("MDBySU7EP0WGPv348iOKyFqtAmHXu3Rfx5UxpT52RrTNy0MVxWZQ6g==", "tiPUK");
    lIlllIlIIIlIlI[lIlllIlIIIllII[65]] = lllllIIllIlIllI("xZxELopHXAfH1PDX8/BUJZmoXOjxuBwuMl8rrehyqF4=", "CiycX");
    lIlllIlIIIlIlI[lIlllIlIIIllII[66]] = lllllIIllIlIlII("JRwbdhgiFwo7ByofG3YcJRAbdjgkGyo+Ey4aGytPLRAKNBEUTllsR38mDGJEeENPeFVr", "KyoXu");
    lIlllIlIIIlIlI[lIlllIlIIIllII[62]] = lllllIIllIlIlIl("rpJASeCS3qLCvJsKAf+eRnbMa+yLbsxFQtAiZedEB9bdrR6HtDjS/zybH+MSIbKOqb2wOweBakesf/agchz9YA==", "QBqZE");
    lIlllIlIIIlIlI[lIlllIlIIIllII[68]] = lllllIIllIlIlII("LyZtFhY3MyoRBi0kbQcKMm0iFFgwJiQMETYmMSwMNiYkABB4aw8PAzQibAkDLCRsNhYwKi0CWQsKCkwuLyZsFhY3MyoRBi0kbAcKMmwlVFJyc3NVUnJzc1VScnNzVVJyc3NVRgstNwAFJzF4X0Ji", "BCCeb");
    lIlllIlIIIlIlI[lIlllIlIIIllII[57]] = lllllIIllIlIlII("LD1KECc0KA0XNy4/SgE7MXYFEmktES0PGggRLQ9paR4iShp7eA==", "AXdcS");
    lIlllIlIIIlIlI[lIlllIlIIIllII[67]] = lllllIIllIlIlII("LzEfVycoOg4aOCAyH1cpLT0OFz5vMQUNIzUtRTwkNT0fABotNRIcOBIEUR8/Lzc0Tnp3YF8mK3t8JxcvNXsGECQkNxkYLDV7GxY+KDsFVhouIAIWJHp9MUNqYQ==", "ATkyJ");
    lIlllIlIIIlIlI[lIlllIlIIIllII[47]] = lllllIIllIlIlII("KzUcQQUsPg0MGiQ2HEELKTkNARxrNQYbATEpRioGMTkcFjgpMREKGhYAUgkBIDwMMFl8YVFXUBoyD1VZdGpIT0g=", "EPhoh");
    lIlllIlIIIlIlI[lIlllIlIIIllII[69]] = lllllIIllIlIllI("7hntA2NX4fCmfgSljFB7uQwZCVUmmEA1bhXkskQLspolIsYApST+Aw==", "uyKKl");
    lIlllIlIIIlIlI[lIlllIlIIIllII[17]] = lllllIIllIlIlII("PSw5YRs6JygsBDIvOWEDJyAhYSI6JCg9TDUgKCMSDHh0e0dncBIqTGJ4d29Wcw==", "SIMOv");
    lIlllIlIIIlIlI[lIlllIlIIIllII[41]] = lllllIIllIlIllI("VJU3U70L9F7mLEL+0LKuvwU3r3GZzy4lXLcZqVuRTa8o91wtSB6hTQ==", "SBbtn");
    lIlllIlIIIlIlI[lIlllIlIIIllII[25]] = lllllIIllIlIllI("1FnNhD8ewcpVfHZyVKucId9X1vFf1OkdioicM1IKq7mCbuOwt/9U4Q/ckfYXnrIoyH5M2aYoxjT7ONyxQ5ckkg==", "FkdVZ");
    lIlllIlIIIlIlI[lIlllIlIIIllII[70]] = lllllIIllIlIlIl("/mgzRxkZtgyElvJHkG7kJuQ254echrJ2OJpeoHQspE1FKvkhRSCwWw==", "xiYHs");
    lIlllIlIIIlIlI[lIlllIlIIIllII[71]] = lllllIIllIlIlIl("O31+QgBm60TmIC+N44AYvYDkeM0hY0S4K11UCceF+tYTb8VEvP2FvhPG4pGs6qFDaWxmwktlrXk=", "umegN");
    lIlllIlIIIlIlI[lIlllIlIIIllII[19]] = lllllIIllIlIlIl("5/plrXAJiJCzYgbCOh3c5W4lHig3UhBroIFF+hSM0DsfJ3IVdUEIoQ==", "vKFKG");
    lIlllIlIIIlIlI[lIlllIlIIIllII[36]] = lllllIIllIlIlIl("UGOhBSHXaaYwv+QRjFt9mH1ZMg88dUo6H8yIiLg/bLfo+DIRGvd6JxZMLn5eM0PO", "saHoP");
    lIlllIlIIIlIlI[lIlllIlIIIllII[45]] = lllllIIllIlIlII("LDkyK30qOSotfQs5MCJpKzk8cHsCHG0OaWY=", "FXDJS");
    lIlllIlIIIlIlI[lIlllIlIIIllII[72]] = lllllIIllIlIlII("GxJBBzoDBwYAKhkQQRYmBlkOBXQGBQoCCh8EG055TFdPVG5W", "vwotN");
    lIlllIlIIIlIlI[lIlllIlIIIllII[73]] = lllllIIllIlIlII("BhBEJTYeBQMiJgQSRDQqG1sLJ3gHPCM6Cwc8Izp4QzxDDHhL", "kujVB");
    lIlllIlIIIlIlI[lIlllIlIIIllII[60]] = lllllIIllIlIllI("Yxh8ZNnIUMZSwiQQWnDjstggtuHjEI8sQWEVt0Rxapo=", "ZMHFq");
    lIlllIlIIIlIlI[lIlllIlIIIllII[74]] = lllllIIllIlIllI("QSOwEv54YSSZ26atA8v7ITuAu5nSWpRhU6nsu6JRnYMoCab6hS0iUg==", "bKLVd");
    lIlllIlIIIlIlI[lIlllIlIIIllII[64]] = lllllIIllIlIlII("FytrNwwPPiwwHBUpayYQCmAkNUIWBwwoMTMiDChCUgdsHkJa", "zNEDx");
    lIlllIlIIIlIlI[lIlllIlIIIllII[53]] = lllllIIllIlIlIl("qegKZi3plmp9OOxzHhsEMcG5g9jXzEHJieeXO3/Myw28lGuuDx8o4chDleukEAQ5skIoQA2C9884Vja8qrt2jQ==", "qADxC");
    lIlllIlIIIlIlI[lIlllIlIIIllII[21]] = lllllIIllIlIlII("AgQxQSgFDyAMNw0HMUEmAAggATFCBCsbLBgYayorGAgxFhUAADwKNz8xfwksCQ0hMHJcUHJYGhZbdF5/TEFl", "laEoE");
    lIlllIlIIIlIlI[lIlllIlIIIllII[14]] = lllllIIllIlIllI("ZrYovfc6kroY5a00sJ8CXh5WtCbWYO9RFGbFI4iSaqlgW/kbGjZTHA==", "Wsofn");
    lIlllIlIIIlIlI[lIlllIlIIIllII[75]] = lllllIIllIlIlII("OCp3Ij0gPzAlLToodzMhJWE4IHMnKj44OiEqKxUmIC01NHN9AzMwPzRgNTAnMmAKJTs8IT5qDRELcB0kMGAqJTwlJi01JjJgOzk5eiloYXllf2lheWV/aWF5ZX9pYXllf2l1DTo6Oz0sbnV5cQ==", "UOYQI");
    lIlllIlIIIlIlI[lIlllIlIIIllII[76]] = lllllIIllIlIlIl("3rExjHR75KQLb7w7BfiKbU3v2F3FZhilxfLKfjSJ8LdC4vuYRN1Ce039Wz8rK6kBuzWJ3fvP3+A=", "nTBQE");
    lIlllIlIIIlIlI[lIlllIlIIIllII[77]] = lllllIIllIlIllI("/MbqmJPJ8dhrGGSbX5MagYTr/tw6j1dZnQDEh4gBbvA4lcCAFIGOeQ==", "aLFcU");
    lIlllIlIIIlIlI[lIlllIlIIIllII[78]] = lllllIIllIlIlII("HxBiIR4HBSUmDh0SYjACAlsqY1pCRXxiWkJFfGJaQkV2IQ8GL3Z6LlsjdnJK", "ruLRj");
    lIlllIlIIIlIlI[lIlllIlIIIllII[79]] = lllllIIllIlIlIl("X0jZouzH95T9tebcaK6R6jpeS6mmh8cyKMAu6WWYHrLvBgk3vjYcKOjAqD5fN/Qt7Qe2cSLSNAn9b29jYkFn4Id/pr1jUBcoWICCPX4ot7VMQqQxejdm9mbGWxU3ytEYBtgA3k6x2ZxUkVp1tFL3rqybiGvK2y6+51+CHqZinv0yGbv480HLulPMEYF9Hsnp09qTwr4ZXow=", "aFADP");
    lIlllIlIIIlIlI[lIlllIlIIIllII[80]] = lllllIIllIlIllI("g/O13mzOXX9u5WIR5i5lXreVIgeIdlTtaRkaUHxsY8a/pPiqFgij0f7q58cA7enH", "Tvebm");
    lIlllIlIIIlIlI[lIlllIlIIIllII[81]] = lllllIIllIlIllI("m/m80MkEjxZ35p/nCGND1BnbfOnA8AYD+zjjDzoDDhtpJW5n7dys/Z+q+nk2Hl0FqY4TpP5VZWrqWzYZSFqxkg==", "NKvTc");
    lIlllIlIIIlIlI[lIlllIlIIIllII[82]] = lllllIIllIlIlIl("zm3isv6WpiFXQ2OpssuHlLzxpQRQkivo1tYAz/BrnNxY0H0+jlFmXYoNrYgNTmg9LMJb+i4DVEhFl/NJRzKeMw==", "FpAiB");
    lIlllIlIIIlIlI[lIlllIlIIIllII[83]] = lllllIIllIlIllI("MEZ58ShLwXdqDtbUzrDHI3jUqNXMYJA2k/w/i/57pFKKID4CutvD7Q==", "iGdiN");
    lIlllIlIIIlIlI[lIlllIlIIIllII[84]] = lllllIIllIlIlIl("VgDSYhzVIPxEKC5eKSA9XijjG4cyBGokQwUGSXfRFFF0umEmAm1pbw==", "uVYUO");
    lIlllIlIIIlIlI[lIlllIlIIIllII[85]] = lllllIIllIlIlII("Ogh8PgYiHTs5FjgKfC8aJ0MzPEglCDUkASMIIA8dOAE3LBxtRR4nEyEMfSETOQp9HgYlBDwqSQ1EHiAXeB4mOAI+GTYiFXgPOj1dMVxifUJnXWJ9QmddYn1CZ11ifUJnXXYPHTgBNywcbFdybQ==", "WmRMr");
    lIlllIlIIIlIlI[lIlllIlIIIllII[86]] = lllllIIllIlIllI("zyPGPB3K9mWs6ChZnVXveE1DwGLHRWGcuFhOl48x9Xuyrc32AfTUhw==", "hJeHt");
    lIlllIlIIIlIll = null;
  }
  
  private static void lllllIIllIllIII() {
    String str = (new Exception()).getStackTrace()[lIlllIlIIIllII[0]].getFileName();
    lIlllIlIIIlIll = str.substring(str.indexOf("ä") + lIlllIlIIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIllIlIlIl(String lllllllllllllllIlllIlIllIllllllI, String lllllllllllllllIlllIlIllIlllllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlllIIIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIlllllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIlllIIIIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIlllIIIIIII.init(lIlllIlIIIllII[2], lllllllllllllllIlllIlIlllIIIIIIl);
      return new String(lllllllllllllllIlllIlIlllIIIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIllllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIlllllll) {
      lllllllllllllllIlllIlIllIlllllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIllIlIllI(String lllllllllllllllIlllIlIllIllllIIl, String lllllllllllllllIlllIlIllIllllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIllIlllllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIllllIII.getBytes(StandardCharsets.UTF_8)), lIlllIlIIIllII[9]), "DES");
      Cipher lllllllllllllllIlllIlIllIllllIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIllIllllIll.init(lIlllIlIIIllII[2], lllllllllllllllIlllIlIllIlllllII);
      return new String(lllllllllllllllIlllIlIllIllllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIllllIlI) {
      lllllllllllllllIlllIlIllIllllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIllIlIlII(String lllllllllllllllIlllIlIllIlllIllI, String lllllllllllllllIlllIlIllIlllIlIl) {
    lllllllllllllllIlllIlIllIlllIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIlllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIllIlllIlII = new StringBuilder();
    char[] lllllllllllllllIlllIlIllIlllIIll = lllllllllllllllIlllIlIllIlllIlIl.toCharArray();
    int lllllllllllllllIlllIlIllIlllIIlI = lIlllIlIIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIllIlllIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIIIllII[0];
    while (lllllIIlllIIlll(j, i)) {
      char lllllllllllllllIlllIlIllIlllIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIllIlllIIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIllIlllIlII);
  }
  
  private static void lllllIIllIllIIl() {
    lIlllIlIIIllII = new int[88];
    lIlllIlIIIllII[0] = "   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ -" ".length());
    lIlllIlIIIllII[1] = " ".length();
    lIlllIlIIIllII[2] = " ".length() << " ".length();
    lIlllIlIIIllII[3] = "   ".length();
    lIlllIlIIIllII[4] = " ".length() << " ".length() << " ".length();
    lIlllIlIIIllII[5] = 0x6 ^ 0x23 ^ " ".length() << (0x61 ^ 0x64);
    lIlllIlIIIllII[6] = (0x28 ^ 0x61 ^ (0x7C ^ 0x6F) << " ".length() << " ".length()) << " ".length();
    lIlllIlIIIllII[7] = "   ".length() << " ".length();
    lIlllIlIIIllII[8] = 74 + 24 - -17 + 12 ^ (0xA9 ^ 0xA6) << "   ".length();
    lIlllIlIIIllII[9] = " ".length() << "   ".length();
    lIlllIlIIIllII[10] = -" ".length();
    lIlllIlIIIllII[11] = 0x1E ^ 0x17;
    lIlllIlIIIllII[12] = 0x14 ^ 0x1F;
    lIlllIlIIIllII[13] = "   ".length() << " ".length() << " ".length();
    lIlllIlIIIllII[14] = 0xEF ^ 0xA6;
    lIlllIlIIIllII[15] = (" ".length() << " ".length() ^ 0x96 ^ 0x9F) << " ".length() << " ".length();
    lIlllIlIIIllII[16] = 0xA0 ^ 0xAD;
    lIlllIlIIIllII[17] = ((0xB9 ^ 0x8E) << " ".length() ^ 0x3B ^ 0x48) << " ".length();
    lIlllIlIIIllII[18] = (0x68 ^ 0x6F) << " ".length();
    lIlllIlIIIllII[19] = 0x4E ^ 0x71;
    lIlllIlIIIllII[20] = (0xBD ^ 0x96) << " ".length() << " ".length() ^ 92 + 75 - 40 + 36;
    lIlllIlIIIllII[21] = (0x9D ^ 0x94) << "   ".length();
    lIlllIlIIIllII[22] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIIllII[23] = (0x2D ^ 0x2) << " ".length() << " ".length() ^ 148 + 83 - 125 + 67;
    lIlllIlIIIllII[24] = (0xF8 ^ 0xC7 ^ (0x48 ^ 0x53) << " ".length()) << " ".length();
    lIlllIlIIIllII[25] = ((0x88 ^ 0xBD) << " ".length() ^ 0x6E ^ 0xB) << " ".length() << " ".length();
    lIlllIlIIIllII[26] = 0x4B ^ 0x58;
    lIlllIlIIIllII[27] = 0x80 ^ 0x9B;
    lIlllIlIIIllII[28] = (156 + 150 - 224 + 95 ^ (0xC ^ 0x21) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIlIIIllII[29] = (0x1E ^ 0x9) << " ".length();
    lIlllIlIIIllII[30] = 0x43 ^ 0x56;
    lIlllIlIIIllII[31] = 0x57 ^ 0x48;
    lIlllIlIIIllII[32] = (0x1A ^ 0x11) << " ".length();
    lIlllIlIIIllII[33] = (0x48 ^ 0x59) << " ".length() << " ".length() ^ 0x7A ^ 0x1F;
    lIlllIlIIIllII[34] = " ".length() << " ".length() << " ".length() ^ 0x12 ^ 0x1;
    lIlllIlIIIllII[35] = "   ".length() << "   ".length();
    lIlllIlIIIllII[36] = " ".length() << "   ".length() << " ".length();
    lIlllIlIIIllII[37] = 0x34 ^ 0x2D;
    lIlllIlIIIllII[38] = (0x95 ^ 0x90) << "   ".length();
    lIlllIlIIIllII[39] = (0xC ^ 0x1) << " ".length();
    lIlllIlIIIllII[40] = (0x96 ^ 0x83) << " ".length();
    lIlllIlIIIllII[41] = 0xFE ^ 0xC5;
    lIlllIlIIIllII[42] = (0x3D ^ 0x3A) << " ".length() << " ".length();
    lIlllIlIIIllII[43] = 0x8D ^ 0xAA;
    lIlllIlIIIllII[44] = 0x3D ^ 0x16 ^ (0x41 ^ 0x5A) << " ".length();
    lIlllIlIIIllII[45] = (0xB2 ^ 0xAB) << " ".length() << " ".length() ^ 0xAE ^ 0x8B;
    lIlllIlIIIllII[46] = (0xC8 ^ 0xC7) << " ".length();
    lIlllIlIIIllII[47] = (0x9F ^ 0x98) << "   ".length();
    lIlllIlIIIllII[48] = " ".length() << (0x7 ^ 0x5E ^ (0x52 ^ 0x45) << " ".length() << " ".length());
    lIlllIlIIIllII[49] = ((0x49 ^ 0x64) << " ".length() << " ".length() ^ 150 + 100 - 178 + 93) << " ".length();
    lIlllIlIIIllII[50] = (0xBA ^ 0xAB) << " ".length() ^ " ".length();
    lIlllIlIIIllII[51] = 0xB5 ^ 0x90;
    lIlllIlIIIllII[52] = ((0x48 ^ 0x79) << " ".length() ^ 0xC2 ^ 0xA9) << " ".length() << " ".length();
    lIlllIlIIIllII[53] = 0x3B ^ 0x7C;
    lIlllIlIIIllII[54] = (0xDA ^ 0x8F ^ (0x24 ^ 0x7) << " ".length()) << " ".length();
    lIlllIlIIIllII[55] = 0x2C ^ 0x3;
    lIlllIlIIIllII[56] = 0x12 ^ 0x3B;
    lIlllIlIIIllII[57] = (0xEC ^ 0xA9 ^ (0x66 ^ 0x49) << " ".length()) << " ".length();
    lIlllIlIIIllII[58] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIIllII[59] = (0x41 ^ 0xC) << " ".length() ^ 9 + 172 - 123 + 119;
    lIlllIlIIIllII[60] = ((0x54 ^ 0x5D) << "   ".length() ^ 0x36 ^ 0x6F) << " ".length() << " ".length();
    lIlllIlIIIllII[61] = 0xAC ^ 0x8F ^ (0x13 ^ 0x14) << " ".length();
    lIlllIlIIIllII[62] = (0xBF ^ 0xB2) << " ".length() << " ".length();
    lIlllIlIIIllII[63] = 0x28 ^ 0x19;
    lIlllIlIIIllII[64] = ("   ".length() ^ " ".length() << (0x75 ^ 0x70)) << " ".length();
    lIlllIlIIIllII[65] = ((0x47 ^ 0x4A) << " ".length() << " ".length() ^ 0x51 ^ 0x7C) << " ".length();
    lIlllIlIIIllII[66] = (0x62 ^ 0x5F) << " ".length() ^ 0x7E ^ 0x37;
    lIlllIlIIIllII[67] = 0x25 ^ 0x12;
    lIlllIlIIIllII[68] = 0xF4 ^ 0xC1;
    lIlllIlIIIllII[69] = 191 + 165 - 244 + 141 ^ (0x89 ^ 0xB8) << " ".length() << " ".length();
    lIlllIlIIIllII[70] = 0x9 ^ 0x34;
    lIlllIlIIIllII[71] = (0xB7 ^ 0xA8) << " ".length();
    lIlllIlIIIllII[72] = ((0xED ^ 0xAC) << " ".length() ^ 10 + 79 - -32 + 42) << " ".length();
    lIlllIlIIIllII[73] = 0x6D ^ 0x3A ^ (0x8 ^ 0xD) << " ".length() << " ".length();
    lIlllIlIIIllII[74] = 0x2 ^ 0x47;
    lIlllIlIIIllII[75] = (159 + 151 - 91 + 12 ^ (0x2F ^ 0x4E) << " ".length()) << " ".length();
    lIlllIlIIIllII[76] = (0x99 ^ 0x9C) << " ".length() << " ".length() ^ 0x3D ^ 0x62;
    lIlllIlIIIllII[77] = (108 + 18 - 106 + 131 ^ (0x60 ^ 0x41) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIlIIIllII[78] = 0x67 ^ 0x2A;
    lIlllIlIIIllII[79] = ("   ".length() << (0x6E ^ 0x6B) ^ 0x21 ^ 0x66) << " ".length();
    lIlllIlIIIllII[80] = 0x8D ^ 0xC2;
    lIlllIlIIIllII[81] = (0x8 ^ 0xD) << " ".length() << " ".length() << " ".length();
    lIlllIlIIIllII[82] = 0x8E ^ 0x91 ^ (0x43 ^ 0x64) << " ".length();
    lIlllIlIIIllII[83] = (0x61 ^ 0x48) << " ".length();
    lIlllIlIIIllII[84] = " ".length() << " ".length() ^ 0xF1 ^ 0xA0;
    lIlllIlIIIllII[85] = (0x47 ^ 0x52) << " ".length() << " ".length();
    lIlllIlIIIllII[86] = 0x62 ^ 0x37;
    lIlllIlIIIllII[87] = ((0xA8 ^ 0xAD) << " ".length() ^ 0x71 ^ 0x50) << " ".length();
  }
  
  private static boolean lllllIIlllIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIlllIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIlllIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIllIllllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIIllIlllII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIIllIlllIl(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lllllIIlllIIIIl(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lllllIIlllIIIlI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllIIllIllIlI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIllIllIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIllIlllll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlllIIIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIlllIIIll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIlllIIlII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\aq.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */