package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class fc extends au {
  private static String[] lIllIIllIlllIl;
  
  private static Class[] lIllIIllIllllI;
  
  private static final String[] lIllIIllIlllll;
  
  private static String[] lIllIIlllIIIll;
  
  private static final int[] lIllIIlllIIlll;
  
  public fc() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllllIIIlIlllIlI	Lme/stupitdog/bhp/fc;
  }
  
  @SubscribeEvent
  public void onChat(ClientChatEvent lllllllllllllllIlllllIIIlIllIlll) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lnet/minecraftforge/client/event/ClientChatEvent;)Ljava/lang/String;
    //   6: astore_2
    //   7: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   10: iconst_3
    //   11: iaload
    //   12: anewarray java/lang/String
    //   15: dup
    //   16: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   19: iconst_0
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   24: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   27: iconst_4
    //   28: iaload
    //   29: aaload
    //   30: aastore
    //   31: dup
    //   32: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   35: iconst_1
    //   36: iaload
    //   37: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   40: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   43: iconst_5
    //   44: iaload
    //   45: aaload
    //   46: aastore
    //   47: dup
    //   48: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   51: iconst_2
    //   52: iaload
    //   53: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   56: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   59: bipush #6
    //   61: iaload
    //   62: aaload
    //   63: aastore
    //   64: dup
    //   65: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   68: iconst_4
    //   69: iaload
    //   70: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   73: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   76: bipush #7
    //   78: iaload
    //   79: aaload
    //   80: aastore
    //   81: dup
    //   82: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   85: iconst_5
    //   86: iaload
    //   87: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   90: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   93: bipush #8
    //   95: iaload
    //   96: aaload
    //   97: aastore
    //   98: dup
    //   99: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   102: bipush #6
    //   104: iaload
    //   105: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   108: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   111: bipush #9
    //   113: iaload
    //   114: aaload
    //   115: aastore
    //   116: dup
    //   117: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   120: bipush #7
    //   122: iaload
    //   123: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   126: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   129: bipush #10
    //   131: iaload
    //   132: aaload
    //   133: aastore
    //   134: dup
    //   135: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   138: bipush #8
    //   140: iaload
    //   141: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   144: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   147: bipush #11
    //   149: iaload
    //   150: aaload
    //   151: aastore
    //   152: dup
    //   153: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   156: bipush #9
    //   158: iaload
    //   159: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   162: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   165: iconst_3
    //   166: iaload
    //   167: aaload
    //   168: aastore
    //   169: dup
    //   170: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   173: bipush #10
    //   175: iaload
    //   176: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   179: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   182: bipush #12
    //   184: iaload
    //   185: aaload
    //   186: aastore
    //   187: dup
    //   188: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   191: bipush #11
    //   193: iaload
    //   194: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   197: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   200: bipush #13
    //   202: iaload
    //   203: aaload
    //   204: aastore
    //   205: <illegal opcode> 2 : ([Ljava/lang/Object;)Ljava/util/List;
    //   210: <illegal opcode> 3 : (Ljava/util/List;)Ljava/util/Iterator;
    //   215: astore_3
    //   216: aload_3
    //   217: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   222: invokestatic llllIIIlllIIIIl : (I)Z
    //   225: ifeq -> 270
    //   228: aload_3
    //   229: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   234: checkcast java/lang/String
    //   237: astore #4
    //   239: aload_2
    //   240: aload #4
    //   242: <illegal opcode> 6 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   247: invokestatic llllIIIlllIIIIl : (I)Z
    //   250: ifeq -> 254
    //   253: return
    //   254: ldc ''
    //   256: invokevirtual length : ()I
    //   259: pop
    //   260: bipush #20
    //   262: bipush #17
    //   264: ixor
    //   265: ineg
    //   266: iflt -> 216
    //   269: return
    //   270: aload_1
    //   271: new java/lang/StringBuilder
    //   274: dup
    //   275: invokespecial <init> : ()V
    //   278: aload_2
    //   279: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   284: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   287: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   290: bipush #14
    //   292: iaload
    //   293: aaload
    //   294: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   299: aload_0
    //   300: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   303: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   306: bipush #15
    //   308: iaload
    //   309: aaload
    //   310: <illegal opcode> 8 : (Lme/stupitdog/bhp/fc;Ljava/lang/String;)Ljava/lang/String;
    //   315: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   320: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   323: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   326: bipush #16
    //   328: iaload
    //   329: aaload
    //   330: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   335: <illegal opcode> 9 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   340: <illegal opcode> 10 : (Lnet/minecraftforge/client/event/ClientChatEvent;Ljava/lang/String;)V
    //   345: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   239	15	4	lllllllllllllllIlllllIIIlIlllIIl	Ljava/lang/String;
    //   0	346	0	lllllllllllllllIlllllIIIlIlllIII	Lme/stupitdog/bhp/fc;
    //   0	346	1	lllllllllllllllIlllllIIIlIllIlll	Lnet/minecraftforge/client/event/ClientChatEvent;
    //   7	339	2	lllllllllllllllIlllllIIIlIllIllI	Ljava/lang/String;
  }
  
  public String toUnicode(String lllllllllllllllIlllllIIIlIllIlII) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 11 : (Ljava/lang/String;)Ljava/lang/String;
    //   6: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   9: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   12: bipush #17
    //   14: iaload
    //   15: aaload
    //   16: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   19: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   22: bipush #18
    //   24: iaload
    //   25: aaload
    //   26: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   34: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   37: bipush #19
    //   39: iaload
    //   40: aaload
    //   41: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   44: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   47: bipush #20
    //   49: iaload
    //   50: aaload
    //   51: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   56: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   59: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   62: bipush #21
    //   64: iaload
    //   65: aaload
    //   66: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   69: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   72: bipush #22
    //   74: iaload
    //   75: aaload
    //   76: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   81: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   84: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   87: bipush #23
    //   89: iaload
    //   90: aaload
    //   91: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   94: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   97: bipush #24
    //   99: iaload
    //   100: aaload
    //   101: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   106: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   109: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   112: bipush #25
    //   114: iaload
    //   115: aaload
    //   116: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   119: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   122: bipush #26
    //   124: iaload
    //   125: aaload
    //   126: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   131: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   134: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   137: bipush #27
    //   139: iaload
    //   140: aaload
    //   141: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   144: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   147: bipush #28
    //   149: iaload
    //   150: aaload
    //   151: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   156: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   159: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   162: bipush #29
    //   164: iaload
    //   165: aaload
    //   166: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   169: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   172: bipush #30
    //   174: iaload
    //   175: aaload
    //   176: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   181: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   184: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   187: bipush #31
    //   189: iaload
    //   190: aaload
    //   191: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   194: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   197: bipush #32
    //   199: iaload
    //   200: aaload
    //   201: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   206: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   209: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   212: bipush #33
    //   214: iaload
    //   215: aaload
    //   216: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   219: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   222: bipush #34
    //   224: iaload
    //   225: aaload
    //   226: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   231: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   234: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   237: bipush #35
    //   239: iaload
    //   240: aaload
    //   241: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   244: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   247: bipush #36
    //   249: iaload
    //   250: aaload
    //   251: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   256: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   259: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   262: bipush #37
    //   264: iaload
    //   265: aaload
    //   266: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   269: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   272: bipush #38
    //   274: iaload
    //   275: aaload
    //   276: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   281: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   284: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   287: bipush #39
    //   289: iaload
    //   290: aaload
    //   291: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   294: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   297: bipush #40
    //   299: iaload
    //   300: aaload
    //   301: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   306: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   309: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   312: bipush #41
    //   314: iaload
    //   315: aaload
    //   316: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   319: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   322: bipush #42
    //   324: iaload
    //   325: aaload
    //   326: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   331: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   334: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   337: bipush #43
    //   339: iaload
    //   340: aaload
    //   341: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   344: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   347: bipush #44
    //   349: iaload
    //   350: aaload
    //   351: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   356: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   359: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   362: bipush #45
    //   364: iaload
    //   365: aaload
    //   366: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   369: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   372: bipush #46
    //   374: iaload
    //   375: aaload
    //   376: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   381: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   384: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   387: bipush #47
    //   389: iaload
    //   390: aaload
    //   391: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   394: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   397: bipush #48
    //   399: iaload
    //   400: aaload
    //   401: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   406: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   409: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   412: bipush #49
    //   414: iaload
    //   415: aaload
    //   416: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   419: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   422: bipush #50
    //   424: iaload
    //   425: aaload
    //   426: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   431: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   434: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   437: bipush #51
    //   439: iaload
    //   440: aaload
    //   441: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   444: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   447: bipush #52
    //   449: iaload
    //   450: aaload
    //   451: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   456: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   459: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   462: bipush #53
    //   464: iaload
    //   465: aaload
    //   466: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   469: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   472: bipush #54
    //   474: iaload
    //   475: aaload
    //   476: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   481: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   484: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   487: bipush #55
    //   489: iaload
    //   490: aaload
    //   491: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   494: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   497: bipush #56
    //   499: iaload
    //   500: aaload
    //   501: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   506: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   509: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   512: bipush #57
    //   514: iaload
    //   515: aaload
    //   516: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   519: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   522: bipush #58
    //   524: iaload
    //   525: aaload
    //   526: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   531: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   534: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   537: bipush #59
    //   539: iaload
    //   540: aaload
    //   541: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   544: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   547: bipush #60
    //   549: iaload
    //   550: aaload
    //   551: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   556: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   559: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   562: bipush #61
    //   564: iaload
    //   565: aaload
    //   566: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   569: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   572: bipush #62
    //   574: iaload
    //   575: aaload
    //   576: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   581: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   584: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   587: bipush #63
    //   589: iaload
    //   590: aaload
    //   591: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   594: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   597: bipush #64
    //   599: iaload
    //   600: aaload
    //   601: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   606: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   609: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   612: bipush #65
    //   614: iaload
    //   615: aaload
    //   616: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   619: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   622: bipush #66
    //   624: iaload
    //   625: aaload
    //   626: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   631: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   634: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   637: bipush #67
    //   639: iaload
    //   640: aaload
    //   641: getstatic me/stupitdog/bhp/fc.lIllIIllIlllll : [Ljava/lang/String;
    //   644: getstatic me/stupitdog/bhp/fc.lIllIIlllIIlll : [I
    //   647: bipush #68
    //   649: iaload
    //   650: aaload
    //   651: <illegal opcode> 12 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   656: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	657	0	lllllllllllllllIlllllIIIlIllIlIl	Lme/stupitdog/bhp/fc;
    //   0	657	1	lllllllllllllllIlllllIIIlIllIlII	Ljava/lang/String;
  }
  
  static {
    llllIIIlllIIIII();
    llllIIIllIllIlI();
    llllIIIllIllIIl();
    llllIIIllIIIlII();
  }
  
  private static CallSite llllIIIllIIIIll(MethodHandles.Lookup lllllllllllllllIlllllIIIlIlIlIll, String lllllllllllllllIlllllIIIlIlIlIlI, MethodType lllllllllllllllIlllllIIIlIlIlIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIIIlIllIIIl = lIllIIllIlllIl[Integer.parseInt(lllllllllllllllIlllllIIIlIlIlIlI)].split(lIllIIllIlllll[lIllIIlllIIlll[69]]);
      Class<?> lllllllllllllllIlllllIIIlIllIIII = Class.forName(lllllllllllllllIlllllIIIlIllIIIl[lIllIIlllIIlll[0]]);
      String lllllllllllllllIlllllIIIlIlIllll = lllllllllllllllIlllllIIIlIllIIIl[lIllIIlllIIlll[1]];
      MethodHandle lllllllllllllllIlllllIIIlIlIlllI = null;
      int lllllllllllllllIlllllIIIlIlIllIl = lllllllllllllllIlllllIIIlIllIIIl[lIllIIlllIIlll[4]].length();
      if (llllIIIlllIIIlI(lllllllllllllllIlllllIIIlIlIllIl, lIllIIlllIIlll[2])) {
        MethodType lllllllllllllllIlllllIIIlIllIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIIIlIllIIIl[lIllIIlllIIlll[2]], fc.class.getClassLoader());
        if (llllIIIlllIIIll(lllllllllllllllIlllllIIIlIlIllIl, lIllIIlllIIlll[2])) {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findVirtual(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIll);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findStatic(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIll);
        } 
        "".length();
        if ((((0x32 ^ 0x35) << " ".length() ^ 0x61 ^ 0x64) << " ".length() << " ".length() & ((0x2F ^ 0x6E ^ (0xA9 ^ 0x8C) << " ".length()) << " ".length() << " ".length() ^ -" ".length())) < ((115 + 69 - 73 + 22 ^ (0x63 ^ 0x70) << "   ".length()) & (0x68 ^ 0x27 ^ (0x35 ^ 0x1C) << " ".length() ^ -" ".length())))
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIIIlIllIIlI = lIllIIllIllllI[Integer.parseInt(lllllllllllllllIlllllIIIlIllIIIl[lIllIIlllIIlll[2]])];
        if (llllIIIlllIIIll(lllllllllllllllIlllllIIIlIlIllIl, lIllIIlllIIlll[4])) {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findGetter(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIlI);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (llllIIIlllIIIll(lllllllllllllllIlllllIIIlIlIllIl, lIllIIlllIIlll[5])) {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findStaticGetter(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIlI);
          "".length();
          if (" ".length() == ((0xC4 ^ 0xC3) << "   ".length() & ((0x33 ^ 0x34) << "   ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (llllIIIlllIIIll(lllllllllllllllIlllllIIIlIlIllIl, lIllIIlllIIlll[6])) {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findSetter(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIlI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllllIIIlIlIlllI = lllllllllllllllIlllllIIIlIlIlIll.findStaticSetter(lllllllllllllllIlllllIIIlIllIIII, lllllllllllllllIlllllIIIlIlIllll, lllllllllllllllIlllllIIIlIllIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIIIlIlIlllI);
    } catch (Exception lllllllllllllllIlllllIIIlIlIllII) {
      lllllllllllllllIlllllIIIlIlIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIllIIIlII() {
    lIllIIllIlllIl = new String[lIllIIlllIIlll[13]];
    lIllIIllIlllIl[lIllIIlllIIlll[10]] = lIllIIllIlllll[lIllIIlllIIlll[70]];
    lIllIIllIlllIl[lIllIIlllIIlll[0]] = lIllIIllIlllll[lIllIIlllIIlll[71]];
    lIllIIllIlllIl[lIllIIlllIIlll[5]] = lIllIIllIlllll[lIllIIlllIIlll[72]];
    lIllIIllIlllIl[lIllIIlllIIlll[3]] = lIllIIllIlllll[lIllIIlllIIlll[73]];
    lIllIIllIlllIl[lIllIIlllIIlll[2]] = lIllIIllIlllll[lIllIIlllIIlll[74]];
    lIllIIllIlllIl[lIllIIlllIIlll[12]] = lIllIIllIlllll[lIllIIlllIIlll[75]];
    lIllIIllIlllIl[lIllIIlllIIlll[11]] = lIllIIllIlllll[lIllIIlllIIlll[76]];
    lIllIIllIlllIl[lIllIIlllIIlll[9]] = lIllIIllIlllll[lIllIIlllIIlll[77]];
    lIllIIllIlllIl[lIllIIlllIIlll[8]] = lIllIIllIlllll[lIllIIlllIIlll[78]];
    lIllIIllIlllIl[lIllIIlllIIlll[1]] = lIllIIllIlllll[lIllIIlllIIlll[79]];
    lIllIIllIlllIl[lIllIIlllIIlll[7]] = lIllIIllIlllll[lIllIIlllIIlll[80]];
    lIllIIllIlllIl[lIllIIlllIIlll[6]] = lIllIIllIlllll[lIllIIlllIIlll[81]];
    lIllIIllIlllIl[lIllIIlllIIlll[4]] = lIllIIllIlllll[lIllIIlllIIlll[82]];
    lIllIIllIllllI = new Class[lIllIIlllIIlll[1]];
    lIllIIllIllllI[lIllIIlllIIlll[0]] = f13.class;
  }
  
  private static void llllIIIllIllIIl() {
    lIllIIllIlllll = new String[lIllIIlllIIlll[83]];
    lIllIIllIlllll[lIllIIlllIIlll[0]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[0]], lIllIIlllIIIll[lIllIIlllIIlll[1]]);
    lIllIIllIlllll[lIllIIlllIIlll[1]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[2]], lIllIIlllIIIll[lIllIIlllIIlll[4]]);
    lIllIIllIlllll[lIllIIlllIIlll[2]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[5]], lIllIIlllIIIll[lIllIIlllIIlll[6]]);
    lIllIIllIlllll[lIllIIlllIIlll[4]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[7]], lIllIIlllIIIll[lIllIIlllIIlll[8]]);
    lIllIIllIlllll[lIllIIlllIIlll[5]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[9]], lIllIIlllIIIll[lIllIIlllIIlll[10]]);
    lIllIIllIlllll[lIllIIlllIIlll[6]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[11]], lIllIIlllIIIll[lIllIIlllIIlll[3]]);
    lIllIIllIlllll[lIllIIlllIIlll[7]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[12]], lIllIIlllIIIll[lIllIIlllIIlll[13]]);
    lIllIIllIlllll[lIllIIlllIIlll[8]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[14]], lIllIIlllIIIll[lIllIIlllIIlll[15]]);
    lIllIIllIlllll[lIllIIlllIIlll[9]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[16]], lIllIIlllIIIll[lIllIIlllIIlll[17]]);
    lIllIIllIlllll[lIllIIlllIIlll[10]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[18]], lIllIIlllIIIll[lIllIIlllIIlll[19]]);
    lIllIIllIlllll[lIllIIlllIIlll[11]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[20]], lIllIIlllIIIll[lIllIIlllIIlll[21]]);
    lIllIIllIlllll[lIllIIlllIIlll[3]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[22]], lIllIIlllIIIll[lIllIIlllIIlll[23]]);
    lIllIIllIlllll[lIllIIlllIIlll[12]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[24]], lIllIIlllIIIll[lIllIIlllIIlll[25]]);
    lIllIIllIlllll[lIllIIlllIIlll[13]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[26]], lIllIIlllIIIll[lIllIIlllIIlll[27]]);
    lIllIIllIlllll[lIllIIlllIIlll[14]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[28]], lIllIIlllIIIll[lIllIIlllIIlll[29]]);
    lIllIIllIlllll[lIllIIlllIIlll[15]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[30]], lIllIIlllIIIll[lIllIIlllIIlll[31]]);
    lIllIIllIlllll[lIllIIlllIIlll[16]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[32]], lIllIIlllIIIll[lIllIIlllIIlll[33]]);
    lIllIIllIlllll[lIllIIlllIIlll[17]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[34]], lIllIIlllIIIll[lIllIIlllIIlll[35]]);
    lIllIIllIlllll[lIllIIlllIIlll[18]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[36]], lIllIIlllIIIll[lIllIIlllIIlll[37]]);
    lIllIIllIlllll[lIllIIlllIIlll[19]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[38]], lIllIIlllIIIll[lIllIIlllIIlll[39]]);
    lIllIIllIlllll[lIllIIlllIIlll[20]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[40]], lIllIIlllIIIll[lIllIIlllIIlll[41]]);
    lIllIIllIlllll[lIllIIlllIIlll[21]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[42]], lIllIIlllIIIll[lIllIIlllIIlll[43]]);
    lIllIIllIlllll[lIllIIlllIIlll[22]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[44]], lIllIIlllIIIll[lIllIIlllIIlll[45]]);
    lIllIIllIlllll[lIllIIlllIIlll[23]] = llllIIIllIIIlll(lIllIIlllIIIll[lIllIIlllIIlll[46]], lIllIIlllIIIll[lIllIIlllIIlll[47]]);
    lIllIIllIlllll[lIllIIlllIIlll[24]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[48]], lIllIIlllIIIll[lIllIIlllIIlll[49]]);
    lIllIIllIlllll[lIllIIlllIIlll[25]] = llllIIIllIIIlIl(lIllIIlllIIIll[lIllIIlllIIlll[50]], lIllIIlllIIIll[lIllIIlllIIlll[51]]);
    lIllIIllIlllll[lIllIIlllIIlll[26]] = llllIIIllIIIllI(lIllIIlllIIIll[lIllIIlllIIlll[52]], "KowWE");
    lIllIIllIlllll[lIllIIlllIIlll[27]] = llllIIIllIIIllI("sRdLYpUrgek=", "PZpHT");
    lIllIIllIlllll[lIllIIlllIIlll[28]] = llllIIIllIIIllI("5lFN37Cn/UE=", "VbNrV");
    lIllIIllIlllll[lIllIIlllIIlll[29]] = llllIIIllIIIllI("fErHE9OEPcc=", "eJYBw");
    lIllIIllIlllll[lIllIIlllIIlll[30]] = llllIIIllIIIlll("yK0=", "OkhQN");
    lIllIIllIlllll[lIllIIlllIIlll[31]] = llllIIIllIIIlIl("R9EKBmlGj5M=", "tXQJF");
    lIllIIllIlllll[lIllIIlllIIlll[32]] = llllIIIllIIIllI("6/lwpuxSXiE=", "WVJre");
    lIllIIllIlllll[lIllIIlllIIlll[33]] = llllIIIllIIIlIl("gBup3ThGQ50=", "AksQl");
    lIllIIllIlllll[lIllIIlllIIlll[34]] = llllIIIllIIIlIl("BgZ1y7+Qag4=", "VUHZt");
    lIllIIllIlllll[lIllIIlllIIlll[35]] = llllIIIllIIIllI("EPpEamPMKXk=", "xNCJv");
    lIllIIllIlllll[lIllIIlllIIlll[36]] = llllIIIllIIIllI("o7HTNmymB3o=", "MWWRc");
    lIllIIllIlllll[lIllIIlllIIlll[37]] = llllIIIllIIIlll("AA==", "kRvlt");
    lIllIIllIlllll[lIllIIlllIIlll[38]] = llllIIIllIIIlIl("6RoNUgJ3sQ0=", "JFvDU");
    lIllIIllIlllll[lIllIIlllIIlll[39]] = llllIIIllIIIlIl("PlQ7Vg8PaqQ=", "dGAZW");
    lIllIIllIlllll[lIllIIlllIIlll[40]] = llllIIIllIIIllI("ZRP13UAdS2I=", "hWHZL");
    lIllIIllIlllll[lIllIIlllIIlll[41]] = llllIIIllIIIlIl("4Xjpm0Dl2eI=", "OKIsA");
    lIllIIllIlllll[lIllIIlllIIlll[42]] = llllIIIllIIIllI("IJN5Jwn8q2I=", "wuGSJ");
    lIllIIllIlllll[lIllIIlllIIlll[43]] = llllIIIllIIIlll("Ag==", "lTAQc");
    lIllIIllIlllll[lIllIIlllIIlll[44]] = llllIIIllIIIllI("AXd0XNFm8nU=", "YoxJM");
    lIllIIllIlllll[lIllIIlllIIlll[45]] = llllIIIllIIIlll("KA==", "GraMU");
    lIllIIllIlllll[lIllIIlllIIlll[46]] = llllIIIllIIIllI("ZRw1i99YEZY=", "Pxbpw");
    lIllIIllIlllll[lIllIIlllIIlll[47]] = llllIIIllIIIlll("Nw==", "GtYWy");
    lIllIIllIlllll[lIllIIlllIIlll[48]] = llllIIIllIIIlIl("QikQ877pJAU=", "BQFlw");
    lIllIIllIlllll[lIllIIlllIIlll[49]] = llllIIIllIIIllI("k/nN/rNgQDQ=", "SHIeD");
    lIllIIllIlllll[lIllIIlllIIlll[50]] = llllIIIllIIIlll("xoo=", "aujIV");
    lIllIIllIlllll[lIllIIlllIIlll[51]] = llllIIIllIIIlIl("+NIyBQ+Gkco=", "evkfW");
    lIllIIllIlllll[lIllIIlllIIlll[52]] = llllIIIllIIIlll("y64=", "nqJiA");
    lIllIIllIlllll[lIllIIlllIIlll[53]] = llllIIIllIIIllI("NOVvRE/rW6E=", "htWmp");
    lIllIIllIlllll[lIllIIlllIIlll[54]] = llllIIIllIIIllI("JWlVL0rwJRc=", "DGuWV");
    lIllIIllIlllll[lIllIIlllIIlll[55]] = llllIIIllIIIllI("sN9V6tsYKkQ=", "yBfPT");
    lIllIIllIlllll[lIllIIlllIIlll[56]] = llllIIIllIIIlll("4bW+", "eRIRD");
    lIllIIllIlllll[lIllIIlllIIlll[57]] = llllIIIllIIIllI("mROl1Vp4Exo=", "TdGbk");
    lIllIIllIlllll[lIllIIlllIIlll[58]] = llllIIIllIIIllI("bct4otYy+tk=", "PofzJ");
    lIllIIllIlllll[lIllIIlllIIlll[59]] = llllIIIllIIIlll("Ig==", "TvqsC");
    lIllIIllIlllll[lIllIIlllIIlll[60]] = llllIIIllIIIlll("4bWZ", "yiqEO");
    lIllIIllIlllll[lIllIIlllIIlll[61]] = llllIIIllIIIlIl("IxERLMujLZg=", "jyvuF");
    lIllIIllIlllll[lIllIIlllIIlll[62]] = llllIIIllIIIlIl("bTNpoS0HQpc=", "GdtDV");
    lIllIIllIlllll[lIllIIlllIIlll[63]] = llllIIIllIIIlIl("GN1X+5x0Waw=", "eTcUz");
    lIllIIllIlllll[lIllIIlllIIlll[64]] = llllIIIllIIIllI("PdPvdR3O1pk=", "gbjdN");
    lIllIIllIlllll[lIllIIlllIIlll[65]] = llllIIIllIIIllI("Jjy8KiYRVWo=", "wNqkd");
    lIllIIllIlllll[lIllIIlllIIlll[66]] = llllIIIllIIIlll("y44=", "AxorL");
    lIllIIllIlllll[lIllIIlllIIlll[67]] = llllIIIllIIIllI("eRzQAHmT6qM=", "gpnyE");
    lIllIIllIlllll[lIllIIlllIIlll[68]] = llllIIIllIIIlll("4bW1", "WwESc");
    lIllIIllIlllll[lIllIIlllIIlll[69]] = llllIIIllIIIllI("bLvUImMZRno=", "kZVYm");
    lIllIIllIlllll[lIllIIlllIIlll[70]] = llllIIIllIIIlIl("i6uT5hYWvM1GGBp41ZR1C6KzF2yDPZW5fvLSTq84pvHedBecj+h5H80TmgRzDWdbgZW1OeFoBN6FCXt8xPgfFw==", "DfOfY");
    lIllIIllIlllll[lIllIIlllIIlll[71]] = llllIIIllIIIllI("RgTybEmWMmCyvhXQGNelC/jytjERFZSVSvMm3xXgQzJV3WRWD6PGBA==", "UZjmS");
    lIllIIllIlllll[lIllIIlllIIlll[72]] = llllIIIllIIIlll("IjsgDWA9Lj8AYAEuMx4vPDUkViYpKRgJNjxgfkUUcnp2", "HZVlN");
    lIllIIllIlllll[lIllIIlllIIlll[73]] = llllIIIllIIIlll("ARQyOV0HFCo/XTgBNjEdDE8wNz8EAiEqMAoGIWJbQjkuOQUKWig5HQxaFywBAhsjY0lLVQ==", "kuDXs");
    lIllIIllIlllll[lIllIIlllIIlll[74]] = llllIIIllIIIlll("LxglAnQwDToPdAQLIQIjNkMyEBYsCidZch41OQIsJFY/AjQiVhwBMCAaJ1hzCRMyFTtqDCcKNmo1OhAufkNz", "EyScZ");
    lIllIIllIlllll[lIllIIlllIIlll[75]] = llllIIIllIIIlIl("LMK7XfzlHu8O4j4bKTxsUk1zOqLjvHNDJYauaQt4O/FdXN34h4W3gSk4SAQIEOrbMQNiU/pbhBJdXN34h4W3gSk4SAQIEOrbp/kv4UA0Ciu1ESeEGlweNqAIPddBvv/htW2kBf12gH0=", "ybsEG");
    lIllIIllIlllll[lIllIIlllIIlll[76]] = llllIIIllIIIlIl("bDivVfVxHlSirQwKSdO8ICEooLJs9hu3KT+GDwCtmArVRG+HJNBDVqUWl21VBMHKHdbfN64jQZJHxXWDyJt8NAMSOc4KrEAZ5/e6AoaoRxW5aks6WE/NOg==", "TvnDv");
    lIllIIllIlllll[lIllIIlllIIlll[77]] = llllIIIllIIIllI("TPD32rhX/ldDOclg2C92nfNoKKkZZY4DSYAmAZkX/g0fJYVnzgf4CZFe0kwMvCCxHFn9R2YywF3LfmFwNIDAMjgE5Zidob2H", "cxdNB");
    lIllIIllIlllll[lIllIIlllIIlll[78]] = llllIIIllIIIllI("uEOIaRoqEtzIKSOrDji39kkgkMCIwn55b2D9iniBNj9JFPKAG5RcgGM8i3p9eLHdLZW6kSqbaeJrFDqlc3IwCxSR0T7LuVgh634u8e88+Ys=", "TUcpl");
    lIllIIllIlllll[lIllIIlllIIlll[79]] = llllIIIllIIIlll("OAEufT0/Cj8wIjcCLjU/JAM/fTM6DT89JHgBLDY+IkoZPzkzCi4QODcQHyU1OBBgNDUiKT8gIzcDP2l4fygwMiY3SzYyPjFLCSciPwo9aGp2RA==", "VdZSP");
    lIllIIllIlllll[lIllIIlllIIlll[80]] = llllIIIllIIIlIl("Xumg1iWhWFiBLpLbIGBRqLb7gQJLcpKFT352G0PHe+m+c2lxeH2NhRiGskb3OKcwUOsJIZB1hTk=", "RZWZm");
    lIllIIllIlllll[lIllIIlllIIlll[81]] = llllIIIllIIIlIl("LzF9+oz9iLJhNa3b8wWQFhfE+97j2Jxcy59ZFPnHBXZTNzcpva8hMPUj4zRVZ9/Y", "AmADf");
    lIllIIllIlllll[lIllIIlllIIlll[82]] = llllIIIllIIIlll("HCYSGWADMw0UYDouFwx0HzMBCi8CKBZCZl8LDhk4F2gRDCcaaC0MKwQmEBc8TX1EWA==", "vGdxN");
    lIllIIlllIIIll = null;
  }
  
  private static void llllIIIllIllIlI() {
    String str = (new Exception()).getStackTrace()[lIllIIlllIIlll[0]].getFileName();
    lIllIIlllIIIll = str.substring(str.indexOf("ä") + lIllIIlllIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIllIIIllI(String lllllllllllllllIlllllIIIlIlIIlIl, String lllllllllllllllIlllllIIIlIlIIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIlIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIlIlIIlII.getBytes(StandardCharsets.UTF_8)), lIllIIlllIIlll[9]), "DES");
      Cipher lllllllllllllllIlllllIIIlIlIIlll = Cipher.getInstance("DES");
      lllllllllllllllIlllllIIIlIlIIlll.init(lIllIIlllIIlll[2], lllllllllllllllIlllllIIIlIlIlIII);
      return new String(lllllllllllllllIlllllIIIlIlIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIlIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIlIlIIllI) {
      lllllllllllllllIlllllIIIlIlIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIllIIIlIl(String lllllllllllllllIlllllIIIlIlIIIII, String lllllllllllllllIlllllIIIlIIlllll) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIlIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIlIIlllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIIIlIlIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIIIlIlIIIlI.init(lIllIIlllIIlll[2], lllllllllllllllIlllllIIIlIlIIIll);
      return new String(lllllllllllllllIlllllIIIlIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIlIlIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIlIlIIIIl) {
      lllllllllllllllIlllllIIIlIlIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIllIIIlll(String lllllllllllllllIlllllIIIlIIlllIl, String lllllllllllllllIlllllIIIlIIlllII) {
    lllllllllllllllIlllllIIIlIIlllIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIIIlIIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIIIlIIllIll = new StringBuilder();
    char[] lllllllllllllllIlllllIIIlIIllIlI = lllllllllllllllIlllllIIIlIIlllII.toCharArray();
    int lllllllllllllllIlllllIIIlIIllIIl = lIllIIlllIIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllllIIIlIIlllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIIlllIIlll[0];
    while (llllIIIlllIIlII(j, i)) {
      char lllllllllllllllIlllllIIIlIIllllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllllIIIlIIllIIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() <= (((0x62 ^ 0x73) << " ".length() ^ 0x59 ^ 0x6A) << " ".length() & ((33 + 81 - 34 + 133 ^ (0x70 ^ 0x41) << " ".length() << " ".length()) << " ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllllIIIlIIllIll);
  }
  
  private static void llllIIIlllIIIII() {
    lIllIIlllIIlll = new int[84];
    lIllIIlllIIlll[0] = "   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF) & ((0xCC ^ 0x99) & (0xDD ^ 0x88 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
    lIllIIlllIIlll[1] = " ".length();
    lIllIIlllIIlll[2] = " ".length() << " ".length();
    lIllIIlllIIlll[3] = 0x45 ^ 0x4E;
    lIllIIlllIIlll[4] = "   ".length();
    lIllIIlllIIlll[5] = " ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[6] = 0 + 78 - 61 + 116 ^ " ".length() << (0x85 ^ 0x82);
    lIllIIlllIIlll[7] = "   ".length() << " ".length();
    lIllIIlllIIlll[8] = 94 + 129 - 175 + 123 ^ (0xBC ^ 0x97) << " ".length() << " ".length();
    lIllIIlllIIlll[9] = " ".length() << "   ".length();
    lIllIIlllIIlll[10] = (0x18 ^ 0x13) << " ".length() << " ".length() << " ".length() ^ 13 + 62 - -64 + 46;
    lIllIIlllIIlll[11] = (0x5D ^ 0x68 ^ "   ".length() << " ".length() << " ".length() << " ".length()) << " ".length();
    lIllIIlllIIlll[12] = "   ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[13] = 0x71 ^ 0x7C;
    lIllIIlllIIlll[14] = (0xBC ^ 0xA1 ^ (0x15 ^ 0x18) << " ".length()) << " ".length();
    lIllIIlllIIlll[15] = (0xBF ^ 0x9A) << " ".length() ^ 0xDA ^ 0x9F;
    lIllIIlllIIlll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[17] = 0x7D ^ 0x6C;
    lIllIIlllIIlll[18] = ((0x89 ^ 0xC6) << " ".length() ^ 76 + 0 - 42 + 117) << " ".length();
    lIllIIlllIIlll[19] = 0x87 ^ 0x94;
    lIllIIlllIIlll[20] = (0x1 ^ 0x4) << " ".length() << " ".length();
    lIllIIlllIIlll[21] = 0x67 ^ 0x72;
    lIllIIlllIIlll[22] = ((0x5B ^ 0x4A) << "   ".length() ^ 7 + 75 - 27 + 76) << " ".length();
    lIllIIlllIIlll[23] = 0x49 ^ 0x5E;
    lIllIIlllIIlll[24] = "   ".length() << "   ".length();
    lIllIIlllIIlll[25] = 0x17 ^ 0x0 ^ (0x2 ^ 0x5) << " ".length();
    lIllIIlllIIlll[26] = ("   ".length() << " ".length() ^ 0xC9 ^ 0xC2) << " ".length();
    lIllIIlllIIlll[27] = 0x71 ^ 0x6C ^ "   ".length() << " ".length();
    lIllIIlllIIlll[28] = (0x61 ^ 0x66) << " ".length() << " ".length();
    lIllIIlllIIlll[29] = (0xEA ^ 0xB7) << " ".length() ^ 125 + 143 - 129 + 28;
    lIllIIlllIIlll[30] = (0xBE ^ 0xB1) << " ".length();
    lIllIIlllIIlll[31] = 0xA ^ 0x15;
    lIllIIlllIIlll[32] = " ".length() << (0x74 ^ 0x71);
    lIllIIlllIIlll[33] = " ".length() << " ".length() ^ 0x9 ^ 0x2A;
    lIllIIlllIIlll[34] = ((0x9D ^ 0xC6) << " ".length() ^ 130 + 8 - 102 + 131) << " ".length();
    lIllIIlllIIlll[35] = (0x3E ^ 0x6F) << " ".length() ^ 66 + 62 - 75 + 76;
    lIllIIlllIIlll[36] = (0x4A ^ 0x43) << " ".length() << " ".length();
    lIllIIlllIIlll[37] = 0x5F ^ 0x7A;
    lIllIIlllIIlll[38] = ((0x51 ^ 0x54) << (0x62 ^ 0x67) ^ 149 + 18 - 59 + 71) << " ".length();
    lIllIIlllIIlll[39] = 23 + 29 - -90 + 17 ^ (0x7A ^ 0x6D) << "   ".length();
    lIllIIlllIIlll[40] = ((0x7E ^ 0x45) << " ".length() ^ 0x3F ^ 0x4C) << "   ".length();
    lIllIIlllIIlll[41] = (0xFF ^ 0xA4) << " ".length() ^ 95 + 17 - 36 + 83;
    lIllIIlllIIlll[42] = (0x7B ^ 0x2 ^ (0x46 ^ 0x5D) << " ".length() << " ".length()) << " ".length();
    lIllIIlllIIlll[43] = 0x65 ^ 0x4E;
    lIllIIlllIIlll[44] = (0x6F ^ 0x64) << " ".length() << " ".length();
    lIllIIlllIIlll[45] = 0xEA ^ 0xC7;
    lIllIIlllIIlll[46] = (0x4D ^ 0x5A) << " ".length();
    lIllIIlllIIlll[47] = 0x7A ^ 0x55;
    lIllIIlllIIlll[48] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[49] = " ".length() << " ".length() << " ".length() ^ 0x21 ^ 0x14;
    lIllIIlllIIlll[50] = ((0x3B ^ 0x78) << " ".length() ^ 124 + 133 - 141 + 43) << " ".length();
    lIllIIlllIIlll[51] = 0x9E ^ 0xAD;
    lIllIIlllIIlll[52] = (0x56 ^ 0x5B) << " ".length() << " ".length();
    lIllIIlllIIlll[53] = 0x69 ^ 0x62 ^ (0x90 ^ 0x8F) << " ".length();
    lIllIIlllIIlll[54] = ((0x46 ^ 0x51) << " ".length() << " ".length() ^ 0x26 ^ 0x61) << " ".length();
    lIllIIlllIIlll[55] = 0xA7 ^ 0x90;
    lIllIIlllIIlll[56] = (0x37 ^ 0x30) << "   ".length();
    lIllIIlllIIlll[57] = 0xCC ^ 0x8D ^ (0xA2 ^ 0xAD) << "   ".length();
    lIllIIlllIIlll[58] = (0x1B ^ 0x6) << " ".length();
    lIllIIlllIIlll[59] = 135 + 106 - 199 + 97 ^ (0xB5 ^ 0xBE) << " ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[60] = (0x9 ^ 0x4 ^ " ".length() << " ".length()) << " ".length() << " ".length();
    lIllIIlllIIlll[61] = 0x70 ^ 0x4D;
    lIllIIlllIIlll[62] = ((0x78 ^ 0x6D) << "   ".length() ^ 167 + 174 - 158 + 0) << " ".length();
    lIllIIlllIIlll[63] = "   ".length() << " ".length() << " ".length() ^ 0x3E ^ 0xD;
    lIllIIlllIIlll[64] = " ".length() << "   ".length() << " ".length();
    lIllIIlllIIlll[65] = 0x82 ^ 0xC3;
    lIllIIlllIIlll[66] = ((0x14 ^ 0x1D) << " ".length() ^ 0x70 ^ 0x43) << " ".length();
    lIllIIlllIIlll[67] = (0x4D ^ 0x78) << " ".length() ^ 0x42 ^ 0x6B;
    lIllIIlllIIlll[68] = (0x2E ^ 0x3F) << " ".length() << " ".length();
    lIllIIlllIIlll[69] = 0x7E ^ 0x3B;
    lIllIIlllIIlll[70] = (0x82 ^ 0xBF ^ (0x6B ^ 0x64) << " ".length()) << " ".length();
    lIllIIlllIIlll[71] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0xF1 ^ 0x86;
    lIllIIlllIIlll[72] = (28 + 50 - 55 + 162 ^ (0x72 ^ 0x79) << " ".length() << " ".length() << " ".length()) << "   ".length();
    lIllIIlllIIlll[73] = 0x2A ^ 0x63;
    lIllIIlllIIlll[74] = ((0x90 ^ 0xBD) << " ".length() << " ".length() ^ 136 + 101 - 136 + 44) << " ".length();
    lIllIIlllIIlll[75] = 0x3E ^ 0x75;
    lIllIIlllIIlll[76] = ((0x4B ^ 0x1E) << " ".length() ^ 47 + 135 - 30 + 33) << " ".length() << " ".length();
    lIllIIlllIIlll[77] = 0xD ^ 0x40;
    lIllIIlllIIlll[78] = (99 + 138 - 167 + 105 ^ (0xD2 ^ 0xC3) << "   ".length()) << " ".length();
    lIllIIlllIIlll[79] = 227 + 79 - 136 + 79 ^ (0x15 ^ 0x4E) << " ".length();
    lIllIIlllIIlll[80] = (0x18 ^ 0x3F ^ (0x17 ^ 0x6) << " ".length()) << " ".length() << " ".length() << " ".length();
    lIllIIlllIIlll[81] = 0x36 ^ 0x67;
    lIllIIlllIIlll[82] = (0x1A ^ 0x79 ^ (0x9A ^ 0xBF) << " ".length()) << " ".length();
    lIllIIlllIIlll[83] = (0xA8 ^ 0xAF) << " ".length() ^ 0xC5 ^ 0x98;
  }
  
  private static boolean llllIIIlllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIIlllIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIIlllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIIIlllIIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */