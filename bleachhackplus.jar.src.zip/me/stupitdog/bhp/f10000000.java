package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.client.event.InputUpdateEvent;

public class f10000000 extends au {
  @EventHandler
  public Listener<InputUpdateEvent> listener;
  
  private static String[] llIIlIllIIIlII;
  
  private static Class[] llIIlIllIIIlIl;
  
  private static final String[] llIIlIllIlIlIl;
  
  private static String[] llIIlIllIlIllI;
  
  private static final int[] llIIlIllIlIlll;
  
  public f10000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/f10000000.llIIlIllIlIlll : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000;Lme/zero/alpine/listener/Listener;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	68	0	lllllllllllllllIllIIlIIIIlIIIIll	Lme/stupitdog/bhp/f10000000;
  }
  
  static {
    lIIIlIIIIIIlllIl();
    lIIIlIIIIIIlllII();
    lIIIlIIIIIIllIll();
    lIIIlIIIIIIlIlll();
  }
  
  private static CallSite lIIIIlllllllIlIl(MethodHandles.Lookup lllllllllllllllIllIIlIIIIIlllIIl, String lllllllllllllllIllIIlIIIIIlllIII, MethodType lllllllllllllllIllIIlIIIIIllIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlIIIIIllllll = llIIlIllIIIlII[Integer.parseInt(lllllllllllllllIllIIlIIIIIlllIII)].split(llIIlIllIlIlIl[llIIlIllIlIlll[3]]);
      Class<?> lllllllllllllllIllIIlIIIIIlllllI = Class.forName(lllllllllllllllIllIIlIIIIIllllll[llIIlIllIlIlll[0]]);
      String lllllllllllllllIllIIlIIIIIllllIl = lllllllllllllllIllIIlIIIIIllllll[llIIlIllIlIlll[1]];
      MethodHandle lllllllllllllllIllIIlIIIIIllllII = null;
      int lllllllllllllllIllIIlIIIIIlllIll = lllllllllllllllIllIIlIIIIIllllll[llIIlIllIlIlll[3]].length();
      if (lIIIlIIIIIlIIIII(lllllllllllllllIllIIlIIIIIlllIll, llIIlIllIlIlll[2])) {
        MethodType lllllllllllllllIllIIlIIIIlIIIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlIIIIIllllll[llIIlIllIlIlll[2]], f10000000.class.getClassLoader());
        if (lIIIlIIIIIlIIIIl(lllllllllllllllIllIIlIIIIIlllIll, llIIlIllIlIlll[2])) {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findVirtual(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIIl);
          "".length();
          if (-(0xA8 ^ 0xAC) > 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findStatic(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIIl);
        } 
        "".length();
        if ("   ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlIIIIlIIIIII = llIIlIllIIIlIl[Integer.parseInt(lllllllllllllllIllIIlIIIIIllllll[llIIlIllIlIlll[2]])];
        if (lIIIlIIIIIlIIIIl(lllllllllllllllIllIIlIIIIIlllIll, llIIlIllIlIlll[3])) {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findGetter(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIII);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else if (lIIIlIIIIIlIIIIl(lllllllllllllllIllIIlIIIIIlllIll, llIIlIllIlIlll[4])) {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findStaticGetter(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIlIIIIIlIIIIl(lllllllllllllllIllIIlIIIIIlllIll, llIIlIllIlIlll[5])) {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findSetter(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIII);
          "".length();
          if (-" ".length() > "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlIIIIIllllII = lllllllllllllllIllIIlIIIIIlllIIl.findStaticSetter(lllllllllllllllIllIIlIIIIIlllllI, lllllllllllllllIllIIlIIIIIllllIl, lllllllllllllllIllIIlIIIIlIIIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlIIIIIllllII);
    } catch (Exception lllllllllllllllIllIIlIIIIIlllIlI) {
      lllllllllllllllIllIIlIIIIIlllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIIIlIlll() {
    llIIlIllIIIlII = new String[llIIlIllIlIlll[6]];
    llIIlIllIIIlII[llIIlIllIlIlll[1]] = llIIlIllIlIlIl[llIIlIllIlIlll[4]];
    llIIlIllIIIlII[llIIlIllIlIlll[0]] = llIIlIllIlIlIl[llIIlIllIlIlll[5]];
    llIIlIllIIIlII[llIIlIllIlIlll[5]] = llIIlIllIlIlIl[llIIlIllIlIlll[7]];
    llIIlIllIIIlII[llIIlIllIlIlll[8]] = llIIlIllIlIlIl[llIIlIllIlIlll[9]];
    llIIlIllIIIlII[llIIlIllIlIlll[3]] = llIIlIllIlIlIl[llIIlIllIlIlll[8]];
    llIIlIllIIIlII[llIIlIllIlIlll[2]] = llIIlIllIlIlIl[llIIlIllIlIlll[6]];
    llIIlIllIIIlII[llIIlIllIlIlll[9]] = llIIlIllIlIlIl[llIIlIllIlIlll[10]];
    llIIlIllIIIlII[llIIlIllIlIlll[7]] = llIIlIllIlIlIl[llIIlIllIlIlll[11]];
    llIIlIllIIIlII[llIIlIllIlIlll[4]] = llIIlIllIlIlIl[llIIlIllIlIlll[12]];
    llIIlIllIIIlIl = new Class[llIIlIllIlIlll[5]];
    llIIlIllIIIlIl[llIIlIllIlIlll[0]] = f13.class;
    llIIlIllIIIlIl[llIIlIllIlIlll[3]] = EntityPlayerSP.class;
    llIIlIllIIIlIl[llIIlIllIlIlll[1]] = Listener.class;
    llIIlIllIIIlIl[llIIlIllIlIlll[4]] = float.class;
    llIIlIllIIIlIl[llIIlIllIlIlll[2]] = Minecraft.class;
  }
  
  private static void lIIIlIIIIIIllIll() {
    llIIlIllIlIlIl = new String[llIIlIllIlIlll[13]];
    llIIlIllIlIlIl[llIIlIllIlIlll[0]] = lIIIlIIIIIIllIII(llIIlIllIlIllI[llIIlIllIlIlll[0]], llIIlIllIlIllI[llIIlIllIlIlll[1]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[1]] = lIIIlIIIIIIllIIl(llIIlIllIlIllI[llIIlIllIlIlll[2]], llIIlIllIlIllI[llIIlIllIlIlll[3]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[2]] = lIIIlIIIIIIllIlI(llIIlIllIlIllI[llIIlIllIlIlll[4]], llIIlIllIlIllI[llIIlIllIlIlll[5]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[3]] = lIIIlIIIIIIllIII(llIIlIllIlIllI[llIIlIllIlIlll[7]], llIIlIllIlIllI[llIIlIllIlIlll[9]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[4]] = lIIIlIIIIIIllIIl(llIIlIllIlIllI[llIIlIllIlIlll[8]], llIIlIllIlIllI[llIIlIllIlIlll[6]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[5]] = lIIIlIIIIIIllIlI(llIIlIllIlIllI[llIIlIllIlIlll[10]], llIIlIllIlIllI[llIIlIllIlIlll[11]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[7]] = lIIIlIIIIIIllIII(llIIlIllIlIllI[llIIlIllIlIlll[12]], llIIlIllIlIllI[llIIlIllIlIlll[13]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[9]] = lIIIlIIIIIIllIII(llIIlIllIlIllI[llIIlIllIlIlll[14]], llIIlIllIlIllI[llIIlIllIlIlll[15]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[8]] = lIIIlIIIIIIllIlI(llIIlIllIlIllI[llIIlIllIlIlll[16]], llIIlIllIlIllI[llIIlIllIlIlll[17]]);
    llIIlIllIlIlIl[llIIlIllIlIlll[6]] = lIIIlIIIIIIllIII("PxJYCRcnBx8OBz0QWBgLIlkQS1NiR0ZKU2JNGxlZYE1WWkNy", "Rwvzc");
    llIIlIllIlIlIl[llIIlIllIlIlll[10]] = lIIIlIIIIIIllIlI("8WUWshEHmSp0yF584w8kFlxKn2Swj7516gk/uJak1ujVAmgEOtnTMyD06B0N1+ffoAbB5gafljc=", "VOnaJ");
    llIIlIllIlIlIl[llIIlIllIlIlll[11]] = lIIIlIIIIIIllIlI("i3ViBOKzt7honbShIw8d9T/m+plVGCnF8PXj1jmpjH3kq3bez+J4347HqmBBQl7LDc+itHii0MYS6hV/YUZSsNXm/RkcKwyqWuYMF9v38W0ZYNQrI+0j36gbJ6/dn7fxCD1Lu+gAEgXIJnw5DLF1yA==", "TCAjH");
    llIIlIllIlIlIl[llIIlIllIlIlll[12]] = lIIIlIIIIIIllIlI("CBh5o45b6Dk8Soycjybr78/I6PL/rNooA8i2itJvsaQT7g7gJEDN/ZDIJdzQJxuJj6J0qFcOr/CkVn2ac/g8Y+q/CYAqbITJ", "platF");
    llIIlIllIlIllI = null;
  }
  
  private static void lIIIlIIIIIIlllII() {
    String str = (new Exception()).getStackTrace()[llIIlIllIlIlll[0]].getFileName();
    llIIlIllIlIllI = str.substring(str.indexOf("ä") + llIIlIllIlIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIIIIllIIl(String lllllllllllllllIllIIlIIIIIllIIll, String lllllllllllllllIllIIlIIIIIllIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIIIIllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIIIIllIIlI.getBytes(StandardCharsets.UTF_8)), llIIlIllIlIlll[8]), "DES");
      Cipher lllllllllllllllIllIIlIIIIIllIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIIIIIllIlIl.init(llIIlIllIlIlll[2], lllllllllllllllIllIIlIIIIIllIllI);
      return new String(lllllllllllllllIllIIlIIIIIllIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIIIIllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIIIIllIlII) {
      lllllllllllllllIllIIlIIIIIllIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIIIllIlI(String lllllllllllllllIllIIlIIIIIlIlllI, String lllllllllllllllIllIIlIIIIIlIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIIIIllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIIIIlIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIIIIIllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIIIIIllIIII.init(llIIlIllIlIlll[2], lllllllllllllllIllIIlIIIIIllIIIl);
      return new String(lllllllllllllllIllIIlIIIIIllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIIIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIIIIlIllll) {
      lllllllllllllllIllIIlIIIIIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIIIllIII(String lllllllllllllllIllIIlIIIIIlIlIll, String lllllllllllllllIllIIlIIIIIlIlIlI) {
    lllllllllllllllIllIIlIIIIIlIlIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIIIIIlIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIIIIIlIlIIl = new StringBuilder();
    char[] lllllllllllllllIllIIlIIIIIlIlIII = lllllllllllllllIllIIlIIIIIlIlIlI.toCharArray();
    int lllllllllllllllIllIIlIIIIIlIIlll = llIIlIllIlIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlIIIIIlIlIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIllIlIlll[0];
    while (lIIIlIIIIIlIIIlI(j, i)) {
      char lllllllllllllllIllIIlIIIIIlIllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlIIIIIlIIlll++;
      j++;
      "".length();
      if (" ".length() << " ".length() <= " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlIIIIIlIlIIl);
  }
  
  private static void lIIIlIIIIIIlllIl() {
    llIIlIllIlIlll = new int[18];
    llIIlIllIlIlll[0] = (0x21 ^ 0x42) & (0x1B ^ 0x78 ^ 0xFFFFFFFF);
    llIIlIllIlIlll[1] = " ".length();
    llIIlIllIlIlll[2] = " ".length() << " ".length();
    llIIlIllIlIlll[3] = "   ".length();
    llIIlIllIlIlll[4] = " ".length() << " ".length() << " ".length();
    llIIlIllIlIlll[5] = 0xA4 ^ 0xBB ^ (0x42 ^ 0x4F) << " ".length();
    llIIlIllIlIlll[6] = 0x8B ^ 0x82;
    llIIlIllIlIlll[7] = "   ".length() << " ".length();
    llIIlIllIlIlll[8] = " ".length() << "   ".length();
    llIIlIllIlIlll[9] = (0x4 ^ 0x13) << "   ".length() ^ 30 + 52 - 22 + 131;
    llIIlIllIlIlll[10] = (0x28 ^ 0x2D) << " ".length();
    llIIlIllIlIlll[11] = (0x73 ^ 0x3C) << " ".length() ^ 89 + 54 - 2 + 8;
    llIIlIllIlIlll[12] = "   ".length() << " ".length() << " ".length();
    llIIlIllIlIlll[13] = 0x11 ^ 0x1C;
    llIIlIllIlIlll[14] = ((0x1 ^ 0x5E) << " ".length() ^ 39 + 46 - -63 + 37) << " ".length();
    llIIlIllIlIlll[15] = 0 + 49 - 30 + 110 ^ (0x63 ^ 0x24) << " ".length();
    llIIlIllIlIlll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIllIlIlll[17] = 0x34 ^ 0x25;
  }
  
  private static boolean lIIIlIIIIIlIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIIIlIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIIIlIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIIIIIllllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIlIIIIIIlllll(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */