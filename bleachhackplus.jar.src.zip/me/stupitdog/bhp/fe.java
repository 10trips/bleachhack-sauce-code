package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fe extends au {
  public static f100000000000000000000.ColorSetting outlineColor;
  
  public static f100000000000000000000.ColorSetting backgroundColor;
  
  public static f100000000000000000000.ColorSetting enabledColor;
  
  public static f100000000000000000000.ColorSetting settingBackgroundColor;
  
  public static f100000000000000000000.ColorSetting fontColor;
  
  public static f100000000000000000000.Integer opacity;
  
  public static f100000000000000000000.Integer animationSpeed;
  
  public static f100000000000000000000.Mode scrolling;
  
  public static f100000000000000000000.Integer scrollSpeed;
  
  public static f100000000000000000000.Mode description;
  
  private static String[] lIllllllIlllIl;
  
  private static Class[] lIllllllIllllI;
  
  private static final String[] lIllllllIlllll;
  
  private static String[] lIlllllllIIIII;
  
  private static final int[] lIlllllllIIIIl;
  
  public fe() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   36: iconst_3
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIllllllllIIIII	Lme/stupitdog/bhp/fe;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   15: iconst_4
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   36: iconst_5
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   54: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   57: bipush #6
    //   59: iaload
    //   60: aaload
    //   61: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   64: bipush #7
    //   66: iaload
    //   67: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   70: bipush #8
    //   72: iaload
    //   73: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   76: bipush #9
    //   78: iaload
    //   79: <illegal opcode> 2 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   84: <illegal opcode> 3 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   89: aload_0
    //   90: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   93: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   96: bipush #10
    //   98: iaload
    //   99: aaload
    //   100: new me/stupitdog/bhp/f01
    //   103: dup
    //   104: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   107: bipush #11
    //   109: iaload
    //   110: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   113: bipush #11
    //   115: iaload
    //   116: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   119: bipush #11
    //   121: iaload
    //   122: invokespecial <init> : (III)V
    //   125: <illegal opcode> 4 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   130: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   135: aload_0
    //   136: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   139: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   142: bipush #12
    //   144: iaload
    //   145: aaload
    //   146: new me/stupitdog/bhp/f01
    //   149: dup
    //   150: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   153: bipush #13
    //   155: iaload
    //   156: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   159: bipush #13
    //   161: iaload
    //   162: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   165: bipush #13
    //   167: iaload
    //   168: invokespecial <init> : (III)V
    //   171: <illegal opcode> 4 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   176: <illegal opcode> 6 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   181: aload_0
    //   182: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   185: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   188: bipush #14
    //   190: iaload
    //   191: aaload
    //   192: new me/stupitdog/bhp/f01
    //   195: dup
    //   196: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   199: bipush #13
    //   201: iaload
    //   202: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   205: bipush #13
    //   207: iaload
    //   208: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   211: bipush #13
    //   213: iaload
    //   214: invokespecial <init> : (III)V
    //   217: <illegal opcode> 4 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   222: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   227: aload_0
    //   228: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   231: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   234: bipush #15
    //   236: iaload
    //   237: aaload
    //   238: new me/stupitdog/bhp/f01
    //   241: dup
    //   242: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   245: bipush #16
    //   247: iaload
    //   248: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   251: bipush #16
    //   253: iaload
    //   254: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   257: bipush #16
    //   259: iaload
    //   260: invokespecial <init> : (III)V
    //   263: <illegal opcode> 4 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   268: <illegal opcode> 8 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   273: aload_0
    //   274: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   277: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   280: bipush #17
    //   282: iaload
    //   283: aaload
    //   284: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   287: bipush #18
    //   289: iaload
    //   290: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   293: iconst_0
    //   294: iaload
    //   295: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   298: bipush #19
    //   300: iaload
    //   301: <illegal opcode> 2 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   306: <illegal opcode> 9 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   311: aload_0
    //   312: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   315: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   318: bipush #20
    //   320: iaload
    //   321: aaload
    //   322: aload_1
    //   323: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   326: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   329: bipush #21
    //   331: iaload
    //   332: aaload
    //   333: <illegal opcode> 10 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   338: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   343: aload_0
    //   344: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   347: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   350: bipush #22
    //   352: iaload
    //   353: aaload
    //   354: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   357: bipush #17
    //   359: iaload
    //   360: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   363: iconst_1
    //   364: iaload
    //   365: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   368: bipush #23
    //   370: iaload
    //   371: <illegal opcode> 2 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   376: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   381: aload_0
    //   382: getstatic me/stupitdog/bhp/fe.lIllllllIlllll : [Ljava/lang/String;
    //   385: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   388: bipush #24
    //   390: iaload
    //   391: aaload
    //   392: new me/stupitdog/bhp/f01
    //   395: dup
    //   396: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   399: bipush #9
    //   401: iaload
    //   402: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   405: bipush #9
    //   407: iaload
    //   408: getstatic me/stupitdog/bhp/fe.lIlllllllIIIIl : [I
    //   411: bipush #9
    //   413: iaload
    //   414: invokespecial <init> : (III)V
    //   417: <illegal opcode> 4 : (Lme/stupitdog/bhp/fe;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   422: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   427: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	428	0	lllllllllllllllIllIlllllllIlllll	Lme/stupitdog/bhp/fe;
    //   8	420	1	lllllllllllllllIllIlllllllIllllI	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	420	1	lllllllllllllllIllIlllllllIllllI	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 14 : ()Lme/stupitdog/bhp/f9;
    //   5: <illegal opcode> 15 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/fd;
    //   10: <illegal opcode> 16 : (Lme/stupitdog/bhp/fd;)V
    //   15: aload_0
    //   16: <illegal opcode> 17 : (Lme/stupitdog/bhp/fe;)V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIllIlllllllIlllIl	Lme/stupitdog/bhp/fe;
  }
  
  static {
    lIIIIIIIIlllIlII();
    lIIIIIIIIlllIIll();
    lIIIIIIIIlllIIlI();
    lIIIIIIIIllIlllI();
  }
  
  private static CallSite lIIIIIIIIllIllIl(MethodHandles.Lookup lllllllllllllllIllIlllllllIlIlII, String lllllllllllllllIllIlllllllIlIIll, MethodType lllllllllllllllIllIlllllllIlIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllllllIllIlI = lIllllllIlllIl[Integer.parseInt(lllllllllllllllIllIlllllllIlIIll)].split(lIllllllIlllll[lIlllllllIIIIl[25]]);
      Class<?> lllllllllllllllIllIlllllllIllIIl = Class.forName(lllllllllllllllIllIlllllllIllIlI[lIlllllllIIIIl[0]]);
      String lllllllllllllllIllIlllllllIllIII = lllllllllllllllIllIlllllllIllIlI[lIlllllllIIIIl[1]];
      MethodHandle lllllllllllllllIllIlllllllIlIlll = null;
      int lllllllllllllllIllIlllllllIlIllI = lllllllllllllllIllIlllllllIllIlI[lIlllllllIIIIl[4]].length();
      if (lIIIIIIIIlllIlIl(lllllllllllllllIllIlllllllIlIllI, lIlllllllIIIIl[2])) {
        MethodType lllllllllllllllIllIlllllllIlllII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllllllIllIlI[lIlllllllIIIIl[2]], fe.class.getClassLoader());
        if (lIIIIIIIIlllIllI(lllllllllllllllIllIlllllllIlIllI, lIlllllllIIIIl[2])) {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findVirtual(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIlllII);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findStatic(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIlllII);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllllllIllIll = lIllllllIllllI[Integer.parseInt(lllllllllllllllIllIlllllllIllIlI[lIlllllllIIIIl[2]])];
        if (lIIIIIIIIlllIllI(lllllllllllllllIllIlllllllIlIllI, lIlllllllIIIIl[4])) {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findGetter(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIllIll);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else if (lIIIIIIIIlllIllI(lllllllllllllllIllIlllllllIlIllI, lIlllllllIIIIl[5])) {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findStaticGetter(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIllIll);
          "".length();
          if ((" ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) != ((0x82 ^ 0x95) << " ".length() & ((0x3 ^ 0x14) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lIIIIIIIIlllIllI(lllllllllllllllIllIlllllllIlIllI, lIlllllllIIIIl[6])) {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findSetter(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIllIll);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlllllllIlIlll = lllllllllllllllIllIlllllllIlIlII.findStaticSetter(lllllllllllllllIllIlllllllIllIIl, lllllllllllllllIllIlllllllIllIII, lllllllllllllllIllIlllllllIllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllllllIlIlll);
    } catch (Exception lllllllllllllllIllIlllllllIlIlIl) {
      lllllllllllllllIllIlllllllIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIllIlllI() {
    lIllllllIlllIl = new String[lIlllllllIIIIl[26]];
    lIllllllIlllIl[lIlllllllIIIIl[20]] = lIllllllIlllll[lIlllllllIIIIl[27]];
    lIllllllIlllIl[lIlllllllIIIIl[14]] = lIllllllIlllll[lIlllllllIIIIl[28]];
    lIllllllIlllIl[lIlllllllIIIIl[15]] = lIllllllIlllll[lIlllllllIIIIl[26]];
    lIllllllIlllIl[lIlllllllIIIIl[24]] = lIllllllIlllll[lIlllllllIIIIl[29]];
    lIllllllIlllIl[lIlllllllIIIIl[28]] = lIllllllIlllll[lIlllllllIIIIl[23]];
    lIllllllIlllIl[lIlllllllIIIIl[12]] = lIllllllIlllll[lIlllllllIIIIl[3]];
    lIllllllIlllIl[lIlllllllIIIIl[27]] = lIllllllIlllll[lIlllllllIIIIl[30]];
    lIllllllIlllIl[lIlllllllIIIIl[0]] = lIllllllIlllll[lIlllllllIIIIl[31]];
    lIllllllIlllIl[lIlllllllIIIIl[10]] = lIllllllIlllll[lIlllllllIIIIl[32]];
    lIllllllIlllIl[lIlllllllIIIIl[25]] = lIllllllIlllll[lIlllllllIIIIl[33]];
    lIllllllIlllIl[lIlllllllIIIIl[22]] = lIllllllIlllll[lIlllllllIIIIl[34]];
    lIllllllIlllIl[lIlllllllIIIIl[6]] = lIllllllIlllll[lIlllllllIIIIl[35]];
    lIllllllIlllIl[lIlllllllIIIIl[17]] = lIllllllIlllll[lIlllllllIIIIl[36]];
    lIllllllIlllIl[lIlllllllIIIIl[2]] = lIllllllIlllll[lIlllllllIIIIl[37]];
    lIllllllIlllIl[lIlllllllIIIIl[5]] = lIllllllIlllll[lIlllllllIIIIl[38]];
    lIllllllIlllIl[lIlllllllIIIIl[1]] = lIllllllIlllll[lIlllllllIIIIl[39]];
    lIllllllIlllIl[lIlllllllIIIIl[21]] = lIllllllIlllll[lIlllllllIIIIl[40]];
    lIllllllIlllIl[lIlllllllIIIIl[4]] = lIllllllIlllll[lIlllllllIIIIl[41]];
    lIllllllIllllI = new Class[lIlllllllIIIIl[10]];
    lIllllllIllllI[lIlllllllIIIIl[0]] = f13.class;
    lIllllllIllllI[lIlllllllIIIIl[5]] = f9.class;
    lIllllllIllllI[lIlllllllIIIIl[2]] = f100000000000000000000.ColorSetting.class;
    lIllllllIllllI[lIlllllllIIIIl[1]] = f100000000000000000000.Integer.class;
    lIllllllIllllI[lIlllllllIIIIl[4]] = f100000000000000000000.Mode.class;
    lIllllllIllllI[lIlllllllIIIIl[6]] = fd.class;
  }
  
  private static void lIIIIIIIIlllIIlI() {
    lIllllllIlllll = new String[lIlllllllIIIIl[42]];
    lIllllllIlllll[lIlllllllIIIIl[0]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[0]], lIlllllllIIIII[lIlllllllIIIIl[1]]);
    lIllllllIlllll[lIlllllllIIIIl[1]] = lIIIIIIIIlllIIII(lIlllllllIIIII[lIlllllllIIIIl[2]], lIlllllllIIIII[lIlllllllIIIIl[4]]);
    lIllllllIlllll[lIlllllllIIIIl[2]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[5]], lIlllllllIIIII[lIlllllllIIIIl[6]]);
    lIllllllIlllll[lIlllllllIIIIl[4]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[10]], lIlllllllIIIII[lIlllllllIIIIl[12]]);
    lIllllllIlllll[lIlllllllIIIIl[5]] = lIIIIIIIIlllIIIl(lIlllllllIIIII[lIlllllllIIIIl[14]], lIlllllllIIIII[lIlllllllIIIIl[15]]);
    lIllllllIlllll[lIlllllllIIIIl[6]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[17]], lIlllllllIIIII[lIlllllllIIIIl[20]]);
    lIllllllIlllll[lIlllllllIIIIl[10]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[21]], lIlllllllIIIII[lIlllllllIIIIl[22]]);
    lIllllllIlllll[lIlllllllIIIIl[12]] = lIIIIIIIIlllIIII(lIlllllllIIIII[lIlllllllIIIIl[24]], lIlllllllIIIII[lIlllllllIIIIl[25]]);
    lIllllllIlllll[lIlllllllIIIIl[14]] = lIIIIIIIIlllIIIl(lIlllllllIIIII[lIlllllllIIIIl[27]], lIlllllllIIIII[lIlllllllIIIIl[28]]);
    lIllllllIlllll[lIlllllllIIIIl[15]] = lIIIIIIIIlllIIIl(lIlllllllIIIII[lIlllllllIIIIl[26]], lIlllllllIIIII[lIlllllllIIIIl[29]]);
    lIllllllIlllll[lIlllllllIIIIl[17]] = lIIIIIIIIlllIIII(lIlllllllIIIII[lIlllllllIIIIl[23]], lIlllllllIIIII[lIlllllllIIIIl[3]]);
    lIllllllIlllll[lIlllllllIIIIl[20]] = lIIIIIIIIlllIIII(lIlllllllIIIII[lIlllllllIIIIl[30]], lIlllllllIIIII[lIlllllllIIIIl[31]]);
    lIllllllIlllll[lIlllllllIIIIl[21]] = lIIIIIIIIlllIIIl(lIlllllllIIIII[lIlllllllIIIIl[32]], lIlllllllIIIII[lIlllllllIIIIl[33]]);
    lIllllllIlllll[lIlllllllIIIIl[22]] = lIIIIIIIIlllIIIl(lIlllllllIIIII[lIlllllllIIIIl[34]], lIlllllllIIIII[lIlllllllIIIIl[35]]);
    lIllllllIlllll[lIlllllllIIIIl[24]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[36]], lIlllllllIIIII[lIlllllllIIIIl[37]]);
    lIllllllIlllll[lIlllllllIIIIl[25]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[38]], lIlllllllIIIII[lIlllllllIIIIl[39]]);
    lIllllllIlllll[lIlllllllIIIIl[27]] = lIIIIIIIIllIllll(lIlllllllIIIII[lIlllllllIIIIl[40]], lIlllllllIIIII[lIlllllllIIIIl[41]]);
    lIllllllIlllll[lIlllllllIIIIl[28]] = lIIIIIIIIlllIIIl("PTZUMRglIxM2CD80VCAEIH0cJ1Y1PRsgADU3OS0APyFAcFZwc1piTHA=", "PSzBl");
    lIllllllIlllll[lIlllllllIIIIl[26]] = lIIIIIIIIlllIIII("E/1GvzWJNX57o0uNbqGBbfUlwCxDBNKzPwTGhYQ0opT98dtN7YaWeKa088+JkZuV", "kEIDP");
    lIllllllIlllll[lIlllllllIIIIl[29]] = lIIIIIIIIlllIIII("6vc4UcZbGJHl9YrBRGdLSrvjS+C8AcEAZPYfixqBKyOWtrIqDm1T+Q==", "Byhui");
    lIllllllIlllll[lIlllllllIIIIl[23]] = lIIIIIIIIlllIIIl("IDxHIx04KQAkDSI+RzIBPXcPNVM5Ng43BShjQXk/d3lJ", "MYiPi");
    lIllllllIlllll[lIlllllllIIIIl[3]] = lIIIIIIIIlllIIII("ar554FFjEnuYTctrFa9G7uyGllE4ltlMfrL5DrX+DrVQiXFpvjOY1kwBZDiMe6rMuPBFtD/Xoy0=", "DhVXn");
    lIllllllIlllll[lIlllllllIIIIl[30]] = lIIIIIIIIlllIIII("AwU5URXRi9JYwBId2dSuKO0aesS1bJZOnrER5baU2zcp3kLSzCPcNQ==", "LfQsl");
    lIllllllIlllll[lIlllllllIIIIl[31]] = lIIIIIIIIllIllll("U/cNuiV4mYheTVAq2SzD2KGWZqIRPR/2H2DjA25C8tmXNQPaAH6UPw==", "HkLPY");
    lIllllllIlllll[lIlllllllIIIIl[32]] = lIIIIIIIIlllIIIl("HyxFETkHOQIWKR0uRQAlAmcNB3cQKAgJKgAmHgwpMSYHDT9Ie1FCbVJpS0I=", "rIkbM");
    lIllllllIlllll[lIlllllllIIIIl[33]] = lIIIIIIIIlllIIIl("AQNeEgUZFhkVFQMBXgMZHEgWWEsPChkCGisTGVtEVkZQQQ==", "lfpaq");
    lIllllllIlllll[lIlllllllIIIIl[34]] = lIIIIIIIIlllIIII("N22mWK30lDGYTWwPFVrxkiyNZ+0t7yXVelFEoZRfC3SkZ9xM6sMBBg==", "zsGps");
    lIllllllIlllll[lIlllllllIIIIl[35]] = lIIIIIIIIllIllll("W1CvNgTmY1T1rvQT4S4nwxizG0LjtQHV9OZQsOrP7HEHo8/I90pm+0RvJXmxGDqQ", "jOSJi");
    lIllllllIlllll[lIlllllllIIIIl[36]] = lIIIIIIIIlllIIIl("AjJYOD8aJx8/LwAwWCkjH3kQLnEdMhEiOBsyBAYkCzJMYwcFNgAqZAM2GCxkPCMEIiUIbDohKhk2WT4/BjtZByIcI00HIQ4hF2QnDjkRZBgbJR8lLFR+OiYuQCQCPjsGIxIkLEA1HjtkCWZGe3tfZ0Z7e19nRnt7X2dGe3tfZ1IGJAsyTXFrTw==", "oWvKK");
    lIllllllIlllll[lIlllllllIIIIl[37]] = lIIIIIIIIlllIIII("KetoeBQJFwSKtL9eA0OI866tCpL2Pe6CZytaB4bbLq3A3NYfzKqG3nr2k+W81BImPEmH7jHlDfBJy4qe1DOR/wlscX1Sa06+qDhTmHtiXTrlCW7kkiatpOUJbuSSJq2k2V+whVjvIGrnZSLGBZ7BmQ==", "DuAFN");
    lIllllllIlllll[lIlllllllIIIIl[38]] = lIIIIIIIIlllIIIl("AyZhHA4bMyYbHgEkYQ0SHm0pCkAcJigGCRomPSwVAiw9VVIiKS4ZG0EvLgEdQRA7HRMAJHQjFwtsPBsPHio7CxUJbC0HCkElf15BRw8iClUdNzofExonIAhVDCs/QBxfc39fSl5zf19KXnN/X0pec39fSl5nDAAWATEcCg4aKiEIQVRjbw==", "nCOoz");
    lIllllllIlllll[lIlllllllIIIIl[39]] = lIIIIIIIIlllIIII("eda/3TkU/Yhk2gzcAAfTG/qNDhlB7J9T68PSwD0xp17Gml1GT/8ByUmi8lq4gD2jhihlA5nfS6s=", "ubRuP");
    lIllllllIlllll[lIlllllllIIIIl[40]] = lIIIIIIIIlllIIIl("DBdMPyEUAgs4MQ4VTC49EVwEKW8SERAjOQ0hEikwBUhTdnVBUkJsdQ==", "arbLU");
    lIllllllIlllll[lIlllllllIIIIl[41]] = lIIIIIIIIlllIIIl("OQd8AzkhEjsEKTsFfBIlJEw0FXc7EjMTJCAbaEF3dEJyUG10", "TbRpM");
    lIlllllllIIIII = null;
  }
  
  private static void lIIIIIIIIlllIIll() {
    String str = (new Exception()).getStackTrace()[lIlllllllIIIIl[0]].getFileName();
    lIlllllllIIIII = str.substring(str.indexOf("ä") + lIlllllllIIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIIlllIIIl(String lllllllllllllllIllIlllllllIlIIII, String lllllllllllllllIllIlllllllIIllll) {
    lllllllllllllllIllIlllllllIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllllllIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllllllIIlllI = new StringBuilder();
    char[] lllllllllllllllIllIlllllllIIllIl = lllllllllllllllIllIlllllllIIllll.toCharArray();
    int lllllllllllllllIllIlllllllIIllII = lIlllllllIIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllllllIlIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllllIIIIl[0];
    while (lIIIIIIIIlllIlll(j, i)) {
      char lllllllllllllllIllIlllllllIlIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllllllIIllII++;
      j++;
      "".length();
      if (-" ".length() >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllllllIIlllI);
  }
  
  private static String lIIIIIIIIllIllll(String lllllllllllllllIllIlllllllIIlIII, String lllllllllllllllIllIlllllllIIIlll) {
    try {
      SecretKeySpec lllllllllllllllIllIlllllllIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllllllIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllllllIIlIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllllllIIlIlI.init(lIlllllllIIIIl[2], lllllllllllllllIllIlllllllIIlIll);
      return new String(lllllllllllllllIllIlllllllIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllllllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllllllIIlIIl) {
      lllllllllllllllIllIlllllllIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIlllIIII(String lllllllllllllllIllIlllllllIIIIll, String lllllllllllllllIllIlllllllIIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlllllllIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllllllIIIIlI.getBytes(StandardCharsets.UTF_8)), lIlllllllIIIIl[14]), "DES");
      Cipher lllllllllllllllIllIlllllllIIIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlllllllIIIlIl.init(lIlllllllIIIIl[2], lllllllllllllllIllIlllllllIIIllI);
      return new String(lllllllllllllllIllIlllllllIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllllllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllllllIIIlII) {
      lllllllllllllllIllIlllllllIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIlllIlII() {
    lIlllllllIIIIl = new int[43];
    lIlllllllIIIIl[0] = (0xE6 ^ 0x89 ^ (0xA0 ^ 0x95) << " ".length()) << " ".length() << " ".length() << " ".length() & (((0x26 ^ 0x23) << " ".length() ^ 0xCE ^ 0xC1) << " ".length() << " ".length() << " ".length() ^ -" ".length());
    lIlllllllIIIIl[1] = " ".length();
    lIlllllllIIIIl[2] = " ".length() << " ".length();
    lIlllllllIIIIl[3] = 0x2 ^ 0x17;
    lIlllllllIIIIl[4] = "   ".length();
    lIlllllllIIIIl[5] = " ".length() << " ".length() << " ".length();
    lIlllllllIIIIl[6] = 0xB3 ^ 0xB6;
    lIlllllllIIIIl[7] = ((0x52 ^ 0x2F) << " ".length() ^ 141 + 158 - 205 + 83) << " ".length();
    lIlllllllIIIIl[8] = ((0xBD ^ 0xBA) << "   ".length() ^ 0x32 ^ 0x13) << " ".length();
    lIlllllllIIIIl[9] = 106 + 92 - 30 + 1 + 115 + 22 - 50 + 102 - 194 + 126 - 114 + 69 + ((0x39 ^ 0x12) << " ".length() << " ".length());
    lIlllllllIIIIl[10] = "   ".length() << " ".length();
    lIlllllllIIIIl[11] = (0xBF ^ 0xA8) << " ".length();
    lIlllllllIIIIl[12] = 95 + 83 - 148 + 135 ^ (0xF4 ^ 0xA5) << " ".length();
    lIlllllllIIIIl[13] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllllllIIIIl[14] = " ".length() << "   ".length();
    lIlllllllIIIIl[15] = 0x13 ^ 0x1A;
    lIlllllllIIIIl[16] = (0x52 ^ 0x15) << " ".length();
    lIlllllllIIIIl[17] = ((0x63 ^ 0x48) << " ".length() << " ".length() ^ 5 + 25 - 5 + 144) << " ".length();
    lIlllllllIIIIl[18] = ((0xE4 ^ 0xC3) << " ".length() ^ 0x76 ^ 0x21) << "   ".length();
    lIlllllllIIIIl[19] = (0x1F ^ 0x3A ^ (0x9 ^ 0x2) << "   ".length()) << "   ".length();
    lIlllllllIIIIl[20] = 0x3A ^ 0x31;
    lIlllllllIIIIl[21] = "   ".length() << " ".length() << " ".length();
    lIlllllllIIIIl[22] = 0x72 ^ 0x7F;
    lIlllllllIIIIl[23] = (71 + 43 - 34 + 89 ^ (0x1D ^ 0x36) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllllllIIIIl[24] = (0x69 ^ 0x6E) << " ".length();
    lIlllllllIIIIl[25] = 0x3A ^ 0x35;
    lIlllllllIIIIl[26] = (0x79 ^ 0x70) << " ".length();
    lIlllllllIIIIl[27] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllllllIIIIl[28] = 78 + 108 - 180 + 137 ^ (0xFE ^ 0xB1) << " ".length();
    lIlllllllIIIIl[29] = 0x41 ^ 0x5E ^ "   ".length() << " ".length() << " ".length();
    lIlllllllIIIIl[30] = (0x55 ^ 0x5E) << " ".length();
    lIlllllllIIIIl[31] = 0xA0 ^ 0xB7;
    lIlllllllIIIIl[32] = "   ".length() << "   ".length();
    lIlllllllIIIIl[33] = 0x94 ^ 0x8D;
    lIlllllllIIIIl[34] = (0xB2 ^ 0x99 ^ (0xAF ^ 0xBC) << " ".length()) << " ".length();
    lIlllllllIIIIl[35] = 0x25 ^ 0x3E;
    lIlllllllIIIIl[36] = (0x94 ^ 0x93) << " ".length() << " ".length();
    lIlllllllIIIIl[37] = 0x1E ^ 0x23 ^ " ".length() << (0x56 ^ 0x53);
    lIlllllllIIIIl[38] = ((0x5 ^ 0xA) << "   ".length() ^ 0x75 ^ 0x2) << " ".length();
    lIlllllllIIIIl[39] = 0x73 ^ 0x6C;
    lIlllllllIIIIl[40] = " ".length() << ((0x60 ^ 0x71) << " ".length() << " ".length() ^ 0xF5 ^ 0xB4);
    lIlllllllIIIIl[41] = 0xD9 ^ 0xB0 ^ (0x84 ^ 0x8D) << "   ".length();
    lIlllllllIIIIl[42] = (0x79 ^ 0x68) << " ".length();
  }
  
  private static boolean lIIIIIIIIlllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIIlllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIIlllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */