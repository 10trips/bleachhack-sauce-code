package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBeacon;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockDynamicLiquid;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.BlockRedstoneComparator;
import net.minecraft.block.BlockRedstoneRepeater;
import net.minecraft.block.BlockStaticLiquid;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class f06 {
  public static final List blackList;
  
  public static final List shulkerList;
  
  private static final Minecraft mc;
  
  public static List<Block> emptyBlocks;
  
  public static List<Block> rightclickableBlocks;
  
  private static String[] llIIIlIIIlIlII;
  
  private static Class[] llIIIlIIIlIlIl;
  
  private static final String[] llIIlIlIIIIIIl;
  
  private static String[] llIIlIlIIIlllI;
  
  private static final int[] llIIlIlIIIllll;
  
  public static IBlockState getState(BlockPos lllllllllllllllIllIIlIllIlIIlIll) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: aload_0
    //   11: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   16: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIllIIlIllIlIIlIll	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static void placeBlock(BlockPos lllllllllllllllIllIIlIllIlIIlIII) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   5: astore_1
    //   6: aload_1
    //   7: arraylength
    //   8: istore_2
    //   9: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   12: iconst_0
    //   13: iaload
    //   14: istore_3
    //   15: iload_3
    //   16: iload_2
    //   17: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   20: ifeq -> 388
    //   23: aload_1
    //   24: iload_3
    //   25: aaload
    //   26: astore #4
    //   28: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   38: aload_0
    //   39: aload #4
    //   41: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   46: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   51: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   56: <illegal opcode> 7 : ()Lnet/minecraft/block/Block;
    //   61: <illegal opcode> 8 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   66: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   69: ifeq -> 369
    //   72: aload_0
    //   73: <illegal opcode> 9 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   78: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   81: ifeq -> 369
    //   84: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   87: iconst_1
    //   88: iaload
    //   89: newarray float
    //   91: dup
    //   92: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   95: iconst_0
    //   96: iaload
    //   97: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   102: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   107: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   112: fastore
    //   113: dup
    //   114: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   117: iconst_2
    //   118: iaload
    //   119: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   124: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   129: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   134: fastore
    //   135: astore #5
    //   137: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   142: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   147: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   152: new net/minecraft/network/play/client/CPacketEntityAction
    //   155: dup
    //   156: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   161: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   166: <illegal opcode> 14 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   171: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   174: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   179: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   184: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   189: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   194: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   199: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   204: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   209: aload_0
    //   210: aload #4
    //   212: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   217: aload #4
    //   219: <illegal opcode> 17 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   224: new net/minecraft/util/math/Vec3d
    //   227: dup
    //   228: aload_0
    //   229: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   232: <illegal opcode> 18 : ()Lnet/minecraft/util/EnumHand;
    //   237: <illegal opcode> 19 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   242: ldc ''
    //   244: invokevirtual length : ()I
    //   247: pop2
    //   248: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   253: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   258: <illegal opcode> 18 : ()Lnet/minecraft/util/EnumHand;
    //   263: <illegal opcode> 20 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   268: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   273: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   278: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   283: new net/minecraft/network/play/client/CPacketEntityAction
    //   286: dup
    //   287: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   292: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   297: <illegal opcode> 21 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   302: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   305: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   310: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   315: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   320: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   325: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   328: dup
    //   329: aload #5
    //   331: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   334: iconst_0
    //   335: iaload
    //   336: faload
    //   337: aload #5
    //   339: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   342: iconst_2
    //   343: iaload
    //   344: faload
    //   345: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   350: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   355: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   360: invokespecial <init> : (FFZ)V
    //   363: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   368: return
    //   369: iinc #3, 1
    //   372: ldc ''
    //   374: invokevirtual length : ()I
    //   377: pop
    //   378: ldc ' '
    //   380: invokevirtual length : ()I
    //   383: ineg
    //   384: ifle -> 15
    //   387: return
    //   388: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   137	232	5	lllllllllllllllIllIIlIllIlIIlIlI	[F
    //   28	341	4	lllllllllllllllIllIIlIllIlIIlIIl	Lnet/minecraft/util/EnumFacing;
    //   0	389	0	lllllllllllllllIllIIlIllIlIIlIII	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static void placePacketBlock(BlockPos lllllllllllllllIllIIlIllIlIIIlll, EnumFacing lllllllllllllllIllIIlIllIlIIIllI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   7: astore_2
    //   8: aload_1
    //   9: <illegal opcode> 17 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   14: astore_3
    //   15: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   20: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   25: <illegal opcode> 23 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   30: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   33: ifeq -> 78
    //   36: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   41: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   46: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   51: new net/minecraft/network/play/client/CPacketEntityAction
    //   54: dup
    //   55: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   60: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   65: <illegal opcode> 14 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   70: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   73: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   78: new net/minecraft/util/math/Vec3d
    //   81: dup
    //   82: aload_2
    //   83: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   86: ldc2_w 0.5
    //   89: ldc2_w 0.5
    //   92: ldc2_w 0.5
    //   95: <illegal opcode> 24 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   100: new net/minecraft/util/math/Vec3d
    //   103: dup
    //   104: aload_3
    //   105: <illegal opcode> 25 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   110: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   113: ldc2_w 0.5
    //   116: <illegal opcode> 26 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   121: <illegal opcode> 27 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   126: astore #4
    //   128: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   133: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   138: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   143: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   146: dup
    //   147: aload_0
    //   148: aload_1
    //   149: <illegal opcode> 18 : ()Lnet/minecraft/util/EnumHand;
    //   154: aload #4
    //   156: <illegal opcode> 28 : (Lnet/minecraft/util/math/Vec3d;)D
    //   161: d2f
    //   162: aload_0
    //   163: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)I
    //   168: i2f
    //   169: fsub
    //   170: aload #4
    //   172: <illegal opcode> 30 : (Lnet/minecraft/util/math/Vec3d;)D
    //   177: d2f
    //   178: aload_0
    //   179: <illegal opcode> 31 : (Lnet/minecraft/util/math/BlockPos;)I
    //   184: i2f
    //   185: fsub
    //   186: aload #4
    //   188: <illegal opcode> 32 : (Lnet/minecraft/util/math/Vec3d;)D
    //   193: d2f
    //   194: aload_0
    //   195: <illegal opcode> 33 : (Lnet/minecraft/util/math/BlockPos;)I
    //   200: i2f
    //   201: fsub
    //   202: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   205: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   210: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   215: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   220: <illegal opcode> 18 : ()Lnet/minecraft/util/EnumHand;
    //   225: <illegal opcode> 20 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   230: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	231	0	lllllllllllllllIllIIlIllIlIIIlll	Lnet/minecraft/util/math/BlockPos;
    //   0	231	1	lllllllllllllllIllIIlIllIlIIIllI	Lnet/minecraft/util/EnumFacing;
    //   8	223	2	lllllllllllllllIllIIlIllIlIIIlIl	Lnet/minecraft/util/math/BlockPos;
    //   15	216	3	lllllllllllllllIllIIlIllIlIIIlII	Lnet/minecraft/util/EnumFacing;
    //   128	103	4	lllllllllllllllIllIIlIllIlIIIIll	Lnet/minecraft/util/math/Vec3d;
  }
  
  public static void openBlock(BlockPos lllllllllllllllIllIIlIllIlIIIIII) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   5: astore_1
    //   6: aload_1
    //   7: astore_2
    //   8: aload_2
    //   9: arraylength
    //   10: istore_3
    //   11: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   14: iconst_0
    //   15: iaload
    //   16: istore #4
    //   18: iload #4
    //   20: iload_3
    //   21: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   24: ifeq -> 158
    //   27: aload_2
    //   28: iload #4
    //   30: aaload
    //   31: astore #5
    //   33: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   38: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   43: aload_0
    //   44: aload #5
    //   46: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   51: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   56: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   61: astore #6
    //   63: <illegal opcode> 34 : ()Ljava/util/List;
    //   68: aload #6
    //   70: <illegal opcode> 35 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   75: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   78: ifeq -> 144
    //   81: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   86: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   91: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   96: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   101: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   106: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   111: aload_0
    //   112: aload #5
    //   114: <illegal opcode> 17 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   119: new net/minecraft/util/math/Vec3d
    //   122: dup
    //   123: aload_0
    //   124: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   127: <illegal opcode> 18 : ()Lnet/minecraft/util/EnumHand;
    //   132: <illegal opcode> 19 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   137: ldc ''
    //   139: invokevirtual length : ()I
    //   142: pop2
    //   143: return
    //   144: iinc #4, 1
    //   147: ldc ''
    //   149: invokevirtual length : ()I
    //   152: pop
    //   153: aconst_null
    //   154: ifnull -> 18
    //   157: return
    //   158: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   63	81	6	lllllllllllllllIllIIlIllIlIIIIlI	Lnet/minecraft/block/Block;
    //   33	111	5	lllllllllllllllIllIIlIllIlIIIIIl	Lnet/minecraft/util/EnumFacing;
    //   0	159	0	lllllllllllllllIllIIlIllIlIIIIII	Lnet/minecraft/util/math/BlockPos;
    //   6	153	1	lllllllllllllllIllIIlIllIIllllll	[Lnet/minecraft/util/EnumFacing;
  }
  
  public static boolean isIntercepted(BlockPos lllllllllllllllIllIIlIllIIllllIl) {
    // Byte code:
    //   0: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 36 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 37 : (Ljava/util/List;)Ljava/util/Iterator;
    //   20: astore_1
    //   21: aload_1
    //   22: <illegal opcode> 38 : (Ljava/util/Iterator;)Z
    //   27: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   30: ifeq -> 124
    //   33: aload_1
    //   34: <illegal opcode> 39 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast net/minecraft/entity/Entity
    //   42: astore_2
    //   43: new net/minecraft/util/math/AxisAlignedBB
    //   46: dup
    //   47: aload_0
    //   48: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   51: aload_2
    //   52: <illegal opcode> 40 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   57: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;Lnet/minecraft/util/math/AxisAlignedBB;)Z
    //   62: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   65: ifeq -> 74
    //   68: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   71: iconst_2
    //   72: iaload
    //   73: ireturn
    //   74: ldc ''
    //   76: invokevirtual length : ()I
    //   79: pop
    //   80: sipush #138
    //   83: sipush #159
    //   86: ixor
    //   87: ldc ' '
    //   89: invokevirtual length : ()I
    //   92: ishl
    //   93: bipush #42
    //   95: bipush #63
    //   97: ixor
    //   98: ldc ' '
    //   100: invokevirtual length : ()I
    //   103: ishl
    //   104: iconst_m1
    //   105: ixor
    //   106: iand
    //   107: ifge -> 21
    //   110: bipush #26
    //   112: bipush #45
    //   114: ixor
    //   115: bipush #87
    //   117: bipush #96
    //   119: ixor
    //   120: iconst_m1
    //   121: ixor
    //   122: iand
    //   123: ireturn
    //   124: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   127: iconst_0
    //   128: iaload
    //   129: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	31	2	lllllllllllllllIllIIlIllIIlllllI	Lnet/minecraft/entity/Entity;
    //   0	130	0	lllllllllllllllIllIIlIllIIllllIl	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static boolean checkForNeighbours(BlockPos lllllllllllllllIllIIlIllIIlllIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 42 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   6: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   9: ifeq -> 149
    //   12: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   17: astore_1
    //   18: aload_1
    //   19: arraylength
    //   20: istore_2
    //   21: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   24: iconst_0
    //   25: iaload
    //   26: istore_3
    //   27: iload_3
    //   28: iload_2
    //   29: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   32: ifeq -> 143
    //   35: aload_1
    //   36: iload_3
    //   37: aaload
    //   38: astore #4
    //   40: aload_0
    //   41: aload #4
    //   43: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   48: astore #5
    //   50: aload #5
    //   52: <illegal opcode> 42 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   57: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   60: ifeq -> 69
    //   63: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   66: iconst_2
    //   67: iaload
    //   68: ireturn
    //   69: iinc #3, 1
    //   72: ldc ''
    //   74: invokevirtual length : ()I
    //   77: pop
    //   78: ldc_w '   '
    //   81: invokevirtual length : ()I
    //   84: ineg
    //   85: ifle -> 27
    //   88: sipush #152
    //   91: sipush #165
    //   94: ixor
    //   95: ldc ' '
    //   97: invokevirtual length : ()I
    //   100: ishl
    //   101: bipush #123
    //   103: bipush #48
    //   105: ixor
    //   106: ixor
    //   107: sipush #139
    //   110: sipush #166
    //   113: ixor
    //   114: sipush #192
    //   117: sipush #199
    //   120: ixor
    //   121: ldc ' '
    //   123: invokevirtual length : ()I
    //   126: ldc ' '
    //   128: invokevirtual length : ()I
    //   131: ishl
    //   132: ishl
    //   133: ixor
    //   134: ldc ' '
    //   136: invokevirtual length : ()I
    //   139: ineg
    //   140: ixor
    //   141: iand
    //   142: ireturn
    //   143: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   146: iconst_0
    //   147: iaload
    //   148: ireturn
    //   149: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   152: iconst_2
    //   153: iaload
    //   154: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   50	19	5	lllllllllllllllIllIIlIllIIllllII	Lnet/minecraft/util/math/BlockPos;
    //   40	29	4	lllllllllllllllIllIIlIllIIlllIll	Lnet/minecraft/util/EnumFacing;
    //   0	155	0	lllllllllllllllIllIIlIllIIlllIlI	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static boolean canPlaceBlock(BlockPos lllllllllllllllIllIIlIllIIllIlll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 43 : (Lnet/minecraft/util/math/BlockPos;)Z
    //   6: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   9: ifeq -> 269
    //   12: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   17: astore_1
    //   18: aload_1
    //   19: astore_2
    //   20: aload_2
    //   21: arraylength
    //   22: istore_3
    //   23: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   26: iconst_0
    //   27: iaload
    //   28: istore #4
    //   30: iload #4
    //   32: iload_3
    //   33: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   36: ifeq -> 269
    //   39: aload_2
    //   40: iload #4
    //   42: aaload
    //   43: astore #5
    //   45: <illegal opcode> 34 : ()Ljava/util/List;
    //   50: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   55: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   60: aload_0
    //   61: aload #5
    //   63: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   68: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   73: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   78: <illegal opcode> 35 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   83: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   86: ifeq -> 216
    //   89: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   94: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   99: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   104: <illegal opcode> 44 : (Lnet/minecraft/client/Minecraft;)F
    //   109: <illegal opcode> 45 : (Lnet/minecraft/client/entity/EntityPlayerSP;F)Lnet/minecraft/util/math/Vec3d;
    //   114: new net/minecraft/util/math/Vec3d
    //   117: dup
    //   118: aload_0
    //   119: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)I
    //   124: i2d
    //   125: ldc2_w 0.5
    //   128: dadd
    //   129: aload #5
    //   131: <illegal opcode> 46 : (Lnet/minecraft/util/EnumFacing;)I
    //   136: i2d
    //   137: ldc2_w 0.5
    //   140: dmul
    //   141: dadd
    //   142: aload_0
    //   143: <illegal opcode> 31 : (Lnet/minecraft/util/math/BlockPos;)I
    //   148: i2d
    //   149: ldc2_w 0.5
    //   152: dadd
    //   153: aload #5
    //   155: <illegal opcode> 47 : (Lnet/minecraft/util/EnumFacing;)I
    //   160: i2d
    //   161: ldc2_w 0.5
    //   164: dmul
    //   165: dadd
    //   166: aload_0
    //   167: <illegal opcode> 33 : (Lnet/minecraft/util/math/BlockPos;)I
    //   172: i2d
    //   173: ldc2_w 0.5
    //   176: dadd
    //   177: aload #5
    //   179: <illegal opcode> 48 : (Lnet/minecraft/util/EnumFacing;)I
    //   184: i2d
    //   185: ldc2_w 0.5
    //   188: dmul
    //   189: dadd
    //   190: invokespecial <init> : (DDD)V
    //   193: <illegal opcode> 49 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)D
    //   198: ldc2_w 4.25
    //   201: invokestatic lIIIIlllIlIIIlIl : (DD)I
    //   204: invokestatic lIIIIlllIlIIIllI : (I)Z
    //   207: ifeq -> 216
    //   210: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   213: iconst_2
    //   214: iaload
    //   215: ireturn
    //   216: iinc #4, 1
    //   219: ldc ''
    //   221: invokevirtual length : ()I
    //   224: pop
    //   225: aconst_null
    //   226: ifnull -> 30
    //   229: ldc ' '
    //   231: invokevirtual length : ()I
    //   234: ldc_w '   '
    //   237: invokevirtual length : ()I
    //   240: ldc ' '
    //   242: invokevirtual length : ()I
    //   245: ishl
    //   246: ishl
    //   247: ldc ' '
    //   249: invokevirtual length : ()I
    //   252: ldc_w '   '
    //   255: invokevirtual length : ()I
    //   258: ldc ' '
    //   260: invokevirtual length : ()I
    //   263: ishl
    //   264: ishl
    //   265: iconst_m1
    //   266: ixor
    //   267: iand
    //   268: ireturn
    //   269: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   272: iconst_0
    //   273: iaload
    //   274: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   45	171	5	lllllllllllllllIllIIlIllIIlllIIl	Lnet/minecraft/util/EnumFacing;
    //   18	251	1	lllllllllllllllIllIIlIllIIlllIII	[Lnet/minecraft/util/EnumFacing;
    //   0	275	0	lllllllllllllllIllIIlIllIIllIlll	Lnet/minecraft/util/math/BlockPos;
  }
  
  private static boolean hasNeighbour(BlockPos lllllllllllllllIllIIlIllIIllIlII) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   5: astore_1
    //   6: aload_1
    //   7: arraylength
    //   8: istore_2
    //   9: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   12: iconst_0
    //   13: iaload
    //   14: istore_3
    //   15: iload_3
    //   16: iload_2
    //   17: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   20: ifeq -> 173
    //   23: aload_1
    //   24: iload_3
    //   25: aaload
    //   26: astore #4
    //   28: aload_0
    //   29: aload #4
    //   31: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   36: astore #5
    //   38: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   43: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   48: aload #5
    //   50: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   55: <illegal opcode> 50 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/material/Material;
    //   60: <illegal opcode> 51 : (Lnet/minecraft/block/material/Material;)Z
    //   65: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   68: ifeq -> 77
    //   71: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   74: iconst_2
    //   75: iaload
    //   76: ireturn
    //   77: iinc #3, 1
    //   80: ldc ''
    //   82: invokevirtual length : ()I
    //   85: pop
    //   86: bipush #85
    //   88: bipush #64
    //   90: ixor
    //   91: ldc ' '
    //   93: invokevirtual length : ()I
    //   96: ldc ' '
    //   98: invokevirtual length : ()I
    //   101: ldc ' '
    //   103: invokevirtual length : ()I
    //   106: ldc ' '
    //   108: invokevirtual length : ()I
    //   111: ishl
    //   112: ishl
    //   113: ishl
    //   114: ixor
    //   115: ifgt -> 15
    //   118: bipush #64
    //   120: bipush #57
    //   122: ixor
    //   123: ldc ' '
    //   125: invokevirtual length : ()I
    //   128: ishl
    //   129: bipush #55
    //   131: bipush #84
    //   133: iadd
    //   134: sipush #138
    //   137: isub
    //   138: sipush #166
    //   141: iadd
    //   142: ixor
    //   143: sipush #146
    //   146: sipush #151
    //   149: ixor
    //   150: ldc ' '
    //   152: invokevirtual length : ()I
    //   155: ishl
    //   156: sipush #217
    //   159: sipush #134
    //   162: ixor
    //   163: ixor
    //   164: ldc ' '
    //   166: invokevirtual length : ()I
    //   169: ineg
    //   170: ixor
    //   171: iand
    //   172: ireturn
    //   173: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   176: iconst_0
    //   177: iaload
    //   178: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   38	39	5	lllllllllllllllIllIIlIllIIllIllI	Lnet/minecraft/util/math/BlockPos;
    //   28	49	4	lllllllllllllllIllIIlIllIIllIlIl	Lnet/minecraft/util/EnumFacing;
    //   0	179	0	lllllllllllllllIllIIlIllIIllIlII	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static Block getBlock(BlockPos lllllllllllllllIllIIlIllIIllIIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 52 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   6: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIIlIllIIllIIll	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static boolean canBeClicked(BlockPos lllllllllllllllIllIIlIllIIllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 53 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/Block;
    //   6: aload_0
    //   7: <illegal opcode> 52 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   12: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   15: iconst_0
    //   16: iaload
    //   17: <illegal opcode> 54 : (Lnet/minecraft/block/Block;Lnet/minecraft/block/state/IBlockState;Z)Z
    //   22: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	23	0	lllllllllllllllIllIIlIllIIllIIlI	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static void faceVectorPacketInstant(Vec3d lllllllllllllllIllIIlIllIIllIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 55 : (Lnet/minecraft/util/math/Vec3d;)[F
    //   6: astore_1
    //   7: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   12: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   17: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   22: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   25: dup
    //   26: aload_1
    //   27: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   30: iconst_0
    //   31: iaload
    //   32: faload
    //   33: aload_1
    //   34: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   37: iconst_2
    //   38: iaload
    //   39: faload
    //   40: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   45: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   50: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   55: invokespecial <init> : (FFZ)V
    //   58: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   63: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	64	0	lllllllllllllllIllIIlIllIIllIIIl	Lnet/minecraft/util/math/Vec3d;
    //   7	57	1	lllllllllllllllIllIIlIllIIllIIII	[F
  }
  
  private static float[] getNeededRotations2(Vec3d lllllllllllllllIllIIlIllIIlIllll) {
    // Byte code:
    //   0: <illegal opcode> 56 : ()Lnet/minecraft/util/math/Vec3d;
    //   5: astore_1
    //   6: aload_0
    //   7: <illegal opcode> 28 : (Lnet/minecraft/util/math/Vec3d;)D
    //   12: aload_1
    //   13: <illegal opcode> 28 : (Lnet/minecraft/util/math/Vec3d;)D
    //   18: dsub
    //   19: dstore_2
    //   20: aload_0
    //   21: <illegal opcode> 30 : (Lnet/minecraft/util/math/Vec3d;)D
    //   26: aload_1
    //   27: <illegal opcode> 30 : (Lnet/minecraft/util/math/Vec3d;)D
    //   32: dsub
    //   33: dstore #4
    //   35: aload_0
    //   36: <illegal opcode> 32 : (Lnet/minecraft/util/math/Vec3d;)D
    //   41: aload_1
    //   42: <illegal opcode> 32 : (Lnet/minecraft/util/math/Vec3d;)D
    //   47: dsub
    //   48: dstore #6
    //   50: dload_2
    //   51: dload_2
    //   52: dmul
    //   53: dload #6
    //   55: dload #6
    //   57: dmul
    //   58: dadd
    //   59: <illegal opcode> 57 : (D)D
    //   64: dstore #8
    //   66: dload #6
    //   68: dload_2
    //   69: <illegal opcode> 58 : (DD)D
    //   74: <illegal opcode> 59 : (D)D
    //   79: d2f
    //   80: ldc_w 90.0
    //   83: fsub
    //   84: fstore #10
    //   86: dload #4
    //   88: dload #8
    //   90: <illegal opcode> 58 : (DD)D
    //   95: <illegal opcode> 59 : (D)D
    //   100: dneg
    //   101: d2f
    //   102: fstore #11
    //   104: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   107: iconst_1
    //   108: iaload
    //   109: newarray float
    //   111: dup
    //   112: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   115: iconst_0
    //   116: iaload
    //   117: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   122: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   127: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   132: fload #10
    //   134: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   139: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   144: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   149: fsub
    //   150: <illegal opcode> 60 : (F)F
    //   155: fadd
    //   156: fastore
    //   157: dup
    //   158: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   161: iconst_2
    //   162: iaload
    //   163: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   168: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   173: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   178: fload #11
    //   180: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   185: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   190: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   195: fsub
    //   196: <illegal opcode> 60 : (F)F
    //   201: fadd
    //   202: fastore
    //   203: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	204	0	lllllllllllllllIllIIlIllIIlIllll	Lnet/minecraft/util/math/Vec3d;
    //   6	198	1	lllllllllllllllIllIIlIllIIlIlllI	Lnet/minecraft/util/math/Vec3d;
    //   20	184	2	lllllllllllllllIllIIlIllIIlIllIl	D
    //   35	169	4	lllllllllllllllIllIIlIllIIlIllII	D
    //   50	154	6	lllllllllllllllIllIIlIllIIlIlIll	D
    //   66	138	8	lllllllllllllllIllIIlIllIIlIlIlI	D
    //   86	118	10	lllllllllllllllIllIIlIllIIlIlIIl	F
    //   104	100	11	lllllllllllllllIllIIlIllIIlIlIII	F
  }
  
  public static Vec3d getEyesPos() {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   19: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   34: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   39: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   44: <illegal opcode> 63 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   49: f2d
    //   50: dadd
    //   51: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   66: invokespecial <init> : (DDD)V
    //   69: areturn
  }
  
  public static List<BlockPos> getCircle(BlockPos lllllllllllllllIllIIlIllIIlIIIll, int lllllllllllllllIllIIlIllIIlIIIlI, float lllllllllllllllIllIIlIllIIlIIIIl, boolean lllllllllllllllIllIIlIllIIlIIIII) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_0
    //   10: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;)I
    //   15: istore #5
    //   17: aload_0
    //   18: <illegal opcode> 33 : (Lnet/minecraft/util/math/BlockPos;)I
    //   23: istore #6
    //   25: iload #5
    //   27: fload_2
    //   28: f2i
    //   29: isub
    //   30: istore #7
    //   32: iload #7
    //   34: i2f
    //   35: iload #5
    //   37: i2f
    //   38: fload_2
    //   39: fadd
    //   40: invokestatic lIIIIlllIlIIIlll : (FF)I
    //   43: invokestatic lIIIIlllIlIIIllI : (I)Z
    //   46: ifeq -> 242
    //   49: iload #6
    //   51: fload_2
    //   52: f2i
    //   53: isub
    //   54: istore #8
    //   56: iload #8
    //   58: i2f
    //   59: iload #6
    //   61: i2f
    //   62: fload_2
    //   63: fadd
    //   64: invokestatic lIIIIlllIlIIIlll : (FF)I
    //   67: invokestatic lIIIIlllIlIIIllI : (I)Z
    //   70: ifeq -> 189
    //   73: iload #5
    //   75: iload #7
    //   77: isub
    //   78: iload #5
    //   80: iload #7
    //   82: isub
    //   83: imul
    //   84: iload #6
    //   86: iload #8
    //   88: isub
    //   89: iload #6
    //   91: iload #8
    //   93: isub
    //   94: imul
    //   95: iadd
    //   96: i2d
    //   97: dstore #9
    //   99: dload #9
    //   101: fload_2
    //   102: fload_2
    //   103: fmul
    //   104: f2d
    //   105: invokestatic lIIIIlllIlIIlIII : (DD)I
    //   108: invokestatic lIIIIlllIlIIlIlI : (I)Z
    //   111: ifeq -> 169
    //   114: iload_3
    //   115: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   118: ifeq -> 140
    //   121: dload #9
    //   123: fload_2
    //   124: fconst_1
    //   125: fsub
    //   126: fload_2
    //   127: fconst_1
    //   128: fsub
    //   129: fmul
    //   130: f2d
    //   131: invokestatic lIIIIlllIlIIlIIl : (DD)I
    //   134: invokestatic lIIIIlllIlIIlIll : (I)Z
    //   137: ifeq -> 169
    //   140: new net/minecraft/util/math/BlockPos
    //   143: dup
    //   144: iload #7
    //   146: iload_1
    //   147: iload #8
    //   149: invokespecial <init> : (III)V
    //   152: astore #11
    //   154: aload #4
    //   156: aload #11
    //   158: <illegal opcode> 65 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   163: ldc ''
    //   165: invokevirtual length : ()I
    //   168: pop2
    //   169: iinc #8, 1
    //   172: ldc ''
    //   174: invokevirtual length : ()I
    //   177: pop
    //   178: ldc_w '   '
    //   181: invokevirtual length : ()I
    //   184: ifgt -> 56
    //   187: aconst_null
    //   188: areturn
    //   189: iinc #7, 1
    //   192: ldc ''
    //   194: invokevirtual length : ()I
    //   197: pop
    //   198: ldc_w '   '
    //   201: invokevirtual length : ()I
    //   204: ldc ' '
    //   206: invokevirtual length : ()I
    //   209: ldc ' '
    //   211: invokevirtual length : ()I
    //   214: ishl
    //   215: ishl
    //   216: ldc_w '   '
    //   219: invokevirtual length : ()I
    //   222: ldc ' '
    //   224: invokevirtual length : ()I
    //   227: ldc ' '
    //   229: invokevirtual length : ()I
    //   232: ishl
    //   233: ishl
    //   234: iconst_m1
    //   235: ixor
    //   236: iand
    //   237: ifeq -> 32
    //   240: aconst_null
    //   241: areturn
    //   242: aload #4
    //   244: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   154	15	11	lllllllllllllllIllIIlIllIIlIIlll	Lnet/minecraft/util/math/BlockPos;
    //   99	70	9	lllllllllllllllIllIIlIllIIlIIllI	D
    //   56	133	8	lllllllllllllllIllIIlIllIIlIIlIl	I
    //   32	210	7	lllllllllllllllIllIIlIllIIlIIlII	I
    //   0	245	0	lllllllllllllllIllIIlIllIIlIIIll	Lnet/minecraft/util/math/BlockPos;
    //   0	245	1	lllllllllllllllIllIIlIllIIlIIIlI	I
    //   0	245	2	lllllllllllllllIllIIlIllIIlIIIIl	F
    //   0	245	3	lllllllllllllllIllIIlIllIIlIIIII	Z
    //   9	236	4	lllllllllllllllIllIIlIllIIIlllll	Ljava/util/List;
    //   17	228	5	lllllllllllllllIllIIlIllIIIllllI	I
    //   25	220	6	lllllllllllllllIllIIlIllIIIlllIl	I
    // Local variable type table:
    //   start	length	slot	name	signature
    //   9	236	4	lllllllllllllllIllIIlIllIIIlllll	Ljava/util/List<Lnet/minecraft/util/math/BlockPos;>;
  }
  
  public static EnumFacing getPlaceableSide(BlockPos lllllllllllllllIllIIlIllIIIllIIl) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()[Lnet/minecraft/util/EnumFacing;
    //   5: astore_1
    //   6: aload_1
    //   7: arraylength
    //   8: istore_2
    //   9: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   12: iconst_0
    //   13: iaload
    //   14: istore_3
    //   15: iload_3
    //   16: iload_2
    //   17: invokestatic lIIIIlllIlIIIIlI : (II)Z
    //   20: ifeq -> 199
    //   23: aload_1
    //   24: iload_3
    //   25: aaload
    //   26: astore #4
    //   28: aload_0
    //   29: aload #4
    //   31: <illegal opcode> 5 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   36: astore #5
    //   38: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   43: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   48: aload #5
    //   50: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   55: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   60: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   65: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   70: aload #5
    //   72: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   77: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   80: iconst_0
    //   81: iaload
    //   82: <illegal opcode> 54 : (Lnet/minecraft/block/Block;Lnet/minecraft/block/state/IBlockState;Z)Z
    //   87: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   90: ifeq -> 135
    //   93: ldc ''
    //   95: invokevirtual length : ()I
    //   98: pop
    //   99: ldc ' '
    //   101: invokevirtual length : ()I
    //   104: ldc ' '
    //   106: invokevirtual length : ()I
    //   109: ldc ' '
    //   111: invokevirtual length : ()I
    //   114: ishl
    //   115: ishl
    //   116: sipush #162
    //   119: sipush #149
    //   122: ixor
    //   123: bipush #51
    //   125: iconst_4
    //   126: ixor
    //   127: iconst_m1
    //   128: ixor
    //   129: iand
    //   130: if_icmpge -> 175
    //   133: aconst_null
    //   134: areturn
    //   135: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   140: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   145: aload #5
    //   147: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   152: astore #6
    //   154: aload #6
    //   156: <illegal opcode> 50 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/material/Material;
    //   161: <illegal opcode> 51 : (Lnet/minecraft/block/material/Material;)Z
    //   166: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   169: ifeq -> 175
    //   172: aload #4
    //   174: areturn
    //   175: iinc #3, 1
    //   178: ldc ''
    //   180: invokevirtual length : ()I
    //   183: pop
    //   184: ldc ' '
    //   186: invokevirtual length : ()I
    //   189: ldc ' '
    //   191: invokevirtual length : ()I
    //   194: if_icmpeq -> 15
    //   197: aconst_null
    //   198: areturn
    //   199: aconst_null
    //   200: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   38	137	5	lllllllllllllllIllIIlIllIIIlllII	Lnet/minecraft/util/math/BlockPos;
    //   154	21	6	lllllllllllllllIllIIlIllIIIllIll	Lnet/minecraft/block/state/IBlockState;
    //   28	147	4	lllllllllllllllIllIIlIllIIIllIlI	Lnet/minecraft/util/EnumFacing;
    //   0	201	0	lllllllllllllllIllIIlIllIIIllIIl	Lnet/minecraft/util/math/BlockPos;
  }
  
  public static boolean isBlockEmpty(BlockPos lllllllllllllllIllIIlIllIIIlIlIl) {
    // Byte code:
    //   0: <illegal opcode> 34 : ()Ljava/util/List;
    //   5: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   10: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   15: aload_0
    //   16: <illegal opcode> 2 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   21: <illegal opcode> 6 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   26: <illegal opcode> 35 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   31: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   34: ifeq -> 123
    //   37: new net/minecraft/util/math/AxisAlignedBB
    //   40: dup
    //   41: aload_0
    //   42: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   45: astore_1
    //   46: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   51: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   56: <illegal opcode> 36 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   61: <illegal opcode> 37 : (Ljava/util/List;)Ljava/util/Iterator;
    //   66: astore_2
    //   67: aload_2
    //   68: <illegal opcode> 38 : (Ljava/util/Iterator;)Z
    //   73: invokestatic lIIIIlllIlIIIIll : (I)Z
    //   76: ifeq -> 85
    //   79: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   82: iconst_2
    //   83: iaload
    //   84: ireturn
    //   85: aload_2
    //   86: <illegal opcode> 39 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   91: checkcast net/minecraft/entity/Entity
    //   94: astore_3
    //   95: aload_3
    //   96: instanceof net/minecraft/entity/EntityLivingBase
    //   99: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   102: ifeq -> 67
    //   105: aload_1
    //   106: aload_3
    //   107: <illegal opcode> 40 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   112: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;Lnet/minecraft/util/math/AxisAlignedBB;)Z
    //   117: invokestatic lIIIIlllIlIIIlII : (I)Z
    //   120: ifeq -> 67
    //   123: ldc ''
    //   125: invokevirtual length : ()I
    //   128: pop
    //   129: ldc_w '  '
    //   132: invokevirtual length : ()I
    //   135: ineg
    //   136: iflt -> 190
    //   139: bipush #115
    //   141: bipush #7
    //   143: iadd
    //   144: iconst_1
    //   145: isub
    //   146: bipush #54
    //   148: iadd
    //   149: bipush #50
    //   151: bipush #111
    //   153: ixor
    //   154: ldc ' '
    //   156: invokevirtual length : ()I
    //   159: ishl
    //   160: ixor
    //   161: sipush #151
    //   164: sipush #158
    //   167: ixor
    //   168: ldc ' '
    //   170: invokevirtual length : ()I
    //   173: ishl
    //   174: bipush #126
    //   176: bipush #121
    //   178: ixor
    //   179: ixor
    //   180: ldc ' '
    //   182: invokevirtual length : ()I
    //   185: ineg
    //   186: ixor
    //   187: iand
    //   188: ireturn
    //   189: astore_1
    //   190: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   193: iconst_0
    //   194: iaload
    //   195: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   46	77	1	lllllllllllllllIllIIlIllIIIllIII	Lnet/minecraft/util/math/AxisAlignedBB;
    //   67	56	2	lllllllllllllllIllIIlIllIIIlIlll	Ljava/util/Iterator;
    //   95	28	3	lllllllllllllllIllIIlIllIIIlIllI	Lnet/minecraft/entity/Entity;
    //   0	196	0	lllllllllllllllIllIIlIllIIIlIlIl	Lnet/minecraft/util/math/BlockPos;
    // Exception table:
    //   from	to	target	type
    //   0	84	189	java/lang/Exception
    //   85	123	189	java/lang/Exception
  }
  
  public static void rotatePacket(double lllllllllllllllIllIIlIllIIIlIlII, double lllllllllllllllIllIIlIllIIIlIIll, double lllllllllllllllIllIIlIllIIIlIIlI) {
    // Byte code:
    //   0: dload_0
    //   1: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   6: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   11: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   16: dsub
    //   17: dstore #6
    //   19: dload_2
    //   20: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   25: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   30: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   35: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   40: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   45: <illegal opcode> 63 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   50: f2d
    //   51: dadd
    //   52: dsub
    //   53: dstore #8
    //   55: dload #4
    //   57: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   62: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   67: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   72: dsub
    //   73: dstore #10
    //   75: dload #6
    //   77: dload #6
    //   79: dmul
    //   80: dload #10
    //   82: dload #10
    //   84: dmul
    //   85: dadd
    //   86: <illegal opcode> 57 : (D)D
    //   91: dstore #12
    //   93: dload #10
    //   95: dload #6
    //   97: <illegal opcode> 58 : (DD)D
    //   102: <illegal opcode> 59 : (D)D
    //   107: d2f
    //   108: ldc_w 90.0
    //   111: fsub
    //   112: fstore #14
    //   114: dload #8
    //   116: dload #12
    //   118: <illegal opcode> 58 : (DD)D
    //   123: <illegal opcode> 59 : (D)D
    //   128: dneg
    //   129: d2f
    //   130: fstore #15
    //   132: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   137: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   142: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   147: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   150: dup
    //   151: fload #14
    //   153: fload #15
    //   155: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   160: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   165: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   170: invokespecial <init> : (FFZ)V
    //   173: <illegal opcode> 15 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   178: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	179	0	lllllllllllllllIllIIlIllIIIlIlII	D
    //   0	179	2	lllllllllllllllIllIIlIllIIIlIIll	D
    //   0	179	4	lllllllllllllllIllIIlIllIIIlIIlI	D
    //   19	160	6	lllllllllllllllIllIIlIllIIIlIIIl	D
    //   55	124	8	lllllllllllllllIllIIlIllIIIlIIII	D
    //   75	104	10	lllllllllllllllIllIIlIllIIIIllll	D
    //   93	86	12	lllllllllllllllIllIIlIllIIIIlllI	D
    //   114	65	14	lllllllllllllllIllIIlIllIIIIllIl	F
    //   132	47	15	lllllllllllllllIllIIlIllIIIIllII	F
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIlllIlIIIIIl : ()V
    //   3: invokestatic lIIIIlllIlIIIIII : ()V
    //   6: invokestatic lIIIIlllIIllllll : ()V
    //   9: invokestatic lIIIIlllIIIlIlII : ()V
    //   12: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   17: putstatic me/stupitdog/bhp/f06.mc : Lnet/minecraft/client/Minecraft;
    //   20: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   23: iconst_3
    //   24: iaload
    //   25: anewarray net/minecraft/block/Block
    //   28: dup
    //   29: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   32: iconst_0
    //   33: iaload
    //   34: <illegal opcode> 7 : ()Lnet/minecraft/block/Block;
    //   39: aastore
    //   40: dup
    //   41: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   44: iconst_2
    //   45: iaload
    //   46: <illegal opcode> 66 : ()Lnet/minecraft/block/BlockDynamicLiquid;
    //   51: aastore
    //   52: dup
    //   53: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   56: iconst_1
    //   57: iaload
    //   58: <illegal opcode> 67 : ()Lnet/minecraft/block/BlockStaticLiquid;
    //   63: aastore
    //   64: dup
    //   65: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   68: iconst_4
    //   69: iaload
    //   70: <illegal opcode> 68 : ()Lnet/minecraft/block/BlockDynamicLiquid;
    //   75: aastore
    //   76: dup
    //   77: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   80: iconst_5
    //   81: iaload
    //   82: <illegal opcode> 69 : ()Lnet/minecraft/block/BlockStaticLiquid;
    //   87: aastore
    //   88: dup
    //   89: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   92: bipush #6
    //   94: iaload
    //   95: <illegal opcode> 70 : ()Lnet/minecraft/block/Block;
    //   100: aastore
    //   101: dup
    //   102: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   105: bipush #7
    //   107: iaload
    //   108: <illegal opcode> 71 : ()Lnet/minecraft/block/Block;
    //   113: aastore
    //   114: dup
    //   115: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   118: bipush #8
    //   120: iaload
    //   121: <illegal opcode> 72 : ()Lnet/minecraft/block/BlockTallGrass;
    //   126: aastore
    //   127: dup
    //   128: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   131: bipush #9
    //   133: iaload
    //   134: <illegal opcode> 73 : ()Lnet/minecraft/block/BlockFire;
    //   139: aastore
    //   140: <illegal opcode> 74 : ([Ljava/lang/Object;)Ljava/util/List;
    //   145: <illegal opcode> 75 : (Ljava/util/List;)V
    //   150: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   153: bipush #10
    //   155: iaload
    //   156: anewarray net/minecraft/block/Block
    //   159: dup
    //   160: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   163: iconst_0
    //   164: iaload
    //   165: <illegal opcode> 76 : ()Lnet/minecraft/block/BlockChest;
    //   170: aastore
    //   171: dup
    //   172: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   175: iconst_2
    //   176: iaload
    //   177: <illegal opcode> 77 : ()Lnet/minecraft/block/Block;
    //   182: aastore
    //   183: dup
    //   184: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   187: iconst_1
    //   188: iaload
    //   189: <illegal opcode> 78 : ()Lnet/minecraft/block/Block;
    //   194: aastore
    //   195: dup
    //   196: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   199: iconst_4
    //   200: iaload
    //   201: <illegal opcode> 79 : ()Lnet/minecraft/block/Block;
    //   206: aastore
    //   207: dup
    //   208: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   211: iconst_5
    //   212: iaload
    //   213: <illegal opcode> 80 : ()Lnet/minecraft/block/Block;
    //   218: aastore
    //   219: dup
    //   220: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   223: bipush #6
    //   225: iaload
    //   226: <illegal opcode> 81 : ()Lnet/minecraft/block/Block;
    //   231: aastore
    //   232: dup
    //   233: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   236: bipush #7
    //   238: iaload
    //   239: <illegal opcode> 82 : ()Lnet/minecraft/block/Block;
    //   244: aastore
    //   245: dup
    //   246: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   249: bipush #8
    //   251: iaload
    //   252: <illegal opcode> 83 : ()Lnet/minecraft/block/Block;
    //   257: aastore
    //   258: dup
    //   259: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   262: bipush #9
    //   264: iaload
    //   265: <illegal opcode> 84 : ()Lnet/minecraft/block/Block;
    //   270: aastore
    //   271: dup
    //   272: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   275: iconst_3
    //   276: iaload
    //   277: <illegal opcode> 85 : ()Lnet/minecraft/block/Block;
    //   282: aastore
    //   283: dup
    //   284: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   287: bipush #11
    //   289: iaload
    //   290: <illegal opcode> 86 : ()Lnet/minecraft/block/Block;
    //   295: aastore
    //   296: dup
    //   297: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   300: bipush #12
    //   302: iaload
    //   303: <illegal opcode> 87 : ()Lnet/minecraft/block/Block;
    //   308: aastore
    //   309: dup
    //   310: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   313: bipush #13
    //   315: iaload
    //   316: <illegal opcode> 88 : ()Lnet/minecraft/block/Block;
    //   321: aastore
    //   322: dup
    //   323: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   326: bipush #14
    //   328: iaload
    //   329: <illegal opcode> 89 : ()Lnet/minecraft/block/Block;
    //   334: aastore
    //   335: dup
    //   336: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   339: bipush #15
    //   341: iaload
    //   342: <illegal opcode> 90 : ()Lnet/minecraft/block/Block;
    //   347: aastore
    //   348: dup
    //   349: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   352: bipush #16
    //   354: iaload
    //   355: <illegal opcode> 91 : ()Lnet/minecraft/block/Block;
    //   360: aastore
    //   361: dup
    //   362: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   365: bipush #17
    //   367: iaload
    //   368: <illegal opcode> 92 : ()Lnet/minecraft/block/Block;
    //   373: aastore
    //   374: dup
    //   375: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   378: bipush #18
    //   380: iaload
    //   381: <illegal opcode> 93 : ()Lnet/minecraft/block/Block;
    //   386: aastore
    //   387: dup
    //   388: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   391: bipush #19
    //   393: iaload
    //   394: <illegal opcode> 94 : ()Lnet/minecraft/block/Block;
    //   399: aastore
    //   400: dup
    //   401: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   404: bipush #20
    //   406: iaload
    //   407: <illegal opcode> 95 : ()Lnet/minecraft/block/Block;
    //   412: aastore
    //   413: dup
    //   414: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   417: bipush #21
    //   419: iaload
    //   420: <illegal opcode> 96 : ()Lnet/minecraft/block/Block;
    //   425: aastore
    //   426: dup
    //   427: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   430: bipush #22
    //   432: iaload
    //   433: <illegal opcode> 97 : ()Lnet/minecraft/block/Block;
    //   438: aastore
    //   439: dup
    //   440: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   443: bipush #23
    //   445: iaload
    //   446: <illegal opcode> 98 : ()Lnet/minecraft/block/BlockRedstoneComparator;
    //   451: aastore
    //   452: dup
    //   453: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   456: bipush #24
    //   458: iaload
    //   459: <illegal opcode> 99 : ()Lnet/minecraft/block/BlockRedstoneRepeater;
    //   464: aastore
    //   465: dup
    //   466: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   469: bipush #25
    //   471: iaload
    //   472: <illegal opcode> 100 : ()Lnet/minecraft/block/BlockRedstoneRepeater;
    //   477: aastore
    //   478: dup
    //   479: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   482: bipush #26
    //   484: iaload
    //   485: <illegal opcode> 101 : ()Lnet/minecraft/block/BlockRedstoneComparator;
    //   490: aastore
    //   491: dup
    //   492: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   495: bipush #27
    //   497: iaload
    //   498: <illegal opcode> 102 : ()Lnet/minecraft/block/Block;
    //   503: aastore
    //   504: dup
    //   505: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   508: bipush #28
    //   510: iaload
    //   511: <illegal opcode> 103 : ()Lnet/minecraft/block/Block;
    //   516: aastore
    //   517: dup
    //   518: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   521: bipush #29
    //   523: iaload
    //   524: <illegal opcode> 104 : ()Lnet/minecraft/block/Block;
    //   529: aastore
    //   530: dup
    //   531: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   534: bipush #30
    //   536: iaload
    //   537: <illegal opcode> 105 : ()Lnet/minecraft/block/Block;
    //   542: aastore
    //   543: dup
    //   544: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   547: bipush #31
    //   549: iaload
    //   550: <illegal opcode> 106 : ()Lnet/minecraft/block/Block;
    //   555: aastore
    //   556: dup
    //   557: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   560: bipush #32
    //   562: iaload
    //   563: <illegal opcode> 107 : ()Lnet/minecraft/block/Block;
    //   568: aastore
    //   569: dup
    //   570: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   573: bipush #33
    //   575: iaload
    //   576: <illegal opcode> 108 : ()Lnet/minecraft/block/Block;
    //   581: aastore
    //   582: dup
    //   583: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   586: bipush #34
    //   588: iaload
    //   589: <illegal opcode> 109 : ()Lnet/minecraft/block/Block;
    //   594: aastore
    //   595: dup
    //   596: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   599: bipush #35
    //   601: iaload
    //   602: <illegal opcode> 110 : ()Lnet/minecraft/block/Block;
    //   607: aastore
    //   608: dup
    //   609: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   612: bipush #36
    //   614: iaload
    //   615: <illegal opcode> 111 : ()Lnet/minecraft/block/Block;
    //   620: aastore
    //   621: dup
    //   622: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   625: bipush #37
    //   627: iaload
    //   628: <illegal opcode> 112 : ()Lnet/minecraft/block/Block;
    //   633: aastore
    //   634: dup
    //   635: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   638: bipush #38
    //   640: iaload
    //   641: <illegal opcode> 113 : ()Lnet/minecraft/block/Block;
    //   646: aastore
    //   647: dup
    //   648: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   651: bipush #39
    //   653: iaload
    //   654: <illegal opcode> 114 : ()Lnet/minecraft/block/BlockBeacon;
    //   659: aastore
    //   660: dup
    //   661: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   664: bipush #40
    //   666: iaload
    //   667: <illegal opcode> 115 : ()Lnet/minecraft/block/Block;
    //   672: aastore
    //   673: dup
    //   674: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   677: bipush #41
    //   679: iaload
    //   680: <illegal opcode> 116 : ()Lnet/minecraft/block/Block;
    //   685: aastore
    //   686: dup
    //   687: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   690: bipush #42
    //   692: iaload
    //   693: <illegal opcode> 117 : ()Lnet/minecraft/block/BlockDoor;
    //   698: aastore
    //   699: dup
    //   700: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   703: bipush #43
    //   705: iaload
    //   706: <illegal opcode> 118 : ()Lnet/minecraft/block/BlockDoor;
    //   711: aastore
    //   712: dup
    //   713: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   716: bipush #44
    //   718: iaload
    //   719: <illegal opcode> 119 : ()Lnet/minecraft/block/BlockDoor;
    //   724: aastore
    //   725: dup
    //   726: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   729: bipush #45
    //   731: iaload
    //   732: <illegal opcode> 120 : ()Lnet/minecraft/block/BlockDoor;
    //   737: aastore
    //   738: dup
    //   739: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   742: bipush #46
    //   744: iaload
    //   745: <illegal opcode> 121 : ()Lnet/minecraft/block/BlockDoor;
    //   750: aastore
    //   751: dup
    //   752: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   755: bipush #47
    //   757: iaload
    //   758: <illegal opcode> 122 : ()Lnet/minecraft/block/BlockDoor;
    //   763: aastore
    //   764: dup
    //   765: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   768: bipush #48
    //   770: iaload
    //   771: <illegal opcode> 123 : ()Lnet/minecraft/block/Block;
    //   776: aastore
    //   777: dup
    //   778: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   781: bipush #49
    //   783: iaload
    //   784: <illegal opcode> 124 : ()Lnet/minecraft/block/Block;
    //   789: aastore
    //   790: dup
    //   791: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   794: bipush #50
    //   796: iaload
    //   797: <illegal opcode> 125 : ()Lnet/minecraft/block/Block;
    //   802: aastore
    //   803: dup
    //   804: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   807: bipush #51
    //   809: iaload
    //   810: <illegal opcode> 126 : ()Lnet/minecraft/block/BlockHopper;
    //   815: aastore
    //   816: dup
    //   817: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   820: bipush #52
    //   822: iaload
    //   823: <illegal opcode> 127 : ()Lnet/minecraft/block/Block;
    //   828: aastore
    //   829: dup
    //   830: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   833: bipush #53
    //   835: iaload
    //   836: <illegal opcode> 128 : ()Lnet/minecraft/block/Block;
    //   841: aastore
    //   842: dup
    //   843: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   846: bipush #54
    //   848: iaload
    //   849: <illegal opcode> 129 : ()Lnet/minecraft/block/Block;
    //   854: aastore
    //   855: dup
    //   856: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   859: bipush #55
    //   861: iaload
    //   862: <illegal opcode> 130 : ()Lnet/minecraft/block/Block;
    //   867: aastore
    //   868: <illegal opcode> 74 : ([Ljava/lang/Object;)Ljava/util/List;
    //   873: <illegal opcode> 131 : (Ljava/util/List;)V
    //   878: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   881: iconst_3
    //   882: iaload
    //   883: anewarray net/minecraft/block/Block
    //   886: dup
    //   887: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   890: iconst_0
    //   891: iaload
    //   892: <illegal opcode> 78 : ()Lnet/minecraft/block/Block;
    //   897: aastore
    //   898: dup
    //   899: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   902: iconst_2
    //   903: iaload
    //   904: <illegal opcode> 76 : ()Lnet/minecraft/block/BlockChest;
    //   909: aastore
    //   910: dup
    //   911: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   914: iconst_1
    //   915: iaload
    //   916: <illegal opcode> 77 : ()Lnet/minecraft/block/Block;
    //   921: aastore
    //   922: dup
    //   923: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   926: iconst_4
    //   927: iaload
    //   928: <illegal opcode> 130 : ()Lnet/minecraft/block/Block;
    //   933: aastore
    //   934: dup
    //   935: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   938: iconst_5
    //   939: iaload
    //   940: <illegal opcode> 95 : ()Lnet/minecraft/block/Block;
    //   945: aastore
    //   946: dup
    //   947: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   950: bipush #6
    //   952: iaload
    //   953: <illegal opcode> 108 : ()Lnet/minecraft/block/Block;
    //   958: aastore
    //   959: dup
    //   960: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   963: bipush #7
    //   965: iaload
    //   966: <illegal opcode> 126 : ()Lnet/minecraft/block/BlockHopper;
    //   971: aastore
    //   972: dup
    //   973: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   976: bipush #8
    //   978: iaload
    //   979: <illegal opcode> 110 : ()Lnet/minecraft/block/Block;
    //   984: aastore
    //   985: dup
    //   986: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   989: bipush #9
    //   991: iaload
    //   992: <illegal opcode> 109 : ()Lnet/minecraft/block/Block;
    //   997: aastore
    //   998: <illegal opcode> 74 : ([Ljava/lang/Object;)Ljava/util/List;
    //   1003: putstatic me/stupitdog/bhp/f06.blackList : Ljava/util/List;
    //   1006: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1009: bipush #17
    //   1011: iaload
    //   1012: anewarray net/minecraft/block/Block
    //   1015: dup
    //   1016: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1019: iconst_0
    //   1020: iaload
    //   1021: <illegal opcode> 79 : ()Lnet/minecraft/block/Block;
    //   1026: aastore
    //   1027: dup
    //   1028: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1031: iconst_2
    //   1032: iaload
    //   1033: <illegal opcode> 80 : ()Lnet/minecraft/block/Block;
    //   1038: aastore
    //   1039: dup
    //   1040: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1043: iconst_1
    //   1044: iaload
    //   1045: <illegal opcode> 81 : ()Lnet/minecraft/block/Block;
    //   1050: aastore
    //   1051: dup
    //   1052: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1055: iconst_4
    //   1056: iaload
    //   1057: <illegal opcode> 82 : ()Lnet/minecraft/block/Block;
    //   1062: aastore
    //   1063: dup
    //   1064: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1067: iconst_5
    //   1068: iaload
    //   1069: <illegal opcode> 83 : ()Lnet/minecraft/block/Block;
    //   1074: aastore
    //   1075: dup
    //   1076: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1079: bipush #6
    //   1081: iaload
    //   1082: <illegal opcode> 84 : ()Lnet/minecraft/block/Block;
    //   1087: aastore
    //   1088: dup
    //   1089: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1092: bipush #7
    //   1094: iaload
    //   1095: <illegal opcode> 85 : ()Lnet/minecraft/block/Block;
    //   1100: aastore
    //   1101: dup
    //   1102: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1105: bipush #8
    //   1107: iaload
    //   1108: <illegal opcode> 86 : ()Lnet/minecraft/block/Block;
    //   1113: aastore
    //   1114: dup
    //   1115: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1118: bipush #9
    //   1120: iaload
    //   1121: <illegal opcode> 87 : ()Lnet/minecraft/block/Block;
    //   1126: aastore
    //   1127: dup
    //   1128: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1131: iconst_3
    //   1132: iaload
    //   1133: <illegal opcode> 88 : ()Lnet/minecraft/block/Block;
    //   1138: aastore
    //   1139: dup
    //   1140: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1143: bipush #11
    //   1145: iaload
    //   1146: <illegal opcode> 89 : ()Lnet/minecraft/block/Block;
    //   1151: aastore
    //   1152: dup
    //   1153: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1156: bipush #12
    //   1158: iaload
    //   1159: <illegal opcode> 90 : ()Lnet/minecraft/block/Block;
    //   1164: aastore
    //   1165: dup
    //   1166: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1169: bipush #13
    //   1171: iaload
    //   1172: <illegal opcode> 91 : ()Lnet/minecraft/block/Block;
    //   1177: aastore
    //   1178: dup
    //   1179: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1182: bipush #14
    //   1184: iaload
    //   1185: <illegal opcode> 92 : ()Lnet/minecraft/block/Block;
    //   1190: aastore
    //   1191: dup
    //   1192: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1195: bipush #15
    //   1197: iaload
    //   1198: <illegal opcode> 93 : ()Lnet/minecraft/block/Block;
    //   1203: aastore
    //   1204: dup
    //   1205: getstatic me/stupitdog/bhp/f06.llIIlIlIIIllll : [I
    //   1208: bipush #16
    //   1210: iaload
    //   1211: <illegal opcode> 94 : ()Lnet/minecraft/block/Block;
    //   1216: aastore
    //   1217: <illegal opcode> 74 : ([Ljava/lang/Object;)Ljava/util/List;
    //   1222: putstatic me/stupitdog/bhp/f06.shulkerList : Ljava/util/List;
    //   1225: return
  }
  
  private static CallSite lIIIIIlllIlIIlIl(MethodHandles.Lookup lllllllllllllllIllIIlIllIIIIIIll, String lllllllllllllllIllIIlIllIIIIIIlI, MethodType lllllllllllllllIllIIlIllIIIIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlIllIIIIlIIl = llIIIlIIIlIlII[Integer.parseInt(lllllllllllllllIllIIlIllIIIIIIlI)].split(llIIlIlIIIIIIl[llIIlIlIIIllll[0]]);
      Class<?> lllllllllllllllIllIIlIllIIIIlIII = Class.forName(lllllllllllllllIllIIlIllIIIIlIIl[llIIlIlIIIllll[0]]);
      String lllllllllllllllIllIIlIllIIIIIlll = lllllllllllllllIllIIlIllIIIIlIIl[llIIlIlIIIllll[2]];
      MethodHandle lllllllllllllllIllIIlIllIIIIIllI = null;
      int lllllllllllllllIllIIlIllIIIIIlIl = lllllllllllllllIllIIlIllIIIIlIIl[llIIlIlIIIllll[4]].length();
      if (lIIIIlllIlIIllIl(lllllllllllllllIllIIlIllIIIIIlIl, llIIlIlIIIllll[1])) {
        MethodType lllllllllllllllIllIIlIllIIIIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlIllIIIIlIIl[llIIlIlIIIllll[1]], f06.class.getClassLoader());
        if (lIIIIlllIlIIlllI(lllllllllllllllIllIIlIllIIIIIlIl, llIIlIlIIIllll[1])) {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findVirtual(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIll);
          "".length();
          if ((((0xE8 ^ 0xC5) << " ".length() << " ".length() ^ 96 + 5 - -14 + 64) << " ".length() << " ".length() & ((124 + 94 - 127 + 68 ^ (0xAB ^ 0xB8) << "   ".length()) << " ".length() << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findStatic(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIll);
        } 
        "".length();
        if ("   ".length() <= -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlIllIIIIlIlI = llIIIlIIIlIlIl[Integer.parseInt(lllllllllllllllIllIIlIllIIIIlIIl[llIIlIlIIIllll[1]])];
        if (lIIIIlllIlIIlllI(lllllllllllllllIllIIlIllIIIIIlIl, llIIlIlIIIllll[4])) {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findGetter(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIlI);
          "".length();
          if ((0x98 ^ 0x9D) == 0)
            return null; 
        } else if (lIIIIlllIlIIlllI(lllllllllllllllIllIIlIllIIIIIlIl, llIIlIlIIIllll[5])) {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findStaticGetter(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIlI);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (lIIIIlllIlIIlllI(lllllllllllllllIllIIlIllIIIIIlIl, llIIlIlIIIllll[6])) {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findSetter(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIlI);
          "".length();
          if (-(0xA1 ^ 0xA4) >= 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIllIIIIIllI = lllllllllllllllIllIIlIllIIIIIIll.findStaticSetter(lllllllllllllllIllIIlIllIIIIlIII, lllllllllllllllIllIIlIllIIIIIlll, lllllllllllllllIllIIlIllIIIIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlIllIIIIIllI);
    } catch (Exception lllllllllllllllIllIIlIllIIIIIlII) {
      lllllllllllllllIllIIlIllIIIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlllIIIlIlII() {
    llIIIlIIIlIlII = new String[llIIlIlIIIllll[56]];
    llIIIlIIIlIlII[llIIlIlIIIllll[57]] = llIIlIlIIIIIIl[llIIlIlIIIllll[2]];
    llIIIlIIIlIlII[llIIlIlIIIllll[42]] = llIIlIlIIIIIIl[llIIlIlIIIllll[1]];
    llIIIlIIIlIlII[llIIlIlIIIllll[58]] = llIIlIlIIIIIIl[llIIlIlIIIllll[4]];
    llIIIlIIIlIlII[llIIlIlIIIllll[59]] = llIIlIlIIIIIIl[llIIlIlIIIllll[5]];
    llIIIlIIIlIlII[llIIlIlIIIllll[22]] = llIIlIlIIIIIIl[llIIlIlIIIllll[6]];
    llIIIlIIIlIlII[llIIlIlIIIllll[38]] = llIIlIlIIIIIIl[llIIlIlIIIllll[7]];
    llIIIlIIIlIlII[llIIlIlIIIllll[60]] = llIIlIlIIIIIIl[llIIlIlIIIllll[8]];
    llIIIlIIIlIlII[llIIlIlIIIllll[61]] = llIIlIlIIIIIIl[llIIlIlIIIllll[9]];
    llIIIlIIIlIlII[llIIlIlIIIllll[20]] = llIIlIlIIIIIIl[llIIlIlIIIllll[3]];
    llIIIlIIIlIlII[llIIlIlIIIllll[62]] = llIIlIlIIIIIIl[llIIlIlIIIllll[11]];
    llIIIlIIIlIlII[llIIlIlIIIllll[54]] = llIIlIlIIIIIIl[llIIlIlIIIllll[12]];
    llIIIlIIIlIlII[llIIlIlIIIllll[63]] = llIIlIlIIIIIIl[llIIlIlIIIllll[13]];
    llIIIlIIIlIlII[llIIlIlIIIllll[17]] = llIIlIlIIIIIIl[llIIlIlIIIllll[14]];
    llIIIlIIIlIlII[llIIlIlIIIllll[64]] = llIIlIlIIIIIIl[llIIlIlIIIllll[15]];
    llIIIlIIIlIlII[llIIlIlIIIllll[65]] = llIIlIlIIIIIIl[llIIlIlIIIllll[16]];
    llIIIlIIIlIlII[llIIlIlIIIllll[4]] = llIIlIlIIIIIIl[llIIlIlIIIllll[17]];
    llIIIlIIIlIlII[llIIlIlIIIllll[24]] = llIIlIlIIIIIIl[llIIlIlIIIllll[18]];
    llIIIlIIIlIlII[llIIlIlIIIllll[66]] = llIIlIlIIIIIIl[llIIlIlIIIllll[19]];
    llIIIlIIIlIlII[llIIlIlIIIllll[67]] = llIIlIlIIIIIIl[llIIlIlIIIllll[20]];
    llIIIlIIIlIlII[llIIlIlIIIllll[19]] = llIIlIlIIIIIIl[llIIlIlIIIllll[21]];
    llIIIlIIIlIlII[llIIlIlIIIllll[68]] = llIIlIlIIIIIIl[llIIlIlIIIllll[22]];
    llIIIlIIIlIlII[llIIlIlIIIllll[26]] = llIIlIlIIIIIIl[llIIlIlIIIllll[23]];
    llIIIlIIIlIlII[llIIlIlIIIllll[69]] = llIIlIlIIIIIIl[llIIlIlIIIllll[24]];
    llIIIlIIIlIlII[llIIlIlIIIllll[70]] = llIIlIlIIIIIIl[llIIlIlIIIllll[25]];
    llIIIlIIIlIlII[llIIlIlIIIllll[71]] = llIIlIlIIIIIIl[llIIlIlIIIllll[26]];
    llIIIlIIIlIlII[llIIlIlIIIllll[72]] = llIIlIlIIIIIIl[llIIlIlIIIllll[27]];
    llIIIlIIIlIlII[llIIlIlIIIllll[49]] = llIIlIlIIIIIIl[llIIlIlIIIllll[28]];
    llIIIlIIIlIlII[llIIlIlIIIllll[43]] = llIIlIlIIIIIIl[llIIlIlIIIllll[29]];
    llIIIlIIIlIlII[llIIlIlIIIllll[73]] = llIIlIlIIIIIIl[llIIlIlIIIllll[30]];
    llIIIlIIIlIlII[llIIlIlIIIllll[45]] = llIIlIlIIIIIIl[llIIlIlIIIllll[31]];
    llIIIlIIIlIlII[llIIlIlIIIllll[74]] = llIIlIlIIIIIIl[llIIlIlIIIllll[32]];
    llIIIlIIIlIlII[llIIlIlIIIllll[75]] = llIIlIlIIIIIIl[llIIlIlIIIllll[33]];
    llIIIlIIIlIlII[llIIlIlIIIllll[76]] = llIIlIlIIIIIIl[llIIlIlIIIllll[34]];
    llIIIlIIIlIlII[llIIlIlIIIllll[77]] = llIIlIlIIIIIIl[llIIlIlIIIllll[35]];
    llIIIlIIIlIlII[llIIlIlIIIllll[12]] = llIIlIlIIIIIIl[llIIlIlIIIllll[36]];
    llIIIlIIIlIlII[llIIlIlIIIllll[35]] = llIIlIlIIIIIIl[llIIlIlIIIllll[37]];
    llIIIlIIIlIlII[llIIlIlIIIllll[78]] = llIIlIlIIIIIIl[llIIlIlIIIllll[38]];
    llIIIlIIIlIlII[llIIlIlIIIllll[79]] = llIIlIlIIIIIIl[llIIlIlIIIllll[39]];
    llIIIlIIIlIlII[llIIlIlIIIllll[46]] = llIIlIlIIIIIIl[llIIlIlIIIllll[40]];
    llIIIlIIIlIlII[llIIlIlIIIllll[55]] = llIIlIlIIIIIIl[llIIlIlIIIllll[41]];
    llIIIlIIIlIlII[llIIlIlIIIllll[80]] = llIIlIlIIIIIIl[llIIlIlIIIllll[42]];
    llIIIlIIIlIlII[llIIlIlIIIllll[81]] = llIIlIlIIIIIIl[llIIlIlIIIllll[43]];
    llIIIlIIIlIlII[llIIlIlIIIllll[82]] = llIIlIlIIIIIIl[llIIlIlIIIllll[44]];
    llIIIlIIIlIlII[llIIlIlIIIllll[83]] = llIIlIlIIIIIIl[llIIlIlIIIllll[45]];
    llIIIlIIIlIlII[llIIlIlIIIllll[84]] = llIIlIlIIIIIIl[llIIlIlIIIllll[46]];
    llIIIlIIIlIlII[llIIlIlIIIllll[85]] = llIIlIlIIIIIIl[llIIlIlIIIllll[47]];
    llIIIlIIIlIlII[llIIlIlIIIllll[86]] = llIIlIlIIIIIIl[llIIlIlIIIllll[48]];
    llIIIlIIIlIlII[llIIlIlIIIllll[23]] = llIIlIlIIIIIIl[llIIlIlIIIllll[49]];
    llIIIlIIIlIlII[llIIlIlIIIllll[87]] = llIIlIlIIIIIIl[llIIlIlIIIllll[50]];
    llIIIlIIIlIlII[llIIlIlIIIllll[16]] = llIIlIlIIIIIIl[llIIlIlIIIllll[51]];
    llIIIlIIIlIlII[llIIlIlIIIllll[88]] = llIIlIlIIIIIIl[llIIlIlIIIllll[52]];
    llIIIlIIIlIlII[llIIlIlIIIllll[53]] = llIIlIlIIIIIIl[llIIlIlIIIllll[53]];
    llIIIlIIIlIlII[llIIlIlIIIllll[41]] = llIIlIlIIIIIIl[llIIlIlIIIllll[54]];
    llIIIlIIIlIlII[llIIlIlIIIllll[1]] = llIIlIlIIIIIIl[llIIlIlIIIllll[55]];
    llIIIlIIIlIlII[llIIlIlIIIllll[39]] = llIIlIlIIIIIIl[llIIlIlIIIllll[10]];
    llIIIlIIIlIlII[llIIlIlIIIllll[89]] = llIIlIlIIIIIIl[llIIlIlIIIllll[90]];
    llIIIlIIIlIlII[llIIlIlIIIllll[91]] = llIIlIlIIIIIIl[llIIlIlIIIllll[87]];
    llIIIlIIIlIlII[llIIlIlIIIllll[92]] = llIIlIlIIIIIIl[llIIlIlIIIllll[75]];
    llIIIlIIIlIlII[llIIlIlIIIllll[93]] = llIIlIlIIIIIIl[llIIlIlIIIllll[94]];
    llIIIlIIIlIlII[llIIlIlIIIllll[34]] = llIIlIlIIIIIIl[llIIlIlIIIllll[58]];
    llIIIlIIIlIlII[llIIlIlIIIllll[95]] = llIIlIlIIIIIIl[llIIlIlIIIllll[96]];
    llIIIlIIIlIlII[llIIlIlIIIllll[97]] = llIIlIlIIIIIIl[llIIlIlIIIllll[98]];
    llIIIlIIIlIlII[llIIlIlIIIllll[51]] = llIIlIlIIIIIIl[llIIlIlIIIllll[99]];
    llIIIlIIIlIlII[llIIlIlIIIllll[36]] = llIIlIlIIIIIIl[llIIlIlIIIllll[100]];
    llIIIlIIIlIlII[llIIlIlIIIllll[101]] = llIIlIlIIIIIIl[llIIlIlIIIllll[102]];
    llIIIlIIIlIlII[llIIlIlIIIllll[11]] = llIIlIlIIIIIIl[llIIlIlIIIllll[76]];
    llIIIlIIIlIlII[llIIlIlIIIllll[100]] = llIIlIlIIIIIIl[llIIlIlIIIllll[86]];
    llIIIlIIIlIlII[llIIlIlIIIllll[40]] = llIIlIlIIIIIIl[llIIlIlIIIllll[103]];
    llIIIlIIIlIlII[llIIlIlIIIllll[52]] = llIIlIlIIIIIIl[llIIlIlIIIllll[71]];
    llIIIlIIIlIlII[llIIlIlIIIllll[31]] = llIIlIlIIIIIIl[llIIlIlIIIllll[104]];
    llIIIlIIIlIlII[llIIlIlIIIllll[105]] = llIIlIlIIIIIIl[llIIlIlIIIllll[85]];
    llIIIlIIIlIlII[llIIlIlIIIllll[8]] = llIIlIlIIIIIIl[llIIlIlIIIllll[92]];
    llIIIlIIIlIlII[llIIlIlIIIllll[2]] = llIIlIlIIIIIIl[llIIlIlIIIllll[106]];
    llIIIlIIIlIlII[llIIlIlIIIllll[37]] = llIIlIlIIIIIIl[llIIlIlIIIllll[61]];
    llIIIlIIIlIlII[llIIlIlIIIllll[107]] = llIIlIlIIIIIIl[llIIlIlIIIllll[108]];
    llIIIlIIIlIlII[llIIlIlIIIllll[109]] = llIIlIlIIIIIIl[llIIlIlIIIllll[110]];
    llIIIlIIIlIlII[llIIlIlIIIllll[28]] = llIIlIlIIIIIIl[llIIlIlIIIllll[70]];
    llIIIlIIIlIlII[llIIlIlIIIllll[111]] = llIIlIlIIIIIIl[llIIlIlIIIllll[112]];
    llIIIlIIIlIlII[llIIlIlIIIllll[27]] = llIIlIlIIIIIIl[llIIlIlIIIllll[95]];
    llIIIlIIIlIlII[llIIlIlIIIllll[113]] = llIIlIlIIIIIIl[llIIlIlIIIllll[114]];
    llIIIlIIIlIlII[llIIlIlIIIllll[110]] = llIIlIlIIIIIIl[llIIlIlIIIllll[115]];
    llIIIlIIIlIlII[llIIlIlIIIllll[106]] = llIIlIlIIIIIIl[llIIlIlIIIllll[113]];
    llIIIlIIIlIlII[llIIlIlIIIllll[115]] = llIIlIlIIIIIIl[llIIlIlIIIllll[91]];
    llIIIlIIIlIlII[llIIlIlIIIllll[116]] = llIIlIlIIIIIIl[llIIlIlIIIllll[117]];
    llIIIlIIIlIlII[llIIlIlIIIllll[118]] = llIIlIlIIIIIIl[llIIlIlIIIllll[105]];
    llIIIlIIIlIlII[llIIlIlIIIllll[10]] = llIIlIlIIIIIIl[llIIlIlIIIllll[66]];
    llIIIlIIIlIlII[llIIlIlIIIllll[13]] = llIIlIlIIIIIIl[llIIlIlIIIllll[119]];
    llIIIlIIIlIlII[llIIlIlIIIllll[44]] = llIIlIlIIIIIIl[llIIlIlIIIllll[67]];
    llIIIlIIIlIlII[llIIlIlIIIllll[47]] = llIIlIlIIIIIIl[llIIlIlIIIllll[109]];
    llIIIlIIIlIlII[llIIlIlIIIllll[117]] = llIIlIlIIIIIIl[llIIlIlIIIllll[78]];
    llIIIlIIIlIlII[llIIlIlIIIllll[33]] = llIIlIlIIIIIIl[llIIlIlIIIllll[120]];
    llIIIlIIIlIlII[llIIlIlIIIllll[102]] = llIIlIlIIIIIIl[llIIlIlIIIllll[121]];
    llIIIlIIIlIlII[llIIlIlIIIllll[7]] = llIIlIlIIIIIIl[llIIlIlIIIllll[60]];
    llIIIlIIIlIlII[llIIlIlIIIllll[96]] = llIIlIlIIIIIIl[llIIlIlIIIllll[57]];
    llIIIlIIIlIlII[llIIlIlIIIllll[6]] = llIIlIlIIIIIIl[llIIlIlIIIllll[84]];
    llIIIlIIIlIlII[llIIlIlIIIllll[122]] = llIIlIlIIIIIIl[llIIlIlIIIllll[82]];
    llIIIlIIIlIlII[llIIlIlIIIllll[123]] = llIIlIlIIIIIIl[llIIlIlIIIllll[116]];
    llIIIlIIIlIlII[llIIlIlIIIllll[124]] = llIIlIlIIIIIIl[llIIlIlIIIllll[123]];
    llIIIlIIIlIlII[llIIlIlIIIllll[119]] = llIIlIlIIIIIIl[llIIlIlIIIllll[97]];
    llIIIlIIIlIlII[llIIlIlIIIllll[125]] = llIIlIlIIIIIIl[llIIlIlIIIllll[118]];
    llIIIlIIIlIlII[llIIlIlIIIllll[114]] = llIIlIlIIIIIIl[llIIlIlIIIllll[126]];
    llIIIlIIIlIlII[llIIlIlIIIllll[32]] = llIIlIlIIIIIIl[llIIlIlIIIllll[74]];
    llIIIlIIIlIlII[llIIlIlIIIllll[18]] = llIIlIlIIIIIIl[llIIlIlIIIllll[77]];
    llIIIlIIIlIlII[llIIlIlIIIllll[103]] = llIIlIlIIIIIIl[llIIlIlIIIllll[125]];
    llIIIlIIIlIlII[llIIlIlIIIllll[126]] = llIIlIlIIIIIIl[llIIlIlIIIllll[107]];
    llIIIlIIIlIlII[llIIlIlIIIllll[15]] = llIIlIlIIIIIIl[llIIlIlIIIllll[64]];
    llIIIlIIIlIlII[llIIlIlIIIllll[108]] = llIIlIlIIIIIIl[llIIlIlIIIllll[62]];
    llIIIlIIIlIlII[llIIlIlIIIllll[127]] = llIIlIlIIIIIIl[llIIlIlIIIllll[65]];
    llIIIlIIIlIlII[llIIlIlIIIllll[128]] = llIIlIlIIIIIIl[llIIlIlIIIllll[68]];
    llIIIlIIIlIlII[llIIlIlIIIllll[90]] = llIIlIlIIIIIIl[llIIlIlIIIllll[129]];
    llIIIlIIIlIlII[llIIlIlIIIllll[29]] = llIIlIlIIIIIIl[llIIlIlIIIllll[122]];
    llIIIlIIIlIlII[llIIlIlIIIllll[120]] = llIIlIlIIIIIIl[llIIlIlIIIllll[124]];
    llIIIlIIIlIlII[llIIlIlIIIllll[130]] = llIIlIlIIIIIIl[llIIlIlIIIllll[63]];
    llIIIlIIIlIlII[llIIlIlIIIllll[5]] = llIIlIlIIIIIIl[llIIlIlIIIllll[131]];
    llIIIlIIIlIlII[llIIlIlIIIllll[9]] = llIIlIlIIIIIIl[llIIlIlIIIllll[69]];
    llIIIlIIIlIlII[llIIlIlIIIllll[48]] = llIIlIlIIIIIIl[llIIlIlIIIllll[83]];
    llIIIlIIIlIlII[llIIlIlIIIllll[94]] = llIIlIlIIIIIIl[llIIlIlIIIllll[130]];
    llIIIlIIIlIlII[llIIlIlIIIllll[3]] = llIIlIlIIIIIIl[llIIlIlIIIllll[128]];
    llIIIlIIIlIlII[llIIlIlIIIllll[129]] = llIIlIlIIIIIIl[llIIlIlIIIllll[80]];
    llIIIlIIIlIlII[llIIlIlIIIllll[14]] = llIIlIlIIIIIIl[llIIlIlIIIllll[79]];
    llIIIlIIIlIlII[llIIlIlIIIllll[21]] = llIIlIlIIIIIIl[llIIlIlIIIllll[101]];
    llIIIlIIIlIlII[llIIlIlIIIllll[121]] = llIIlIlIIIIIIl[llIIlIlIIIllll[81]];
    llIIIlIIIlIlII[llIIlIlIIIllll[30]] = llIIlIlIIIIIIl[llIIlIlIIIllll[89]];
    llIIIlIIIlIlII[llIIlIlIIIllll[25]] = llIIlIlIIIIIIl[llIIlIlIIIllll[111]];
    llIIIlIIIlIlII[llIIlIlIIIllll[98]] = llIIlIlIIIIIIl[llIIlIlIIIllll[93]];
    llIIIlIIIlIlII[llIIlIlIIIllll[99]] = llIIlIlIIIIIIl[llIIlIlIIIllll[127]];
    llIIIlIIIlIlII[llIIlIlIIIllll[132]] = llIIlIlIIIIIIl[llIIlIlIIIllll[88]];
    llIIIlIIIlIlII[llIIlIlIIIllll[0]] = llIIlIlIIIIIIl[llIIlIlIIIllll[59]];
    llIIIlIIIlIlII[llIIlIlIIIllll[112]] = llIIlIlIIIIIIl[llIIlIlIIIllll[72]];
    llIIIlIIIlIlII[llIIlIlIIIllll[104]] = llIIlIlIIIIIIl[llIIlIlIIIllll[73]];
    llIIIlIIIlIlII[llIIlIlIIIllll[50]] = llIIlIlIIIIIIl[llIIlIlIIIllll[132]];
    llIIIlIIIlIlII[llIIlIlIIIllll[131]] = llIIlIlIIIIIIl[llIIlIlIIIllll[56]];
    llIIIlIIIlIlIl = new Class[llIIlIlIIIllll[23]];
    llIIIlIIIlIlIl[llIIlIlIIIllll[11]] = double.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[13]] = BlockDynamicLiquid.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[17]] = BlockChest.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[16]] = BlockFire.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[21]] = BlockDoor.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[14]] = BlockStaticLiquid.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[3]] = boolean.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[4]] = EntityPlayerSP.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[20]] = BlockBeacon.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[5]] = float.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[12]] = List.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[19]] = BlockRedstoneRepeater.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[9]] = EnumHand.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[7]] = CPacketEntityAction.Action.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[18]] = BlockRedstoneComparator.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[8]] = PlayerControllerMP.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[1]] = Block.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[2]] = WorldClient.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[6]] = NetHandlerPlayClient.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[22]] = BlockHopper.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[0]] = Minecraft.class;
    llIIIlIIIlIlIl[llIIlIlIIIllll[15]] = BlockTallGrass.class;
  }
  
  private static void lIIIIlllIIllllll() {
    llIIlIlIIIIIIl = new String[llIIlIlIIIllll[133]];
    llIIlIlIIIIIIl[llIIlIlIIIllll[0]] = lIIIIlllIIIlIlIl(llIIlIlIIIlllI[llIIlIlIIIllll[0]], llIIlIlIIIlllI[llIIlIlIIIllll[2]]);
    llIIlIlIIIIIIl[llIIlIlIIIllll[2]] = lIIIIlllIIIlIlIl(llIIlIlIIIlllI[llIIlIlIIIllll[1]], llIIlIlIIIlllI[llIIlIlIIIllll[4]]);
    llIIlIlIIIIIIl[llIIlIlIIIllll[1]] = lIIIIlllIIIlIlIl(llIIlIlIIIlllI[llIIlIlIIIllll[5]], llIIlIlIIIlllI[llIIlIlIIIllll[6]]);
    llIIlIlIIIIIIl[llIIlIlIIIllll[4]] = lIIIIlllIIIlIllI(llIIlIlIIIlllI[llIIlIlIIIllll[7]], llIIlIlIIIlllI[llIIlIlIIIllll[8]]);
    llIIlIlIIIIIIl[llIIlIlIIIllll[5]] = lIIIIlllIIIlIlIl(llIIlIlIIIlllI[llIIlIlIIIllll[9]], llIIlIlIIIlllI[llIIlIlIIIllll[3]]);
    llIIlIlIIIIIIl[llIIlIlIIIllll[6]] = lIIIIlllIIIlIlIl("VOrHbrNV/IuQUw5vkTQtX/SQbQpfEtIK4SP5GcFCWshO4St3juaUQcOdPJXxyxtO6yLcjUCVZX/b4/KScSQMrLG1Vj85KhgacZ0ljoIC+TK5TrRFVxbY7w==", "iAgda");
    llIIlIlIIIIIIl[llIIlIlIIIllll[7]] = lIIIIlllIIIlIllI("KIoSZiewYd1++lZpTA6L0xSOr9BHuwSQvTNaNdwHqmj2MvykTzOkdIM3yfPhCCikmhGsyOvcwsA=", "TaBkN");
    llIIlIlIIIIIIl[llIIlIlIIIllll[8]] = lIIIIlllIIIlIlIl("6Z8O8UacQsgaR15ILDTW5ohu99Rm9QToWcKvkV6pFbpqZxCzUfZxytKpe88fNG7itpTVKca4mv4=", "KrfQa");
    llIIlIlIIIIIIl[llIIlIlIIIllll[9]] = lIIIIlllIIIllIll("CwgyIEkUHS0tSSAbNiAeElMlMisIGjB7TzolLiARAEYoIAkGRgsjDQQKMHpOLQMlNwZOHDAoC04lLTITWlNk", "aiDAg");
    llIIlIlIIIIIIl[llIIlIlIIIllll[3]] = lIIIIlllIIIllIll("LwgbRCcoAwoJOCALG0QpLQQKBD5vABoGPigdAwszJB9BOiYgFAoYCS4DGxglLQEKGAcRVwkfJCIyXlJ9cVRWNSt7RSMELzVCAgMkJA4dCyw1QgwGIyQDG0UvLxkGHjNuKAEeIzUUPwYrOAgdORp6IQEPPm4ABgQvIh8ODD5uDgMDLy8ZQAc/LRkGGiYgFAoYZRYCHQYuAgEGDyQ1ViMELzVCAgMkJA4dCyw1QhoeIy1CAgs+KUItBiUiBj8FOXohAQ8+bgAGBC8iHw4MPm4YGwMmbigBHycHDAwDJCZWIwQvNUICAyQkDh0LLDVCGh4jLUICCz4pQjkPKXIJVCYkJBlAByMvCAwYKycZQB8+KAFALyQ0ACcLJCVWRiYkJBlAByMvCAwYKycZQB8+KAFALyQ0AC4JPigCATgvMhgDHnF7TU8=", "AmojJ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[11]] = lIIIIlllIIIlIlIl("x7q1vSsXCyE8TGss2BuSfo9doDMQ5g4Kyxx8WlGfaW8lg+jBCfVeOSslyzG257IshUruHM0nXdU=", "Hhgdz");
    llIIlIlIIIIIIl[llIIlIlIIIllll[12]] = lIIIIlllIIIlIllI("djQEFhRnCAvS/c+CwtjUF81VVXhOk7uWbu2ubcX25aCoA4qvInO5WlzZjVFMFtl2XyV+hJMsv/N2/D0PTqS0UxO4dI1dcRA+EA8RqcaJXfKNwTx3a6YImy/VVrYFZQVb", "YFcPV");
    llIIlIlIIIIIIl[llIIlIlIIIllll[13]] = lIIIIlllIIIlIllI("QivqT/CPvyYZ7QXZ1kbLXGZ0d7DU58fWtDgUE2e+l2G9peB/hdIHGCQQgqZKlN1c+jHFyOPWNsg=", "tlIrQ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[14]] = lIIIIlllIIIlIlIl("+wHWPNQ/mrspzKKSuI9/T2ApmZkJtpkr8bo0RJrEk4d6E3F62UsKyAZ7EraDSPHZCGLWLto+Jyo=", "pQiqM");
    llIIlIlIIIIIIl[llIIlIlIIIllll[15]] = lIIIIlllIIIlIllI("xPSXI964rkCEkZRLacxUE1rA9L5tw2iq8fA1hfbSFvQw1agRSD9nbp0+r1yP6/V0FgsznHcj5JA=", "HCIXQ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[16]] = lIIIIlllIIIllIll("KDAfYDovOw4tJSczH2A+KDwfYBUqOgglJHwzAis7Igpae2d1bVkRNSlvWXR3ZnVL", "FUkNW");
    llIIlIlIIIIIIl[llIIlIlIIIllll[17]] = lIIIIlllIIIlIlIl("mi5U+IMD7ms8JY0TBXegdUjpCcxtu8ZXKvD+nX1DDY9aVoUDp8zv4VZdpZaVU8K3fJ8U8kYvanQ5PAMYjACkmoqwZV2mlQbkBdd0nkh47WY=", "uxhNc");
    llIIlIlIIIIIIl[llIIlIlIIIllll[18]] = lIIIIlllIIIllIll("GQYAegoeDRE3FRYFAHoEGwoROhNZBhogDgMaWhEJAwoALTcbAg0xFSQzTjISGQArY1dHWkcLBhFZXH09TUNU", "wctTg");
    llIIlIlIIIIIIl[llIIlIlIIIllll[19]] = lIIIIlllIIIlIlIl("tfWBnYoKSR61GsXzlWxV02aTHnjgD/PuxJPwEAFoBsHGRrYdBDdE43d6NJNiFXm4PHInuiS64LQ=", "nbgIw");
    llIIlIlIIIIIIl[llIIlIlIIIllll[20]] = lIIIIlllIIIllIll("ARIBWCAGGRAVPw4RAVgkAR4BWA8DGBYdPlURHBMhCyhET31WT0MpKRpNR0xtT1dV", "owuvM");
    llIIlIlIIIIIIl[llIIlIlIIIllll[21]] = lIIIIlllIIIlIlIl("yH1eH69aDJNfTttGHZI2uxaEGJ1aKyJoT0EgJDH4y5lP9k+50fhn1+IA15DezS5m", "nOEJH");
    llIIlIlIIIIIIl[llIIlIlIIIllll[22]] = lIIIIlllIIIllIll("JCEdZQYjKgwoGSsiHWUCJC0dZSkmKwogGHAiAC4HLhtYflt5cl4UEXB2U2tLamQ=", "JDiKk");
    llIIlIlIIIIIIl[llIIlIlIIIllll[23]] = lIIIIlllIIIlIllI("pNIOJ7xQQiiGam02dIzmzSoX7WveqSAGdpy6gQLF9bmnkeFN/7kLKvE2ej6rtr7XaGB6asRYp9B5NzwlqfX3VilWh08N/cy97hX+YK57z3VayEnh2uD+LA==", "KTlCv");
    llIIlIlIIIIIIl[llIIlIlIIIllll[24]] = lIIIIlllIIIlIllI("ohVsPC9+DCvR9P5aikwr/9Ch+wC2/zM7Cen/Szr3t1ISmn/cM0CA3a5g995Dhdef", "RNqUc");
    llIIlIlIIIIIIl[llIIlIlIIIllll[25]] = lIIIIlllIIIlIllI("qkucxHtfTYVCfuDnmPnVqZS4+9b3xX+N2m6BqXycCsIiwZtcZq82vd7TX43fWNv7HBBfn8UJf7I=", "mcQyn");
    llIIlIlIIIIIIl[llIIlIlIIIllll[26]] = lIIIIlllIIIllIll("PTE2fQ46OicwETIyNn0KPT02fSE/OyE4EGkyKzYPNwtzZlNgYXcMCWllcWlDc3Ri", "STBSc");
    llIIlIlIIIIIIl[llIIlIlIIIllll[27]] = lIIIIlllIIIllIll("NggnXwgxAzYSFzkLJ18MNgQnXyc0AjAaFmILOhQJPDJiSVBvWmQuATxXYUtFeE1z", "XmSqe");
    llIIlIlIIIIIIl[llIIlIlIIIllll[28]] = lIIIIlllIIIllIll("DRQeTSEKHw8APgIXHk05FxgGTQkNBAclLQAYBAR2BQQEABNbQ19adTwUUEtlKktKQw==", "cqjcL");
    llIIlIlIIIIIIl[llIIlIlIIIllll[29]] = lIIIIlllIIIlIlIl("pRF7EJI291/tUEOKltSoX8SkC0RqUNryCH+bXKx9L3eJvLRX50OzJi7h1E00IiPnqEZFftGjVoQQ3pK/ChSFJySWR1fIUNhRC21tpmI+YBM=", "aRXEV");
    llIIlIlIIIIIIl[llIIlIlIIIllll[30]] = lIIIIlllIIIlIllI("TuCepVhnEfVqGEyKoqDnoAI9Hm/+MjZUrmGNCPU+E30Z90NdM5+VeiR7G/+qVqST3Pdz3U/xIQ8=", "HkxfI");
    llIIlIlIIIIIIl[llIIlIlIIIllll[31]] = lIIIIlllIIIllIll("IAMcSwgnCA0GFy8AHEsGIg8NCxFgKwELAC0UCQMRdAAdCwYRV1BRVHxXNwQOdE5BI19uRg==", "Nfhee");
    llIIlIlIIIIIIl[llIIlIlIIIllll[32]] = lIIIIlllIIIllIll("Pyg4fRU4IykwCjArOH0RPyQ4fTo9Ii84C2srJTYUNRJ9a0hidHwMGj53fmlYcW1s", "QMLSx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[33]] = lIIIIlllIIIllIll("KzEQM2otMQg1agwxEjp+ICQHPHZ7eCIWbQVqRg==", "APfRD");
    llIIlIlIIIIIIl[llIIlIlIIIllll[34]] = lIIIIlllIIIllIll("BxUATD8AHhEBIAgWAEw7BxkATBAFHxcJIVMWHQc+DS9FV2JaRUI9OVNBRlhySVBU", "iptbR");
    llIIlIlIIIIIIl[llIIlIlIIIllll[35]] = lIIIIlllIIIllIll("IC8taDQnJDwlKy8sLWgwICMtaBsiJTotKnQsMCM1KhVofml9c2gZOz5wa3x5bmp5", "NJYFY");
    llIIlIlIIIIIIl[llIIlIlIIIllll[36]] = lIIIIlllIIIllIll("NgINeRcxCRw0CDkBDXkZNA4cOQ52AhcjEyweVxIULA4NLio0BgAyCAs3QzETPQsdCE1oVk5gJSJdTW1aeEc=", "XgyWz");
    llIIlIlIIIIIIl[llIIlIlIIIllll[37]] = lIIIIlllIIIllIll("Hz1bKh4HKBwtDh0/WzsCAnYTaVxIPRgpHgsaGTYJGStPaFtIeFV5Sg==", "rXuYj");
    llIIlIlIIIIIIl[llIIlIlIIIllll[38]] = lIIIIlllIIIlIllI("J8NGogz0qEGmdjt+jw2f4h6VBlmnmL1aC0PNoH6EWX2WU8CSpcC/ZAM2moDFIBObMep07E+tsF0=", "EAhJK");
    llIIlIlIIIIIIl[llIIlIlIIIllll[39]] = lIIIIlllIIIlIlIl("7/NWWqvGxYltky2o9Mh34/Iyzkd2wX7Vupzp+2F6JyCBG8wE2nS1A6aFZM6ScHStGDAIaFaT0rU=", "OEGKY");
    llIIlIlIIIIIIl[llIIlIlIIIllll[40]] = lIIIIlllIIIlIllI("fe85sq3crlqiUqUDgStAXxquvI0YG1H3umIKAJq6xQbyoXWytpIttq+q7JCAE/jNKDmPMDcJJ6A8hh1oIICv8Rbg4KkRquqseDVstSGURRIc2DuuNA22/uD25B+LFs51", "xpQmx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[41]] = lIIIIlllIIIlIlIl("Vaj75yxrALgZ4i6t7N8lXFEE6cJeQMMptPZ8oruLZZQkPC3LQMWKSiVx3N5CmpgCTfzf3TQjlIHPJRspwj+zx3N+y2GOPPUDi3iUPJhjeAJ3cEUIZdafQQ==", "OXNuA");
    llIIlIlIIIIIIl[llIIlIlIIIllll[42]] = lIIIIlllIIIllIll("ByERWTUAKgAUKggiEVkxBy0RWRoFKwYcK1MiDBI0DRtUT2hddVcoORh+V0diSWRFVw==", "iDewX");
    llIIlIlIIIIIIl[llIIlIlIIIllll[43]] = lIIIIlllIIIllIll("Iggley8lAzQ2MC0LJXsrIgQlewAgAjI+MXYLODAuKDJgbXJ4XWgKIzhXY2V4bE1xdQ==", "LmQUB");
    llIIlIlIIIIIIl[llIIlIlIIIllll[44]] = lIIIIlllIIIlIllI("dCd5RHFZE2JX7oizAftrjSgaZG2ODaRysSHD+6kPf2VwH3/9MFt2YTQBetm01fxWRI42r6XLGrk=", "cjDqu");
    llIIlIlIIIIIIl[llIIlIlIIIllll[45]] = lIIIIlllIIIllIll("Cx8iWR8MFDMUAAQcIlkbCxMiWTAJFTUcAV8cPxIeASVnQkJRTGYoEwlAZE1SRVp2", "ezVwr");
    llIIlIlIIIIIIl[llIIlIlIIIllll[46]] = lIIIIlllIIIlIlIl("gRBSBbdL/3noKmo2PtpIbac6y4OqjDT2B0zd5ljd9ppDiAT9P0vnKvh7CB0XmRJ/+3uxxg4QmDM=", "JmGpa");
    llIIlIlIIIIIIl[llIIlIlIIIllll[47]] = lIIIIlllIIIlIllI("JQtvDyeZKYC3yokVWYI6dxTH6vZAeWILCWAC66YBoNjCo0vgbjWwz2C1H+kTDGKplwj8sZWn9Yg=", "cqdVf");
    llIIlIlIIIIIIl[llIIlIlIIIllll[48]] = lIIIIlllIIIlIllI("YKu8VaIHes54auwf7TCXdhXy+bfLANyl33g+T6aMb0vz8WFbM1Zh82w7KC9rmpVmeSCWTBlH2XY=", "soVLj");
    llIIlIlIIIIIIl[llIIlIlIIIllll[49]] = lIIIIlllIIIlIlIl("a1FpRIBhSV7GZPs2oAepDrryGxcOh7V8e6puW/bkYUO2hA8TUq6Z0lGGAq9KfKxBnQu5kodvC3HwFaL+BVdXsg==", "rdoVg");
    llIIlIlIIIIIIl[llIIlIlIIIllll[50]] = lIIIIlllIIIllIll("DQ8VLmELDw0oYSoPFyd1FB8RO3VPKkoLdUc=", "gncOO");
    llIIlIlIIIIIIl[llIIlIlIIIllll[51]] = lIIIIlllIIIlIllI("9+y7P8q8AtmMuOtlBJghfd7eNqYzyNaZYhgeVUJSNFPgGRHSJlrP6xVXaNEEkVF9N5wNaS2+mNVkDYdJjj7Nj0cO3pRy0GZ5OapwO6HEwVrouqze44BRdibCgjAvtLZpnStgxAZh75I=", "dLonT");
    llIIlIlIIIIIIl[llIIlIlIIIllll[52]] = lIIIIlllIIIllIll("NzUDWzkwPhIWJjg2A1s9NzkDWxY1PxQeJ2M2HhA4PQ9GTWFuZ0EqMDpqRU90eXBX", "YPwuT");
    llIIlIlIIIIIIl[llIIlIlIIIllll[53]] = lIIIIlllIIIlIlIl("8ojd0gwkjPGX3Pa2tt4iMwic9Tw+fI5tIaIi0laAh+7lwFDnI4wlw8UXJEqKiohnfCqzzm0XefpxbdHFp1VKAcqBieNkwzVHdEsZa20bbKYPTvIRvY5i0U9yZaMMp7NT7BF9vT0ka9Z/TAJVHtCy+g==", "jniNw");
    llIIlIlIIIIIIl[llIIlIlIIIllll[54]] = lIIIIlllIIIlIllI("jmvkaCG38avy12ba+7jMkSYd0DA9lq3EI4wm+gams2rGEAcoaqoy9WA45Fb+EsBaj9BbDSrEs2ifwHMXivGjuzAIfVV8F4ZgO8aj2/JOBXp5qPphpzCdXg==", "ETsWQ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[55]] = lIIIIlllIIIlIlIl("27bDs9oBr+tk9ELIdg1t+zE+mAZZZxoLRtSmM+9I+ll1FUduwvF2DD+ZflTpPmVX8xVCDM3LQQrs9N6nExJGvilAjgdRdozwcvNOTrtLcpwsikvZN4jVsbABJAdQt19YLaFuazADxTdVsfsaB2ARTsheNVEd1vbF4WZYYu5KduhBAk1bcQ5fqkViVSLp3ePL", "QWWxY");
    llIIlIlIIIIIIl[llIIlIlIIIllll[10]] = lIIIIlllIIIlIllI("Nihiaq0CboagMoeCTrMKupvWvrzZTvJSjsDIp8Vsho6YMqnsabsfRA==", "CYUuK");
    llIIlIlIIIIIIl[llIIlIlIIIllll[90]] = lIIIIlllIIIlIllI("z+1k1gQo824UT+lT0NaV0im6voJUWDr0fWe1b5ex3jgTm1pKOl8XnvFMyT58ZeocZ9QrULejpSE=", "rawnU");
    llIIlIlIIIIIIl[llIIlIlIIIllll[87]] = lIIIIlllIIIlIlIl("r6RS5gICnZpSOlqY9OmMIYq5AWuJhzfu28LmGo4Vs4wPXcG/81gWeBKN0FLAHwy+VF1qieGiqcA=", "Osrbx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[75]] = lIIIIlllIIIlIlIl("EFm7qG7kcm9Nq1bxSj3TYJBtTmdkxFpSelqU+4uq//wIoxhJMBm/M/P+ZZPxGZpacHETdz0GFsI=", "khmwN");
    llIIlIlIIIIIIl[llIIlIlIIIllll[94]] = lIIIIlllIIIlIlIl("K5frki2TnbRiJNPvXMqwXwsHxzaF77PdP7u7GHrTPInRfx1aG11nlo+sM5DprOM5zziT5vqv6ww=", "YELrh");
    llIIlIlIIIIIIl[llIIlIlIIIllll[58]] = lIIIIlllIIIlIlIl("dqyJ9JSjowAkHHO/cPTYFsfgx0r8Nk02rKlrqmo+hnHMrWYpxCbXLYCQH4o2KkR23EbO3JmaOkM=", "vwyvv");
    llIIlIlIIIIIIl[llIIlIlIIIllll[96]] = lIIIIlllIIIllIll("LTMcdyEqOA06PiIwHHclLT8cdw4vOQsyP3kwATwgJwlZYHx6YV8GKC9sWmNsY3ZI", "CVhYL");
    llIIlIlIIIIIIl[llIIlIlIIIllll[98]] = lIIIIlllIIIlIlIl("FV6c9ls/1mbOorrK49VKeYr5eDlM//o+FOpHKek4A3epAi9OLSAGFXCZylehaL3o728gcb7HZNo=", "cvGxB");
    llIIlIlIIIIIIl[llIIlIlIIIllll[99]] = lIIIIlllIIIlIlIl("xmJ2ySkZalJ/aB8WAm8m2mr6REpT98pmZ0Esl9uUSTa0GL7f2xi+j+L3/pi0dOqGwdmNQxKsHQSfvnXhofL5CXYjhl54cf0Yu/3pynpesBzc3Pb0UpFj7VslyAlLZ2bT24YQYgtaB7I=", "jEkRf");
    llIIlIlIIIIIIl[llIIlIlIIIllll[100]] = lIIIIlllIIIlIlIl("ikhePwSUuTvzju9vVUg/G/M9/xOIWMqcZjfxGEabXWTHyc+vvp/L6JFA+gixnILGAq9NjkpzN+M=", "aKUDA");
    llIIlIlIIIIIIl[llIIlIlIIIllll[102]] = lIIIIlllIIIlIlIl("BV1Wxh6qE23IiaMbPTy/b705j9NiK21MEmY2nS+IZftDWdDIdklJHU3DaSuoXaU+Nwd64jhloj0=", "BToMP");
    llIIlIlIIIIIIl[llIIlIlIIIllll[76]] = lIIIIlllIIIlIlIl("Q0OMUaA+XosRajDzVZIyWJHiXhocJBzXG1FTK6MbCVi03dWv7LEKJQ2HO2UQgzNQR05HGr/U1E8=", "xwrwm");
    llIIlIlIIIIIIl[llIIlIlIIIllll[86]] = lIIIIlllIIIlIlIl("R/heySmFz+GW+MeAlOjPVu8TAlw9yWskKJ1ZF1PlMHbOlq3e4xFjd5Xb9jHcnD9VJi4bEkm2tAFqctAO8TfqmQ==", "KZsEX");
    llIIlIlIIIIIIl[llIIlIlIIIllll[103]] = lIIIIlllIIIlIlIl("DjH6yigFTTXEU1dydQXIrwl3MuGL+u1l6Z7bKb0oDp5SXuTylW8NaJpwh2a/MAlM", "oYkXo");
    llIIlIlIIIIIIl[llIIlIlIIIllll[71]] = lIIIIlllIIIlIllI("fxrpKhRm2pKNorfhp/NcDfrw1ahnTkpdVdHl0kMdtrS4b46uUV3qlavAd9gyosQt/tIK/geKXaDJXcqvyK4M1g==", "GVOtl");
    llIIlIlIIIIIIl[llIIlIlIIIllll[104]] = lIIIIlllIIIlIlIl("vmE32Uxq+FUTc1ICCZE0+Ck9p2RkeGmzKYtuvunKYFVPJATWEqaxurluBYbjqgvVmib9vRUhswU=", "MiIuh");
    llIIlIlIIIIIIl[llIIlIlIIIllll[85]] = lIIIIlllIIIllIll("AzUdfD8EPgwxIAw2HXw7AzkdfBABPwo5IVc2ADc+CQ9Ya2JUaFoNNh9qW2hyTXBJ", "mPiRR");
    llIIlIlIIIIIIl[llIIlIlIIIllll[92]] = lIIIIlllIIIllIll("NBA2aDozGyclJTsTNmg+NBw2aBU2GiEtJGATKyM7Pipzc2dpQHIZNmBHeGZ3elU=", "ZuBFW");
    llIIlIlIIIIIIl[llIIlIlIIIllll[106]] = lIIIIlllIIIlIlIl("Q22fphaWULhvoQulspL4qEmIkDrl48vhnXWqJJ3TPkVhjfdB5yLDGkAxlBsBpwMUkOdwBmJ3G4s=", "mvoVf");
    llIIlIlIIIIIIl[llIIlIlIIIllll[61]] = lIIIIlllIIIllIll("JxMxaSogGCAkNSgQMWkkJR8gKTNnGzArMyAGKSY+LARrECg7GiEEKyATKzN9Lx8gKyMWQXd+fn8pI312eExlZ2c=", "IvEGG");
    llIIlIlIIIIIIl[llIIlIlIIIllll[108]] = lIIIIlllIIIlIlIl("qp3OgpXL2haAx8PmwIpigBghsxnAyuFYsoNeT/waf1Lhl9uCj1eFQ0+mQII9s7pnjnJEMk0xiUw=", "nQljF");
    llIIlIlIIIIIIl[llIIlIlIIIllll[110]] = lIIIIlllIIIlIlIl("Vil9yk43oyOuXHRx71EAKK9fxMzYF0oXLONx/aO7OeSpbNRD9v+MWsEjxtaP0oIhJhWXzhXGvAI=", "acJoj");
    llIIlIlIIIIIIl[llIIlIlIIIllll[70]] = lIIIIlllIIIlIlIl("ohhmkb7G5YVVMEN5g1vDxWn15YceqNKz4yL0B0yfaiqyE3AbrxDLuV9qBhD3rjUB4yI8nc6mhgaGK1K2dsJp6XM7Qan1zLOi9P62/SPIQNLjIjydzqaGBoYrUrZ2wmnpcztBqfXMs6IM592qyb6Amg==", "KeNbe");
    llIIlIlIIIIIIl[llIIlIlIIIllll[112]] = lIIIIlllIIIlIllI("/NBK9x/yF09257DCiBxjGVOIvwWm9bHTeo5wNI0aGOSE3RhnfNEZg71SPFsfgBCJ2gxpeP+Z05g=", "isBox");
    llIIlIlIIIIIIl[llIIlIlIIIllll[95]] = lIIIIlllIIIlIllI("1wPjAEBWWe2daQNdLIr+nCwdsUKNjElksgf8CrxKpSFVHR+GH8+CfCo8rNjMOezGSyHD4LUT3cwlykjo/SheMN7soJKI8PY6Z4YHGAO88YkiXbhF+uqV1A==", "sbbfT");
    llIIlIlIIIIIIl[llIIlIlIIIllll[114]] = lIIIIlllIIIllIll("JQ8FZBsiBBQpBCoMBWQfJQMFZDQnBRIhBXEMGC8aLzVAc0ZyUkEVEiRQQ3BWa0pR", "KjqJv");
    llIIlIlIIIIIIl[llIIlIlIIIllll[115]] = lIIIIlllIIIllIll("JiwQXyIhJwESPSkvEF8mJiAQXw0kJgcaPHIvDRQjLBZVRH98cVIuLi1zVUd1aGlEUQ==", "HIdqO");
    llIIlIlIIIIIIl[llIIlIlIIIllll[113]] = lIIIIlllIIIlIlIl("R5BTQ6+p5nkIY3hq86fSm+prHhMLjNueNNW3AgCbCV5AE64xRp0uwRJmwswGfzruc2mDu3UYZjo=", "wfspu");
    llIIlIlIIIIIIl[llIIlIlIIIllll[91]] = lIIIIlllIIIllIll("NhQRZBcxHwApCDkXEWQTNhgRZDg0HgYhCWIXDC8WPC5Uc0phRlwVHjZLV3BaeFFF", "XqeJz");
    llIIlIlIIIIIIl[llIIlIlIIIllll[117]] = lIIIIlllIIIlIllI("HDDhzUNHvTtMGFuJ+qEIhBgfhXdQ73h8+l8aQJPuRyxECoHsADEclp6OarC1YNrxEjXp4o7LkVQ=", "GNtQi");
    llIIlIlIIIIIIl[llIIlIlIIIllll[105]] = lIIIIlllIIIlIllI("AwWogEJXSonOAnlRaQU7XzDKdnUqoHIeFf+aS9L9jE8C/B0ifpIT3y0LPfE6z4CnMh8gbzMhAN4=", "npPvj");
    llIIlIlIIIIIIl[llIIlIlIIIllll[66]] = lIIIIlllIIIlIllI("PR+J+lEhR/eyhceXgbYEhr4e/tQyJsR9kh4qDQYov/re7r6yAqfSxXlWcr8BI+Tq0w+XkX2JhscxgSDSWAONbHls9D6y67GNxzsR3pR4awM=", "ZnUrt");
    llIIlIlIIIIIIl[llIIlIlIIIllll[119]] = lIIIIlllIIIlIllI("0femDh7bRhqxlBGfELI3ZlCPkh30CH5CnGrRcsOkAF7bozAV7k0v7N2qi/aUqax3+d60YTDbZZczpny+zvBcig==", "twkTP");
    llIIlIlIIIIIIl[llIIlIlIIIllll[67]] = lIIIIlllIIIlIlIl("pktqHXa08BG3VShMW9HfVIl1DPRpgDfAUwIwPdzuHI6gIPM8+/aigK5CqmYvJEvCAqwyRvMWO4FlFVwBaq/NLZrBO2PN56+Yo4LkOUuBQFo=", "RHEAD");
    llIIlIlIIIIIIl[llIIlIlIIIllll[109]] = lIIIIlllIIIlIllI("t8p0FgsgJpr4kk4zXh+w4RM7DH6SqMbrQsFMlXoNgOhSwRaJ7z/rtM6D/+16QcTk47OcyHMnRa4=", "JsWiU");
    llIIlIlIIIIIIl[llIIlIlIIIllll[78]] = lIIIIlllIIIlIllI("8b36SoDHGl1tWn+UjrkGkgv8670Fo88ohNVUi/k3kF5Qu56wCMVwbFjiZKMqx4iV11Lb5wcq+7A=", "oVFXg");
    llIIlIlIIIIIIl[llIIlIlIIIllll[120]] = lIIIIlllIIIllIll("IjYsdiclPT07OC01LHY/ODo0dictJzB2HCkwazxwKjo9NC4TZGpsfnUMO2J7fGl4eGo=", "LSXXJ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[121]] = lIIIIlllIIIlIllI("sYJa84f4U74gqpdP7PBPuuuSRTIXNr0k3Pbi+7wthJ24OLYteY0lWOS/vzmA+YUy", "BKBOC");
    llIIlIlIIIIIIl[llIIlIlIIIllll[60]] = lIIIIlllIIIlIllI("2YZ3NotW3bVYwCOLPa5U4MLjYy30xlRssG63RL4qR4E85DKk1/IZUv60d+JeDaGsdsTll30/0d4yudZv8VqCwaGbhnlBYuv33O1airkPq05RFClwplKIFw==", "uJUih");
    llIIlIlIIIIIIl[llIIlIlIIIllll[57]] = lIIIIlllIIIlIllI("bZ9E7Ng4bc9EXFMk64hiLcmzEIA/xbSZtzQOkiikvSbeB2BEH9lht1o7pHD2qHZ23zvSSf/gDsw18MFicwnLqA==", "FInEF");
    llIIlIlIIIIIIl[llIIlIlIIIllll[84]] = lIIIIlllIIIlIllI("IessnVh7p8McDW2rCeDWfsxPewegpvTljdD3yHHlUx47l4pigL09ErjNDtxuhzXs7tTJfqJQ+GqhkgHPC1hO9YJTwTULT6WX7t+FLSBP6oTu1Ml+olD4aqGSAc8LWE71BBV+dgUyy6cVSR1IS1ojo9jmap14lhRO", "ytExb");
    llIIlIlIIIIIIl[llIIlIlIIIllll[82]] = lIIIIlllIIIlIllI("fNrOBO9pwwUWFCThd/yIg6Q6xLCLzarJViRutj5IJIR1Cd4fhEz2luFWzoRPTxlY972wFxjdN+I=", "PRbID");
    llIIlIlIIIIIIl[llIIlIlIIIllll[116]] = lIIIIlllIIIlIllI("woVeZ4T7cZWdbUA1lALJFJlPkPEax9qZooKUS89plFK8kmIChVDrgKc8O1yaH9AgutzihtQKKag=", "qJNCx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[123]] = lIIIIlllIIIlIlIl("Ia27c/2ujRYAtDdciG7ETKIeZwGTjfR2bAG6IJ+uB+eYPRAdekwZudS1gG3yxWX4", "xPMNT");
    llIIlIlIIIIIIl[llIIlIlIIIllll[97]] = lIIIIlllIIIllIll("CQ4ZbzsOBQgiJAYNGW8/CQIZbxQLBA4qJV0NBCQ6AzRceGZeU1geMhNRX3t2R0tN", "gkmAV");
    llIIlIlIIIIIIl[llIIlIlIIIllll[118]] = lIIIIlllIIIlIlIl("8sXBGejSA/GW8unrLnxeksB18EZot5FAwuZ4SE2yN6UEYT+W43KCoenavgAtSKuYrXgfQLD/aA8=", "NGPoz");
    llIIlIlIIIIIIl[llIIlIlIIIllll[126]] = lIIIIlllIIIlIlIl("qFOmBCWNB51e9dd+RygNBnhtBwEaV8owWLhxqlgv7AM0GEDgCpZlBzHC+37qlZpQuyL4CAZdRCk=", "SKQBf");
    llIIlIlIIIIIIl[llIIlIlIIIllll[74]] = lIIIIlllIIIlIlIl("oKq2xTuDF4XXo1tJTfXbBPD4oMPTxuZ9PIOoOePSS0GWHaETZCU8bgl01N9ylbVfRg/+9nGd0J4=", "QehAz");
    llIIlIlIIIIIIl[llIIlIlIIIllll[77]] = lIIIIlllIIIlIlIl("w6AFjhLj4W+moTExUXyGF2Pr+WDBhMfZBaEHANAa9cJJ5ChQktU/2iCGKmtyWKDurMzgPeHITi9HZJybKZZDmzGrkTt9BjmJu0uitntg+DaH2iAH0K/laA==", "cnhep");
    llIIlIlIIIIIIl[llIIlIlIIIllll[125]] = lIIIIlllIIIlIllI("0AaCPYjJtSmFUlOF5MEovo9TCQYEwp/3LuQGB+KLu3EF7NxQwMEloiEfZiM5vdmfZONZvDgccaY=", "TdbDR");
    llIIlIlIIIIIIl[llIIlIlIIIllll[107]] = lIIIIlllIIIlIlIl("8LtTzXOOxf9LFrgIGKEFMPRWyPGjxYcDoa6zxRrxdYo3X4rM9Mn7Bb35R/g5dLUCn0Y/ZRu53Do=", "NeFXZ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[64]] = lIIIIlllIIIlIllI("Lq1ep7Jxhjix7tafLBcVr6nKHRS1D89WclK5UlDiKV73w7QsiIUeZKFvyNz5ubI8aajyepc03UhHJ5jwlaGYx0iPmMTBkcTYhblwciWpwdjrMDx6xnD85Q==", "ZQmUs");
    llIIlIlIIIIIIl[llIIlIlIIIllll[62]] = lIIIIlllIIIlIlIl("yybsDaemmN6iDFFGMjHFjr/CYOGIygh4emBtLt8Ib36Dc9sGU1F21bx6QGM0K5Xu", "SjauS");
    llIIlIlIIIIIIl[llIIlIlIIIllll[65]] = lIIIIlllIIIllIll("OC4Hfg8/JRYzEDctB34LOCIHfiA6JBA7EWwtGjUOMhRCZVJieEsPAAxxQWFYdmtTcA==", "VKsPb");
    llIIlIlIIIIIIl[llIIlIlIIIllll[68]] = lIIIIlllIIIllIll("HSo4ag4aISknERIpOGoKHSY4aiEfIC8vEEkpJSEPFxB9fFNHfngbAgN1fnRZU29sZA==", "sOLDc");
    llIIlIlIIIIIIl[llIIlIlIIIllll[129]] = lIIIIlllIIIllIll("BxZ+GzcfAzkcJwUUfgorGl02WHVQFDUcBhMWIzgsGUl4QQ8EFiRHLgMdNQsxCxUkRzYeGjxHLgsHOEcVDxBjDHhQUw==", "jsPhC");
    llIIlIlIIIIIIl[llIIlIlIIIllll[122]] = lIIIIlllIIIlIlIl("Cag0qKnBnSNF07fnO9QaGeRyttHcme0nCZqNXwbKYdCsewpN+PhHNX8XS2hbIdBIETVWJ4aNtdk=", "cVrCO");
    llIIlIlIIIIIIl[llIIlIlIIIllll[124]] = lIIIIlllIIIlIlIl("zGOfsYh05K+nYbmKa+qOJgCjthl/dc8HKFVvVlob7Wqp5d3vD2wJZj46rgyXPxhizg/QckQVp7I=", "lIoNX");
    llIIlIlIIIIIIl[llIIlIlIIIllll[63]] = lIIIIlllIIIllIll("FhIxfQQRGSAwGxkRMX0AFh4xfSsUGCY4GkIRLDYFHCh0a1lMRnYMCBdNd2NTWFdlcw==", "xwESi");
    llIIlIlIIIIIIl[llIIlIlIIIllll[131]] = lIIIIlllIIIlIllI("NlV3xGP8btMVCdbLGbqUuqMJxLZ0iiDtpEQj97g0s2fm8K1VEGTWW9t1xq3P1QB7ij3QD8Hrdl6mJhZCrQFYg1RZOnGSziBKwIEUq2wQui4wfyZkszyXFA==", "NXpEy");
    llIIlIlIIIIIIl[llIIlIlIIIllll[69]] = lIIIIlllIIIllIll("KRA+K3ovECYtegwTIi83N0stOyEiHTtwfA8bKTw1bB0pJDNsPiogMSAFc2MOeVFo", "CqHJT");
    llIIlIlIIIIIIl[llIIlIlIIIllll[83]] = lIIIIlllIIIlIllI("s2RVXnXvcxwjKwpcw9Rs87idGOaC32EehfZgX/KNiwj2mgFAlIP2p3C8OZ/iKvQ+q1Fv4hvTaY8=", "FIFej");
    llIIlIlIIIIIIl[llIIlIlIIIllll[130]] = lIIIIlllIIIlIlIl("UyIRvWrrnT80PC9ZB/udGPCFo7pBuE01qktyaf3txxM=", "fJSae");
    llIIlIlIIIIIIl[llIIlIlIIIllll[128]] = lIIIIlllIIIlIllI("3kjwSnMBlD+V+rrtAC921zkTM08zMMoOBKHJuCSkpidy7TnFOUGOOi+sPxb1+tY4pbRPEqAMJkc9PRTLuGUgOttJi82RiBKnpEF2YE0Yc+g=", "EnKbE");
    llIIlIlIIIIIIl[llIIlIlIIIllll[80]] = lIIIIlllIIIlIllI("mLu/EgfzhsTeVZnGO2JwKbHW0JmM5oLrAzSf+9UuNG52Kee3Ji01ZvxVovQxdipr6EZZ/6WMQkY=", "oWZRj");
    llIIlIlIIIIIIl[llIIlIlIIIllll[79]] = lIIIIlllIIIllIll("IC0aSBUnJgsFCi8uGkgbIiELCAxgLQASEToxQCMWOiEaHygiKRcDCh0YVAARKyQKOU9/eVlSJy9yW1xYbmg=", "NHnfx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[101]] = lIIIIlllIIIlIllI("TH9pMooNt6THA1TQnzWPFwXm+3cQe4tFjDzuAsiKKWya3ecQwGuaASPkt3dkbcIe1+EgQUQHD/1+0WGcePWPv/QaS4CTUKTf73B70lFBaTllCQnvVaQ1b4I5gESd5ri5", "FIymU");
    llIIlIlIIIIIIl[llIIlIlIIIllll[81]] = lIIIIlllIIIlIlIl("n041c0ATd0VRfkYc/fMRciCgz8dhHYp6x5cqjj5iYBbzAWOtA1WjRJHUekJwyoDMkFtP51PdIZI=", "cznof");
    llIIlIlIIIIIIl[llIIlIlIIIllll[89]] = lIIIIlllIIIlIlIl("sYuBU0GN/zZXXUati4/qqjO6ti3Rrf6x8rPF4uSQQFbeXbCPVD4q+t5KTAADsjJ9Ln0PpsN4cj4=", "bmIaV");
    llIIlIlIIIIIIl[llIIlIlIIIllll[111]] = lIIIIlllIIIlIllI("SZ8c8FLH2BsRgsIU7wWEDCVuaH8BMONW+YhtmVvsrNld8/Cu5gETgptDlpwk2fiAfiztinAuarmWg89DEAr8D0vhyBwHU/AUmJqLbUysWWm/qAyFEaND1A==", "WeTot");
    llIIlIlIIIIIIl[llIIlIlIIIllll[93]] = lIIIIlllIIIlIlIl("li0xnKbp7oSBBhOoOReylq+wID2/Z2QT07+qZ/1G7QWkZ/PCluvDKAGabKsd4orgG76vFXVndpKklIbVjxII0w==", "qeeBD");
    llIIlIlIIIIIIl[llIIlIlIIIllll[127]] = lIIIIlllIIIlIllI("mLuTiDeV8MDGbu9FqrOIiHryVLnavoSpGiGCavB3/9NzArbk2hlZfwWFtFI10+M3Fdp+0xcQW7a5uE/4OIK9MA==", "lywhX");
    llIIlIlIIIIIIl[llIIlIlIIIllll[88]] = lIIIIlllIIIlIllI("QRYyMF7SBA/HsnoG7dE5AUul2HjevLgTdnP4D7mWA6jOTmtkKp2pASGYCXNe7Z6wTov6qbrWX8s=", "ORlFn");
    llIIlIlIIIIIIl[llIIlIlIIIllll[59]] = lIIIIlllIIIlIlIl("3nooEB83KLUzrfojVWIrywLEyWD5QNusFMK90wqQ8jw=", "CerjP");
    llIIlIlIIIIIIl[llIIlIlIIIllll[72]] = lIIIIlllIIIlIlIl("5z38SxJfJXLvzfipQGUdC2y5bYzjr1BQeqFd1WCZNr0Q03WfJMt0Tat32QAXmCjeNzUtZXPk6+Q=", "ZaOBQ");
    llIIlIlIIIIIIl[llIIlIlIIIllll[73]] = lIIIIlllIIIlIlIl("DXvI4uCVfTGeqiZeaEDDW1KN/17DantvI8vRU5fJkmshP5VpikMXn2PWH/V1pE0ryB34kAHmB+g=", "fNPoH");
    llIIlIlIIIIIIl[llIIlIlIIIllll[132]] = lIIIIlllIIIlIllI("WrM6Lvjeb4I2NuaCkAz0x9Rw1LClFzmKT1qpAUew4XjbXUoOWTgd14ODj2HAvbCIKXxrDK91jOePRlOcyHtfozV2HMmae2P+uZXYSMr2Puh5n/JW1BjMxw==", "oHZWx");
    llIIlIlIIIIIIl[llIIlIlIIIllll[56]] = lIIIIlllIIIllIll("PRMWTy46GAcCMTIQFk8qPR8WTwE/GQEKMGkQCwQvNylTVHNnQFM+IRlMU1h5c1ZCQQ==", "SvbaC");
    llIIlIlIIIlllI = null;
  }
  
  private static void lIIIIlllIlIIIIII() {
    String str = (new Exception()).getStackTrace()[llIIlIlIIIllll[0]].getFileName();
    llIIlIlIIIlllI = str.substring(str.indexOf("ä") + llIIlIlIIIllll[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlllIIIllIll(String lllllllllllllllIllIIlIlIllllllll, String lllllllllllllllIllIIlIlIlllllllI) {
    lllllllllllllllIllIIlIlIllllllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIllllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIlIllllllIl = new StringBuilder();
    char[] lllllllllllllllIllIIlIlIllllllII = lllllllllllllllIllIIlIlIlllllllI.toCharArray();
    int lllllllllllllllIllIIlIlIlllllIll = llIIlIlIIIllll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlIlIllllllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIlIIIllll[0];
    while (lIIIIlllIlIIIIlI(j, i)) {
      char lllllllllllllllIllIIlIllIIIIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlIlIlllllIll++;
      j++;
      "".length();
      if (-"   ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlIlIllllllIl);
  }
  
  private static String lIIIIlllIIIlIllI(String lllllllllllllllIllIIlIlIllllIlll, String lllllllllllllllIllIIlIlIllllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIlIlllllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIlIllllIllI.getBytes(StandardCharsets.UTF_8)), llIIlIlIIIllll[9]), "DES");
      Cipher lllllllllllllllIllIIlIlIlllllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIlIlllllIIl.init(llIIlIlIIIllll[1], lllllllllllllllIllIIlIlIlllllIlI);
      return new String(lllllllllllllllIllIIlIlIlllllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIllllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIlIlllllIII) {
      lllllllllllllllIllIIlIlIlllllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlllIIIlIlIl(String lllllllllllllllIllIIlIlIllllIIlI, String lllllllllllllllIllIIlIlIllllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIlIllllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIlIllllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIlIllllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIlIllllIlII.init(llIIlIlIIIllll[1], lllllllllllllllIllIIlIlIllllIlIl);
      return new String(lllllllllllllllIllIIlIlIllllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIllllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIlIllllIIll) {
      lllllllllllllllIllIIlIlIllllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlllIlIIIIIl() {
    llIIlIlIIIllll = new int[134];
    llIIlIlIIIllll[0] = ("   ".length() << " ".length() << " ".length() << " ".length() ^ 0x15 ^ 0xE) << " ".length() & (((0x41 ^ 0x1A) << " ".length() ^ 39 + 88 - 108 + 138) << " ".length() ^ -" ".length());
    llIIlIlIIIllll[1] = " ".length() << " ".length();
    llIIlIlIIIllll[2] = " ".length();
    llIIlIlIIIllll[3] = (0x13 ^ 0x3A) << " ".length() ^ 0x9A ^ 0xC1;
    llIIlIlIIIllll[4] = "   ".length();
    llIIlIlIIIllll[5] = " ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[6] = 0x20 ^ 0x25;
    llIIlIlIIIllll[7] = "   ".length() << " ".length();
    llIIlIlIIIllll[8] = 0x95 ^ 0x92;
    llIIlIlIIIllll[9] = " ".length() << "   ".length();
    llIIlIlIIIllll[10] = 0x2A ^ 0x1B ^ "   ".length() << " ".length();
    llIIlIlIIIllll[11] = (0x3C ^ 0x39) << " ".length();
    llIIlIlIIIllll[12] = 0x9D ^ 0xB4 ^ (0x47 ^ 0x56) << " ".length();
    llIIlIlIIIllll[13] = "   ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[14] = 0x88 ^ 0x85;
    llIIlIlIIIllll[15] = (0x40 ^ 0x47) << " ".length();
    llIIlIlIIIllll[16] = 0x29 ^ 0x26;
    llIIlIlIIIllll[17] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[18] = (0xB8 ^ 0x8D) << " ".length() ^ 0x30 ^ 0x4B;
    llIIlIlIIIllll[19] = (0x20 ^ 0x29) << " ".length();
    llIIlIlIIIllll[20] = (0x7B ^ 0x72) << " ".length() ^ " ".length();
    llIIlIlIIIllll[21] = (0xC ^ 0x9) << " ".length() << " ".length();
    llIIlIlIIIllll[22] = 0x1A ^ 0x53 ^ (0x3F ^ 0x28) << " ".length() << " ".length();
    llIIlIlIIIllll[23] = (0x17 ^ 0x56 ^ (0x11 ^ 0x34) << " ".length()) << " ".length();
    llIIlIlIIIllll[24] = (0x76 ^ 0x41) << " ".length() ^ 0x25 ^ 0x5C;
    llIIlIlIIIllll[25] = "   ".length() << "   ".length();
    llIIlIlIIIllll[26] = 0xA6 ^ 0xBF;
    llIIlIlIIIllll[27] = (0x61 ^ 0x6C) << " ".length();
    llIIlIlIIIllll[28] = 0x76 ^ 0x6D;
    llIIlIlIIIllll[29] = (0xB8 ^ 0xBF) << " ".length() << " ".length();
    llIIlIlIIIllll[30] = 0x8 ^ 0x15;
    llIIlIlIIIllll[31] = (0xC8 ^ 0xC7) << " ".length();
    llIIlIlIIIllll[32] = 15 + 62 - 49 + 121 ^ (0x7B ^ 0x3E) << " ".length();
    llIIlIlIIIllll[33] = " ".length() << ((0x34 ^ 0x2B) << " ".length() << " ".length() ^ 0x2E ^ 0x57);
    llIIlIlIIIllll[34] = 0x85 ^ 0xA4;
    llIIlIlIIIllll[35] = (0x20 ^ 0x31) << " ".length();
    llIIlIlIIIllll[36] = 0x3B ^ 0x18;
    llIIlIlIIIllll[37] = ((0x51 ^ 0x56) << " ".length() << " ".length() ^ 0x3D ^ 0x28) << " ".length() << " ".length();
    llIIlIlIIIllll[38] = 0x2B ^ 0xE;
    llIIlIlIIIllll[39] = (0x4F ^ 0x5C) << " ".length();
    llIIlIlIIIllll[40] = 0xF3 ^ 0x90 ^ (0x5C ^ 0x4D) << " ".length() << " ".length();
    llIIlIlIIIllll[41] = (0xC7 ^ 0xC2) << "   ".length();
    llIIlIlIIIllll[42] = (0x9F ^ 0x82) << " ".length() << " ".length() ^ 0x9F ^ 0xC2;
    llIIlIlIIIllll[43] = (0x0 ^ 0x15) << " ".length();
    llIIlIlIIIllll[44] = 0x33 ^ 0x18;
    llIIlIlIIIllll[45] = (0x3B ^ 0x30) << " ".length() << " ".length();
    llIIlIlIIIllll[46] = 0xE ^ 0x23;
    llIIlIlIIIllll[47] = ((0xDD ^ 0xC4) << " ".length() ^ 0x4D ^ 0x68) << " ".length();
    llIIlIlIIIllll[48] = 120 + 111 - 170 + 104 ^ (0x5E ^ 0x1B) << " ".length();
    llIIlIlIIIllll[49] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[50] = 0x3 ^ 0x32;
    llIIlIlIIIllll[51] = (112 + 165 - 272 + 216 ^ (0x7F ^ 0x4E) << " ".length() << " ".length()) << " ".length();
    llIIlIlIIIllll[52] = 109 + 42 - 116 + 130 ^ (0x3F ^ 0x74) << " ".length();
    llIIlIlIIIllll[53] = ((0x53 ^ 0x60) << " ".length() ^ 0xD3 ^ 0xB8) << " ".length() << " ".length();
    llIIlIlIIIllll[54] = 0x21 ^ 0x14;
    llIIlIlIIIllll[55] = (0x92 ^ 0x89) << " ".length();
    llIIlIlIIIllll[56] = ("   ".length() ^ (0x2F ^ 0x3E) << " ".length()) << " ".length() << " ".length();
    llIIlIlIIIllll[57] = (0x83 ^ 0xAC) << " ".length();
    llIIlIlIIIllll[58] = (0x56 ^ 0x59) << " ".length() << " ".length();
    llIIlIlIIIllll[59] = " ".length() << (0x17 ^ 0x10);
    llIIlIlIIIllll[60] = 0x35 ^ 0x68;
    llIIlIlIIIllll[61] = ((0x2F ^ 0x74) << " ".length() ^ 3 + 111 - -2 + 31) << " ".length();
    llIIlIlIIIllll[62] = 0x93 ^ 0xC0 ^ (0x2C ^ 0x2B) << "   ".length();
    llIIlIlIIIllll[63] = (0x3C ^ 0x11) << " ".length() ^ 0x6C ^ 0x47;
    llIIlIlIIIllll[64] = (0xAE ^ 0x9B) << " ".length();
    llIIlIlIIIllll[65] = (0x19 ^ 0x2) << " ".length() << " ".length();
    llIIlIlIIIllll[66] = (0x4B ^ 0x60) << " ".length();
    llIIlIlIIIllll[67] = ((0x1A ^ 0x1D) << " ".length() << " ".length() << " ".length() ^ 0x52 ^ 0x29) << "   ".length();
    llIIlIlIIIllll[68] = 0x31 ^ 0x5C;
    llIIlIlIIIllll[69] = 0x9C ^ 0xB5 ^ (0x7F ^ 0x52) << " ".length();
    llIIlIlIIIllll[70] = 0x4F ^ 0x2;
    llIIlIlIIIllll[71] = 0xE4 ^ 0xA1;
    llIIlIlIIIllll[72] = ((0x8 ^ 0x3B) << " ".length()) + ((0xA6 ^ 0xB9) << " ".length()) - ((0xA1 ^ 0xA8) << "   ".length()) + (0x96 ^ 0xB3);
    llIIlIlIIIllll[73] = ((0x8F ^ 0x96) << " ".length() << " ".length() ^ 0x60 ^ 0x45) << " ".length();
    llIIlIlIIIllll[74] = (0x86 ^ 0xB5) << " ".length();
    llIIlIlIIIllll[75] = (0x0 ^ 0x1D) << " ".length();
    llIIlIlIIIllll[76] = ((0x31 ^ 0x36) << "   ".length() ^ 0x20 ^ 0x39) << " ".length();
    llIIlIlIIIllll[77] = 0xC ^ 0x6B;
    llIIlIlIIIllll[78] = (0x49 ^ 0x64) << " ".length();
    llIIlIlIIIllll[79] = (" ".length() << (0x57 ^ 0x52) ^ 0xA1 ^ 0x8E) << "   ".length();
    llIIlIlIIIllll[80] = 0x7B ^ 0xC;
    llIIlIlIIIllll[81] = ((0x49 ^ 0x5A) << " ".length() << " ".length() ^ 0x16 ^ 0x67) << " ".length();
    llIIlIlIIIllll[82] = "   ".length() << (0x99 ^ 0x9C);
    llIIlIlIIIllll[83] = ((0xB6 ^ 0xBB) << "   ".length() ^ 0x10 ^ 0x65) << " ".length() << " ".length();
    llIIlIlIIIllll[84] = 0x31 ^ 0x6E;
    llIIlIlIIIllll[85] = 0x38 ^ 0x7F;
    llIIlIlIIIllll[86] = " ".length() << " ".length() ^ 0xD1 ^ 0x90;
    llIIlIlIIIllll[87] = 0xE ^ 0x37;
    llIIlIlIIIllll[88] = 7 + 18 - -63 + 39;
    llIIlIlIIIllll[89] = 0x1C ^ 0x67;
    llIIlIlIIIllll[90] = (0x55 ^ 0x52) << "   ".length();
    llIIlIlIIIllll[91] = (0x3C ^ 0x4F) << " ".length() ^ 49 + 102 - 48 + 78;
    llIIlIlIIIllll[92] = (0x7B ^ 0x72) << "   ".length();
    llIIlIlIIIllll[93] = (0x4E ^ 0x4B) << "   ".length() ^ 0x4A ^ 0x1F;
    llIIlIlIIIllll[94] = " ".length() << "   ".length() ^ 0xB4 ^ 0x87;
    llIIlIlIIIllll[95] = (0x45 ^ 0x5A) << " ".length() ^ 0x20 ^ 0x51;
    llIIlIlIIIllll[96] = (0x2B ^ 0x3E) << "   ".length() ^ 5 + 110 - -24 + 10;
    llIIlIlIIIllll[97] = 95 + 56 - 103 + 117 ^ (0x22 ^ 0x41) << " ".length();
    llIIlIlIIIllll[98] = (0x12 ^ 0xD) << " ".length();
    llIIlIlIIIllll[99] = 0x35 ^ 0xA;
    llIIlIlIIIllll[100] = " ".length() << "   ".length() << " ".length();
    llIIlIlIIIllll[101] = 0xE6 ^ 0x9F;
    llIIlIlIIIllll[102] = 0x2E ^ 0x6F;
    llIIlIlIIIllll[103] = (0x69 ^ 0x78) << " ".length() << " ".length();
    llIIlIlIIIllll[104] = (0x62 ^ 0x41) << " ".length();
    llIIlIlIIIllll[105] = 0x13 ^ 0x46;
    llIIlIlIIIllll[106] = 0x63 ^ 0x2A;
    llIIlIlIIIllll[107] = 0xD0 ^ 0xB9;
    llIIlIlIIIllll[108] = 0x7B ^ 0x30;
    llIIlIlIIIllll[109] = (0x43 ^ 0x76) << " ".length() ^ 0x86 ^ 0xB5;
    llIIlIlIIIllll[110] = (0x81 ^ 0xC6 ^ (0x8A ^ 0x9F) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIlIlIIIllll[111] = ((0x2F ^ 0x64) << " ".length() ^ 124 + 70 - 148 + 91) << " ".length() << " ".length();
    llIIlIlIIIllll[112] = (0x9E ^ 0xB9) << " ".length();
    llIIlIlIIIllll[113] = ((0x4E ^ 0xF) << " ".length() ^ 50 + 73 - 21 + 69) << " ".length();
    llIIlIlIIIllll[114] = ((0x5D ^ 0x2) << " ".length() ^ 35 + 43 - 26 + 135) << " ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[115] = 0x40 ^ 0x11;
    llIIlIlIIIllll[116] = 0x2A ^ 0x4B;
    llIIlIlIIIllll[117] = (0x78 ^ 0x59 ^ (0x2D ^ 0x20) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIlIlIIIllll[118] = (0x2D ^ 0x34) << " ".length() << " ".length();
    llIIlIlIIIllll[119] = 0x3A ^ 0x6D;
    llIIlIlIIIllll[120] = 0xEE ^ 0xB5;
    llIIlIlIIIllll[121] = (" ".length() ^ (0x36 ^ 0x3D) << " ".length()) << " ".length() << " ".length();
    llIIlIlIIIllll[122] = 0xCB ^ 0xA4;
    llIIlIlIIIllll[123] = ((0x52 ^ 0x5) << " ".length() ^ 103 + 91 - 109 + 74) << " ".length();
    llIIlIlIIIllll[124] = ((0x99 ^ 0x88) << " ".length() ^ 0x48 ^ 0x6D) << " ".length() << " ".length() << " ".length();
    llIIlIlIIIllll[125] = (0x23 ^ 0x2E) << "   ".length();
    llIIlIlIIIllll[126] = (0xDC ^ 0xA5) << " ".length() ^ 82 + 147 - 136 + 58;
    llIIlIlIIIllll[127] = (0x1D ^ 0xA ^ (0xA3 ^ 0xA6) << "   ".length()) << " ".length();
    llIIlIlIIIllll[128] = ((0x57 ^ 0x58) << "   ".length() ^ 0x1D ^ 0x5E) << " ".length();
    llIIlIlIIIllll[129] = ((0x1E ^ 0xB) << " ".length() << " ".length() ^ 0xF0 ^ 0x93) << " ".length();
    llIIlIlIIIllll[130] = (0xD ^ 0x16) << " ".length() ^ 0x1 ^ 0x42;
    llIIlIlIIIllll[131] = (0xB7 ^ 0x8E) << " ".length();
    llIIlIlIIIllll[132] = 118 + 47 - 116 + 82;
    llIIlIlIIIllll[133] = 111 + 120 - 228 + 124 + (" ".length() << (0x8F ^ 0x8A)) - ((0x95 ^ 0xA0) << " ".length()) + ((0x23 ^ 0x26) << " ".length() << " ".length() << " ".length());
  }
  
  private static boolean lIIIIlllIlIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlllIlIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlllIlIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlllIlIIIlII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlllIlIIIIll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlllIlIIlIll(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lIIIIlllIlIIlIlI(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lIIIIlllIlIIIllI(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static int lIIIIlllIlIIIlIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIlllIlIIIlll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIlllIlIIlIIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIlllIlIIlIII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f06.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */