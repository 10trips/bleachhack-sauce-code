package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.EnumFacing;

public final class ab {
  public static final HashMap<EnumFacing, Integer> FACEMAP;
  
  private static String[] lIllllllllllll;
  
  private static Class[] llIIIIIIIIIIII;
  
  private static final String[] llIIIIIIIlIlll;
  
  private static String[] llIIIIIIIllIII;
  
  private static final int[] llIIIIIIIllIIl;
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIIIlIIIlIIII : ()V
    //   3: invokestatic lIIIIIIlIIIIllll : ()V
    //   6: invokestatic lIIIIIIlIIIIlllI : ()V
    //   9: invokestatic lIIIIIIlIIIIlIlI : ()V
    //   12: new java/util/HashMap
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: putstatic me/stupitdog/bhp/ab.FACEMAP : Ljava/util/HashMap;
    //   22: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   27: <illegal opcode> 1 : ()Lnet/minecraft/util/EnumFacing;
    //   32: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   35: iconst_0
    //   36: iaload
    //   37: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   42: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   47: ldc ''
    //   49: invokevirtual length : ()I
    //   52: pop2
    //   53: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   58: <illegal opcode> 4 : ()Lnet/minecraft/util/EnumFacing;
    //   63: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   66: iconst_1
    //   67: iaload
    //   68: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   73: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   78: ldc ''
    //   80: invokevirtual length : ()I
    //   83: pop2
    //   84: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   89: <illegal opcode> 5 : ()Lnet/minecraft/util/EnumFacing;
    //   94: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   97: iconst_2
    //   98: iaload
    //   99: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   104: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   109: ldc ''
    //   111: invokevirtual length : ()I
    //   114: pop2
    //   115: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   120: <illegal opcode> 6 : ()Lnet/minecraft/util/EnumFacing;
    //   125: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   128: iconst_3
    //   129: iaload
    //   130: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   135: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   140: ldc ''
    //   142: invokevirtual length : ()I
    //   145: pop2
    //   146: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   151: <illegal opcode> 7 : ()Lnet/minecraft/util/EnumFacing;
    //   156: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   159: iconst_4
    //   160: iaload
    //   161: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   166: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   171: ldc ''
    //   173: invokevirtual length : ()I
    //   176: pop2
    //   177: <illegal opcode> 0 : ()Ljava/util/HashMap;
    //   182: <illegal opcode> 8 : ()Lnet/minecraft/util/EnumFacing;
    //   187: getstatic me/stupitdog/bhp/ab.llIIIIIIIllIIl : [I
    //   190: iconst_5
    //   191: iaload
    //   192: <illegal opcode> 2 : (I)Ljava/lang/Integer;
    //   197: <illegal opcode> 3 : (Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   202: ldc ''
    //   204: invokevirtual length : ()I
    //   207: pop2
    //   208: return
  }
  
  private static CallSite lIIIIIIIllIlIIII(MethodHandles.Lookup lllllllllllllllIllIllllIIIlllIIl, String lllllllllllllllIllIllllIIIlllIII, MethodType lllllllllllllllIllIllllIIIllIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllllIIIllllll = lIllllllllllll[Integer.parseInt(lllllllllllllllIllIllllIIIlllIII)].split(llIIIIIIIlIlll[llIIIIIIIllIIl[6]]);
      Class<?> lllllllllllllllIllIllllIIIlllllI = Class.forName(lllllllllllllllIllIllllIIIllllll[llIIIIIIIllIIl[6]]);
      String lllllllllllllllIllIllllIIIllllIl = lllllllllllllllIllIllllIIIllllll[llIIIIIIIllIIl[0]];
      MethodHandle lllllllllllllllIllIllllIIIllllII = null;
      int lllllllllllllllIllIllllIIIlllIll = lllllllllllllllIllIllllIIIllllll[llIIIIIIIllIIl[7]].length();
      if (lIIIIIIlIIIlIIIl(lllllllllllllllIllIllllIIIlllIll, llIIIIIIIllIIl[5])) {
        MethodType lllllllllllllllIllIllllIIlIIIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllllIIIllllll[llIIIIIIIllIIl[5]], ab.class.getClassLoader());
        if (lIIIIIIlIIIlIIlI(lllllllllllllllIllIllllIIIlllIll, llIIIIIIIllIIl[5])) {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findVirtual(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIIl);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findStatic(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIIl);
        } 
        "".length();
        if (-" ".length() >= " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllllIIlIIIIII = llIIIIIIIIIIII[Integer.parseInt(lllllllllllllllIllIllllIIIllllll[llIIIIIIIllIIl[5]])];
        if (lIIIIIIlIIIlIIlI(lllllllllllllllIllIllllIIIlllIll, llIIIIIIIllIIl[7])) {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findGetter(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIII);
          "".length();
          if (" ".length() < " ".length())
            return null; 
        } else if (lIIIIIIlIIIlIIlI(lllllllllllllllIllIllllIIIlllIll, llIIIIIIIllIIl[2])) {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findStaticGetter(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIlIIIlIIlI(lllllllllllllllIllIllllIIIlllIll, llIIIIIIIllIIl[8])) {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findSetter(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIllllIIIllllII = lllllllllllllllIllIllllIIIlllIIl.findStaticSetter(lllllllllllllllIllIllllIIIlllllI, lllllllllllllllIllIllllIIIllllIl, lllllllllllllllIllIllllIIlIIIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllllIIIllllII);
    } catch (Exception lllllllllllllllIllIllllIIIlllIlI) {
      lllllllllllllllIllIllllIIIlllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIIIlIlI() {
    lIllllllllllll = new String[llIIIIIIIllIIl[9]];
    lIllllllllllll[llIIIIIIIllIIl[10]] = llIIIIIIIlIlll[llIIIIIIIllIIl[0]];
    lIllllllllllll[llIIIIIIIllIIl[7]] = llIIIIIIIlIlll[llIIIIIIIllIIl[5]];
    lIllllllllllll[llIIIIIIIllIIl[11]] = llIIIIIIIlIlll[llIIIIIIIllIIl[7]];
    lIllllllllllll[llIIIIIIIllIIl[3]] = llIIIIIIIlIlll[llIIIIIIIllIIl[2]];
    lIllllllllllll[llIIIIIIIllIIl[6]] = llIIIIIIIlIlll[llIIIIIIIllIIl[8]];
    lIllllllllllll[llIIIIIIIllIIl[5]] = llIIIIIIIlIlll[llIIIIIIIllIIl[10]];
    lIllllllllllll[llIIIIIIIllIIl[2]] = llIIIIIIIlIlll[llIIIIIIIllIIl[11]];
    lIllllllllllll[llIIIIIIIllIIl[0]] = llIIIIIIIlIlll[llIIIIIIIllIIl[3]];
    lIllllllllllll[llIIIIIIIllIIl[8]] = llIIIIIIIlIlll[llIIIIIIIllIIl[9]];
    llIIIIIIIIIIII = new Class[llIIIIIIIllIIl[5]];
    llIIIIIIIIIIII[llIIIIIIIllIIl[0]] = EnumFacing.class;
    llIIIIIIIIIIII[llIIIIIIIllIIl[6]] = HashMap.class;
  }
  
  private static void lIIIIIIlIIIIlllI() {
    llIIIIIIIlIlll = new String[llIIIIIIIllIIl[12]];
    llIIIIIIIlIlll[llIIIIIIIllIIl[6]] = lIIIIIIlIIIIlIll(llIIIIIIIllIII[llIIIIIIIllIIl[6]], llIIIIIIIllIII[llIIIIIIIllIIl[0]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[0]] = lIIIIIIlIIIIllII(llIIIIIIIllIII[llIIIIIIIllIIl[5]], llIIIIIIIllIII[llIIIIIIIllIIl[7]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[5]] = lIIIIIIlIIIIllII(llIIIIIIIllIII[llIIIIIIIllIIl[2]], llIIIIIIIllIII[llIIIIIIIllIIl[8]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[7]] = lIIIIIIlIIIIllIl(llIIIIIIIllIII[llIIIIIIIllIIl[10]], llIIIIIIIllIII[llIIIIIIIllIIl[11]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[2]] = lIIIIIIlIIIIllIl(llIIIIIIIllIII[llIIIIIIIllIIl[3]], llIIIIIIIllIII[llIIIIIIIllIIl[9]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[8]] = lIIIIIIlIIIIllIl(llIIIIIIIllIII[llIIIIIIIllIIl[12]], llIIIIIIIllIII[llIIIIIIIllIIl[13]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[10]] = lIIIIIIlIIIIllII(llIIIIIIIllIII[llIIIIIIIllIIl[14]], llIIIIIIIllIII[llIIIIIIIllIIl[15]]);
    llIIIIIIIlIlll[llIIIIIIIllIIl[11]] = lIIIIIIlIIIIllIl("JOcCQiI6EI6cr8Qb4S3JfSbDNE96aJHysaCEJY8xRk8N7vkksuRrxQbyTP8XMRHQ", "TRIyh");
    llIIIIIIIlIlll[llIIIIIIIllIIl[3]] = lIIIIIIlIIIIllIl("NkyxSYOJk5yNeTWRu/P9P6/NVCqOXxncD5BIa8TQA9GSTO6G2whu7+Bo/6uGDNGM", "OMMzC");
    llIIIIIIIlIlll[llIIIIIIIllIIl[9]] = lIIIIIIlIIIIllII("jSoAXwOAwTxMZzzgPriCbsaYGMLH+7UgP3y5Ux0OEzBy8N5Wrsob/GdoCPEapMaJ", "iqVoo");
    llIIIIIIIllIII = null;
  }
  
  private static void lIIIIIIlIIIIllll() {
    String str = (new Exception()).getStackTrace()[llIIIIIIIllIIl[6]].getFileName();
    llIIIIIIIllIII = str.substring(str.indexOf("ä") + llIIIIIIIllIIl[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIIIIlIll(String lllllllllllllllIllIllllIIIllIlIl, String lllllllllllllllIllIllllIIIllIlII) {
    lllllllllllllllIllIllllIIIllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIllllIIIllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllllIIIllIIll = new StringBuilder();
    char[] lllllllllllllllIllIllllIIIllIIlI = lllllllllllllllIllIllllIIIllIlII.toCharArray();
    int lllllllllllllllIllIllllIIIllIIIl = llIIIIIIIllIIl[6];
    char[] arrayOfChar1 = lllllllllllllllIllIllllIIIllIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIIllIIl[6];
    while (lIIIIIIlIIIlIIll(j, i)) {
      char lllllllllllllllIllIllllIIIllIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllllIIIllIIIl++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllllIIIllIIll);
  }
  
  private static String lIIIIIIlIIIIllIl(String lllllllllllllllIllIllllIIIlIllIl, String lllllllllllllllIllIllllIIIlIllII) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIIIllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIIIlIllII.getBytes(StandardCharsets.UTF_8)), llIIIIIIIllIIl[3]), "DES");
      Cipher lllllllllllllllIllIllllIIIlIllll = Cipher.getInstance("DES");
      lllllllllllllllIllIllllIIIlIllll.init(llIIIIIIIllIIl[5], lllllllllllllllIllIllllIIIllIIII);
      return new String(lllllllllllllllIllIllllIIIlIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIIIlIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIIIlIlllI) {
      lllllllllllllllIllIllllIIIlIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIIIIllII(String lllllllllllllllIllIllllIIIlIlIII, String lllllllllllllllIllIllllIIIlIIlll) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIIIlIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIIIlIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllllIIIlIlIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllllIIIlIlIlI.init(llIIIIIIIllIIl[5], lllllllllllllllIllIllllIIIlIlIll);
      return new String(lllllllllllllllIllIllllIIIlIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIIIlIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIIIlIlIIl) {
      lllllllllllllllIllIllllIIIlIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIIlIIII() {
    llIIIIIIIllIIl = new int[16];
    llIIIIIIIllIIl[0] = " ".length();
    llIIIIIIIllIIl[1] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIIllIIl[2] = " ".length() << " ".length() << " ".length();
    llIIIIIIIllIIl[3] = " ".length() << "   ".length();
    llIIIIIIIllIIl[4] = " ".length() << (0x17 ^ 0x44 ^ (0x4F ^ 0x64) << " ".length());
    llIIIIIIIllIIl[5] = " ".length() << " ".length();
    llIIIIIIIllIIl[6] = (53 + 27 - 74 + 121 ^ (0x64 ^ 0x7F) << " ".length() << " ".length()) & (0x2 ^ 0x7F ^ (0x2A ^ 0x1D) << " ".length() ^ -" ".length());
    llIIIIIIIllIIl[7] = "   ".length();
    llIIIIIIIllIIl[8] = 0x50 ^ 0x9 ^ (0x25 ^ 0x32) << " ".length() << " ".length();
    llIIIIIIIllIIl[9] = 0xA9 ^ 0xA0;
    llIIIIIIIllIIl[10] = "   ".length() << " ".length();
    llIIIIIIIllIIl[11] = 26 + 40 - 17 + 86 ^ " ".length() << (0x13 ^ 0x14);
    llIIIIIIIllIIl[12] = (0x59 ^ 0x5C) << " ".length();
    llIIIIIIIllIIl[13] = 0xDF ^ 0xAC ^ (0x2A ^ 0x25) << "   ".length();
    llIIIIIIIllIIl[14] = "   ".length() << " ".length() << " ".length();
    llIIIIIIIllIIl[15] = 0x66 ^ 0x6B;
  }
  
  private static boolean lIIIIIIlIIIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlIIIlIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlIIIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  public static final class Line {
    public static final int DOWN_WEST;
    
    public static final int UP_WEST = lIlllIIllIlIlI[1];
    
    public static final int DOWN_EAST;
    
    public static final int UP_EAST;
    
    public static final int DOWN_NORTH;
    
    public static final int UP_NORTH;
    
    public static final int DOWN_SOUTH;
    
    public static final int UP_SOUTH = lIlllIIllIlIlI[0];
    
    public static final int NORTH_WEST;
    
    public static final int NORTH_EAST;
    
    public static final int SOUTH_WEST = lIlllIIllIlIlI[2];
    
    public static final int SOUTH_EAST;
    
    public static final int ALL;
    
    private static final int[] lIlllIIllIlIlI;
    
    static {
      UP_NORTH = lIlllIIllIlIlI[3];
      DOWN_SOUTH = lIlllIIllIlIlI[4];
      SOUTH_EAST = lIlllIIllIlIlI[5];
      UP_EAST = lIlllIIllIlIlI[6];
      DOWN_EAST = lIlllIIllIlIlI[7];
      DOWN_NORTH = lIlllIIllIlIlI[8];
      NORTH_EAST = lIlllIIllIlIlI[9];
      ALL = lIlllIIllIlIlI[10];
      DOWN_WEST = lIlllIIllIlIlI[11];
      NORTH_WEST = lIlllIIllIlIlI[12];
    }
    
    private static void lllllIIlIIIIlll() {
      lIlllIIllIlIlI = new int[13];
      lIlllIIllIlIlI[0] = ((0xA0 ^ 0xA7) << " ".length() << " ".length() ^ 0xBF ^ 0xA6) << " ".length();
      lIlllIIllIlIlI[1] = (67 + 132 - 5 + 11 ^ (0x5B ^ 0x6A) << " ".length() << " ".length()) << " ".length();
      lIlllIIllIlIlI[2] = "   ".length() << "   ".length();
      lIlllIIllIlIlI[3] = "   ".length() << " ".length();
      lIlllIIllIlIlI[4] = (0x4C ^ 0x6B) << " ".length() << " ".length() ^ 27 + 131 - 123 + 114;
      lIlllIIllIlIlI[5] = (0xBA ^ 0xBF) << "   ".length();
      lIlllIIllIlIlI[6] = ((0xC8 ^ 0xC5) << " ".length() << " ".length() << " ".length() ^ 34 + 107 - 68 + 120) << " ".length();
      lIlllIIllIlIlI[7] = 0x45 ^ 0x64;
      lIlllIIllIlIlI[8] = 0x7 ^ 0x2;
      lIlllIIllIlIlI[9] = (0x9D ^ 0x94) << " ".length() << " ".length();
      lIlllIIllIlIlI[10] = 0x11 ^ 0x2E;
      lIlllIIllIlIlI[11] = 0x0 ^ 0x11;
      lIlllIIllIlIlI[12] = (0xAE ^ 0xAB) << " ".length() << " ".length();
    }
    
    static {
      lllllIIlIIIIlll();
    }
  }
  
  public static final class Quad {
    public static final int DOWN;
    
    public static final int UP;
    
    public static final int NORTH;
    
    public static final int SOUTH = lIllIIllllllll[0];
    
    public static final int WEST = lIllIIllllllll[1];
    
    public static final int EAST = lIllIIllllllll[3];
    
    public static final int ALL = lIllIIllllllll[2];
    
    private static final int[] lIllIIllllllll;
    
    static {
      DOWN = lIllIIllllllll[4];
      NORTH = lIllIIllllllll[5];
      UP = lIllIIllllllll[6];
    }
    
    private static void llllIIlIIIIlIII() {
      lIllIIllllllll = new int[7];
      lIllIIllllllll[0] = " ".length() << "   ".length();
      lIllIIllllllll[1] = " ".length() << " ".length() << " ".length() << " ".length();
      lIllIIllllllll[2] = (0x6 ^ 0x9) << "   ".length() ^ 0x71 ^ 0x36;
      lIllIIllllllll[3] = " ".length() << (0x19 ^ 0x1C);
      lIllIIllllllll[4] = " ".length();
      lIllIIllllllll[5] = " ".length() << " ".length() << " ".length();
      lIllIIllllllll[6] = " ".length() << " ".length();
    }
    
    static {
      llllIIlIIIIlIII();
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */