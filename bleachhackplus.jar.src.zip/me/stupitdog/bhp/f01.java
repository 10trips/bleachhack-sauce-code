package me.stupitdog.bhp;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f01 extends Color {
  private static final long serialVersionUID = 1L;
  
  private static String[] lIllllIllIIIlI;
  
  private static Class[] lIllllIllIIIll;
  
  private static final String[] lIllllIllIIlII;
  
  private static String[] lIllllIllIIllI;
  
  private static final int[] lIllllIllIIlll;
  
  public f01(int lllllllllllllllIlllIIlIIlIIIIIIl) {
    super(lllllllllllllllIlllIIlIIlIIIIIIl);
  }
  
  public f01(int lllllllllllllllIlllIIlIIIlllllll, boolean lllllllllllllllIlllIIlIIIllllllI) {
    super(lllllllllllllllIlllIIlIIIlllllll, lllllllllllllllIlllIIlIIIllllllI);
  }
  
  public f01(int lllllllllllllllIlllIIlIIIlllllII, int lllllllllllllllIlllIIlIIIllllIll, int lllllllllllllllIlllIIlIIIllllIlI) {
    super(lllllllllllllllIlllIIlIIIlllllII, lllllllllllllllIlllIIlIIIllllIll, lllllllllllllllIlllIIlIIIllllIlI);
  }
  
  public f01(int lllllllllllllllIlllIIlIIIllllIII, int lllllllllllllllIlllIIlIIIlllIlll, int lllllllllllllllIlllIIlIIIlllIllI, int lllllllllllllllIlllIIlIIIlllIlIl) {
    super(lllllllllllllllIlllIIlIIIllllIII, lllllllllllllllIlllIIlIIIlllIlll, lllllllllllllllIlllIIlIIIlllIllI, lllllllllllllllIlllIIlIIIlllIlIl);
  }
  
  public f01(Color lllllllllllllllIlllIIlIIIlllIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Ljava/awt/Color;)I
    //   7: aload_1
    //   8: <illegal opcode> 1 : (Ljava/awt/Color;)I
    //   13: aload_1
    //   14: <illegal opcode> 2 : (Ljava/awt/Color;)I
    //   19: aload_1
    //   20: <illegal opcode> 3 : (Ljava/awt/Color;)I
    //   25: invokespecial <init> : (IIII)V
    //   28: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	29	0	lllllllllllllllIlllIIlIIIlllIlII	Lme/stupitdog/bhp/f01;
    //   0	29	1	lllllllllllllllIlllIIlIIIlllIIll	Ljava/awt/Color;
  }
  
  public f01(f01 lllllllllllllllIlllIIlIIIlllIIIl, int lllllllllllllllIlllIIlIIIlllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lme/stupitdog/bhp/f01;)I
    //   7: aload_1
    //   8: <illegal opcode> 5 : (Lme/stupitdog/bhp/f01;)I
    //   13: aload_1
    //   14: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   19: iload_2
    //   20: invokespecial <init> : (IIII)V
    //   23: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	24	0	lllllllllllllllIlllIIlIIIlllIIlI	Lme/stupitdog/bhp/f01;
    //   0	24	1	lllllllllllllllIlllIIlIIIlllIIIl	Lme/stupitdog/bhp/f01;
    //   0	24	2	lllllllllllllllIlllIIlIIIlllIIII	I
  }
  
  public static f01 fromHSB(float lllllllllllllllIlllIIlIIIllIllll, float lllllllllllllllIlllIIlIIIllIlllI, float lllllllllllllllIlllIIlIIIllIllIl) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f01
    //   3: dup
    //   4: fload_0
    //   5: fload_1
    //   6: fload_2
    //   7: <illegal opcode> 7 : (FFF)Ljava/awt/Color;
    //   12: invokespecial <init> : (Ljava/awt/Color;)V
    //   15: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIIlIIIllIllll	F
    //   0	16	1	lllllllllllllllIlllIIlIIIllIlllI	F
    //   0	16	2	lllllllllllllllIlllIIlIIIllIllIl	F
  }
  
  public float getHue() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/f01;)I
    //   6: aload_0
    //   7: <illegal opcode> 5 : (Lme/stupitdog/bhp/f01;)I
    //   12: aload_0
    //   13: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   18: aconst_null
    //   19: <illegal opcode> 8 : (III[F)[F
    //   24: getstatic me/stupitdog/bhp/f01.lIllllIllIIlll : [I
    //   27: iconst_0
    //   28: iaload
    //   29: faload
    //   30: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIlllIIlIIIllIllII	Lme/stupitdog/bhp/f01;
  }
  
  public float getSaturation() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/f01;)I
    //   6: aload_0
    //   7: <illegal opcode> 5 : (Lme/stupitdog/bhp/f01;)I
    //   12: aload_0
    //   13: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   18: aconst_null
    //   19: <illegal opcode> 8 : (III[F)[F
    //   24: getstatic me/stupitdog/bhp/f01.lIllllIllIIlll : [I
    //   27: iconst_1
    //   28: iaload
    //   29: faload
    //   30: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIlllIIlIIIllIlIll	Lme/stupitdog/bhp/f01;
  }
  
  public float getBrightness() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/f01;)I
    //   6: aload_0
    //   7: <illegal opcode> 5 : (Lme/stupitdog/bhp/f01;)I
    //   12: aload_0
    //   13: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   18: aconst_null
    //   19: <illegal opcode> 8 : (III[F)[F
    //   24: getstatic me/stupitdog/bhp/f01.lIllllIllIIlll : [I
    //   27: iconst_2
    //   28: iaload
    //   29: faload
    //   30: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIlllIIlIIIllIlIlI	Lme/stupitdog/bhp/f01;
  }
  
  public void glColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/f01;)I
    //   6: i2f
    //   7: ldc 255.0
    //   9: fdiv
    //   10: aload_0
    //   11: <illegal opcode> 5 : (Lme/stupitdog/bhp/f01;)I
    //   16: i2f
    //   17: ldc 255.0
    //   19: fdiv
    //   20: aload_0
    //   21: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   26: i2f
    //   27: ldc 255.0
    //   29: fdiv
    //   30: aload_0
    //   31: <illegal opcode> 9 : (Lme/stupitdog/bhp/f01;)I
    //   36: i2f
    //   37: ldc 255.0
    //   39: fdiv
    //   40: <illegal opcode> 10 : (FFFF)V
    //   45: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	46	0	lllllllllllllllIlllIIlIIIllIlIIl	Lme/stupitdog/bhp/f01;
  }
  
  static {
    lllllllIIlllIll();
    lllllllIIllIIII();
    lllllllIIlIllll();
    lllllllIIlIlIll();
  }
  
  private static CallSite lllllllIIlIlIlI(MethodHandles.Lookup lllllllllllllllIlllIIlIIIllIIIII, String lllllllllllllllIlllIIlIIIlIlllll, MethodType lllllllllllllllIlllIIlIIIlIllllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIIIllIIllI = lIllllIllIIIlI[Integer.parseInt(lllllllllllllllIlllIIlIIIlIlllll)].split(lIllllIllIIlII[lIllllIllIIlll[0]]);
      Class<?> lllllllllllllllIlllIIlIIIllIIlIl = Class.forName(lllllllllllllllIlllIIlIIIllIIllI[lIllllIllIIlll[0]]);
      String lllllllllllllllIlllIIlIIIllIIlII = lllllllllllllllIlllIIlIIIllIIllI[lIllllIllIIlll[1]];
      MethodHandle lllllllllllllllIlllIIlIIIllIIIll = null;
      int lllllllllllllllIlllIIlIIIllIIIlI = lllllllllllllllIlllIIlIIIllIIllI[lIllllIllIIlll[3]].length();
      if (lllllllIIllllII(lllllllllllllllIlllIIlIIIllIIIlI, lIllllIllIIlll[2])) {
        MethodType lllllllllllllllIlllIIlIIIllIlIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIIIllIIllI[lIllllIllIIlll[2]], f01.class.getClassLoader());
        if (lllllllIIllllIl(lllllllllllllllIlllIIlIIIllIIIlI, lIllllIllIIlll[2])) {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findVirtual(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIlIII);
          "".length();
          if ((" ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) < 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findStatic(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIlIII);
        } 
        "".length();
        if ("   ".length() >= " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIIIllIIlll = lIllllIllIIIll[Integer.parseInt(lllllllllllllllIlllIIlIIIllIIllI[lIllllIllIIlll[2]])];
        if (lllllllIIllllIl(lllllllllllllllIlllIIlIIIllIIIlI, lIllllIllIIlll[3])) {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findGetter(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIIlll);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else if (lllllllIIllllIl(lllllllllllllllIlllIIlIIIllIIIlI, lIllllIllIIlll[4])) {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findStaticGetter(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIIlll);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllllIIllllIl(lllllllllllllllIlllIIlIIIllIIIlI, lIllllIllIIlll[5])) {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findSetter(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIIlll);
          "".length();
          if (" ".length() << " ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIIIllIIIll = lllllllllllllllIlllIIlIIIllIIIII.findStaticSetter(lllllllllllllllIlllIIlIIIllIIlIl, lllllllllllllllIlllIIlIIIllIIlII, lllllllllllllllIlllIIlIIIllIIlll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIIIllIIIll);
    } catch (Exception lllllllllllllllIlllIIlIIIllIIIIl) {
      lllllllllllllllIlllIIlIIIllIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIIlIlIll() {
    lIllllIllIIIlI = new String[lIllllIllIIlll[6]];
    lIllllIllIIIlI[lIllllIllIIlll[7]] = lIllllIllIIlII[lIllllIllIIlll[1]];
    lIllllIllIIIlI[lIllllIllIIlll[3]] = lIllllIllIIlII[lIllllIllIIlll[2]];
    lIllllIllIIIlI[lIllllIllIIlll[8]] = lIllllIllIIlII[lIllllIllIIlll[3]];
    lIllllIllIIIlI[lIllllIllIIlll[5]] = lIllllIllIIlII[lIllllIllIIlll[4]];
    lIllllIllIIIlI[lIllllIllIIlll[0]] = lIllllIllIIlII[lIllllIllIIlll[5]];
    lIllllIllIIIlI[lIllllIllIIlll[9]] = lIllllIllIIlII[lIllllIllIIlll[8]];
    lIllllIllIIIlI[lIllllIllIIlll[1]] = lIllllIllIIlII[lIllllIllIIlll[10]];
    lIllllIllIIIlI[lIllllIllIIlll[10]] = lIllllIllIIlII[lIllllIllIIlll[9]];
    lIllllIllIIIlI[lIllllIllIIlll[11]] = lIllllIllIIlII[lIllllIllIIlll[7]];
    lIllllIllIIIlI[lIllllIllIIlll[2]] = lIllllIllIIlII[lIllllIllIIlll[11]];
    lIllllIllIIIlI[lIllllIllIIlll[4]] = lIllllIllIIlII[lIllllIllIIlll[6]];
    lIllllIllIIIll = new Class[lIllllIllIIlll[0]];
  }
  
  private static void lllllllIIlIllll() {
    lIllllIllIIlII = new String[lIllllIllIIlll[12]];
    lIllllIllIIlII[lIllllIllIIlll[0]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[0]], lIllllIllIIllI[lIllllIllIIlll[1]]);
    lIllllIllIIlII[lIllllIllIIlll[1]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[2]], lIllllIllIIllI[lIllllIllIIlll[3]]);
    lIllllIllIIlII[lIllllIllIIlll[2]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[4]], lIllllIllIIllI[lIllllIllIIlll[5]]);
    lIllllIllIIlII[lIllllIllIIlll[3]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[8]], lIllllIllIIllI[lIllllIllIIlll[10]]);
    lIllllIllIIlII[lIllllIllIIlll[4]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[9]], lIllllIllIIllI[lIllllIllIIlll[7]]);
    lIllllIllIIlII[lIllllIllIIlll[5]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[11]], lIllllIllIIllI[lIllllIllIIlll[6]]);
    lIllllIllIIlII[lIllllIllIIlll[8]] = lllllllIIlIllIl(lIllllIllIIllI[lIllllIllIIlll[12]], lIllllIllIIllI[lIllllIllIIlll[13]]);
    lIllllIllIIlII[lIllllIllIIlll[10]] = lllllllIIlIllII(lIllllIllIIllI[lIllllIllIIlll[14]], lIllllIllIIllI[lIllllIllIIlll[15]]);
    lIllllIllIIlII[lIllllIllIIlll[9]] = lllllllIIlIllII("bv+F7hjhkfK8G5TXHixK/JX1wqd4ZXg4UVtEu8Mxiiy9hNeNLj5rph5f61ynct1ZjhdFJ5kbDAs=", "lwCcs");
    lIllllIllIIlII[lIllllIllIIlll[7]] = lllllllIIlIlllI("HjYgRAEZPTEJHhE1IEQPHDoxBBheITEECBUhMRhCNz8HHg0ENhkLAhE0MRhWFiY6CTNBZG1bX0EMN1BENhUSLEUmaXQ=", "pSTjl");
    lIllllIllIIlII[lIllllIllIIlll[11]] = lllllllIIlIllIl("6YpWLYAjTvqu857xR/qk1f6B7nxh8xAWAlS0P1fCqxA=", "JhIiF");
    lIllllIllIIlII[lIllllIllIIlll[6]] = lllllllIIlIlllI("IBRXNDw4ARAzLCIWVyUgPV8fd3l3FhwzGigVQ29hBEtZZw==", "MqyGH");
    lIllllIllIIllI = null;
  }
  
  private static void lllllllIIllIIII() {
    String str = (new Exception()).getStackTrace()[lIllllIllIIlll[0]].getFileName();
    lIllllIllIIllI = str.substring(str.indexOf("ä") + lIllllIllIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIIlIllIl(String lllllllllllllllIlllIIlIIIlIllIlI, String lllllllllllllllIlllIIlIIIlIllIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIIlIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIIlIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIIIlIlllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIIIlIlllII.init(lIllllIllIIlll[2], lllllllllllllllIlllIIlIIIlIlllIl);
      return new String(lllllllllllllllIlllIIlIIIlIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIlIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIIlIllIll) {
      lllllllllllllllIlllIIlIIIlIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIIlIllII(String lllllllllllllllIlllIIlIIIlIlIlIl, String lllllllllllllllIlllIIlIIIlIlIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIIlIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIIlIlIlII.getBytes(StandardCharsets.UTF_8)), lIllllIllIIlll[9]), "DES");
      Cipher lllllllllllllllIlllIIlIIIlIlIlll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIIIlIlIlll.init(lIllllIllIIlll[2], lllllllllllllllIlllIIlIIIlIllIII);
      return new String(lllllllllllllllIlllIIlIIIlIlIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIlIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIIlIlIllI) {
      lllllllllllllllIlllIIlIIIlIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIIlIlllI(String lllllllllllllllIlllIIlIIIlIlIIlI, String lllllllllllllllIlllIIlIIIlIlIIIl) {
    lllllllllllllllIlllIIlIIIlIlIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIlIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIIIlIlIIII = new StringBuilder();
    char[] lllllllllllllllIlllIIlIIIlIIllll = lllllllllllllllIlllIIlIIIlIlIIIl.toCharArray();
    int lllllllllllllllIlllIIlIIIlIIlllI = lIllllIllIIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIIIlIlIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIllIIlll[0];
    while (lllllllIIlllllI(j, i)) {
      char lllllllllllllllIlllIIlIIIlIlIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIIIlIIlllI++;
      j++;
      "".length();
      if (-"  ".length() > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIIIlIlIIII);
  }
  
  private static void lllllllIIlllIll() {
    lIllllIllIIlll = new int[16];
    lIllllIllIIlll[0] = ((0x3C ^ 0x1F) << " ".length() << " ".length() ^ 89 + 98 - 42 + 6) << " ".length() & ((72 + 19 - 82 + 118 ^ (0x6F ^ 0x76) << " ".length() << " ".length()) << " ".length() ^ -" ".length());
    lIllllIllIIlll[1] = " ".length();
    lIllllIllIIlll[2] = " ".length() << " ".length();
    lIllllIllIIlll[3] = "   ".length();
    lIllllIllIIlll[4] = " ".length() << " ".length() << " ".length();
    lIllllIllIIlll[5] = 0x47 ^ 0x42;
    lIllllIllIIlll[6] = 0x9F ^ 0x94;
    lIllllIllIIlll[7] = 0x5F ^ 0x26 ^ (0xC0 ^ 0xC7) << " ".length() << " ".length() << " ".length();
    lIllllIllIIlll[8] = "   ".length() << " ".length();
    lIllllIllIIlll[9] = " ".length() << "   ".length();
    lIllllIllIIlll[10] = 0xFD ^ 0x86 ^ (0x22 ^ 0x3D) << " ".length() << " ".length();
    lIllllIllIIlll[11] = (0x3D ^ 0x38) << " ".length();
    lIllllIllIIlll[12] = "   ".length() << " ".length() << " ".length();
    lIllllIllIIlll[13] = 0xC9 ^ 0xC4;
    lIllllIllIIlll[14] = (0x4A ^ 0x4D) << " ".length();
    lIllllIllIIlll[15] = 0x3 ^ 0xC;
  }
  
  private static boolean lllllllIIllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIIllllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f01.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */