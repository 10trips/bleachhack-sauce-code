package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public class f1000000000000000000000000000 extends au {
  private static String[] lIllllIIIlIlll;
  
  private static Class[] lIllllIIIllIII;
  
  private static final String[] lIllllIIlIIIII;
  
  private static String[] lIllllIIlIIIIl;
  
  private static final int[] lIllllIIlIIIlI;
  
  public f1000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIllIIllIlIII	Lme/stupitdog/bhp/f1000000000000000000000000000;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   15: <illegal opcode> 4 : (Lnet/minecraft/client/settings/KeyBinding;)I
    //   20: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   23: iconst_0
    //   24: iaload
    //   25: <illegal opcode> 5 : (IZ)V
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIlllIIllIIllIIlll	Lme/stupitdog/bhp/f1000000000000000000000000000;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   15: <illegal opcode> 4 : (Lnet/minecraft/client/settings/KeyBinding;)I
    //   20: getstatic me/stupitdog/bhp/f1000000000000000000000000000.lIllllIIlIIIlI : [I
    //   23: iconst_1
    //   24: iaload
    //   25: <illegal opcode> 5 : (IZ)V
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIlllIIllIIllIIllI	Lme/stupitdog/bhp/f1000000000000000000000000000;
  }
  
  static {
    llllllIlIIIllIl();
    llllllIlIIIllII();
    llllllIlIIIlIll();
    llllllIlIIIIlll();
  }
  
  private static CallSite llllllIIllllIIl(MethodHandles.Lookup lllllllllllllllIlllIIllIIlIlllIl, String lllllllllllllllIlllIIllIIlIlllII, MethodType lllllllllllllllIlllIIllIIlIllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIllIIllIIIll = lIllllIIIlIlll[Integer.parseInt(lllllllllllllllIlllIIllIIlIlllII)].split(lIllllIIlIIIII[lIllllIIlIIIlI[3]]);
      Class<?> lllllllllllllllIlllIIllIIllIIIlI = Class.forName(lllllllllllllllIlllIIllIIllIIIll[lIllllIIlIIIlI[0]]);
      String lllllllllllllllIlllIIllIIllIIIIl = lllllllllllllllIlllIIllIIllIIIll[lIllllIIlIIIlI[1]];
      MethodHandle lllllllllllllllIlllIIllIIllIIIII = null;
      int lllllllllllllllIlllIIllIIlIlllll = lllllllllllllllIlllIIllIIllIIIll[lIllllIIlIIIlI[3]].length();
      if (llllllIlIIIlllI(lllllllllllllllIlllIIllIIlIlllll, lIllllIIlIIIlI[2])) {
        MethodType lllllllllllllllIlllIIllIIllIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIllIIllIIIll[lIllllIIlIIIlI[2]], f1000000000000000000000000000.class.getClassLoader());
        if (llllllIlIIIllll(lllllllllllllllIlllIIllIIlIlllll, lIllllIIlIIIlI[2])) {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findVirtual(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlIl);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findStatic(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlIl);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIllIIllIIlII = lIllllIIIllIII[Integer.parseInt(lllllllllllllllIlllIIllIIllIIIll[lIllllIIlIIIlI[2]])];
        if (llllllIlIIIllll(lllllllllllllllIlllIIllIIlIlllll, lIllllIIlIIIlI[3])) {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findGetter(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (llllllIlIIIllll(lllllllllllllllIlllIIllIIlIlllll, lIllllIIlIIIlI[4])) {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findStaticGetter(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlII);
          "".length();
          if ("   ".length() <= -" ".length())
            return null; 
        } else if (llllllIlIIIllll(lllllllllllllllIlllIIllIIlIlllll, lIllllIIlIIIlI[5])) {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findSetter(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlII);
          "".length();
          if (((0x2C ^ 0x3F) << " ".length() & ((0x48 ^ 0x5B) << " ".length() ^ 0xFFFFFFFF)) > 0)
            return null; 
        } else {
          lllllllllllllllIlllIIllIIllIIIII = lllllllllllllllIlllIIllIIlIlllIl.findStaticSetter(lllllllllllllllIlllIIllIIllIIIlI, lllllllllllllllIlllIIllIIllIIIIl, lllllllllllllllIlllIIllIIllIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIllIIllIIIII);
    } catch (Exception lllllllllllllllIlllIIllIIlIllllI) {
      lllllllllllllllIlllIIllIIlIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIlIIIIlll() {
    lIllllIIIlIlll = new String[lIllllIIlIIIlI[6]];
    lIllllIIIlIlll[lIllllIIlIIIlI[2]] = lIllllIIlIIIII[lIllllIIlIIIlI[4]];
    lIllllIIIlIlll[lIllllIIlIIIlI[1]] = lIllllIIlIIIII[lIllllIIlIIIlI[5]];
    lIllllIIIlIlll[lIllllIIlIIIlI[4]] = lIllllIIlIIIII[lIllllIIlIIIlI[6]];
    lIllllIIIlIlll[lIllllIIlIIIlI[5]] = lIllllIIlIIIII[lIllllIIlIIIlI[7]];
    lIllllIIIlIlll[lIllllIIlIIIlI[3]] = lIllllIIlIIIII[lIllllIIlIIIlI[8]];
    lIllllIIIlIlll[lIllllIIlIIIlI[0]] = lIllllIIlIIIII[lIllllIIlIIIlI[9]];
    lIllllIIIllIII = new Class[lIllllIIlIIIlI[4]];
    lIllllIIIllIII[lIllllIIlIIIlI[2]] = GameSettings.class;
    lIllllIIIllIII[lIllllIIlIIIlI[1]] = Minecraft.class;
    lIllllIIIllIII[lIllllIIlIIIlI[3]] = KeyBinding.class;
    lIllllIIIllIII[lIllllIIlIIIlI[0]] = f13.class;
  }
  
  private static void llllllIlIIIlIll() {
    lIllllIIlIIIII = new String[lIllllIIlIIIlI[10]];
    lIllllIIlIIIII[lIllllIIlIIIlI[0]] = llllllIlIIIlIII(lIllllIIlIIIIl[lIllllIIlIIIlI[0]], lIllllIIlIIIIl[lIllllIIlIIIlI[1]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[1]] = llllllIlIIIlIII(lIllllIIlIIIIl[lIllllIIlIIIlI[2]], lIllllIIlIIIIl[lIllllIIlIIIlI[3]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[2]] = llllllIlIIIlIIl(lIllllIIlIIIIl[lIllllIIlIIIlI[4]], lIllllIIlIIIIl[lIllllIIlIIIlI[5]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[3]] = llllllIlIIIlIIl(lIllllIIlIIIIl[lIllllIIlIIIlI[6]], lIllllIIlIIIIl[lIllllIIlIIIlI[7]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[4]] = llllllIlIIIlIIl(lIllllIIlIIIIl[lIllllIIlIIIlI[8]], lIllllIIlIIIIl[lIllllIIlIIIlI[9]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[5]] = llllllIlIIIlIII(lIllllIIlIIIIl[lIllllIIlIIIlI[10]], lIllllIIlIIIIl[lIllllIIlIIIlI[11]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[6]] = llllllIlIIIlIIl(lIllllIIlIIIIl[lIllllIIlIIIlI[12]], lIllllIIlIIIIl[lIllllIIlIIIlI[13]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[7]] = llllllIlIIIlIIl(lIllllIIlIIIIl[lIllllIIlIIIlI[14]], lIllllIIlIIIIl[lIllllIIlIIIlI[15]]);
    lIllllIIlIIIII[lIllllIIlIIIlI[8]] = llllllIlIIIlIII("sqD4XJ9Fq3yQR6oMeuEKK5zGyP31TWgTtuJ8y9Js1lhGrEJWRVjkWLt7xwHFLp1cMXr5zPLkxUJRpeoNp+4XUw==", "rCjPx");
    lIllllIIlIIIII[lIllllIIlIIIlI[9]] = llllllIlIIIlIlI("80bBh71Opuc+GeNHjbAs/iL4ade83BEBdH8PvrCACLOXDXvWIpzG0g==", "mOdpK");
    lIllllIIlIIIIl = null;
  }
  
  private static void llllllIlIIIllII() {
    String str = (new Exception()).getStackTrace()[lIllllIIlIIIlI[0]].getFileName();
    lIllllIIlIIIIl = str.substring(str.indexOf("ä") + lIllllIIlIIIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIlIIIlIIl(String lllllllllllllllIlllIIllIIlIllIIl, String lllllllllllllllIlllIIllIIlIllIII) {
    lllllllllllllllIlllIIllIIlIllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlIllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIllIIlIlIlll = new StringBuilder();
    char[] lllllllllllllllIlllIIllIIlIlIllI = lllllllllllllllIlllIIllIIlIllIII.toCharArray();
    int lllllllllllllllIlllIIllIIlIlIlIl = lIllllIIlIIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIllIIlIllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIlIIIlI[0];
    while (llllllIlIIlIIII(j, i)) {
      char lllllllllllllllIlllIIllIIlIllIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIllIIlIlIlIl++;
      j++;
      "".length();
      if (((0xB0 ^ 0x95) & (0x21 ^ 0x4 ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIllIIlIlIlll);
  }
  
  private static String llllllIlIIIlIII(String lllllllllllllllIlllIIllIIlIlIIIl, String lllllllllllllllIlllIIllIIlIlIIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIlIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIlIlIIII.getBytes(StandardCharsets.UTF_8)), lIllllIIlIIIlI[8]), "DES");
      Cipher lllllllllllllllIlllIIllIIlIlIIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIllIIlIlIIll.init(lIllllIIlIIIlI[2], lllllllllllllllIlllIIllIIlIlIlII);
      return new String(lllllllllllllllIlllIIllIIlIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIlIlIIlI) {
      lllllllllllllllIlllIIllIIlIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlIIIlIlI(String lllllllllllllllIlllIIllIIlIIllII, String lllllllllllllllIlllIIllIIlIIlIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIlIIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIlIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIllIIlIIlllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIllIIlIIlllI.init(lIllllIIlIIIlI[2], lllllllllllllllIlllIIllIIlIIllll);
      return new String(lllllllllllllllIlllIIllIIlIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIlIIllIl) {
      lllllllllllllllIlllIIllIIlIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIlIIIllIl() {
    lIllllIIlIIIlI = new int[16];
    lIllllIIlIIIlI[0] = (0x67 ^ 0x78) << " ".length() & ((0x99 ^ 0x86) << " ".length() ^ 0xFFFFFFFF);
    lIllllIIlIIIlI[1] = " ".length();
    lIllllIIlIIIlI[2] = " ".length() << " ".length();
    lIllllIIlIIIlI[3] = "   ".length();
    lIllllIIlIIIlI[4] = " ".length() << " ".length() << " ".length();
    lIllllIIlIIIlI[5] = (0x87 ^ 0xA4) << " ".length() ^ 0x7 ^ 0x44;
    lIllllIIlIIIlI[6] = "   ".length() << " ".length();
    lIllllIIlIIIlI[7] = (0x83 ^ 0xA0) << " ".length() ^ 0xF7 ^ 0xB6;
    lIllllIIlIIIlI[8] = " ".length() << "   ".length();
    lIllllIIlIIIlI[9] = 0xBC ^ 0xA5 ^ " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIlIIIlI[10] = ((0x1E ^ 0x11) << " ".length() << " ".length() ^ 0x85 ^ 0xBC) << " ".length();
    lIllllIIlIIIlI[11] = 0x78 ^ 0x73;
    lIllllIIlIIIlI[12] = "   ".length() << " ".length() << " ".length();
    lIllllIIlIIIlI[13] = 0xA6 ^ 0xAB;
    lIllllIIlIIIlI[14] = (0x9B ^ 0x9C) << " ".length();
    lIllllIIlIIIlI[15] = 0x9 ^ 0x6;
  }
  
  private static boolean llllllIlIIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIlIIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIlIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */