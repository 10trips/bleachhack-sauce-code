package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class f0g extends au {
  private static String[] lIlllIlIllIIll;
  
  private static Class[] lIlllIlIllIlII;
  
  private static final String[] lIlllIlllIIIII;
  
  private static String[] lIlllIlllIIIIl;
  
  private static final int[] lIlllIlllIIIlI;
  
  public f0g() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIlIIIlIlIlIll	Lme/stupitdog/bhp/f0g;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   15: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   18: iconst_2
    //   19: iaload
    //   20: irem
    //   21: invokestatic lllllIlllIlIIlI : (I)Z
    //   24: ifeq -> 28
    //   27: return
    //   28: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   38: instanceof net/minecraft/client/gui/inventory/GuiContainer
    //   41: invokestatic lllllIlllIlIIll : (I)Z
    //   44: ifeq -> 67
    //   47: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   57: instanceof net/minecraft/client/renderer/InventoryEffectRenderer
    //   60: invokestatic lllllIlllIlIIlI : (I)Z
    //   63: ifeq -> 67
    //   66: return
    //   67: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   70: iconst_3
    //   71: iaload
    //   72: newarray int
    //   74: astore_1
    //   75: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   78: iconst_3
    //   79: iaload
    //   80: newarray int
    //   82: astore_2
    //   83: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   86: iconst_0
    //   87: iaload
    //   88: istore_3
    //   89: iload_3
    //   90: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   93: iconst_3
    //   94: iaload
    //   95: invokestatic lllllIlllIlIlII : (II)Z
    //   98: ifeq -> 195
    //   101: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   106: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   111: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   116: iload_3
    //   117: <illegal opcode> 6 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   122: astore #4
    //   124: aload #4
    //   126: invokestatic lllllIlllIlIlIl : (Ljava/lang/Object;)Z
    //   129: ifeq -> 166
    //   132: aload #4
    //   134: <illegal opcode> 7 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   139: instanceof net/minecraft/item/ItemArmor
    //   142: invokestatic lllllIlllIlIIll : (I)Z
    //   145: ifeq -> 166
    //   148: aload_2
    //   149: iload_3
    //   150: aload #4
    //   152: <illegal opcode> 7 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   157: checkcast net/minecraft/item/ItemArmor
    //   160: <illegal opcode> 8 : (Lnet/minecraft/item/ItemArmor;)I
    //   165: iastore
    //   166: aload_1
    //   167: iload_3
    //   168: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   171: iconst_4
    //   172: iaload
    //   173: iastore
    //   174: iinc #3, 1
    //   177: ldc ''
    //   179: invokevirtual length : ()I
    //   182: pop
    //   183: sipush #168
    //   186: sipush #172
    //   189: ixor
    //   190: ineg
    //   191: iflt -> 89
    //   194: return
    //   195: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   198: iconst_0
    //   199: iaload
    //   200: istore_3
    //   201: iload_3
    //   202: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   205: iconst_5
    //   206: iaload
    //   207: invokestatic lllllIlllIlIlII : (II)Z
    //   210: ifeq -> 479
    //   213: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   218: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   223: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   228: iload_3
    //   229: <illegal opcode> 9 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   234: astore #4
    //   236: aload #4
    //   238: <illegal opcode> 10 : (Lnet/minecraft/item/ItemStack;)I
    //   243: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   246: iconst_1
    //   247: iaload
    //   248: invokestatic lllllIlllIlIllI : (II)Z
    //   251: ifeq -> 265
    //   254: ldc ''
    //   256: invokevirtual length : ()I
    //   259: pop
    //   260: aconst_null
    //   261: ifnull -> 455
    //   264: return
    //   265: aload #4
    //   267: invokestatic lllllIlllIlIlIl : (Ljava/lang/Object;)Z
    //   270: ifeq -> 455
    //   273: aload #4
    //   275: <illegal opcode> 7 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   280: instanceof net/minecraft/item/ItemArmor
    //   283: invokestatic lllllIlllIlIIlI : (I)Z
    //   286: ifeq -> 300
    //   289: ldc ''
    //   291: invokevirtual length : ()I
    //   294: pop
    //   295: aconst_null
    //   296: ifnull -> 455
    //   299: return
    //   300: aload #4
    //   302: <illegal opcode> 7 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   307: checkcast net/minecraft/item/ItemArmor
    //   310: astore #5
    //   312: aload #5
    //   314: <illegal opcode> 11 : (Lnet/minecraft/item/ItemArmor;)Lnet/minecraft/inventory/EntityEquipmentSlot;
    //   319: <illegal opcode> 12 : (Lnet/minecraft/inventory/EntityEquipmentSlot;)I
    //   324: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   327: iconst_2
    //   328: iaload
    //   329: isub
    //   330: istore #6
    //   332: iload #6
    //   334: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   337: iconst_2
    //   338: iaload
    //   339: invokestatic lllllIlllIlIlll : (II)Z
    //   342: ifeq -> 423
    //   345: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   350: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   355: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   360: iload #6
    //   362: <illegal opcode> 6 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   367: <illegal opcode> 7 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   372: <illegal opcode> 13 : ()Lnet/minecraft/item/Item;
    //   377: <illegal opcode> 14 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   382: invokestatic lllllIlllIlIIll : (I)Z
    //   385: ifeq -> 423
    //   388: ldc ''
    //   390: invokevirtual length : ()I
    //   393: pop
    //   394: bipush #112
    //   396: bipush #59
    //   398: iadd
    //   399: bipush #82
    //   401: isub
    //   402: bipush #84
    //   404: iadd
    //   405: sipush #140
    //   408: sipush #153
    //   411: ixor
    //   412: ldc '   '
    //   414: invokevirtual length : ()I
    //   417: ishl
    //   418: ixor
    //   419: ifgt -> 455
    //   422: return
    //   423: aload #5
    //   425: <illegal opcode> 8 : (Lnet/minecraft/item/ItemArmor;)I
    //   430: istore #7
    //   432: iload #7
    //   434: aload_2
    //   435: iload #6
    //   437: iaload
    //   438: invokestatic lllllIlllIlIllI : (II)Z
    //   441: ifeq -> 455
    //   444: aload_1
    //   445: iload #6
    //   447: iload_3
    //   448: iastore
    //   449: aload_2
    //   450: iload #6
    //   452: iload #7
    //   454: iastore
    //   455: iinc #3, 1
    //   458: ldc ''
    //   460: invokevirtual length : ()I
    //   463: pop
    //   464: ldc ' '
    //   466: invokevirtual length : ()I
    //   469: ineg
    //   470: ldc '   '
    //   472: invokevirtual length : ()I
    //   475: if_icmple -> 201
    //   478: return
    //   479: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   482: iconst_0
    //   483: iaload
    //   484: istore_3
    //   485: iload_3
    //   486: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   489: iconst_3
    //   490: iaload
    //   491: invokestatic lllllIlllIlIlII : (II)Z
    //   494: ifeq -> 969
    //   497: aload_1
    //   498: iload_3
    //   499: iaload
    //   500: istore #4
    //   502: iload #4
    //   504: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   507: iconst_4
    //   508: iaload
    //   509: invokestatic lllllIlllIlIlll : (II)Z
    //   512: ifeq -> 664
    //   515: ldc ''
    //   517: invokevirtual length : ()I
    //   520: pop
    //   521: bipush #72
    //   523: sipush #141
    //   526: iadd
    //   527: bipush #53
    //   529: isub
    //   530: bipush #87
    //   532: iadd
    //   533: bipush #70
    //   535: bipush #39
    //   537: ixor
    //   538: ldc ' '
    //   540: invokevirtual length : ()I
    //   543: ishl
    //   544: ixor
    //   545: bipush #24
    //   547: iconst_3
    //   548: ixor
    //   549: bipush #53
    //   551: bipush #34
    //   553: ixor
    //   554: ldc ' '
    //   556: invokevirtual length : ()I
    //   559: ishl
    //   560: ixor
    //   561: ldc ' '
    //   563: invokevirtual length : ()I
    //   566: ineg
    //   567: ixor
    //   568: iand
    //   569: sipush #162
    //   572: bipush #69
    //   574: iadd
    //   575: bipush #58
    //   577: isub
    //   578: bipush #16
    //   580: iadd
    //   581: bipush #62
    //   583: bipush #21
    //   585: ixor
    //   586: ldc ' '
    //   588: invokevirtual length : ()I
    //   591: ldc ' '
    //   593: invokevirtual length : ()I
    //   596: ishl
    //   597: ishl
    //   598: ixor
    //   599: ldc ' '
    //   601: invokevirtual length : ()I
    //   604: ldc ' '
    //   606: invokevirtual length : ()I
    //   609: ishl
    //   610: ishl
    //   611: bipush #110
    //   613: sipush #139
    //   616: iadd
    //   617: bipush #70
    //   619: isub
    //   620: iconst_2
    //   621: iadd
    //   622: bipush #66
    //   624: bipush #107
    //   626: ixor
    //   627: ldc ' '
    //   629: invokevirtual length : ()I
    //   632: ldc ' '
    //   634: invokevirtual length : ()I
    //   637: ishl
    //   638: ishl
    //   639: ixor
    //   640: ldc ' '
    //   642: invokevirtual length : ()I
    //   645: ldc ' '
    //   647: invokevirtual length : ()I
    //   650: ishl
    //   651: ishl
    //   652: ldc ' '
    //   654: invokevirtual length : ()I
    //   657: ineg
    //   658: ixor
    //   659: iand
    //   660: if_icmpeq -> 945
    //   663: return
    //   664: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   669: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   674: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   679: iload_3
    //   680: <illegal opcode> 6 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   685: astore #5
    //   687: aload #5
    //   689: invokestatic lllllIlllIlIlIl : (Ljava/lang/Object;)Z
    //   692: ifeq -> 739
    //   695: aload #5
    //   697: <illegal opcode> 15 : ()Lnet/minecraft/item/ItemStack;
    //   702: invokestatic lllllIlllIllIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   705: ifeq -> 739
    //   708: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   713: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   718: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   723: <illegal opcode> 16 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   728: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   731: iconst_4
    //   732: iaload
    //   733: invokestatic lllllIlllIllIIl : (II)Z
    //   736: ifeq -> 945
    //   739: iload #4
    //   741: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   744: bipush #6
    //   746: iaload
    //   747: invokestatic lllllIlllIlIlII : (II)Z
    //   750: ifeq -> 756
    //   753: iinc #4, 36
    //   756: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   761: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   766: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   769: iconst_0
    //   770: iaload
    //   771: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   774: bipush #7
    //   776: iaload
    //   777: iload_3
    //   778: isub
    //   779: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   782: iconst_0
    //   783: iaload
    //   784: <illegal opcode> 18 : ()Lnet/minecraft/inventory/ClickType;
    //   789: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   794: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   799: <illegal opcode> 19 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   804: ldc ''
    //   806: invokevirtual length : ()I
    //   809: pop2
    //   810: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   815: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   820: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   823: iconst_0
    //   824: iaload
    //   825: iload #4
    //   827: getstatic me/stupitdog/bhp/f0g.lIlllIlllIIIlI : [I
    //   830: iconst_0
    //   831: iaload
    //   832: <illegal opcode> 18 : ()Lnet/minecraft/inventory/ClickType;
    //   837: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   842: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   847: <illegal opcode> 19 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   852: ldc ''
    //   854: invokevirtual length : ()I
    //   857: pop2
    //   858: ldc ''
    //   860: invokevirtual length : ()I
    //   863: pop
    //   864: ldc ' '
    //   866: invokevirtual length : ()I
    //   869: bipush #121
    //   871: bipush #14
    //   873: iadd
    //   874: sipush #132
    //   877: isub
    //   878: sipush #172
    //   881: iadd
    //   882: sipush #152
    //   885: sipush #177
    //   888: ixor
    //   889: ldc ' '
    //   891: invokevirtual length : ()I
    //   894: ldc ' '
    //   896: invokevirtual length : ()I
    //   899: ishl
    //   900: ishl
    //   901: ixor
    //   902: ldc '   '
    //   904: invokevirtual length : ()I
    //   907: ishl
    //   908: sipush #186
    //   911: sipush #141
    //   914: ixor
    //   915: ldc ' '
    //   917: invokevirtual length : ()I
    //   920: ishl
    //   921: bipush #108
    //   923: bipush #9
    //   925: ixor
    //   926: ixor
    //   927: ldc '   '
    //   929: invokevirtual length : ()I
    //   932: ishl
    //   933: ldc ' '
    //   935: invokevirtual length : ()I
    //   938: ineg
    //   939: ixor
    //   940: iand
    //   941: if_icmpne -> 969
    //   944: return
    //   945: iinc #3, 1
    //   948: ldc ''
    //   950: invokevirtual length : ()I
    //   953: pop
    //   954: ldc ' '
    //   956: invokevirtual length : ()I
    //   959: ldc ' '
    //   961: invokevirtual length : ()I
    //   964: ineg
    //   965: if_icmpgt -> 485
    //   968: return
    //   969: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   124	50	4	lllllllllllllllIlllIlIIIlIlIlIlI	Lnet/minecraft/item/ItemStack;
    //   89	106	3	lllllllllllllllIlllIlIIIlIlIlIIl	I
    //   236	219	4	lllllllllllllllIlllIlIIIlIlIlIII	Lnet/minecraft/item/ItemStack;
    //   312	143	5	lllllllllllllllIlllIlIIIlIlIIlll	Lnet/minecraft/item/ItemArmor;
    //   332	123	6	lllllllllllllllIlllIlIIIlIlIIllI	I
    //   432	23	7	lllllllllllllllIlllIlIIIlIlIIlIl	I
    //   201	278	3	lllllllllllllllIlllIlIIIlIlIIlII	I
    //   502	443	4	lllllllllllllllIlllIlIIIlIlIIIll	I
    //   687	258	5	lllllllllllllllIlllIlIIIlIlIIIlI	Lnet/minecraft/item/ItemStack;
    //   485	484	3	lllllllllllllllIlllIlIIIlIlIIIIl	I
    //   0	970	0	lllllllllllllllIlllIlIIIlIlIIIII	Lme/stupitdog/bhp/f0g;
    //   75	895	1	lllllllllllllllIlllIlIIIlIIlllll	[I
    //   83	887	2	lllllllllllllllIlllIlIIIlIIllllI	[I
  }
  
  static {
    lllllIlllIlIIIl();
    lllllIlllIlIIII();
    lllllIlllIIllll();
    lllllIlllIIlIll();
  }
  
  private static CallSite lllllIlIlIIlIIl(MethodHandles.Lookup lllllllllllllllIlllIlIIIlIIlIlIl, String lllllllllllllllIlllIlIIIlIIlIlII, MethodType lllllllllllllllIlllIlIIIlIIlIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIIIlIIllIll = lIlllIlIllIIll[Integer.parseInt(lllllllllllllllIlllIlIIIlIIlIlII)].split(lIlllIlllIIIII[lIlllIlllIIIlI[8]]);
      Class<?> lllllllllllllllIlllIlIIIlIIllIlI = Class.forName(lllllllllllllllIlllIlIIIlIIllIll[lIlllIlllIIIlI[0]]);
      String lllllllllllllllIlllIlIIIlIIllIIl = lllllllllllllllIlllIlIIIlIIllIll[lIlllIlllIIIlI[1]];
      MethodHandle lllllllllllllllIlllIlIIIlIIllIII = null;
      int lllllllllllllllIlllIlIIIlIIlIlll = lllllllllllllllIlllIlIIIlIIllIll[lIlllIlllIIIlI[8]].length();
      if (lllllIlllIllIlI(lllllllllllllllIlllIlIIIlIIlIlll, lIlllIlllIIIlI[2])) {
        MethodType lllllllllllllllIlllIlIIIlIIlllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIIIlIIllIll[lIlllIlllIIIlI[2]], f0g.class.getClassLoader());
        if (lllllIlllIlIlll(lllllllllllllllIlllIlIIIlIIlIlll, lIlllIlllIIIlI[2])) {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findVirtual(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllIl);
          "".length();
          if (((0x89 ^ 0xB8 ^ (0x4F ^ 0x54) << " ".length() << " ".length()) & ((0x69 ^ 0x6C) << " ".length() << " ".length() << " ".length() ^ 0x96 ^ 0x9B ^ -" ".length())) > 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findStatic(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllIl);
        } 
        "".length();
        if (-" ".length() > " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIIIlIIlllII = lIlllIlIllIlII[Integer.parseInt(lllllllllllllllIlllIlIIIlIIllIll[lIlllIlllIIIlI[2]])];
        if (lllllIlllIlIlll(lllllllllllllllIlllIlIIIlIIlIlll, lIlllIlllIIIlI[8])) {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findGetter(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllII);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIlllIlIlll(lllllllllllllllIlllIlIIIlIIlIlll, lIlllIlllIIIlI[3])) {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findStaticGetter(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < "   ".length())
            return null; 
        } else if (lllllIlllIlIlll(lllllllllllllllIlllIlIIIlIIlIlll, lIlllIlllIIIlI[9])) {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findSetter(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIlIIIlIIllIII = lllllllllllllllIlllIlIIIlIIlIlIl.findStaticSetter(lllllllllllllllIlllIlIIIlIIllIlI, lllllllllllllllIlllIlIIIlIIllIIl, lllllllllllllllIlllIlIIIlIIlllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIIIlIIllIII);
    } catch (Exception lllllllllllllllIlllIlIIIlIIlIllI) {
      lllllllllllllllIlllIlIIIlIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlllIIlIll() {
    lIlllIlIllIIll = new String[lIlllIlllIIIlI[10]];
    lIlllIlIllIIll[lIlllIlllIIIlI[11]] = lIlllIlllIIIII[lIlllIlllIIIlI[3]];
    lIlllIlIllIIll[lIlllIlllIIIlI[2]] = lIlllIlllIIIII[lIlllIlllIIIlI[9]];
    lIlllIlIllIIll[lIlllIlllIIIlI[12]] = lIlllIlllIIIII[lIlllIlllIIIlI[13]];
    lIlllIlIllIIll[lIlllIlllIIIlI[0]] = lIlllIlllIIIII[lIlllIlllIIIlI[14]];
    lIlllIlIllIIll[lIlllIlllIIIlI[1]] = lIlllIlllIIIII[lIlllIlllIIIlI[7]];
    lIlllIlIllIIll[lIlllIlllIIIlI[15]] = lIlllIlllIIIII[lIlllIlllIIIlI[6]];
    lIlllIlIllIIll[lIlllIlllIIIlI[6]] = lIlllIlllIIIII[lIlllIlllIIIlI[16]];
    lIlllIlIllIIll[lIlllIlllIIIlI[8]] = lIlllIlllIIIII[lIlllIlllIIIlI[17]];
    lIlllIlIllIIll[lIlllIlllIIIlI[18]] = lIlllIlllIIIII[lIlllIlllIIIlI[18]];
    lIlllIlIllIIll[lIlllIlllIIIlI[9]] = lIlllIlllIIIII[lIlllIlllIIIlI[19]];
    lIlllIlIllIIll[lIlllIlllIIIlI[13]] = lIlllIlllIIIII[lIlllIlllIIIlI[12]];
    lIlllIlIllIIll[lIlllIlllIIIlI[19]] = lIlllIlllIIIII[lIlllIlllIIIlI[11]];
    lIlllIlIllIIll[lIlllIlllIIIlI[20]] = lIlllIlllIIIII[lIlllIlllIIIlI[21]];
    lIlllIlIllIIll[lIlllIlllIIIlI[3]] = lIlllIlllIIIII[lIlllIlllIIIlI[22]];
    lIlllIlIllIIll[lIlllIlllIIIlI[14]] = lIlllIlllIIIII[lIlllIlllIIIlI[15]];
    lIlllIlIllIIll[lIlllIlllIIIlI[17]] = lIlllIlllIIIII[lIlllIlllIIIlI[20]];
    lIlllIlIllIIll[lIlllIlllIIIlI[16]] = lIlllIlllIIIII[lIlllIlllIIIlI[10]];
    lIlllIlIllIIll[lIlllIlllIIIlI[21]] = lIlllIlllIIIII[lIlllIlllIIIlI[23]];
    lIlllIlIllIIll[lIlllIlllIIIlI[22]] = lIlllIlllIIIII[lIlllIlllIIIlI[24]];
    lIlllIlIllIIll[lIlllIlllIIIlI[7]] = lIlllIlllIIIII[lIlllIlllIIIlI[25]];
    lIlllIlIllIlII = new Class[lIlllIlllIIIlI[17]];
    lIlllIlIllIlII[lIlllIlllIIIlI[9]] = InventoryPlayer.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[1]] = Minecraft.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[13]] = EntityEquipmentSlot.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[3]] = GuiScreen.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[6]] = PlayerControllerMP.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[14]] = Item.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[7]] = ItemStack.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[0]] = f13.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[16]] = ClickType.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[8]] = int.class;
    lIlllIlIllIlII[lIlllIlllIIIlI[2]] = EntityPlayerSP.class;
  }
  
  private static void lllllIlllIIllll() {
    lIlllIlllIIIII = new String[lIlllIlllIIIlI[26]];
    lIlllIlllIIIII[lIlllIlllIIIlI[0]] = lllllIlllIIllII(lIlllIlllIIIIl[lIlllIlllIIIlI[0]], lIlllIlllIIIIl[lIlllIlllIIIlI[1]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[1]] = lllllIlllIIllIl(lIlllIlllIIIIl[lIlllIlllIIIlI[2]], lIlllIlllIIIIl[lIlllIlllIIIlI[8]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[2]] = lllllIlllIIllII(lIlllIlllIIIIl[lIlllIlllIIIlI[3]], lIlllIlllIIIIl[lIlllIlllIIIlI[9]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[8]] = lllllIlllIIlllI(lIlllIlllIIIIl[lIlllIlllIIIlI[13]], lIlllIlllIIIIl[lIlllIlllIIIlI[14]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[3]] = lllllIlllIIllII(lIlllIlllIIIIl[lIlllIlllIIIlI[7]], lIlllIlllIIIIl[lIlllIlllIIIlI[6]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[9]] = lllllIlllIIlllI(lIlllIlllIIIIl[lIlllIlllIIIlI[16]], lIlllIlllIIIIl[lIlllIlllIIIlI[17]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[13]] = lllllIlllIIllIl(lIlllIlllIIIIl[lIlllIlllIIIlI[18]], lIlllIlllIIIIl[lIlllIlllIIIlI[19]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[14]] = lllllIlllIIllII(lIlllIlllIIIIl[lIlllIlllIIIlI[12]], lIlllIlllIIIIl[lIlllIlllIIIlI[11]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[7]] = lllllIlllIIllII(lIlllIlllIIIIl[lIlllIlllIIIlI[21]], lIlllIlllIIIIl[lIlllIlllIIIlI[22]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[6]] = lllllIlllIIlllI(lIlllIlllIIIIl[lIlllIlllIIIlI[15]], lIlllIlllIIIIl[lIlllIlllIIIlI[20]]);
    lIlllIlllIIIII[lIlllIlllIIIlI[16]] = lllllIlllIIllII("NxMGWA4wGBcVETgQBlgGNwIbAhp3Bh4XGjwEXD8NLxMcAgwrDyIaAiATAEwFLBgRKVRpRUJHPDhMWj9KFRgXAkw0HxwTACsXFAJMMAIXG0wQAhcbMC0XER1YY1ZS", "Yvrvc");
    lIlllIlllIIIII[lIlllIlllIIIlI[17]] = lllllIlllIIllII("IzIbRAckOQoJGCwxG0QJIT4KBB5jMgEeAzkuQS8EOT4bEzohNhYPGB4HVQwDKDsLNV19ZlhZNSw2VVlQbXdP", "MWojj");
    lIlllIlllIIIII[lIlllIlllIIIlI[18]] = lllllIlllIIlllI("SUXWMEUTP6DZ7b8ciQeyuGWisWaYkHotu8XeAxcynboYoyoILYKs3rjocVa8BZXhPNzw++CfO2cxU/Ic5/34IA==", "XMfJt");
    lIlllIlllIIIII[lIlllIlllIIIlI[19]] = lllllIlllIIllIl("rPlN2YJA2PKnPSLVALb9CJUYw73R02tSxMQ0UjhsWkckqppR7zM5e7QbRV4Qcf7Fas5+q39gBNnuuzJZeoqyIQ==", "xcMGp");
    lIlllIlllIIIII[lIlllIlllIIIlI[12]] = lllllIlllIIllIl("IvgXgq7knceFSO8C86nXsEoKPT+iOQIDMnMUVDURNAysFWMWhi+6m0t8TjI2F0rFVld2hncOaz2/m8lLyRUJ0qIr9ybm1nbrEDI0hsBsrym1rYE/rBP723ybkCh0A7BT", "PCyBU");
    lIlllIlllIIIII[lIlllIlllIIIlI[11]] = lllllIlllIIllII("JSwtRRciJzwICCovLUUTJSAtRTM/LDQYQC0gPAceFHhhXkt9eQYIKHF+Y0taa2k=", "KIYkz");
    lIlllIlllIIIII[lIlllIlllIIIlI[21]] = lllllIlllIIlllI("h8rAuvARNFsE3No7a6qb3BmW8SEhMVa6PWYSazLP5b0hFiIKzbO7j2aRKRXcY2eJXwA7vZCMhVaSWVto5Yk4c+kZehxPIbSuS8hi2jiDYyBGPxjUzMv8wzBBPO7ezjxo2xrCidttvH+ERwl993X54fb4S6JoBtGC66VU4zE8yiDSMCrdvC00wuv946b9JE7JdFBkjD2Bkviqlh4syy+wdshUv8eXkiMS9nEAVHeZCTd0WA47+49OIw==", "XSClb");
    lIlllIlllIIIII[lIlllIlllIIIlI[22]] = lllllIlllIIllII("PgQcQB45Dw0NATEHHEAQPAgNAAd+LAEAFjMTCQgHagcBCx80Pl9fR2ZTNxxJZFtITlM=", "Pahns");
    lIlllIlllIIIII[lIlllIlllIIIlI[15]] = lllllIlllIIlllI("mcM1RqCd/vMTL1NaBORAS62/UcDQb6DSkGFklWs5t6uTEpDpJPWNT/roJwsNuFjbrAeZZkbk2RehhlkK3oq7tArTS9/lHNWxTLXdvml5C/c=", "ALfts");
    lIlllIlllIIIII[lIlllIlllIIIlI[20]] = lllllIlllIIllIl("JIcS6dbw8hqv0fjzkX6lPcxwtyNjwfySBGCwtRkio4v9z/hzWsoUOlYwQacWmSi87BzQV2Nrarc=", "HbkyJ");
    lIlllIlllIIIII[lIlllIlllIIIlI[10]] = lllllIlllIIlllI("ey6LVEkuyRVIJbYqmVPqu36GFiWPM+wsDHHulSz86++83waB5ZbcqbBYtCt++q/fbLg4wKYSNeg=", "jqlyH");
    lIlllIlllIIIII[lIlllIlllIIIlI[23]] = lllllIlllIIllIl("d/CzXIwvzLpIFnfYxtY9+rkYswqkI9YzVLclD9OV1mYKtZGr1sOMzlBDF7525XT9F37Cz0KUW9ZFQsgj7adm1g==", "LVRKY");
    lIlllIlllIIIII[lIlllIlllIIIlI[24]] = lllllIlllIIllII("JC4NZQEjJRwoHistDWUPJiIcJRhkBhAlCSk5GC0YcC0QLgAuFE56WH55JilWc3FZa0w=", "JKyKl");
    lIlllIlllIIIII[lIlllIlllIIIlI[25]] = lllllIlllIIllII("HyIddCAYKQw5PxAhHXQkBSIEdAQFIgQbPxwoG2ArGCIFPhJGcFFtdC4lU2l3UWdJ", "qGiZM");
    lIlllIlllIIIIl = null;
  }
  
  private static void lllllIlllIlIIII() {
    String str = (new Exception()).getStackTrace()[lIlllIlllIIIlI[0]].getFileName();
    lIlllIlllIIIIl = str.substring(str.indexOf("ä") + lIlllIlllIIIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIlllIIllII(String lllllllllllllllIlllIlIIIlIIlIIIl, String lllllllllllllllIlllIlIIIlIIlIIII) {
    lllllllllllllllIlllIlIIIlIIlIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIIIlIIIllll = new StringBuilder();
    char[] lllllllllllllllIlllIlIIIlIIIlllI = lllllllllllllllIlllIlIIIlIIlIIII.toCharArray();
    int lllllllllllllllIlllIlIIIlIIIllIl = lIlllIlllIIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIIIlIIlIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlllIIIlI[0];
    while (lllllIlllIlIlII(j, i)) {
      char lllllllllllllllIlllIlIIIlIIlIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIIIlIIIllIl++;
      j++;
      "".length();
      if ("   ".length() >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIIIlIIIllll);
  }
  
  private static String lllllIlllIIllIl(String lllllllllllllllIlllIlIIIlIIIlIIl, String lllllllllllllllIlllIlIIIlIIIlIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIlIIIllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIlIIIlIII.getBytes(StandardCharsets.UTF_8)), lIlllIlllIIIlI[7]), "DES");
      Cipher lllllllllllllllIlllIlIIIlIIIlIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIIIlIIIlIll.init(lIlllIlllIIIlI[2], lllllllllllllllIlllIlIIIlIIIllII);
      return new String(lllllllllllllllIlllIlIIIlIIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIlIIIlIlI) {
      lllllllllllllllIlllIlIIIlIIIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlllIIlllI(String lllllllllllllllIlllIlIIIlIIIIlII, String lllllllllllllllIlllIlIIIlIIIIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIlIIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIlIIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIIIlIIIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIIIlIIIIllI.init(lIlllIlllIIIlI[2], lllllllllllllllIlllIlIIIlIIIIlll);
      return new String(lllllllllllllllIlllIlIIIlIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIlIIIIlIl) {
      lllllllllllllllIlllIlIIIlIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlllIlIIIl() {
    lIlllIlllIIIlI = new int[27];
    lIlllIlllIIIlI[0] = (0xAB ^ 0xB8) << " ".length() << " ".length() & ((0x4A ^ 0x59) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIlllIlllIIIlI[1] = " ".length();
    lIlllIlllIIIlI[2] = " ".length() << " ".length();
    lIlllIlllIIIlI[3] = " ".length() << " ".length() << " ".length();
    lIlllIlllIIIlI[4] = -" ".length();
    lIlllIlllIIIlI[5] = (0x65 ^ 0x54 ^ (0x1D ^ 0x1A) << "   ".length()) << " ".length() << " ".length();
    lIlllIlllIIIlI[6] = 0x6C ^ 0x59 ^ (0x8E ^ 0x81) << " ".length() << " ".length();
    lIlllIlllIIIlI[7] = " ".length() << "   ".length();
    lIlllIlllIIIlI[8] = "   ".length();
    lIlllIlllIIIlI[9] = 78 + 121 - 170 + 120 ^ (0x8B ^ 0x82) << " ".length() << " ".length() << " ".length();
    lIlllIlllIIIlI[10] = (0x45 ^ 0x40) << " ".length() << " ".length();
    lIlllIlllIIIlI[11] = 0x71 ^ 0x7E;
    lIlllIlllIIIlI[12] = (0x8A ^ 0x8D) << " ".length();
    lIlllIlllIIIlI[13] = "   ".length() << " ".length();
    lIlllIlllIIIlI[14] = 0x2D ^ 0x76 ^ (0xBE ^ 0xA9) << " ".length() << " ".length();
    lIlllIlllIIIlI[15] = (0xCF ^ 0xC6) << " ".length();
    lIlllIlllIIIlI[16] = (0x97 ^ 0xB6 ^ (0x5F ^ 0x56) << " ".length() << " ".length()) << " ".length();
    lIlllIlllIIIlI[17] = (0x45 ^ 0x0) << " ".length() ^ 74 + 123 - 188 + 120;
    lIlllIlllIIIlI[18] = "   ".length() << " ".length() << " ".length();
    lIlllIlllIIIlI[19] = (0x5B ^ 0x4) << " ".length() ^ 164 + 13 - 38 + 40;
    lIlllIlllIIIlI[20] = (0x7E ^ 0x23) << " ".length() ^ 104 + 162 - 131 + 34;
    lIlllIlllIIIlI[21] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlllIIIlI[22] = 0x39 ^ 0x28;
    lIlllIlllIIIlI[23] = 0x3B ^ 0x7C ^ (0xEE ^ 0xC7) << " ".length();
    lIlllIlllIIIlI[24] = ((0x62 ^ 0x65) << " ".length() ^ 0x15 ^ 0x10) << " ".length();
    lIlllIlllIIIlI[25] = 0x8D ^ 0x9A;
    lIlllIlllIIIlI[26] = "   ".length() << "   ".length();
  }
  
  private static boolean lllllIlllIlIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIlllIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIlllIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIlllIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lllllIlllIlIlIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lllllIlllIllIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lllllIlllIlIIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIlllIlIIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIlllIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */