package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.math.BlockPos;

public class f0a extends au {
  f100000000000000000000.Integer maxHeight;
  
  BlockPos playerPos;
  
  private static String[] llIIIIIlllllII;
  
  private static Class[] llIIIIIlllllIl;
  
  private static final String[] llIIIIlIllIlII;
  
  private static String[] llIIIIlIllIlIl;
  
  private static final int[] llIIIIlIllIllI;
  
  public f0a() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIlII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIlII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIllIIllIIlIllI	Lme/stupitdog/bhp/f0a;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIlII : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   14: iconst_4
    //   15: iaload
    //   16: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   19: iconst_1
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   24: iconst_5
    //   25: iaload
    //   26: <illegal opcode> 1 : (Lme/stupitdog/bhp/f0a;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   31: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0a;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   36: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	37	0	lllllllllllllllIllIllIIllIIlIlIl	Lme/stupitdog/bhp/f0a;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIlIlIlIlIll : (Ljava/lang/Object;)Z
    //   13: ifeq -> 17
    //   16: return
    //   17: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   32: dconst_0
    //   33: invokestatic lIIIIIlIlIlIlIlI : (DD)I
    //   36: invokestatic lIIIIIlIlIlIllII : (I)Z
    //   39: ifeq -> 43
    //   42: return
    //   43: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   48: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   53: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   58: <illegal opcode> 7 : (D)D
    //   63: dstore_1
    //   64: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   69: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   74: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   79: <illegal opcode> 7 : (D)D
    //   84: dstore_3
    //   85: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   90: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   95: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   100: dload_1
    //   101: dsub
    //   102: <illegal opcode> 9 : (D)D
    //   107: dstore #5
    //   109: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   114: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   119: <illegal opcode> 8 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   124: dload_3
    //   125: dsub
    //   126: <illegal opcode> 9 : (D)D
    //   131: dstore #7
    //   133: aload_0
    //   134: new net/minecraft/util/math/BlockPos
    //   137: dup
    //   138: dload_1
    //   139: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   144: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   149: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   154: dload_3
    //   155: invokespecial <init> : (DDD)V
    //   158: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0a;Lnet/minecraft/util/math/BlockPos;)V
    //   163: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   168: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   173: aload_0
    //   174: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0a;)Lnet/minecraft/util/math/BlockPos;
    //   179: <illegal opcode> 13 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   184: <illegal opcode> 14 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   189: <illegal opcode> 15 : ()Lnet/minecraft/block/Block;
    //   194: invokestatic lIIIIIlIlIlIllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   197: ifeq -> 201
    //   200: return
    //   201: aload_0
    //   202: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0a;)Lnet/minecraft/util/math/BlockPos;
    //   207: <illegal opcode> 16 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   212: astore #9
    //   214: getstatic me/stupitdog/bhp/f0a.llIIIIlIllIllI : [I
    //   217: iconst_0
    //   218: iaload
    //   219: istore #10
    //   221: iload #10
    //   223: aload_0
    //   224: <illegal opcode> 17 : (Lme/stupitdog/bhp/f0a;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   229: <illegal opcode> 18 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   234: invokestatic lIIIIIlIlIlIlllI : (II)Z
    //   237: ifeq -> 424
    //   240: aload #9
    //   242: <illegal opcode> 16 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   247: astore #9
    //   249: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   254: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   259: aload #9
    //   261: <illegal opcode> 13 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   266: <illegal opcode> 14 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   271: <illegal opcode> 15 : ()Lnet/minecraft/block/Block;
    //   276: invokestatic lIIIIIlIlIlIllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   279: ifeq -> 360
    //   282: aload #9
    //   284: <illegal opcode> 19 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   289: <illegal opcode> 20 : (Lnet/minecraft/util/math/BlockPos;)Ljava/util/HashMap;
    //   294: astore #11
    //   296: aload #11
    //   298: <illegal opcode> 21 : (Ljava/util/HashMap;)Ljava/util/Set;
    //   303: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   308: <illegal opcode> 22 : (Ljava/util/Set;Ljava/util/function/Predicate;)Z
    //   313: ldc ''
    //   315: invokevirtual length : ()I
    //   318: pop2
    //   319: aload #11
    //   321: <illegal opcode> 23 : (Ljava/util/HashMap;)I
    //   326: invokestatic lIIIIIlIlIlIllll : (I)Z
    //   329: ifeq -> 360
    //   332: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   337: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   342: dconst_0
    //   343: putfield field_70159_w : D
    //   346: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   351: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   356: dconst_0
    //   357: putfield field_70179_y : D
    //   360: iinc #10, 1
    //   363: ldc ''
    //   365: invokevirtual length : ()I
    //   368: pop
    //   369: bipush #53
    //   371: bipush #6
    //   373: ixor
    //   374: ldc ' '
    //   376: invokevirtual length : ()I
    //   379: ishl
    //   380: bipush #56
    //   382: bipush #101
    //   384: ixor
    //   385: ixor
    //   386: sipush #176
    //   389: sipush #149
    //   392: ixor
    //   393: sipush #172
    //   396: sipush #163
    //   399: ixor
    //   400: ldc ' '
    //   402: invokevirtual length : ()I
    //   405: ishl
    //   406: ixor
    //   407: ldc ' '
    //   409: invokevirtual length : ()I
    //   412: ineg
    //   413: ixor
    //   414: iand
    //   415: ldc '   '
    //   417: invokevirtual length : ()I
    //   420: if_icmplt -> 221
    //   423: return
    //   424: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   296	64	11	lllllllllllllllIllIllIIllIIlIlII	Ljava/util/HashMap;
    //   221	203	10	lllllllllllllllIllIllIIllIIlIIll	I
    //   0	425	0	lllllllllllllllIllIllIIllIIlIIlI	Lme/stupitdog/bhp/f0a;
    //   64	361	1	lllllllllllllllIllIllIIllIIlIIIl	D
    //   85	340	3	lllllllllllllllIllIllIIllIIlIIII	D
    //   109	316	5	lllllllllllllllIllIllIIllIIIllll	D
    //   133	292	7	lllllllllllllllIllIllIIllIIIlllI	D
    //   214	211	9	lllllllllllllllIllIllIIllIIIllIl	Lnet/minecraft/util/math/BlockPos;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   296	64	11	lllllllllllllllIllIllIIllIIlIlII	Ljava/util/HashMap<Lme/stupitdog/bhp/ak$BlockOffset;Lme/stupitdog/bhp/ak$BlockSafety;>;
  }
  
  static {
    lIIIIIlIlIlIlIIl();
    lIIIIIlIlIlIlIII();
    lIIIIIlIlIlIIlll();
    lIIIIIlIlIlIIIll();
  }
  
  private static CallSite lIIIIIlIIIlIIIIl(MethodHandles.Lookup lllllllllllllllIllIllIIllIIIIIll, String lllllllllllllllIllIllIIllIIIIIlI, MethodType lllllllllllllllIllIllIIllIIIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIllIIIlIIl = llIIIIIlllllII[Integer.parseInt(lllllllllllllllIllIllIIllIIIIIlI)].split(llIIIIlIllIlII[llIIIIlIllIllI[6]]);
      Class<?> lllllllllllllllIllIllIIllIIIlIII = Class.forName(lllllllllllllllIllIllIIllIIIlIIl[llIIIIlIllIllI[0]]);
      String lllllllllllllllIllIllIIllIIIIlll = lllllllllllllllIllIllIIllIIIlIIl[llIIIIlIllIllI[1]];
      MethodHandle lllllllllllllllIllIllIIllIIIIllI = null;
      int lllllllllllllllIllIllIIllIIIIlIl = lllllllllllllllIllIllIIllIIIlIIl[llIIIIlIllIllI[3]].length();
      if (lIIIIIlIlIllIIIl(lllllllllllllllIllIllIIllIIIIlIl, llIIIIlIllIllI[2])) {
        MethodType lllllllllllllllIllIllIIllIIIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIllIIIlIIl[llIIIIlIllIllI[2]], f0a.class.getClassLoader());
        if (lIIIIIlIlIllIIlI(lllllllllllllllIllIllIIllIIIIlIl, llIIIIlIllIllI[2])) {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findVirtual(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIll);
          "".length();
          if (" ".length() << " ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findStatic(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIll);
        } 
        "".length();
        if ("   ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIllIIIlIlI = llIIIIIlllllIl[Integer.parseInt(lllllllllllllllIllIllIIllIIIlIIl[llIIIIlIllIllI[2]])];
        if (lIIIIIlIlIllIIlI(lllllllllllllllIllIllIIllIIIIlIl, llIIIIlIllIllI[3])) {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findGetter(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIlI);
          "".length();
          if (((0x2 ^ 0x29 ^ "   ".length() << "   ".length()) & ((0x86 ^ 0x8F) << " ".length() << " ".length() << " ".length() ^ 16 + 131 - 117 + 133 ^ -" ".length())) > ((0xFD ^ 0x9A ^ (0x70 ^ 0x61) << " ".length() << " ".length()) & (0x1F ^ 0x7C ^ " ".length() << "   ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else if (lIIIIIlIlIllIIlI(lllllllllllllllIllIllIIllIIIIlIl, llIIIIlIllIllI[6])) {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findStaticGetter(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIlI);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else if (lIIIIIlIlIllIIlI(lllllllllllllllIllIllIIllIIIIlIl, llIIIIlIllIllI[4])) {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findSetter(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIlI);
          "".length();
          if (-" ".length() < -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIIIll.findStaticSetter(lllllllllllllllIllIllIIllIIIlIII, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIllIIIIllI);
    } catch (Exception lllllllllllllllIllIllIIllIIIIlII) {
      lllllllllllllllIllIllIIllIIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlIlIIIll() {
    llIIIIIlllllII = new String[llIIIIlIllIllI[7]];
    llIIIIIlllllII[llIIIIlIllIllI[8]] = llIIIIlIllIlII[llIIIIlIllIllI[4]];
    llIIIIIlllllII[llIIIIlIllIllI[9]] = llIIIIlIllIlII[llIIIIlIllIllI[5]];
    llIIIIIlllllII[llIIIIlIllIllI[10]] = llIIIIlIllIlII[llIIIIlIllIllI[11]];
    llIIIIIlllllII[llIIIIlIllIllI[12]] = llIIIIlIllIlII[llIIIIlIllIllI[13]];
    llIIIIIlllllII[llIIIIlIllIllI[14]] = llIIIIlIllIlII[llIIIIlIllIllI[15]];
    llIIIIIlllllII[llIIIIlIllIllI[16]] = llIIIIlIllIlII[llIIIIlIllIllI[17]];
    llIIIIIlllllII[llIIIIlIllIllI[18]] = llIIIIlIllIlII[llIIIIlIllIllI[19]];
    llIIIIIlllllII[llIIIIlIllIllI[13]] = llIIIIlIllIlII[llIIIIlIllIllI[20]];
    llIIIIIlllllII[llIIIIlIllIllI[5]] = llIIIIlIllIlII[llIIIIlIllIllI[12]];
    llIIIIIlllllII[llIIIIlIllIllI[21]] = llIIIIlIllIlII[llIIIIlIllIllI[22]];
    llIIIIIlllllII[llIIIIlIllIllI[15]] = llIIIIlIllIlII[llIIIIlIllIllI[18]];
    llIIIIIlllllII[llIIIIlIllIllI[4]] = llIIIIlIllIlII[llIIIIlIllIllI[23]];
    llIIIIIlllllII[llIIIIlIllIllI[24]] = llIIIIlIllIlII[llIIIIlIllIllI[24]];
    llIIIIIlllllII[llIIIIlIllIllI[2]] = llIIIIlIllIlII[llIIIIlIllIllI[8]];
    llIIIIIlllllII[llIIIIlIllIllI[11]] = llIIIIlIllIlII[llIIIIlIllIllI[14]];
    llIIIIIlllllII[llIIIIlIllIllI[0]] = llIIIIlIllIlII[llIIIIlIllIllI[21]];
    llIIIIIlllllII[llIIIIlIllIllI[6]] = llIIIIlIllIlII[llIIIIlIllIllI[10]];
    llIIIIIlllllII[llIIIIlIllIllI[3]] = llIIIIlIllIlII[llIIIIlIllIllI[25]];
    llIIIIIlllllII[llIIIIlIllIllI[22]] = llIIIIlIllIlII[llIIIIlIllIllI[26]];
    llIIIIIlllllII[llIIIIlIllIllI[26]] = llIIIIlIllIlII[llIIIIlIllIllI[16]];
    llIIIIIlllllII[llIIIIlIllIllI[19]] = llIIIIlIllIlII[llIIIIlIllIllI[9]];
    llIIIIIlllllII[llIIIIlIllIllI[20]] = llIIIIlIllIlII[llIIIIlIllIllI[7]];
    llIIIIIlllllII[llIIIIlIllIllI[17]] = llIIIIlIllIlII[llIIIIlIllIllI[27]];
    llIIIIIlllllII[llIIIIlIllIllI[25]] = llIIIIlIllIlII[llIIIIlIllIllI[28]];
    llIIIIIlllllII[llIIIIlIllIllI[23]] = llIIIIlIllIlII[llIIIIlIllIllI[29]];
    llIIIIIlllllII[llIIIIlIllIllI[1]] = llIIIIlIllIlII[llIIIIlIllIllI[30]];
    llIIIIIlllllIl = new Class[llIIIIlIllIllI[15]];
    llIIIIIlllllIl[llIIIIlIllIllI[2]] = Minecraft.class;
    llIIIIIlllllIl[llIIIIlIllIllI[3]] = EntityPlayerSP.class;
    llIIIIIlllllIl[llIIIIlIllIllI[1]] = f100000000000000000000.Integer.class;
    llIIIIIlllllIl[llIIIIlIllIllI[6]] = double.class;
    llIIIIIlllllIl[llIIIIlIllIllI[13]] = ak.BlockSafety.class;
    llIIIIIlllllIl[llIIIIlIllIllI[5]] = WorldClient.class;
    llIIIIIlllllIl[llIIIIlIllIllI[11]] = Block.class;
    llIIIIIlllllIl[llIIIIlIllIllI[0]] = f13.class;
    llIIIIIlllllIl[llIIIIlIllIllI[4]] = BlockPos.class;
  }
  
  private static void lIIIIIlIlIlIIlll() {
    llIIIIlIllIlII = new String[llIIIIlIllIllI[31]];
    llIIIIlIllIlII[llIIIIlIllIllI[0]] = lIIIIIlIlIlIIlII(llIIIIlIllIlIl[llIIIIlIllIllI[0]], llIIIIlIllIlIl[llIIIIlIllIllI[1]]);
    llIIIIlIllIlII[llIIIIlIllIllI[1]] = lIIIIIlIlIlIIlIl(llIIIIlIllIlIl[llIIIIlIllIllI[2]], llIIIIlIllIlIl[llIIIIlIllIllI[3]]);
    llIIIIlIllIlII[llIIIIlIllIllI[2]] = lIIIIIlIlIlIIlII(llIIIIlIllIlIl[llIIIIlIllIllI[6]], llIIIIlIllIlIl[llIIIIlIllIllI[4]]);
    llIIIIlIllIlII[llIIIIlIllIllI[3]] = lIIIIIlIlIlIIllI(llIIIIlIllIlIl[llIIIIlIllIllI[5]], llIIIIlIllIlIl[llIIIIlIllIllI[11]]);
    llIIIIlIllIlII[llIIIIlIllIllI[6]] = lIIIIIlIlIlIIllI(llIIIIlIllIlIl[llIIIIlIllIllI[13]], llIIIIlIllIlIl[llIIIIlIllIllI[15]]);
    llIIIIlIllIlII[llIIIIlIllIllI[4]] = lIIIIIlIlIlIIlII(llIIIIlIllIlIl[llIIIIlIllIllI[17]], llIIIIlIllIlIl[llIIIIlIllIllI[19]]);
    llIIIIlIllIlII[llIIIIlIllIllI[5]] = lIIIIIlIlIlIIlIl(llIIIIlIllIlIl[llIIIIlIllIllI[20]], llIIIIlIllIlIl[llIIIIlIllIllI[12]]);
    llIIIIlIllIlII[llIIIIlIllIllI[11]] = lIIIIIlIlIlIIlIl(llIIIIlIllIlIl[llIIIIlIllIllI[22]], llIIIIlIllIlIl[llIIIIlIllIllI[18]]);
    llIIIIlIllIlII[llIIIIlIllIllI[13]] = lIIIIIlIlIlIIlII("Bik1TCMBIiQBPAkqNUwtBCUkDDpGITQOOgE8LQM3DT5vNSEaICUhIgEpLxZ0DjkvARFZdHFWd10TMVhmJCIkFmEFJS8HLRotJxZhHTgoDmEFLTUKYSogLgElOCMyWWckIiQWYQUlLwctGi0nFmEKIC4BJUc/NQM6DWMIICIHLyoxOgk4JFl0SGw=", "hLAbN");
    llIIIIlIllIlII[llIIIIlIllIllI[15]] = lIIIIIlIlIlIIllI("HLA+z/X8KJ36lrFBCPfjg04jl5oscCYOjh68vOUlY/YRWv+ecJziHeBTCPuQZ/q8LUbG2M2WaRUloQOOp1MDN8C/Wq1sLxyzVMDgKR8FhsU1OX/14FwMyw==", "HAWSo");
    llIIIIlIllIlII[llIIIIlIllIllI[17]] = lIIIIIlIlIlIIlII("LAI6OUIzFyU0QgsCPHwpKBc+IVYhBjgODSoWKWJEby8mORonTCA5AiFMAzoGIwA4Y1ZmQw==", "FcLXl");
    llIIIIlIllIlII[llIIIIlIllIllI[19]] = lIIIIIlIlIlIIlII("LCA1Xz8rKyQSICMjNV87LCw1XxAuKiIaIXgjKBQ+JhpwRGJxcHEuM3hye1FyYmU=", "BEAqR");
    llIIIIlIllIlII[llIIIIlIllIllI[20]] = lIIIIIlIlIlIIlII("Bxc3YxQAHCYuCwgUN2MaBRsmIw1HFy05EB0LbQgXHRs3NCkFEzooCzoieSsQDB4nEk5ZQ3V8Jh9Id3dZSVI=", "irCMy");
    llIIIIlIllIlII[llIIIIlIllIllI[12]] = lIIIIIlIlIlIIlII("PRUyQwQ6HiMOGzIWMkMKPxkjAx19FSgZACcJaCgHJxkyFDk/ET8IGwAgfAsANhwiMl5jQXBYNidKcldJc1A=", "SpFmi");
    llIIIIlIllIlII[llIIIIlIllIllI[22]] = lIIIIIlIlIlIIllI("F6rutfrtpbjTUrV0KbkpzJTnfBy7g5EOrLDkZ7RUuMeUCdxnM0IZMJ5Pt2noeKs8kcmXOdyY/PjC3e6Le8Qv4wJGxYJS2b1vLWENdCvZBNVriKaHlj7Azh6Whlfwr9R+", "bErHf");
    llIIIIlIllIlII[llIIIIlIllIllI[18]] = lIIIIIlIlIlIIlIl("jR+ba8gq7zCpi+mWUQnDJoFCq53eMB89Tjr94fm/zYU=", "RHnyf");
    llIIIIlIllIlII[llIIIIlIllIllI[23]] = lIIIIIlIlIlIIllI("Ys9hd2vn3jyWaUtp1QaCLDdU8jWi6wz48fmZDKMOlocpM02BZr7kmQ11UbnlnazdPYwkIEWErp0Bi6iVdgXa7g==", "vXBJF");
    llIIIIlIllIlII[llIIIIlIllIllI[24]] = lIIIIIlIlIlIIllI("6AdoloqOdiyqjphCnBzWD4+sLw179C9PF0cA+2vNafjAKqapWDaftQ==", "MtIDk");
    llIIIIlIllIlII[llIIIIlIllIllI[8]] = lIIIIIlIlIlIIlIl("GP8J1pAhlEAdwF4RdmB8hYYfyRZ+V1MWKlHJwoBA7J3ekS9a3yAkRA==", "NyYcr");
    llIIIIlIllIlII[llIIIIlIllIllI[14]] = lIIIIIlIlIlIIlIl("Yvaq6smWQA/Sqw8RvGaBSrthb9QzhYJE2kdc5Tbgwoo=", "fgsyj");
    llIIIIlIllIlII[llIIIIlIllIllI[21]] = lIIIIIlIlIlIIllI("7Yoxywd2J5AXAfM6gTtfEPEToJcXCudLmbkaeN17v3dQslSDFB21/w==", "cXYEI");
    llIIIIlIllIlII[llIIIIlIllIllI[10]] = lIIIIIlIlIlIIlII("CjUZWhwNPggXAwU2GVoSCDkIGgVKHQQaFAciDBIFXjYEER0AD1pFRVdpMhNLV2pNVFE=", "dPmtq");
    llIIIIlIllIlII[llIIIIlIllIllI[25]] = lIIIIIlIlIlIIlII("OCxiECAgOSUXMDouYgE8JWcqUzVvJC9ZZm9pbEN0", "UILcT");
    llIIIIlIllIlII[llIIIIlIllIllI[26]] = lIIIIIlIlIlIIlII("Gj0/SDcdNi4FKBU+P0g4GDcoDXQHLCoSP1oRCQo1FzMYEjsAPXEALxo7FFdtQ2p4VgUXYmNPFho9P0k3HTYuBSgVPj9JOBg3KA11NjQkBTFPYmtG", "tXKfZ");
    llIIIIlIllIlII[llIIIIlIllIllI[16]] = lIIIIIlIlIlIIllI("vFEo1yJQZoCG8PpgorpVId/ity3XnuMRsnZnr0i0sMc=", "LZjnr");
    llIIIIlIllIlII[llIIIIlIllIllI[9]] = lIIIIIlIlIlIIllI("yM5FVZZP/fCUeZZwwunI9zgvXH8IOieaogQi1nK0fDCTM88xBt6LHLS3EErYOEC8ntXfu2kBMmk=", "rAExC");
    llIIIIlIllIlII[llIIIIlIllIllI[7]] = lIIIIIlIlIlIIllI("im96Rqd5SeTsEA3KrPl1VXQ3WqIy8leU7iLNZAZLfAG9RXxgpQNzDQ==", "Fyknx");
    llIIIIlIllIlII[llIIIIlIllIllI[27]] = lIIIIIlIlIlIIlII("ORVeIwMhABkkEzsXXjIfJF4WYBZuABwxDjECID8EbkVKcFd0UFA=", "TppPw");
    llIIIIlIllIlII[llIIIIlIllIllI[28]] = lIIIIIlIlIlIIlII("HzIEIkkAJxsvSSY2BnkVED4dNQI8NUhrKx8yBCJIACcbL0gTJhwgExw8HGw3BzYWKgQUJxd4Ti9pUmM=", "uSrCg");
    llIIIIlIllIlII[llIIIIlIllIllI[29]] = lIIIIIlIlIlIIlIl("0rPvKQyzTb268MG5alFQHf/orNmJKHNJWk+hRMN9Y6igHy3tumrnd5Pv7FlXqmRzpLNsus2b7hrjktBASQImI56dPsSKBif1AmiQHqTfIpBonmu1S/5I0g==", "dqwHM");
    llIIIIlIllIlII[llIIIIlIllIllI[30]] = lIIIIIlIlIlIIllI("kFgFzvkDjT/0EgOFiS7hsKnk9R5Mee64riTEyCsp/9ZeokFMBeqePV93XN3v5IldUrn5UPRGoixMnW4Iw6KyYUyquxwYsEdu7wZK1fzqxN2k/fvGHgFQuqT9+8YeAVC6Jy4yxNRneFuUpWCu3ljConhWKy8g206W", "Eflxr");
    llIIIIlIllIlIl = null;
  }
  
  private static void lIIIIIlIlIlIlIII() {
    String str = (new Exception()).getStackTrace()[llIIIIlIllIllI[0]].getFileName();
    llIIIIlIllIlIl = str.substring(str.indexOf("ä") + llIIIIlIllIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIlIlIIlII(String lllllllllllllllIllIllIIlIlllllll, String lllllllllllllllIllIllIIlIllllllI) {
    lllllllllllllllIllIllIIlIlllllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIlIlllllIl = new StringBuilder();
    char[] lllllllllllllllIllIllIIlIlllllII = lllllllllllllllIllIllIIlIllllllI.toCharArray();
    int lllllllllllllllIllIllIIlIllllIll = llIIIIlIllIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIlIlllllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIlIllIllI[0];
    while (lIIIIIlIlIlIlllI(j, i)) {
      char lllllllllllllllIllIllIIllIIIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIlIllllIll++;
      j++;
      "".length();
      if (" ".length() << " ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIlIlllllIl);
  }
  
  private static String lIIIIIlIlIlIIllI(String lllllllllllllllIllIllIIlIlllIlll, String lllllllllllllllIllIllIIlIlllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIlIllllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIlIlllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIlIllllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIlIllllIIl.init(llIIIIlIllIllI[2], lllllllllllllllIllIllIIlIllllIlI);
      return new String(lllllllllllllllIllIllIIlIllllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIlIllllIII) {
      lllllllllllllllIllIllIIlIllllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIlIlIIlIl(String lllllllllllllllIllIllIIlIlllIIlI, String lllllllllllllllIllIllIIlIlllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIlIlllIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIlIlllIIIl.getBytes(StandardCharsets.UTF_8)), llIIIIlIllIllI[13]), "DES");
      Cipher lllllllllllllllIllIllIIlIlllIlII = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIlIlllIlII.init(llIIIIlIllIllI[2], lllllllllllllllIllIllIIlIlllIlIl);
      return new String(lllllllllllllllIllIllIIlIlllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIlIlllIIll) {
      lllllllllllllllIllIllIIlIlllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlIlIlIIl() {
    llIIIIlIllIllI = new int[32];
    llIIIIlIllIllI[0] = ((0xA6 ^ 0x83) << " ".length() << " ".length() ^ 25 + 42 - 61 + 125) << " ".length() << " ".length() & ((125 + 103 - 200 + 123 ^ " ".length() << (0x92 ^ 0x95)) << " ".length() << " ".length() ^ -" ".length());
    llIIIIlIllIllI[1] = " ".length();
    llIIIIlIllIllI[2] = " ".length() << " ".length();
    llIIIIlIllIllI[3] = "   ".length();
    llIIIIlIllIllI[4] = 0x38 ^ 0x3D;
    llIIIIlIllIllI[5] = "   ".length() << " ".length();
    llIIIIlIllIllI[6] = " ".length() << " ".length() << " ".length();
    llIIIIlIllIllI[7] = (2 + 26 - -11 + 92 ^ (0xEB ^ 0xAC) << " ".length()) << " ".length();
    llIIIIlIllIllI[8] = ((0xAF ^ 0xA4) << " ".length() << " ".length() << " ".length() ^ 0 + 118 - -8 + 59) << " ".length();
    llIIIIlIllIllI[9] = 68 + 54 - 33 + 50 ^ (0x12 ^ 0x5B) << " ".length();
    llIIIIlIllIllI[10] = " ".length() << " ".length() << " ".length() ^ 0x63 ^ 0x72;
    llIIIIlIllIllI[11] = 0x27 ^ 0x34 ^ (0x8 ^ 0xD) << " ".length() << " ".length();
    llIIIIlIllIllI[12] = 0x8E ^ 0x83;
    llIIIIlIllIllI[13] = " ".length() << "   ".length();
    llIIIIlIllIllI[14] = (0x45 ^ 0x66) << " ".length() ^ 0x3D ^ 0x68;
    llIIIIlIllIllI[15] = 0x1B ^ 0x12;
    llIIIIlIllIllI[16] = "   ".length() << "   ".length();
    llIIIIlIllIllI[17] = (0x6 ^ 0x3) << " ".length();
    llIIIIlIllIllI[18] = 0xB8 ^ 0xB7;
    llIIIIlIllIllI[19] = (0xB0 ^ 0xB5) << "   ".length() ^ 0x82 ^ 0xA1;
    llIIIIlIllIllI[20] = "   ".length() << " ".length() << " ".length();
    llIIIIlIllIllI[21] = ((0x1A ^ 0x5F) << " ".length() ^ 106 + 87 - 77 + 27) << " ".length() << " ".length();
    llIIIIlIllIllI[22] = (0xFF ^ 0xAA ^ (0x44 ^ 0x6D) << " ".length()) << " ".length();
    llIIIIlIllIllI[23] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIllIllI[24] = 0xB2 ^ 0xA3;
    llIIIIlIllIllI[25] = ((0xAC ^ 0x93) << " ".length() ^ 0xD9 ^ 0xAC) << " ".length();
    llIIIIlIllIllI[26] = 0x13 ^ 0x4E ^ (0x53 ^ 0x76) << " ".length();
    llIIIIlIllIllI[27] = 0x8B ^ 0x90;
    llIIIIlIllIllI[28] = (0xEF ^ 0x84 ^ (0xBD ^ 0xA6) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIlIllIllI[29] = 0x2C ^ 0x31;
    llIIIIlIllIllI[30] = (0x60 ^ 0x7 ^ (0x4A ^ 0x47) << "   ".length()) << " ".length();
    llIIIIlIllIllI[31] = 0x6B ^ 0x6C ^ "   ".length() << "   ".length();
  }
  
  private static boolean lIIIIIlIlIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIlIlIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIlIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlIlIlIllIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIlIlIllIIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIlIlIlIlIll(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIlIlIlIllll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIlIlIlIllII(int paramInt) {
    return (paramInt < 0);
  }
  
  private static int lIIIIIlIlIlIlIlI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */