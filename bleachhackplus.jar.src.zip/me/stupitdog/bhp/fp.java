package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class fp extends au {
  @EventHandler
  private Listener<f10000000000000000000000000000> OnSteerEntity;
  
  @EventHandler
  private Listener<al> OnHorseSaddled;
  
  private static String[] llIIIllIIIIlll;
  
  private static Class[] llIIIllIIIlIII;
  
  private static final String[] llIIIllIIIlIIl;
  
  private static String[] llIIIllIIIllIl;
  
  private static final int[] llIIIllIIlIIIl;
  
  public fp() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fp.llIIIllIIIlIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fp.llIIIllIIIlIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fp.llIIIllIIIlIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/fp;Lme/zero/alpine/listener/Listener;)V
    //   67: aload_0
    //   68: new me/zero/alpine/listener/Listener
    //   71: dup
    //   72: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   77: getstatic me/stupitdog/bhp/fp.llIIIllIIlIIIl : [I
    //   80: iconst_0
    //   81: iaload
    //   82: anewarray java/util/function/Predicate
    //   85: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   88: <illegal opcode> 2 : (Lme/stupitdog/bhp/fp;Lme/zero/alpine/listener/Listener;)V
    //   93: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	94	0	lllllllllllllllIllIlIIlllIlIIIlI	Lme/stupitdog/bhp/fp;
  }
  
  static {
    lIIIIlIIllIIIIlI();
    lIIIIlIIllIIIIII();
    lIIIIlIIlIllllll();
    lIIIIlIIlIlllIII();
  }
  
  private static CallSite lIIIIlIIlIllIlll(MethodHandles.Lookup lllllllllllllllIllIlIIlllIIlIlll, String lllllllllllllllIllIlIIlllIIlIllI, MethodType lllllllllllllllIllIlIIlllIIlIlIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIlllIIlllIl = llIIIllIIIIlll[Integer.parseInt(lllllllllllllllIllIlIIlllIIlIllI)].split(llIIIllIIIlIIl[llIIIllIIlIIIl[3]]);
      Class<?> lllllllllllllllIllIlIIlllIIlllII = Class.forName(lllllllllllllllIllIlIIlllIIlllIl[llIIIllIIlIIIl[0]]);
      String lllllllllllllllIllIlIIlllIIllIll = lllllllllllllllIllIlIIlllIIlllIl[llIIIllIIlIIIl[1]];
      MethodHandle lllllllllllllllIllIlIIlllIIllIlI = null;
      int lllllllllllllllIllIlIIlllIIllIIl = lllllllllllllllIllIlIIlllIIlllIl[llIIIllIIlIIIl[3]].length();
      if (lIIIIlIIllIIIIll(lllllllllllllllIllIlIIlllIIllIIl, llIIIllIIlIIIl[2])) {
        MethodType lllllllllllllllIllIlIIlllIIlllll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIlllIIlllIl[llIIIllIIlIIIl[2]], fp.class.getClassLoader());
        if (lIIIIlIIllIIIlII(lllllllllllllllIllIlIIlllIIllIIl, llIIIllIIlIIIl[2])) {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findVirtual(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIlllll);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findStatic(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIlllll);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIlllIIllllI = llIIIllIIIlIII[Integer.parseInt(lllllllllllllllIllIlIIlllIIlllIl[llIIIllIIlIIIl[2]])];
        if (lIIIIlIIllIIIlII(lllllllllllllllIllIlIIlllIIllIIl, llIIIllIIlIIIl[3])) {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findGetter(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIllllI);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else if (lIIIIlIIllIIIlII(lllllllllllllllIllIlIIlllIIllIIl, llIIIllIIlIIIl[4])) {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findStaticGetter(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIllllI);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIIllIIIlII(lllllllllllllllIllIlIIlllIIllIIl, llIIIllIIlIIIl[5])) {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findSetter(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIllllI);
          "".length();
          if ("   ".length() == " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIlllIIllIlI = lllllllllllllllIllIlIIlllIIlIlll.findStaticSetter(lllllllllllllllIllIlIIlllIIlllII, lllllllllllllllIllIlIIlllIIllIll, lllllllllllllllIllIlIIlllIIllllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIlllIIllIlI);
    } catch (Exception lllllllllllllllIllIlIIlllIIllIII) {
      lllllllllllllllIllIlIIlllIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIlIlllIII() {
    llIIIllIIIIlll = new String[llIIIllIIlIIIl[5]];
    llIIIllIIIIlll[llIIIllIIlIIIl[2]] = llIIIllIIIlIIl[llIIIllIIlIIIl[4]];
    llIIIllIIIIlll[llIIIllIIlIIIl[4]] = llIIIllIIIlIIl[llIIIllIIlIIIl[5]];
    llIIIllIIIIlll[llIIIllIIlIIIl[1]] = llIIIllIIIlIIl[llIIIllIIlIIIl[6]];
    llIIIllIIIIlll[llIIIllIIlIIIl[0]] = llIIIllIIIlIIl[llIIIllIIlIIIl[7]];
    llIIIllIIIIlll[llIIIllIIlIIIl[3]] = llIIIllIIIlIIl[llIIIllIIlIIIl[8]];
    llIIIllIIIlIII = new Class[llIIIllIIlIIIl[2]];
    llIIIllIIIlIII[llIIIllIIlIIIl[1]] = Listener.class;
    llIIIllIIIlIII[llIIIllIIlIIIl[0]] = f13.class;
  }
  
  private static void lIIIIlIIlIllllll() {
    llIIIllIIIlIIl = new String[llIIIllIIlIIIl[9]];
    llIIIllIIIlIIl[llIIIllIIlIIIl[0]] = lIIIIlIIlIlllIIl(llIIIllIIIllIl[llIIIllIIlIIIl[0]], llIIIllIIIllIl[llIIIllIIlIIIl[1]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[1]] = lIIIIlIIlIlllIlI(llIIIllIIIllIl[llIIIllIIlIIIl[2]], llIIIllIIIllIl[llIIIllIIlIIIl[3]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[2]] = lIIIIlIIlIlllIlI(llIIIllIIIllIl[llIIIllIIlIIIl[4]], llIIIllIIIllIl[llIIIllIIlIIIl[5]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[3]] = lIIIIlIIlIlllIll(llIIIllIIIllIl[llIIIllIIlIIIl[6]], llIIIllIIIllIl[llIIIllIIlIIIl[7]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[4]] = lIIIIlIIlIlllIlI(llIIIllIIIllIl[llIIIllIIlIIIl[8]], llIIIllIIIllIl[llIIIllIIlIIIl[9]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[5]] = lIIIIlIIlIlllIlI(llIIIllIIIllIl[llIIIllIIlIIIl[10]], llIIIllIIIllIl[llIIIllIIlIIIl[11]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[6]] = lIIIIlIIlIlllIIl(llIIIllIIIllIl[llIIIllIIlIIIl[12]], llIIIllIIIllIl[llIIIllIIlIIIl[13]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[7]] = lIIIIlIIlIlllIll(llIIIllIIIllIl[llIIIllIIlIIIl[14]], llIIIllIIIllIl[llIIIllIIlIIIl[15]]);
    llIIIllIIIlIIl[llIIIllIIlIIIl[8]] = lIIIIlIIlIlllIll(llIIIllIIIllIl[llIIIllIIlIIIl[16]], llIIIllIIIllIl[llIIIllIIlIIIl[17]]);
    llIIIllIIIllIl = null;
  }
  
  private static void lIIIIlIIllIIIIII() {
    String str = (new Exception()).getStackTrace()[llIIIllIIlIIIl[0]].getFileName();
    llIIIllIIIllIl = str.substring(str.indexOf("ä") + llIIIllIIlIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIlIlllIll(String lllllllllllllllIllIlIIlllIIlIIIl, String lllllllllllllllIllIlIIlllIIlIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlllIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlllIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIlllIIlIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIlllIIlIIll.init(llIIIllIIlIIIl[2], lllllllllllllllIllIlIIlllIIlIlII);
      return new String(lllllllllllllllIllIlIIlllIIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlllIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlllIIlIIlI) {
      lllllllllllllllIllIlIIlllIIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIlIlllIIl(String lllllllllllllllIllIlIIlllIIIlllI, String lllllllllllllllIllIlIIlllIIIllIl) {
    lllllllllllllllIllIlIIlllIIIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIlllIIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIlllIIIllII = new StringBuilder();
    char[] lllllllllllllllIllIlIIlllIIIlIll = lllllllllllllllIllIlIIlllIIIllIl.toCharArray();
    int lllllllllllllllIllIlIIlllIIIlIlI = llIIIllIIlIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIlllIIIlllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIIlIIIl[0];
    while (lIIIIlIIllIIIlll(j, i)) {
      char lllllllllllllllIllIlIIlllIIIllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIlllIIIlIlI++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIlllIIIllII);
  }
  
  private static String lIIIIlIIlIlllIlI(String lllllllllllllllIllIlIIlllIIIIllI, String lllllllllllllllIllIlIIlllIIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlllIIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlllIIIIlIl.getBytes(StandardCharsets.UTF_8)), llIIIllIIlIIIl[8]), "DES");
      Cipher lllllllllllllllIllIlIIlllIIIlIII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIlllIIIlIII.init(llIIIllIIlIIIl[2], lllllllllllllllIllIlIIlllIIIlIIl);
      return new String(lllllllllllllllIllIlIIlllIIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlllIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlllIIIIlll) {
      lllllllllllllllIllIlIIlllIIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIllIIIIlI() {
    llIIIllIIlIIIl = new int[18];
    llIIIllIIlIIIl[0] = (0x7 ^ 0x2E) << " ".length() & ((0x55 ^ 0x7C) << " ".length() ^ 0xFFFFFFFF);
    llIIIllIIlIIIl[1] = " ".length();
    llIIIllIIlIIIl[2] = " ".length() << " ".length();
    llIIIllIIlIIIl[3] = "   ".length();
    llIIIllIIlIIIl[4] = " ".length() << " ".length() << " ".length();
    llIIIllIIlIIIl[5] = 0xB0 ^ 0xB5;
    llIIIllIIlIIIl[6] = "   ".length() << " ".length();
    llIIIllIIlIIIl[7] = 0xC6 ^ 0xC1;
    llIIIllIIlIIIl[8] = " ".length() << "   ".length();
    llIIIllIIlIIIl[9] = (0xDF ^ 0x86) << " ".length() ^ 45 + 87 - -37 + 18;
    llIIIllIIlIIIl[10] = ((0x93 ^ 0x94) << " ".length() << " ".length() << " ".length() ^ 0xA ^ 0x7F) << " ".length();
    llIIIllIIlIIIl[11] = (0x65 ^ 0x2) << " ".length() ^ 172 + 108 - 145 + 62;
    llIIIllIIlIIIl[12] = "   ".length() << " ".length() << " ".length();
    llIIIllIIlIIIl[13] = 0x4F ^ 0x42;
    llIIIllIIlIIIl[14] = (0xB6 ^ 0xB1) << " ".length();
    llIIIllIIlIIIl[15] = 0xCE ^ 0xC1;
    llIIIllIIlIIIl[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIIlIIIl[17] = 165 + 86 - 133 + 91 ^ "   ".length() << "   ".length() << " ".length();
  }
  
  private static boolean lIIIIlIIllIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIllIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIllIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */