package me.stupitdog.bhp;

public class f09 extends fs {
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f09.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */