package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.network.Packet;

public class f100000000000 extends fs {
  private final Packet packet;
  
  private static String[] lIllllIllllIlI;
  
  private static Class[] lIllllIllllIll;
  
  private static final String[] lIllllIlllllII;
  
  private static String[] lIllllIlllllIl;
  
  private static final int[] lIllllIllllllI;
  
  public f100000000000(Packet lllllllllllllllIlllIIIlllllIIlII) {
    this.packet = lllllllllllllllIlllIIIlllllIIlII;
  }
  
  public Packet getPacket() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f100000000000;)Lnet/minecraft/network/Packet;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIlllllIIIll	Lme/stupitdog/bhp/f100000000000;
  }
  
  static {
    lllllllIllIlIll();
    lllllllIllIlIlI();
    lllllllIllIlIIl();
    lllllllIllIIllI();
  }
  
  private static CallSite lllllllIllIIlIl(MethodHandles.Lookup lllllllllllllllIlllIIIllllIllIlI, String lllllllllllllllIlllIIIllllIllIIl, MethodType lllllllllllllllIlllIIIllllIllIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIlllllIIIII = lIllllIllllIlI[Integer.parseInt(lllllllllllllllIlllIIIllllIllIIl)].split(lIllllIlllllII[lIllllIllllllI[0]]);
      Class<?> lllllllllllllllIlllIIIllllIlllll = Class.forName(lllllllllllllllIlllIIIlllllIIIII[lIllllIllllllI[0]]);
      String lllllllllllllllIlllIIIllllIllllI = lllllllllllllllIlllIIIlllllIIIII[lIllllIllllllI[1]];
      MethodHandle lllllllllllllllIlllIIIllllIlllIl = null;
      int lllllllllllllllIlllIIIllllIlllII = lllllllllllllllIlllIIIlllllIIIII[lIllllIllllllI[2]].length();
      if (lllllllIllIllII(lllllllllllllllIlllIIIllllIlllII, lIllllIllllllI[3])) {
        MethodType lllllllllllllllIlllIIIlllllIIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIlllllIIIII[lIllllIllllllI[3]], f100000000000.class.getClassLoader());
        if (lllllllIllIllIl(lllllllllllllllIlllIIIllllIlllII, lIllllIllllllI[3])) {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findVirtual(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findStatic(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIlI);
        } 
        "".length();
        if ((0x17 ^ 0x12) == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIlllllIIIIl = lIllllIllllIll[Integer.parseInt(lllllllllllllllIlllIIIlllllIIIII[lIllllIllllllI[3]])];
        if (lllllllIllIllIl(lllllllllllllllIlllIIIllllIlllII, lIllllIllllllI[2])) {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findGetter(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIIl);
          "".length();
          if ("   ".length() < " ".length())
            return null; 
        } else if (lllllllIllIllIl(lllllllllllllllIlllIIIllllIlllII, lIllllIllllllI[4])) {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findStaticGetter(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIIl);
          "".length();
          if (" ".length() == ((0x30 ^ 0x7) & (0x18 ^ 0x2F ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllllIllIllIl(lllllllllllllllIlllIIIllllIlllII, lIllllIllllllI[5])) {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findSetter(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIIl);
          "".length();
          if (" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIllllIlllIl = lllllllllllllllIlllIIIllllIllIlI.findStaticSetter(lllllllllllllllIlllIIIllllIlllll, lllllllllllllllIlllIIIllllIllllI, lllllllllllllllIlllIIIlllllIIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIllllIlllIl);
    } catch (Exception lllllllllllllllIlllIIIllllIllIll) {
      lllllllllllllllIlllIIIllllIllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIllIIllI() {
    lIllllIllllIlI = new String[lIllllIllllllI[1]];
    lIllllIllllIlI[lIllllIllllllI[0]] = lIllllIlllllII[lIllllIllllllI[1]];
    lIllllIllllIll = new Class[lIllllIllllllI[1]];
    lIllllIllllIll[lIllllIllllllI[0]] = Packet.class;
  }
  
  private static void lllllllIllIlIIl() {
    lIllllIlllllII = new String[lIllllIllllllI[3]];
    lIllllIlllllII[lIllllIllllllI[0]] = lllllllIllIIlll(lIllllIlllllIl[lIllllIllllllI[0]], lIllllIlllllIl[lIllllIllllllI[1]]);
    lIllllIlllllII[lIllllIllllllI[1]] = lllllllIllIlIII(lIllllIlllllIl[lIllllIllllllI[3]], lIllllIlllllIl[lIllllIllllllI[2]]);
    lIllllIlllllIl = null;
  }
  
  private static void lllllllIllIlIlI() {
    String str = (new Exception()).getStackTrace()[lIllllIllllllI[0]].getFileName();
    lIllllIlllllIl = str.substring(str.indexOf("ä") + lIllllIllllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIllIlIII(String lllllllllllllllIlllIIIllllIlIlII, String lllllllllllllllIlllIIIllllIlIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllllIlIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllllIlIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIllllIlIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIllllIlIllI.init(lIllllIllllllI[3], lllllllllllllllIlllIIIllllIlIlll);
      return new String(lllllllllllllllIlllIIIllllIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllllIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllllIlIlIl) {
      lllllllllllllllIlllIIIllllIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIllIIlll(String lllllllllllllllIlllIIIllllIlIIIl, String lllllllllllllllIlllIIIllllIlIIII) {
    lllllllllllllllIlllIIIllllIlIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIllllIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIllllIIllll = new StringBuilder();
    char[] lllllllllllllllIlllIIIllllIIlllI = lllllllllllllllIlllIIIllllIlIIII.toCharArray();
    int lllllllllllllllIlllIIIllllIIllIl = lIllllIllllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIllllIlIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIllllllI[0];
    while (lllllllIllIlllI(j, i)) {
      char lllllllllllllllIlllIIIllllIlIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIllllIIllIl++;
      j++;
      "".length();
      if (-"  ".length() > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIllllIIllll);
  }
  
  private static void lllllllIllIlIll() {
    lIllllIllllllI = new int[6];
    lIllllIllllllI[0] = (0x38 ^ 0x61 ^ " ".length() << "   ".length() << " ".length()) & (9 + 55 - -80 + 1 ^ (0x42 ^ 0x53) << "   ".length() ^ -" ".length());
    lIllllIllllllI[1] = " ".length();
    lIllllIllllllI[2] = "   ".length();
    lIllllIllllllI[3] = " ".length() << " ".length();
    lIllllIllllllI[4] = " ".length() << " ".length() << " ".length();
    lIllllIllllllI[5] = (0x5A ^ 0x45) << " ".length() << " ".length() ^ 0x54 ^ 0x2D;
  }
  
  private static boolean lllllllIllIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIllIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIllIllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  public static class PostSend extends f100000000000 {
    public PostSend(Packet lllllllllllllllIllIlIIIIlIIlllll) {
      super(lllllllllllllllIllIlIIIIlIIlllll);
    }
    
    static {
    
    }
  }
  
  public static class PostReceive extends f100000000000 {
    public PostReceive(Packet lllllllllllllllIlllIIIllllIIlIll) {
      super(lllllllllllllllIlllIIIllllIIlIll);
    }
    
    static {
    
    }
  }
  
  public static class Send extends f100000000000 {
    public Send(Packet lllllllllllllllIllllIIIlllllIlll) {
      super(lllllllllllllllIllllIIIlllllIlll);
    }
    
    static {
    
    }
  }
  
  public static class Receive extends f100000000000 {
    public Receive(Packet lllllllllllllllIllllIIlIIllllIll) {
      super(lllllllllllllllIllllIIlIIllllIll);
    }
    
    static {
    
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */