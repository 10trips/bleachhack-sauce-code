package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.MovementInput;

public class fo extends au {
  f100000000000000000000.Double speed;
  
  @EventHandler
  public Listener<f10000000000000> listener;
  
  private static String[] llIIIIlIIIIlll;
  
  private static Class[] llIIIIlIIIlIII;
  
  private static final String[] llIIIIllllIIll;
  
  private static String[] llIIIIllllIlll;
  
  private static final int[] llIIIIllllllIl;
  
  public fo() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fo.llIIIIllllIIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fo.llIIIIllllIIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fo.llIIIIllllIIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/fo;Lme/zero/alpine/listener/Listener;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	68	0	lllllllllllllllIllIlIllllIIIIllI	Lme/stupitdog/bhp/fo;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/fo.llIIIIllllIIll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: ldc2_w 2.0
    //   14: dconst_0
    //   15: ldc2_w 5.0
    //   18: <illegal opcode> 2 : (Lme/stupitdog/bhp/fo;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   23: <illegal opcode> 3 : (Lme/stupitdog/bhp/fo;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   28: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	29	0	lllllllllllllllIllIlIllllIIIIlIl	Lme/stupitdog/bhp/fo;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   15: invokestatic lIIIIIllIllllIll : (I)Z
    //   18: ifeq -> 310
    //   21: aload_0
    //   22: <illegal opcode> 7 : (Lme/stupitdog/bhp/fo;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   27: <illegal opcode> 8 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   32: dstore_1
    //   33: dload_1
    //   34: <illegal opcode> 9 : (D)[D
    //   39: astore_3
    //   40: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   45: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   50: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   55: <illegal opcode> 11 : (Lnet/minecraft/util/MovementInput;)F
    //   60: fconst_0
    //   61: invokestatic lIIIIIllIllllIIl : (FF)I
    //   64: invokestatic lIIIIIllIlllllII : (I)Z
    //   67: ifeq -> 100
    //   70: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   75: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   80: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   85: <illegal opcode> 12 : (Lnet/minecraft/util/MovementInput;)F
    //   90: fconst_0
    //   91: invokestatic lIIIIIllIllllIIl : (FF)I
    //   94: invokestatic lIIIIIllIllllIll : (I)Z
    //   97: ifeq -> 166
    //   100: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   105: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   110: aload_3
    //   111: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   114: iconst_0
    //   115: iaload
    //   116: daload
    //   117: putfield field_70159_w : D
    //   120: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   125: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   130: aload_3
    //   131: getstatic me/stupitdog/bhp/fo.llIIIIllllllIl : [I
    //   134: iconst_1
    //   135: iaload
    //   136: daload
    //   137: putfield field_70179_y : D
    //   140: ldc ''
    //   142: invokevirtual length : ()I
    //   145: pop
    //   146: ldc ' '
    //   148: invokevirtual length : ()I
    //   151: ldc ' '
    //   153: invokevirtual length : ()I
    //   156: ldc ' '
    //   158: invokevirtual length : ()I
    //   161: ishl
    //   162: if_icmplt -> 194
    //   165: return
    //   166: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   171: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   176: dconst_0
    //   177: putfield field_70159_w : D
    //   180: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   185: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   190: dconst_0
    //   191: putfield field_70179_y : D
    //   194: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   199: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   204: <illegal opcode> 14 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   209: <illegal opcode> 15 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   214: invokestatic lIIIIIllIllllIll : (I)Z
    //   217: ifeq -> 234
    //   220: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   225: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   230: dload_1
    //   231: putfield field_70181_x : D
    //   234: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   239: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   244: <illegal opcode> 16 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   249: <illegal opcode> 15 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   254: invokestatic lIIIIIllIllllIll : (I)Z
    //   257: ifeq -> 278
    //   260: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   265: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   270: dload_1
    //   271: ldc2_w -1.0
    //   274: dmul
    //   275: putfield field_70181_x : D
    //   278: ldc ''
    //   280: invokevirtual length : ()I
    //   283: pop
    //   284: ldc '   '
    //   286: invokevirtual length : ()I
    //   289: ldc ' '
    //   291: invokevirtual length : ()I
    //   294: ldc ' '
    //   296: invokevirtual length : ()I
    //   299: ldc ' '
    //   301: invokevirtual length : ()I
    //   304: ishl
    //   305: ishl
    //   306: if_icmple -> 368
    //   309: return
    //   310: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   315: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   320: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   325: invokestatic lIIIIIllIlllllII : (I)Z
    //   328: ifeq -> 368
    //   331: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   336: <illegal opcode> 18 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   341: new net/minecraft/network/play/client/CPacketEntityAction
    //   344: dup
    //   345: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   350: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   355: <illegal opcode> 19 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   360: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   363: <illegal opcode> 20 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   368: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   33	245	1	lllllllllllllllIllIlIllllIIIIlII	D
    //   40	238	3	lllllllllllllllIllIlIllllIIIIIll	[D
    //   0	369	0	lllllllllllllllIllIlIllllIIIIIlI	Lme/stupitdog/bhp/fo;
  }
  
  static {
    lIIIIIllIllllIII();
    lIIIIIllIllIIlll();
    lIIIIIllIllIIllI();
    lIIIIIllIlIllllI();
  }
  
  private static CallSite lIIIIIlIIlIIIIII(MethodHandles.Lookup lllllllllllllllIllIlIlllIllllIII, String lllllllllllllllIllIlIlllIlllIlll, MethodType lllllllllllllllIllIlIlllIlllIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlllIllllllI = llIIIIlIIIIlll[Integer.parseInt(lllllllllllllllIllIlIlllIlllIlll)].split(llIIIIllllIIll[llIIIIllllllIl[4]]);
      Class<?> lllllllllllllllIllIlIlllIlllllIl = Class.forName(lllllllllllllllIllIlIlllIllllllI[llIIIIllllllIl[0]]);
      String lllllllllllllllIllIlIlllIlllllII = lllllllllllllllIllIlIlllIllllllI[llIIIIllllllIl[1]];
      MethodHandle lllllllllllllllIllIlIlllIllllIll = null;
      int lllllllllllllllIllIlIlllIllllIlI = lllllllllllllllIllIlIlllIllllllI[llIIIIllllllIl[3]].length();
      if (lIIIIIllIllllllI(lllllllllllllllIllIlIlllIllllIlI, llIIIIllllllIl[2])) {
        MethodType lllllllllllllllIllIlIllllIIIIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlllIllllllI[llIIIIllllllIl[2]], fo.class.getClassLoader());
        if (lIIIIIlllIIIIIII(lllllllllllllllIllIlIlllIllllIlI, llIIIIllllllIl[2])) {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findVirtual(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIllllIIIIIII);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findStatic(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIllllIIIIIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlllIlllllll = llIIIIlIIIlIII[Integer.parseInt(lllllllllllllllIllIlIlllIllllllI[llIIIIllllllIl[2]])];
        if (lIIIIIlllIIIIIII(lllllllllllllllIllIlIlllIllllIlI, llIIIIllllllIl[3])) {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findGetter(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIlllIlllllll);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else if (lIIIIIlllIIIIIII(lllllllllllllllIllIlIlllIllllIlI, llIIIIllllllIl[4])) {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findStaticGetter(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIlllIlllllll);
          "".length();
          if ((" ".length() & (" ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (lIIIIIlllIIIIIII(lllllllllllllllIllIlIlllIllllIlI, llIIIIllllllIl[5])) {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findSetter(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIlllIlllllll);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlllIllllIll = lllllllllllllllIllIlIlllIllllIII.findStaticSetter(lllllllllllllllIllIlIlllIlllllIl, lllllllllllllllIllIlIlllIlllllII, lllllllllllllllIllIlIlllIlllllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlllIllllIll);
    } catch (Exception lllllllllllllllIllIlIlllIllllIIl) {
      lllllllllllllllIllIlIlllIllllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIlIllllI() {
    llIIIIlIIIIlll = new String[llIIIIllllllIl[6]];
    llIIIIlIIIIlll[llIIIIllllllIl[7]] = llIIIIllllIIll[llIIIIllllllIl[5]];
    llIIIIlIIIIlll[llIIIIllllllIl[8]] = llIIIIllllIIll[llIIIIllllllIl[9]];
    llIIIIlIIIIlll[llIIIIllllllIl[10]] = llIIIIllllIIll[llIIIIllllllIl[11]];
    llIIIIlIIIIlll[llIIIIllllllIl[9]] = llIIIIllllIIll[llIIIIllllllIl[7]];
    llIIIIlIIIIlll[llIIIIllllllIl[2]] = llIIIIllllIIll[llIIIIllllllIl[12]];
    llIIIIlIIIIlll[llIIIIllllllIl[13]] = llIIIIllllIIll[llIIIIllllllIl[14]];
    llIIIIlIIIIlll[llIIIIllllllIl[15]] = llIIIIllllIIll[llIIIIllllllIl[16]];
    llIIIIlIIIIlll[llIIIIllllllIl[1]] = llIIIIllllIIll[llIIIIllllllIl[17]];
    llIIIIlIIIIlll[llIIIIllllllIl[3]] = llIIIIllllIIll[llIIIIllllllIl[18]];
    llIIIIlIIIIlll[llIIIIllllllIl[14]] = llIIIIllllIIll[llIIIIllllllIl[13]];
    llIIIIlIIIIlll[llIIIIllllllIl[11]] = llIIIIllllIIll[llIIIIllllllIl[19]];
    llIIIIlIIIIlll[llIIIIllllllIl[12]] = llIIIIllllIIll[llIIIIllllllIl[20]];
    llIIIIlIIIIlll[llIIIIllllllIl[21]] = llIIIIllllIIll[llIIIIllllllIl[22]];
    llIIIIlIIIIlll[llIIIIllllllIl[22]] = llIIIIllllIIll[llIIIIllllllIl[23]];
    llIIIIlIIIIlll[llIIIIllllllIl[24]] = llIIIIllllIIll[llIIIIllllllIl[25]];
    llIIIIlIIIIlll[llIIIIllllllIl[4]] = llIIIIllllIIll[llIIIIllllllIl[21]];
    llIIIIlIIIIlll[llIIIIllllllIl[17]] = llIIIIllllIIll[llIIIIllllllIl[26]];
    llIIIIlIIIIlll[llIIIIllllllIl[26]] = llIIIIllllIIll[llIIIIllllllIl[27]];
    llIIIIlIIIIlll[llIIIIllllllIl[28]] = llIIIIllllIIll[llIIIIllllllIl[15]];
    llIIIIlIIIIlll[llIIIIllllllIl[27]] = llIIIIllllIIll[llIIIIllllllIl[29]];
    llIIIIlIIIIlll[llIIIIllllllIl[25]] = llIIIIllllIIll[llIIIIllllllIl[8]];
    llIIIIlIIIIlll[llIIIIllllllIl[18]] = llIIIIllllIIll[llIIIIllllllIl[10]];
    llIIIIlIIIIlll[llIIIIllllllIl[30]] = llIIIIllllIIll[llIIIIllllllIl[24]];
    llIIIIlIIIIlll[llIIIIllllllIl[16]] = llIIIIllllIIll[llIIIIllllllIl[31]];
    llIIIIlIIIIlll[llIIIIllllllIl[5]] = llIIIIllllIIll[llIIIIllllllIl[28]];
    llIIIIlIIIIlll[llIIIIllllllIl[20]] = llIIIIllllIIll[llIIIIllllllIl[30]];
    llIIIIlIIIIlll[llIIIIllllllIl[19]] = llIIIIllllIIll[llIIIIllllllIl[6]];
    llIIIIlIIIIlll[llIIIIllllllIl[29]] = llIIIIllllIIll[llIIIIllllllIl[32]];
    llIIIIlIIIIlll[llIIIIllllllIl[23]] = llIIIIllllIIll[llIIIIllllllIl[33]];
    llIIIIlIIIIlll[llIIIIllllllIl[31]] = llIIIIllllIIll[llIIIIllllllIl[34]];
    llIIIIlIIIIlll[llIIIIllllllIl[0]] = llIIIIllllIIll[llIIIIllllllIl[35]];
    llIIIIlIIIlIII = new Class[llIIIIllllllIl[17]];
    llIIIIlIIIlIII[llIIIIllllllIl[0]] = f13.class;
    llIIIIlIIIlIII[llIIIIllllllIl[14]] = boolean.class;
    llIIIIlIIIlIII[llIIIIllllllIl[7]] = GameSettings.class;
    llIIIIlIIIlIII[llIIIIllllllIl[1]] = Listener.class;
    llIIIIlIIIlIII[llIIIIllllllIl[11]] = double.class;
    llIIIIlIIIlIII[llIIIIllllllIl[2]] = f100000000000000000000.Double.class;
    llIIIIlIIIlIII[llIIIIllllllIl[4]] = EntityPlayerSP.class;
    llIIIIlIIIlIII[llIIIIllllllIl[5]] = MovementInput.class;
    llIIIIlIIIlIII[llIIIIllllllIl[3]] = Minecraft.class;
    llIIIIlIIIlIII[llIIIIllllllIl[16]] = CPacketEntityAction.Action.class;
    llIIIIlIIIlIII[llIIIIllllllIl[12]] = KeyBinding.class;
    llIIIIlIIIlIII[llIIIIllllllIl[9]] = float.class;
  }
  
  private static void lIIIIIllIllIIllI() {
    llIIIIllllIIll = new String[llIIIIllllllIl[36]];
    llIIIIllllIIll[llIIIIllllllIl[0]] = lIIIIIllIlIlllll(llIIIIllllIlll[llIIIIllllllIl[0]], llIIIIllllIlll[llIIIIllllllIl[1]]);
    llIIIIllllIIll[llIIIIllllllIl[1]] = lIIIIIllIllIIIII(llIIIIllllIlll[llIIIIllllllIl[2]], llIIIIllllIlll[llIIIIllllllIl[3]]);
    llIIIIllllIIll[llIIIIllllllIl[2]] = lIIIIIllIlIlllll(llIIIIllllIlll[llIIIIllllllIl[4]], llIIIIllllIlll[llIIIIllllllIl[5]]);
    llIIIIllllIIll[llIIIIllllllIl[3]] = lIIIIIllIlIlllll(llIIIIllllIlll[llIIIIllllllIl[9]], llIIIIllllIlll[llIIIIllllllIl[11]]);
    llIIIIllllIIll[llIIIIllllllIl[4]] = lIIIIIllIlIlllll(llIIIIllllIlll[llIIIIllllllIl[7]], llIIIIllllIlll[llIIIIllllllIl[12]]);
    llIIIIllllIIll[llIIIIllllllIl[5]] = lIIIIIllIllIIIII(llIIIIllllIlll[llIIIIllllllIl[14]], llIIIIllllIlll[llIIIIllllllIl[16]]);
    llIIIIllllIIll[llIIIIllllllIl[9]] = lIIIIIllIllIIIII(llIIIIllllIlll[llIIIIllllllIl[17]], llIIIIllllIlll[llIIIIllllllIl[18]]);
    llIIIIllllIIll[llIIIIllllllIl[11]] = lIIIIIllIllIIIII(llIIIIllllIlll[llIIIIllllllIl[13]], llIIIIllllIlll[llIIIIllllllIl[19]]);
    llIIIIllllIIll[llIIIIllllllIl[7]] = lIIIIIllIllIIIIl(llIIIIllllIlll[llIIIIllllllIl[20]], llIIIIllllIlll[llIIIIllllllIl[22]]);
    llIIIIllllIIll[llIIIIllllllIl[12]] = lIIIIIllIlIlllll("FlondqQ2d1hhy0BTEgLNEzz/hUwWWrT7F/2ovfxVFLBPNMLFyelajj6bnLa1j4w7YQ7zSWFnUf8gTzvMgiqRPGbgy0Q3Y5DAjJ2RqsE179AeBRxdrC0HdB4FHF2sLQd0xxmetWBCK9XwNLav419Ijw==", "gEGin");
    llIIIIllllIIll[llIIIIllllllIl[14]] = lIIIIIllIllIIIIl("MhfeIk8xSN8rov4QMNvDT0YquImM2rMTvIsrUyWtMxG6zEQcdk7SsLeevOtpa89c9Cv6L/N1Va666ixNTTVsHg==", "dLuVz");
    llIIIIllllIIll[llIIIIllllllIl[16]] = lIIIIIllIllIIIIl("1IYtcpkNn4eEi/jVcv2rI8boUkb8oJWXtaTwVRqamjCoEf6HUOYJJnsZPQnvJXXA", "UTuOS");
    llIIIIllllIIll[llIIIIllllllIl[17]] = lIIIIIllIlIlllll("dw6L1IZ/9m9dLHfg57rmHynjF4/KsGyfN6rPUNpAL0BHcmeh1eQX0g==", "IHnFr");
    llIIIIllllIIll[llIIIIllllllIl[18]] = lIIIIIllIllIIIII("GTdqOjsBIi09Kxs1aisnBHwiJnUHIiEsK05gfmlvVHJk", "tRDIO");
    llIIIIllllIIll[llIIIIllllllIl[13]] = lIIIIIllIllIIIIl("O5wSmDjLhSNvUvrO4fdhYEcmSzvqd8XItRdARya2Raw801+3U/OctvuG+gPxbumsa6CnZ0JzNnPqFGRaQmekDA==", "WvJQb");
    llIIIIllllIIll[llIIIIllllllIl[19]] = lIIIIIllIlIlllll("UU6JiaxxP05Mr7qg5bGCCKw9J9HNBsWpbJcZ3LW7zok=", "VDnXJ");
    llIIIIllllIIll[llIIIIllllllIl[20]] = lIIIIIllIllIIIII("CCJMOQYQNws+FgogTCgaFWkDOEgBLhAvEREuDSQhFSIHLkhNA0sRNl9n", "eGbJr");
    llIIIIllllIIll[llIIIIllllllIl[22]] = lIIIIIllIlIlllll("Xil+LxeMrAJQQUBdG8FDElDUUP4hRHWQ49DwiMriwYRmV2g2HcrIDwqebnMVqIx5tJqlAjNZ48HKXYBbexfUCn52jggy1fndJ0KHXsqWNWM5578lu2OgpwX6NiWq64ifpnOxm6/Qfrs=", "VCXGu");
    llIIIIllllIIll[llIIIIllllllIl[23]] = lIIIIIllIlIlllll("lpVDegB1henoetJbZq2XhtKBjQ2QsZM80UoaAIJL5dq0xKUhVWJcnpYO+rJWFb0TxX5TUWcYpgDtpxvpUJs08Q==", "iIgpu");
    llIIIIllllIIll[llIIIIllllllIl[25]] = lIIIIIllIllIIIIl("aTuQpN8Cy6Z8UZlaX24jPsCYspHLMlVHMzB31vdyuAvMRE3EDNTo2nflvKws9HOxqb5I08IIzKJfet9cU65CGw==", "jTTti");
    llIIIIllllIIll[llIIIIllllllIl[21]] = lIIIIIllIllIIIII("OiltKxgiPCosCDgrbToEJ2IlN1Y6L3lrVndsY3g=", "WLCXl");
    llIIIIllllIIll[llIIIIllllllIl[26]] = lIIIIIllIllIIIII("LBcNShkrHBwHBiMUDUoBNhsVSjktBBwJESwGMAoENwZDAh0nHh07RXtAQVdGHRBDUk5iUlk=", "Brydt");
    llIIIIllllIIll[llIIIIllllllIl[27]] = lIIIIIllIllIIIII("KSFnCQ0xNCAOHSsjZxgRNGovS0l0dHlKSXR0eUpJdHRzAkNzfmlaWQ==", "DDIzy");
    llIIIIllllIIll[llIIIIllllllIl[15]] = lIIIIIllIllIIIIl("Y9odrmZIYo8kHjg/EPJcCB4e6ypgJAC1H1m9qZMF0NF/WBjJndF8ky4dBODoDDW0H5EJRRu0qALe7yovLYHKZg==", "QThry");
    llIIIIllllIIll[llIIIIllllllIl[29]] = lIIIIIllIllIIIII("CRJgKRwRBycuDAsQYDgAFFkoa1hUR35qWFRHfmpYVEd0IlJTTW56SERX", "dwNZh");
    llIIIIllllIIll[llIIIIllllllIl[8]] = lIIIIIllIlIlllll("QJOaz/h/LAc2wIUJmy8xc23XrQVfC3WRzRbNSJX7QDTAAcnnvBcV7RZ1UeuAAAuc7/t6N+evLUQMcqc45Zx6dm40IIWM6pRe4FOtlt7pZ/AjIbFSLnDd1w==", "dBFxc");
    llIIIIllllIIll[llIIIIllllllIl[10]] = lIIIIIllIlIlllll("TPmBxhZu5UKTUqi5wrdOlUskWpsh1muwpdLpaDyLURcu9+RwEsV2B48dXUS0i0Ydh0emT98r/I8=", "dvZwm");
    llIIIIllllIIll[llIIIIllllllIl[24]] = lIIIIIllIlIlllll("HHZxdpAEeI+hGuZg/raLg4GU+CHmedzsmLO3zAgP18OyjTE6NAiC4X/p0TnSnPm8", "WIcKD");
    llIIIIllllIIll[llIIIIllllllIl[31]] = lIIIIIllIllIIIII("DAkCWTkLAhMUJgMKAlkhFgUaWRkNGhMaMQwYPxkkFxhMET0HABIoY1pVRkULA1ZATXRCTA==", "blvwT");
    llIIIIllllIIll[llIIIIllllllIl[28]] = lIIIIIllIlIlllll("w4ZeOCy6FCp/nEtTHSI8bR3+NqD777DYPBIN2EzrHSUVj2u6KBvebXf9Gj1hah0g/Q4U1c8a/7c=", "bGCyO");
    llIIIIllllIIll[llIIIIllllllIl[30]] = lIIIIIllIllIIIIl("fK91HDokRekRlMXwKw1qh9iS9wrT87ABGDPwA0Te0pH5Yh1dpvuS9Wh6b14tgzAeBkdNE2BUFLxPGAaSI9+ZwA==", "lXzaZ");
    llIIIIllllIIll[llIIIIllllllIl[6]] = lIIIIIllIllIIIIl("4h7O/SnKj1Gh22YnSwVrU7p4m04xoDdZwpcJuCXv9Af2agxha6d3x+Md5GUmmBo+NKLrMIZj/tAEb3gvt/pPxQ==", "JiQso");
    llIIIIllllIIll[llIIIIllllllIl[32]] = lIIIIIllIllIIIII("FS9pIgYNOi4lFhctaTMaCGQhYEJIendhQkh6d2FCSHp9K0hPcGdxUg==", "xJGQr");
    llIIIIllllIIll[llIIIIllllllIl[33]] = lIIIIIllIllIIIIl("GaRyd4WDapcuMQ/uTFOT0iiXHM1J2Jhm9l2xsaMiZR+lhIWzY0DqwmRYzaRWWsheioQ1U/gVPRQzln2pzcHVUmg50oPA3ooTsIrVppzhalLTUNl06dEAVzQgcHLorOz37liAXUjIJrk=", "sWTrj");
    llIIIIllllIIll[llIIIIllllllIl[34]] = lIIIIIllIllIIIII("OTIGaBg+ORclBzYxBmgWOz4XKAF5JBcyAT45FTVbEDYfIyYyIwYvGzAkSCAcMjsWGUJjZEd3KiBtS3xVd3c=", "WWrFu");
    llIIIIllllIIll[llIIIIllllllIl[35]] = lIIIIIllIllIIIII("Lw5tCyQ3GyoMNC0MbRo4MkUlSWN4Ow85CQc5eUhqYktjWA==", "BkCxP");
    llIIIIllllIlll = null;
  }
  
  private static void lIIIIIllIllIIlll() {
    String str = (new Exception()).getStackTrace()[llIIIIllllllIl[0]].getFileName();
    llIIIIllllIlll = str.substring(str.indexOf("ä") + llIIIIllllllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIllIlIlllll(String lllllllllllllllIllIlIlllIlllIIlI, String lllllllllllllllIllIlIlllIlllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlllIlllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIlllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlllIlllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlllIlllIlII.init(llIIIIllllllIl[2], lllllllllllllllIllIlIlllIlllIlIl);
      return new String(lllllllllllllllIllIlIlllIlllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIlllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlllIlllIIll) {
      lllllllllllllllIllIlIlllIlllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIllIllIIIII(String lllllllllllllllIllIlIlllIllIllll, String lllllllllllllllIllIlIlllIllIlllI) {
    lllllllllllllllIllIlIlllIllIllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIllIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlllIllIllIl = new StringBuilder();
    char[] lllllllllllllllIllIlIlllIllIllII = lllllllllllllllIllIlIlllIllIlllI.toCharArray();
    int lllllllllllllllIllIlIlllIllIlIll = llIIIIllllllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIlllIllIllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIllllllIl[0];
    while (lIIIIIlllIIIIIlI(j, i)) {
      char lllllllllllllllIllIlIlllIlllIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIlllIllIlIll++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlllIllIllIl);
  }
  
  private static String lIIIIIllIllIIIIl(String lllllllllllllllIllIlIlllIllIIlll, String lllllllllllllllIllIlIlllIllIIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlllIllIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIllIIllI.getBytes(StandardCharsets.UTF_8)), llIIIIllllllIl[7]), "DES");
      Cipher lllllllllllllllIllIlIlllIllIlIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlllIllIlIIl.init(llIIIIllllllIl[2], lllllllllllllllIllIlIlllIllIlIlI);
      return new String(lllllllllllllllIllIlIlllIllIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIllIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlllIllIlIII) {
      lllllllllllllllIllIlIlllIllIlIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIllllIII() {
    llIIIIllllllIl = new int[37];
    llIIIIllllllIl[0] = (0xBE ^ 0x83) & (0x4A ^ 0x77 ^ 0xFFFFFFFF);
    llIIIIllllllIl[1] = " ".length();
    llIIIIllllllIl[2] = " ".length() << " ".length();
    llIIIIllllllIl[3] = "   ".length();
    llIIIIllllllIl[4] = " ".length() << " ".length() << " ".length();
    llIIIIllllllIl[5] = 0x80 ^ 0x85;
    llIIIIllllllIl[6] = 0x0 ^ 0x9 ^ (0x30 ^ 0x3B) << " ".length();
    llIIIIllllllIl[7] = " ".length() << "   ".length();
    llIIIIllllllIl[8] = 0x96 ^ 0x8F;
    llIIIIllllllIl[9] = "   ".length() << " ".length();
    llIIIIllllllIl[10] = (0x9C ^ 0x91) << " ".length();
    llIIIIllllllIl[11] = (0x93 ^ 0x84) << " ".length() ^ 0x46 ^ 0x6F;
    llIIIIllllllIl[12] = 0xAE ^ 0xA7;
    llIIIIllllllIl[13] = (0x6F ^ 0x68) << " ".length();
    llIIIIllllllIl[14] = (0x86 ^ 0x83) << " ".length();
    llIIIIllllllIl[15] = 148 + 60 - 71 + 38 ^ (0x5A ^ 0x4D) << "   ".length();
    llIIIIllllllIl[16] = (0xA0 ^ 0xB9) << " ".length() ^ 0x49 ^ 0x70;
    llIIIIllllllIl[17] = "   ".length() << " ".length() << " ".length();
    llIIIIllllllIl[18] = (0x93 ^ 0x96) << "   ".length() ^ 0xB0 ^ 0x95;
    llIIIIllllllIl[19] = 0x5E ^ 0x51;
    llIIIIllllllIl[20] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllllllIl[21] = (0x82 ^ 0x87) << " ".length() << " ".length();
    llIIIIllllllIl[22] = 0xFD ^ 0xBE ^ (0x7F ^ 0x56) << " ".length();
    llIIIIllllllIl[23] = (0x5B ^ 0x52) << " ".length();
    llIIIIllllllIl[24] = 0xF7 ^ 0x80 ^ (0x9B ^ 0x80) << " ".length() << " ".length();
    llIIIIllllllIl[25] = 0x3D ^ 0x2E;
    llIIIIllllllIl[26] = 0x58 ^ 0x4D;
    llIIIIllllllIl[27] = (0x3D ^ 0x36) << " ".length();
    llIIIIllllllIl[28] = 0xB8 ^ 0xA5;
    llIIIIllllllIl[29] = "   ".length() << "   ".length();
    llIIIIllllllIl[30] = (0x72 ^ 0x7D) << " ".length();
    llIIIIllllllIl[31] = ((0x46 ^ 0x4B) << " ".length() ^ 0x3F ^ 0x22) << " ".length() << " ".length();
    llIIIIllllllIl[32] = " ".length() << ((0x55 ^ 0x46) << " ".length() << " ".length() ^ 0x6 ^ 0x4F);
    llIIIIllllllIl[33] = 0x74 ^ 0x55;
    llIIIIllllllIl[34] = ((0xB8 ^ 0x9D) << " ".length() << " ".length() ^ 113 + 130 - 177 + 67) << " ".length();
    llIIIIllllllIl[35] = (0xA1 ^ 0xA6) << " ".length() << " ".length() ^ 0x33 ^ 0xC;
    llIIIIllllllIl[36] = (0x7B ^ 0x72) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIIlllIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlllIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllIllllllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIllIllllIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIllIlllllII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static int lIIIIIllIllllIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */