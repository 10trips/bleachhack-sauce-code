package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class f100000000000000000000000000 extends au {
  private BlockPos renderBlock;
  
  private BlockPos lastBlock;
  
  private boolean packetCancel;
  
  private ao breaktimer;
  
  private EnumFacing direction;
  
  f100000000000000000000.Boolean autoBreak;
  
  f100000000000000000000.Boolean picOnly;
  
  f100000000000000000000.Integer delay;
  
  @EventHandler
  private Listener<f100000000000.Send> packetSendListener;
  
  @EventHandler
  private Listener<fm> OnDamageBlock;
  
  private static String[] llIIIIIllIlIll;
  
  private static Class[] llIIIIIllIllII;
  
  private static final String[] llIIIIlIllllll;
  
  private static String[] llIIIIllIIllll;
  
  private static final int[] llIIIIllIlIIll;
  
  public f100000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   45: iconst_0
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000;Z)V
    //   52: aload_0
    //   53: new me/stupitdog/bhp/ao
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: <illegal opcode> 2 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/stupitdog/bhp/ao;)V
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: aload_0
    //   71: <illegal opcode> invoke : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/zero/alpine/listener/EventHook;
    //   76: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   79: iconst_0
    //   80: iaload
    //   81: anewarray java/util/function/Predicate
    //   84: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   87: <illegal opcode> 3 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/zero/alpine/listener/Listener;)V
    //   92: aload_0
    //   93: new me/zero/alpine/listener/Listener
    //   96: dup
    //   97: aload_0
    //   98: <illegal opcode> invoke : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/zero/alpine/listener/EventHook;
    //   103: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   106: iconst_0
    //   107: iaload
    //   108: anewarray java/util/function/Predicate
    //   111: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   114: <illegal opcode> 4 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/zero/alpine/listener/Listener;)V
    //   119: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	120	0	lllllllllllllllIllIllIIIlIIIlIlI	Lme/stupitdog/bhp/f100000000000000000000000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   14: iconst_1
    //   15: iaload
    //   16: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   21: <illegal opcode> 6 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   26: aload_0
    //   27: aload_0
    //   28: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   34: iconst_4
    //   35: iaload
    //   36: aaload
    //   37: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   40: iconst_1
    //   41: iaload
    //   42: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   47: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   52: aload_0
    //   53: aload_0
    //   54: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIlIllllll : [Ljava/lang/String;
    //   57: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   60: iconst_5
    //   61: iaload
    //   62: aaload
    //   63: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   66: bipush #6
    //   68: iaload
    //   69: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   72: iconst_0
    //   73: iaload
    //   74: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   77: bipush #7
    //   79: iaload
    //   80: <illegal opcode> 8 : (Lme/stupitdog/bhp/f100000000000000000000000000;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   85: <illegal opcode> 9 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   90: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	91	0	lllllllllllllllIllIllIIIlIIIlIIl	Lme/stupitdog/bhp/f100000000000000000000000000;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lnet/minecraft/util/math/BlockPos;
    //   6: invokestatic lIIIIIllIIIlIIII : (Ljava/lang/Object;)Z
    //   9: ifeq -> 167
    //   12: aload_0
    //   13: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   18: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   23: invokestatic lIIIIIllIIIlIIIl : (I)Z
    //   26: ifeq -> 167
    //   29: aload_0
    //   30: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/stupitdog/bhp/ao;
    //   35: aload_0
    //   36: <illegal opcode> 14 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   41: <illegal opcode> 15 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   46: i2l
    //   47: <illegal opcode> 16 : (Lme/stupitdog/bhp/ao;J)Z
    //   52: invokestatic lIIIIIllIIIlIIIl : (I)Z
    //   55: ifeq -> 167
    //   58: aload_0
    //   59: <illegal opcode> 17 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   64: <illegal opcode> 12 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   69: invokestatic lIIIIIllIIIlIIIl : (I)Z
    //   72: ifeq -> 112
    //   75: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   80: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   85: <illegal opcode> 20 : ()Lnet/minecraft/util/EnumHand;
    //   90: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/item/ItemStack;
    //   95: <illegal opcode> 22 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   100: <illegal opcode> 23 : ()Lnet/minecraft/item/Item;
    //   105: invokestatic lIIIIIllIIIlIIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   108: ifeq -> 112
    //   111: return
    //   112: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   117: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   122: <illegal opcode> 24 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   127: new net/minecraft/network/play/client/CPacketPlayerDigging
    //   130: dup
    //   131: <illegal opcode> 25 : ()Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;
    //   136: aload_0
    //   137: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lnet/minecraft/util/math/BlockPos;
    //   142: aload_0
    //   143: <illegal opcode> 26 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lnet/minecraft/util/EnumFacing;
    //   148: invokespecial <init> : (Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   151: <illegal opcode> 27 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   156: aload_0
    //   157: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lme/stupitdog/bhp/ao;
    //   162: <illegal opcode> 28 : (Lme/stupitdog/bhp/ao;)V
    //   167: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   172: <illegal opcode> 29 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   177: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   180: iconst_0
    //   181: iaload
    //   182: putfield field_78781_i : I
    //   185: ldc ''
    //   187: invokevirtual length : ()I
    //   190: pop
    //   191: ldc_w ' '
    //   194: invokevirtual length : ()I
    //   197: ldc_w ' '
    //   200: invokevirtual length : ()I
    //   203: ishl
    //   204: ldc_w ' '
    //   207: invokevirtual length : ()I
    //   210: ldc_w ' '
    //   213: invokevirtual length : ()I
    //   216: ishl
    //   217: if_icmpeq -> 222
    //   220: return
    //   221: astore_1
    //   222: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	223	0	lllllllllllllllIllIllIIIlIIIlIII	Lme/stupitdog/bhp/f100000000000000000000000000;
    // Exception table:
    //   from	to	target	type
    //   167	185	221	java/lang/Exception
  }
  
  private boolean canBreak(BlockPos lllllllllllllllIllIllIIIlIIIIllI) {
    // Byte code:
    //   0: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 30 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: aload_1
    //   11: <illegal opcode> 31 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   16: astore_2
    //   17: aload_2
    //   18: <illegal opcode> 32 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   23: astore_3
    //   24: aload_3
    //   25: aload_2
    //   26: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   31: <illegal opcode> 30 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   36: aload_1
    //   37: <illegal opcode> 33 : (Lnet/minecraft/block/Block;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F
    //   42: ldc_w -1.0
    //   45: invokestatic lIIIIIllIIIlIIll : (FF)I
    //   48: invokestatic lIIIIIllIIIlIIIl : (I)Z
    //   51: ifeq -> 90
    //   54: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   57: iconst_1
    //   58: iaload
    //   59: ldc ''
    //   61: invokevirtual length : ()I
    //   64: pop
    //   65: bipush #10
    //   67: bipush #14
    //   69: ixor
    //   70: ineg
    //   71: ifle -> 95
    //   74: bipush #82
    //   76: bipush #89
    //   78: ixor
    //   79: sipush #136
    //   82: sipush #131
    //   85: ixor
    //   86: iconst_m1
    //   87: ixor
    //   88: iand
    //   89: ireturn
    //   90: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   93: iconst_0
    //   94: iaload
    //   95: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	96	0	lllllllllllllllIllIllIIIlIIIIlll	Lme/stupitdog/bhp/f100000000000000000000000000;
    //   0	96	1	lllllllllllllllIllIllIIIlIIIIllI	Lnet/minecraft/util/math/BlockPos;
    //   17	79	2	lllllllllllllllIllIllIIIlIIIIlIl	Lnet/minecraft/block/state/IBlockState;
    //   24	72	3	lllllllllllllllIllIllIIIlIIIIlII	Lnet/minecraft/block/Block;
  }
  
  public BlockPos getTarget() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000000000;)Lnet/minecraft/util/math/BlockPos;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIllIIIlIIIIIll	Lme/stupitdog/bhp/f100000000000000000000000000;
  }
  
  public void setTarget(BlockPos lllllllllllllllIllIllIIIlIIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lnet/minecraft/util/math/BlockPos;)V
    //   7: aload_0
    //   8: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   11: iconst_0
    //   12: iaload
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000;Z)V
    //   18: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   23: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   28: <illegal opcode> 24 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   33: new net/minecraft/network/play/client/CPacketPlayerDigging
    //   36: dup
    //   37: <illegal opcode> 35 : ()Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;
    //   42: aload_1
    //   43: <illegal opcode> 36 : ()Lnet/minecraft/util/EnumFacing;
    //   48: invokespecial <init> : (Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   51: <illegal opcode> 27 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   56: aload_0
    //   57: getstatic me/stupitdog/bhp/f100000000000000000000000000.llIIIIllIlIIll : [I
    //   60: iconst_1
    //   61: iaload
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000;Z)V
    //   67: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   72: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   77: <illegal opcode> 24 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   82: new net/minecraft/network/play/client/CPacketPlayerDigging
    //   85: dup
    //   86: <illegal opcode> 25 : ()Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;
    //   91: aload_1
    //   92: <illegal opcode> 36 : ()Lnet/minecraft/util/EnumFacing;
    //   97: invokespecial <init> : (Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   100: <illegal opcode> 27 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   105: aload_0
    //   106: <illegal opcode> 36 : ()Lnet/minecraft/util/EnumFacing;
    //   111: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lnet/minecraft/util/EnumFacing;)V
    //   116: aload_0
    //   117: aload_1
    //   118: <illegal opcode> 38 : (Lme/stupitdog/bhp/f100000000000000000000000000;Lnet/minecraft/util/math/BlockPos;)V
    //   123: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	124	0	lllllllllllllllIllIllIIIlIIIIIlI	Lme/stupitdog/bhp/f100000000000000000000000000;
    //   0	124	1	lllllllllllllllIllIllIIIlIIIIIIl	Lnet/minecraft/util/math/BlockPos;
  }
  
  static {
    lIIIIIllIIIIllll();
    lIIIIIlIlllllIlI();
    lIIIIIlIllllIllI();
    lIIIIIlIllIIlllI();
  }
  
  private static CallSite lIIIIIlIIIIIIlIl(MethodHandles.Lookup lllllllllllllllIllIllIIIIlllIIlI, String lllllllllllllllIllIllIIIIlllIIIl, MethodType lllllllllllllllIllIllIIIIlllIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIIIllllIII = llIIIIIllIlIll[Integer.parseInt(lllllllllllllllIllIllIIIIlllIIIl)].split(llIIIIlIllllll[llIIIIllIlIIll[8]]);
      Class<?> lllllllllllllllIllIllIIIIlllIlll = Class.forName(lllllllllllllllIllIllIIIIllllIII[llIIIIllIlIIll[0]]);
      String lllllllllllllllIllIllIIIIlllIllI = lllllllllllllllIllIllIIIIllllIII[llIIIIllIlIIll[1]];
      MethodHandle lllllllllllllllIllIllIIIIlllIlIl = null;
      int lllllllllllllllIllIllIIIIlllIlII = lllllllllllllllIllIllIIIIllllIII[llIIIIllIlIIll[3]].length();
      if (lIIIIIllIIIllIII(lllllllllllllllIllIllIIIIlllIlII, llIIIIllIlIIll[2])) {
        MethodType lllllllllllllllIllIllIIIIllllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIIIllllIII[llIIIIllIlIIll[2]], f100000000000000000000000000.class.getClassLoader());
        if (lIIIIIllIIIlIlIl(lllllllllllllllIllIllIIIIlllIlII, llIIIIllIlIIll[2])) {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findVirtual(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIlI);
          "".length();
          if ((" ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ 0xFFFFFFFF)) == -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findStatic(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIlI);
        } 
        "".length();
        if (" ".length() >= "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIIIllllIIl = llIIIIIllIllII[Integer.parseInt(lllllllllllllllIllIllIIIIllllIII[llIIIIllIlIIll[2]])];
        if (lIIIIIllIIIlIlIl(lllllllllllllllIllIllIIIIlllIlII, llIIIIllIlIIll[3])) {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findGetter(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIIl);
          "".length();
          if (-" ".length() >= 0)
            return null; 
        } else if (lIIIIIllIIIlIlIl(lllllllllllllllIllIllIIIIlllIlII, llIIIIllIlIIll[4])) {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findStaticGetter(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIIl);
          "".length();
          if (((" ".length() << (0x8A ^ 0x8D) ^ 26 + 96 - 18 + 31) << "   ".length() & ((98 + 8 - 55 + 92 ^ (0x3 ^ 0x12) << "   ".length()) << "   ".length() ^ -" ".length())) > "   ".length())
            return null; 
        } else if (lIIIIIllIIIlIlIl(lllllllllllllllIllIllIIIIlllIlII, llIIIIllIlIIll[5])) {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findSetter(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIIl);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIIIlllIlIl = lllllllllllllllIllIllIIIIlllIIlI.findStaticSetter(lllllllllllllllIllIllIIIIlllIlll, lllllllllllllllIllIllIIIIlllIllI, lllllllllllllllIllIllIIIIllllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIIIlllIlIl);
    } catch (Exception lllllllllllllllIllIllIIIIlllIIll) {
      lllllllllllllllIllIllIIIIlllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIllIIlllI() {
    llIIIIIllIlIll = new String[llIIIIllIlIIll[9]];
    llIIIIIllIlIll[llIIIIllIlIIll[10]] = llIIIIlIllllll[llIIIIllIlIIll[11]];
    llIIIIIllIlIll[llIIIIllIlIIll[3]] = llIIIIlIllllll[llIIIIllIlIIll[12]];
    llIIIIIllIlIll[llIIIIllIlIIll[13]] = llIIIIlIllllll[llIIIIllIlIIll[14]];
    llIIIIIllIlIll[llIIIIllIlIIll[15]] = llIIIIlIllllll[llIIIIllIlIIll[16]];
    llIIIIIllIlIll[llIIIIllIlIIll[17]] = llIIIIlIllllll[llIIIIllIlIIll[18]];
    llIIIIIllIlIll[llIIIIllIlIIll[19]] = llIIIIlIllllll[llIIIIllIlIIll[20]];
    llIIIIIllIlIll[llIIIIllIlIIll[8]] = llIIIIlIllllll[llIIIIllIlIIll[21]];
    llIIIIIllIlIll[llIIIIllIlIIll[12]] = llIIIIlIllllll[llIIIIllIlIIll[17]];
    llIIIIIllIlIll[llIIIIllIlIIll[22]] = llIIIIlIllllll[llIIIIllIlIIll[23]];
    llIIIIIllIlIll[llIIIIllIlIIll[24]] = llIIIIlIllllll[llIIIIllIlIIll[19]];
    llIIIIIllIlIll[llIIIIllIlIIll[25]] = llIIIIlIllllll[llIIIIllIlIIll[26]];
    llIIIIIllIlIll[llIIIIllIlIIll[1]] = llIIIIlIllllll[llIIIIllIlIIll[27]];
    llIIIIIllIlIll[llIIIIllIlIIll[28]] = llIIIIlIllllll[llIIIIllIlIIll[29]];
    llIIIIIllIlIll[llIIIIllIlIIll[21]] = llIIIIlIllllll[llIIIIllIlIIll[6]];
    llIIIIIllIlIll[llIIIIllIlIIll[30]] = llIIIIlIllllll[llIIIIllIlIIll[28]];
    llIIIIIllIlIll[llIIIIllIlIIll[31]] = llIIIIlIllllll[llIIIIllIlIIll[32]];
    llIIIIIllIlIll[llIIIIllIlIIll[33]] = llIIIIlIllllll[llIIIIllIlIIll[34]];
    llIIIIIllIlIll[llIIIIllIlIIll[20]] = llIIIIlIllllll[llIIIIllIlIIll[35]];
    llIIIIIllIlIll[llIIIIllIlIIll[36]] = llIIIIlIllllll[llIIIIllIlIIll[37]];
    llIIIIIllIlIll[llIIIIllIlIIll[14]] = llIIIIlIllllll[llIIIIllIlIIll[38]];
    llIIIIIllIlIll[llIIIIllIlIIll[35]] = llIIIIlIllllll[llIIIIllIlIIll[33]];
    llIIIIIllIlIll[llIIIIllIlIIll[37]] = llIIIIlIllllll[llIIIIllIlIIll[39]];
    llIIIIIllIlIll[llIIIIllIlIIll[40]] = llIIIIlIllllll[llIIIIllIlIIll[40]];
    llIIIIIllIlIll[llIIIIllIlIIll[23]] = llIIIIlIllllll[llIIIIllIlIIll[13]];
    llIIIIIllIlIll[llIIIIllIlIIll[41]] = llIIIIlIllllll[llIIIIllIlIIll[36]];
    llIIIIIllIlIll[llIIIIllIlIIll[42]] = llIIIIlIllllll[llIIIIllIlIIll[43]];
    llIIIIIllIlIll[llIIIIllIlIIll[44]] = llIIIIlIllllll[llIIIIllIlIIll[42]];
    llIIIIIllIlIll[llIIIIllIlIIll[18]] = llIIIIlIllllll[llIIIIllIlIIll[22]];
    llIIIIIllIlIll[llIIIIllIlIIll[38]] = llIIIIlIllllll[llIIIIllIlIIll[30]];
    llIIIIIllIlIll[llIIIIllIlIIll[45]] = llIIIIlIllllll[llIIIIllIlIIll[46]];
    llIIIIIllIlIll[llIIIIllIlIIll[34]] = llIIIIlIllllll[llIIIIllIlIIll[41]];
    llIIIIIllIlIll[llIIIIllIlIIll[32]] = llIIIIlIllllll[llIIIIllIlIIll[47]];
    llIIIIIllIlIll[llIIIIllIlIIll[2]] = llIIIIlIllllll[llIIIIllIlIIll[25]];
    llIIIIIllIlIll[llIIIIllIlIIll[29]] = llIIIIlIllllll[llIIIIllIlIIll[48]];
    llIIIIIllIlIll[llIIIIllIlIIll[11]] = llIIIIlIllllll[llIIIIllIlIIll[49]];
    llIIIIIllIlIll[llIIIIllIlIIll[49]] = llIIIIlIllllll[llIIIIllIlIIll[45]];
    llIIIIIllIlIll[llIIIIllIlIIll[26]] = llIIIIlIllllll[llIIIIllIlIIll[50]];
    llIIIIIllIlIll[llIIIIllIlIIll[4]] = llIIIIlIllllll[llIIIIllIlIIll[15]];
    llIIIIIllIlIll[llIIIIllIlIIll[27]] = llIIIIlIllllll[llIIIIllIlIIll[44]];
    llIIIIIllIlIll[llIIIIllIlIIll[6]] = llIIIIlIllllll[llIIIIllIlIIll[51]];
    llIIIIIllIlIll[llIIIIllIlIIll[43]] = llIIIIlIllllll[llIIIIllIlIIll[10]];
    llIIIIIllIlIll[llIIIIllIlIIll[5]] = llIIIIlIllllll[llIIIIllIlIIll[52]];
    llIIIIIllIlIll[llIIIIllIlIIll[46]] = llIIIIlIllllll[llIIIIllIlIIll[24]];
    llIIIIIllIlIll[llIIIIllIlIIll[47]] = llIIIIlIllllll[llIIIIllIlIIll[31]];
    llIIIIIllIlIll[llIIIIllIlIIll[0]] = llIIIIlIllllll[llIIIIllIlIIll[9]];
    llIIIIIllIlIll[llIIIIllIlIIll[51]] = llIIIIlIllllll[llIIIIllIlIIll[53]];
    llIIIIIllIlIll[llIIIIllIlIIll[52]] = llIIIIlIllllll[llIIIIllIlIIll[54]];
    llIIIIIllIlIll[llIIIIllIlIIll[50]] = llIIIIlIllllll[llIIIIllIlIIll[55]];
    llIIIIIllIlIll[llIIIIllIlIIll[16]] = llIIIIlIllllll[llIIIIllIlIIll[56]];
    llIIIIIllIlIll[llIIIIllIlIIll[39]] = llIIIIlIllllll[llIIIIllIlIIll[57]];
    llIIIIIllIlIll[llIIIIllIlIIll[48]] = llIIIIlIllllll[llIIIIllIlIIll[58]];
    llIIIIIllIllII = new Class[llIIIIllIlIIll[26]];
    llIIIIIllIllII[llIIIIllIlIIll[21]] = EnumFacing.class;
    llIIIIIllIllII[llIIIIllIlIIll[12]] = EntityPlayerSP.class;
    llIIIIIllIllII[llIIIIllIlIIll[3]] = Listener.class;
    llIIIIIllIllII[llIIIIllIlIIll[11]] = Minecraft.class;
    llIIIIIllIllII[llIIIIllIlIIll[20]] = CPacketPlayerDigging.Action.class;
    llIIIIIllIllII[llIIIIllIlIIll[23]] = int.class;
    llIIIIIllIllII[llIIIIllIlIIll[4]] = f100000000000000000000.Boolean.class;
    llIIIIIllIllII[llIIIIllIlIIll[18]] = NetHandlerPlayClient.class;
    llIIIIIllIllII[llIIIIllIlIIll[19]] = WorldClient.class;
    llIIIIIllIllII[llIIIIllIlIIll[17]] = PlayerControllerMP.class;
    llIIIIIllIllII[llIIIIllIlIIll[14]] = EnumHand.class;
    llIIIIIllIllII[llIIIIllIlIIll[16]] = Item.class;
    llIIIIIllIllII[llIIIIllIlIIll[5]] = f100000000000000000000.Integer.class;
    llIIIIIllIllII[llIIIIllIlIIll[0]] = f13.class;
    llIIIIIllIllII[llIIIIllIlIIll[2]] = ao.class;
    llIIIIIllIllII[llIIIIllIlIIll[1]] = boolean.class;
    llIIIIIllIllII[llIIIIllIlIIll[8]] = BlockPos.class;
  }
  
  private static void lIIIIIlIllllIllI() {
    llIIIIlIllllll = new String[llIIIIllIlIIll[59]];
    llIIIIlIllllll[llIIIIllIlIIll[0]] = lIIIIIlIllIlIIII(llIIIIllIIllll[llIIIIllIlIIll[0]], llIIIIllIIllll[llIIIIllIlIIll[1]]);
    llIIIIlIllllll[llIIIIllIlIIll[1]] = lIIIIIlIllIlIIIl(llIIIIllIIllll[llIIIIllIlIIll[2]], llIIIIllIIllll[llIIIIllIlIIll[3]]);
    llIIIIlIllllll[llIIIIllIlIIll[2]] = lIIIIIlIllIlIIIl(llIIIIllIIllll[llIIIIllIlIIll[4]], llIIIIllIIllll[llIIIIllIlIIll[5]]);
    llIIIIlIllllll[llIIIIllIlIIll[3]] = lIIIIIlIllIlIIIl(llIIIIllIIllll[llIIIIllIlIIll[8]], llIIIIllIIllll[llIIIIllIlIIll[11]]);
    llIIIIlIllllll[llIIIIllIlIIll[4]] = lIIIIIlIllIlIIII(llIIIIllIIllll[llIIIIllIlIIll[12]], llIIIIllIIllll[llIIIIllIlIIll[14]]);
    llIIIIlIllllll[llIIIIllIlIIll[5]] = lIIIIIlIllIlIIlI(llIIIIllIIllll[llIIIIllIlIIll[16]], llIIIIllIIllll[llIIIIllIlIIll[18]]);
    llIIIIlIllllll[llIIIIllIlIIll[8]] = lIIIIIlIllIlIIlI(llIIIIllIIllll[llIIIIllIlIIll[20]], llIIIIllIIllll[llIIIIllIlIIll[21]]);
    llIIIIlIllllll[llIIIIllIlIIll[11]] = lIIIIIlIllIlIIlI(llIIIIllIIllll[llIIIIllIlIIll[17]], llIIIIllIIllll[llIIIIllIlIIll[23]]);
    llIIIIlIllllll[llIIIIllIlIIll[12]] = lIIIIIlIllIlIIlI(llIIIIllIIllll[llIIIIllIlIIll[19]], llIIIIllIIllll[llIIIIllIlIIll[26]]);
    llIIIIlIllllll[llIIIIllIlIIll[14]] = lIIIIIlIllIlIIlI(llIIIIllIIllll[llIIIIllIlIIll[27]], llIIIIllIIllll[llIIIIllIlIIll[29]]);
    llIIIIlIllllll[llIIIIllIlIIll[16]] = lIIIIIlIllIlIIII("TiTOZZmR9KRz/sOZkvic8unZtEehPZEI0bzJ86AUel7RwRv9svjBrtIctcN8S/cWc3TdfjbI9NtZiZlwYm8Uy0+qvGpilJis+p7jh/D431YR/wYEdDPBJLiwcIcS77dc", "BBmcW");
    llIIIIlIllllll[llIIIIllIlIIll[18]] = lIIIIIlIllIlIIII("lYVPFyYn5OVNALrt37cjt+V+sASXrVkqMksPqSTIT6IySw+pJMhPol7f0ZCDZhv6b10ffvhn5Kyg69P0ttCIxw==", "gEyXG");
    llIIIIlIllllll[llIIIIllIlIIll[20]] = lIIIIIlIllIlIIIl("ODZlAzIgIyIEIjo0ZRIuJX0qH3w9MjgiIzQwIxUib3sBWRxvc2s=", "USKpF");
    llIIIIlIllllll[llIIIIllIlIIll[21]] = lIIIIIlIllIlIIII("QkEGdiDW7JHbDgLZbOBH1ZTP032ApMo+ctFZepZzXoty0Vl6lnNei7/9isomIv5yjSpPKDMR0fUV5USPsdEkKw==", "IWUEF");
    llIIIIlIllllll[llIIIIllIlIIll[17]] = lIIIIIlIllIlIIIl("DghpOR8WHS4+DwwKaSgDE0Mhe1tTXXd6W1Ndd3pbU113eltTXXd6W1Ndd3pbWR8iLQIQGSI4Ig0ZIi0OEVdvBgECGyZlBwIDIGU4Fx8uJAxYJA4DQi8AImUYFxg3Ix8HAiBlCQsdaCxaU113eltTXXd6W1Ndd3pbU113eltHJCk+DgQINXFRQ00=", "cmGJk");
    llIIIIlIllllll[llIIIIllIlIIll[23]] = lIIIIIlIllIlIIlI("lV8aKyCArIydiC7AIlGd15XAAFkHNef9eCf8FpbnIW14J/wWluchbS+9QjDEuG7z5+wNT5BqjGb5Ih6BUOtsXyWPUaifTgAT", "xcmmQ");
    llIIIIlIllllll[llIIIIllIlIIll[19]] = lIIIIIlIllIlIIlI("vDPKFl00COSXOU5YO1Ix2Xxvw3ZX/yhdFJrEa8YDLyEUmsRrxgMvIUL9z7zUWn0TOaZvLAbKW//NiOITKOftMJwMmXFeVUa5", "dEtbz");
    llIIIIlIllllll[llIIIIllIlIIll[26]] = lIIIIIlIllIlIIIl("Dg9WBScWGhECNwwNVhQ7E0QeG2kEDww0PwwJEyY8EFBQXx8NDwxZPgoEHRUhAgwMWSYXAxRZPgIeEFkRDwUbHQMMGUNMc0M=", "cjxvS");
    llIIIIlIllllll[llIIIIllIlIIll[27]] = lIIIIIlIllIlIIlI("6WGS302oSjJrMGCMsc1S56q5OwBd02kVBCLNVLm1dMUEIs1UubV0xXeaEQykVS88X7yxcdireZxDLeGNcn/5aEf3kD5N8v6y", "pZxqJ");
    llIIIIlIllllll[llIIIIllIlIIll[29]] = lIIIIIlIllIlIIlI("3ZBgBtYrAmV4Y1btW9oadukCimB1UCTrAK007Soo9IfSDt+IaoFE8bLJDtnlJvghuWKSmN1dfEuYA2Sp40a6BPiC8PDn1tCz4zelBhX+MwcdXXPXuHlq//pFU8CNwZeLlpuE17TuBMTLuTV/ijHrD6HhqSxQ5Q0Kio/t58PsBFA=", "JxugV");
    llIIIIlIllllll[llIIIIllIlIIll[6]] = lIIIIIlIllIlIIIl("GSpIGj4BPw8dLhsoSAsiBGEAWHpEf1ZZekR/Vll6RH9WWXpEf1ZZekR/Vll6Ti0UDCsfOw8ELwZ1VFNqVG8=", "tOfiJ");
    llIIIIlIllllll[llIIIIllIlIIll[28]] = lIIIIIlIllIlIIlI("U4I7dPzt4qkB+oPXcfKSb/hCFxzS3q20iAehbcFFrJErYfXbqV3nUeNYio/1nxCx28vjLCfTqtUtLy+XHu3RJbZ0WSRggd2vnIclJtwr9vtxDDcyqb6dbmp9jTpuCsQP", "ObEmv");
    llIIIIlIllllll[llIIIIllIlIIll[32]] = lIIIIIlIllIlIIIl("ITx2CSU5KTEONSM+dhg5PHc+S2F8aWhKYXxpaEphaAo9FDV2OjkUMik1YlJ4GmN4Wg==", "LYXzQ");
    llIIIIlIllllll[llIIIIllIlIIll[34]] = lIIIIIlIllIlIIII("8OrrrVvO+xB2q3F9rGNhacQVJYzMkbMNQC1gMD3L35z7TyvCBbrTxMS084cXwnNcO3i5antXVx0DWdSuZvsIcYH1u4PayYkGQ3cRYm+pbbr0iwMBrlMaDII6BZ0yocqduhuPbYCfGUg=", "Ikxpk");
    llIIIIlIllllll[llIIIIllIlIIll[35]] = lIIIIIlIllIlIIIl("Oh9AJDgiCgcjKDgdQDUkJ1QIZnxnSl5nfGdKXmd8Z0peZ3xnSl5naBUVATspNhRUMCkjLA87OTJARn4WbVpO", "WznWL");
    llIIIIlIllllll[llIIIIllIlIIll[37]] = lIIIIIlIllIlIIIl("GwcMdAocDB05FRQEDHQEGQsdNBNbDw02ExwSFDseEBBWDQgHDhwZCxwHFi5dExcWOThEWkhuXkA9CGBPOQwdLkgYCxY/BAcDHi5IABYRNkgYAwwySDcOFzkMJQ0LYU45DB0uSBgLFj8EBwMeLkgXDhc5DFoRDDsTEE0xGAsaARMJExQWHWFdVUI=", "ubxZg");
    llIIIIlIllllll[llIIIIllIlIIll[38]] = lIIIIIlIllIlIIlI("mkzfSUwLUx/oAEQXXcx1ZwoBAc6HBBSahsK7zlViuseGwrvOVWK6x1zySbhKDZmeTKcA4zN+fHAlacntxYOWsQ==", "nTsxx");
    llIIIIlIllllll[llIIIIllIlIIll[33]] = lIIIIIlIllIlIIlI("naZdyTASFllIvtdqfWAACLarDtNvBu+2+twvQBJoGWPpwlIsSMBbdFtGAnrXZETqim6WWOy3ey9MpDaEJV8lAQ==", "Eqtas");
    llIIIIlIllllll[llIIIIllIlIIll[39]] = lIIIIIlIllIlIIlI("7u6Tc+ZIAGmtuUojuO2zO1ZxPqCiYWJ9D9GuexFh8y/p12h8hMXTc5KD7DEp5QADijjj0mbzYDTnPxKBJAh+7E7w8VGazX0hR2JZRtS5w/0SpB1wpNsi/3b7Pl+lFk2v", "WZWQO");
    llIIIIlIllllll[llIIIIllIlIIll[40]] = lIIIIIlIllIlIIIl("HiQ+fygZLy8yNxEnPn8mHCgvPzFeDCM/IBMzKzcxSicjNCkUHn1gcURzFTN/QXVwcWVQ", "pAJQE");
    llIIIIlIllllll[llIIIIllIlIIll[13]] = lIIIIIlIllIlIIlI("Rde3GFTIbhL36H1/Y8p5tB1H2N3Uoae4Gw50Rgx/MbBVwCuoa5JVILmUoqWWK4shFpGiRkeR0foRDhH69B5Sxw==", "eWqQf");
    llIIIIlIllllll[llIIIIllIlIIll[36]] = lIIIIIlIllIlIIIl("AgpJBgMaHw4BEwAISRcfH0EBREdfX1dFR19fV0VHX19XRUdfX1dFR19fV0VHVQsOBxIMGw4aGVVeVE9XT09HVQ==", "ooguw");
    llIIIIlIllllll[llIIIIllIlIIll[43]] = lIIIIIlIllIlIIIl("IDAyRggnOyMLFy8zMkYHIjolA0sMOSkLDnQzMwYGEWRxXlR3YBkPX2YZKA0RYTgvBgAtJycOEWE3KgcGJXo1HAQ6MGkhJyI6JQM2OjQyDV4COyMcSiM8KA0GPDQgHEo5OjQEAWECKRoJKm4KBgA6eisBCys2NAkDOnozHAwieisJESZ6BAQKLT4WBxZ1fABSRW4=", "NUFhe");
    llIIIIlIllllll[llIIIIllIlIIll[42]] = lIIIIIlIllIlIIII("Ezl0ww0EqWYH6pc5ZTDb6AkwRbEY6oHwR+NfBl+ng/QcVubFspne2S6r8f5erhaTYWZqFXTIwaTVtkVtTgCC4WPUbT5JlB3A", "SIJfl");
    llIIIIlIllllll[llIIIIllIlIIll[22]] = lIIIIIlIllIlIIlI("RIDzioQ67fl+ASftXREseXNSTKJ9s4IJcHBLvUVIo2xwcEu9RUijbOg9Be4Up/c/1jsRR/HB39n3H0sVcETy2w==", "qvJbc");
    llIIIIlIllllll[llIIIIllIlIIll[30]] = lIIIIIlIllIlIIIl("KxBIBAMzBQ8DEykSSBUfNlsARkd2RVZHR3ZFVkdHdkVWR0d2RVZHR3ZFVkdHfBEPBRIlAQ8YGXxEVU1XZlU=", "Fufww");
    llIIIIlIllllll[llIIIIllIlIIll[46]] = lIIIIIlIllIlIIII("yY2pUdUbGMJAuScFCxpPYXhIlyfXqojZOiHaA99Q8GJrIe9ObGoC7sGUI7OmMffR+jFl7rae5TA=", "zmCSp");
    llIIIIlIllllll[llIIIIllIlIIll[41]] = lIIIIIlIllIlIIII("nuJPcPFgOFde7lSMwVi7cFKG424OrTL2wg1Fo2McY5oG8nsg67xVAWfy2A4nnMaR", "pxYtO");
    llIIIIlIllllll[llIIIIllIlIIll[47]] = lIIIIIlIllIlIIlI("ROygWfQKv3YonwzVZtwo3ApXC+BRospphkrZ5TXxaOsc69oB9lH8ntn3Ofv/fSSVbE9raSuUTxqNt20yO6VTK4Ey9R5hQJCo1ZJY+lmZr+4=", "jsilY");
    llIIIIlIllllll[llIIIIllIlIIll[25]] = lIIIIIlIllIlIIIl("Dg9FFDgWGgITKAwNRQUkE0QNVnxTWltXfFNaW1d8U1pbV3xTWltXfFNaW1d8WQgZAi0IHgIKKRFQWV1sQ0pLRw==", "cjkgL");
    llIIIIlIllllll[llIIIIllIlIIll[48]] = lIIIIIlIllIlIIlI("5fWXc8N76r2ovSwaxpFl8VD5TyH+EaMo7NKhnbi7PF1QI8Q67WXsZk7jgtAHG0pPmrKLykxAK8s=", "kyxlq");
    llIIIIlIllllll[llIIIIllIlIIll[49]] = lIIIIIlIllIlIIlI("7UJ+3VNIwKCAGoq0lbAqn+MKLCOv1EfVu5yBCnpdusW7nIEKel26xXKKNlHPpOY1l8UVPzJ5t6hk0S0r9aPNcg==", "uyiHZ");
    llIIIIlIllllll[llIIIIllIlIIll[45]] = lIIIIIlIllIlIIlI("cnG9WqKjVsEUIydseFORf8lsCyrZ4FNXAVEJs/oaXzXzphuRF2FZoOL0EjkPlhXZrb5cj9p4S00=", "AFsHH");
    llIIIIlIllllll[llIIIIllIlIIll[50]] = lIIIIIlIllIlIIlI("EcyAImXUFAJ9GNroapCghPMs8a3Ej9goQDMBzQCPvPZAMwHNAI+89oXJGrdwl5Ui7WcjM9MmQMeFHNbBxy9Pyg==", "VbDlV");
    llIIIIlIllllll[llIIIIllIlIIll[15]] = lIIIIIlIllIlIIlI("oP0GINbO7HGQmVqMwxbSHORx2M0pbNLEKVvk4r2FXZopW+TivYVdmhAGyfg0IQUElyn2q3u7XLVDdh71bTN/UbPnEM02ykjn", "VEyKD");
    llIIIIlIllllll[llIIIIllIlIIll[44]] = lIIIIIlIllIlIIIl("JTZlEQM9IyIWEyc0ZQAfOH0tU0d4Y3tSR3hje1JHeGN7Ukd4Y3tSR3hje1JHcj4oWEByc2tCVw==", "HSKbw");
    llIIIIlIllllll[llIIIIllIlIIll[51]] = lIIIIIlIllIlIIII("I6cC86Jeg135q3xtZlT3V6tQMy++s8RhRE5/UQ10JhOlkd68zGSqmE0r1/5g38HY", "Soatv");
    llIIIIlIllllll[llIIIIllIlIIll[10]] = lIIIIIlIllIlIIlI("JHUv41/JKKXDZk7zOI7GbaEizKo+/v0hHy9cvp7YfNR/PaKb+HC0K7VNC2rVgReJc6849fKN7nv6JvxC92jrYhZ/IArSBZi3ivbCku9xVL5AwJabJmJ3iw==", "vgxXK");
    llIIIIlIllllll[llIIIIllIlIIll[52]] = lIIIIIlIllIlIIIl("GxJnNAEDByAzERkQZyUdBlkvdkVGR3l3RUZHeXdFRkd5d0VGR3l3RUZHeXdFTAUsIBwFAyw1NxkYJSIUGE1hCx8XAShoGRcZLmgmAgUgKRJNLWALGBNYOjMABh49IxoRWCsvBVkReHdFRkd5d0VGR3l3RUZHeXdFRkd5YzcZGCUiFBhMc2dV", "vwIGu");
    llIIIIlIllllll[llIIIIllIlIIll[24]] = lIIIIIlIllIlIIIl("LyosSTsoIT0EJCApLEkjNSY0SRMvOjUhNyImNgBsBQAPKWxwfGJHdmFv", "AOXgV");
    llIIIIlIllllll[llIIIIllIlIIll[31]] = lIIIIIlIllIlIIlI("MBIowL2HfIbQ7N6T8tdCdhRFgFCPPi/fM5N0V58VpYQzk3RXnxWlhB4bGvI/uN4pfgUkmmrj644awQAHTn8PwQ==", "arrbv");
    llIIIIlIllllll[llIIIIllIlIIll[9]] = lIIIIIlIllIlIIlI("4pf1CRcmTCwXRjbnH4k69Yd1SnPkh3kUuvhTSCOEJHaTFO4xb0Dzwg==", "HKyxB");
    llIIIIlIllllll[llIIIIllIlIIll[53]] = lIIIIIlIllIlIIIl("Ow59MSMjGzo2MzkMfSA/JkU1L201Cj0hMjpRe2sBbEtz", "VkSBW");
    llIIIIlIllllll[llIIIIllIlIIll[54]] = lIIIIIlIllIlIIlI("szUM3qGTgwCd+UVaFicvb/7lVGE8U3UtoAtzsoV1QjMIBsuafUxPU+dVrVCyoDU7wyksfWiM+PU60Cxq2xbsvlj174L09Av6HAuhPiraBFYHrQne6sauGephKUegErurvXzqJGzuuLFm3IPRp0WGE+dVrVCyoDU7EU2jx+X8KbU+SZqCctg/b+uMshRbcrPs", "iCeRN");
    llIIIIlIllllll[llIIIIllIlIIll[55]] = lIIIIIlIllIlIIlI("8TiwAe+LYOTDVU0V9LgkteuZB1GSYntUUvFPzSu/PvMXyVzktwpJp7KhuVJHzKLQCg8XfxxLxUI=", "NepEn");
    llIIIIlIllllll[llIIIIllIlIIll[56]] = lIIIIIlIllIlIIII("Fman6Jo7h4rMBKdrpVATByDKErkXS90KdBagc11qA4R0FqBzXWoDhD8EdEdqEzJ1oJOONJUGtgaLuTPgZmVI3w==", "djjJu");
    llIIIIlIllllll[llIIIIllIlIIll[57]] = lIIIIIlIllIlIIIl("ICdKHi04Mg0ZPSIlSg8xPWwFAmM/JxcILXdqTTtjbWI=", "MBdmY");
    llIIIIlIllllll[llIIIIllIlIIll[58]] = lIIIIIlIllIlIIIl("CCtDPzIQPgQ4IgopQy4uFWALfXZVfl18dlV+XXx2VX5dfHZVfl18dlV+XXx2XyIMPzInIgIvLV94V2xmRQ==", "eNmLF");
    llIIIIllIIllll = null;
  }
  
  private static void lIIIIIlIlllllIlI() {
    String str = (new Exception()).getStackTrace()[llIIIIllIlIIll[0]].getFileName();
    llIIIIllIIllll = str.substring(str.indexOf("ä") + llIIIIllIlIIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIllIlIIII(String lllllllllllllllIllIllIIIIllIIllI, String lllllllllllllllIllIllIIIIllIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIIllIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIIllIIlIl.getBytes(StandardCharsets.UTF_8)), llIIIIllIlIIll[12]), "DES");
      Cipher lllllllllllllllIllIllIIIIllIlIII = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIIIllIlIII.init(llIIIIllIlIIll[2], lllllllllllllllIllIllIIIIllIlIIl);
      return new String(lllllllllllllllIllIllIIIIllIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIIllIIlll) {
      lllllllllllllllIllIllIIIIllIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIllIlIIlI(String lllllllllllllllIllIllIIIIllIIIIl, String lllllllllllllllIllIllIIIIllIIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIIllIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIIllIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIIIllIIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIIIllIIIll.init(llIIIIllIlIIll[2], lllllllllllllllIllIllIIIIllIIlII);
      return new String(lllllllllllllllIllIllIIIIllIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIIllIIIlI) {
      lllllllllllllllIllIllIIIIllIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIllIlIIIl(String lllllllllllllllIllIllIIIIlIllIIl, String lllllllllllllllIllIllIIIIlIlIlll) {
    lllllllllllllllIllIllIIIIlIllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIlIllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIIIlIlIlIl = new StringBuilder();
    char[] lllllllllllllllIllIllIIIIlIlIIll = lllllllllllllllIllIllIIIIlIlIlll.toCharArray();
    int lllllllllllllllIllIllIIIIlIlIIIl = llIIIIllIlIIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIIIlIllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIllIlIIll[0];
    while (lIIIIIllIIIllIlI(j, i)) {
      char lllllllllllllllIllIllIIIIlIllIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIIIlIlIIIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIIIlIlIlIl);
  }
  
  private static void lIIIIIllIIIIllll() {
    llIIIIllIlIIll = new int[60];
    llIIIIllIlIIll[0] = " ".length() << " ".length() & (" ".length() << " ".length() ^ -" ".length());
    llIIIIllIlIIll[1] = " ".length();
    llIIIIllIlIIll[2] = " ".length() << " ".length();
    llIIIIllIlIIll[3] = "   ".length();
    llIIIIllIlIIll[4] = " ".length() << " ".length() << " ".length();
    llIIIIllIlIIll[5] = (0xB4 ^ 0xB1) << " ".length() ^ 0x52 ^ 0x5D;
    llIIIIllIlIIll[6] = (0x6A ^ 0x6F) << " ".length() << " ".length();
    llIIIIllIlIIll[7] = (0x26 ^ 0x5B) << " ".length() << " ".length();
    llIIIIllIlIIll[8] = "   ".length() << " ".length();
    llIIIIllIlIIll[9] = 0x37 ^ 0x4;
    llIIIIllIlIIll[10] = 0x2F ^ 0x3A ^ (0x41 ^ 0x5C) << " ".length();
    llIIIIllIlIIll[11] = 0x3A ^ 0x3D;
    llIIIIllIlIIll[12] = " ".length() << "   ".length();
    llIIIIllIlIIll[13] = ((0x90 ^ 0xA3) << " ".length() ^ 0x19 ^ 0x70) << " ".length();
    llIIIIllIlIIll[14] = (0x2B ^ 0x3C) << "   ".length() ^ 135 + 6 - 62 + 98;
    llIIIIllIlIIll[15] = (0xBD ^ 0xB6) << " ".length() << " ".length();
    llIIIIllIlIIll[16] = (0xA8 ^ 0xAD) << " ".length();
    llIIIIllIlIIll[17] = (0x9B ^ 0x9C) << " ".length();
    llIIIIllIlIIll[18] = 0x3E ^ 0x35;
    llIIIIllIlIIll[19] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllIlIIll[20] = "   ".length() << " ".length() << " ".length();
    llIIIIllIlIIll[21] = 0x16 ^ 0x43 ^ (0xD ^ 0x6) << "   ".length();
    llIIIIllIlIIll[22] = (0x9B ^ 0x8A) << " ".length();
    llIIIIllIlIIll[23] = 0x3B ^ 0x34;
    llIIIIllIlIIll[24] = 0x83 ^ 0x90 ^ (0x5 ^ 0x14) << " ".length();
    llIIIIllIlIIll[25] = 0x9A ^ 0xBD;
    llIIIIllIlIIll[26] = 26 + 7 - -69 + 49 ^ (0x36 ^ 0x75) << " ".length();
    llIIIIllIlIIll[27] = ((0x2E ^ 0x29) << " ".length() ^ 0xB5 ^ 0xB2) << " ".length();
    llIIIIllIlIIll[28] = 0xD6 ^ 0xC3;
    llIIIIllIlIIll[29] = 0x8B ^ 0xB0 ^ (0x91 ^ 0x94) << "   ".length();
    llIIIIllIlIIll[30] = 0x90 ^ 0xB3;
    llIIIIllIlIIll[31] = (0x47 ^ 0x5E) << " ".length();
    llIIIIllIlIIll[32] = (0x21 ^ 0x2A) << " ".length();
    llIIIIllIlIIll[33] = (0x93 ^ 0xA4) << " ".length() << " ".length() ^ 16 + 196 - 117 + 104;
    llIIIIllIlIIll[34] = (0xCA ^ 0x8F) << " ".length() ^ 116 + 39 - 39 + 41;
    llIIIIllIlIIll[35] = "   ".length() << "   ".length();
    llIIIIllIlIIll[36] = 0x8A ^ 0x95;
    llIIIIllIlIIll[37] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x4D ^ 0x64;
    llIIIIllIlIIll[38] = ((0x6B ^ 0x7E) << " ".length() << " ".length() ^ 0xDD ^ 0x84) << " ".length();
    llIIIIllIlIIll[39] = (0x61 ^ 0x64 ^ " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIllIlIIll[40] = 0x5 ^ 0x56 ^ (0x90 ^ 0xB7) << " ".length();
    llIIIIllIlIIll[41] = (0xC7 ^ 0xC0) << " ".length() << " ".length() << " ".length() ^ 0xFE ^ 0xAB;
    llIIIIllIlIIll[42] = 0x18 ^ 0x39;
    llIIIIllIlIIll[43] = " ".length() << (0xC5 ^ 0xC0);
    llIIIIllIlIIll[44] = 60 + 170 - 74 + 15 ^ (0x15 ^ 0x56) << " ".length();
    llIIIIllIlIIll[45] = (0xA1 ^ 0xB4) << " ".length();
    llIIIIllIlIIll[46] = (0xAA ^ 0xA3) << " ".length() << " ".length();
    llIIIIllIlIIll[47] = ((0x78 ^ 0x25) << " ".length() ^ 46 + 108 - 78 + 93) << " ".length();
    llIIIIllIlIIll[48] = (0xF4 ^ 0xB1 ^ " ".length() << "   ".length() << " ".length()) << "   ".length();
    llIIIIllIlIIll[49] = 0x71 ^ 0x58;
    llIIIIllIlIIll[50] = (0x49 ^ 0x16) << " ".length() ^ 84 + 132 - 106 + 39;
    llIIIIllIlIIll[51] = (0x10 ^ 0x15 ^ (0x47 ^ 0x4E) << " ".length()) << " ".length();
    llIIIIllIlIIll[52] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllIlIIll[53] = ((0x12 ^ 0x29) << " ".length() ^ 0x5A ^ 0x21) << " ".length() << " ".length();
    llIIIIllIlIIll[54] = 0x78 ^ 0x57 ^ (0x76 ^ 0x7B) << " ".length();
    llIIIIllIlIIll[55] = (0x33 ^ 0x28) << " ".length();
    llIIIIllIlIIll[56] = 0x5C ^ 0x6B;
    llIIIIllIlIIll[57] = ((0x3 ^ 0x12) << "   ".length() ^ 31 + 22 - 50 + 140) << "   ".length();
    llIIIIllIlIIll[58] = 0x89 ^ 0xB0;
    llIIIIllIlIIll[59] = (0xE ^ 0x13) << " ".length();
  }
  
  private static boolean lIIIIIllIIIlIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIllIIIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllIIIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIllIIIlIIlI(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIllIIIlIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIllIIIlIlll(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIllIIIlIIIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIllIIIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIIllIIIlIIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */