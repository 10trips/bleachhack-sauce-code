package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;

public class f10000000000000000000000000 extends au {
  private boolean slowDown;
  
  private double playerSpeed;
  
  private ao timer;
  
  private double jumpHeight;
  
  private int timerSpeed;
  
  @EventHandler
  private final Listener<f10000000000000> playerMoveEventListener;
  
  private static String[] lIllIlIllllIll;
  
  private static Class[] lIllIlIlllllII;
  
  private static final String[] lIllIlllIIIIIl;
  
  private static String[] lIllIlllIIIlll;
  
  private static final int[] lIllIlllIIlIlI;
  
  public f10000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIIIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIIIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIIIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/stupitdog/bhp/ao
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000000000000000;Lme/stupitdog/bhp/ao;)V
    //   54: aload_0
    //   55: ldc2_w 0.41
    //   58: <illegal opcode> 2 : (Lme/stupitdog/bhp/f10000000000000000000000000;D)V
    //   63: aload_0
    //   64: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   67: iconst_2
    //   68: iaload
    //   69: <illegal opcode> 3 : (Lme/stupitdog/bhp/f10000000000000000000000000;I)V
    //   74: aload_0
    //   75: new me/zero/alpine/listener/Listener
    //   78: dup
    //   79: aload_0
    //   80: <illegal opcode> invoke : (Lme/stupitdog/bhp/f10000000000000000000000000;)Lme/zero/alpine/listener/EventHook;
    //   85: getstatic me/stupitdog/bhp/f10000000000000000000000000.lIllIlllIIlIlI : [I
    //   88: iconst_0
    //   89: iaload
    //   90: anewarray java/util/function/Predicate
    //   93: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   96: putfield playerMoveEventListener : Lme/zero/alpine/listener/Listener;
    //   99: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	100	0	lllllllllllllllIllllIIlIIllllIlI	Lme/stupitdog/bhp/f10000000000000000000000000;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onEnable : ()V
    //   4: aload_0
    //   5: <illegal opcode> 4 : ()D
    //   10: <illegal opcode> 5 : (Lme/stupitdog/bhp/f10000000000000000000000000;D)V
    //   15: <illegal opcode> 6 : ()Lme/zero/alpine/EventManager;
    //   20: aload_0
    //   21: <illegal opcode> 7 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   26: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	27	0	lllllllllllllllIllllIIlIIllllIIl	Lme/stupitdog/bhp/f10000000000000000000000000;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onDisable : ()V
    //   4: aload_0
    //   5: <illegal opcode> 8 : (Lme/stupitdog/bhp/f10000000000000000000000000;)Lme/stupitdog/bhp/ao;
    //   10: <illegal opcode> 9 : (Lme/stupitdog/bhp/ao;)V
    //   15: <illegal opcode> 10 : ()V
    //   20: <illegal opcode> 6 : ()Lme/zero/alpine/EventManager;
    //   25: aload_0
    //   26: <illegal opcode> 11 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   31: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	32	0	lllllllllllllllIllllIIlIIllllIII	Lme/stupitdog/bhp/f10000000000000000000000000;
  }
  
  public static float getDirection() {
    // Byte code:
    //   0: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   15: fstore_0
    //   16: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   31: fconst_0
    //   32: invokestatic llllIlIlllllIIl : (FF)I
    //   35: invokestatic llllIlIlllllIll : (I)Z
    //   38: ifeq -> 46
    //   41: fload_0
    //   42: ldc 180.0
    //   44: fadd
    //   45: fstore_0
    //   46: fconst_1
    //   47: fstore_1
    //   48: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   53: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   58: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   63: fconst_0
    //   64: invokestatic llllIlIlllllIIl : (FF)I
    //   67: invokestatic llllIlIlllllIll : (I)Z
    //   70: ifeq -> 92
    //   73: ldc -0.5
    //   75: fstore_1
    //   76: ldc ''
    //   78: invokevirtual length : ()I
    //   81: pop
    //   82: ldc ' '
    //   84: invokevirtual length : ()I
    //   87: ifge -> 120
    //   90: fconst_0
    //   91: freturn
    //   92: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   97: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   102: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   107: fconst_0
    //   108: invokestatic llllIlIlllllIlI : (FF)I
    //   111: invokestatic llllIlIllllllII : (I)Z
    //   114: ifeq -> 120
    //   117: ldc 0.5
    //   119: fstore_1
    //   120: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   125: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   130: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   135: fconst_0
    //   136: invokestatic llllIlIlllllIlI : (FF)I
    //   139: invokestatic llllIlIllllllII : (I)Z
    //   142: ifeq -> 152
    //   145: fload_0
    //   146: ldc 90.0
    //   148: fload_1
    //   149: fmul
    //   150: fsub
    //   151: fstore_0
    //   152: <illegal opcode> 12 : ()Lnet/minecraft/client/Minecraft;
    //   157: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   162: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   167: fconst_0
    //   168: invokestatic llllIlIlllllIIl : (FF)I
    //   171: invokestatic llllIlIlllllIll : (I)Z
    //   174: ifeq -> 184
    //   177: fload_0
    //   178: ldc 90.0
    //   180: fload_1
    //   181: fmul
    //   182: fadd
    //   183: fstore_0
    //   184: fload_0
    //   185: ldc 0.017453292
    //   187: fmul
    //   188: fstore_0
    //   189: fload_0
    //   190: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   16	175	0	lllllllllllllllIllllIIlIIlllIlll	F
    //   48	143	1	lllllllllllllllIllllIIlIIlllIllI	F
  }
  
  static {
    llllIlIlllllIII();
    llllIlIllllIlll();
    llllIlIllllIllI();
    llllIlIlllIllll();
  }
  
  private static CallSite llllIlIIIlllIll(MethodHandles.Lookup lllllllllllllllIllllIIlIIllIlIIl, String lllllllllllllllIllllIIlIIllIlIII, MethodType lllllllllllllllIllllIIlIIllIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIlIIllIllll = lIllIlIllllIll[Integer.parseInt(lllllllllllllllIllllIIlIIllIlIII)].split(lIllIlllIIIIIl[lIllIlllIIlIlI[3]]);
      Class<?> lllllllllllllllIllllIIlIIllIlllI = Class.forName(lllllllllllllllIllllIIlIIllIllll[lIllIlllIIlIlI[0]]);
      String lllllllllllllllIllllIIlIIllIllIl = lllllllllllllllIllllIIlIIllIllll[lIllIlllIIlIlI[1]];
      MethodHandle lllllllllllllllIllllIIlIIllIllII = null;
      int lllllllllllllllIllllIIlIIllIlIll = lllllllllllllllIllllIIlIIllIllll[lIllIlllIIlIlI[3]].length();
      if (llllIlIllllllll(lllllllllllllllIllllIIlIIllIlIll, lIllIlllIIlIlI[2])) {
        MethodType lllllllllllllllIllllIIlIIlllIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIlIIllIllll[lIllIlllIIlIlI[2]], f10000000000000000000000000.class.getClassLoader());
        if (llllIllIIIIIIII(lllllllllllllllIllllIIlIIllIlIll, lIllIlllIIlIlI[2])) {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findVirtual(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIIl);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findStatic(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIIl);
        } 
        "".length();
        if (" ".length() == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIlIIlllIIII = lIllIlIlllllII[Integer.parseInt(lllllllllllllllIllllIIlIIllIllll[lIllIlllIIlIlI[2]])];
        if (llllIllIIIIIIII(lllllllllllllllIllllIIlIIllIlIll, lIllIlllIIlIlI[3])) {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findGetter(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < -" ".length())
            return null; 
        } else if (llllIllIIIIIIII(lllllllllllllllIllllIIlIIllIlIll, lIllIlllIIlIlI[4])) {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findStaticGetter(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIII);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else if (llllIllIIIIIIII(lllllllllllllllIllllIIlIIllIlIll, lIllIlllIIlIlI[5])) {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findSetter(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIII);
          "".length();
          if (" ".length() << " ".length() <= " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIlIIllIllII = lllllllllllllllIllllIIlIIllIlIIl.findStaticSetter(lllllllllllllllIllllIIlIIllIlllI, lllllllllllllllIllllIIlIIllIllIl, lllllllllllllllIllllIIlIIlllIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIlIIllIllII);
    } catch (Exception lllllllllllllllIllllIIlIIllIlIlI) {
      lllllllllllllllIllllIIlIIllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIlllIllll() {
    lIllIlIllllIll = new String[lIllIlllIIlIlI[6]];
    lIllIlIllllIll[lIllIlllIIlIlI[7]] = lIllIlllIIIIIl[lIllIlllIIlIlI[4]];
    lIllIlIllllIll[lIllIlllIIlIlI[8]] = lIllIlllIIIIIl[lIllIlllIIlIlI[5]];
    lIllIlIllllIll[lIllIlllIIlIlI[9]] = lIllIlllIIIIIl[lIllIlllIIlIlI[10]];
    lIllIlIllllIll[lIllIlllIIlIlI[1]] = lIllIlllIIIIIl[lIllIlllIIlIlI[11]];
    lIllIlIllllIll[lIllIlllIIlIlI[12]] = lIllIlllIIIIIl[lIllIlllIIlIlI[13]];
    lIllIlIllllIll[lIllIlllIIlIlI[14]] = lIllIlllIIIIIl[lIllIlllIIlIlI[15]];
    lIllIlIllllIll[lIllIlllIIlIlI[16]] = lIllIlllIIIIIl[lIllIlllIIlIlI[7]];
    lIllIlIllllIll[lIllIlllIIlIlI[17]] = lIllIlllIIIIIl[lIllIlllIIlIlI[9]];
    lIllIlIllllIll[lIllIlllIIlIlI[18]] = lIllIlllIIIIIl[lIllIlllIIlIlI[19]];
    lIllIlIllllIll[lIllIlllIIlIlI[20]] = lIllIlllIIIIIl[lIllIlllIIlIlI[21]];
    lIllIlIllllIll[lIllIlllIIlIlI[22]] = lIllIlllIIIIIl[lIllIlllIIlIlI[14]];
    lIllIlIllllIll[lIllIlllIIlIlI[23]] = lIllIlllIIIIIl[lIllIlllIIlIlI[23]];
    lIllIlIllllIll[lIllIlllIIlIlI[24]] = lIllIlllIIIIIl[lIllIlllIIlIlI[25]];
    lIllIlIllllIll[lIllIlllIIlIlI[26]] = lIllIlllIIIIIl[lIllIlllIIlIlI[27]];
    lIllIlIllllIll[lIllIlllIIlIlI[3]] = lIllIlllIIIIIl[lIllIlllIIlIlI[16]];
    lIllIlIllllIll[lIllIlllIIlIlI[25]] = lIllIlllIIIIIl[lIllIlllIIlIlI[18]];
    lIllIlIllllIll[lIllIlllIIlIlI[28]] = lIllIlllIIIIIl[lIllIlllIIlIlI[28]];
    lIllIlIllllIll[lIllIlllIIlIlI[10]] = lIllIlllIIIIIl[lIllIlllIIlIlI[29]];
    lIllIlIllllIll[lIllIlllIIlIlI[30]] = lIllIlllIIIIIl[lIllIlllIIlIlI[31]];
    lIllIlIllllIll[lIllIlllIIlIlI[11]] = lIllIlllIIIIIl[lIllIlllIIlIlI[32]];
    lIllIlIllllIll[lIllIlllIIlIlI[33]] = lIllIlllIIIIIl[lIllIlllIIlIlI[24]];
    lIllIlIllllIll[lIllIlllIIlIlI[34]] = lIllIlllIIIIIl[lIllIlllIIlIlI[12]];
    lIllIlIllllIll[lIllIlllIIlIlI[35]] = lIllIlllIIIIIl[lIllIlllIIlIlI[8]];
    lIllIlIllllIll[lIllIlllIIlIlI[0]] = lIllIlllIIIIIl[lIllIlllIIlIlI[36]];
    lIllIlIllllIll[lIllIlllIIlIlI[36]] = lIllIlllIIIIIl[lIllIlllIIlIlI[37]];
    lIllIlIllllIll[lIllIlllIIlIlI[27]] = lIllIlllIIIIIl[lIllIlllIIlIlI[34]];
    lIllIlIllllIll[lIllIlllIIlIlI[19]] = lIllIlllIIIIIl[lIllIlllIIlIlI[17]];
    lIllIlIllllIll[lIllIlllIIlIlI[38]] = lIllIlllIIIIIl[lIllIlllIIlIlI[22]];
    lIllIlIllllIll[lIllIlllIIlIlI[37]] = lIllIlllIIIIIl[lIllIlllIIlIlI[26]];
    lIllIlIllllIll[lIllIlllIIlIlI[29]] = lIllIlllIIIIIl[lIllIlllIIlIlI[39]];
    lIllIlIllllIll[lIllIlllIIlIlI[5]] = lIllIlllIIIIIl[lIllIlllIIlIlI[35]];
    lIllIlIllllIll[lIllIlllIIlIlI[31]] = lIllIlllIIIIIl[lIllIlllIIlIlI[20]];
    lIllIlIllllIll[lIllIlllIIlIlI[15]] = lIllIlllIIIIIl[lIllIlllIIlIlI[33]];
    lIllIlIllllIll[lIllIlllIIlIlI[2]] = lIllIlllIIIIIl[lIllIlllIIlIlI[40]];
    lIllIlIllllIll[lIllIlllIIlIlI[41]] = lIllIlllIIIIIl[lIllIlllIIlIlI[41]];
    lIllIlIllllIll[lIllIlllIIlIlI[32]] = lIllIlllIIIIIl[lIllIlllIIlIlI[30]];
    lIllIlIllllIll[lIllIlllIIlIlI[13]] = lIllIlllIIIIIl[lIllIlllIIlIlI[38]];
    lIllIlIllllIll[lIllIlllIIlIlI[21]] = lIllIlllIIIIIl[lIllIlllIIlIlI[42]];
    lIllIlIllllIll[lIllIlllIIlIlI[39]] = lIllIlllIIIIIl[lIllIlllIIlIlI[6]];
    lIllIlIllllIll[lIllIlllIIlIlI[42]] = lIllIlllIIIIIl[lIllIlllIIlIlI[43]];
    lIllIlIllllIll[lIllIlllIIlIlI[4]] = lIllIlllIIIIIl[lIllIlllIIlIlI[44]];
    lIllIlIllllIll[lIllIlllIIlIlI[40]] = lIllIlllIIIIIl[lIllIlllIIlIlI[45]];
    lIllIlIlllllII = new Class[lIllIlllIIlIlI[9]];
    lIllIlIlllllII[lIllIlllIIlIlI[4]] = Listener.class;
    lIllIlIlllllII[lIllIlllIIlIlI[2]] = double.class;
    lIllIlIlllllII[lIllIlllIIlIlI[5]] = EventManager.class;
    lIllIlIlllllII[lIllIlllIIlIlI[13]] = float.class;
    lIllIlIlllllII[lIllIlllIIlIlI[15]] = boolean.class;
    lIllIlIlllllII[lIllIlllIIlIlI[7]] = Potion.class;
    lIllIlIlllllII[lIllIlllIIlIlI[3]] = int.class;
    lIllIlIlllllII[lIllIlllIIlIlI[10]] = Minecraft.class;
    lIllIlIlllllII[lIllIlllIIlIlI[0]] = f13.class;
    lIllIlIlllllII[lIllIlllIIlIlI[1]] = ao.class;
    lIllIlIlllllII[lIllIlllIIlIlI[11]] = EntityPlayerSP.class;
  }
  
  private static void llllIlIllllIllI() {
    lIllIlllIIIIIl = new String[lIllIlllIIlIlI[46]];
    lIllIlllIIIIIl[lIllIlllIIlIlI[0]] = llllIlIllllIIII(lIllIlllIIIlll[lIllIlllIIlIlI[0]], lIllIlllIIIlll[lIllIlllIIlIlI[1]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[1]] = llllIlIllllIIIl(lIllIlllIIIlll[lIllIlllIIlIlI[2]], lIllIlllIIIlll[lIllIlllIIlIlI[3]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[2]] = llllIlIllllIIII(lIllIlllIIIlll[lIllIlllIIlIlI[4]], lIllIlllIIIlll[lIllIlllIIlIlI[5]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[3]] = llllIlIllllIIII(lIllIlllIIIlll[lIllIlllIIlIlI[10]], lIllIlllIIIlll[lIllIlllIIlIlI[11]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[4]] = llllIlIllllIIII(lIllIlllIIIlll[lIllIlllIIlIlI[13]], lIllIlllIIIlll[lIllIlllIIlIlI[15]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[5]] = llllIlIllllIIlI(lIllIlllIIIlll[lIllIlllIIlIlI[7]], lIllIlllIIIlll[lIllIlllIIlIlI[9]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[10]] = llllIlIllllIIlI(lIllIlllIIIlll[lIllIlllIIlIlI[19]], lIllIlllIIIlll[lIllIlllIIlIlI[21]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[11]] = llllIlIllllIIlI(lIllIlllIIIlll[lIllIlllIIlIlI[14]], lIllIlllIIIlll[lIllIlllIIlIlI[23]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[13]] = llllIlIllllIIlI(lIllIlllIIIlll[lIllIlllIIlIlI[25]], lIllIlllIIIlll[lIllIlllIIlIlI[27]]);
    lIllIlllIIIIIl[lIllIlllIIlIlI[15]] = llllIlIllllIIII("PRY5eig6HSg3NzIVOXomPxooOjF9FiMgLCcKYxErJxo5LRU/EjQxNwAjdzIsNh8pC3JjQnpjGilJdW5lc1M=", "SsMTE");
    lIllIlllIIIIIl[lIllIlllIIlIlI[7]] = llllIlIllllIIII("CQA7SxcOCyoGCAYDO0sZCwwqCw5JACERExMcYSAUEww7HCoLBDYACDQ1dQMPCQYQUkpXXH86Ml1NZj9AR0U=", "geOez");
    lIllIlllIIIIIl[lIllIlllIIlIlI[9]] = llllIlIllllIIlI("IlGntBg4N4Tocp12Cc8eN5IpkwH4RJUwV0YDkrBuJ9VMiTeGBhUHFzLwDxN0mCf7ecuHG3oVckQ=", "CSfwO");
    lIllIlllIIIIIl[lIllIlllIIlIlI[19]] = llllIlIllllIIII("GyIERwgcKRUKFxQhBEcGGS4VBxFbIh4dDAE+XiwLAS4EEDUZJgkMFyYXSg8QGyQvXlVDdkc2Ayp9WEA/T2dQ", "uGpie");
    lIllIlllIIIIIl[lIllIlllIIlIlI[21]] = llllIlIllllIIlI("qufXjOey0b6jmIJJC3IhgYRm3NPZJtnsuOBrxj4wIaq44GvGPjAhqpIoNOhFnqiU/Sf4D+yc7E2CUqkWnlQDcA==", "RUjaU");
    lIllIlllIIIIIl[lIllIlllIIlIlI[14]] = llllIlIllllIIlI("kUdbdn15eQebbmfghzbSgz/qNifN99p5VrsJ7PdSyMYxVw0hIMSTuzMoD42QpjBN", "BRoyU");
    lIllIlllIIIIIl[lIllIlllIIlIlI[23]] = llllIlIllllIIIl("8Zx6AmF0pKpWLiwBdcCat2MR4xBT8ZGGcEtMPKV6FKsNBnM/OH0Vp+zPr9VWhUCFMIsn+P1ga8dI3LfdUXCPgxFjWN14MEtw", "Ajjle");
    lIllIlllIIIIIl[lIllIlllIIlIlI[25]] = llllIlIllllIIII("OAZdNRcgExoyBzoEXSQLJU0SKVk9AgAUBjQAGyMHb0s5bzlvQ1M=", "UcsFc");
    lIllIlllIIIIIl[lIllIlllIIlIlI[27]] = llllIlIllllIIIl("pCXaricy71EwjiKQeGXMkUX+IsOZCK2bn4DHV2mAcC2nLOIpA/WVC/CtHcT4/GRkjWPbpq871V8lc/RO4lYx11YNp/uLKW8g", "LkWAY");
    lIllIlllIIIIIl[lIllIlllIIlIlI[16]] = llllIlIllllIIII("FBZNKT0MAwouLRYUTTghCV0Fa3lJQ1NqeUlDU2p5SUNTanlJQ1NqeUlDU2pzDRoOPzsqAwY/LUNAWXppWVND", "yscZI");
    lIllIlllIIIIIl[lIllIlllIIlIlI[18]] = llllIlIllllIIIl("gYthk8bSmEcUHKxxHgzBgX3mCHiMzhvU/WAWlGnL+i6aYoDgBcobBCjk3Q//zZ9IDJUhR1aX7lo279Y/buyyIA==", "VmADw");
    lIllIlllIIIIIl[lIllIlllIIlIlI[28]] = llllIlIllllIIII("PQg8Wgs6Ay0XFDILPFoFPwQtGhJ9CCYADycUZjEIJwQ8DTY/DDERFAA9chIPNgEsK1FjXHtAORlXcU5Gc00=", "SmHtf");
    lIllIlllIIIIIl[lIllIlllIIlIlI[29]] = llllIlIllllIIIl("lrjX8F3gkZXXgd47XJ9FmmbbQkwClgPmE+8CnvGpXwz7zGdQ12CvOA==", "sAeQS");
    lIllIlllIIIIIl[lIllIlllIIlIlI[31]] = llllIlIllllIIIl("zDOuFxdKE/CtFpP7GWs3g6iZwPFJ731UeQyZa5PTHry1QQT8ZYo/eA==", "qhsTY");
    lIllIlllIIIIIl[lIllIlllIIlIlI[32]] = llllIlIllllIIIl("DoKhG4PVWz/TZmh+1iiBLw8QMNpFKqjDpmNH12cVikkWv6Zv7fmiCeMX/1Kyf6/hnmd9wnu9Q2Laa+KK0RxjLw==", "omqFX");
    lIllIlllIIIIIl[lIllIlllIIlIlI[24]] = llllIlIllllIIII("IQAwYwUmCyEuGi4DMGMLIwwhIxxhACo5ATscaggGOwwwNDgjBD0oGhw1fisBKgkgEl9/VHZ+NwlffXdIb0U=", "OeDMh");
    lIllIlllIIIIIl[lIllIlllIIlIlI[12]] = llllIlIllllIIlI("ZMaYdQJ8zzQBUatPffdsdmWN8GivGblUOTfs5GebAJgX6lAmSgbqMVz4XpheImkBWGTz7EizCcT3Ut08qwW5RB0AAjYmMP/8Vq/wt4z57gR278U1fbox05zB5F6VPp2R30afRzKyRTa0WLhvAmEZbOOfiU6wyKcFXnOca3vTWJM=", "RpkYz");
    lIllIlllIIIIIl[lIllIlllIIlIlI[8]] = llllIlIllllIIII("Gjd0JgYCIjMhFhg1dDcaB3w8ZEJHYmplQkdiamVCR2JqZUJHYmplQkdiamVIBD41IjYYJTRvS01yenVSVw==", "wRZUr");
    lIllIlllIIIIIl[lIllIlllIIlIlI[36]] = llllIlIllllIIII("CzxnBzwTKSAALAk+ZxYgFncvRXtcFAYiDSscByByVmNpVGhG", "fYItH");
    lIllIlllIIIIIl[lIllIlllIIlIlI[37]] = llllIlIllllIIIl("KWo5JGcwXwNuuXdrtELjozgTGKwN7LEixRGj6zor7hbnxLhbB6bnyYX1A0hUjH92F47T/Y1WJc4=", "pjcYC");
    lIllIlllIIIIIl[lIllIlllIIlIlI[34]] = llllIlIllllIIlI("TTg2ZiWUmEdFNpPIn68L9xww4qpuZbQZ1pdSxZSVA9EQj7ibhTLxdz8maT+UdUf5HbWa3JAL0kzchgnU9U7TuaW/OuvgRzob", "hZEiF");
    lIllIlllIIIIIl[lIllIlllIIlIlI[17]] = llllIlIllllIIII("HChNHToEPQoaKh4qTQwmAWMFX35BfVNefkF9U15+QX1TXn5BfVNefkF9U150HC5ZWHRRbUNO", "qMcnN");
    lIllIlllIIIIIl[lIllIlllIIlIlI[22]] = llllIlIllllIIII("JgF/Hgw+FDgZHCQDfw8QO0o3XEh7VGFdSHtUYV1Ie1RrHh0/PGtFPGIya01Y", "KdQmx");
    lIllIlllIIIIIl[lIllIlllIIlIlI[26]] = llllIlIllllIIlI("VGSQE9GSKQ3P4cCWlMMuJ+ag+VvsK9PeUMOids75s6z+6o1Ke4Tr6yyKiAwaU4cHPUrFhkTA6l3ajL5/CaP2cTB0vluKwENqXcXvo/oxxBqFr3ravGM8DpXDudZ7OOMp", "XMGxb");
    lIllIlllIIIIIl[lIllIlllIIlIlI[39]] = llllIlIllllIIlI("bci9JD1BVIyTVY+t9SJKBVb38MwzZodsOTrAUp/ZBk05OsBSn9kGTa7Y2O70LHEvZ6B2Y2GGG4r4IpjWycQ0rA==", "uBxDB");
    lIllIlllIIIIIl[lIllIlllIIlIlI[35]] = llllIlIllllIIII("NxZoMjkvAy81KTUUaCMlKl0gcH1qQ3ZxfWpDdnF9akN2cX1qQ3ZxfWpDdnF3Kh8nOCgoIDYkKD5JdHttelNmYQ==", "ZsFAM");
    lIllIlllIIIIIl[lIllIlllIIlIlI[20]] = llllIlIllllIIIl("6ju/NCjSc9HaogERD1wzWLrSL2CWY3o3M8mEvgWQPz7SffzAaXIrwUdUO0IBhbxrbzUUmT9DTmFtEFaiOCU55A==", "nmmOH");
    lIllIlllIIIIIl[lIllIlllIIlIlI[33]] = llllIlIllllIIII("FCtpKgAMPi4tEBYpaTscCWAmNk4LKzQ8AENmbg9OWW4=", "yNGYt");
    lIllIlllIIIIIl[lIllIlllIIlIlI[40]] = llllIlIllllIIIl("TcQimKrNtnzVivqTH9xbMf9lvhEJ98od92+F/rrtl+z3b4X+uu2X7K+M+cpzu4/i3/Kwt1bENOInnUkGBZy9dQ==", "fhKgQ");
    lIllIlllIIIIIl[lIllIlllIIlIlI[41]] = llllIlIllllIIIl("YbLpEN5VbOveHaWihluN2t35/ZtLhSv/M04OgTI0vHE=", "qXVQw");
    lIllIlllIIIIIl[lIllIlllIIlIlI[30]] = llllIlIllllIIII("HgpYITsGHx8mKxwIWDAnA0EQI3UaHDs9ORoBEWhnPwETJmAeBhg3LAEOECZgFgECOzsKQDM8OxobDx4mBQYYNQ0SHBNpZilVVg==", "sovRO");
    lIllIlllIIIIIl[lIllIlllIIlIlI[38]] = llllIlIllllIIII("NAdhPBEsEiY7ATYFYS0NKUwpflVpUn9/VWlSf39VaVJ/f1VpUn9/VWlSf39fLQsiKhdjU3VvRXk=", "YbOOe");
    lIllIlllIIIIIl[lIllIlllIIlIlI[42]] = llllIlIllllIIlI("E+Tp0ZXZJ1+6irZWcd8tm0HHQVqbEYxK9HlloMVkF5YjwAdqeP9iOAv60aQzHQLmxFEwu7aFkP8=", "FMjVD");
    lIllIlllIIIIIl[lIllIlllIIlIlI[6]] = llllIlIllllIIlI("+I1+q+xWbaHcInjVusZYNUNCpUTP/YhmJwqD6kq/pRvapJ9FT3b5vA==", "WhPkM");
    lIllIlllIIIIIl[lIllIlllIIlIlI[43]] = llllIlIllllIIlI("Xpot0/b3HaH8jmRyNMNX3TQ2xdz/cbPHYUffHpQ7vH0vicFem1aKdBPpFYpuUgH+", "UbQHM");
    lIllIlllIIIIIl[lIllIlllIIlIlI[44]] = llllIlIllllIIII("LCNYGzk0Nh8cKS4hWAolMWgQGXcmIwIqLDIjOwc7JBUGDSglfF5BCXtm", "AFvhM");
    lIllIlllIIIIIl[lIllIlllIIlIlI[45]] = llllIlIllllIIlI("2N1tvEsEwQ6nPm2S5mD6hDKZ3oey0FXi8xacF+kZBcrzFpwX6RkFyjJOhgc091qQns+4NlrwTZt7aL1lZfaPEw==", "ZDwJE");
    lIllIlllIIIlll = null;
  }
  
  private static void llllIlIllllIlll() {
    String str = (new Exception()).getStackTrace()[lIllIlllIIlIlI[0]].getFileName();
    lIllIlllIIIlll = str.substring(str.indexOf("ä") + lIllIlllIIlIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIllllIIII(String lllllllllllllllIllllIIlIIllIIlIl, String lllllllllllllllIllllIIlIIllIIlII) {
    lllllllllllllllIllllIIlIIllIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIlIIllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIlIIllIIIll = new StringBuilder();
    char[] lllllllllllllllIllllIIlIIllIIIlI = lllllllllllllllIllllIIlIIllIIlII.toCharArray();
    int lllllllllllllllIllllIIlIIllIIIIl = lIllIlllIIlIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIlIIllIIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlllIIlIlI[0];
    while (llllIllIIIIIIIl(j, i)) {
      char lllllllllllllllIllllIIlIIllIIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIlIIllIIIIl++;
      j++;
      "".length();
      if (" ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIlIIllIIIll);
  }
  
  private static String llllIlIllllIIIl(String lllllllllllllllIllllIIlIIlIlllIl, String lllllllllllllllIllllIIlIIlIlllII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlIIllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlIIlIlllII.getBytes(StandardCharsets.UTF_8)), lIllIlllIIlIlI[13]), "DES");
      Cipher lllllllllllllllIllllIIlIIlIlllll = Cipher.getInstance("DES");
      lllllllllllllllIllllIIlIIlIlllll.init(lIllIlllIIlIlI[2], lllllllllllllllIllllIIlIIllIIIII);
      return new String(lllllllllllllllIllllIIlIIlIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlIIlIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlIIlIllllI) {
      lllllllllllllllIllllIIlIIlIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIllllIIlI(String lllllllllllllllIllllIIlIIlIllIII, String lllllllllllllllIllllIIlIIlIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlIIlIllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlIIlIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIlIIlIllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIlIIlIllIlI.init(lIllIlllIIlIlI[2], lllllllllllllllIllllIIlIIlIllIll);
      return new String(lllllllllllllllIllllIIlIIlIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlIIlIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlIIlIllIIl) {
      lllllllllllllllIllllIIlIIlIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIlllllIII() {
    lIllIlllIIlIlI = new int[47];
    lIllIlllIIlIlI[0] = " ".length() << (146 + 95 - 210 + 160 ^ (0x3B ^ 0x66) << " ".length()) & (" ".length() << (0xED ^ 0xB8 ^ (0xA6 ^ 0xA3) << " ".length() << " ".length() << " ".length()) ^ -" ".length());
    lIllIlllIIlIlI[1] = " ".length();
    lIllIlllIIlIlI[2] = " ".length() << " ".length();
    lIllIlllIIlIlI[3] = "   ".length();
    lIllIlllIIlIlI[4] = " ".length() << " ".length() << " ".length();
    lIllIlllIIlIlI[5] = (0xA0 ^ 0x8D) << " ".length() ^ 0x5F ^ 0x0;
    lIllIlllIIlIlI[6] = (0x75 ^ 0x60) << " ".length();
    lIllIlllIIlIlI[7] = ((0x19 ^ 0x44) << " ".length() ^ 142 + 49 - 57 + 57) << " ".length();
    lIllIlllIIlIlI[8] = (0x4A ^ 0x47) << " ".length();
    lIllIlllIIlIlI[9] = 0x84 ^ 0x8F;
    lIllIlllIIlIlI[10] = "   ".length() << " ".length();
    lIllIlllIIlIlI[11] = 0x68 ^ 0x23 ^ (0x5E ^ 0x4D) << " ".length() << " ".length();
    lIllIlllIIlIlI[12] = "   ".length() << "   ".length() ^ " ".length();
    lIllIlllIIlIlI[13] = " ".length() << "   ".length();
    lIllIlllIIlIlI[14] = (0x90 ^ 0x97) << " ".length();
    lIllIlllIIlIlI[15] = (0x7D ^ 0x52) << " ".length() ^ 0xC6 ^ 0x91;
    lIllIlllIIlIlI[16] = (0x31 ^ 0x38) << " ".length();
    lIllIlllIIlIlI[17] = (0x2D ^ 0x22) << " ".length();
    lIllIlllIIlIlI[18] = 0x71 ^ 0x62;
    lIllIlllIIlIlI[19] = "   ".length() << " ".length() << " ".length();
    lIllIlllIIlIlI[20] = 0x6F ^ 0x4C;
    lIllIlllIIlIlI[21] = 0x30 ^ 0x3D;
    lIllIlllIIlIlI[22] = 0xD ^ 0x2E ^ (0xC9 ^ 0xC6) << " ".length() << " ".length();
    lIllIlllIIlIlI[23] = 0x9E ^ 0x91;
    lIllIlllIIlIlI[24] = "   ".length() << "   ".length();
    lIllIlllIIlIlI[25] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIlllIIlIlI[26] = " ".length() << (40 + 35 - 53 + 125 ^ (0x76 ^ 0x3D) << " ".length());
    lIllIlllIIlIlI[27] = 0x51 ^ 0x40;
    lIllIlllIIlIlI[28] = ((0x38 ^ 0x23) << " ".length() ^ 0x38 ^ 0xB) << " ".length() << " ".length();
    lIllIlllIIlIlI[29] = 0x46 ^ 0x53;
    lIllIlllIIlIlI[30] = 0x65 ^ 0x42;
    lIllIlllIIlIlI[31] = (0xB6 ^ 0xBD) << " ".length();
    lIllIlllIIlIlI[32] = " ".length() << (0x5F ^ 0x58) ^ 55 + 13 - -37 + 46;
    lIllIlllIIlIlI[33] = (0xA2 ^ 0xB3 ^ "   ".length() << "   ".length()) << " ".length() << " ".length();
    lIllIlllIIlIlI[34] = 0x97 ^ 0x8A;
    lIllIlllIIlIlI[35] = (0x11 ^ 0x0) << " ".length();
    lIllIlllIIlIlI[36] = 0xD ^ 0x16;
    lIllIlllIIlIlI[37] = (0x2B ^ 0x2C) << " ".length() << " ".length();
    lIllIlllIIlIlI[38] = (0x86 ^ 0x83) << "   ".length();
    lIllIlllIIlIlI[39] = 0x2A ^ 0x3F ^ (0x1E ^ 0x13) << " ".length() << " ".length();
    lIllIlllIIlIlI[40] = (0x28 ^ 0x1B) << " ".length() ^ 0x21 ^ 0x62;
    lIllIlllIIlIlI[41] = (0x8E ^ 0x9D) << " ".length();
    lIllIlllIIlIlI[42] = (0x9C ^ 0x81) << " ".length() ^ 0x8C ^ 0x9F;
    lIllIlllIIlIlI[43] = " ".length() << " ".length() << " ".length() ^ 0x76 ^ 0x59;
    lIllIlllIIlIlI[44] = (0xCB ^ 0xC0) << " ".length() << " ".length();
    lIllIlllIIlIlI[45] = 0x28 ^ 0x5;
    lIllIlllIIlIlI[46] = ((0x2 ^ 0x23) << " ".length() << " ".length() ^ 139 + 6 - 78 + 80) << " ".length();
  }
  
  private static boolean llllIllIIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIllIIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIllllllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIlllllllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllIlIllllllIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean llllIlIlllllIll(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean llllIlIllllllII(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int llllIlIlllllIlI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int llllIlIlllllIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */