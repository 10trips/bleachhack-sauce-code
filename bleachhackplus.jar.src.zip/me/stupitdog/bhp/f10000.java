package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;

public class f10000 extends au {
  private static String[] lIllIlllllIlIl;
  
  private static Class[] lIllIlllllIllI;
  
  private static final String[] lIllIllllllllI;
  
  private static String[] lIllIlllllllll;
  
  private static final int[] lIlllIIIIIIIII;
  
  public f10000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f10000.lIllIllllllllI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f10000.lIlllIIIIIIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f10000.lIllIllllllllI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f10000.lIlllIIIIIIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f10000.lIllIllllllllI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f10000.lIlllIIIIIIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f10000.lIlllIIIIIIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllllIIIIllIIIIII	Lme/stupitdog/bhp/f10000;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   15: fconst_2
    //   16: invokestatic llllIllIlllllll : (FF)I
    //   19: invokestatic llllIlllIIIIIII : (I)Z
    //   22: ifeq -> 57
    //   25: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   30: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   35: <illegal opcode> 4 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   40: new net/minecraft/network/play/client/CPacketPlayer
    //   43: dup
    //   44: getstatic me/stupitdog/bhp/f10000.lIlllIIIIIIIII : [I
    //   47: iconst_1
    //   48: iaload
    //   49: invokespecial <init> : (Z)V
    //   52: <illegal opcode> 5 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   57: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	58	0	lllllllllllllllIllllIIIIlIllllll	Lme/stupitdog/bhp/f10000;
  }
  
  static {
    llllIllIllllllI();
    llllIllIlllllIl();
    llllIllIlllllII();
    llllIllIllllIII();
  }
  
  private static CallSite llllIllIllIlIIl(MethodHandles.Lookup lllllllllllllllIllllIIIIlIllIllI, String lllllllllllllllIllllIIIIlIllIlIl, MethodType lllllllllllllllIllllIIIIlIllIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIIIlIllllII = lIllIlllllIlIl[Integer.parseInt(lllllllllllllllIllllIIIIlIllIlIl)].split(lIllIllllllllI[lIlllIIIIIIIII[3]]);
      Class<?> lllllllllllllllIllllIIIIlIlllIll = Class.forName(lllllllllllllllIllllIIIIlIllllII[lIlllIIIIIIIII[0]]);
      String lllllllllllllllIllllIIIIlIlllIlI = lllllllllllllllIllllIIIIlIllllII[lIlllIIIIIIIII[1]];
      MethodHandle lllllllllllllllIllllIIIIlIlllIIl = null;
      int lllllllllllllllIllllIIIIlIlllIII = lllllllllllllllIllllIIIIlIllllII[lIlllIIIIIIIII[3]].length();
      if (llllIlllIIIIIIl(lllllllllllllllIllllIIIIlIlllIII, lIlllIIIIIIIII[2])) {
        MethodType lllllllllllllllIllllIIIIlIlllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIIIlIllllII[lIlllIIIIIIIII[2]], f10000.class.getClassLoader());
        if (llllIlllIIIIIlI(lllllllllllllllIllllIIIIlIlllIII, lIlllIIIIIIIII[2])) {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findVirtual(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIlllllI);
          "".length();
          if (((0x72 ^ 0x29 ^ (0x20 ^ 0x2F) << "   ".length()) & ((0x6F ^ 0x38) << " ".length() ^ 75 + 108 - 96 + 54 ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findStatic(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIlllllI);
        } 
        "".length();
        if (-" ".length() >= " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIIIlIllllIl = lIllIlllllIllI[Integer.parseInt(lllllllllllllllIllllIIIIlIllllII[lIlllIIIIIIIII[2]])];
        if (llllIlllIIIIIlI(lllllllllllllllIllllIIIIlIlllIII, lIlllIIIIIIIII[3])) {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findGetter(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIllllIl);
          "".length();
          if ((0x43 ^ 0x7A ^ (0xBB ^ 0xB4) << " ".length() << " ".length()) == 0)
            return null; 
        } else if (llllIlllIIIIIlI(lllllllllllllllIllllIIIIlIlllIII, lIlllIIIIIIIII[4])) {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findStaticGetter(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIllllIl);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else if (llllIlllIIIIIlI(lllllllllllllllIllllIIIIlIlllIII, lIlllIIIIIIIII[5])) {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findSetter(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIllllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllllIIIIlIlllIIl = lllllllllllllllIllllIIIIlIllIllI.findStaticSetter(lllllllllllllllIllllIIIIlIlllIll, lllllllllllllllIllllIIIIlIlllIlI, lllllllllllllllIllllIIIIlIllllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIIIlIlllIIl);
    } catch (Exception lllllllllllllllIllllIIIIlIllIlll) {
      lllllllllllllllIllllIIIIlIllIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIllllIII() {
    lIllIlllllIlIl = new String[lIlllIIIIIIIII[6]];
    lIllIlllllIlIl[lIlllIIIIIIIII[3]] = lIllIllllllllI[lIlllIIIIIIIII[4]];
    lIllIlllllIlIl[lIlllIIIIIIIII[0]] = lIllIllllllllI[lIlllIIIIIIIII[5]];
    lIllIlllllIlIl[lIlllIIIIIIIII[2]] = lIllIllllllllI[lIlllIIIIIIIII[6]];
    lIllIlllllIlIl[lIlllIIIIIIIII[1]] = lIllIllllllllI[lIlllIIIIIIIII[7]];
    lIllIlllllIlIl[lIlllIIIIIIIII[5]] = lIllIllllllllI[lIlllIIIIIIIII[8]];
    lIllIlllllIlIl[lIlllIIIIIIIII[4]] = lIllIllllllllI[lIlllIIIIIIIII[9]];
    lIllIlllllIllI = new Class[lIlllIIIIIIIII[5]];
    lIllIlllllIllI[lIlllIIIIIIIII[4]] = NetHandlerPlayClient.class;
    lIllIlllllIllI[lIlllIIIIIIIII[1]] = Minecraft.class;
    lIllIlllllIllI[lIlllIIIIIIIII[0]] = f13.class;
    lIllIlllllIllI[lIlllIIIIIIIII[2]] = EntityPlayerSP.class;
    lIllIlllllIllI[lIlllIIIIIIIII[3]] = float.class;
  }
  
  private static void llllIllIlllllII() {
    lIllIllllllllI = new String[lIlllIIIIIIIII[10]];
    lIllIllllllllI[lIlllIIIIIIIII[0]] = llllIllIllllIIl(lIllIlllllllll[lIlllIIIIIIIII[0]], lIllIlllllllll[lIlllIIIIIIIII[1]]);
    lIllIllllllllI[lIlllIIIIIIIII[1]] = llllIllIllllIIl(lIllIlllllllll[lIlllIIIIIIIII[2]], lIllIlllllllll[lIlllIIIIIIIII[3]]);
    lIllIllllllllI[lIlllIIIIIIIII[2]] = llllIllIllllIlI(lIllIlllllllll[lIlllIIIIIIIII[4]], lIllIlllllllll[lIlllIIIIIIIII[5]]);
    lIllIllllllllI[lIlllIIIIIIIII[3]] = llllIllIllllIlI(lIllIlllllllll[lIlllIIIIIIIII[6]], lIllIlllllllll[lIlllIIIIIIIII[7]]);
    lIllIllllllllI[lIlllIIIIIIIII[4]] = llllIllIllllIlI(lIllIlllllllll[lIlllIIIIIIIII[8]], lIllIlllllllll[lIlllIIIIIIIII[9]]);
    lIllIllllllllI[lIlllIIIIIIIII[5]] = llllIllIllllIll(lIllIlllllllll[lIlllIIIIIIIII[10]], lIllIlllllllll[lIlllIIIIIIIII[11]]);
    lIllIllllllllI[lIlllIIIIIIIII[6]] = llllIllIllllIll(lIllIlllllllll[lIlllIIIIIIIII[12]], lIllIlllllllll[lIlllIIIIIIIII[13]]);
    lIllIllllllllI[lIlllIIIIIIIII[7]] = llllIllIllllIll(lIllIlllllllll[lIlllIIIIIIIII[14]], lIllIlllllllll[lIlllIIIIIIIII[15]]);
    lIllIllllllllI[lIlllIIIIIIIII[8]] = llllIllIllllIlI("PSYDXi46LRITMTIlA14gPyoSHjd9LRIENDwxHF4NNjc/ES03LxICEz8iDjMvOiYZBHk1NhkTHGJ3QEJ6ZBwWSmsfLRIEbD4qGRUgISIRBGw9JgMHLCEoWCAiMCgSBHh6FU1QYw==", "SCwpC");
    lIllIllllllllI[lIlllIIIIIIIII[9]] = llllIllIllllIlI("IiA3SwolKyYGFS0jN0sEICwmCxNiIC0RDjg8bSAJOCw3HDcgJDoAFR8VeQMOKSknOlB9dHRROC1/d19HbGU=", "LECeg");
    lIllIlllllllll = null;
  }
  
  private static void llllIllIlllllIl() {
    String str = (new Exception()).getStackTrace()[lIlllIIIIIIIII[0]].getFileName();
    lIllIlllllllll = str.substring(str.indexOf("ä") + lIlllIIIIIIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllIllllIIl(String lllllllllllllllIllllIIIIlIllIIII, String lllllllllllllllIllllIIIIlIlIllll) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIIlIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIlIlIllll.getBytes(StandardCharsets.UTF_8)), lIlllIIIIIIIII[8]), "DES");
      Cipher lllllllllllllllIllllIIIIlIllIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllllIIIIlIllIIlI.init(lIlllIIIIIIIII[2], lllllllllllllllIllllIIIIlIllIIll);
      return new String(lllllllllllllllIllllIIIIlIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIIlIllIIIl) {
      lllllllllllllllIllllIIIIlIllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllIllllIlI(String lllllllllllllllIllllIIIIlIlIllIl, String lllllllllllllllIllllIIIIlIlIllII) {
    lllllllllllllllIllllIIIIlIlIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIlIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIIIlIlIlIll = new StringBuilder();
    char[] lllllllllllllllIllllIIIIlIlIlIlI = lllllllllllllllIllllIIIIlIlIllII.toCharArray();
    int lllllllllllllllIllllIIIIlIlIlIIl = lIlllIIIIIIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIIIlIlIllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIIIIIIII[0];
    while (llllIlllIIIIIll(j, i)) {
      char lllllllllllllllIllllIIIIlIlIlllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIIIlIlIlIIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() < ((0xC3 ^ 0x88) & (0x2B ^ 0x60 ^ 0xFFFFFFFF)))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIIIlIlIlIll);
  }
  
  private static String llllIllIllllIll(String lllllllllllllllIllllIIIIlIlIIlIl, String lllllllllllllllIllllIIIIlIlIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIIlIlIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIlIlIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIIIlIlIIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIIIlIlIIlll.init(lIlllIIIIIIIII[2], lllllllllllllllIllllIIIIlIlIlIII);
      return new String(lllllllllllllllIllllIIIIlIlIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIIlIlIIllI) {
      lllllllllllllllIllllIIIIlIlIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIllllllI() {
    lIlllIIIIIIIII = new int[16];
    lIlllIIIIIIIII[0] = (0x76 ^ 0x7F) << " ".length() & ((0xA ^ 0x3) << " ".length() ^ 0xFFFFFFFF);
    lIlllIIIIIIIII[1] = " ".length();
    lIlllIIIIIIIII[2] = " ".length() << " ".length();
    lIlllIIIIIIIII[3] = "   ".length();
    lIlllIIIIIIIII[4] = " ".length() << " ".length() << " ".length();
    lIlllIIIIIIIII[5] = 0x99 ^ 0xB2 ^ (0x48 ^ 0x5F) << " ".length();
    lIlllIIIIIIIII[6] = "   ".length() << " ".length();
    lIlllIIIIIIIII[7] = 47 + 145 - 161 + 134 ^ (0x7 ^ 0x56) << " ".length();
    lIlllIIIIIIIII[8] = " ".length() << "   ".length();
    lIlllIIIIIIIII[9] = 0x3F ^ 0x36;
    lIlllIIIIIIIII[10] = (0x6 ^ 0x3) << " ".length();
    lIlllIIIIIIIII[11] = 0xB3 ^ 0xB8;
    lIlllIIIIIIIII[12] = "   ".length() << " ".length() << " ".length();
    lIlllIIIIIIIII[13] = 0x3E ^ 0x33;
    lIlllIIIIIIIII[14] = (0x14 ^ 0x71 ^ (0x2F ^ 0x1E) << " ".length()) << " ".length();
    lIlllIIIIIIIII[15] = 0x77 ^ 0x66 ^ (0x77 ^ 0x78) << " ".length();
  }
  
  private static boolean llllIlllIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlllIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlllIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlllIIIIIII(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int llllIllIlllllll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */