package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class f1000000000000000000000000000000 extends au {
  f100000000000000000000.Boolean centre;
  
  f100000000000000000000.Integer blockspertick;
  
  f100000000000000000000.Boolean render;
  
  f100000000000000000000.ColorSetting color;
  
  private Vec3d center;
  
  private ArrayList<BlockPos> renderBlock;
  
  private int y;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private final List<Vec3d> standardSurround;
  
  private static String[] llIIllIIlIllIl;
  
  private static Class[] llIIllIIlIlllI;
  
  private static final String[] llIIllIlIIlIlI;
  
  private static String[] llIIllIlIIlIll;
  
  private static final int[] llIIllIlIIllII;
  
  public f1000000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: <illegal opcode> 1 : ()Lnet/minecraft/util/math/Vec3d;
    //   47: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lnet/minecraft/util/math/Vec3d;)V
    //   52: aload_0
    //   53: new java/util/ArrayList
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: <illegal opcode> 3 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Ljava/util/ArrayList;)V
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: aload_0
    //   71: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lme/zero/alpine/listener/EventHook;
    //   76: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   79: iconst_0
    //   80: iaload
    //   81: anewarray java/util/function/Predicate
    //   84: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   87: <illegal opcode> 4 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lme/zero/alpine/listener/Listener;)V
    //   92: aload_0
    //   93: new java/util/ArrayList
    //   96: dup
    //   97: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   100: iconst_3
    //   101: iaload
    //   102: anewarray net/minecraft/util/math/Vec3d
    //   105: dup
    //   106: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   109: iconst_0
    //   110: iaload
    //   111: new net/minecraft/util/math/Vec3d
    //   114: dup
    //   115: dconst_0
    //   116: ldc2_w -1.0
    //   119: dconst_0
    //   120: invokespecial <init> : (DDD)V
    //   123: aastore
    //   124: dup
    //   125: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   128: iconst_1
    //   129: iaload
    //   130: new net/minecraft/util/math/Vec3d
    //   133: dup
    //   134: dconst_1
    //   135: ldc2_w -1.0
    //   138: dconst_0
    //   139: invokespecial <init> : (DDD)V
    //   142: aastore
    //   143: dup
    //   144: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   147: iconst_2
    //   148: iaload
    //   149: new net/minecraft/util/math/Vec3d
    //   152: dup
    //   153: dconst_0
    //   154: ldc2_w -1.0
    //   157: dconst_1
    //   158: invokespecial <init> : (DDD)V
    //   161: aastore
    //   162: dup
    //   163: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   166: iconst_4
    //   167: iaload
    //   168: new net/minecraft/util/math/Vec3d
    //   171: dup
    //   172: ldc2_w -1.0
    //   175: ldc2_w -1.0
    //   178: dconst_0
    //   179: invokespecial <init> : (DDD)V
    //   182: aastore
    //   183: dup
    //   184: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   187: iconst_5
    //   188: iaload
    //   189: new net/minecraft/util/math/Vec3d
    //   192: dup
    //   193: dconst_0
    //   194: ldc2_w -1.0
    //   197: ldc2_w -1.0
    //   200: invokespecial <init> : (DDD)V
    //   203: aastore
    //   204: dup
    //   205: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   208: bipush #6
    //   210: iaload
    //   211: new net/minecraft/util/math/Vec3d
    //   214: dup
    //   215: dconst_1
    //   216: dconst_0
    //   217: dconst_0
    //   218: invokespecial <init> : (DDD)V
    //   221: aastore
    //   222: dup
    //   223: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   226: bipush #7
    //   228: iaload
    //   229: new net/minecraft/util/math/Vec3d
    //   232: dup
    //   233: dconst_0
    //   234: dconst_0
    //   235: dconst_1
    //   236: invokespecial <init> : (DDD)V
    //   239: aastore
    //   240: dup
    //   241: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   244: bipush #8
    //   246: iaload
    //   247: new net/minecraft/util/math/Vec3d
    //   250: dup
    //   251: ldc2_w -1.0
    //   254: dconst_0
    //   255: dconst_0
    //   256: invokespecial <init> : (DDD)V
    //   259: aastore
    //   260: dup
    //   261: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   264: bipush #9
    //   266: iaload
    //   267: new net/minecraft/util/math/Vec3d
    //   270: dup
    //   271: dconst_0
    //   272: dconst_0
    //   273: ldc2_w -1.0
    //   276: invokespecial <init> : (DDD)V
    //   279: aastore
    //   280: <illegal opcode> 5 : ([Ljava/lang/Object;)Ljava/util/List;
    //   285: invokespecial <init> : (Ljava/util/Collection;)V
    //   288: putfield standardSurround : Ljava/util/List;
    //   291: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	292	0	lllllllllllllllIllIIIIlllllIIlll	Lme/stupitdog/bhp/f1000000000000000000000000000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   8: iconst_4
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   14: iconst_1
    //   15: iaload
    //   16: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   21: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   26: aload_0
    //   27: aload_0
    //   28: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   34: iconst_5
    //   35: iaload
    //   36: aaload
    //   37: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   40: iconst_5
    //   41: iaload
    //   42: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   45: iconst_1
    //   46: iaload
    //   47: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   50: bipush #10
    //   52: iaload
    //   53: <illegal opcode> 8 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   58: <illegal opcode> 9 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   63: aload_0
    //   64: aload_0
    //   65: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   68: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   71: bipush #6
    //   73: iaload
    //   74: aaload
    //   75: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   78: iconst_1
    //   79: iaload
    //   80: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   85: <illegal opcode> 10 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   90: aload_0
    //   91: aload_0
    //   92: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIlIlI : [Ljava/lang/String;
    //   95: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   98: bipush #7
    //   100: iaload
    //   101: aaload
    //   102: new me/stupitdog/bhp/f01
    //   105: dup
    //   106: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   109: bipush #11
    //   111: iaload
    //   112: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   115: bipush #11
    //   117: iaload
    //   118: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   121: bipush #11
    //   123: iaload
    //   124: invokespecial <init> : (III)V
    //   127: <illegal opcode> 11 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   132: <illegal opcode> 12 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   137: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	138	0	lllllllllllllllIllIIIIlllllIIllI	Lme/stupitdog/bhp/f1000000000000000000000000000000;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onEnable : ()V
    //   4: aload_0
    //   5: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   10: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   15: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   20: d2i
    //   21: <illegal opcode> 16 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;I)V
    //   26: aload_0
    //   27: <illegal opcode> 17 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   32: <illegal opcode> 18 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   37: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   40: ifeq -> 357
    //   43: aload_0
    //   44: invokespecial getSurroundType : ()Ljava/util/List;
    //   47: <illegal opcode> 19 : (Ljava/util/List;)Ljava/util/Iterator;
    //   52: astore_1
    //   53: aload_1
    //   54: <illegal opcode> 20 : (Ljava/util/Iterator;)Z
    //   59: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   62: ifeq -> 357
    //   65: aload_1
    //   66: <illegal opcode> 21 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   71: checkcast net/minecraft/util/math/Vec3d
    //   74: astore_2
    //   75: new net/minecraft/util/math/BlockPos
    //   78: dup
    //   79: aload_2
    //   80: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   85: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   90: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/Vec3d;
    //   95: <illegal opcode> 23 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   100: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   103: astore_3
    //   104: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   109: <illegal opcode> 24 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   114: aload_3
    //   115: <illegal opcode> 25 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   120: <illegal opcode> 26 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   125: <illegal opcode> 27 : ()Lnet/minecraft/block/Block;
    //   130: <illegal opcode> 28 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   135: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   138: ifeq -> 339
    //   141: aload_0
    //   142: aload_0
    //   143: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   148: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   153: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   158: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   163: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   168: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   173: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   178: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   183: <illegal opcode> 30 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   188: <illegal opcode> 31 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;DDD)Lnet/minecraft/util/math/Vec3d;
    //   193: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;Lnet/minecraft/util/math/Vec3d;)V
    //   198: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   203: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   208: dconst_0
    //   209: putfield field_70159_w : D
    //   212: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   217: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   222: dconst_0
    //   223: putfield field_70179_y : D
    //   226: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   231: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   236: <illegal opcode> 32 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   241: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   244: dup
    //   245: aload_0
    //   246: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   251: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;)D
    //   256: aload_0
    //   257: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   262: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   267: aload_0
    //   268: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   273: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   278: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   281: iconst_1
    //   282: iaload
    //   283: invokespecial <init> : (DDDZ)V
    //   286: <illegal opcode> 37 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   291: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   296: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   301: aload_0
    //   302: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   307: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;)D
    //   312: aload_0
    //   313: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   318: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   323: aload_0
    //   324: <illegal opcode> 33 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lnet/minecraft/util/math/Vec3d;
    //   329: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   334: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)V
    //   339: ldc_w ''
    //   342: invokevirtual length : ()I
    //   345: pop
    //   346: ldc_w ' '
    //   349: invokevirtual length : ()I
    //   352: ineg
    //   353: iflt -> 53
    //   356: return
    //   357: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   104	235	3	lllllllllllllllIllIIIIlllllIIlIl	Lnet/minecraft/util/math/BlockPos;
    //   75	264	2	lllllllllllllllIllIIIIlllllIIlII	Lnet/minecraft/util/math/Vec3d;
    //   0	358	0	lllllllllllllllIllIIIIlllllIIIll	Lme/stupitdog/bhp/f1000000000000000000000000000000;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   15: aload_0
    //   16: <illegal opcode> 39 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)I
    //   21: i2d
    //   22: invokestatic lIIIlIIlIlIllIll : (DD)I
    //   25: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   28: ifeq -> 37
    //   31: aload_0
    //   32: <illegal opcode> 40 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)V
    //   37: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   40: iconst_0
    //   41: iaload
    //   42: istore_1
    //   43: aload_0
    //   44: <illegal opcode> 41 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Ljava/util/ArrayList;
    //   49: <illegal opcode> 42 : (Ljava/util/ArrayList;)V
    //   54: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   59: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   64: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   69: <illegal opcode> 44 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   74: istore_2
    //   75: aload_0
    //   76: invokespecial getSurroundType : ()Ljava/util/List;
    //   79: <illegal opcode> 19 : (Ljava/util/List;)Ljava/util/Iterator;
    //   84: astore_3
    //   85: aload_3
    //   86: <illegal opcode> 20 : (Ljava/util/Iterator;)Z
    //   91: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   94: ifeq -> 483
    //   97: aload_3
    //   98: <illegal opcode> 21 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   103: checkcast net/minecraft/util/math/Vec3d
    //   106: astore #4
    //   108: new net/minecraft/util/math/BlockPos
    //   111: dup
    //   112: aload #4
    //   114: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   119: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   124: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/Vec3d;
    //   129: <illegal opcode> 23 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   134: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   137: astore #5
    //   139: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   142: iconst_0
    //   143: iaload
    //   144: istore #6
    //   146: iload #6
    //   148: getstatic me/stupitdog/bhp/f1000000000000000000000000000000.llIIllIlIIllII : [I
    //   151: iconst_3
    //   152: iaload
    //   153: invokestatic lIIIlIIlIlIlllII : (II)Z
    //   156: ifeq -> 300
    //   159: <illegal opcode> 45 : ()Lnet/minecraft/client/Minecraft;
    //   164: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   169: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   174: iload #6
    //   176: <illegal opcode> 46 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   181: <illegal opcode> 47 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   186: astore #7
    //   188: aload #7
    //   190: instanceof net/minecraft/item/ItemBlock
    //   193: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   196: ifeq -> 245
    //   199: aload #7
    //   201: checkcast net/minecraft/item/ItemBlock
    //   204: <illegal opcode> 48 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   209: <illegal opcode> 49 : ()Lnet/minecraft/block/Block;
    //   214: <illegal opcode> 28 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   219: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   222: ifeq -> 245
    //   225: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   230: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   235: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   240: iload #6
    //   242: putfield field_70461_c : I
    //   245: iinc #6, 1
    //   248: ldc_w ''
    //   251: invokevirtual length : ()I
    //   254: pop
    //   255: ldc_w '   '
    //   258: invokevirtual length : ()I
    //   261: ldc_w ' '
    //   264: invokevirtual length : ()I
    //   267: ldc_w '   '
    //   270: invokevirtual length : ()I
    //   273: ishl
    //   274: ldc_w ' '
    //   277: invokevirtual length : ()I
    //   280: ldc_w '   '
    //   283: invokevirtual length : ()I
    //   286: ishl
    //   287: ldc_w ' '
    //   290: invokevirtual length : ()I
    //   293: ineg
    //   294: ixor
    //   295: iand
    //   296: if_icmpgt -> 146
    //   299: return
    //   300: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   305: <illegal opcode> 24 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   310: aload #5
    //   312: <illegal opcode> 25 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   317: <illegal opcode> 26 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   322: <illegal opcode> 27 : ()Lnet/minecraft/block/Block;
    //   327: <illegal opcode> 28 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   332: invokestatic lIIIlIIlIlIllIlI : (I)Z
    //   335: ifeq -> 387
    //   338: aload #5
    //   340: <illegal opcode> 50 : (Lnet/minecraft/util/math/BlockPos;)V
    //   345: aload_0
    //   346: <illegal opcode> 41 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Ljava/util/ArrayList;
    //   351: aload #5
    //   353: <illegal opcode> 51 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   358: ldc_w ''
    //   361: invokevirtual length : ()I
    //   364: pop2
    //   365: iinc #1, 1
    //   368: iload_1
    //   369: aload_0
    //   370: <illegal opcode> 52 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   375: <illegal opcode> 53 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   380: invokestatic lIIIlIIlIlIlllIl : (II)Z
    //   383: ifeq -> 387
    //   386: return
    //   387: ldc_w ''
    //   390: invokevirtual length : ()I
    //   393: pop
    //   394: sipush #244
    //   397: sipush #151
    //   400: ixor
    //   401: sipush #162
    //   404: sipush #159
    //   407: ixor
    //   408: ldc_w ' '
    //   411: invokevirtual length : ()I
    //   414: ishl
    //   415: ixor
    //   416: bipush #96
    //   418: bipush #107
    //   420: iadd
    //   421: sipush #160
    //   424: isub
    //   425: bipush #114
    //   427: iadd
    //   428: sipush #227
    //   431: sipush #194
    //   434: ixor
    //   435: ldc_w ' '
    //   438: invokevirtual length : ()I
    //   441: ldc_w ' '
    //   444: invokevirtual length : ()I
    //   447: ishl
    //   448: ishl
    //   449: ixor
    //   450: ldc_w ' '
    //   453: invokevirtual length : ()I
    //   456: ineg
    //   457: ixor
    //   458: iand
    //   459: ldc_w ' '
    //   462: invokevirtual length : ()I
    //   465: ldc_w ' '
    //   468: invokevirtual length : ()I
    //   471: ldc_w ' '
    //   474: invokevirtual length : ()I
    //   477: ishl
    //   478: ishl
    //   479: if_icmple -> 85
    //   482: return
    //   483: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   488: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   493: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   498: iload_2
    //   499: putfield field_70461_c : I
    //   502: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   188	57	7	lllllllllllllllIllIIIIlllllIIIlI	Lnet/minecraft/item/Item;
    //   146	154	6	lllllllllllllllIllIIIIlllllIIIIl	I
    //   139	248	5	lllllllllllllllIllIIIIlllllIIIII	Lnet/minecraft/util/math/BlockPos;
    //   108	279	4	lllllllllllllllIllIIIIllllIlllll	Lnet/minecraft/util/math/Vec3d;
    //   0	503	0	lllllllllllllllIllIIIIllllIllllI	Lme/stupitdog/bhp/f1000000000000000000000000000000;
    //   43	460	1	lllllllllllllllIllIIIIllllIlllIl	I
    //   75	428	2	lllllllllllllllIllIIIIllllIlllII	I
  }
  
  private List<Vec3d> getSurroundType() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 54 : (Lme/stupitdog/bhp/f1000000000000000000000000000000;)Ljava/util/List;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIIllllIllIll	Lme/stupitdog/bhp/f1000000000000000000000000000000;
  }
  
  public Vec3d getCenter(double lllllllllllllllIllIIIIllllIllIIl, double lllllllllllllllIllIIIIllllIllIII, double lllllllllllllllIllIIIIllllIlIlll) {
    // Byte code:
    //   0: dload_1
    //   1: <illegal opcode> 55 : (D)D
    //   6: ldc2_w 0.5
    //   9: dadd
    //   10: dstore #7
    //   12: dload_3
    //   13: <illegal opcode> 55 : (D)D
    //   18: dstore #9
    //   20: dload #5
    //   22: <illegal opcode> 55 : (D)D
    //   27: ldc2_w 0.5
    //   30: dadd
    //   31: dstore #11
    //   33: new net/minecraft/util/math/Vec3d
    //   36: dup
    //   37: dload #7
    //   39: dload #9
    //   41: dload #11
    //   43: invokespecial <init> : (DDD)V
    //   46: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIllIIIIllllIllIlI	Lme/stupitdog/bhp/f1000000000000000000000000000000;
    //   0	47	1	lllllllllllllllIllIIIIllllIllIIl	D
    //   0	47	3	lllllllllllllllIllIIIIllllIllIII	D
    //   0	47	5	lllllllllllllllIllIIIIllllIlIlll	D
    //   12	35	7	lllllllllllllllIllIIIIllllIlIllI	D
    //   20	27	9	lllllllllllllllIllIIIIllllIlIlIl	D
    //   33	14	11	lllllllllllllllIllIIIIllllIlIlII	D
  }
  
  static {
    lIIIlIIlIlIllIIl();
    lIIIlIIlIlIllIII();
    lIIIlIIlIlIlIlll();
    lIIIlIIlIlIlIIll();
  }
  
  private static CallSite lIIIlIIIlllIIlIl(MethodHandles.Lookup lllllllllllllllIllIIIIllllIIlIII, String lllllllllllllllIllIIIIllllIIIlll, MethodType lllllllllllllllIllIIIIllllIIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIIllllIIlllI = llIIllIIlIllIl[Integer.parseInt(lllllllllllllllIllIIIIllllIIIlll)].split(llIIllIlIIlIlI[llIIllIlIIllII[8]]);
      Class<?> lllllllllllllllIllIIIIllllIIllIl = Class.forName(lllllllllllllllIllIIIIllllIIlllI[llIIllIlIIllII[0]]);
      String lllllllllllllllIllIIIIllllIIllII = lllllllllllllllIllIIIIllllIIlllI[llIIllIlIIllII[1]];
      MethodHandle lllllllllllllllIllIIIIllllIIlIll = null;
      int lllllllllllllllIllIIIIllllIIlIlI = lllllllllllllllIllIIIIllllIIlllI[llIIllIlIIllII[4]].length();
      if (lIIIlIIlIlIlllll(lllllllllllllllIllIIIIllllIIlIlI, llIIllIlIIllII[2])) {
        MethodType lllllllllllllllIllIIIIllllIlIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIIllllIIlllI[llIIllIlIIllII[2]], f1000000000000000000000000000000.class.getClassLoader());
        if (lIIIlIIlIlIlllIl(lllllllllllllllIllIIIIllllIIlIlI, llIIllIlIIllII[2])) {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findVirtual(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIlIIII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findStatic(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIlIIII);
        } 
        "".length();
        if (((0x92 ^ 0xBB ^ (0xB6 ^ 0x85) << " ".length()) & ((0xAD ^ 0xA8) << " ".length() << " ".length() ^ 0xFA ^ 0xA1 ^ -" ".length())) != (((0x1D ^ 0x10) << " ".length() ^ "   ".length()) & (89 + 81 - 94 + 59 ^ (0xC2 ^ 0x8D) << " ".length() ^ -" ".length())))
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIIllllIIllll = llIIllIIlIlllI[Integer.parseInt(lllllllllllllllIllIIIIllllIIlllI[llIIllIlIIllII[2]])];
        if (lIIIlIIlIlIlllIl(lllllllllllllllIllIIIIllllIIlIlI, llIIllIlIIllII[4])) {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findGetter(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIIllll);
          "".length();
          if (" ".length() > " ".length())
            return null; 
        } else if (lIIIlIIlIlIlllIl(lllllllllllllllIllIIIIllllIIlIlI, llIIllIlIIllII[5])) {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findStaticGetter(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIIllll);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (lIIIlIIlIlIlllIl(lllllllllllllllIllIIIIllllIIlIlI, llIIllIlIIllII[6])) {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findSetter(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIIllll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIIIllllIIlIll = lllllllllllllllIllIIIIllllIIlIII.findStaticSetter(lllllllllllllllIllIIIIllllIIllIl, lllllllllllllllIllIIIIllllIIllII, lllllllllllllllIllIIIIllllIIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIIllllIIlIll);
    } catch (Exception lllllllllllllllIllIIIIllllIIlIIl) {
      lllllllllllllllIllIIIIllllIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIlIlIlIIll() {
    llIIllIIlIllIl = new String[llIIllIlIIllII[12]];
    llIIllIIlIllIl[llIIllIlIIllII[13]] = llIIllIlIIlIlI[llIIllIlIIllII[9]];
    llIIllIIlIllIl[llIIllIlIIllII[14]] = llIIllIlIIlIlI[llIIllIlIIllII[3]];
    llIIllIIlIllIl[llIIllIlIIllII[10]] = llIIllIlIIlIlI[llIIllIlIIllII[10]];
    llIIllIIlIllIl[llIIllIlIIllII[15]] = llIIllIlIIlIlI[llIIllIlIIllII[16]];
    llIIllIIlIllIl[llIIllIlIIllII[17]] = llIIllIlIIlIlI[llIIllIlIIllII[18]];
    llIIllIIlIllIl[llIIllIlIIllII[19]] = llIIllIlIIlIlI[llIIllIlIIllII[20]];
    llIIllIIlIllIl[llIIllIlIIllII[21]] = llIIllIlIIlIlI[llIIllIlIIllII[22]];
    llIIllIIlIllIl[llIIllIlIIllII[23]] = llIIllIlIIlIlI[llIIllIlIIllII[24]];
    llIIllIIlIllIl[llIIllIlIIllII[16]] = llIIllIlIIlIlI[llIIllIlIIllII[25]];
    llIIllIIlIllIl[llIIllIlIIllII[26]] = llIIllIlIIlIlI[llIIllIlIIllII[27]];
    llIIllIIlIllIl[llIIllIlIIllII[8]] = llIIllIlIIlIlI[llIIllIlIIllII[28]];
    llIIllIIlIllIl[llIIllIlIIllII[29]] = llIIllIlIIlIlI[llIIllIlIIllII[30]];
    llIIllIIlIllIl[llIIllIlIIllII[24]] = llIIllIlIIlIlI[llIIllIlIIllII[31]];
    llIIllIIlIllIl[llIIllIlIIllII[27]] = llIIllIlIIlIlI[llIIllIlIIllII[32]];
    llIIllIIlIllIl[llIIllIlIIllII[3]] = llIIllIlIIlIlI[llIIllIlIIllII[33]];
    llIIllIIlIllIl[llIIllIlIIllII[34]] = llIIllIlIIlIlI[llIIllIlIIllII[26]];
    llIIllIIlIllIl[llIIllIlIIllII[35]] = llIIllIlIIlIlI[llIIllIlIIllII[36]];
    llIIllIIlIllIl[llIIllIlIIllII[31]] = llIIllIlIIlIlI[llIIllIlIIllII[37]];
    llIIllIIlIllIl[llIIllIlIIllII[38]] = llIIllIlIIlIlI[llIIllIlIIllII[39]];
    llIIllIIlIllIl[llIIllIlIIllII[40]] = llIIllIlIIlIlI[llIIllIlIIllII[41]];
    llIIllIIlIllIl[llIIllIlIIllII[42]] = llIIllIlIIlIlI[llIIllIlIIllII[14]];
    llIIllIIlIllIl[llIIllIlIIllII[43]] = llIIllIlIIlIlI[llIIllIlIIllII[44]];
    llIIllIIlIllIl[llIIllIlIIllII[45]] = llIIllIlIIlIlI[llIIllIlIIllII[46]];
    llIIllIIlIllIl[llIIllIlIIllII[18]] = llIIllIlIIlIlI[llIIllIlIIllII[47]];
    llIIllIIlIllIl[llIIllIlIIllII[22]] = llIIllIlIIlIlI[llIIllIlIIllII[48]];
    llIIllIIlIllIl[llIIllIlIIllII[49]] = llIIllIlIIlIlI[llIIllIlIIllII[50]];
    llIIllIIlIllIl[llIIllIlIIllII[51]] = llIIllIlIIlIlI[llIIllIlIIllII[19]];
    llIIllIIlIllIl[llIIllIlIIllII[52]] = llIIllIlIIlIlI[llIIllIlIIllII[23]];
    llIIllIIlIllIl[llIIllIlIIllII[53]] = llIIllIlIIlIlI[llIIllIlIIllII[54]];
    llIIllIIlIllIl[llIIllIlIIllII[48]] = llIIllIlIIlIlI[llIIllIlIIllII[49]];
    llIIllIIlIllIl[llIIllIlIIllII[55]] = llIIllIlIIlIlI[llIIllIlIIllII[56]];
    llIIllIIlIllIl[llIIllIlIIllII[25]] = llIIllIlIIlIlI[llIIllIlIIllII[57]];
    llIIllIIlIllIl[llIIllIlIIllII[58]] = llIIllIlIIlIlI[llIIllIlIIllII[53]];
    llIIllIIlIllIl[llIIllIlIIllII[54]] = llIIllIlIIlIlI[llIIllIlIIllII[40]];
    llIIllIIlIllIl[llIIllIlIIllII[59]] = llIIllIlIIlIlI[llIIllIlIIllII[42]];
    llIIllIIlIllIl[llIIllIlIIllII[33]] = llIIllIlIIlIlI[llIIllIlIIllII[45]];
    llIIllIIlIllIl[llIIllIlIIllII[60]] = llIIllIlIIlIlI[llIIllIlIIllII[52]];
    llIIllIIlIllIl[llIIllIlIIllII[36]] = llIIllIlIIlIlI[llIIllIlIIllII[61]];
    llIIllIIlIllIl[llIIllIlIIllII[20]] = llIIllIlIIlIlI[llIIllIlIIllII[62]];
    llIIllIIlIllIl[llIIllIlIIllII[63]] = llIIllIlIIlIlI[llIIllIlIIllII[43]];
    llIIllIIlIllIl[llIIllIlIIllII[64]] = llIIllIlIIlIlI[llIIllIlIIllII[65]];
    llIIllIIlIllIl[llIIllIlIIllII[4]] = llIIllIlIIlIlI[llIIllIlIIllII[66]];
    llIIllIIlIllIl[llIIllIlIIllII[67]] = llIIllIlIIlIlI[llIIllIlIIllII[38]];
    llIIllIIlIllIl[llIIllIlIIllII[65]] = llIIllIlIIlIlI[llIIllIlIIllII[34]];
    llIIllIIlIllIl[llIIllIlIIllII[44]] = llIIllIlIIlIlI[llIIllIlIIllII[15]];
    llIIllIIlIllIl[llIIllIlIIllII[30]] = llIIllIlIIlIlI[llIIllIlIIllII[60]];
    llIIllIIlIllIl[llIIllIlIIllII[0]] = llIIllIlIIlIlI[llIIllIlIIllII[35]];
    llIIllIIlIllIl[llIIllIlIIllII[32]] = llIIllIlIIlIlI[llIIllIlIIllII[13]];
    llIIllIIlIllIl[llIIllIlIIllII[6]] = llIIllIlIIlIlI[llIIllIlIIllII[64]];
    llIIllIIlIllIl[llIIllIlIIllII[61]] = llIIllIlIIlIlI[llIIllIlIIllII[51]];
    llIIllIIlIllIl[llIIllIlIIllII[7]] = llIIllIlIIlIlI[llIIllIlIIllII[59]];
    llIIllIIlIllIl[llIIllIlIIllII[28]] = llIIllIlIIlIlI[llIIllIlIIllII[63]];
    llIIllIIlIllIl[llIIllIlIIllII[39]] = llIIllIlIIlIlI[llIIllIlIIllII[17]];
    llIIllIIlIllIl[llIIllIlIIllII[50]] = llIIllIlIIlIlI[llIIllIlIIllII[29]];
    llIIllIIlIllIl[llIIllIlIIllII[46]] = llIIllIlIIlIlI[llIIllIlIIllII[68]];
    llIIllIIlIllIl[llIIllIlIIllII[2]] = llIIllIlIIlIlI[llIIllIlIIllII[67]];
    llIIllIIlIllIl[llIIllIlIIllII[47]] = llIIllIlIIlIlI[llIIllIlIIllII[55]];
    llIIllIIlIllIl[llIIllIlIIllII[66]] = llIIllIlIIlIlI[llIIllIlIIllII[21]];
    llIIllIIlIllIl[llIIllIlIIllII[69]] = llIIllIlIIlIlI[llIIllIlIIllII[69]];
    llIIllIIlIllIl[llIIllIlIIllII[57]] = llIIllIlIIlIlI[llIIllIlIIllII[58]];
    llIIllIIlIllIl[llIIllIlIIllII[9]] = llIIllIlIIlIlI[llIIllIlIIllII[70]];
    llIIllIIlIllIl[llIIllIlIIllII[68]] = llIIllIlIIlIlI[llIIllIlIIllII[12]];
    llIIllIIlIllIl[llIIllIlIIllII[1]] = llIIllIlIIlIlI[llIIllIlIIllII[71]];
    llIIllIIlIllIl[llIIllIlIIllII[41]] = llIIllIlIIlIlI[llIIllIlIIllII[72]];
    llIIllIIlIllIl[llIIllIlIIllII[5]] = llIIllIlIIlIlI[llIIllIlIIllII[73]];
    llIIllIIlIllIl[llIIllIlIIllII[62]] = llIIllIlIIlIlI[llIIllIlIIllII[74]];
    llIIllIIlIllIl[llIIllIlIIllII[56]] = llIIllIlIIlIlI[llIIllIlIIllII[75]];
    llIIllIIlIllIl[llIIllIlIIllII[37]] = llIIllIlIIlIlI[llIIllIlIIllII[76]];
    llIIllIIlIllIl[llIIllIlIIllII[70]] = llIIllIlIIlIlI[llIIllIlIIllII[77]];
    llIIllIIlIlllI = new Class[llIIllIlIIllII[25]];
    llIIllIIlIlllI[llIIllIlIIllII[4]] = Listener.class;
    llIIllIIlIlllI[llIIllIlIIllII[16]] = int.class;
    llIIllIIlIlllI[llIIllIlIIllII[0]] = f13.class;
    llIIllIIlIlllI[llIIllIlIIllII[2]] = ArrayList.class;
    llIIllIIlIlllI[llIIllIlIIllII[5]] = List.class;
    llIIllIIlIlllI[llIIllIlIIllII[8]] = f100000000000000000000.ColorSetting.class;
    llIIllIIlIlllI[llIIllIlIIllII[10]] = double.class;
    llIIllIIlIlllI[llIIllIlIIllII[20]] = Block.class;
    llIIllIIlIlllI[llIIllIlIIllII[24]] = InventoryPlayer.class;
    llIIllIIlIlllI[llIIllIlIIllII[6]] = f100000000000000000000.Boolean.class;
    llIIllIIlIlllI[llIIllIlIIllII[9]] = Minecraft.class;
    llIIllIIlIlllI[llIIllIlIIllII[18]] = WorldClient.class;
    llIIllIIlIlllI[llIIllIlIIllII[22]] = NetHandlerPlayClient.class;
    llIIllIIlIlllI[llIIllIlIIllII[3]] = EntityPlayerSP.class;
    llIIllIIlIlllI[llIIllIlIIllII[1]] = Vec3d.class;
    llIIllIIlIlllI[llIIllIlIIllII[7]] = f100000000000000000000.Integer.class;
  }
  
  private static void lIIIlIIlIlIlIlll() {
    llIIllIlIIlIlI = new String[llIIllIlIIllII[78]];
    llIIllIlIIlIlI[llIIllIlIIllII[0]] = lIIIlIIlIlIlIlII(llIIllIlIIlIll[llIIllIlIIllII[0]], llIIllIlIIlIll[llIIllIlIIllII[1]]);
    llIIllIlIIlIlI[llIIllIlIIllII[1]] = lIIIlIIlIlIlIlIl(llIIllIlIIlIll[llIIllIlIIllII[2]], llIIllIlIIlIll[llIIllIlIIllII[4]]);
    llIIllIlIIlIlI[llIIllIlIIllII[2]] = lIIIlIIlIlIlIllI(llIIllIlIIlIll[llIIllIlIIllII[5]], llIIllIlIIlIll[llIIllIlIIllII[6]]);
    llIIllIlIIlIlI[llIIllIlIIllII[4]] = lIIIlIIlIlIlIllI(llIIllIlIIlIll[llIIllIlIIllII[7]], llIIllIlIIlIll[llIIllIlIIllII[8]]);
    llIIllIlIIlIlI[llIIllIlIIllII[5]] = lIIIlIIlIlIlIlIl(llIIllIlIIlIll[llIIllIlIIllII[9]], llIIllIlIIlIll[llIIllIlIIllII[3]]);
    llIIllIlIIlIlI[llIIllIlIIllII[6]] = lIIIlIIlIlIlIlII(llIIllIlIIlIll[llIIllIlIIllII[10]], llIIllIlIIlIll[llIIllIlIIllII[16]]);
    llIIllIlIIlIlI[llIIllIlIIllII[7]] = lIIIlIIlIlIlIlIl(llIIllIlIIlIll[llIIllIlIIllII[18]], llIIllIlIIlIll[llIIllIlIIllII[20]]);
    llIIllIlIIlIlI[llIIllIlIIllII[8]] = lIIIlIIlIlIlIlII(llIIllIlIIlIll[llIIllIlIIllII[22]], llIIllIlIIlIll[llIIllIlIIllII[24]]);
    llIIllIlIIlIlI[llIIllIlIIllII[9]] = lIIIlIIlIlIlIlII(llIIllIlIIlIll[llIIllIlIIllII[25]], llIIllIlIIlIll[llIIllIlIIllII[27]]);
    llIIllIlIIlIlI[llIIllIlIIllII[3]] = lIIIlIIlIlIlIllI(llIIllIlIIlIll[llIIllIlIIllII[28]], llIIllIlIIlIll[llIIllIlIIllII[30]]);
    llIIllIlIIlIlI[llIIllIlIIllII[10]] = lIIIlIIlIlIlIllI(llIIllIlIIlIll[llIIllIlIIllII[31]], llIIllIlIIlIll[llIIllIlIIllII[32]]);
    llIIllIlIIlIlI[llIIllIlIIllII[16]] = lIIIlIIlIlIlIlII(llIIllIlIIlIll[llIIllIlIIllII[33]], llIIllIlIIlIll[llIIllIlIIllII[26]]);
    llIIllIlIIlIlI[llIIllIlIIllII[18]] = lIIIlIIlIlIlIlIl("D5HjxC0n+fTGVN9WZeZ//nVN12u4fZ1vI6ZupLUhrnLSJG+RYaw3kxj5oFodGD8uEr62QiH1g1o=", "oWsFD");
    llIIllIlIIlIlI[llIIllIlIIllII[20]] = lIIIlIIlIlIlIllI("uITt6AE4wqDYHQCQQtMJkV2YiyBpCwy3ZYHPoCCUAM3jk9azqNpjuG+y0/aonk+yZsfHLKqZPkc=", "WOtxC");
    llIIllIlIIlIlI[llIIllIlIIllII[22]] = lIIIlIIlIlIlIlIl("+rS33QInhGHqPb/5yuLgOwgj6ydAuwvyAarshO3hXYCPmyZ2yxqWgw==", "EIslQ");
    llIIllIlIIlIlI[llIIllIlIIllII[24]] = lIIIlIIlIlIlIlII("ASo5Sh4GISgHAQ4pOUoGGyYhSh4OOyVKJQosfgBJCSYoCBcweH9QR1cQL15CX3VtRFM=", "oOMds");
    llIIllIlIIlIlI[llIIllIlIIllII[25]] = lIIIlIIlIlIlIlII("HhJXNg4GBxAxHhwQVycSA1kfdEpDR0l1SkNHSXVKQ0dJdUpDR0l1SkNHSXVKQ0dJdUABEh4sCQcSCwYVHxgLf1I/HRgzG1wbGCsdXCQNNxMdEEIJFxZYCjEPAx4NIRUUWBstClwRSXRBWjsUIFUAAww1EwcTFiJVER8JahxCR0l1SkNHSXVKQ0dJdUpDR0l1SkNTOioWHAUqIA4HHhciQUlXWQ==", "swyEz");
    llIIllIlIIlIlI[llIIllIlIIllII[27]] = lIIIlIIlIlIlIlII("HzYDSAgYPRIFFxA1A0gQBTobSAgQJx9IMxQwRAJfFyYZBTpAZE9RXUYMElxNPT0SEkocOhkDBgMyERJKBCceCkocMgMOSic2FFUBSno7CAAFfBoPCxQwBQcDBXwCEgwdfBoHERl8IQMGQjdMXEVR", "qSwfe");
    llIIllIlIIlIlI[llIIllIlIIllII[28]] = lIIIlIIlIlIlIlIl("mYKK9gnpx7KVwRsjNCLXXjPNv0EMjYddidtVry+MEJOJ21WvL4wQk4nbVa8vjBCTivWi+mdXeSE6M/QhgpJ28SX4a3d8hlD6", "GGljq");
    llIIllIlIIlIlI[llIIllIlIIllII[30]] = lIIIlIIlIlIlIllI("RyYpLtOKJxyfGabvfgEKoSivg5FDg1y86gMOlF5BjZGtyGqodkKPSC1Yle9nrs58J+ntXLbSwirV/4LNA38bJ0E/3ffXKrIMu9GU1NwdB1I1/Nd1dyH5Vr/TE1VmFhq7", "PXzFi");
    llIIllIlIIlIlI[llIIllIlIIllII[31]] = lIIIlIIlIlIlIlIl("9h5s+XHNYqvB8+K57Sdb4cCbToj4InHdeeHViv9eiiKtl7xl2FpWj1jcaarwJv3M16/eGzDMucotvN/yTYXNkA==", "PdHet");
    llIIllIlIIlIlI[llIIllIlIIllII[32]] = lIIIlIIlIlIlIlIl("esGGB2AP8sqyIZ7j4YW1OenQ4EXdXMziTqPn9W6FFHhOo+f1boUUeE6j5/VuhRR4vsLn6+XOpXDyM6dOhxYagw==", "JZFqk");
    llIIllIlIIlIlI[llIIllIlIIllII[33]] = lIIIlIIlIlIlIllI("n35ynw3iUP5sFXo8GubR9txe2PpGrStE1PNK7Qh9pMLU80rtCH2kwtTzSu0IfaTCvx6gFCYvMDnuojVjAtTxQDvZt3SNjzwR", "DVCQX");
    llIIllIlIIlIlI[llIIllIlIIllII[26]] = lIIIlIIlIlIlIllI("8qmTqJJLWe8VkrlgXHFSknkPnlhy3Zc6fyAkTC2RoVzA6DXIWMDlcz9tXwnfo1dSQL9dhjfymlo=", "WORPP");
    llIIllIlIIlIlI[llIIllIlIIllII[36]] = lIIIlIIlIlIlIllI("aUhPTbUmg41mMNyzKZhzf6y7ki7hmhXG0R6wp9KjPbDRHrCn0qM9sNEesKfSoz2wylTajN9SwImwqX/9/y7SDydVKRtYpiL3uK963rd1hLA=", "cUpjn");
    llIIllIlIIlIlI[llIIllIlIIllII[37]] = lIIIlIIlIlIlIlIl("UtGVWfEOJ/uEKJafPMzNXAgLco5QvnDCNXmnb8Gmaj9TcmG2HtFGkw==", "aOkVF");
    llIIllIlIIlIlI[llIIllIlIIllII[39]] = lIIIlIIlIlIlIlII("OB90PxkgCjM4CToddC4FJVQ8fFtvCjYtDjA4NiMOPkByAAMwDnUhBDsfOT4MMw51ORk8FnUhDCESdQ4BOhkxHAImQXMaV3U=", "UzZLm");
    llIIllIlIIlIlI[llIIllIlIIllII[41]] = lIIIlIIlIlIlIlII("JgRHBhM+EQABAyQGRxcPO08PRFd7UVlFV3tRWUVXe1FZRVd7UVlFV3tRWUVXe1FZRV05BAcRAjkjBRoEIFtbT0drQQ==", "Kaiug");
    llIIllIlIIlIlI[llIIllIlIIllII[14]] = lIIIlIIlIlIlIlII("HBIyMWQDBy08ZDcBNjEzOho3JHAVHyExOExbbQZwVlM=", "vsDPJ");
    llIIllIlIIlIlI[llIIllIlIIllII[44]] = lIIIlIIlIlIlIllI("silZXgh/Dh13JWoA0haMNXK9Q5mXTa/Aoo9qCFq0XHJNM7VVtX8z5WIJJ/RIgMEQxA9qYVAqbX4w8F2n41L0YnJ2W7KeGo2H69jl7jdr2Zo=", "QiUHO");
    llIIllIlIIlIlI[llIIllIlIIllII[46]] = lIIIlIIlIlIlIllI("f1ULD1+PNICkrX3P2WvnOGQ3msZCW1tay++EAVeWNAcuTOYCAJx2bZ7SEEZJv3+KrzXCs3i1c53pyzK1H5Bu40nqtL0llCTe", "JXppC");
    llIIllIlIIlIlI[llIIllIlIIllII[47]] = lIIIlIIlIlIlIlIl("ACv6xgc/aF6tNHIGnI9FF8cUL0g4PREBJNoZF1NR3j4k2hkXU1HePiTaGRdTUd4+abjNLKpD/ltzEFwH7RMhqA==", "JDgSY");
    llIIllIlIIlIlI[llIIllIlIIllII[48]] = lIIIlIIlIlIlIllI("GMeB5UqGtKTik77opojLizdd3yFXNcY+kiNxBB0zwAyjQsUaEBxx2U/6DYRf5wMcWfYNydzRZdw=", "qXvCB");
    llIIllIlIIlIlI[llIIllIlIIllII[50]] = lIIIlIIlIlIlIlIl("bp6LpJ6lDC9et+vydctErsiHBUkJKbFefAewIfjiDk2wZU12Gv4JlaR3DcksCIz4pmOjaHPis2EU+KM6X2N1LUh6wgsOhq0HlVpCuaEYiTeccwEwQYljhBQhV2hLX74e4QYeccwFU+4=", "UlaSs");
    llIIllIlIIlIlI[llIIllIlIIllII[19]] = lIIIlIIlIlIlIlIl("oyRlhf54alzn9jPoWP2dHvEzF6qVHbYPew3g4kN+X98H+bYqAvsiuaEnjSEfNXVQG2Kd2hmgeJE=", "NJLsc");
    llIIllIlIIlIlI[llIIllIlIIllII[23]] = lIIIlIIlIlIlIllI("ezXwFAGMkxB8TDYVIBz1LTWzzu/9HPmNbie+3PJx8dwd9bJO0FAuDJwVx91fBlpjg97EsM91BWyl7bpj4UAbNLKF0kgorQD+", "xYmGI");
    llIIllIlIIlIlI[llIIllIlIIllII[54]] = lIIIlIIlIlIlIlIl("OEYSzK1ehIHtE4uz2MxRGal1JmDi3nlfNp3I1B4C1m02ncjUHgLWbTadyNQeAtZtnA8L4dkcfAKoeNu8rhnebQ==", "YliAY");
    llIIllIlIIlIlI[llIIllIlIIllII[49]] = lIIIlIIlIlIlIllI("RvbFCoF/uGZlJ2tdrPVNJgiRhTel4zcUku0EW9IkrigrOjU1Gw5cGltTnn2gQeDRn+i+M2aIKP+Ab39roZWzcg==", "OSWZX");
    llIIllIlIIlIlI[llIIllIlIIllII[56]] = lIIIlIIlIlIlIlIl("qDiKUSbk7X0iskVCf16nahIvqKmLuV96aJJsJbcdeMYGkkC1Xxd8Dg==", "RVtGN");
    llIIllIlIIlIlI[llIIllIlIIllII[57]] = lIIIlIIlIlIlIlIl("CtNSPeOjqoT//d5AXOXGflTNQ8i++AS++Xk0nnkG3Iz5eTSeeQbcjPl5NJ55BtyMEz59vyXjBncrCH7X9mlY8w==", "Jckki");
    llIIllIlIIlIlI[llIIllIlIIllII[53]] = lIIIlIIlIlIlIllI("JJckj1xwVbvmOBQNp61AJLf5wTZL7kb22AxNwlLry7bYXIFv2lnO0KFvlNxT9UDGRG/fYSiHL3Z20oVLcMJMpLdIIEMpuCOD5ql0kwY6fFwh4BSHPThYYxfVzyJbckwP", "IRrIn");
    llIIllIlIIlIlI[llIIllIlIIllII[40]] = lIIIlIIlIlIlIlII("IyY4dxckLSk6CCwlOHcPOSogdxcsNyR3LCggfz1AKyopNR4SdH5tTnQcL2NLfXlseVo=", "MCLYz");
    llIIllIlIIlIlI[llIIllIlIIllII[42]] = lIIIlIIlIlIlIlII("Pg4Afxk5BREyBjENAH8BJAIYfxkxHxx/NjwEFzokPxhONwE+CCtgQ2dSQWkrPlFceD1qS1Q=", "PktQt");
    llIIllIlIIlIlI[llIIllIlIIllII[45]] = lIIIlIIlIlIlIlIl("Laup5IK3BmkgShg8jQkhxyWzf109VSNtkeipZFUtbCcaex8Jd2/qjQ70P7j5Gjn1dr/cehD6RjywH7q7Xl9FZUHKntaRiBfS1sf4qwfF1b91YfcY3LM2+Ene5dHrBg9L", "Lcrlv");
    llIIllIlIIlIlI[llIIllIlIIllII[52]] = lIIIlIIlIlIlIlIl("qn+uerzdCmz/psq/ihRApHDhgHhXKktzjWVhA9+UJrdq77bpnQMFZs3cjzX4L/oGjA+ZaLIyW7k0ho1S2ls+Iw==", "oBbGW");
    llIIllIlIIlIlI[llIIllIlIIllII[61]] = lIIIlIIlIlIlIllI("JMjb8XhOAmnNAoL3K44rEJ5uZr+SPvtSdOSOryKtIf3y9Ddt6jVsL/YSbMlcZMuhVugqFmNuCsI=", "Ofmdz");
    llIIllIlIIlIlI[llIIllIlIIllII[62]] = lIIIlIIlIlIlIllI("17AYZCwkL2VP+31GFEMl3Yl6oBcfSuFNyVSuVXReG/jJVK5VdF4b+MlUrlV0Xhv4qPiUMiR8/CszbVVNGd3OGw==", "Iprmf");
    llIIllIlIIlIlI[llIIllIlIIllII[43]] = lIIIlIIlIlIlIlII("AR8DZBgGFBIpBw4cA2QAGxMbZBgODh9kNwMVFCElAAlNLAABGSh7QlhDQnwqAEBfYzxVWlc=", "ozwJu");
    llIIllIlIIlIlI[llIIllIlIIllII[65]] = lIIIlIIlIlIlIlIl("ghupVZgV+gddRpQTk5WYqsdbWiWEGrrLpJrb3550MiSkmtvfnnQyJKSa29+edDIkF6BUwoFv5v0oHSQv7ac9LQ==", "XaWKo");
    llIIllIlIIlIlI[llIIllIlIIllII[66]] = lIIIlIIlIlIlIlIl("mbtJ/6OMY7Z2wwiHrTt5wTxR7tZ0gAxILq1EhlfPXwsurUSGV89fCy6tRIZXz18L0W3D7YpZvWhaMzfPfzaLLvMbp+NuNQgk", "UJXVf");
    llIIllIlIIlIlI[llIIllIlIIllII[38]] = lIIIlIIlIlIlIlII("KhFaGwMyBB0cEygTWgofN1oSWUd3RERYR3dERFhHd0REWEd3RERYUwQbGAcFFBEAHB4pE04PEjMiFQQCIk5cQTsqEVsbAzIEHRwTKBNbCh83WxJYRnxOVEg=", "Gtthw");
    llIIllIlIIlIlI[llIIllIlIIllII[34]] = lIIIlIIlIlIlIlII("KwEdTSEsCgwAPiQCHU0lMQEETQUxAQQhICoHAlkqMAoKPH1yXVtRfxoAU0tlCQoMF2MoDQcGLzcFDxdjJwgGACdqJgUMLy5fU0Ns", "EdicL");
    llIIllIlIIlIlI[llIIllIlIIllII[15]] = lIIIlIIlIlIlIlII("FwgkQB4QAzUNARgLJEAQFQQ1AAdXCD4aGg0UfisdDQQkFyMVDCkLASo9aggaHAE0MURJXGZbLA1XYV5JWU1w", "ymPns");
    llIIllIlIIlIlI[llIIllIlIIllII[60]] = lIIIlIIlIlIlIllI("uUaNQ9Iq+/+tg3xxN7Jh9MoJAZBf29TmyXAmkeQKibY9HIvhgzy+Si3kRx022jcLn9nHF0iGbSk=", "qKvrV");
    llIIllIlIIlIlI[llIIllIlIIllII[35]] = lIIIlIIlIlIlIllI("SxXrCwb04+ArUHNerGYLuLS4QdxG5AqyKzvcKf4Yrww84BFFxGcMkg==", "dOnhH");
    llIIllIlIIlIlI[llIIllIlIIllII[13]] = lIIIlIIlIlIlIlIl("awbjJoL8e4ICSlBeKbZt5YlIAh0xha8iGH7PZtuigO1IRtAFycXO1FZwOf7OdSvd", "nvyQA");
    llIIllIlIIlIlI[llIIllIlIIllII[64]] = lIIIlIIlIlIlIlIl("oXFnaCog6gPEzyjGtxA1y6D5gCHl6bT/+VdtoC/nAxCwG+eukXXSF+XQw4vpu1vpXwAk1gJvyIeGalttJ8Yt5A==", "gTdad");
    llIIllIlIIlIlI[llIIllIlIIllII[51]] = lIIIlIIlIlIlIllI("YUuUc7jl7KX9baJYP1291RvYpwrUS/c+eCOn/uRkZlud6k5M4SD5vYJfehAiHtjTMdstb/XXAkkeEbBUJy4AeuRAiLZj1SmmBeO8QJInhgqyKfBi4vaa/w==", "HoJvX");
    llIIllIlIIlIlI[llIIllIlIIllII[59]] = lIIIlIIlIlIlIlII("CSNkBAERNiMDEQshZBUdFGgsRkVUdnpHRVR2ekdFVHZ6R0VUdnpHRVR2ekdFVHZ6R08WIy0eBhAjODUaCyovFhtebgYdFBInZRsUCiFlJAEWLyQQTj5vBhoQSzU+AgUNMi4YEkskIgdaAnd6R0VUdnpHRVR2ekdFVHZ6R0VUdm41GgsqLxYbX3xqVw==", "dFJwu");
    llIIllIlIIlIlI[llIIllIlIIllII[63]] = lIIIlIIlIlIlIllI("hGXCcL1zakBGysYvzH9je2pLDwxJbYleQwuxah/bZsp+jpHjY7ARdciZICwvzHRPPYBU9JRcxTjVj8y0PzDJew==", "RdnbD");
    llIIllIlIIlIlI[llIIllIlIIllII[17]] = lIIIlIIlIlIlIlII("OggQWik9AwEXNjULEFomOAIHH2onGQUAIXokJhgrNwY3ACUgCF4SMToOO0VzY19XRBs3V0xdCDoIEFspPQMBFzY1CxBbJjgCBx9rFgELFy9vV0RU", "TmdtD");
    llIIllIlIIlIlI[llIIllIlIIllII[29]] = lIIIlIIlIlIlIlIl("uO0uWhltw1ZZttQhknwrxEwyxrRYQhKTXbdOn9FPPGldt06f0U88aV23Tp/RTzxpy3a/66QoDZqfJryDywjFGw==", "xxvDx");
    llIIllIlIIlIlI[llIIllIlIIllII[68]] = lIIIlIIlIlIlIlII("GhMlaR8dGDQkABUQJWkRGB80KQZaEz8zGwAPfwIcAB8lPiIYFygiACcmayEbERo1GEVER2d2LQJMYHdIVFZx", "tvQGr");
    llIIllIlIIlIlI[llIIllIlIIllII[67]] = lIIIlIIlIlIlIlII("OTdmBR8hIiECDzs1ZhQDJHwuR1tkYnhGW2RieEZbZGJ4RltkYnhGW2RieEZbZGJ4RlE3NyYCDiZoeUxLdHJoVg==", "TRHvk");
    llIIllIlIIlIlI[llIIllIlIIllII[55]] = lIIIlIIlIlIlIlIl("JSZqigdQizseU6VZDGLAE6BzMnY2wTnecjiHZTbOZutyOIdlNs5m63I4h2U2zmbrw7S43XaSsT3X3L04ptUYN0EZyTNwmbd0jtA4GBBeMbTDrmUGY/s/iwEoKBehoJSx0q7VOsIEs2c=", "itysX");
    llIIllIlIIlIlI[llIIllIlIIllII[21]] = lIIIlIIlIlIlIllI("S6DaEZg3PKj7N3163Dej+VgtzwaZniNgfxLl++0jQ0aRkB2KlWkZ2/TOU1/PcBB7GwULWzErNVY=", "kxCtO");
    llIIllIlIIlIlI[llIIllIlIIllII[69]] = lIIIlIIlIlIlIlIl("I9poDol8CLy6MLKhBb/pmdpMCbC6Ke574yXyDkWMnDa4b/xurIIZpg==", "cqiOr");
    llIIllIlIIlIlI[llIIllIlIIllII[58]] = lIIIlIIlIlIlIllI("yDiBOyoIZY4lyHtWvZ4hqJTWtVUOv7xxBZUAtA3ZaBIFlQC0DdloEgWVALQN2WgS1TfOGYNOReCrH2iBUIuayg==", "pghEy");
    llIIllIlIIlIlI[llIIllIlIIllII[70]] = lIIIlIIlIlIlIlIl("neneqjWiuAQHHjb2mufbZAYj8SgSoJOjczldWXiOskRzOV1ZeI6yRHM5XVl4jrJEiB58OSIealrEIyyyh4Q4ZkPK5FYjfhlSIovqgmSdIvHRUFcfgRAJ4uUKTjWr+0fO4sjCXEifSXNajl3+Rt9Mw3M5XVl4jrJEczldWXiOskRbKZqDP9S9KhSOaNM0HpDF", "oJcvx");
    llIIllIlIIlIlI[llIIllIlIIllII[12]] = lIIIlIIlIlIlIllI("QnRbQ6TTmhCgbt+zqUcYHXW23DFEzZOJA3b5tRt3H+0Ddvm1G3cf7QN2+bUbdx/tilBh/SqsvYkZogu72ii9SQ==", "CAIoG");
    llIIllIlIIlIlI[llIIllIlIIllII[71]] = lIIIlIIlIlIlIlIl("HMBy6ZyDhAVDo3RQmXO4kdeKDtxcJpTuIYVPsA/3mOSI3chuGhRXy8UcLOCzqiSWx44/sTtiqDI=", "BGJrx");
    llIIllIlIIlIlI[llIIllIlIIllII[72]] = lIIIlIIlIlIlIlII("HSEteCoaKjw1NRIiLXguHS0teAUfKzo9NEkiMDMrFxtoY3dAcWkJJkl1amxnU2R5", "sDYVG");
    llIIllIlIIlIlI[llIIllIlIIllII[73]] = lIIIlIIlIlIlIllI("WxHcp5sbMV9cRuD2pL/k8t88cThanWrqag0fE7mDjMJqDR8TuYOMwmoNHxO5g4zCh8HVuGwe184vY0rXxZ+gTVDRxQhIbRVd", "QLRuJ");
    llIIllIlIIlIlI[llIIllIlIIllII[74]] = lIIIlIIlIlIlIlIl("V2Qlngsjnl/hgBRI4OWDKkqWC8kwYPIvRWFNk3c36bc2/tHAZwIHuyyyNQ1NXP/9mTPkAy6KiDEZ+8XVEMdJ3BtkqBa0+nut1m/TC4kBSo/K9ejgaAFQFAe5bi8qo4GT", "XOCJj");
    llIIllIlIIlIlI[llIIllIlIIllII[75]] = lIIIlIIlIlIlIlII("GigzZSMdIyIoPBUrM2UtGCQiJTpaKCk/JwA0aQ4gACQzMh4YLD4uPCcdfS07Gi4YfH5FfXAULE5lAw8KXRt9a24=", "tMGKN");
    llIIllIlIIlIlI[llIIllIlIIllII[76]] = lIIIlIIlIlIlIlII("GiwMWBodJx0VBRUvDFgUGCAdGANaJA0aAx05FBcOETtWIRgGJRw1Gx0sFgJNEjwWFShFcUhCTkEWCExfOCcdAlgZIBYTFAYoHgJYAT0RGlgZKAweWDYlFxUcJCYLTV44Jx0CWBkgFhMUBigeAlgWJRcVHFs6DBcDEWYxNBsbKhMlAxU9HU1NVGk=", "tIxvw");
    llIIllIlIIlIlI[llIIllIlIIllII[77]] = lIIIlIIlIlIlIllI("tyE75a8tCTLV5GNBU2oXPMJ+AP8qZ9f67WOJOd7r9i76Ja6BLe1DfdOXv6AtSWQ1PdxuCIOadQJp4dyOFcSGofBiuxnXuW9Vs1eaqnyiw03V0Cg/BAvj6G6Z3dfWnoAPKy91rOGgJNw=", "pmKmB");
    llIIllIlIIlIll = null;
  }
  
  private static void lIIIlIIlIlIllIII() {
    String str = (new Exception()).getStackTrace()[llIIllIlIIllII[0]].getFileName();
    llIIllIlIIlIll = str.substring(str.indexOf("ä") + llIIllIlIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIlIlIlIlIl(String lllllllllllllllIllIIIIllllIIIIlI, String lllllllllllllllIllIIIIllllIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIIllllIIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIllllIIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIIllllIIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIIllllIIIlII.init(llIIllIlIIllII[2], lllllllllllllllIllIIIIllllIIIlIl);
      return new String(lllllllllllllllIllIIIIllllIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIllllIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIIllllIIIIll) {
      lllllllllllllllIllIIIIllllIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIlIlIlIlII(String lllllllllllllllIllIIIIlllIllllll, String lllllllllllllllIllIIIIlllIlllllI) {
    lllllllllllllllIllIIIIlllIllllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIIlllIllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIIlllIllllIl = new StringBuilder();
    char[] lllllllllllllllIllIIIIlllIllllII = lllllllllllllllIllIIIIlllIlllllI.toCharArray();
    int lllllllllllllllIllIIIIlllIlllIll = llIIllIlIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIIlllIllllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIlIIllII[0];
    while (lIIIlIIlIlIlllII(j, i)) {
      char lllllllllllllllIllIIIIllllIIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIIlllIlllIll++;
      j++;
      "".length();
      if (" ".length() << " ".length() == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIIlllIllllIl);
  }
  
  private static String lIIIlIIlIlIlIllI(String lllllllllllllllIllIIIIlllIllIlll, String lllllllllllllllIllIIIIlllIllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIIIlllIlllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIlllIllIllI.getBytes(StandardCharsets.UTF_8)), llIIllIlIIllII[9]), "DES");
      Cipher lllllllllllllllIllIIIIlllIlllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIIIlllIlllIIl.init(llIIllIlIIllII[2], lllllllllllllllIllIIIIlllIlllIlI);
      return new String(lllllllllllllllIllIIIIlllIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIlllIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIIlllIlllIII) {
      lllllllllllllllIllIIIIlllIlllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIlIlIllIIl() {
    llIIllIlIIllII = new int[79];
    llIIllIlIIllII[0] = ((0xB ^ 0x16) << " ".length() ^ 0x3A ^ 0x31) & (34 + 159 - 174 + 142 ^ (0xCC ^ 0xC5) << " ".length() << " ".length() << " ".length() ^ -" ".length());
    llIIllIlIIllII[1] = " ".length();
    llIIllIlIIllII[2] = " ".length() << " ".length();
    llIIllIlIIllII[3] = 0x9E ^ 0x97;
    llIIllIlIIllII[4] = "   ".length();
    llIIllIlIIllII[5] = " ".length() << " ".length() << " ".length();
    llIIllIlIIllII[6] = 0x2D ^ 0x28;
    llIIllIlIIllII[7] = "   ".length() << " ".length();
    llIIllIlIIllII[8] = 0x1B ^ 0x1C;
    llIIllIlIIllII[9] = " ".length() << "   ".length();
    llIIllIlIIllII[10] = (0x9 ^ 0xC) << " ".length();
    llIIllIlIIllII[11] = 156 + 186 - 321 + 234;
    llIIllIlIIllII[12] = 0x6A ^ 0x2F;
    llIIllIlIIllII[13] = 173 + 127 - 131 + 18 ^ (0x65 ^ 0x46) << " ".length() << " ".length();
    llIIllIlIIllII[14] = (24 + 184 - 60 + 51 ^ "   ".length() << "   ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIllII[15] = (165 + 138 - 143 + 9 ^ (0x63 ^ 0x4A) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIllII[16] = 0x72 ^ 0x79;
    llIIllIlIIllII[17] = (0xA2 ^ 0xB5 ^ "   ".length() << "   ".length()) << " ".length() << " ".length();
    llIIllIlIIllII[18] = "   ".length() << " ".length() << " ".length();
    llIIllIlIIllII[19] = (0x65 ^ 0x74) << " ".length();
    llIIllIlIIllII[20] = 0xFA ^ 0xC1 ^ (0xAF ^ 0xB4) << " ".length();
    llIIllIlIIllII[21] = 0x3F ^ 0x6 ^ (0x1B ^ 0x14) << "   ".length();
    llIIllIlIIllII[22] = (0x8 ^ 0xF) << " ".length();
    llIIllIlIIllII[23] = 0x3E ^ 0x1D;
    llIIllIlIIllII[24] = 0x7D ^ 0x72;
    llIIllIlIIllII[25] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIllIlIIllII[26] = 31 + 134 - 73 + 83 ^ (0x88 ^ 0x9F) << "   ".length();
    llIIllIlIIllII[27] = 0xB0 ^ 0x8B ^ (0x6D ^ 0x78) << " ".length();
    llIIllIlIIllII[28] = (138 + 72 - 108 + 87 ^ (0x3 ^ 0x2E) << " ".length() << " ".length()) << " ".length();
    llIIllIlIIllII[29] = 0x17 ^ 0x2A;
    llIIllIlIIllII[30] = 0xD1 ^ 0xA4 ^ (0x8D ^ 0xBE) << " ".length();
    llIIllIlIIllII[31] = ((0xBF ^ 0x9E) << " ".length() ^ 0x27 ^ 0x60) << " ".length() << " ".length();
    llIIllIlIIllII[32] = 0x36 ^ 0x23;
    llIIllIlIIllII[33] = (0x48 ^ 0x43) << " ".length();
    llIIllIlIIllII[34] = 110 + 40 - 55 + 54 ^ (0x19 ^ 0x4A) << " ".length();
    llIIllIlIIllII[35] = ((0xF ^ 0x14) << " ".length() << " ".length() ^ 0xE3 ^ 0x94) << " ".length();
    llIIllIlIIllII[36] = "   ".length() << "   ".length();
    llIIllIlIIllII[37] = 0x69 ^ 0x70;
    llIIllIlIIllII[38] = (0x67 ^ 0x7E) << " ".length();
    llIIllIlIIllII[39] = (0x53 ^ 0x48 ^ (0x85 ^ 0x8E) << " ".length()) << " ".length();
    llIIllIlIIllII[40] = 0x7A ^ 0x53;
    llIIllIlIIllII[41] = 0xF2 ^ 0xBB ^ (0x6C ^ 0x45) << " ".length();
    llIIllIlIIllII[42] = (0xB3 ^ 0xA6) << " ".length();
    llIIllIlIIllII[43] = 0xB4 ^ 0x89 ^ (0x79 ^ 0x70) << " ".length();
    llIIllIlIIllII[44] = 0x7E ^ 0x63;
    llIIllIlIIllII[45] = 0x40 ^ 0x6B;
    llIIllIlIIllII[46] = ((0x31 ^ 0x38) << "   ".length() ^ 0x4 ^ 0x43) << " ".length();
    llIIllIlIIllII[47] = 118 + 20 - 135 + 160 ^ (0x77 ^ 0x58) << " ".length() << " ".length();
    llIIllIlIIllII[48] = " ".length() << (" ".length() << " ".length() ^ 0x70 ^ 0x77);
    llIIllIlIIllII[49] = (0x33 ^ 0x3A) << " ".length() ^ 0x5F ^ 0x68;
    llIIllIlIIllII[50] = 0xE ^ 0x2F;
    llIIllIlIIllII[51] = (0x63 ^ 0x48) << " ".length() ^ 0x55 ^ 0x3A;
    llIIllIlIIllII[52] = (0x10 ^ 0x23 ^ (0x83 ^ 0x84) << "   ".length()) << " ".length() << " ".length();
    llIIllIlIIllII[53] = (0xC3 ^ 0xC6) << "   ".length();
    llIIllIlIIllII[54] = (0x18 ^ 0x11) << " ".length() << " ".length();
    llIIllIlIIllII[55] = " ".length() << "   ".length() << " ".length();
    llIIllIlIIllII[56] = (0x12 ^ 0x1) << " ".length();
    llIIllIlIIllII[57] = 0x5B ^ 0x7C;
    llIIllIlIIllII[58] = 0x16 ^ 0x5F ^ (0x68 ^ 0x6D) << " ".length();
    llIIllIlIIllII[59] = ((0x8A ^ 0xA5) << " ".length() ^ 0x3F ^ 0x7C) << " ".length();
    llIIllIlIIllII[60] = 0x1 ^ 0x40 ^ (0x9F ^ 0x82) << " ".length() << " ".length();
    llIIllIlIIllII[61] = (0xC9 ^ 0x9C) << " ".length() ^ 85 + 111 - 66 + 5;
    llIIllIlIIllII[62] = (0x18 ^ 0xF) << " ".length();
    llIIllIlIIllII[63] = 0x1B ^ 0x0 ^ " ".length() << (0x2E ^ 0x2B);
    llIIllIlIIllII[64] = (0x3E ^ 0x6B ^ (0xBC ^ 0x95) << " ".length()) << "   ".length();
    llIIllIlIIllII[65] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIllIlIIllII[66] = (0x77 ^ 0x64) << " ".length() ^ 0x3B ^ 0x2C;
    llIIllIlIIllII[67] = 0xA7 ^ 0x98;
    llIIllIlIIllII[68] = (0x80 ^ 0x9F) << " ".length();
    llIIllIlIIllII[69] = (0x1B ^ 0x3A) << " ".length();
    llIIllIlIIllII[70] = ((0xED ^ 0xA6) << " ".length() ^ 5 + 127 - 4 + 7) << " ".length() << " ".length();
    llIIllIlIIllII[71] = (0x92 ^ 0xB1) << " ".length();
    llIIllIlIIllII[72] = 0x4D ^ 0xA;
    llIIllIlIIllII[73] = (0x51 ^ 0x0 ^ (0x40 ^ 0x4B) << "   ".length()) << "   ".length();
    llIIllIlIIllII[74] = (0xD ^ 0x12) << "   ".length() ^ 15 + 150 - 41 + 53;
    llIIllIlIIllII[75] = (0x35 ^ 0x10) << " ".length();
    llIIllIlIIllII[76] = 0x63 ^ 0x28;
    llIIllIlIIllII[77] = (0x7E ^ 0x6D) << " ".length() << " ".length();
    llIIllIlIIllII[78] = (0x70 ^ 0x77) << " ".length() << " ".length() << " ".length() ^ 0x36 ^ 0xB;
  }
  
  private static boolean lIIIlIIlIlIlllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIlIlIlllII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIlIlIlllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIlIlIllllI(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIlIIlIlIllIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static int lIIIlIIlIlIllIll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */