package me.stupitdog.bhp;

import java.awt.Font;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.texture.DynamicTexture;

public class fa extends f14 {
  protected f14.CharData[] boldChars;
  
  protected f14.CharData[] italicChars;
  
  protected f14.CharData[] boldItalicChars;
  
  private final int[] colorCode;
  
  private final String colorcodeIdentifiers = "0123456789abcdefklmnor";
  
  String fontName;
  
  int fontSize;
  
  protected DynamicTexture texBold;
  
  protected DynamicTexture texItalic;
  
  protected DynamicTexture texItalicBold;
  
  private static String[] lIllllIlIllllI;
  
  private static Class[] lIllllIlIlllll;
  
  private static final String[] lIllllIlllllll;
  
  private static String[] lIlllllIIIIlII;
  
  private static final int[] lIlllllIIIIlIl;
  
  public fa(Font lllllllllllllllIlllIIIllllIIlIIl, boolean lllllllllllllllIlllIIIllllIIlIII, boolean lllllllllllllllIlllIIIllllIIIlll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Ljava/awt/Font;ZZ)V
    //   7: aload_0
    //   8: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   11: iconst_0
    //   12: iaload
    //   13: anewarray me/stupitdog/bhp/f14$CharData
    //   16: <illegal opcode> 0 : (Lme/stupitdog/bhp/fa;[Lme/stupitdog/bhp/f14$CharData;)V
    //   21: aload_0
    //   22: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   25: iconst_0
    //   26: iaload
    //   27: anewarray me/stupitdog/bhp/f14$CharData
    //   30: <illegal opcode> 1 : (Lme/stupitdog/bhp/fa;[Lme/stupitdog/bhp/f14$CharData;)V
    //   35: aload_0
    //   36: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   39: iconst_0
    //   40: iaload
    //   41: anewarray me/stupitdog/bhp/f14$CharData
    //   44: <illegal opcode> 2 : (Lme/stupitdog/bhp/fa;[Lme/stupitdog/bhp/f14$CharData;)V
    //   49: aload_0
    //   50: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   53: iconst_1
    //   54: iaload
    //   55: newarray int
    //   57: putfield colorCode : [I
    //   60: aload_0
    //   61: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   64: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   67: iconst_2
    //   68: iaload
    //   69: aaload
    //   70: putfield colorcodeIdentifiers : Ljava/lang/String;
    //   73: aload_0
    //   74: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   77: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   80: iconst_3
    //   81: iaload
    //   82: aaload
    //   83: <illegal opcode> 3 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)V
    //   88: aload_0
    //   89: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   92: iconst_4
    //   93: iaload
    //   94: <illegal opcode> 4 : (Lme/stupitdog/bhp/fa;I)V
    //   99: aload_0
    //   100: invokespecial setupMinecraftColorcodes : ()V
    //   103: aload_0
    //   104: invokespecial setupBoldItalicIDs : ()V
    //   107: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	108	0	lllllllllllllllIlllIIIllllIIlIlI	Lme/stupitdog/bhp/fa;
    //   0	108	1	lllllllllllllllIlllIIIllllIIlIIl	Ljava/awt/Font;
    //   0	108	2	lllllllllllllllIlllIIIllllIIlIII	Z
    //   0	108	3	lllllllllllllllIlllIIIllllIIIlll	Z
  }
  
  public String getFontName() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lme/stupitdog/bhp/fa;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIllllIIIllI	Lme/stupitdog/bhp/fa;
  }
  
  public int getFontSize() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lme/stupitdog/bhp/fa;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIllllIIIlIl	Lme/stupitdog/bhp/fa;
  }
  
  public void setFontName(String lllllllllllllllIlllIIIllllIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 3 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllllIIIlII	Lme/stupitdog/bhp/fa;
    //   0	8	1	lllllllllllllllIlllIIIllllIIIIll	Ljava/lang/String;
  }
  
  public void setFontSize(int lllllllllllllllIlllIIIllllIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: <illegal opcode> 4 : (Lme/stupitdog/bhp/fa;I)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllllIIIIlI	Lme/stupitdog/bhp/fa;
    //   0	8	1	lllllllllllllllIlllIIIllllIIIIIl	I
  }
  
  public float drawStringWithShadow(String lllllllllllllllIlllIIIlllIllllll, double lllllllllllllllIlllIIIlllIlllllI, double lllllllllllllllIlllIIIlllIllllIl, f01 lllllllllllllllIlllIIIlllIllllII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: dload_2
    //   3: dconst_1
    //   4: dadd
    //   5: dload #4
    //   7: dconst_1
    //   8: dadd
    //   9: aload #6
    //   11: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   14: iconst_3
    //   15: iaload
    //   16: <illegal opcode> 7 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;DDLme/stupitdog/bhp/f01;Z)F
    //   21: fstore #7
    //   23: fload #7
    //   25: aload_0
    //   26: aload_1
    //   27: dload_2
    //   28: dload #4
    //   30: aload #6
    //   32: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   35: iconst_2
    //   36: iaload
    //   37: <illegal opcode> 7 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;DDLme/stupitdog/bhp/f01;Z)F
    //   42: <illegal opcode> 8 : (FF)F
    //   47: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	48	0	lllllllllllllllIlllIIIllllIIIIII	Lme/stupitdog/bhp/fa;
    //   0	48	1	lllllllllllllllIlllIIIlllIllllll	Ljava/lang/String;
    //   0	48	2	lllllllllllllllIlllIIIlllIlllllI	D
    //   0	48	4	lllllllllllllllIlllIIIlllIllllIl	D
    //   0	48	6	lllllllllllllllIlllIIIlllIllllII	Lme/stupitdog/bhp/f01;
    //   23	25	7	lllllllllllllllIlllIIIlllIlllIll	F
  }
  
  public float drawString(String lllllllllllllllIlllIIIlllIlllIIl, float lllllllllllllllIlllIIIlllIlllIII, float lllllllllllllllIlllIIIlllIllIlll, f01 lllllllllllllllIlllIIIlllIllIllI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: fload_2
    //   3: f2d
    //   4: fload_3
    //   5: f2d
    //   6: aload #4
    //   8: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   11: iconst_2
    //   12: iaload
    //   13: <illegal opcode> 7 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;DDLme/stupitdog/bhp/f01;Z)F
    //   18: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIlllIIIlllIlllIlI	Lme/stupitdog/bhp/fa;
    //   0	19	1	lllllllllllllllIlllIIIlllIlllIIl	Ljava/lang/String;
    //   0	19	2	lllllllllllllllIlllIIIlllIlllIII	F
    //   0	19	3	lllllllllllllllIlllIIIlllIllIlll	F
    //   0	19	4	lllllllllllllllIlllIIIlllIllIllI	Lme/stupitdog/bhp/f01;
  }
  
  public float drawCenteredStringWithShadow(String lllllllllllllllIlllIIIlllIllIlII, float lllllllllllllllIlllIIIlllIllIIll, float lllllllllllllllIlllIIIlllIllIIlI, f01 lllllllllllllllIlllIIIlllIllIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: fload_2
    //   3: aload_0
    //   4: aload_1
    //   5: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   10: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   13: iconst_5
    //   14: iaload
    //   15: idiv
    //   16: i2f
    //   17: fsub
    //   18: f2d
    //   19: fload_3
    //   20: f2d
    //   21: aload #4
    //   23: <illegal opcode> 10 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;DDLme/stupitdog/bhp/f01;)F
    //   28: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	29	0	lllllllllllllllIlllIIIlllIllIlIl	Lme/stupitdog/bhp/fa;
    //   0	29	1	lllllllllllllllIlllIIIlllIllIlII	Ljava/lang/String;
    //   0	29	2	lllllllllllllllIlllIIIlllIllIIll	F
    //   0	29	3	lllllllllllllllIlllIIIlllIllIIlI	F
    //   0	29	4	lllllllllllllllIlllIIIlllIllIIIl	Lme/stupitdog/bhp/f01;
  }
  
  public float drawCenteredString(String lllllllllllllllIlllIIIlllIlIllll, float lllllllllllllllIlllIIIlllIlIlllI, float lllllllllllllllIlllIIIlllIlIllIl, f01 lllllllllllllllIlllIIIlllIlIllII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: fload_2
    //   3: aload_0
    //   4: aload_1
    //   5: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   10: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   13: iconst_5
    //   14: iaload
    //   15: idiv
    //   16: i2f
    //   17: fsub
    //   18: fload_3
    //   19: aload #4
    //   21: <illegal opcode> 11 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;FFLme/stupitdog/bhp/f01;)F
    //   26: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	27	0	lllllllllllllllIlllIIIlllIllIIII	Lme/stupitdog/bhp/fa;
    //   0	27	1	lllllllllllllllIlllIIIlllIlIllll	Ljava/lang/String;
    //   0	27	2	lllllllllllllllIlllIIIlllIlIlllI	F
    //   0	27	3	lllllllllllllllIlllIIIlllIlIllIl	F
    //   0	27	4	lllllllllllllllIlllIIIlllIlIllII	Lme/stupitdog/bhp/f01;
  }
  
  public float drawString(String lllllllllllllllIlllIIIlllIlIIlIl, double lllllllllllllllIlllIIIlllIlIIlII, double lllllllllllllllIlllIIIlllIlIIIll, f01 lllllllllllllllIlllIIIlllIlIIIlI, boolean lllllllllllllllIlllIIIlllIlIIIIl) {
    // Byte code:
    //   0: dload_2
    //   1: dconst_1
    //   2: dsub
    //   3: dstore_2
    //   4: dload #4
    //   6: ldc2_w 3.0
    //   9: dsub
    //   10: dstore #4
    //   12: new me/stupitdog/bhp/f01
    //   15: dup
    //   16: aload #6
    //   18: invokespecial <init> : (Ljava/awt/Color;)V
    //   21: astore #8
    //   23: aload_1
    //   24: invokestatic lllllllIlllIlll : (Ljava/lang/Object;)Z
    //   27: ifeq -> 32
    //   30: fconst_0
    //   31: freturn
    //   32: aload #8
    //   34: <illegal opcode> 12 : (Lme/stupitdog/bhp/f01;)I
    //   39: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   42: bipush #6
    //   44: iaload
    //   45: invokestatic lllllllIllllIII : (II)Z
    //   48: ifeq -> 134
    //   51: aload #8
    //   53: <illegal opcode> 13 : (Lme/stupitdog/bhp/f01;)I
    //   58: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   61: bipush #6
    //   63: iaload
    //   64: invokestatic lllllllIllllIII : (II)Z
    //   67: ifeq -> 134
    //   70: aload #8
    //   72: <illegal opcode> 14 : (Lme/stupitdog/bhp/f01;)I
    //   77: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   80: bipush #6
    //   82: iaload
    //   83: invokestatic lllllllIllllIII : (II)Z
    //   86: ifeq -> 134
    //   89: aload #8
    //   91: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   96: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   99: iconst_1
    //   100: iaload
    //   101: invokestatic lllllllIllllIII : (II)Z
    //   104: ifeq -> 134
    //   107: new me/stupitdog/bhp/f01
    //   110: dup
    //   111: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   114: bipush #6
    //   116: iaload
    //   117: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   120: bipush #6
    //   122: iaload
    //   123: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   126: bipush #6
    //   128: iaload
    //   129: invokespecial <init> : (III)V
    //   132: astore #8
    //   134: aload #8
    //   136: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   141: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   144: bipush #7
    //   146: iaload
    //   147: invokestatic lllllllIllllIIl : (II)Z
    //   150: ifeq -> 170
    //   153: new me/stupitdog/bhp/f01
    //   156: dup
    //   157: aload #8
    //   159: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   162: bipush #6
    //   164: iaload
    //   165: invokespecial <init> : (Lme/stupitdog/bhp/f01;I)V
    //   168: astore #8
    //   170: iload #7
    //   172: invokestatic lllllllIllllIlI : (I)Z
    //   175: ifeq -> 236
    //   178: new me/stupitdog/bhp/f01
    //   181: dup
    //   182: aload #8
    //   184: <illegal opcode> 12 : (Lme/stupitdog/bhp/f01;)I
    //   189: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   192: bipush #7
    //   194: iaload
    //   195: idiv
    //   196: aload #8
    //   198: <illegal opcode> 13 : (Lme/stupitdog/bhp/f01;)I
    //   203: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   206: bipush #7
    //   208: iaload
    //   209: idiv
    //   210: aload #8
    //   212: <illegal opcode> 14 : (Lme/stupitdog/bhp/f01;)I
    //   217: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   220: bipush #7
    //   222: iaload
    //   223: idiv
    //   224: aload #8
    //   226: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   231: invokespecial <init> : (IIII)V
    //   234: astore #8
    //   236: aload_0
    //   237: <illegal opcode> 16 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   242: astore #9
    //   244: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   247: iconst_2
    //   248: iaload
    //   249: istore #10
    //   251: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   254: iconst_2
    //   255: iaload
    //   256: istore #11
    //   258: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   261: iconst_2
    //   262: iaload
    //   263: istore #12
    //   265: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   268: iconst_2
    //   269: iaload
    //   270: istore #13
    //   272: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   275: iconst_2
    //   276: iaload
    //   277: istore #14
    //   279: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   282: iconst_3
    //   283: iaload
    //   284: istore #15
    //   286: dload_2
    //   287: ldc2_w 2.0
    //   290: dmul
    //   291: dstore_2
    //   292: dload #4
    //   294: ldc2_w 2.0
    //   297: dmul
    //   298: dstore #4
    //   300: iload #15
    //   302: invokestatic lllllllIllllIlI : (I)Z
    //   305: ifeq -> 1667
    //   308: <illegal opcode> 17 : ()V
    //   313: ldc2_w 0.5
    //   316: ldc2_w 0.5
    //   319: ldc2_w 0.5
    //   322: <illegal opcode> 18 : (DDD)V
    //   327: <illegal opcode> 19 : ()V
    //   332: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   335: bipush #8
    //   337: iaload
    //   338: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   341: bipush #9
    //   343: iaload
    //   344: <illegal opcode> 20 : (II)V
    //   349: aload #8
    //   351: <illegal opcode> 12 : (Lme/stupitdog/bhp/f01;)I
    //   356: i2f
    //   357: ldc 255.0
    //   359: fdiv
    //   360: aload #8
    //   362: <illegal opcode> 13 : (Lme/stupitdog/bhp/f01;)I
    //   367: i2f
    //   368: ldc 255.0
    //   370: fdiv
    //   371: aload #8
    //   373: <illegal opcode> 14 : (Lme/stupitdog/bhp/f01;)I
    //   378: i2f
    //   379: ldc 255.0
    //   381: fdiv
    //   382: aload #8
    //   384: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   389: i2f
    //   390: ldc 255.0
    //   392: fdiv
    //   393: <illegal opcode> 21 : (FFFF)V
    //   398: aload_1
    //   399: <illegal opcode> 22 : (Ljava/lang/String;)I
    //   404: istore #16
    //   406: <illegal opcode> 23 : ()V
    //   411: aload_0
    //   412: <illegal opcode> 24 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   417: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   422: <illegal opcode> 26 : (I)V
    //   427: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   430: iconst_2
    //   431: iaload
    //   432: istore #17
    //   434: iload #17
    //   436: iload #16
    //   438: invokestatic lllllllIllllIIl : (II)Z
    //   441: ifeq -> 1645
    //   444: aload_1
    //   445: iload #17
    //   447: <illegal opcode> 27 : (Ljava/lang/String;I)C
    //   452: istore #18
    //   454: iload #18
    //   456: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   459: bipush #10
    //   461: iaload
    //   462: invokestatic lllllllIllllIII : (II)Z
    //   465: ifeq -> 1338
    //   468: iload #17
    //   470: iload #16
    //   472: invokestatic lllllllIllllIIl : (II)Z
    //   475: ifeq -> 1338
    //   478: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   481: bipush #11
    //   483: iaload
    //   484: istore #19
    //   486: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   489: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   492: iconst_5
    //   493: iaload
    //   494: aaload
    //   495: aload_1
    //   496: iload #17
    //   498: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   501: iconst_3
    //   502: iaload
    //   503: iadd
    //   504: <illegal opcode> 27 : (Ljava/lang/String;I)C
    //   509: <illegal opcode> 28 : (Ljava/lang/String;I)I
    //   514: istore #19
    //   516: ldc ''
    //   518: invokevirtual length : ()I
    //   521: pop
    //   522: ldc_w ' '
    //   525: invokevirtual length : ()I
    //   528: ineg
    //   529: iflt -> 536
    //   532: fconst_0
    //   533: freturn
    //   534: astore #20
    //   536: iload #19
    //   538: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   541: bipush #12
    //   543: iaload
    //   544: invokestatic lllllllIllllIIl : (II)Z
    //   547: ifeq -> 751
    //   550: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   553: iconst_2
    //   554: iaload
    //   555: istore #11
    //   557: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   560: iconst_2
    //   561: iaload
    //   562: istore #12
    //   564: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   567: iconst_2
    //   568: iaload
    //   569: istore #10
    //   571: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   574: iconst_2
    //   575: iaload
    //   576: istore #14
    //   578: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   581: iconst_2
    //   582: iaload
    //   583: istore #13
    //   585: aload_0
    //   586: <illegal opcode> 24 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   591: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   596: <illegal opcode> 26 : (I)V
    //   601: aload_0
    //   602: <illegal opcode> 16 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   607: astore #9
    //   609: iload #19
    //   611: invokestatic lllllllIllllIll : (I)Z
    //   614: ifeq -> 631
    //   617: iload #19
    //   619: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   622: bipush #13
    //   624: iaload
    //   625: invokestatic lllllllIlllllII : (II)Z
    //   628: ifeq -> 639
    //   631: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   634: bipush #13
    //   636: iaload
    //   637: istore #19
    //   639: iload #7
    //   641: invokestatic lllllllIllllIlI : (I)Z
    //   644: ifeq -> 650
    //   647: iinc #19, 16
    //   650: aload_0
    //   651: <illegal opcode> 29 : (Lme/stupitdog/bhp/fa;)[I
    //   656: iload #19
    //   658: iaload
    //   659: istore #20
    //   661: iload #20
    //   663: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   666: bipush #12
    //   668: iaload
    //   669: ishr
    //   670: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   673: bipush #6
    //   675: iaload
    //   676: iand
    //   677: i2f
    //   678: ldc 255.0
    //   680: fdiv
    //   681: iload #20
    //   683: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   686: bipush #14
    //   688: iaload
    //   689: ishr
    //   690: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   693: bipush #6
    //   695: iaload
    //   696: iand
    //   697: i2f
    //   698: ldc 255.0
    //   700: fdiv
    //   701: iload #20
    //   703: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   706: bipush #6
    //   708: iaload
    //   709: iand
    //   710: i2f
    //   711: ldc 255.0
    //   713: fdiv
    //   714: aload #8
    //   716: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   721: i2f
    //   722: <illegal opcode> 21 : (FFFF)V
    //   727: ldc ''
    //   729: invokevirtual length : ()I
    //   732: pop
    //   733: ldc_w ' '
    //   736: invokevirtual length : ()I
    //   739: ldc_w ' '
    //   742: invokevirtual length : ()I
    //   745: ineg
    //   746: if_icmpgt -> 1305
    //   749: fconst_0
    //   750: freturn
    //   751: iload #19
    //   753: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   756: bipush #12
    //   758: iaload
    //   759: invokestatic lllllllIllllIII : (II)Z
    //   762: ifeq -> 803
    //   765: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   768: iconst_3
    //   769: iaload
    //   770: istore #10
    //   772: ldc ''
    //   774: invokevirtual length : ()I
    //   777: pop
    //   778: ldc_w ' '
    //   781: invokevirtual length : ()I
    //   784: ldc_w ' '
    //   787: invokevirtual length : ()I
    //   790: ldc_w ' '
    //   793: invokevirtual length : ()I
    //   796: ishl
    //   797: ishl
    //   798: ifgt -> 1305
    //   801: fconst_0
    //   802: freturn
    //   803: iload #19
    //   805: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   808: bipush #15
    //   810: iaload
    //   811: invokestatic lllllllIllllIII : (II)Z
    //   814: ifeq -> 950
    //   817: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   820: iconst_3
    //   821: iaload
    //   822: istore #11
    //   824: iload #12
    //   826: invokestatic lllllllIllllIlI : (I)Z
    //   829: ifeq -> 902
    //   832: aload_0
    //   833: <illegal opcode> 30 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   838: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   843: <illegal opcode> 26 : (I)V
    //   848: aload_0
    //   849: <illegal opcode> 31 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   854: astore #9
    //   856: ldc ''
    //   858: invokevirtual length : ()I
    //   861: pop
    //   862: ldc_w '   '
    //   865: invokevirtual length : ()I
    //   868: ldc_w ' '
    //   871: invokevirtual length : ()I
    //   874: ldc_w ' '
    //   877: invokevirtual length : ()I
    //   880: ishl
    //   881: ishl
    //   882: ldc_w ' '
    //   885: invokevirtual length : ()I
    //   888: ldc_w '   '
    //   891: invokevirtual length : ()I
    //   894: ishl
    //   895: ixor
    //   896: ineg
    //   897: ifle -> 1305
    //   900: fconst_0
    //   901: freturn
    //   902: aload_0
    //   903: <illegal opcode> 32 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   908: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   913: <illegal opcode> 26 : (I)V
    //   918: aload_0
    //   919: <illegal opcode> 33 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   924: astore #9
    //   926: ldc ''
    //   928: invokevirtual length : ()I
    //   931: pop
    //   932: ldc_w ' '
    //   935: invokevirtual length : ()I
    //   938: ldc_w ' '
    //   941: invokevirtual length : ()I
    //   944: ineg
    //   945: if_icmpge -> 1305
    //   948: fconst_0
    //   949: freturn
    //   950: iload #19
    //   952: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   955: iconst_4
    //   956: iaload
    //   957: invokestatic lllllllIllllIII : (II)Z
    //   960: ifeq -> 1008
    //   963: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   966: iconst_3
    //   967: iaload
    //   968: istore #13
    //   970: ldc ''
    //   972: invokevirtual length : ()I
    //   975: pop
    //   976: ldc_w ' '
    //   979: invokevirtual length : ()I
    //   982: ldc_w ' '
    //   985: invokevirtual length : ()I
    //   988: ldc_w ' '
    //   991: invokevirtual length : ()I
    //   994: ishl
    //   995: ishl
    //   996: ldc_w ' '
    //   999: invokevirtual length : ()I
    //   1002: ineg
    //   1003: if_icmpne -> 1305
    //   1006: fconst_0
    //   1007: freturn
    //   1008: iload #19
    //   1010: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1013: bipush #16
    //   1015: iaload
    //   1016: invokestatic lllllllIllllIII : (II)Z
    //   1019: ifeq -> 1052
    //   1022: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1025: iconst_3
    //   1026: iaload
    //   1027: istore #14
    //   1029: ldc ''
    //   1031: invokevirtual length : ()I
    //   1034: pop
    //   1035: ldc_w '   '
    //   1038: invokevirtual length : ()I
    //   1041: ldc_w ' '
    //   1044: invokevirtual length : ()I
    //   1047: if_icmpge -> 1305
    //   1050: fconst_0
    //   1051: freturn
    //   1052: iload #19
    //   1054: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1057: bipush #17
    //   1059: iaload
    //   1060: invokestatic lllllllIllllIII : (II)Z
    //   1063: ifeq -> 1183
    //   1066: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1069: iconst_3
    //   1070: iaload
    //   1071: istore #12
    //   1073: iload #11
    //   1075: invokestatic lllllllIllllIlI : (I)Z
    //   1078: ifeq -> 1122
    //   1081: aload_0
    //   1082: <illegal opcode> 30 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   1087: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   1092: <illegal opcode> 26 : (I)V
    //   1097: aload_0
    //   1098: <illegal opcode> 31 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   1103: astore #9
    //   1105: ldc ''
    //   1107: invokevirtual length : ()I
    //   1110: pop
    //   1111: ldc_w ' '
    //   1114: invokevirtual length : ()I
    //   1117: ifne -> 1305
    //   1120: fconst_0
    //   1121: freturn
    //   1122: aload_0
    //   1123: <illegal opcode> 34 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   1128: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   1133: <illegal opcode> 26 : (I)V
    //   1138: aload_0
    //   1139: <illegal opcode> 35 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   1144: astore #9
    //   1146: ldc ''
    //   1148: invokevirtual length : ()I
    //   1151: pop
    //   1152: ldc_w ' '
    //   1155: invokevirtual length : ()I
    //   1158: ldc_w ' '
    //   1161: invokevirtual length : ()I
    //   1164: ishl
    //   1165: ldc_w ' '
    //   1168: invokevirtual length : ()I
    //   1171: ldc_w ' '
    //   1174: invokevirtual length : ()I
    //   1177: ishl
    //   1178: if_icmpeq -> 1305
    //   1181: fconst_0
    //   1182: freturn
    //   1183: iload #19
    //   1185: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1188: bipush #11
    //   1190: iaload
    //   1191: invokestatic lllllllIllllIII : (II)Z
    //   1194: ifeq -> 1305
    //   1197: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1200: iconst_2
    //   1201: iaload
    //   1202: istore #11
    //   1204: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1207: iconst_2
    //   1208: iaload
    //   1209: istore #12
    //   1211: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1214: iconst_2
    //   1215: iaload
    //   1216: istore #10
    //   1218: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1221: iconst_2
    //   1222: iaload
    //   1223: istore #14
    //   1225: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1228: iconst_2
    //   1229: iaload
    //   1230: istore #13
    //   1232: aload #8
    //   1234: <illegal opcode> 12 : (Lme/stupitdog/bhp/f01;)I
    //   1239: i2f
    //   1240: ldc 255.0
    //   1242: fdiv
    //   1243: aload #8
    //   1245: <illegal opcode> 13 : (Lme/stupitdog/bhp/f01;)I
    //   1250: i2f
    //   1251: ldc 255.0
    //   1253: fdiv
    //   1254: aload #8
    //   1256: <illegal opcode> 14 : (Lme/stupitdog/bhp/f01;)I
    //   1261: i2f
    //   1262: ldc 255.0
    //   1264: fdiv
    //   1265: aload #8
    //   1267: <illegal opcode> 15 : (Lme/stupitdog/bhp/f01;)I
    //   1272: i2f
    //   1273: ldc 255.0
    //   1275: fdiv
    //   1276: <illegal opcode> 21 : (FFFF)V
    //   1281: aload_0
    //   1282: <illegal opcode> 24 : (Lme/stupitdog/bhp/fa;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   1287: <illegal opcode> 25 : (Lnet/minecraft/client/renderer/texture/DynamicTexture;)I
    //   1292: <illegal opcode> 26 : (I)V
    //   1297: aload_0
    //   1298: <illegal opcode> 16 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   1303: astore #9
    //   1305: iinc #17, 1
    //   1308: ldc ''
    //   1310: invokevirtual length : ()I
    //   1313: pop
    //   1314: ldc_w ' '
    //   1317: invokevirtual length : ()I
    //   1320: ldc_w ' '
    //   1323: invokevirtual length : ()I
    //   1326: ishl
    //   1327: ldc_w ' '
    //   1330: invokevirtual length : ()I
    //   1333: if_icmpge -> 1554
    //   1336: fconst_0
    //   1337: freturn
    //   1338: iload #18
    //   1340: aload #9
    //   1342: arraylength
    //   1343: invokestatic lllllllIllllIIl : (II)Z
    //   1346: ifeq -> 1554
    //   1349: iload #18
    //   1351: invokestatic lllllllIllllIll : (I)Z
    //   1354: ifeq -> 1554
    //   1357: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1360: bipush #7
    //   1362: iaload
    //   1363: <illegal opcode> 36 : (I)V
    //   1368: aload_0
    //   1369: aload #9
    //   1371: iload #18
    //   1373: dload_2
    //   1374: d2f
    //   1375: dload #4
    //   1377: d2f
    //   1378: <illegal opcode> 37 : (Lme/stupitdog/bhp/fa;[Lme/stupitdog/bhp/f14$CharData;CFF)V
    //   1383: <illegal opcode> 38 : ()V
    //   1388: iload #13
    //   1390: invokestatic lllllllIllllIlI : (I)Z
    //   1393: ifeq -> 1459
    //   1396: aload_0
    //   1397: dload_2
    //   1398: dload #4
    //   1400: aload #9
    //   1402: iload #18
    //   1404: aaload
    //   1405: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1410: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1413: iconst_5
    //   1414: iaload
    //   1415: idiv
    //   1416: i2d
    //   1417: dadd
    //   1418: dload_2
    //   1419: aload #9
    //   1421: iload #18
    //   1423: aaload
    //   1424: <illegal opcode> 40 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1429: i2d
    //   1430: dadd
    //   1431: ldc2_w 8.0
    //   1434: dsub
    //   1435: dload #4
    //   1437: aload #9
    //   1439: iload #18
    //   1441: aaload
    //   1442: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1447: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1450: iconst_5
    //   1451: iaload
    //   1452: idiv
    //   1453: i2d
    //   1454: dadd
    //   1455: fconst_1
    //   1456: invokespecial drawLine : (DDDDF)V
    //   1459: iload #14
    //   1461: invokestatic lllllllIllllIlI : (I)Z
    //   1464: ifeq -> 1526
    //   1467: aload_0
    //   1468: dload_2
    //   1469: dload #4
    //   1471: aload #9
    //   1473: iload #18
    //   1475: aaload
    //   1476: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1481: i2d
    //   1482: dadd
    //   1483: ldc2_w 2.0
    //   1486: dsub
    //   1487: dload_2
    //   1488: aload #9
    //   1490: iload #18
    //   1492: aaload
    //   1493: <illegal opcode> 40 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1498: i2d
    //   1499: dadd
    //   1500: ldc2_w 8.0
    //   1503: dsub
    //   1504: dload #4
    //   1506: aload #9
    //   1508: iload #18
    //   1510: aaload
    //   1511: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1516: i2d
    //   1517: dadd
    //   1518: ldc2_w 2.0
    //   1521: dsub
    //   1522: fconst_1
    //   1523: invokespecial drawLine : (DDDDF)V
    //   1526: dload_2
    //   1527: aload #9
    //   1529: iload #18
    //   1531: aaload
    //   1532: <illegal opcode> 40 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   1537: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1540: bipush #14
    //   1542: iaload
    //   1543: isub
    //   1544: aload_0
    //   1545: <illegal opcode> 41 : (Lme/stupitdog/bhp/fa;)I
    //   1550: iadd
    //   1551: i2d
    //   1552: dadd
    //   1553: dstore_2
    //   1554: iinc #17, 1
    //   1557: ldc ''
    //   1559: invokevirtual length : ()I
    //   1562: pop
    //   1563: bipush #94
    //   1565: bipush #97
    //   1567: ixor
    //   1568: bipush #10
    //   1570: bipush #29
    //   1572: ixor
    //   1573: ldc_w ' '
    //   1576: invokevirtual length : ()I
    //   1579: ishl
    //   1580: ixor
    //   1581: ldc_w ' '
    //   1584: invokevirtual length : ()I
    //   1587: ldc_w ' '
    //   1590: invokevirtual length : ()I
    //   1593: ishl
    //   1594: ishl
    //   1595: sipush #187
    //   1598: sipush #170
    //   1601: ixor
    //   1602: ldc_w ' '
    //   1605: invokevirtual length : ()I
    //   1608: ishl
    //   1609: sipush #247
    //   1612: sipush #196
    //   1615: ixor
    //   1616: ixor
    //   1617: ldc_w ' '
    //   1620: invokevirtual length : ()I
    //   1623: ldc_w ' '
    //   1626: invokevirtual length : ()I
    //   1629: ishl
    //   1630: ishl
    //   1631: ldc_w ' '
    //   1634: invokevirtual length : ()I
    //   1637: ineg
    //   1638: ixor
    //   1639: iand
    //   1640: ifeq -> 434
    //   1643: fconst_0
    //   1644: freturn
    //   1645: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1648: bipush #18
    //   1650: iaload
    //   1651: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   1654: bipush #19
    //   1656: iaload
    //   1657: <illegal opcode> 42 : (II)V
    //   1662: <illegal opcode> 43 : ()V
    //   1667: dload_2
    //   1668: d2f
    //   1669: fconst_2
    //   1670: fdiv
    //   1671: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   661	66	20	lllllllllllllllIlllIIIlllIlIlIll	I
    //   486	822	19	lllllllllllllllIlllIIIlllIlIlIlI	I
    //   454	1100	18	lllllllllllllllIlllIIIlllIlIlIIl	C
    //   434	1211	17	lllllllllllllllIlllIIIlllIlIlIII	I
    //   406	1261	16	lllllllllllllllIlllIIIlllIlIIlll	I
    //   0	1672	0	lllllllllllllllIlllIIIlllIlIIllI	Lme/stupitdog/bhp/fa;
    //   0	1672	1	lllllllllllllllIlllIIIlllIlIIlIl	Ljava/lang/String;
    //   0	1672	2	lllllllllllllllIlllIIIlllIlIIlII	D
    //   0	1672	4	lllllllllllllllIlllIIIlllIlIIIll	D
    //   0	1672	6	lllllllllllllllIlllIIIlllIlIIIlI	Lme/stupitdog/bhp/f01;
    //   0	1672	7	lllllllllllllllIlllIIIlllIlIIIIl	Z
    //   23	1649	8	lllllllllllllllIlllIIIlllIlIIIII	Lme/stupitdog/bhp/f01;
    //   244	1428	9	lllllllllllllllIlllIIIlllIIlllll	[Lme/stupitdog/bhp/f14$CharData;
    //   251	1421	10	lllllllllllllllIlllIIIlllIIllllI	Z
    //   258	1414	11	lllllllllllllllIlllIIIlllIIlllIl	Z
    //   265	1407	12	lllllllllllllllIlllIIIlllIIlllII	Z
    //   272	1400	13	lllllllllllllllIlllIIIlllIIllIll	Z
    //   279	1393	14	lllllllllllllllIlllIIIlllIIllIlI	Z
    //   286	1386	15	lllllllllllllllIlllIIIlllIIllIIl	Z
    // Exception table:
    //   from	to	target	type
    //   486	516	534	java/lang/Exception
  }
  
  public int getStringWidth(String lllllllllllllllIlllIIIlllIIlIlII) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic lllllllIlllIlll : (Ljava/lang/Object;)Z
    //   4: ifeq -> 13
    //   7: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   10: iconst_2
    //   11: iaload
    //   12: ireturn
    //   13: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   16: iconst_2
    //   17: iaload
    //   18: istore_2
    //   19: aload_0
    //   20: <illegal opcode> 16 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   25: astore_3
    //   26: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   29: iconst_2
    //   30: iaload
    //   31: istore #4
    //   33: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   36: iconst_2
    //   37: iaload
    //   38: istore #5
    //   40: aload_1
    //   41: <illegal opcode> 22 : (Ljava/lang/String;)I
    //   46: istore #6
    //   48: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   51: iconst_2
    //   52: iaload
    //   53: istore #7
    //   55: iload #7
    //   57: iload #6
    //   59: invokestatic lllllllIllllIIl : (II)Z
    //   62: ifeq -> 793
    //   65: aload_1
    //   66: iload #7
    //   68: <illegal opcode> 27 : (Ljava/lang/String;I)C
    //   73: istore #8
    //   75: iload #8
    //   77: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   80: bipush #10
    //   82: iaload
    //   83: invokestatic lllllllIllllIII : (II)Z
    //   86: ifeq -> 707
    //   89: iload #7
    //   91: iload #6
    //   93: invokestatic lllllllIllllIIl : (II)Z
    //   96: ifeq -> 707
    //   99: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   102: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   105: bipush #20
    //   107: iaload
    //   108: aaload
    //   109: iload #8
    //   111: <illegal opcode> 28 : (Ljava/lang/String;I)I
    //   116: istore #9
    //   118: iload #9
    //   120: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   123: bipush #12
    //   125: iaload
    //   126: invokestatic lllllllIllllIIl : (II)Z
    //   129: ifeq -> 177
    //   132: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   135: iconst_2
    //   136: iaload
    //   137: istore #4
    //   139: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   142: iconst_2
    //   143: iaload
    //   144: istore #5
    //   146: ldc ''
    //   148: invokevirtual length : ()I
    //   151: pop
    //   152: ldc_w '   '
    //   155: invokevirtual length : ()I
    //   158: ifge -> 570
    //   161: sipush #217
    //   164: sipush #158
    //   167: ixor
    //   168: bipush #37
    //   170: bipush #98
    //   172: ixor
    //   173: iconst_m1
    //   174: ixor
    //   175: iand
    //   176: ireturn
    //   177: iload #9
    //   179: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   182: bipush #15
    //   184: iaload
    //   185: invokestatic lllllllIllllIII : (II)Z
    //   188: ifeq -> 352
    //   191: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   194: iconst_3
    //   195: iaload
    //   196: istore #4
    //   198: iload #5
    //   200: invokestatic lllllllIllllIlI : (I)Z
    //   203: ifeq -> 271
    //   206: aload_0
    //   207: <illegal opcode> 31 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   212: astore_3
    //   213: ldc ''
    //   215: invokevirtual length : ()I
    //   218: pop
    //   219: ldc_w '   '
    //   222: invokevirtual length : ()I
    //   225: bipush #70
    //   227: bipush #75
    //   229: ixor
    //   230: ldc_w ' '
    //   233: invokevirtual length : ()I
    //   236: ishl
    //   237: bipush #67
    //   239: bipush #78
    //   241: ixor
    //   242: ldc_w ' '
    //   245: invokevirtual length : ()I
    //   248: ishl
    //   249: iconst_m1
    //   250: ixor
    //   251: iand
    //   252: if_icmpgt -> 570
    //   255: bipush #68
    //   257: bipush #29
    //   259: ixor
    //   260: sipush #202
    //   263: sipush #147
    //   266: ixor
    //   267: iconst_m1
    //   268: ixor
    //   269: iand
    //   270: ireturn
    //   271: aload_0
    //   272: <illegal opcode> 33 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   277: astore_3
    //   278: ldc ''
    //   280: invokevirtual length : ()I
    //   283: pop
    //   284: ldc_w ' '
    //   287: invokevirtual length : ()I
    //   290: bipush #48
    //   292: bipush #53
    //   294: ixor
    //   295: ishl
    //   296: ldc_w ' '
    //   299: invokevirtual length : ()I
    //   302: sipush #144
    //   305: sipush #149
    //   308: ixor
    //   309: ishl
    //   310: iconst_m1
    //   311: ixor
    //   312: iand
    //   313: ldc_w ' '
    //   316: invokevirtual length : ()I
    //   319: if_icmplt -> 570
    //   322: bipush #65
    //   324: bipush #94
    //   326: ixor
    //   327: ldc_w ' '
    //   330: invokevirtual length : ()I
    //   333: ishl
    //   334: sipush #136
    //   337: sipush #151
    //   340: ixor
    //   341: ldc_w ' '
    //   344: invokevirtual length : ()I
    //   347: ishl
    //   348: iconst_m1
    //   349: ixor
    //   350: iand
    //   351: ireturn
    //   352: iload #9
    //   354: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   357: bipush #17
    //   359: iaload
    //   360: invokestatic lllllllIllllIII : (II)Z
    //   363: ifeq -> 535
    //   366: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   369: iconst_3
    //   370: iaload
    //   371: istore #5
    //   373: iload #4
    //   375: invokestatic lllllllIllllIlI : (I)Z
    //   378: ifeq -> 454
    //   381: aload_0
    //   382: <illegal opcode> 31 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   387: astore_3
    //   388: ldc ''
    //   390: invokevirtual length : ()I
    //   393: pop
    //   394: aconst_null
    //   395: ifnull -> 570
    //   398: bipush #64
    //   400: bipush #109
    //   402: ixor
    //   403: ldc_w ' '
    //   406: invokevirtual length : ()I
    //   409: ishl
    //   410: bipush #94
    //   412: bipush #57
    //   414: ixor
    //   415: ixor
    //   416: sipush #179
    //   419: sipush #188
    //   422: ixor
    //   423: ldc_w ' '
    //   426: invokevirtual length : ()I
    //   429: ldc_w ' '
    //   432: invokevirtual length : ()I
    //   435: ishl
    //   436: ishl
    //   437: ldc_w ' '
    //   440: invokevirtual length : ()I
    //   443: ixor
    //   444: ldc_w ' '
    //   447: invokevirtual length : ()I
    //   450: ineg
    //   451: ixor
    //   452: iand
    //   453: ireturn
    //   454: aload_0
    //   455: <illegal opcode> 35 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   460: astore_3
    //   461: ldc ''
    //   463: invokevirtual length : ()I
    //   466: pop
    //   467: ldc_w '   '
    //   470: invokevirtual length : ()I
    //   473: ldc_w ' '
    //   476: invokevirtual length : ()I
    //   479: ishl
    //   480: ldc_w '   '
    //   483: invokevirtual length : ()I
    //   486: ldc_w ' '
    //   489: invokevirtual length : ()I
    //   492: ishl
    //   493: iconst_m1
    //   494: ixor
    //   495: iand
    //   496: ldc_w ' '
    //   499: invokevirtual length : ()I
    //   502: ldc_w ' '
    //   505: invokevirtual length : ()I
    //   508: ldc_w ' '
    //   511: invokevirtual length : ()I
    //   514: ishl
    //   515: ishl
    //   516: if_icmpne -> 570
    //   519: ldc_w '   '
    //   522: invokevirtual length : ()I
    //   525: ldc_w '   '
    //   528: invokevirtual length : ()I
    //   531: iconst_m1
    //   532: ixor
    //   533: iand
    //   534: ireturn
    //   535: iload #9
    //   537: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   540: bipush #11
    //   542: iaload
    //   543: invokestatic lllllllIllllIII : (II)Z
    //   546: ifeq -> 570
    //   549: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   552: iconst_2
    //   553: iaload
    //   554: istore #4
    //   556: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   559: iconst_2
    //   560: iaload
    //   561: istore #5
    //   563: aload_0
    //   564: <illegal opcode> 16 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   569: astore_3
    //   570: iinc #7, 1
    //   573: ldc ''
    //   575: invokevirtual length : ()I
    //   578: pop
    //   579: sipush #164
    //   582: sipush #183
    //   585: ixor
    //   586: ldc_w ' '
    //   589: invokevirtual length : ()I
    //   592: ldc_w ' '
    //   595: invokevirtual length : ()I
    //   598: ishl
    //   599: ishl
    //   600: bipush #13
    //   602: bipush #16
    //   604: ixor
    //   605: ixor
    //   606: bipush #37
    //   608: bipush #40
    //   610: ixor
    //   611: ldc_w ' '
    //   614: invokevirtual length : ()I
    //   617: ishl
    //   618: sipush #223
    //   621: sipush #148
    //   624: ixor
    //   625: ixor
    //   626: ldc_w ' '
    //   629: invokevirtual length : ()I
    //   632: ineg
    //   633: ixor
    //   634: iand
    //   635: ifle -> 751
    //   638: sipush #131
    //   641: sipush #146
    //   644: ixor
    //   645: ldc_w ' '
    //   648: invokevirtual length : ()I
    //   651: ldc_w ' '
    //   654: invokevirtual length : ()I
    //   657: ishl
    //   658: ishl
    //   659: bipush #50
    //   661: bipush #81
    //   663: ixor
    //   664: ixor
    //   665: ldc_w ' '
    //   668: invokevirtual length : ()I
    //   671: ishl
    //   672: bipush #43
    //   674: iconst_4
    //   675: ixor
    //   676: ldc_w ' '
    //   679: invokevirtual length : ()I
    //   682: ldc_w '   '
    //   685: invokevirtual length : ()I
    //   688: ishl
    //   689: ixor
    //   690: ldc_w ' '
    //   693: invokevirtual length : ()I
    //   696: ishl
    //   697: ldc_w ' '
    //   700: invokevirtual length : ()I
    //   703: ineg
    //   704: ixor
    //   705: iand
    //   706: ireturn
    //   707: iload #8
    //   709: aload_3
    //   710: arraylength
    //   711: invokestatic lllllllIllllIIl : (II)Z
    //   714: ifeq -> 751
    //   717: iload #8
    //   719: invokestatic lllllllIllllIll : (I)Z
    //   722: ifeq -> 751
    //   725: iload_2
    //   726: aload_3
    //   727: iload #8
    //   729: aaload
    //   730: <illegal opcode> 40 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   735: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   738: bipush #14
    //   740: iaload
    //   741: isub
    //   742: aload_0
    //   743: <illegal opcode> 41 : (Lme/stupitdog/bhp/fa;)I
    //   748: iadd
    //   749: iadd
    //   750: istore_2
    //   751: iinc #7, 1
    //   754: ldc ''
    //   756: invokevirtual length : ()I
    //   759: pop
    //   760: ldc_w ' '
    //   763: invokevirtual length : ()I
    //   766: ldc_w ' '
    //   769: invokevirtual length : ()I
    //   772: if_icmpeq -> 55
    //   775: sipush #151
    //   778: sipush #134
    //   781: ixor
    //   782: sipush #178
    //   785: sipush #163
    //   788: ixor
    //   789: iconst_m1
    //   790: ixor
    //   791: iand
    //   792: ireturn
    //   793: iload_2
    //   794: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   797: iconst_5
    //   798: iaload
    //   799: idiv
    //   800: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   118	455	9	lllllllllllllllIlllIIIlllIIllIII	I
    //   75	676	8	lllllllllllllllIlllIIIlllIIlIlll	C
    //   55	738	7	lllllllllllllllIlllIIIlllIIlIllI	I
    //   0	801	0	lllllllllllllllIlllIIIlllIIlIlIl	Lme/stupitdog/bhp/fa;
    //   0	801	1	lllllllllllllllIlllIIIlllIIlIlII	Ljava/lang/String;
    //   19	782	2	lllllllllllllllIlllIIIlllIIlIIll	I
    //   26	775	3	lllllllllllllllIlllIIIlllIIlIIlI	[Lme/stupitdog/bhp/f14$CharData;
    //   33	768	4	lllllllllllllllIlllIIIlllIIlIIIl	Z
    //   40	761	5	lllllllllllllllIlllIIIlllIIlIIII	Z
    //   48	753	6	lllllllllllllllIlllIIIlllIIIllll	I
  }
  
  public void setFont(Font lllllllllllllllIlllIIIlllIIIllIl) {
    super.setFont(lllllllllllllllIlllIIIlllIIIllIl);
    setupBoldItalicIDs();
  }
  
  public void setAntiAlias(boolean lllllllllllllllIlllIIIlllIIIlIll) {
    super.setAntiAlias(lllllllllllllllIlllIIIlllIIIlIll);
    setupBoldItalicIDs();
  }
  
  public void setFractionalMetrics(boolean lllllllllllllllIlllIIIlllIIIlIIl) {
    super.setFractionalMetrics(lllllllllllllllIlllIIIlllIIIlIIl);
    setupBoldItalicIDs();
  }
  
  private void setupBoldItalicIDs() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: aload_0
    //   3: <illegal opcode> 44 : (Lme/stupitdog/bhp/fa;)Ljava/awt/Font;
    //   8: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   11: iconst_3
    //   12: iaload
    //   13: <illegal opcode> 45 : (Ljava/awt/Font;I)Ljava/awt/Font;
    //   18: aload_0
    //   19: <illegal opcode> 46 : (Lme/stupitdog/bhp/fa;)Z
    //   24: aload_0
    //   25: <illegal opcode> 47 : (Lme/stupitdog/bhp/fa;)Z
    //   30: aload_0
    //   31: <illegal opcode> 33 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   36: <illegal opcode> 48 : (Lme/stupitdog/bhp/fa;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   41: <illegal opcode> 49 : (Lme/stupitdog/bhp/fa;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   46: aload_0
    //   47: aload_0
    //   48: aload_0
    //   49: <illegal opcode> 44 : (Lme/stupitdog/bhp/fa;)Ljava/awt/Font;
    //   54: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   57: iconst_5
    //   58: iaload
    //   59: <illegal opcode> 45 : (Ljava/awt/Font;I)Ljava/awt/Font;
    //   64: aload_0
    //   65: <illegal opcode> 46 : (Lme/stupitdog/bhp/fa;)Z
    //   70: aload_0
    //   71: <illegal opcode> 47 : (Lme/stupitdog/bhp/fa;)Z
    //   76: aload_0
    //   77: <illegal opcode> 35 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   82: <illegal opcode> 48 : (Lme/stupitdog/bhp/fa;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   87: <illegal opcode> 50 : (Lme/stupitdog/bhp/fa;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   92: aload_0
    //   93: aload_0
    //   94: aload_0
    //   95: <illegal opcode> 44 : (Lme/stupitdog/bhp/fa;)Ljava/awt/Font;
    //   100: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   103: bipush #20
    //   105: iaload
    //   106: <illegal opcode> 45 : (Ljava/awt/Font;I)Ljava/awt/Font;
    //   111: aload_0
    //   112: <illegal opcode> 46 : (Lme/stupitdog/bhp/fa;)Z
    //   117: aload_0
    //   118: <illegal opcode> 47 : (Lme/stupitdog/bhp/fa;)Z
    //   123: aload_0
    //   124: <illegal opcode> 31 : (Lme/stupitdog/bhp/fa;)[Lme/stupitdog/bhp/f14$CharData;
    //   129: <illegal opcode> 48 : (Lme/stupitdog/bhp/fa;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   134: <illegal opcode> 51 : (Lme/stupitdog/bhp/fa;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   139: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	140	0	lllllllllllllllIlllIIIlllIIIlIII	Lme/stupitdog/bhp/fa;
  }
  
  private void drawLine(double lllllllllllllllIlllIIIlllIIIIllI, double lllllllllllllllIlllIIIlllIIIIlIl, double lllllllllllllllIlllIIIlllIIIIlII, double lllllllllllllllIlllIIIlllIIIIIll, float lllllllllllllllIlllIIIlllIIIIIlI) {
    // Byte code:
    //   0: <illegal opcode> 52 : ()V
    //   5: fload #9
    //   7: <illegal opcode> 53 : (F)V
    //   12: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   15: iconst_3
    //   16: iaload
    //   17: <illegal opcode> 36 : (I)V
    //   22: dload_1
    //   23: dload_3
    //   24: <illegal opcode> 54 : (DD)V
    //   29: dload #5
    //   31: dload #7
    //   33: <illegal opcode> 54 : (DD)V
    //   38: <illegal opcode> 38 : ()V
    //   43: <illegal opcode> 23 : ()V
    //   48: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	49	0	lllllllllllllllIlllIIIlllIIIIlll	Lme/stupitdog/bhp/fa;
    //   0	49	1	lllllllllllllllIlllIIIlllIIIIllI	D
    //   0	49	3	lllllllllllllllIlllIIIlllIIIIlIl	D
    //   0	49	5	lllllllllllllllIlllIIIlllIIIIlII	D
    //   0	49	7	lllllllllllllllIlllIIIlllIIIIIll	D
    //   0	49	9	lllllllllllllllIlllIIIlllIIIIIlI	F
  }
  
  public List<String> wrapWords(String lllllllllllllllIlllIIIllIllllIIl, double lllllllllllllllIlllIIIllIllllIII) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_0
    //   10: aload_1
    //   11: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   16: i2d
    //   17: dload_2
    //   18: invokestatic lllllllIlllllIl : (DD)I
    //   21: invokestatic lllllllIlllllll : (I)Z
    //   24: ifeq -> 651
    //   27: aload_1
    //   28: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   31: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   34: bipush #7
    //   36: iaload
    //   37: aaload
    //   38: <illegal opcode> 55 : (Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;
    //   43: astore #5
    //   45: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   48: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   51: bipush #21
    //   53: iaload
    //   54: aaload
    //   55: astore #6
    //   57: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   60: bipush #22
    //   62: iaload
    //   63: istore #7
    //   65: aload #5
    //   67: astore #8
    //   69: aload #8
    //   71: arraylength
    //   72: istore #9
    //   74: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   77: iconst_2
    //   78: iaload
    //   79: istore #10
    //   81: iload #10
    //   83: iload #9
    //   85: invokestatic lllllllIllllIIl : (II)Z
    //   88: ifeq -> 408
    //   91: aload #8
    //   93: iload #10
    //   95: aaload
    //   96: astore #11
    //   98: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   101: iconst_2
    //   102: iaload
    //   103: istore #12
    //   105: iload #12
    //   107: aload #11
    //   109: <illegal opcode> 56 : (Ljava/lang/String;)[C
    //   114: arraylength
    //   115: invokestatic lllllllIllllIIl : (II)Z
    //   118: ifeq -> 207
    //   121: aload #11
    //   123: <illegal opcode> 56 : (Ljava/lang/String;)[C
    //   128: iload #12
    //   130: caload
    //   131: istore #13
    //   133: iload #13
    //   135: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   138: bipush #10
    //   140: iaload
    //   141: invokestatic lllllllIllllIII : (II)Z
    //   144: ifeq -> 187
    //   147: iload #12
    //   149: aload #11
    //   151: <illegal opcode> 56 : (Ljava/lang/String;)[C
    //   156: arraylength
    //   157: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   160: iconst_3
    //   161: iaload
    //   162: isub
    //   163: invokestatic lllllllIllllIIl : (II)Z
    //   166: ifeq -> 187
    //   169: aload #11
    //   171: <illegal opcode> 56 : (Ljava/lang/String;)[C
    //   176: iload #12
    //   178: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   181: iconst_3
    //   182: iaload
    //   183: iadd
    //   184: caload
    //   185: istore #7
    //   187: iinc #12, 1
    //   190: ldc ''
    //   192: invokevirtual length : ()I
    //   195: pop
    //   196: ldc_w '   '
    //   199: invokevirtual length : ()I
    //   202: ifgt -> 105
    //   205: aconst_null
    //   206: areturn
    //   207: aload_0
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: aload #6
    //   217: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: aload #11
    //   224: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   232: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   235: bipush #23
    //   237: iaload
    //   238: aaload
    //   239: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   249: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   254: i2d
    //   255: dload_2
    //   256: invokestatic lllllllIllllllI : (DD)I
    //   259: invokestatic llllllllIIIIIII : (I)Z
    //   262: ifeq -> 320
    //   265: new java/lang/StringBuilder
    //   268: dup
    //   269: invokespecial <init> : ()V
    //   272: aload #6
    //   274: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: aload #11
    //   281: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   289: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   292: bipush #24
    //   294: iaload
    //   295: aaload
    //   296: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   306: astore #6
    //   308: ldc ''
    //   310: invokevirtual length : ()I
    //   313: pop
    //   314: aconst_null
    //   315: ifnull -> 393
    //   318: aconst_null
    //   319: areturn
    //   320: aload #4
    //   322: aload #6
    //   324: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   329: ldc ''
    //   331: invokevirtual length : ()I
    //   334: pop2
    //   335: new java/lang/StringBuilder
    //   338: dup
    //   339: invokespecial <init> : ()V
    //   342: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   345: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   348: bipush #14
    //   350: iaload
    //   351: aaload
    //   352: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: iload #7
    //   359: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   364: aload #11
    //   366: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   371: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   374: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   377: bipush #25
    //   379: iaload
    //   380: aaload
    //   381: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   386: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   391: astore #6
    //   393: iinc #10, 1
    //   396: ldc ''
    //   398: invokevirtual length : ()I
    //   401: pop
    //   402: aconst_null
    //   403: ifnull -> 81
    //   406: aconst_null
    //   407: areturn
    //   408: aload #6
    //   410: <illegal opcode> 22 : (Ljava/lang/String;)I
    //   415: invokestatic lllllllIlllllll : (I)Z
    //   418: ifeq -> 620
    //   421: aload_0
    //   422: aload #6
    //   424: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   429: i2d
    //   430: dload_2
    //   431: invokestatic lllllllIllllllI : (DD)I
    //   434: invokestatic llllllllIIIIIII : (I)Z
    //   437: ifeq -> 546
    //   440: aload #4
    //   442: new java/lang/StringBuilder
    //   445: dup
    //   446: invokespecial <init> : ()V
    //   449: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   452: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   455: bipush #26
    //   457: iaload
    //   458: aaload
    //   459: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   464: iload #7
    //   466: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   471: aload #6
    //   473: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   478: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   481: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   484: bipush #27
    //   486: iaload
    //   487: aaload
    //   488: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   498: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   503: ldc ''
    //   505: invokevirtual length : ()I
    //   508: pop2
    //   509: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   512: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   515: bipush #28
    //   517: iaload
    //   518: aaload
    //   519: astore #6
    //   521: ldc ''
    //   523: invokevirtual length : ()I
    //   526: pop
    //   527: ldc_w ' '
    //   530: invokevirtual length : ()I
    //   533: ineg
    //   534: ldc_w ' '
    //   537: invokevirtual length : ()I
    //   540: ineg
    //   541: if_icmpge -> 620
    //   544: aconst_null
    //   545: areturn
    //   546: aload_0
    //   547: aload #6
    //   549: dload_2
    //   550: <illegal opcode> 61 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;D)Ljava/util/List;
    //   555: <illegal opcode> 62 : (Ljava/util/List;)Ljava/util/Iterator;
    //   560: astore #8
    //   562: aload #8
    //   564: <illegal opcode> 63 : (Ljava/util/Iterator;)Z
    //   569: invokestatic lllllllIllllIlI : (I)Z
    //   572: ifeq -> 620
    //   575: aload #8
    //   577: <illegal opcode> 64 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   582: checkcast java/lang/String
    //   585: astore #9
    //   587: aload #4
    //   589: aload #9
    //   591: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   596: ldc ''
    //   598: invokevirtual length : ()I
    //   601: pop2
    //   602: ldc ''
    //   604: invokevirtual length : ()I
    //   607: pop
    //   608: ldc_w ' '
    //   611: invokevirtual length : ()I
    //   614: ineg
    //   615: ifle -> 562
    //   618: aconst_null
    //   619: areturn
    //   620: ldc ''
    //   622: invokevirtual length : ()I
    //   625: pop
    //   626: ldc_w ' '
    //   629: invokevirtual length : ()I
    //   632: ldc_w ' '
    //   635: invokevirtual length : ()I
    //   638: ldc_w ' '
    //   641: invokevirtual length : ()I
    //   644: ishl
    //   645: ishl
    //   646: ifne -> 665
    //   649: aconst_null
    //   650: areturn
    //   651: aload #4
    //   653: aload_1
    //   654: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   659: ldc ''
    //   661: invokevirtual length : ()I
    //   664: pop2
    //   665: aload #4
    //   667: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   133	54	13	lllllllllllllllIlllIIIlllIIIIIIl	C
    //   105	102	12	lllllllllllllllIlllIIIlllIIIIIII	I
    //   98	295	11	lllllllllllllllIlllIIIllIlllllll	Ljava/lang/String;
    //   587	15	9	lllllllllllllllIlllIIIllIllllllI	Ljava/lang/String;
    //   45	575	5	lllllllllllllllIlllIIIllIlllllIl	[Ljava/lang/String;
    //   57	563	6	lllllllllllllllIlllIIIllIlllllII	Ljava/lang/String;
    //   65	555	7	lllllllllllllllIlllIIIllIllllIll	C
    //   0	668	0	lllllllllllllllIlllIIIllIllllIlI	Lme/stupitdog/bhp/fa;
    //   0	668	1	lllllllllllllllIlllIIIllIllllIIl	Ljava/lang/String;
    //   0	668	2	lllllllllllllllIlllIIIllIllllIII	D
    //   9	659	4	lllllllllllllllIlllIIIllIlllIlll	Ljava/util/List;
  }
  
  public List<String> formatString(String lllllllllllllllIlllIIIllIlllIIll, double lllllllllllllllIlllIIIllIlllIIlI) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   15: bipush #29
    //   17: iaload
    //   18: aaload
    //   19: astore #5
    //   21: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   24: bipush #22
    //   26: iaload
    //   27: istore #6
    //   29: aload_1
    //   30: <illegal opcode> 56 : (Ljava/lang/String;)[C
    //   35: astore #7
    //   37: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   40: iconst_2
    //   41: iaload
    //   42: istore #8
    //   44: iload #8
    //   46: aload #7
    //   48: arraylength
    //   49: invokestatic lllllllIllllIIl : (II)Z
    //   52: ifeq -> 288
    //   55: aload #7
    //   57: iload #8
    //   59: caload
    //   60: istore #9
    //   62: iload #9
    //   64: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   67: bipush #10
    //   69: iaload
    //   70: invokestatic lllllllIllllIII : (II)Z
    //   73: ifeq -> 106
    //   76: iload #8
    //   78: aload #7
    //   80: arraylength
    //   81: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   84: iconst_3
    //   85: iaload
    //   86: isub
    //   87: invokestatic lllllllIllllIIl : (II)Z
    //   90: ifeq -> 106
    //   93: aload #7
    //   95: iload #8
    //   97: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   100: iconst_3
    //   101: iaload
    //   102: iadd
    //   103: caload
    //   104: istore #6
    //   106: aload_0
    //   107: new java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: aload #5
    //   116: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: iload #9
    //   123: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   128: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   133: <illegal opcode> 9 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   138: i2d
    //   139: dload_2
    //   140: invokestatic llllllllIIIIIIl : (DD)I
    //   143: invokestatic llllllllIIIIIII : (I)Z
    //   146: ifeq -> 189
    //   149: new java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial <init> : ()V
    //   156: aload #5
    //   158: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: iload #9
    //   165: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   170: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   175: astore #5
    //   177: ldc ''
    //   179: invokevirtual length : ()I
    //   182: pop
    //   183: aconst_null
    //   184: ifnull -> 247
    //   187: aconst_null
    //   188: areturn
    //   189: aload #4
    //   191: aload #5
    //   193: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   198: ldc ''
    //   200: invokevirtual length : ()I
    //   203: pop2
    //   204: new java/lang/StringBuilder
    //   207: dup
    //   208: invokespecial <init> : ()V
    //   211: getstatic me/stupitdog/bhp/fa.lIllllIlllllll : [Ljava/lang/String;
    //   214: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   217: bipush #30
    //   219: iaload
    //   220: aaload
    //   221: <illegal opcode> 57 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: iload #6
    //   228: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   233: iload #9
    //   235: <illegal opcode> 60 : (Ljava/lang/StringBuilder;C)Ljava/lang/StringBuilder;
    //   240: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   245: astore #5
    //   247: iinc #8, 1
    //   250: ldc ''
    //   252: invokevirtual length : ()I
    //   255: pop
    //   256: ldc_w ' '
    //   259: invokevirtual length : ()I
    //   262: ineg
    //   263: ldc_w ' '
    //   266: invokevirtual length : ()I
    //   269: ldc_w ' '
    //   272: invokevirtual length : ()I
    //   275: ldc_w ' '
    //   278: invokevirtual length : ()I
    //   281: ishl
    //   282: ishl
    //   283: if_icmplt -> 44
    //   286: aconst_null
    //   287: areturn
    //   288: aload #5
    //   290: <illegal opcode> 22 : (Ljava/lang/String;)I
    //   295: invokestatic lllllllIlllllll : (I)Z
    //   298: ifeq -> 316
    //   301: aload #4
    //   303: aload #5
    //   305: <illegal opcode> 59 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   310: ldc ''
    //   312: invokevirtual length : ()I
    //   315: pop2
    //   316: aload #4
    //   318: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   62	185	9	lllllllllllllllIlllIIIllIlllIllI	C
    //   44	244	8	lllllllllllllllIlllIIIllIlllIlIl	I
    //   0	319	0	lllllllllllllllIlllIIIllIlllIlII	Lme/stupitdog/bhp/fa;
    //   0	319	1	lllllllllllllllIlllIIIllIlllIIll	Ljava/lang/String;
    //   0	319	2	lllllllllllllllIlllIIIllIlllIIlI	D
    //   9	310	4	lllllllllllllllIlllIIIllIlllIIIl	Ljava/util/List;
    //   21	298	5	lllllllllllllllIlllIIIllIlllIIII	Ljava/lang/String;
    //   29	290	6	lllllllllllllllIlllIIIllIllIllll	C
    //   37	282	7	lllllllllllllllIlllIIIllIllIlllI	[C
  }
  
  private void setupMinecraftColorcodes() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   3: iconst_2
    //   4: iaload
    //   5: istore_1
    //   6: iload_1
    //   7: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   10: iconst_1
    //   11: iaload
    //   12: invokestatic lllllllIllllIIl : (II)Z
    //   15: ifeq -> 253
    //   18: iload_1
    //   19: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   22: bipush #20
    //   24: iaload
    //   25: ishr
    //   26: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   29: iconst_3
    //   30: iaload
    //   31: iand
    //   32: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   35: bipush #31
    //   37: iaload
    //   38: imul
    //   39: istore_2
    //   40: iload_1
    //   41: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   44: iconst_5
    //   45: iaload
    //   46: ishr
    //   47: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   50: iconst_3
    //   51: iaload
    //   52: iand
    //   53: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   56: bipush #32
    //   58: iaload
    //   59: imul
    //   60: iload_2
    //   61: iadd
    //   62: istore_3
    //   63: iload_1
    //   64: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   67: iconst_3
    //   68: iaload
    //   69: ishr
    //   70: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   73: iconst_3
    //   74: iaload
    //   75: iand
    //   76: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   79: bipush #32
    //   81: iaload
    //   82: imul
    //   83: iload_2
    //   84: iadd
    //   85: istore #4
    //   87: iload_1
    //   88: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   91: iconst_2
    //   92: iaload
    //   93: ishr
    //   94: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   97: iconst_3
    //   98: iaload
    //   99: iand
    //   100: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   103: bipush #32
    //   105: iaload
    //   106: imul
    //   107: iload_2
    //   108: iadd
    //   109: istore #5
    //   111: iload_1
    //   112: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   115: bipush #23
    //   117: iaload
    //   118: invokestatic lllllllIllllIII : (II)Z
    //   121: ifeq -> 127
    //   124: iinc #3, 85
    //   127: iload_1
    //   128: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   131: bipush #12
    //   133: iaload
    //   134: invokestatic llllllllIIIIIlI : (II)Z
    //   137: ifeq -> 171
    //   140: iload_3
    //   141: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   144: bipush #7
    //   146: iaload
    //   147: idiv
    //   148: istore_3
    //   149: iload #4
    //   151: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   154: bipush #7
    //   156: iaload
    //   157: idiv
    //   158: istore #4
    //   160: iload #5
    //   162: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   165: bipush #7
    //   167: iaload
    //   168: idiv
    //   169: istore #5
    //   171: aload_0
    //   172: <illegal opcode> 29 : (Lme/stupitdog/bhp/fa;)[I
    //   177: iload_1
    //   178: iload_3
    //   179: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   182: bipush #6
    //   184: iaload
    //   185: iand
    //   186: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   189: bipush #12
    //   191: iaload
    //   192: ishl
    //   193: iload #4
    //   195: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   198: bipush #6
    //   200: iaload
    //   201: iand
    //   202: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   205: bipush #14
    //   207: iaload
    //   208: ishl
    //   209: ior
    //   210: iload #5
    //   212: getstatic me/stupitdog/bhp/fa.lIlllllIIIIlIl : [I
    //   215: bipush #6
    //   217: iaload
    //   218: iand
    //   219: ior
    //   220: iastore
    //   221: iinc #1, 1
    //   224: ldc ''
    //   226: invokevirtual length : ()I
    //   229: pop
    //   230: ldc_w ' '
    //   233: invokevirtual length : ()I
    //   236: bipush #26
    //   238: bipush #15
    //   240: ixor
    //   241: bipush #73
    //   243: bipush #92
    //   245: ixor
    //   246: iconst_m1
    //   247: ixor
    //   248: iand
    //   249: if_icmpne -> 6
    //   252: return
    //   253: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   40	181	2	lllllllllllllllIlllIIIllIllIllIl	I
    //   63	158	3	lllllllllllllllIlllIIIllIllIllII	I
    //   87	134	4	lllllllllllllllIlllIIIllIllIlIll	I
    //   111	110	5	lllllllllllllllIlllIIIllIllIlIlI	I
    //   6	247	1	lllllllllllllllIlllIIIllIllIlIIl	I
    //   0	254	0	lllllllllllllllIlllIIIllIllIlIII	Lme/stupitdog/bhp/fa;
  }
  
  static {
    lllllllIlllIllI();
    lllllllIlllIlIl();
    lllllllIlllIlII();
    lllllllIllIllll();
  }
  
  private static CallSite lllllllIIlIIIll(MethodHandles.Lookup lllllllllllllllIlllIIIllIlIlllll, String lllllllllllllllIlllIIIllIlIllllI, MethodType lllllllllllllllIlllIIIllIlIlllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIllIllIIlIl = lIllllIlIllllI[Integer.parseInt(lllllllllllllllIlllIIIllIlIllllI)].split(lIllllIlllllll[lIlllllIIIIlIl[13]]);
      Class<?> lllllllllllllllIlllIIIllIllIIlII = Class.forName(lllllllllllllllIlllIIIllIllIIlIl[lIlllllIIIIlIl[2]]);
      String lllllllllllllllIlllIIIllIllIIIll = lllllllllllllllIlllIIIllIllIIlIl[lIlllllIIIIlIl[3]];
      MethodHandle lllllllllllllllIlllIIIllIllIIIlI = null;
      int lllllllllllllllIlllIIIllIllIIIIl = lllllllllllllllIlllIIIllIllIIlIl[lIlllllIIIIlIl[20]].length();
      if (llllllllIIIIIll(lllllllllllllllIlllIIIllIllIIIIl, lIlllllIIIIlIl[5])) {
        MethodType lllllllllllllllIlllIIIllIllIIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIllIllIIlIl[lIlllllIIIIlIl[5]], fa.class.getClassLoader());
        if (lllllllIllllIII(lllllllllllllllIlllIIIllIllIIIIl, lIlllllIIIIlIl[5])) {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findVirtual(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIlll);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findStatic(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIlll);
        } 
        "".length();
        if (-" ".length() == " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIllIllIIllI = lIllllIlIlllll[Integer.parseInt(lllllllllllllllIlllIIIllIllIIlIl[lIlllllIIIIlIl[5]])];
        if (lllllllIllllIII(lllllllllllllllIlllIIIllIllIIIIl, lIlllllIIIIlIl[20])) {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findGetter(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIllI);
          "".length();
          if ("   ".length() <= ((0x84 ^ 0xA7) << " ".length() & ((0x20 ^ 0x3) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllllIllllIII(lllllllllllllllIlllIIIllIllIIIIl, lIlllllIIIIlIl[7])) {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findStaticGetter(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIllI);
          "".length();
          if ("   ".length() < "   ".length())
            return null; 
        } else if (lllllllIllllIII(lllllllllllllllIlllIIIllIllIIIIl, lIlllllIIIIlIl[21])) {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findSetter(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIIIllIllIIIlI = lllllllllllllllIlllIIIllIlIlllll.findStaticSetter(lllllllllllllllIlllIIIllIllIIlII, lllllllllllllllIlllIIIllIllIIIll, lllllllllllllllIlllIIIllIllIIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIllIllIIIlI);
    } catch (Exception lllllllllllllllIlllIIIllIllIIIII) {
      lllllllllllllllIlllIIIllIllIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIllIllll() {
    lIllllIlIllllI = new String[lIlllllIIIIlIl[33]];
    lIllllIlIllllI[lIlllllIIIIlIl[34]] = lIllllIlllllll[lIlllllIIIIlIl[12]];
    lIllllIlIllllI[lIlllllIIIIlIl[16]] = lIllllIlllllll[lIlllllIIIIlIl[15]];
    lIllllIlIllllI[lIlllllIIIIlIl[3]] = lIllllIlllllll[lIlllllIIIIlIl[4]];
    lIllllIlIllllI[lIlllllIIIIlIl[20]] = lIllllIlllllll[lIlllllIIIIlIl[16]];
    lIllllIlIllllI[lIlllllIIIIlIl[17]] = lIllllIlllllll[lIlllllIIIIlIl[17]];
    lIllllIlIllllI[lIlllllIIIIlIl[35]] = lIllllIlllllll[lIlllllIIIIlIl[11]];
    lIllllIlIllllI[lIlllllIIIIlIl[36]] = lIllllIlllllll[lIlllllIIIIlIl[35]];
    lIllllIlIllllI[lIlllllIIIIlIl[37]] = lIllllIlllllll[lIlllllIIIIlIl[38]];
    lIllllIlIllllI[lIlllllIIIIlIl[39]] = lIllllIlllllll[lIlllllIIIIlIl[40]];
    lIllllIlIllllI[lIlllllIIIIlIl[30]] = lIllllIlllllll[lIlllllIIIIlIl[41]];
    lIllllIlIllllI[lIlllllIIIIlIl[27]] = lIllllIlllllll[lIlllllIIIIlIl[42]];
    lIllllIlIllllI[lIlllllIIIIlIl[38]] = lIllllIlllllll[lIlllllIIIIlIl[43]];
    lIllllIlIllllI[lIlllllIIIIlIl[44]] = lIllllIlllllll[lIlllllIIIIlIl[45]];
    lIllllIlIllllI[lIlllllIIIIlIl[46]] = lIllllIlllllll[lIlllllIIIIlIl[47]];
    lIllllIlIllllI[lIlllllIIIIlIl[41]] = lIllllIlllllll[lIlllllIIIIlIl[37]];
    lIllllIlIllllI[lIlllllIIIIlIl[48]] = lIllllIlllllll[lIlllllIIIIlIl[49]];
    lIllllIlIllllI[lIlllllIIIIlIl[50]] = lIllllIlllllll[lIlllllIIIIlIl[1]];
    lIllllIlIllllI[lIlllllIIIIlIl[11]] = lIllllIlllllll[lIlllllIIIIlIl[51]];
    lIllllIlIllllI[lIlllllIIIIlIl[25]] = lIllllIlllllll[lIlllllIIIIlIl[52]];
    lIllllIlIllllI[lIlllllIIIIlIl[53]] = lIllllIlllllll[lIlllllIIIIlIl[44]];
    lIllllIlIllllI[lIlllllIIIIlIl[40]] = lIllllIlllllll[lIlllllIIIIlIl[54]];
    lIllllIlIllllI[lIlllllIIIIlIl[21]] = lIllllIlllllll[lIlllllIIIIlIl[55]];
    lIllllIlIllllI[lIlllllIIIIlIl[56]] = lIllllIlllllll[lIlllllIIIIlIl[57]];
    lIllllIlIllllI[lIlllllIIIIlIl[58]] = lIllllIlllllll[lIlllllIIIIlIl[59]];
    lIllllIlIllllI[lIlllllIIIIlIl[42]] = lIllllIlllllll[lIlllllIIIIlIl[60]];
    lIllllIlIllllI[lIlllllIIIIlIl[61]] = lIllllIlllllll[lIlllllIIIIlIl[56]];
    lIllllIlIllllI[lIlllllIIIIlIl[62]] = lIllllIlllllll[lIlllllIIIIlIl[61]];
    lIllllIlIllllI[lIlllllIIIIlIl[63]] = lIllllIlllllll[lIlllllIIIIlIl[64]];
    lIllllIlIllllI[lIlllllIIIIlIl[65]] = lIllllIlllllll[lIlllllIIIIlIl[63]];
    lIllllIlIllllI[lIlllllIIIIlIl[13]] = lIllllIlllllll[lIlllllIIIIlIl[66]];
    lIllllIlIllllI[lIlllllIIIIlIl[29]] = lIllllIlllllll[lIlllllIIIIlIl[67]];
    lIllllIlIllllI[lIlllllIIIIlIl[68]] = lIllllIlllllll[lIlllllIIIIlIl[46]];
    lIllllIlIllllI[lIlllllIIIIlIl[1]] = lIllllIlllllll[lIlllllIIIIlIl[69]];
    lIllllIlIllllI[lIlllllIIIIlIl[26]] = lIllllIlllllll[lIlllllIIIIlIl[70]];
    lIllllIlIllllI[lIlllllIIIIlIl[15]] = lIllllIlllllll[lIlllllIIIIlIl[62]];
    lIllllIlIllllI[lIlllllIIIIlIl[14]] = lIllllIlllllll[lIlllllIIIIlIl[71]];
    lIllllIlIllllI[lIlllllIIIIlIl[43]] = lIllllIlllllll[lIlllllIIIIlIl[72]];
    lIllllIlIllllI[lIlllllIIIIlIl[66]] = lIllllIlllllll[lIlllllIIIIlIl[53]];
    lIllllIlIllllI[lIlllllIIIIlIl[72]] = lIllllIlllllll[lIlllllIIIIlIl[73]];
    lIllllIlIllllI[lIlllllIIIIlIl[51]] = lIllllIlllllll[lIlllllIIIIlIl[74]];
    lIllllIlIllllI[lIlllllIIIIlIl[4]] = lIllllIlllllll[lIlllllIIIIlIl[75]];
    lIllllIlIllllI[lIlllllIIIIlIl[12]] = lIllllIlllllll[lIlllllIIIIlIl[65]];
    lIllllIlIllllI[lIlllllIIIIlIl[64]] = lIllllIlllllll[lIlllllIIIIlIl[39]];
    lIllllIlIllllI[lIlllllIIIIlIl[54]] = lIllllIlllllll[lIlllllIIIIlIl[36]];
    lIllllIlIllllI[lIlllllIIIIlIl[75]] = lIllllIlllllll[lIlllllIIIIlIl[50]];
    lIllllIlIllllI[lIlllllIIIIlIl[55]] = lIllllIlllllll[lIlllllIIIIlIl[58]];
    lIllllIlIllllI[lIlllllIIIIlIl[52]] = lIllllIlllllll[lIlllllIIIIlIl[68]];
    lIllllIlIllllI[lIlllllIIIIlIl[71]] = lIllllIlllllll[lIlllllIIIIlIl[34]];
    lIllllIlIllllI[lIlllllIIIIlIl[45]] = lIllllIlllllll[lIlllllIIIIlIl[48]];
    lIllllIlIllllI[lIlllllIIIIlIl[69]] = lIllllIlllllll[lIlllllIIIIlIl[33]];
    lIllllIlIllllI[lIlllllIIIIlIl[2]] = lIllllIlllllll[lIlllllIIIIlIl[76]];
    lIllllIlIllllI[lIlllllIIIIlIl[74]] = lIllllIlllllll[lIlllllIIIIlIl[77]];
    lIllllIlIllllI[lIlllllIIIIlIl[67]] = lIllllIlllllll[lIlllllIIIIlIl[78]];
    lIllllIlIllllI[lIlllllIIIIlIl[49]] = lIllllIlllllll[lIlllllIIIIlIl[79]];
    lIllllIlIllllI[lIlllllIIIIlIl[23]] = lIllllIlllllll[lIlllllIIIIlIl[80]];
    lIllllIlIllllI[lIlllllIIIIlIl[5]] = lIllllIlllllll[lIlllllIIIIlIl[81]];
    lIllllIlIllllI[lIlllllIIIIlIl[7]] = lIllllIlllllll[lIlllllIIIIlIl[82]];
    lIllllIlIllllI[lIlllllIIIIlIl[60]] = lIllllIlllllll[lIlllllIIIIlIl[83]];
    lIllllIlIllllI[lIlllllIIIIlIl[28]] = lIllllIlllllll[lIlllllIIIIlIl[84]];
    lIllllIlIllllI[lIlllllIIIIlIl[57]] = lIllllIlllllll[lIlllllIIIIlIl[85]];
    lIllllIlIllllI[lIlllllIIIIlIl[59]] = lIllllIlllllll[lIlllllIIIIlIl[86]];
    lIllllIlIllllI[lIlllllIIIIlIl[47]] = lIllllIlllllll[lIlllllIIIIlIl[87]];
    lIllllIlIllllI[lIlllllIIIIlIl[24]] = lIllllIlllllll[lIlllllIIIIlIl[88]];
    lIllllIlIllllI[lIlllllIIIIlIl[70]] = lIllllIlllllll[lIlllllIIIIlIl[89]];
    lIllllIlIllllI[lIlllllIIIIlIl[73]] = lIllllIlllllll[lIlllllIIIIlIl[90]];
    lIllllIlIlllll = new Class[lIlllllIIIIlIl[24]];
    lIllllIlIlllll[lIlllllIIIIlIl[23]] = boolean.class;
    lIllllIlIlllll[lIlllllIIIIlIl[20]] = int.class;
    lIllllIlIlllll[lIlllllIIIIlIl[7]] = DynamicTexture.class;
    lIllllIlIlllll[lIlllllIIIIlIl[3]] = int[].class;
    lIllllIlIlllll[lIlllllIIIIlIl[2]] = f14.CharData[].class;
    lIllllIlIlllll[lIlllllIIIIlIl[5]] = String.class;
    lIllllIlIlllll[lIlllllIIIIlIl[21]] = Font.class;
  }
  
  private static void lllllllIlllIlII() {
    lIllllIlllllll = new String[lIlllllIIIIlIl[91]];
    lIllllIlllllll[lIlllllIIIIlIl[2]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[2]], lIlllllIIIIlII[lIlllllIIIIlIl[3]]);
    lIllllIlllllll[lIlllllIIIIlIl[3]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[5]], lIlllllIIIIlII[lIlllllIIIIlIl[20]]);
    lIllllIlllllll[lIlllllIIIIlIl[5]] = lllllllIlllIIIl(lIlllllIIIIlII[lIlllllIIIIlIl[7]], lIlllllIIIIlII[lIlllllIIIIlIl[21]]);
    lIllllIlllllll[lIlllllIIIIlIl[20]] = lllllllIlllIIIl(lIlllllIIIIlII[lIlllllIIIIlIl[23]], lIlllllIIIIlII[lIlllllIIIIlIl[24]]);
    lIllllIlllllll[lIlllllIIIIlIl[7]] = lllllllIlllIIIl(lIlllllIIIIlII[lIlllllIIIIlIl[14]], lIlllllIIIIlII[lIlllllIIIIlIl[25]]);
    lIllllIlllllll[lIlllllIIIIlIl[21]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[26]], lIlllllIIIIlII[lIlllllIIIIlIl[27]]);
    lIllllIlllllll[lIlllllIIIIlIl[23]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[28]], lIlllllIIIIlII[lIlllllIIIIlIl[29]]);
    lIllllIlllllll[lIlllllIIIIlIl[24]] = lllllllIlllIIlI(lIlllllIIIIlII[lIlllllIIIIlIl[30]], lIlllllIIIIlII[lIlllllIIIIlIl[13]]);
    lIllllIlllllll[lIlllllIIIIlIl[14]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[12]], lIlllllIIIIlII[lIlllllIIIIlIl[15]]);
    lIllllIlllllll[lIlllllIIIIlIl[25]] = lllllllIlllIIIl(lIlllllIIIIlII[lIlllllIIIIlIl[4]], lIlllllIIIIlII[lIlllllIIIIlIl[16]]);
    lIllllIlllllll[lIlllllIIIIlIl[26]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[17]], lIlllllIIIIlII[lIlllllIIIIlIl[11]]);
    lIllllIlllllll[lIlllllIIIIlIl[27]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[35]], lIlllllIIIIlII[lIlllllIIIIlIl[38]]);
    lIllllIlllllll[lIlllllIIIIlIl[28]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[40]], lIlllllIIIIlII[lIlllllIIIIlIl[41]]);
    lIllllIlllllll[lIlllllIIIIlIl[29]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[42]], lIlllllIIIIlII[lIlllllIIIIlIl[43]]);
    lIllllIlllllll[lIlllllIIIIlIl[30]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[45]], lIlllllIIIIlII[lIlllllIIIIlIl[47]]);
    lIllllIlllllll[lIlllllIIIIlIl[13]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[37]], lIlllllIIIIlII[lIlllllIIIIlIl[49]]);
    lIllllIlllllll[lIlllllIIIIlIl[12]] = lllllllIlllIIIl(lIlllllIIIIlII[lIlllllIIIIlIl[1]], lIlllllIIIIlII[lIlllllIIIIlIl[51]]);
    lIllllIlllllll[lIlllllIIIIlIl[15]] = lllllllIlllIIII(lIlllllIIIIlII[lIlllllIIIIlIl[52]], "hiOLI");
    lIllllIlllllll[lIlllllIIIIlIl[4]] = lllllllIlllIIII("KlmQ/FOwhQ2427Uwx0Y11TAK7Zb5Hfw/Id4MpDNcLAu4yV5Sd64/8w==", "gQqZc");
    lIllllIlllllll[lIlllllIIIIlIl[16]] = lllllllIlllIIlI("637bm5XXjvYNp0sHCZ2iS9o358xrt4/Qke3L0nRsJYN9OvvDYpCUaA==", "ODWKD");
    lIllllIlllllll[lIlllllIIIIlIl[17]] = lllllllIlllIIIl("Cg06VhQNBisbCwUOOlYaCAErFg1KGisWHQEaKwpXIwQdDBgQDQMZFwUPKwpDAh0gGyZVX3dJSFY3LEJRLSFnLkNE", "dhNxy");
    lIllllIlllllll[lIlllllIIIIlIl[11]] = lllllllIlllIIlI("TeB+XhvXGMbN0O8F4hl/n/nJom2oMTHhXNFVmOAM5P4=", "leDoL");
    lIllllIlllllll[lIlllllIIIIlIl[35]] = lllllllIlllIIII("1dDt6zHzOUmp39T/dwMO1dEOVAKwmY0cd0nv+KCV02Zipqr5xrn9KCjin1fmYPsi", "TESPx");
    lIllllIlllllll[lIlllllIIIIlIl[38]] = lllllllIlllIIlI("PxNfM79f7zkx2jxLNUJMbxYcbtF5fRdlzDjlUVghaogRJjiKgcNiOA==", "IgxkC");
    lIllllIlllllll[lIlllllIIIIlIl[40]] = lllllllIlllIIII("4qXIU/zl+s0IUFjxOakmXt3QqDdY2ucMWriXkaajkjWYdGYovjonEqqKxSpwmkcAWkBciDDIdV5HRxpS/Z2/Gg==", "EEIGb");
    lIllllIlllllll[lIlllllIIIIlIl[41]] = lllllllIlllIIIl("IT9FPBI5KgI7AiM9RS0OPHQNf1d2PQ47JCAvDnVOZRNRb0Y=", "LZkOf");
    lIllllIlllllll[lIlllllIIIIlIl[42]] = lllllllIlllIIII("ebHqFkUSBQTGyHr1y5MQypfa1Sb4HCrVNHBiNgsbPK1s1rvvN57gbGeNQfH9MSvGb3JzfpNzVooDLnpVBJ6QE1j7bMohS6+QsCoqztFsoeA=", "ZZOhz");
    lIllllIlllllll[lIlllllIIIIlIl[43]] = lllllllIlllIIII("HZxkgifUEcYoJNCYqJjZOi9j8yInWb+wMNgrBMjrs7iqkFWGYT6Zkdv2dWf+D/WQedWc2RAfYd1D9jw469LGreXZzBsCySc2", "vDMUx");
    lIllllIlllllll[lIlllllIIIIlIl[45]] = lllllllIlllIIlI("HrCBiRMdwVZfQyNwLIzeymnuOzw1Ea/hX37gcc9Truyj5SW7lapdXg==", "WDxsz");
    lIllllIlllllll[lIlllllIIIIlIl[47]] = lllllllIlllIIIl("NxNgAjsvBicFKzURYBMnKlgoEHU8BC8SOzMZIBAjFxM6AyY5BXRHdXpWbg==", "ZvNqO");
    lIllllIlllllll[lIlllllIIIIlIl[37]] = lllllllIlllIIIl("Ij0WSCYlNgcFOS0+FkgoIDEHCD9iKgcILykqBxRlOD0aEj4+PUwiMiI5Dw8oGD0aEj4+PVgAPiI7PVd6fG1XVBQuYkpPAnZ4Qg==", "LXbfK");
    lIllllIlllllll[lIlllllIIIIlIl[49]] = lllllllIlllIIlI("dvCpRUIhYdcxeOXqSJt9IjRwx+nlFZjqxuagMhJefG22k/cnuuOVkqBy2mbp27ci", "JXhiP");
    lIllllIlllllll[lIlllllIIIIlIl[1]] = lllllllIlllIIII("c6EOwS/obxficYaFhzS1Hq1AfqN+FvrZvnzel8tmEaCM3y2JHwQeR/qw0NJKMWUUU81k9qPvb0uz/0kxF9Qccw==", "mvUhb");
    lIllllIlllllll[lIlllllIIIIlIl[51]] = lllllllIlllIIlI("OZLDsW+xohh9c4uA0Y3acINd7wbmlZ4LqbSdYcOSaC03vUJdArjXmsZgouuXoZjU2JtOqupB8QN5tvC4BCCBJRfx16Qp82YP", "ScRyv");
    lIllllIlllllll[lIlllllIIIIlIl[52]] = lllllllIlllIIlI("Jk49RVfv/nqun+1gHrAQe9/yNgBzEYYOXmHgYDf5zQFd+ZLn15JMTLNtvnFGHVvIdZC2wB+CUpSTNSilaJwhfA==", "PhqBQ");
    lIllllIlllllll[lIlllllIIIIlIl[44]] = lllllllIlllIIIl("JRAhXDsiGzARJCoTIVw1JxwwHCJlBzAcMi4HMAB4DBkGBjc/EBgTOCoSMABsLQA7EQl6TWJGYnoqMUh+DVwDSHY=", "KuUrV");
    lIllllIlllllll[lIlllllIIIIlIl[54]] = lllllllIlllIIII("baPeugeHDo8fKfn8AFziYiWd4HfGIGK4zu46IPwXGbA=", "XKIPJ");
    lIllllIlllllll[lIlllllIIIIlIl[55]] = lllllllIlllIIII("g8bD8x06w/hXllTzneBH++18fUBEvaUEvuSZvlhzTnJ5vXOqBQzCWQ==", "kTUww");
    lIllllIlllllll[lIlllllIIIIlIl[57]] = lllllllIlllIIIl("LzRWBQw3IRECHC02VhQQMn8eF0IhORkENyQ3CxMMeGJCVlhi", "BQxvx");
    lIllllIlllllll[lIlllllIIIIlIl[59]] = lllllllIlllIIlI("dFJIk7EErkuh7lZoKSyXfgvwR/eTuUUQwqAbH3ZWr911opJnHJ8OYnIGOV0KZan1iVfYDvbvYI1IcmYUuIElHz8rxS0qytsJ1fnodIAflCQ=", "fYSCn");
    lIllllIlllllll[lIlllllIIIIlIl[60]] = lllllllIlllIIlI("eOeKePJoIa0A6xo3x6nqfjuDUNjM+u994Ny8xryGFMUnx0pH7W4l6a0Y/gTCpnjuRqGlAwzjCKvvzLXBIBjoQHuM3JXFKs5u", "JrStI");
    lIllllIlllllll[lIlllllIIIIlIl[56]] = lllllllIlllIIlI("hah25AIvJMxNLHIRTw60cpiILk1sTvpPDYPEWPlKoRUKjEhdiTsPuw==", "KAQfF");
    lIllllIlllllll[lIlllllIIIIlIl[61]] = lllllllIlllIIIl("ICt+MBo4Pjk3CiIpfiEGPWA2IlQ5KygKGiwiOSBUeXRwY05tbg==", "MNPCn");
    lIllllIlllllll[lIlllllIIIIlIl[64]] = lllllllIlllIIlI("tmwI/6xCcIZYSnYZ4pHCRqLO0IB/aspUh/iyfsF370s=", "sKfeJ");
    lIllllIlllllll[lIlllllIIIIlIl[63]] = lllllllIlllIIlI("Sn7r6DxLEql7ut3Fg/7WpZLmivJNpYm5TQCGMVS/U+e1061sWPflVMHcLV13Bmt5ak53X7GCVBRyrx3k+NDsvd1+5jpTRKqrXMGOyKAWPU4=", "roGMx");
    lIllllIlllllll[lIlllllIIIIlIl[66]] = lllllllIlllIIlI("c3HogvZUkmwf9qgFfjc/i/wJ4YaTzzXV3FUYogwNz7K994uSnMocrg==", "uOXCz");
    lIllllIlllllll[lIlllllIIIIlIl[67]] = lllllllIlllIIII("mtuJJHUuQkh3r3Ycal6KEhdkf9QnkHE2G6vbMWuj435yZ0ubdHxgvg==", "bBdDx");
    lIllllIlllllll[lIlllllIIIIlIl[46]] = lllllllIlllIIII("lruA7Ghl/ckV2cJiGeOiZ6qAKziawFUdXM932xbYGI4PsgFnJs5YrbpZ2RypGtiF1v0Cvqs9rTY=", "zrKNr");
    lIllllIlllllll[lIlllllIIIIlIl[69]] = lllllllIlllIIII("j2hJdPD0U3J8w/QVC6Xq8UKzSP+EsuNKiMx/lyRP+JYYWE/5MmBoQQ==", "OEWVs");
    lIllllIlllllll[lIlllllIIIIlIl[70]] = lllllllIlllIIlI("MHVRMqBZHSndX861GbqlOeRuJnXBb6CDt8/aMIFRRaXEBOD6G5VsrBPIjPdN9UXKPwWtRBUvCV/F+DvsOWyyLhMw7UtVEtOjdbfuYSJGkrLqv1Uem0Gvaj42chYgZ+ib", "KToiN");
    lIllllIlllllll[lIlllllIIIIlIl[62]] = lllllllIlllIIlI("OGgAO2WRljG5M4Dnu72cmjKxHoCtUZ9nTU2K1Gn986eRdDz0zIHH1oajmBjUUVv3aIon3Ti/aMQUlUtkWMdXr5IS92jIiJ5v", "TpWRH");
    lIllllIlllllll[lIlllllIIIIlIl[71]] = lllllllIlllIIlI("hMNkcElf/eIGN9eEPSYvjxAdjGG4h2veg7XyfNvteBQ=", "MNpms");
    lIllllIlllllll[lIlllllIIIIlIl[72]] = lllllllIlllIIII("ZeZ5AO9mWck59ZLTUqzymowo4ZMpAXUJJuZzfZYySUs=", "dbIki");
    lIllllIlllllll[lIlllllIIIIlIl[53]] = lllllllIlllIIII("HTYVwwqkKv9ydqN8X7AZcDZ5mt0OHbNHyhTE7eH/lB3++KxfeD8q56Zm+HvDmBee", "cFTfV");
    lIllllIlllllll[lIlllllIIIIlIl[73]] = lllllllIlllIIIl("KTwHSAUuNxYFGiY/B0gLKzAWCBxpKxYIDCIrFhRGADUgEgkzPD4HBiY+FhRSISwdBTd2bkpWUXcGC1xAbg9JRg==", "GYsfh");
    lIllllIlllllll[lIlllllIIIIlIl[74]] = lllllllIlllIIlI("hTH8N6upMmjuvSSip36EuUdTZFgOrVusnf+mAjN6NWdnEEhsOqcZPQ==", "xNeNq");
    lIllllIlllllll[lIlllllIIIIlIl[75]] = lllllllIlllIIII("UPjNANR67GM8hHPLNgs0vFUfz2HlxdFkfYbWxW0tJR/QYvSaUgZdkp/zWmLltM3P6CKj/bJp1dW8yRi40epO3n7PKWoEsXrR", "yqqXN");
    lIllllIlllllll[lIlllllIIIIlIl[65]] = lllllllIlllIIlI("ZAYIBur2P1z1smTMywo50FhNc+56uWJVQKsRk+/+JtHltSstyDwZiQ==", "HqPAP");
    lIllllIlllllll[lIlllllIIIIlIl[39]] = lllllllIlllIIlI("00Lki2TgDLTx04Ow2kgw7xUhaIsH3mCevRvKwMVR3QTNLgCmgQCrEEi0hIkqSgD6WQ041wbKbu52OP2cIyy/ice2vrB/JRNc", "ufAIE");
    lIllllIlllllll[lIlllllIIIIlIl[36]] = lllllllIlllIIII("Jm5dSb5v2Aiiof0WdI10mzAGeUTCEZw4dgbYR3ygdwGG0UNHNP9SSDVKZNXUznf5gOCOc0ji1FLtbSbX7WLqDIBx7rBy/lXY", "XhVNb");
    lIllllIlllllll[lIlllllIIIIlIl[50]] = lllllllIlllIIIl("IA8vCGomDzcOahkaKwAqLVQtBgciDysoNjgPIFNsYzUaU2Rq", "JnYiD");
    lIllllIlllllll[lIlllllIIIIlIl[58]] = lllllllIlllIIIl("Kwl7FDIzHDwTIikLewUuNkIzBnwiHjQQBS4NJ11uHSA4Amk1GCAXLzIIOgBpJAQlSCB3WHEkLiceEQYyJ1cWIQBvOm9HZg==", "FlUgF");
    lIllllIlllllll[lIlllllIIIIlIl[68]] = lllllllIlllIIlI("h8ZdSToEo/QkdtQ3qzoddU9s2ZdDws+jqp4R91/s2iumzLNpRSYNUQ==", "xbcUb");
    lIllllIlllllll[lIlllllIIIIlIl[34]] = lllllllIlllIIlI("4E0JSt1mtjk4N/iSa9mllEdh3wrmUHRgHDR9JbyBXsoI+MY3medgSUy3+wiKlw2V", "JzSIZ");
    lIllllIlllllll[lIlllllIIIIlIl[48]] = lllllllIlllIIIl("CQ4SJUUPDgojRTAbFi0FBFUNKg8GFysiUUsmTQ1RQ08=", "codDk");
    lIllllIlllllll[lIlllllIIIIlIl[33]] = lllllllIlllIIlI("Z0l30ikl9GunF5PlNTugoh8yiXnDg4HgtvrSmK0plapdQCvd0yhgBdW3MXp21FbCqtQLTyOtCTcAxY9O58iG3+43RAiLprUFTwDbZUAg5OstIEPjJhtfkR4fIkIKm2QlOkVpvMCIN4vy7xL7PNdNfHpNa7g0EBvDS1ToXAiz5bnKiYesmsQRkl/Eiv5zXQB6", "vxlMa");
    lIllllIlllllll[lIlllllIIIIlIl[76]] = lllllllIlllIIlI("biYoaIamzNSEaBEoFU66JRQ44dtrqpqBo8MiYAhvASqBv03L+wpSZA==", "ldtkr");
    lIllllIlllllll[lIlllllIIIIlIl[77]] = lllllllIlllIIII("kMpSOEQz7WoBHgGPG8FB77S0cQoX/h0e2vwASpiRO4wKJYWPnK8EUC2MxQuYJwjq/gi/CYiN8gjQSKt8vM/nTaD+iQ2rMgqd", "JofHP");
    lIllllIlllllll[lIlllllIIIIlIl[78]] = lllllllIlllIIIl("CS9iGzoROiUcKgstYgomFGQqCXQFJDgBDwgjLRt0UnBsSG4=", "dJLhN");
    lIllllIlllllll[lIlllllIIIIlIl[79]] = lllllllIlllIIlI("kGQnnPfcUXpJiYrduakrTwi0rtuM3KUT4UNSA7WFoG2bAfqLaxjRJBpBcED97/eo", "VvUVS");
    lIllllIlllllll[lIlllllIIIIlIl[80]] = lllllllIlllIIlI("JPprOtlrLe7tiw6Q930Vyi4t6xY2iW6Y2uortsdu0dIlxFrIZvPFEA==", "VCkBf");
    lIllllIlllllll[lIlllllIIIIlIl[81]] = lllllllIlllIIIl("Ozx0BxsjKTMACzk+dBYHJnc8FVU0NjYQJiI4Nh0MFTE7BhxsaWBUT3Z5eg==", "VYZto");
    lIllllIlllllll[lIlllllIIIIlIl[82]] = lllllllIlllIIIl("AQJfIRkZFxgmCQMAXzAFHEkXM1cKCB8mPgUdFGheVkdRck1M", "lgqRm");
    lIllllIlllllll[lIlllllIIIIlIl[83]] = lllllllIlllIIIl("Ail8ATgaPDsGKAArfBAkH2I0Q3hLDzoTPistJhN2GCU2BiRVf2hSbE8=", "oLRrL");
    lIllllIlllllll[lIlllllIIIIlIl[84]] = lllllllIlllIIIl("Gy9fHxoDOhgYChktXw4GBmQXXF9MLRQYPBMuS0RHP3BRTA==", "vJqln");
    lIllllIlllllll[lIlllllIIIIlIl[85]] = lllllllIlllIIII("0eUKibLO7P1NDVT8MCUO0Ywy+mklIXQDIX2GyP7ejXx67ZpOneJ/KZy1Uz7ZSneSbFBrNyg/f2PA3DOHrZlmpK7hVFc4bxU9", "qWlJz");
    lIllllIlllllll[lIlllllIIIIlIl[86]] = lllllllIlllIIIl("KT1sGhcxKCsdBys/bAsLNHYkWFdgGyoIEQA5NghZLD0rDgswYnFTQ2R4", "DXBic");
    lIllllIlllllll[lIlllllIIIIlIl[87]] = lllllllIlllIIII("ZAoLn4Eov/krCU2DxKKSsL88fQdLykUmJ1vZ2HJb4HYbND9mDjlIpA==", "Rottg");
    lIllllIlllllll[lIlllllIIIIlIl[88]] = lllllllIlllIIIl("NyFtGgEvNCodETUjbQsdKmolCE8+NiIeJi42KgcSYGwPAxQsJWwFFDQjbDoBKC0tDk4eAA8EEHU3NxwFMzAnBhJ1JisZWjx0clIvcwJ5SVU=", "ZDCiu");
    lIllllIlllllll[lIlllllIIIIlIl[89]] = lllllllIlllIIIl("NzB5Og0vJT49HTUyeSsRKnsxKEMuMC8LFjYxbX1DenV3aVk=", "ZUWIy");
    lIllllIlllllll[lIlllllIIIIlIl[90]] = lllllllIlllIIlI("ID+BnXJEqJBjpjC+jdIR515wN4CHbpRlW1rQ/ZM5siKtz2m76L+6Y9qQFfsG8V2L", "dtrro");
    lIlllllIIIIlII = null;
  }
  
  private static void lllllllIlllIlIl() {
    String str = (new Exception()).getStackTrace()[lIlllllIIIIlIl[2]].getFileName();
    lIlllllIIIIlII = str.substring(str.indexOf("ä") + lIlllllIIIIlIl[3], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIlllIIlI(String lllllllllllllllIlllIIIllIlIllIIl, String lllllllllllllllIlllIIIllIlIllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllIlIlllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllIlIllIII.getBytes(StandardCharsets.UTF_8)), lIlllllIIIIlIl[14]), "DES");
      Cipher lllllllllllllllIlllIIIllIlIllIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIllIlIllIll.init(lIlllllIIIIlIl[5], lllllllllllllllIlllIIIllIlIlllII);
      return new String(lllllllllllllllIlllIIIllIlIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllIlIllIlI) {
      lllllllllllllllIlllIIIllIlIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIlllIIIl(String lllllllllllllllIlllIIIllIlIlIllI, String lllllllllllllllIlllIIIllIlIlIlIl) {
    lllllllllllllllIlllIIIllIlIlIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIlIlIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIllIlIlIlII = new StringBuilder();
    char[] lllllllllllllllIlllIIIllIlIlIIll = lllllllllllllllIlllIIIllIlIlIlIl.toCharArray();
    int lllllllllllllllIlllIIIllIlIlIIlI = lIlllllIIIIlIl[2];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIllIlIlIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllIIIIlIl[2];
    while (lllllllIllllIIl(j, i)) {
      char lllllllllllllllIlllIIIllIlIlIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIllIlIlIIlI++;
      j++;
      "".length();
      if (-"   ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIllIlIlIlII);
  }
  
  private static String lllllllIlllIIII(String lllllllllllllllIlllIIIllIlIIlllI, String lllllllllllllllIlllIIIllIlIIllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllIlIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllIlIIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIllIlIlIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIllIlIlIIII.init(lIlllllIIIIlIl[5], lllllllllllllllIlllIIIllIlIlIIIl);
      return new String(lllllllllllllllIlllIIIllIlIlIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIlIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllIlIIllll) {
      lllllllllllllllIlllIIIllIlIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIlllIllI() {
    lIlllllIIIIlIl = new int[92];
    lIlllllIIIIlIl[0] = " ".length() << " ".length() << "   ".length();
    lIlllllIIIIlIl[1] = " ".length() << (9 + 114 - 48 + 66 ^ (0xD0 ^ 0xC1) << "   ".length());
    lIlllllIIIIlIl[2] = (0x70 ^ 0x7F) << " ".length() & ((0x66 ^ 0x69) << " ".length() ^ 0xFFFFFFFF);
    lIlllllIIIIlIl[3] = " ".length();
    lIlllllIIIIlIl[4] = (0x44 ^ 0x4D) << " ".length();
    lIlllllIIIIlIl[5] = " ".length() << " ".length();
    lIlllllIIIIlIl[6] = ((0x76 ^ 0x73) << " ".length()) + 61 + 44 - -34 + 2 - ("   ".length() << " ".length()) + ((0x24 ^ 0x13) << " ".length());
    lIlllllIIIIlIl[7] = " ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[8] = 63 + 62 - 68 + 250 + ((0x5E ^ 0x57) << " ".length()) - (" ".length() << "   ".length()) + ((0x20 ^ 0x31) << " ".length() << " ".length()) << " ".length();
    lIlllllIIIIlIl[9] = 701 + 765 - 1231 + 536;
    lIlllllIIIIlIl[10] = ((0x95 ^ 0xC6) << " ".length()) + (0xBD ^ 0x92) - (0x56 ^ 0x11) + (0x74 ^ 0x6D);
    lIlllllIIIIlIl[11] = 0x99 ^ 0x8C;
    lIlllllIIIIlIl[12] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[13] = 0x6C ^ 0x33 ^ (0x8B ^ 0x8E) << " ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[14] = " ".length() << "   ".length();
    lIlllllIIIIlIl[15] = 0x85 ^ 0x94;
    lIlllllIIIIlIl[16] = (0x3D ^ 0x24) << " ".length() ^ 0x87 ^ 0xA6;
    lIlllllIIIIlIl[17] = (0x62 ^ 0x31 ^ (0x95 ^ 0xBE) << " ".length()) << " ".length() << " ".length();
    lIlllllIIIIlIl[18] = 1029 + 1117 - 1784 + 1009 + (515 + 310 - 477 + 455 << " ".length()) - 1080 + 189 - 1221 + 1503 + 659 + 1199 - 1423 + 1294;
    lIlllllIIIIlIl[19] = (0x40 ^ 0x51) << " ".length() << "   ".length();
    lIlllllIIIIlIl[20] = "   ".length();
    lIlllllIIIIlIl[21] = 0xA1 ^ 0xA4;
    lIlllllIIIIlIl[22] = 32116 + 24274 - 29506 + 38651;
    lIlllllIIIIlIl[23] = "   ".length() << " ".length();
    lIlllllIIIIlIl[24] = (0x37 ^ 0x6C) << " ".length() ^ 120 + 174 - 217 + 100;
    lIlllllIIIIlIl[25] = 20 + 103 - 29 + 51 ^ (0xBE ^ 0xAD) << "   ".length();
    lIlllllIIIIlIl[26] = (0x82 ^ 0x87) << " ".length();
    lIlllllIIIIlIl[27] = 0x3A ^ 0x31;
    lIlllllIIIIlIl[28] = "   ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[29] = 0xF4 ^ 0x9D ^ (0x9F ^ 0x86) << " ".length() << " ".length();
    lIlllllIIIIlIl[30] = (11 + 108 - 56 + 84 ^ (0x74 ^ 0x51) << " ".length() << " ".length()) << " ".length();
    lIlllllIIIIlIl[31] = 0x94 ^ 0xC1;
    lIlllllIIIIlIl[32] = (0xC3 ^ 0x96) << " ".length();
    lIlllllIIIIlIl[33] = (0x62 ^ 0x7D) << "   ".length() ^ 96 + 163 - 195 + 121;
    lIlllllIIIIlIl[34] = (0x5B ^ 0x68) << " ".length() ^ 0x35 ^ 0x6C;
    lIlllllIIIIlIl[35] = ((0xB9 ^ 0xA4) << " ".length() << " ".length() ^ 107 + 19 - 7 + 8) << " ".length();
    lIlllllIIIIlIl[36] = 0x1F ^ 0x3E ^ (0x2D ^ 0x20) << " ".length();
    lIlllllIIIIlIl[37] = (102 + 108 - 171 + 142 ^ (0x26 ^ 0x7B) << " ".length()) << " ".length();
    lIlllllIIIIlIl[38] = 107 + 163 - 142 + 63 ^ (0x63 ^ 0x76) << "   ".length();
    lIlllllIIIIlIl[39] = (0xB8 ^ 0xA5) << " ".length();
    lIlllllIIIIlIl[40] = "   ".length() << "   ".length();
    lIlllllIIIIlIl[41] = (0x8A ^ 0xBF) << " ".length() ^ 0xD6 ^ 0xA5;
    lIlllllIIIIlIl[42] = (0x46 ^ 0x4B) << " ".length();
    lIlllllIIIIlIl[43] = 0x48 ^ 0x2B ^ (0xC9 ^ 0xC6) << "   ".length();
    lIlllllIIIIlIl[44] = (0x6C ^ 0x49) << " ".length() << " ".length() ^ 83 + 108 - 46 + 38;
    lIlllllIIIIlIl[45] = (0xA5 ^ 0xB4 ^ (0x7C ^ 0x77) << " ".length()) << " ".length() << " ".length();
    lIlllllIIIIlIl[46] = 0x37 ^ 0x18;
    lIlllllIIIIlIl[47] = 151 + 92 - 208 + 154 ^ (0xAA ^ 0xAF) << (0x43 ^ 0x46);
    lIlllllIIIIlIl[48] = " ".length() << "   ".length() << " ".length();
    lIlllllIIIIlIl[49] = 0xF1 ^ 0x96 ^ (0xBD ^ 0xB2) << "   ".length();
    lIlllllIIIIlIl[50] = (0x34 ^ 0x3B) << " ".length() << " ".length();
    lIlllllIIIIlIl[51] = 102 + 106 - 115 + 42 ^ (0x93 ^ 0xC0) << " ".length();
    lIlllllIIIIlIl[52] = (0x75 ^ 0x1A ^ (0x14 ^ 0x2B) << " ".length()) << " ".length();
    lIlllllIIIIlIl[53] = 0x59 ^ 0x6C;
    lIlllllIIIIlIl[54] = (0x23 ^ 0x2A) << " ".length() << " ".length();
    lIlllllIIIIlIl[55] = (0x76 ^ 0x55) << " ".length() << " ".length() ^ 60 + 76 - 54 + 87;
    lIlllllIIIIlIl[56] = (0x46 ^ 0x49) << " ".length() << " ".length() ^ 0x29 ^ 0x3C;
    lIlllllIIIIlIl[57] = (0x32 ^ 0x21) << " ".length();
    lIlllllIIIIlIl[58] = 0x4D ^ 0x70;
    lIlllllIIIIlIl[59] = (0x7 ^ 0x14) << " ".length() << " ".length() ^ 0x41 ^ 0x2A;
    lIlllllIIIIlIl[60] = ((0x6D ^ 0x4E) << " ".length() ^ 0x76 ^ 0x35) << "   ".length();
    lIlllllIIIIlIl[61] = (38 + 1 - -83 + 89 ^ (0xF4 ^ 0x97) << " ".length()) << " ".length();
    lIlllllIIIIlIl[62] = (0xDD ^ 0xC4) << " ".length();
    lIlllllIIIIlIl[63] = (58 + 128 - 102 + 85 ^ (0xE5 ^ 0xB4) << " ".length()) << " ".length() << " ".length();
    lIlllllIIIIlIl[64] = 0x19 ^ 0x3E ^ "   ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[65] = 0xF8 ^ 0xC1;
    lIlllllIIIIlIl[66] = 0x26 ^ 0xB;
    lIlllllIIIIlIl[67] = (0x4 ^ 0x13) << " ".length();
    lIlllllIIIIlIl[68] = ((0x86 ^ 0xB3) << " ".length() ^ 0x9 ^ 0x7C) << " ".length();
    lIlllllIIIIlIl[69] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[70] = (0x59 ^ 0x76) << " ".length() ^ 0x1A ^ 0x75;
    lIlllllIIIIlIl[71] = (0x6E ^ 0x6B) << (0xE ^ 0xB) ^ 11 + 57 - 47 + 126;
    lIlllllIIIIlIl[72] = (0x97 ^ 0xC2 ^ (0x9D ^ 0x96) << "   ".length()) << " ".length() << " ".length();
    lIlllllIIIIlIl[73] = (0x42 ^ 0x31 ^ (0xA9 ^ 0xA4) << "   ".length()) << " ".length();
    lIlllllIIIIlIl[74] = 0xF ^ 0x58 ^ "   ".length() << (0x5C ^ 0x59);
    lIlllllIIIIlIl[75] = (0x60 ^ 0x67) << "   ".length();
    lIlllllIIIIlIl[76] = (0x5C ^ 0x7D) << " ".length();
    lIlllllIIIIlIl[77] = 44 + 158 - 180 + 175 ^ (0x25 ^ 0x66) << " ".length();
    lIlllllIIIIlIl[78] = (0xD0 ^ 0xC1) << " ".length() << " ".length();
    lIlllllIIIIlIl[79] = 0x7E ^ 0x3B;
    lIlllllIIIIlIl[80] = (0x8E ^ 0xAD) << " ".length();
    lIlllllIIIIlIl[81] = (0xC7 ^ 0xC2) << " ".length() << " ".length() << " ".length() ^ 0xD5 ^ 0xC2;
    lIlllllIIIIlIl[82] = (0x2 ^ 0xF ^ " ".length() << " ".length() << " ".length()) << "   ".length();
    lIlllllIIIIlIl[83] = 0xC5 ^ 0x9A ^ (0x50 ^ 0x5B) << " ".length();
    lIlllllIIIIlIl[84] = (0xB7 ^ 0x92) << " ".length();
    lIlllllIIIIlIl[85] = 199 + 2 - 150 + 184 ^ (0x3C ^ 0x39) << (0xBC ^ 0xB9);
    lIlllllIIIIlIl[86] = (0x69 ^ 0x7A) << " ".length() << " ".length();
    lIlllllIIIIlIl[87] = 0xF8 ^ 0xB5;
    lIlllllIIIIlIl[88] = (0xC1 ^ 0xB4 ^ (0xEB ^ 0xC2) << " ".length()) << " ".length();
    lIlllllIIIIlIl[89] = 125 + 119 - 122 + 19 ^ (0xF5 ^ 0x94) << " ".length();
    lIlllllIIIIlIl[90] = (0xBB ^ 0xBE) << " ".length() << " ".length() << " ".length();
    lIlllllIIIIlIl[91] = 0x9A ^ 0x8D ^ (0x58 ^ 0x7B) << " ".length();
  }
  
  private static boolean lllllllIllllIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllllIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 >= paramInt2);
  }
  
  private static boolean lllllllIllllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllllIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllIlllllII(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lllllllIlllIlll(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lllllllIllllIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllllIllllIll(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean llllllllIIIIIII(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lllllllIlllllll(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllllIlllllIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllllIllllllI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int llllllllIIIIIIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */