package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;

@Mod(modid = "bhp", name = "bleachhack+", version = "0.0.1")
public class f9 {
  @Instance
  public static f9 instance;
  
  public static EventManager EVENT_BUS;
  
  public ft eventProcessor;
  
  public av moduleManager;
  
  public f1000000000000000000000 settingsManager;
  
  public fi commandManager;
  
  public a friendManager;
  
  public f10000000000000000000 saveConfig;
  
  public ap loadConfig;
  
  public fa customFontRenderer;
  
  public fd clickGui;
  
  public String clientname;
  
  private static String[] llIIIlIIIIlIlI;
  
  private static Class[] llIIIlIIIIlIll;
  
  private static final String[] llIIIlIIIllIII;
  
  private static String[] llIIIlIIIllIlI;
  
  private static final int[] llIIIlIIIllIll;
  
  public f9() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIII : [Ljava/lang/String;
    //   8: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   11: iconst_0
    //   12: iaload
    //   13: aaload
    //   14: <illegal opcode> 0 : (Lme/stupitdog/bhp/f9;Ljava/lang/String;)V
    //   19: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIlIllIllIIIIll	Lme/stupitdog/bhp/f9;
  }
  
  @EventHandler
  public void init(FMLPreInitializationEvent lllllllllllllllIllIlIllIllIIIIIl) {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   5: <illegal opcode> 2 : ()Lme/stupitdog/bhp/f9;
    //   10: <illegal opcode> 3 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   15: aload_0
    //   16: new me/stupitdog/bhp/ft
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: <illegal opcode> 4 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/ft;)V
    //   28: <illegal opcode> 1 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   33: aload_0
    //   34: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/ft;
    //   39: <illegal opcode> 3 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   44: aload_0
    //   45: new me/stupitdog/bhp/f1000000000000000000000
    //   48: dup
    //   49: invokespecial <init> : ()V
    //   52: <illegal opcode> 6 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/f1000000000000000000000;)V
    //   57: aload_0
    //   58: new me/stupitdog/bhp/av
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: <illegal opcode> 7 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/av;)V
    //   70: aload_0
    //   71: <illegal opcode> 8 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   76: <illegal opcode> 9 : (Lme/stupitdog/bhp/av;)V
    //   81: <illegal opcode> 1 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   86: aload_0
    //   87: <illegal opcode> 8 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   92: <illegal opcode> 3 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   97: aload_0
    //   98: new me/stupitdog/bhp/fi
    //   101: dup
    //   102: invokespecial <init> : ()V
    //   105: <illegal opcode> 10 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/fi;)V
    //   110: aload_0
    //   111: new me/stupitdog/bhp/a
    //   114: dup
    //   115: invokespecial <init> : ()V
    //   118: <illegal opcode> 11 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/a;)V
    //   123: aload_0
    //   124: new me/stupitdog/bhp/fa
    //   127: dup
    //   128: new java/awt/Font
    //   131: dup
    //   132: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIII : [Ljava/lang/String;
    //   135: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   138: iconst_1
    //   139: iaload
    //   140: aaload
    //   141: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   144: iconst_0
    //   145: iaload
    //   146: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   149: iconst_2
    //   150: iaload
    //   151: invokespecial <init> : (Ljava/lang/String;II)V
    //   154: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   157: iconst_1
    //   158: iaload
    //   159: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   162: iconst_1
    //   163: iaload
    //   164: invokespecial <init> : (Ljava/awt/Font;ZZ)V
    //   167: <illegal opcode> 12 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/fa;)V
    //   172: aload_0
    //   173: new me/stupitdog/bhp/fd
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: <illegal opcode> 13 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/fd;)V
    //   185: aload_0
    //   186: new me/stupitdog/bhp/f10000000000000000000
    //   189: dup
    //   190: invokespecial <init> : ()V
    //   193: <illegal opcode> 14 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/f10000000000000000000;)V
    //   198: aload_0
    //   199: new me/stupitdog/bhp/ap
    //   202: dup
    //   203: invokespecial <init> : ()V
    //   206: <illegal opcode> 15 : (Lme/stupitdog/bhp/f9;Lme/stupitdog/bhp/ap;)V
    //   211: <illegal opcode> 16 : ()Ljava/lang/Runtime;
    //   216: new me/stupitdog/bhp/fj
    //   219: dup
    //   220: invokespecial <init> : ()V
    //   223: <illegal opcode> 17 : (Ljava/lang/Runtime;Ljava/lang/Thread;)V
    //   228: new java/lang/StringBuilder
    //   231: dup
    //   232: invokespecial <init> : ()V
    //   235: aload_0
    //   236: <illegal opcode> 18 : (Lme/stupitdog/bhp/f9;)Ljava/lang/String;
    //   241: <illegal opcode> 19 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   246: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIII : [Ljava/lang/String;
    //   249: getstatic me/stupitdog/bhp/f9.llIIIlIIIllIll : [I
    //   252: iconst_3
    //   253: iaload
    //   254: aaload
    //   255: <illegal opcode> 19 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: <illegal opcode> 20 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   265: <illegal opcode> 21 : (Ljava/lang/String;)V
    //   270: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	271	0	lllllllllllllllIllIlIllIllIIIIlI	Lme/stupitdog/bhp/f9;
    //   0	271	1	lllllllllllllllIllIlIllIllIIIIIl	Lnet/minecraftforge/fml/common/event/FMLPreInitializationEvent;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIIlllIlllIII : ()V
    //   3: invokestatic lIIIIIlllIllIlll : ()V
    //   6: invokestatic lIIIIIlllIllIllI : ()V
    //   9: invokestatic lIIIIIlllIlIllII : ()V
    //   12: new me/stupitdog/bhp/f9
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: <illegal opcode> 22 : (Lme/stupitdog/bhp/f9;)V
    //   24: new me/zero/alpine/EventManager
    //   27: dup
    //   28: invokespecial <init> : ()V
    //   31: <illegal opcode> 23 : (Lme/zero/alpine/EventManager;)V
    //   36: return
  }
  
  private static CallSite lIIIIIlllIIllIII(MethodHandles.Lookup lllllllllllllllIllIlIllIlIlllIII, String lllllllllllllllIllIlIllIlIllIlll, MethodType lllllllllllllllIllIlIllIlIllIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIllIlIlllllI = llIIIlIIIIlIlI[Integer.parseInt(lllllllllllllllIllIlIllIlIllIlll)].split(llIIIlIIIllIII[llIIIlIIIllIll[4]]);
      Class<?> lllllllllllllllIllIlIllIlIllllIl = Class.forName(lllllllllllllllIllIlIllIlIlllllI[llIIIlIIIllIll[0]]);
      String lllllllllllllllIllIlIllIlIllllII = lllllllllllllllIllIlIllIlIlllllI[llIIIlIIIllIll[1]];
      MethodHandle lllllllllllllllIllIlIllIlIlllIll = null;
      int lllllllllllllllIllIlIllIlIlllIlI = lllllllllllllllIllIlIllIlIlllllI[llIIIlIIIllIll[4]].length();
      if (lIIIIIlllIlllIIl(lllllllllllllllIllIlIllIlIlllIlI, llIIIlIIIllIll[3])) {
        MethodType lllllllllllllllIllIlIllIllIIIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIllIlIlllllI[llIIIlIIIllIll[3]], f9.class.getClassLoader());
        if (lIIIIIlllIlllIlI(lllllllllllllllIllIlIllIlIlllIlI, llIIIlIIIllIll[3])) {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findVirtual(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIllIIIIII);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findStatic(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIllIIIIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIllIlIllllll = llIIIlIIIIlIll[Integer.parseInt(lllllllllllllllIllIlIllIlIlllllI[llIIIlIIIllIll[3]])];
        if (lIIIIIlllIlllIlI(lllllllllllllllIllIlIllIlIlllIlI, llIIIlIIIllIll[4])) {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findGetter(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIlIllllll);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (lIIIIIlllIlllIlI(lllllllllllllllIllIlIllIlIlllIlI, llIIIlIIIllIll[5])) {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findStaticGetter(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIlIllllll);
          "".length();
          if (-" ".length() >= " ".length())
            return null; 
        } else if (lIIIIIlllIlllIlI(lllllllllllllllIllIlIllIlIlllIlI, llIIIlIIIllIll[6])) {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findSetter(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIlIllllll);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIllIlIlllIll = lllllllllllllllIllIlIllIlIlllIII.findStaticSetter(lllllllllllllllIllIlIllIlIllllIl, lllllllllllllllIllIlIllIlIllllII, lllllllllllllllIllIlIllIlIllllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIllIlIlllIll);
    } catch (Exception lllllllllllllllIllIlIllIlIlllIIl) {
      lllllllllllllllIllIlIllIlIlllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlllIlIllII() {
    llIIIlIIIIlIlI = new String[llIIIlIIIllIll[7]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[4]] = llIIIlIIIllIII[llIIIlIIIllIll[5]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[8]] = llIIIlIIIllIII[llIIIlIIIllIll[6]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[9]] = llIIIlIIIllIII[llIIIlIIIllIll[10]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[2]] = llIIIlIIIllIII[llIIIlIIIllIll[11]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[5]] = llIIIlIIIllIII[llIIIlIIIllIll[12]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[13]] = llIIIlIIIllIII[llIIIlIIIllIll[14]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[14]] = llIIIlIIIllIII[llIIIlIIIllIll[15]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[0]] = llIIIlIIIllIII[llIIIlIIIllIll[16]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[12]] = llIIIlIIIllIII[llIIIlIIIllIll[17]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[6]] = llIIIlIIIllIII[llIIIlIIIllIll[18]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[19]] = llIIIlIIIllIII[llIIIlIIIllIll[20]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[21]] = llIIIlIIIllIII[llIIIlIIIllIll[21]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[20]] = llIIIlIIIllIII[llIIIlIIIllIll[22]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[23]] = llIIIlIIIllIII[llIIIlIIIllIll[19]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[22]] = llIIIlIIIllIII[llIIIlIIIllIll[2]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[10]] = llIIIlIIIllIII[llIIIlIIIllIll[23]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[16]] = llIIIlIIIllIII[llIIIlIIIllIll[9]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[11]] = llIIIlIIIllIII[llIIIlIIIllIll[8]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[3]] = llIIIlIIIllIII[llIIIlIIIllIll[13]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[1]] = llIIIlIIIllIII[llIIIlIIIllIll[24]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[24]] = llIIIlIIIllIII[llIIIlIIIllIll[7]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[17]] = llIIIlIIIllIII[llIIIlIIIllIll[25]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[15]] = llIIIlIIIllIII[llIIIlIIIllIll[26]];
    llIIIlIIIIlIlI[llIIIlIIIllIll[18]] = llIIIlIIIllIII[llIIIlIIIllIll[27]];
    llIIIlIIIIlIll = new Class[llIIIlIIIllIll[18]];
    llIIIlIIIIlIll[llIIIlIIIllIll[10]] = fi.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[6]] = av.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[15]] = f10000000000000000000.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[17]] = EventManager.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[0]] = String.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[5]] = f1000000000000000000000.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[14]] = fd.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[3]] = f9.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[1]] = EventBus.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[4]] = ft.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[12]] = fa.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[11]] = a.class;
    llIIIlIIIIlIll[llIIIlIIIllIll[16]] = ap.class;
  }
  
  private static void lIIIIIlllIllIllI() {
    llIIIlIIIllIII = new String[llIIIlIIIllIll[28]];
    llIIIlIIIllIII[llIIIlIIIllIll[0]] = lIIIIIlllIlIllIl(llIIIlIIIllIlI[llIIIlIIIllIll[0]], llIIIlIIIllIlI[llIIIlIIIllIll[1]]);
    llIIIlIIIllIII[llIIIlIIIllIll[1]] = lIIIIIlllIlIlllI(llIIIlIIIllIlI[llIIIlIIIllIll[3]], llIIIlIIIllIlI[llIIIlIIIllIll[4]]);
    llIIIlIIIllIII[llIIIlIIIllIll[3]] = lIIIIIlllIlIllll(llIIIlIIIllIlI[llIIIlIIIllIll[5]], llIIIlIIIllIlI[llIIIlIIIllIll[6]]);
    llIIIlIIIllIII[llIIIlIIIllIll[4]] = lIIIIIlllIlIllIl(llIIIlIIIllIlI[llIIIlIIIllIll[10]], llIIIlIIIllIlI[llIIIlIIIllIll[11]]);
    llIIIlIIIllIII[llIIIlIIIllIll[5]] = lIIIIIlllIlIlllI(llIIIlIIIllIlI[llIIIlIIIllIll[12]], llIIIlIIIllIlI[llIIIlIIIllIll[14]]);
    llIIIlIIIllIII[llIIIlIIIllIll[6]] = lIIIIIlllIlIlllI(llIIIlIIIllIlI[llIIIlIIIllIll[15]], llIIIlIIIllIlI[llIIIlIIIllIll[16]]);
    llIIIlIIIllIII[llIIIlIIIllIll[10]] = lIIIIIlllIlIllll(llIIIlIIIllIlI[llIIIlIIIllIll[17]], llIIIlIIIllIlI[llIIIlIIIllIll[18]]);
    llIIIlIIIllIII[llIIIlIIIllIll[11]] = lIIIIIlllIlIllIl(llIIIlIIIllIlI[llIIIlIIIllIll[20]], llIIIlIIIllIlI[llIIIlIIIllIll[21]]);
    llIIIlIIIllIII[llIIIlIIIllIll[12]] = lIIIIIlllIlIlllI("FRFtASINBCoGMhcTbRA+CFolS2wdAiYcIigGLBEzCwcsAGxLTmNSdlhU", "xtCrV");
    llIIIlIIIllIII[llIIIlIIIllIll[14]] = lIIIIIlllIlIlllI("FQNePR4NFhk6DhcBXiwCCEgWd1ARCAM6CxYFFXRYQkZQbkpYRg==", "xfpNj");
    llIIIlIIIllIII[llIIIlIIIllIll[15]] = lIIIIIlllIlIllll("V9KZ4UyrNdx089wqEYqMNjzm6xctx6C5/g0NRtpOdcI=", "sbmMy");
    llIIIlIIIllIII[llIIIlIIIllIll[16]] = lIIIIIlllIlIllIl("D0akPsMnpqMqHgRCQATX/y1lnb2CQPWilxJiT61u0ZtQuTTibDJv5g==", "EcFgJ");
    llIIIlIIIllIII[llIIIlIIIllIll[17]] = lIIIIIlllIlIllll("O2lL78XBWRZaKtW8mWqJtBGq/GBTeL88FOB8E9Vsi65gk8ftOQDqqw==", "pRdvT");
    llIIIlIIIllIII[llIIIlIIIllIll[18]] = lIIIIIlllIlIllll("3/ol+g1wcS8hjnfehslvdLrp8N+8rav2l1rRJcHhHvlqBXuPR8LeHn/CxKu4Nqhk", "lhBel");
    llIIIlIIIllIII[llIIIlIIIllIll[20]] = lIIIIIlllIlIllIl("5duwPc0/u041SY8YRB5WFDavWhzg2XdbEsAS2wRX5qRYj6mu0zlxT2BNfTlv0ygjz9BwefuOsJqjwBYI941XIQ==", "coxQj");
    llIIIlIIIllIII[llIIIlIIIllIll[21]] = lIIIIIlllIlIllll("mEFZ46D+ozn8BYIxYM3CMP7VNFiVQ9jjB1//XhmlN5X7cTC1201Brg==", "mzUUq");
    llIIIlIIIllIII[llIIIlIIIllIll[22]] = lIIIIIlllIlIllll("4LGeuPicVtQtuD2Ydgqw0XSPSzBwse6Brjb2tv+ddrxyTu2pzrYn7w==", "uEfjU");
    llIIIlIIIllIII[llIIIlIIIllIll[19]] = lIIIIIlllIlIlllI("EDA8GGEWMCQeYSklOBAhHRM/ECMeNDhDLgohLxcrQHkGEy4MMGUVLhQ2ZSo7CDgkHnRTHSAYORt+JhghHX4ZDT0TPy07OhM9Lhw9QWtqWQ==", "zQJyO");
    llIIIlIIIllIII[llIIIlIIIllIll[2]] = lIIIIIlllIlIllll("3ZkAQbc3dQVriO5JyI+glTeZDGKLH9IwLMml9oEQqlvH730naU7To699AHN32ijtb6zOaRSqm3A=", "NYCah");
    llIIIlIIIllIII[llIIIlIIIllIll[23]] = lIIIIIlllIlIllll("vRn4T/1R5s/5ukBfsGStYdQDacLQrXB6dDYLqolUOflTGdabLj8Olbs8M0BqqH1+", "fMoBB");
    llIIIlIIIllIII[llIIIlIIIllIll[9]] = lIIIIIlllIlIllIl("XR1N4QN4Zdhl74uwkXR+BvgZKe+aWfY4W5eAhwQQZm/4oysc1gaYjX32Lu3Toz3j", "RyqkV");
    llIIIlIIIllIII[llIIIlIIIllIll[8]] = lIIIIIlllIlIllll("JBR1F0H7kQTFOaLX5F2l5qpqbXRwy0AojQ3KNFKjxu+Nz12TO4jGrwfZj71mUdQU", "KUTgX");
    llIIIlIIIllIII[llIIIlIIIllIll[13]] = lIIIIIlllIlIllll("invTOrAr5bID88B7WqP26sZhimXxT34J7d8ed25MDMAXWhNSSpmAUw==", "wKLcq");
    llIIIlIIIllIII[llIIIlIIIllIll[24]] = lIIIIIlllIlIllll("pJ7oxWbQRHWtGgSB5frAkhj0q8RiVxlS0xAjb5zR7NGd1/FYHwU7Q2GkJN0u2V0wQvd2MH9DNs1O5JZ2jKIMjQ==", "tRqtR");
    llIIIlIIIllIII[llIIIlIIIllIll[7]] = lIIIIIlllIlIlllI("AQ9EEBoZGgMXCgMNRAEGHEQMWlQpPC8tOjMoPzBUXVhQQ05MSkpD", "ljjcn");
    llIIIlIIIllIII[llIIIlIIIllIll[25]] = lIIIIIlllIlIllIl("ywtkzbcbaO0CZemuAqrX3J8ZlqKsU5UeXUAP+mZPMimCRZJZyENobUcvuRnSx1tH", "spQvT");
    llIIIlIIIllIII[llIIIlIIIllIll[26]] = lIIIIIlllIlIllIl("tzvaT/Pod4zjb7hq2s7bamB1Ofm3JE0SJVa9zIiULbPsFeTBO5SxqT2L7q9Tuotd", "cGtFv");
    llIIIlIIIllIII[llIIIlIIIllIll[27]] = lIIIIIlllIlIllll("TDbAGe16SXyFgFj1/RWynD9fIK3eFiBqHqn9C8kdfHMfTzpccSFWtQ==", "xYndG");
    llIIIlIIIllIlI = null;
  }
  
  private static void lIIIIIlllIllIlll() {
    String str = (new Exception()).getStackTrace()[llIIIlIIIllIll[0]].getFileName();
    llIIIlIIIllIlI = str.substring(str.indexOf("ä") + llIIIlIIIllIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlllIlIllll(String lllllllllllllllIllIlIllIlIllIIlI, String lllllllllllllllIllIlIllIlIllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIllIlIllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIllIlIllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIllIlIllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIllIlIllIlII.init(llIIIlIIIllIll[3], lllllllllllllllIllIlIllIlIllIlIl);
      return new String(lllllllllllllllIllIlIllIlIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIllIlIllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIllIlIllIIll) {
      lllllllllllllllIllIlIllIlIllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlllIlIllIl(String lllllllllllllllIllIlIllIlIlIllIl, String lllllllllllllllIllIlIllIlIlIllII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIllIlIllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIllIlIlIllII.getBytes(StandardCharsets.UTF_8)), llIIIlIIIllIll[12]), "DES");
      Cipher lllllllllllllllIllIlIllIlIlIllll = Cipher.getInstance("DES");
      lllllllllllllllIllIlIllIlIlIllll.init(llIIIlIIIllIll[3], lllllllllllllllIllIlIllIlIllIIII);
      return new String(lllllllllllllllIllIlIllIlIlIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIllIlIlIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIllIlIlIlllI) {
      lllllllllllllllIllIlIllIlIlIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlllIlIlllI(String lllllllllllllllIllIlIllIlIlIlIlI, String lllllllllllllllIllIlIllIlIlIlIIl) {
    lllllllllllllllIllIlIllIlIlIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIllIlIlIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIllIlIlIlIII = new StringBuilder();
    char[] lllllllllllllllIllIlIllIlIlIIlll = lllllllllllllllIllIlIllIlIlIlIIl.toCharArray();
    int lllllllllllllllIllIlIllIlIlIIllI = llIIIlIIIllIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIllIlIlIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIIIllIll[0];
    while (lIIIIIlllIlllIll(j, i)) {
      char lllllllllllllllIllIlIllIlIlIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIllIlIlIIllI++;
      j++;
      "".length();
      if (" ".length() << " ".length() != " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIllIlIlIlIII);
  }
  
  private static void lIIIIIlllIlllIII() {
    llIIIlIIIllIll = new int[29];
    llIIIlIIIllIll[0] = (0xBF ^ 0xBA) & (0x6A ^ 0x6F ^ 0xFFFFFFFF);
    llIIIlIIIllIll[1] = " ".length();
    llIIIlIIIllIll[2] = (0x43 ^ 0x4A) << " ".length();
    llIIIlIIIllIll[3] = " ".length() << " ".length();
    llIIIlIIIllIll[4] = "   ".length();
    llIIIlIIIllIll[5] = " ".length() << " ".length() << " ".length();
    llIIIlIIIllIll[6] = 0xBB ^ 0xBE;
    llIIIlIIIllIll[7] = "   ".length() << "   ".length();
    llIIIlIIIllIll[8] = 0x1 ^ 0x14;
    llIIIlIIIllIll[9] = (0x93 ^ 0xBE ^ (0x90 ^ 0x95) << "   ".length()) << " ".length() << " ".length();
    llIIIlIIIllIll[10] = "   ".length() << " ".length();
    llIIIlIIIllIll[11] = (0x87 ^ 0x94) << " ".length() ^ 0x84 ^ 0xA5;
    llIIIlIIIllIll[12] = " ".length() << "   ".length();
    llIIIlIIIllIll[13] = (93 + 3 - 70 + 177 ^ "   ".length() << "   ".length() << " ".length()) << " ".length();
    llIIIlIIIllIll[14] = 0x93 ^ 0x9A;
    llIIIlIIIllIll[15] = ((0xEF ^ 0xC4) << " ".length() ^ 0xF5 ^ 0xA6) << " ".length();
    llIIIlIIIllIll[16] = 0xCA ^ 0xC1;
    llIIIlIIIllIll[17] = "   ".length() << " ".length() << " ".length();
    llIIIlIIIllIll[18] = 0x41 ^ 0xC ^ " ".length() << "   ".length() << " ".length();
    llIIIlIIIllIll[19] = 0x11 ^ 0x0;
    llIIIlIIIllIll[20] = (0x7 ^ 0x0) << " ".length();
    llIIIlIIIllIll[21] = 39 + 125 - 57 + 56 ^ (0xA4 ^ 0x8F) << " ".length() << " ".length();
    llIIIlIIIllIll[22] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIlIIIllIll[23] = 0x5C ^ 0x69 ^ (0x33 ^ 0x20) << " ".length();
    llIIIlIIIllIll[24] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0x76 ^ 0x71;
    llIIIlIIIllIll[25] = 0xA1 ^ 0xB8;
    llIIIlIIIllIll[26] = (0x42 ^ 0x61 ^ (0xA5 ^ 0xB2) << " ".length()) << " ".length();
    llIIIlIIIllIll[27] = 0x30 ^ 0x1D ^ (0x74 ^ 0x6F) << " ".length();
    llIIIlIIIllIll[28] = (17 + 97 - 34 + 65 ^ (0xFC ^ 0xB7) << " ".length()) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIIlllIlllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlllIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlllIlllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f9.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */