package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class f7 extends au {
  private static String[] lIllIlIlIllIll;
  
  private static Class[] lIllIlIlIlllII;
  
  private static final String[] lIllIlIllIIIlI;
  
  private static String[] lIllIlIllIIIll;
  
  private static final int[] lIllIlIllIIlIl;
  
  public f7() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f7.lIllIlIllIIIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f7.lIllIlIllIIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f7.lIllIlIllIIIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f7.lIllIlIllIIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f7.lIllIlIllIIIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f7.lIllIlIllIIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f7.lIllIlIllIIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllllIlIlIlIlIllI	Lme/stupitdog/bhp/f7;
  }
  
  @SubscribeEvent
  public void onUpdateInput(InputUpdateEvent lllllllllllllllIllllIlIlIlIlIlII) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lnet/minecraftforge/client/event/InputUpdateEvent;)Lnet/minecraft/util/MovementInput;
    //   6: fconst_1
    //   7: putfield field_192832_b : F
    //   10: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	11	0	lllllllllllllllIllllIlIlIlIlIlIl	Lme/stupitdog/bhp/f7;
    //   0	11	1	lllllllllllllllIllllIlIlIlIlIlII	Lnet/minecraftforge/client/event/InputUpdateEvent;
  }
  
  static {
    llllIIllllllllI();
    llllIIlllllllII();
    llllIIllllllIll();
    llllIIlllllIlll();
  }
  
  private static CallSite llllIIllllIIIIl(MethodHandles.Lookup lllllllllllllllIllllIlIlIlIIlIll, String lllllllllllllllIllllIlIlIlIIlIlI, MethodType lllllllllllllllIllllIlIlIlIIlIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIlIlIlIlIIIl = lIllIlIlIllIll[Integer.parseInt(lllllllllllllllIllllIlIlIlIIlIlI)].split(lIllIlIllIIIlI[lIllIlIllIIlIl[3]]);
      Class<?> lllllllllllllllIllllIlIlIlIlIIII = Class.forName(lllllllllllllllIllllIlIlIlIlIIIl[lIllIlIllIIlIl[0]]);
      String lllllllllllllllIllllIlIlIlIIllll = lllllllllllllllIllllIlIlIlIlIIIl[lIllIlIllIIlIl[1]];
      MethodHandle lllllllllllllllIllllIlIlIlIIlllI = null;
      int lllllllllllllllIllllIlIlIlIIllIl = lllllllllllllllIllllIlIlIlIlIIIl[lIllIlIllIIlIl[3]].length();
      if (llllIlIIIIIIIII(lllllllllllllllIllllIlIlIlIIllIl, lIllIlIllIIlIl[2])) {
        MethodType lllllllllllllllIllllIlIlIlIlIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlIlIlIlIIIl[lIllIlIllIIlIl[2]], f7.class.getClassLoader());
        if (llllIlIIIIIIIIl(lllllllllllllllIllllIlIlIlIIllIl, lIllIlIllIIlIl[2])) {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findVirtual(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIll);
          "".length();
          if (-" ".length() > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findStatic(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIll);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIlIlIlIlIIlI = lIllIlIlIlllII[Integer.parseInt(lllllllllllllllIllllIlIlIlIlIIIl[lIllIlIllIIlIl[2]])];
        if (llllIlIIIIIIIIl(lllllllllllllllIllllIlIlIlIIllIl, lIllIlIllIIlIl[3])) {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findGetter(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIlI);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else if (llllIlIIIIIIIIl(lllllllllllllllIllllIlIlIlIIllIl, lIllIlIllIIlIl[4])) {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findStaticGetter(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIlI);
          "".length();
          if (" ".length() << " ".length() <= -" ".length())
            return null; 
        } else if (llllIlIIIIIIIIl(lllllllllllllllIllllIlIlIlIIllIl, lIllIlIllIIlIl[5])) {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findSetter(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIlI);
          "".length();
          if (((0x66 ^ 0x75) << " ".length() & ((0x19 ^ 0xA) << " ".length() ^ 0xFFFFFFFF)) != ((0x46 ^ 0x4D) << " ".length() & ((0x54 ^ 0x5F) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else {
          lllllllllllllllIllllIlIlIlIIlllI = lllllllllllllllIllllIlIlIlIIlIll.findStaticSetter(lllllllllllllllIllllIlIlIlIlIIII, lllllllllllllllIllllIlIlIlIIllll, lllllllllllllllIllllIlIlIlIlIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIlIlIlIIlllI);
    } catch (Exception lllllllllllllllIllllIlIlIlIIllII) {
      lllllllllllllllIllllIlIlIlIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlllllIlll() {
    lIllIlIlIllIll = new String[lIllIlIllIIlIl[2]];
    lIllIlIlIllIll[lIllIlIllIIlIl[0]] = lIllIlIllIIIlI[lIllIlIllIIlIl[4]];
    lIllIlIlIllIll[lIllIlIllIIlIl[1]] = lIllIlIllIIIlI[lIllIlIllIIlIl[5]];
    lIllIlIlIlllII = new Class[lIllIlIllIIlIl[2]];
    lIllIlIlIlllII[lIllIlIllIIlIl[1]] = float.class;
    lIllIlIlIlllII[lIllIlIllIIlIl[0]] = f13.class;
  }
  
  private static void llllIIllllllIll() {
    lIllIlIllIIIlI = new String[lIllIlIllIIlIl[6]];
    lIllIlIllIIIlI[lIllIlIllIIlIl[0]] = llllIIllllllIIl(lIllIlIllIIIll[lIllIlIllIIlIl[0]], lIllIlIllIIIll[lIllIlIllIIlIl[1]]);
    lIllIlIllIIIlI[lIllIlIllIIlIl[1]] = llllIIllllllIIl(lIllIlIllIIIll[lIllIlIllIIlIl[2]], lIllIlIllIIIll[lIllIlIllIIlIl[3]]);
    lIllIlIllIIIlI[lIllIlIllIIlIl[2]] = llllIIllllllIIl(lIllIlIllIIIll[lIllIlIllIIlIl[4]], lIllIlIllIIIll[lIllIlIllIIlIl[5]]);
    lIllIlIllIIIlI[lIllIlIllIIlIl[3]] = llllIIllllllIlI(lIllIlIllIIIll[lIllIlIllIIlIl[6]], lIllIlIllIIIll[lIllIlIllIIlIl[7]]);
    lIllIlIllIIIlI[lIllIlIllIIlIl[4]] = llllIIllllllIlI(lIllIlIllIIIll[lIllIlIllIIlIl[8]], lIllIlIllIIIll[lIllIlIllIIlIl[9]]);
    lIllIlIllIIIlI[lIllIlIllIIlIl[5]] = llllIIllllllIIl(lIllIlIllIIIll[lIllIlIllIIlIl[10]], lIllIlIllIIIll[lIllIlIllIIlIl[11]]);
    lIllIlIllIIIll = null;
  }
  
  private static void llllIIlllllllII() {
    String str = (new Exception()).getStackTrace()[lIllIlIllIIlIl[0]].getFileName();
    lIllIlIllIIIll = str.substring(str.indexOf("ä") + lIllIlIllIIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIllllllIlI(String lllllllllllllllIllllIlIlIlIIIlIl, String lllllllllllllllIllllIlIlIlIIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIlIlIIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIlIlIIIlII.getBytes(StandardCharsets.UTF_8)), lIllIlIllIIlIl[8]), "DES");
      Cipher lllllllllllllllIllllIlIlIlIIIlll = Cipher.getInstance("DES");
      lllllllllllllllIllllIlIlIlIIIlll.init(lIllIlIllIIlIl[2], lllllllllllllllIllllIlIlIlIIlIII);
      return new String(lllllllllllllllIllllIlIlIlIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIlIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIlIlIIIllI) {
      lllllllllllllllIllllIlIlIlIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIllllllIIl(String lllllllllllllllIllllIlIlIlIIIIlI, String lllllllllllllllIllllIlIlIlIIIIIl) {
    lllllllllllllllIllllIlIlIlIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIlIlIlIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIlIlIlIIIIII = new StringBuilder();
    char[] lllllllllllllllIllllIlIlIIllllll = lllllllllllllllIllllIlIlIlIIIIIl.toCharArray();
    int lllllllllllllllIllllIlIlIIlllllI = lIllIlIllIIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIlIlIlIIIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlIllIIlIl[0];
    while (llllIlIIIIIIIlI(j, i)) {
      char lllllllllllllllIllllIlIlIlIIIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIlIlIIlllllI++;
      j++;
      "".length();
      if (-" ".length() >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIlIlIlIIIIII);
  }
  
  private static void llllIIllllllllI() {
    lIllIlIllIIlIl = new int[12];
    lIllIlIllIIlIl[0] = ((0x9A ^ 0xA9) << " ".length() ^ 0x65 ^ 0x36) & ((0x2E ^ 0x3D) << " ".length() << " ".length() ^ 0xE ^ 0x77 ^ -" ".length());
    lIllIlIllIIlIl[1] = " ".length();
    lIllIlIllIIlIl[2] = " ".length() << " ".length();
    lIllIlIllIIlIl[3] = "   ".length();
    lIllIlIllIIlIl[4] = " ".length() << " ".length() << " ".length();
    lIllIlIllIIlIl[5] = 0xA9 ^ 0x88 ^ (0xA8 ^ 0xA1) << " ".length() << " ".length();
    lIllIlIllIIlIl[6] = "   ".length() << " ".length();
    lIllIlIllIIlIl[7] = (0x1C ^ 0x2B) << " ".length() ^ 0xC9 ^ 0xA0;
    lIllIlIllIIlIl[8] = " ".length() << "   ".length();
    lIllIlIllIIlIl[9] = (0x6C ^ 0x65) << " ".length() << " ".length() << " ".length() ^ 136 + 99 - 96 + 14;
    lIllIlIllIIlIl[10] = (0x46 ^ 0x43) << " ".length();
    lIllIlIllIIlIl[11] = (0x42 ^ 0xD) << " ".length() ^ 140 + 50 - 132 + 91;
  }
  
  private static boolean llllIlIIIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIIIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIIIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f7.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */