package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f1000000000000000 extends au {
  public static f100000000000000000000.Double reach;
  
  private static String[] lIllIIlIlIlIll;
  
  private static Class[] lIllIIlIlIllII;
  
  private static final String[] lIllIIlIlIllIl;
  
  private static String[] lIllIIlIlIllll;
  
  private static final int[] lIllIIlIllIIII;
  
  public f1000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIlIllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIllIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIlIllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIllIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIlIllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIllIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIllIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIlIllIl : [Ljava/lang/String;
    //   45: getstatic me/stupitdog/bhp/f1000000000000000.lIllIIlIllIIII : [I
    //   48: iconst_3
    //   49: iaload
    //   50: aaload
    //   51: ldc2_w 3.5
    //   54: dconst_0
    //   55: ldc2_w 5.0
    //   58: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1000000000000000;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   63: <illegal opcode> 2 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   68: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	69	0	lllllllllllllllIlllllIIlllIlIIlI	Lme/stupitdog/bhp/f1000000000000000;
  }
  
  static {
    llllIIIlIIIlIIl();
    llllIIIlIIIIllI();
    llllIIIlIIIIlIl();
    llllIIIIlllllIl();
  }
  
  private static CallSite llllIIIIlllllII(MethodHandles.Lookup lllllllllllllllIlllllIIlllIIlIIl, String lllllllllllllllIlllllIIlllIIlIII, MethodType lllllllllllllllIlllllIIlllIIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIIlllIIllll = lIllIIlIlIlIll[Integer.parseInt(lllllllllllllllIlllllIIlllIIlIII)].split(lIllIIlIlIllIl[lIllIIlIllIIII[4]]);
      Class<?> lllllllllllllllIlllllIIlllIIlllI = Class.forName(lllllllllllllllIlllllIIlllIIllll[lIllIIlIllIIII[0]]);
      String lllllllllllllllIlllllIIlllIIllIl = lllllllllllllllIlllllIIlllIIllll[lIllIIlIllIIII[1]];
      MethodHandle lllllllllllllllIlllllIIlllIIllII = null;
      int lllllllllllllllIlllllIIlllIIlIll = lllllllllllllllIlllllIIlllIIllll[lIllIIlIllIIII[3]].length();
      if (llllIIIlIIIlIlI(lllllllllllllllIlllllIIlllIIlIll, lIllIIlIllIIII[2])) {
        MethodType lllllllllllllllIlllllIIlllIlIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIIlllIIllll[lIllIIlIllIIII[2]], f1000000000000000.class.getClassLoader());
        if (llllIIIlIIIlIll(lllllllllllllllIlllllIIlllIIlIll, lIllIIlIllIIII[2])) {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findVirtual(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findStatic(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIIl);
        } 
        "".length();
        if (" ".length() >= "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIIlllIlIIII = lIllIIlIlIllII[Integer.parseInt(lllllllllllllllIlllllIIlllIIllll[lIllIIlIllIIII[2]])];
        if (llllIIIlIIIlIll(lllllllllllllllIlllllIIlllIIlIll, lIllIIlIllIIII[3])) {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findGetter(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIII);
          "".length();
          if (" ".length() << " ".length() <= ((0x17 ^ 0x1C) << " ".length() << " ".length() & ((0x12 ^ 0x19) << " ".length() << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (llllIIIlIIIlIll(lllllllllllllllIlllllIIlllIIlIll, lIllIIlIllIIII[4])) {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findStaticGetter(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIII);
          "".length();
          if (" ".length() <= ((0x62 ^ 0x3D) & (0x58 ^ 0x7 ^ 0xFFFFFFFF)))
            return null; 
        } else if (llllIIIlIIIlIll(lllllllllllllllIlllllIIlllIIlIll, lIllIIlIllIIII[5])) {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findSetter(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIII);
          "".length();
          if (" ".length() << " ".length() <= " ".length())
            return null; 
        } else {
          lllllllllllllllIlllllIIlllIIllII = lllllllllllllllIlllllIIlllIIlIIl.findStaticSetter(lllllllllllllllIlllllIIlllIIlllI, lllllllllllllllIlllllIIlllIIllIl, lllllllllllllllIlllllIIlllIlIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIIlllIIllII);
    } catch (Exception lllllllllllllllIlllllIIlllIIlIlI) {
      lllllllllllllllIlllllIIlllIIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIIlllllIl() {
    lIllIIlIlIlIll = new String[lIllIIlIllIIII[3]];
    lIllIIlIlIlIll[lIllIIlIllIIII[2]] = lIllIIlIlIllIl[lIllIIlIllIIII[5]];
    lIllIIlIlIlIll[lIllIIlIllIIII[0]] = lIllIIlIlIllIl[lIllIIlIllIIII[6]];
    lIllIIlIlIlIll[lIllIIlIllIIII[1]] = lIllIIlIlIllIl[lIllIIlIllIIII[7]];
    lIllIIlIlIllII = new Class[lIllIIlIllIIII[2]];
    lIllIIlIlIllII[lIllIIlIllIIII[0]] = f13.class;
    lIllIIlIlIllII[lIllIIlIllIIII[1]] = f100000000000000000000.Double.class;
  }
  
  private static void llllIIIlIIIIlIl() {
    lIllIIlIlIllIl = new String[lIllIIlIllIIII[8]];
    lIllIIlIlIllIl[lIllIIlIllIIII[0]] = llllIIIIllllllI(lIllIIlIlIllll[lIllIIlIllIIII[0]], lIllIIlIlIllll[lIllIIlIllIIII[1]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[1]] = llllIIIIlllllll(lIllIIlIlIllll[lIllIIlIllIIII[2]], lIllIIlIlIllll[lIllIIlIllIIII[3]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[2]] = llllIIIIllllllI(lIllIIlIlIllll[lIllIIlIllIIII[4]], lIllIIlIlIllll[lIllIIlIllIIII[5]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[3]] = llllIIIIllllllI(lIllIIlIlIllll[lIllIIlIllIIII[6]], lIllIIlIlIllll[lIllIIlIllIIII[7]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[4]] = llllIIIIlllllll(lIllIIlIlIllll[lIllIIlIllIIII[8]], lIllIIlIlIllll[lIllIIlIllIIII[9]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[5]] = llllIIIlIIIIIll(lIllIIlIlIllll[lIllIIlIllIIII[10]], lIllIIlIlIllll[lIllIIlIllIIII[11]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[6]] = llllIIIIlllllll(lIllIIlIlIllll[lIllIIlIllIIII[12]], lIllIIlIlIllll[lIllIIlIllIIII[13]]);
    lIllIIlIlIllIl[lIllIIlIllIIII[7]] = llllIIIlIIIIIll(lIllIIlIlIllll[lIllIIlIllIIII[14]], lIllIIlIlIllll[lIllIIlIllIIII[15]]);
    lIllIIlIlIllll = null;
  }
  
  private static void llllIIIlIIIIllI() {
    String str = (new Exception()).getStackTrace()[lIllIIlIllIIII[0]].getFileName();
    lIllIIlIlIllll = str.substring(str.indexOf("ä") + lIllIIlIllIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIIllllllI(String lllllllllllllllIlllllIIlllIIIlIl, String lllllllllllllllIlllllIIlllIIIlII) {
    lllllllllllllllIlllllIIlllIIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIIlllIIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIIlllIIIIll = new StringBuilder();
    char[] lllllllllllllllIlllllIIlllIIIIlI = lllllllllllllllIlllllIIlllIIIlII.toCharArray();
    int lllllllllllllllIlllllIIlllIIIIIl = lIllIIlIllIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllllIIlllIIIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIIlIllIIII[0];
    while (llllIIIlIIIllII(j, i)) {
      char lllllllllllllllIlllllIIlllIIIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllllIIlllIIIIIl++;
      j++;
      "".length();
      if ("   ".length() < " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllllIIlllIIIIll);
  }
  
  private static String llllIIIlIIIIIll(String lllllllllllllllIlllllIIllIllllIl, String lllllllllllllllIlllllIIllIllllII) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIlllIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIllIllllII.getBytes(StandardCharsets.UTF_8)), lIllIIlIllIIII[8]), "DES");
      Cipher lllllllllllllllIlllllIIllIllllll = Cipher.getInstance("DES");
      lllllllllllllllIlllllIIllIllllll.init(lIllIIlIllIIII[2], lllllllllllllllIlllllIIlllIIIIII);
      return new String(lllllllllllllllIlllllIIllIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIllIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIllIlllllI) {
      lllllllllllllllIlllllIIllIlllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIIlllllll(String lllllllllllllllIlllllIIllIlllIII, String lllllllllllllllIlllllIIllIllIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIllIlllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIllIllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIIllIlllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIIllIlllIlI.init(lIllIIlIllIIII[2], lllllllllllllllIlllllIIllIlllIll);
      return new String(lllllllllllllllIlllllIIllIlllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIllIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIllIlllIIl) {
      lllllllllllllllIlllllIIllIlllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIlIIIlIIl() {
    lIllIIlIllIIII = new int[16];
    lIllIIlIllIIII[0] = "   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIllIIlIllIIII[1] = " ".length();
    lIllIIlIllIIII[2] = " ".length() << " ".length();
    lIllIIlIllIIII[3] = "   ".length();
    lIllIIlIllIIII[4] = " ".length() << " ".length() << " ".length();
    lIllIIlIllIIII[5] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x66 ^ 0x53;
    lIllIIlIllIIII[6] = "   ".length() << " ".length();
    lIllIIlIllIIII[7] = 0x97 ^ 0x90;
    lIllIIlIllIIII[8] = " ".length() << "   ".length();
    lIllIIlIllIIII[9] = 0x46 ^ 0x4F;
    lIllIIlIllIIII[10] = ((0x10 ^ 0x1D) << " ".length() ^ 0xA0 ^ 0xBF) << " ".length();
    lIllIIlIllIIII[11] = (0x35 ^ 0x3E) << " ".length() << " ".length() ^ 0x99 ^ 0xBE;
    lIllIIlIllIIII[12] = "   ".length() << " ".length() << " ".length();
    lIllIIlIllIIII[13] = 0xCD ^ 0xC0;
    lIllIIlIllIIII[14] = (0xB6 ^ 0xB1) << " ".length();
    lIllIIlIllIIII[15] = 0x25 ^ 0x2A;
  }
  
  private static boolean llllIIIlIIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIIlIIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIIlIIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */