package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class fx extends au {
  f100000000000000000000.Integer fov;
  
  f100000000000000000000.Boolean item;
  
  float df;
  
  private static String[] llIIlIIlIlIlll;
  
  private static Class[] llIIlIIlIllIII;
  
  private static final String[] llIIlIIlIlllII;
  
  private static String[] llIIlIIlIlllIl;
  
  private static final int[] llIIlIIlIllllI;
  
  public fx() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fx.llIIlIIlIlllII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fx.llIIlIIlIlllII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fx.llIIlIIlIlllII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIllIlIIIIllII	Lme/stupitdog/bhp/fx;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/fx.llIIlIIlIlllII : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   14: iconst_4
    //   15: iaload
    //   16: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   19: iconst_5
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   24: bipush #6
    //   26: iaload
    //   27: <illegal opcode> 1 : (Lme/stupitdog/bhp/fx;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   32: <illegal opcode> 2 : (Lme/stupitdog/bhp/fx;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   37: aload_0
    //   38: aload_0
    //   39: getstatic me/stupitdog/bhp/fx.llIIlIIlIlllII : [Ljava/lang/String;
    //   42: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   45: bipush #7
    //   47: iaload
    //   48: aaload
    //   49: getstatic me/stupitdog/bhp/fx.llIIlIIlIllllI : [I
    //   52: iconst_1
    //   53: iaload
    //   54: <illegal opcode> 3 : (Lme/stupitdog/bhp/fx;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   59: <illegal opcode> 4 : (Lme/stupitdog/bhp/fx;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   64: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	65	0	lllllllllllllllIllIIllIlIIIIlIll	Lme/stupitdog/bhp/fx;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   6: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   11: <illegal opcode> 7 : (Lnet/minecraft/client/settings/GameSettings;)F
    //   16: <illegal opcode> 8 : (Lme/stupitdog/bhp/fx;F)V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIllIIllIlIIIIlIlI	Lme/stupitdog/bhp/fx;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   10: aload_0
    //   11: <illegal opcode> 9 : (Lme/stupitdog/bhp/fx;)F
    //   16: putfield field_74334_X : F
    //   19: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIIllIlIIIIlIIl	Lme/stupitdog/bhp/fx;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   10: aload_0
    //   11: <illegal opcode> 10 : (Lme/stupitdog/bhp/fx;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   16: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   21: i2f
    //   22: putfield field_74334_X : F
    //   25: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	26	0	lllllllllllllllIllIIllIlIIIIlIII	Lme/stupitdog/bhp/fx;
  }
  
  @SubscribeEvent
  public void fovRender(EntityViewRenderEvent.FOVModifier lllllllllllllllIllIIllIlIIIIIllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 12 : (Lme/stupitdog/bhp/fx;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: invokestatic lIIIIllIllIIIIIl : (I)Z
    //   14: ifeq -> 35
    //   17: aload_1
    //   18: aload_0
    //   19: <illegal opcode> 10 : (Lme/stupitdog/bhp/fx;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   24: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   29: i2f
    //   30: <illegal opcode> 14 : (Lnet/minecraftforge/client/event/EntityViewRenderEvent$FOVModifier;F)V
    //   35: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	36	0	lllllllllllllllIllIIllIlIIIIIlll	Lme/stupitdog/bhp/fx;
    //   0	36	1	lllllllllllllllIllIIllIlIIIIIllI	Lnet/minecraftforge/client/event/EntityViewRenderEvent$FOVModifier;
  }
  
  static {
    lIIIIllIllIIIIII();
    lIIIIllIlIllllll();
    lIIIIllIlIlllllI();
    lIIIIllIlIlllIlI();
  }
  
  private static CallSite lIIIIllIlIlIllIl(MethodHandles.Lookup lllllllllllllllIllIIllIIllllllIl, String lllllllllllllllIllIIllIIllllllII, MethodType lllllllllllllllIllIIllIIlllllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIlIIIIIIll = llIIlIIlIlIlll[Integer.parseInt(lllllllllllllllIllIIllIIllllllII)].split(llIIlIIlIlllII[llIIlIIlIllllI[8]]);
      Class<?> lllllllllllllllIllIIllIlIIIIIIlI = Class.forName(lllllllllllllllIllIIllIlIIIIIIll[llIIlIIlIllllI[0]]);
      String lllllllllllllllIllIIllIlIIIIIIIl = lllllllllllllllIllIIllIlIIIIIIll[llIIlIIlIllllI[1]];
      MethodHandle lllllllllllllllIllIIllIlIIIIIIII = null;
      int lllllllllllllllIllIIllIIllllllll = lllllllllllllllIllIIllIlIIIIIIll[llIIlIIlIllllI[3]].length();
      if (lIIIIllIllIIIIlI(lllllllllllllllIllIIllIIllllllll, llIIlIIlIllllI[2])) {
        MethodType lllllllllllllllIllIIllIlIIIIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIlIIIIIIll[llIIlIIlIllllI[2]], fx.class.getClassLoader());
        if (lIIIIllIllIIIIll(lllllllllllllllIllIIllIIllllllll, llIIlIIlIllllI[2])) {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findVirtual(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlIl);
          "".length();
          if ("   ".length() < (((0x11 ^ 0x0) << " ".length() ^ 0x84 ^ 0x8D) << " ".length() & ((0x45 ^ 0x20 ^ (0x72 ^ 0x55) << " ".length()) << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findStatic(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlIl);
        } 
        "".length();
        if (((0xF ^ 0x24) & (0xA1 ^ 0x8A ^ 0xFFFFFFFF)) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIlIIIIIlII = llIIlIIlIllIII[Integer.parseInt(lllllllllllllllIllIIllIlIIIIIIll[llIIlIIlIllllI[2]])];
        if (lIIIIllIllIIIIll(lllllllllllllllIllIIllIIllllllll, llIIlIIlIllllI[3])) {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findGetter(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlII);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= "   ".length())
            return null; 
        } else if (lIIIIllIllIIIIll(lllllllllllllllIllIIllIIllllllll, llIIlIIlIllllI[7])) {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findStaticGetter(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIllIllIIIIll(lllllllllllllllIllIIllIIllllllll, llIIlIIlIllllI[8])) {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findSetter(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlII);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIlIIIIIIII = lllllllllllllllIllIIllIIllllllIl.findStaticSetter(lllllllllllllllIllIIllIlIIIIIIlI, lllllllllllllllIllIIllIlIIIIIIIl, lllllllllllllllIllIIllIlIIIIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIlIIIIIIII);
    } catch (Exception lllllllllllllllIllIIllIIlllllllI) {
      lllllllllllllllIllIIllIIlllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIlIlllIlI() {
    llIIlIIlIlIlll = new String[llIIlIIlIllllI[9]];
    llIIlIIlIlIlll[llIIlIIlIllllI[10]] = llIIlIIlIlllII[llIIlIIlIllllI[11]];
    llIIlIIlIlIlll[llIIlIIlIllllI[12]] = llIIlIIlIlllII[llIIlIIlIllllI[13]];
    llIIlIIlIlIlll[llIIlIIlIllllI[14]] = llIIlIIlIlllII[llIIlIIlIllllI[15]];
    llIIlIIlIlIlll[llIIlIIlIllllI[16]] = llIIlIIlIlllII[llIIlIIlIllllI[17]];
    llIIlIIlIlIlll[llIIlIIlIllllI[2]] = llIIlIIlIlllII[llIIlIIlIllllI[12]];
    llIIlIIlIlIlll[llIIlIIlIllllI[1]] = llIIlIIlIlllII[llIIlIIlIllllI[18]];
    llIIlIIlIlIlll[llIIlIIlIllllI[8]] = llIIlIIlIlllII[llIIlIIlIllllI[14]];
    llIIlIIlIlIlll[llIIlIIlIllllI[13]] = llIIlIIlIlllII[llIIlIIlIllllI[16]];
    llIIlIIlIlIlll[llIIlIIlIllllI[0]] = llIIlIIlIlllII[llIIlIIlIllllI[10]];
    llIIlIIlIlIlll[llIIlIIlIllllI[3]] = llIIlIIlIlllII[llIIlIIlIllllI[9]];
    llIIlIIlIlIlll[llIIlIIlIllllI[17]] = llIIlIIlIlllII[llIIlIIlIllllI[19]];
    llIIlIIlIlIlll[llIIlIIlIllllI[7]] = llIIlIIlIlllII[llIIlIIlIllllI[20]];
    llIIlIIlIlIlll[llIIlIIlIllllI[11]] = llIIlIIlIlllII[llIIlIIlIllllI[21]];
    llIIlIIlIlIlll[llIIlIIlIllllI[18]] = llIIlIIlIlllII[llIIlIIlIllllI[22]];
    llIIlIIlIlIlll[llIIlIIlIllllI[15]] = llIIlIIlIlllII[llIIlIIlIllllI[23]];
    llIIlIIlIllIII = new Class[llIIlIIlIllllI[11]];
    llIIlIIlIllIII[llIIlIIlIllllI[8]] = float.class;
    llIIlIIlIllIII[llIIlIIlIllllI[0]] = f13.class;
    llIIlIIlIllIII[llIIlIIlIllllI[1]] = f100000000000000000000.Integer.class;
    llIIlIIlIllIII[llIIlIIlIllllI[3]] = Minecraft.class;
    llIIlIIlIllIII[llIIlIIlIllllI[7]] = GameSettings.class;
    llIIlIIlIllIII[llIIlIIlIllllI[2]] = f100000000000000000000.Boolean.class;
  }
  
  private static void lIIIIllIlIlllllI() {
    llIIlIIlIlllII = new String[llIIlIIlIllllI[24]];
    llIIlIIlIlllII[llIIlIIlIllllI[0]] = lIIIIllIlIlllIll(llIIlIIlIlllIl[llIIlIIlIllllI[0]], llIIlIIlIlllIl[llIIlIIlIllllI[1]]);
    llIIlIIlIlllII[llIIlIIlIllllI[1]] = lIIIIllIlIlllIll(llIIlIIlIlllIl[llIIlIIlIllllI[2]], llIIlIIlIlllIl[llIIlIIlIllllI[3]]);
    llIIlIIlIlllII[llIIlIIlIllllI[2]] = lIIIIllIlIlllIll(llIIlIIlIlllIl[llIIlIIlIllllI[7]], llIIlIIlIlllIl[llIIlIIlIllllI[8]]);
    llIIlIIlIlllII[llIIlIIlIllllI[3]] = lIIIIllIlIllllII(llIIlIIlIlllIl[llIIlIIlIllllI[11]], llIIlIIlIlllIl[llIIlIIlIllllI[13]]);
    llIIlIIlIlllII[llIIlIIlIllllI[7]] = lIIIIllIlIllllII(llIIlIIlIlllIl[llIIlIIlIllllI[15]], llIIlIIlIlllIl[llIIlIIlIllllI[17]]);
    llIIlIIlIlllII[llIIlIIlIllllI[8]] = lIIIIllIlIllllIl(llIIlIIlIlllIl[llIIlIIlIllllI[12]], llIIlIIlIlllIl[llIIlIIlIllllI[18]]);
    llIIlIIlIlllII[llIIlIIlIllllI[11]] = lIIIIllIlIllllII(llIIlIIlIlllIl[llIIlIIlIllllI[14]], llIIlIIlIlllIl[llIIlIIlIllllI[16]]);
    llIIlIIlIlllII[llIIlIIlIllllI[13]] = lIIIIllIlIllllII(llIIlIIlIlllIl[llIIlIIlIllllI[10]], llIIlIIlIlllIl[llIIlIIlIllllI[9]]);
    llIIlIIlIlllII[llIIlIIlIllllI[15]] = lIIIIllIlIlllIll(llIIlIIlIlllIl[llIIlIIlIllllI[19]], llIIlIIlIlllIl[llIIlIIlIllllI[20]]);
    llIIlIIlIlllII[llIIlIIlIllllI[17]] = lIIIIllIlIlllIll(llIIlIIlIlllIl[llIIlIIlIllllI[21]], llIIlIIlIlllIl[llIIlIIlIllllI[22]]);
    llIIlIIlIlllII[llIIlIIlIllllI[12]] = lIIIIllIlIllllII(llIIlIIlIlllIl[llIIlIIlIllllI[23]], llIIlIIlIlllIl[llIIlIIlIllllI[24]]);
    llIIlIIlIlllII[llIIlIIlIllllI[18]] = lIIIIllIlIllllII("8oywwJHGCENmZ7G96xIcOa6Ydt++jdSmltlRDCImi1kmUqXvX7pF0YcD4j180+wvaD49yGA9w2YUC4ssFWuUdCxlPySRX52KaRqgcScBDjgR4ZnCPU2oNhHhmcI9Tag201qnF5TWN5yDp/ayCvksEg==", "YmJPi");
    llIIlIIlIlllII[llIIlIIlIllllI[14]] = lIIIIllIlIllllIl("cMSfEuS5SAHTJAVT7yxZZmT5j0kAaJt0frW/gv8AcKQ=", "ENWJF");
    llIIlIIlIlllII[llIIlIIlIllllI[16]] = lIIIIllIlIlllIll("GwAMaiYcCx0nORQDDGooGQwdKj9bFh0wPxwLHzdlMgQVIRgQEQwtJRIWQiIiEAkcG3xBVktwFC1fTX5rVUU=", "uexDK");
    llIIlIIlIlllII[llIIlIIlIllllI[10]] = lIIIIllIlIllllIl("eDlfvB7Zrgo95qcU1TyM94yYr4C6Nk1X/j3oiFMi1U1AMIoTuSwXtw==", "BHMlt");
    llIIlIIlIlllII[llIIlIIlIllllI[9]] = lIIIIllIlIllllIl("Mqwh/jKtjjs/vfEZYDNjJepaBbDX7qZbmjY3Wz0PCoeh2Uv3SsxK/a77iOCgXTjo6n9zp60ZQWTJcOhoHino3qyAXemGHEY1VbQXv6CyHv/m4cPJD2lslubhw8kPaWyWaugdejg/+KXR/IIXB1pHnQ==", "TvaLW");
    llIIlIIlIlllII[llIIlIIlIllllI[19]] = lIIIIllIlIllllII("q+r2zA4qRo4ag5oEXhAQ95dOKZ3iUaqDastVKo9szQM=", "fkjXo");
    llIIlIIlIlllII[llIIlIIlIllllI[20]] = lIIIIllIlIllllIl("EmKeh9eyKrp+uenkf4bESHrxnHsgYPEd0S5MMYlPEzIGen+21zYX8Q==", "fIWjn");
    llIIlIIlIlllII[llIIlIIlIllllI[21]] = lIIIIllIlIllllII("GLse3f0qNo7uTNA2XzShYrvEugbUs3BQ6ORkax6AdIdFU4nARPPFwJsmh8kgiUgMKHfZs1QB5sQ=", "MbcWv");
    llIIlIIlIlllII[llIIlIIlIllllI[22]] = lIIIIllIlIlllIll("HQt8PAYFHjs7Fh8JfC0aAEA0fkJAXmJ/QkBeYn9CQF5if0JAXmJ/VjkAJioVFRxoKBcEODMjBxVUemY7Sk5y", "pnROr");
    llIIlIIlIlllII[llIIlIIlIllllI[23]] = lIIIIllIlIllllIl("0eXpbs8BwjTZWroDkCCe1v9auYMqkgOSknhoZ6D3Mz8=", "UbqNU");
    llIIlIIlIlllIl = null;
  }
  
  private static void lIIIIllIlIllllll() {
    String str = (new Exception()).getStackTrace()[llIIlIIlIllllI[0]].getFileName();
    llIIlIIlIlllIl = str.substring(str.indexOf("ä") + llIIlIIlIllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIlIllllIl(String lllllllllllllllIllIIllIIllllIlll, String lllllllllllllllIllIIllIIllllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIIlllllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIIllllIllI.getBytes(StandardCharsets.UTF_8)), llIIlIIlIllllI[15]), "DES");
      Cipher lllllllllllllllIllIIllIIlllllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIIlllllIIl.init(llIIlIIlIllllI[2], lllllllllllllllIllIIllIIlllllIlI);
      return new String(lllllllllllllllIllIIllIIlllllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIIllllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIIlllllIII) {
      lllllllllllllllIllIIllIIlllllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIlIllllII(String lllllllllllllllIllIIllIIllllIIlI, String lllllllllllllllIllIIllIIllllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIIllllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIIllllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIIllllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIIllllIlII.init(llIIlIIlIllllI[2], lllllllllllllllIllIIllIIllllIlIl);
      return new String(lllllllllllllllIllIIllIIllllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIIllllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIIllllIIll) {
      lllllllllllllllIllIIllIIllllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIlIlllIll(String lllllllllllllllIllIIllIIlllIllll, String lllllllllllllllIllIIllIIlllIlllI) {
    lllllllllllllllIllIIllIIlllIllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllIIlllIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllIIlllIllIl = new StringBuilder();
    char[] lllllllllllllllIllIIllIIlllIllII = lllllllllllllllIllIIllIIlllIlllI.toCharArray();
    int lllllllllllllllIllIIllIIlllIlIll = llIIlIIlIllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIllIIlllIllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIlIllllI[0];
    while (lIIIIllIllIIIlII(j, i)) {
      char lllllllllllllllIllIIllIIllllIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllIIlllIlIll++;
      j++;
      "".length();
      if ("   ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllIIlllIllIl);
  }
  
  private static void lIIIIllIllIIIIII() {
    llIIlIIlIllllI = new int[25];
    llIIlIIlIllllI[0] = (0x23 ^ 0x7A) & (0xF7 ^ 0xAE ^ 0xFFFFFFFF);
    llIIlIIlIllllI[1] = " ".length();
    llIIlIIlIllllI[2] = " ".length() << " ".length();
    llIIlIIlIllllI[3] = "   ".length();
    llIIlIIlIllllI[4] = ((0x36 ^ 0x3F) << " ".length() ^ 0x15 ^ 0x8) << "   ".length();
    llIIlIIlIllllI[5] = 0x24 ^ 0x4B;
    llIIlIIlIllllI[6] = ((0x60 ^ 0x55) << " ".length() << " ".length() ^ 12 + 10 - -95 + 12) << " ".length();
    llIIlIIlIllllI[7] = " ".length() << " ".length() << " ".length();
    llIIlIIlIllllI[8] = 0xC ^ 0x9;
    llIIlIIlIllllI[9] = (0xB5 ^ 0xAC) << " ".length() ^ 0x1B ^ 0x26;
    llIIlIIlIllllI[10] = ("   ".length() << "   ".length() << " ".length() ^ 175 + 174 - 274 + 124) << " ".length();
    llIIlIIlIllllI[11] = "   ".length() << " ".length();
    llIIlIIlIllllI[12] = (0x19 ^ 0x68 ^ (0xB2 ^ 0xAF) << " ".length() << " ".length()) << " ".length();
    llIIlIIlIllllI[13] = 0x92 ^ 0x95;
    llIIlIIlIllllI[14] = "   ".length() << " ".length() << " ".length();
    llIIlIIlIllllI[15] = " ".length() << "   ".length();
    llIIlIIlIllllI[16] = 0xBD ^ 0xB0;
    llIIlIIlIllllI[17] = (0x9E ^ 0x9B) << "   ".length() ^ 0xBA ^ 0x9B;
    llIIlIIlIllllI[18] = 0xA9 ^ 0xA2;
    llIIlIIlIllllI[19] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIlIllllI[20] = (0x96 ^ 0x8F) << " ".length() << " ".length() ^ 0x66 ^ 0x13;
    llIIlIIlIllllI[21] = (0xAA ^ 0xA1 ^ " ".length() << " ".length()) << " ".length();
    llIIlIIlIllllI[22] = 0x74 ^ 0x67;
    llIIlIIlIllllI[23] = (0x97 ^ 0x92) << " ".length() << " ".length();
    llIIlIIlIllllI[24] = 0x2A ^ 0x33 ^ "   ".length() << " ".length() << " ".length();
  }
  
  private static boolean lIIIIllIllIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIllIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIllIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIllIIIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fx.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */