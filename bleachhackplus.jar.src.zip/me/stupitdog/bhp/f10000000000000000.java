package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.AbstractClientPlayer;

public class f10000000000000000 extends fs {
  public AbstractClientPlayer Entity;
  
  public double X;
  
  public double Y;
  
  public double Z;
  
  public String Name;
  
  public double DistanceSq;
  
  private static String[] lIllllIIlllIII;
  
  private static Class[] lIllllIIlllIIl;
  
  private static final String[] lIllllIIlllIlI;
  
  private static String[] lIllllIIlllIll;
  
  private static final int[] lIllllIIllllII;
  
  public f10000000000000000(AbstractClientPlayer lllllllllllllllIlllIIlIllIllIllI, double lllllllllllllllIlllIIlIllIllIlIl, double lllllllllllllllIlllIIlIllIllIlII, double lllllllllllllllIlllIIlIllIllIIll, String lllllllllllllllIlllIIlIllIllIIlI, double lllllllllllllllIlllIIlIllIllIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000000;Lnet/minecraft/client/entity/AbstractClientPlayer;)V
    //   11: aload_0
    //   12: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000000;)D
    //   17: dstore_2
    //   18: aload_0
    //   19: <illegal opcode> 2 : (Lme/stupitdog/bhp/f10000000000000000;)D
    //   24: dstore #4
    //   26: aload_0
    //   27: <illegal opcode> 3 : (Lme/stupitdog/bhp/f10000000000000000;)D
    //   32: dstore #6
    //   34: aload_0
    //   35: aload #8
    //   37: <illegal opcode> 4 : (Lme/stupitdog/bhp/f10000000000000000;Ljava/lang/String;)V
    //   42: aload_0
    //   43: dload #9
    //   45: <illegal opcode> 5 : (Lme/stupitdog/bhp/f10000000000000000;D)V
    //   50: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	51	0	lllllllllllllllIlllIIlIllIllIlll	Lme/stupitdog/bhp/f10000000000000000;
    //   0	51	1	lllllllllllllllIlllIIlIllIllIllI	Lnet/minecraft/client/entity/AbstractClientPlayer;
    //   0	51	2	lllllllllllllllIlllIIlIllIllIlIl	D
    //   0	51	4	lllllllllllllllIlllIIlIllIllIlII	D
    //   0	51	6	lllllllllllllllIlllIIlIllIllIIll	D
    //   0	51	8	lllllllllllllllIlllIIlIllIllIIlI	Ljava/lang/String;
    //   0	51	9	lllllllllllllllIlllIIlIllIllIIIl	D
  }
  
  static {
    llllllIllIIllIl();
    llllllIllIIllII();
    llllllIllIIlIll();
    llllllIllIIIlll();
  }
  
  private static CallSite llllllIllIIIllI(MethodHandles.Lookup lllllllllllllllIlllIIlIllIlIlIII, String lllllllllllllllIlllIIlIllIlIIlll, MethodType lllllllllllllllIlllIIlIllIlIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIllIlIlllI = lIllllIIlllIII[Integer.parseInt(lllllllllllllllIlllIIlIllIlIIlll)].split(lIllllIIlllIlI[lIllllIIllllII[0]]);
      Class<?> lllllllllllllllIlllIIlIllIlIllIl = Class.forName(lllllllllllllllIlllIIlIllIlIlllI[lIllllIIllllII[0]]);
      String lllllllllllllllIlllIIlIllIlIllII = lllllllllllllllIlllIIlIllIlIlllI[lIllllIIllllII[1]];
      MethodHandle lllllllllllllllIlllIIlIllIlIlIll = null;
      int lllllllllllllllIlllIIlIllIlIlIlI = lllllllllllllllIlllIIlIllIlIlllI[lIllllIIllllII[2]].length();
      if (llllllIllIIlllI(lllllllllllllllIlllIIlIllIlIlIlI, lIllllIIllllII[3])) {
        MethodType lllllllllllllllIlllIIlIllIllIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIllIlIlllI[lIllllIIllllII[3]], f10000000000000000.class.getClassLoader());
        if (llllllIllIIllll(lllllllllllllllIlllIIlIllIlIlIlI, lIllllIIllllII[3])) {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findVirtual(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIllIIII);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findStatic(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIllIIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIllIlIllll = lIllllIIlllIIl[Integer.parseInt(lllllllllllllllIlllIIlIllIlIlllI[lIllllIIllllII[3]])];
        if (llllllIllIIllll(lllllllllllllllIlllIIlIllIlIlIlI, lIllllIIllllII[2])) {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findGetter(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIlIllll);
          "".length();
          if (-"   ".length() > 0)
            return null; 
        } else if (llllllIllIIllll(lllllllllllllllIlllIIlIllIlIlIlI, lIllllIIllllII[4])) {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findStaticGetter(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIlIllll);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (llllllIllIIllll(lllllllllllllllIlllIIlIllIlIlIlI, lIllllIIllllII[5])) {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findSetter(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIlIllll);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIllIlIlIll = lllllllllllllllIlllIIlIllIlIlIII.findStaticSetter(lllllllllllllllIlllIIlIllIlIllIl, lllllllllllllllIlllIIlIllIlIllII, lllllllllllllllIlllIIlIllIlIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIllIlIlIll);
    } catch (Exception lllllllllllllllIlllIIlIllIlIlIIl) {
      lllllllllllllllIlllIIlIllIlIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIllIIIlll() {
    lIllllIIlllIII = new String[lIllllIIllllII[6]];
    lIllllIIlllIII[lIllllIIllllII[1]] = lIllllIIlllIlI[lIllllIIllllII[1]];
    lIllllIIlllIII[lIllllIIllllII[4]] = lIllllIIlllIlI[lIllllIIllllII[3]];
    lIllllIIlllIII[lIllllIIllllII[2]] = lIllllIIlllIlI[lIllllIIllllII[2]];
    lIllllIIlllIII[lIllllIIllllII[0]] = lIllllIIlllIlI[lIllllIIllllII[4]];
    lIllllIIlllIII[lIllllIIllllII[5]] = lIllllIIlllIlI[lIllllIIllllII[5]];
    lIllllIIlllIII[lIllllIIllllII[3]] = lIllllIIlllIlI[lIllllIIllllII[6]];
    lIllllIIlllIIl = new Class[lIllllIIllllII[2]];
    lIllllIIlllIIl[lIllllIIllllII[0]] = AbstractClientPlayer.class;
    lIllllIIlllIIl[lIllllIIllllII[1]] = double.class;
    lIllllIIlllIIl[lIllllIIllllII[3]] = String.class;
  }
  
  private static void llllllIllIIlIll() {
    lIllllIIlllIlI = new String[lIllllIIllllII[7]];
    lIllllIIlllIlI[lIllllIIllllII[0]] = llllllIllIIlIII(lIllllIIlllIll[lIllllIIllllII[0]], lIllllIIlllIll[lIllllIIllllII[1]]);
    lIllllIIlllIlI[lIllllIIllllII[1]] = llllllIllIIlIIl(lIllllIIlllIll[lIllllIIllllII[3]], lIllllIIlllIll[lIllllIIllllII[2]]);
    lIllllIIlllIlI[lIllllIIllllII[3]] = llllllIllIIlIII(lIllllIIlllIll[lIllllIIllllII[4]], lIllllIIlllIll[lIllllIIllllII[5]]);
    lIllllIIlllIlI[lIllllIIllllII[2]] = llllllIllIIlIIl(lIllllIIlllIll[lIllllIIllllII[6]], lIllllIIlllIll[lIllllIIllllII[7]]);
    lIllllIIlllIlI[lIllllIIllllII[4]] = llllllIllIIlIIl(lIllllIIlllIll[lIllllIIllllII[8]], lIllllIIlllIll[lIllllIIllllII[9]]);
    lIllllIIlllIlI[lIllllIIllllII[5]] = llllllIllIIlIlI(lIllllIIlllIll[lIllllIIllllII[10]], lIllllIIlllIll[lIllllIIllllII[11]]);
    lIllllIIlllIlI[lIllllIIllllII[6]] = llllllIllIIlIIl(lIllllIIlllIll[lIllllIIllllII[12]], lIllllIIlllIll[lIllllIIllllII[13]]);
    lIllllIIlllIll = null;
  }
  
  private static void llllllIllIIllII() {
    String str = (new Exception()).getStackTrace()[lIllllIIllllII[0]].getFileName();
    lIllllIIlllIll = str.substring(str.indexOf("ä") + lIllllIIllllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIllIIlIIl(String lllllllllllllllIlllIIlIllIlIIIlI, String lllllllllllllllIlllIIlIllIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIllIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIllIlIIIIl.getBytes(StandardCharsets.UTF_8)), lIllllIIllllII[8]), "DES");
      Cipher lllllllllllllllIlllIIlIllIlIIlII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIllIlIIlII.init(lIllllIIllllII[3], lllllllllllllllIlllIIlIllIlIIlIl);
      return new String(lllllllllllllllIlllIIlIllIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIllIlIIIll) {
      lllllllllllllllIlllIIlIllIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIllIIlIlI(String lllllllllllllllIlllIIlIllIIlllIl, String lllllllllllllllIlllIIlIllIIlllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIllIlIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIllIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIllIIlllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIllIIlllll.init(lIllllIIllllII[3], lllllllllllllllIlllIIlIllIlIIIII);
      return new String(lllllllllllllllIlllIIlIllIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIllIIllllI) {
      lllllllllllllllIlllIIlIllIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIllIIlIII(String lllllllllllllllIlllIIlIllIIllIlI, String lllllllllllllllIlllIIlIllIIllIIl) {
    lllllllllllllllIlllIIlIllIIllIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllIIllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIllIIllIII = new StringBuilder();
    char[] lllllllllllllllIlllIIlIllIIlIlll = lllllllllllllllIlllIIlIllIIllIIl.toCharArray();
    int lllllllllllllllIlllIIlIllIIlIllI = lIllllIIllllII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIllIIllIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIllllII[0];
    while (llllllIllIlIIII(j, i)) {
      char lllllllllllllllIlllIIlIllIIllIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIllIIlIllI++;
      j++;
      "".length();
      if ("   ".length() < -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIllIIllIII);
  }
  
  private static void llllllIllIIllIl() {
    lIllllIIllllII = new int[14];
    lIllllIIllllII[0] = "   ".length() << ((0x38 ^ 0x33) << " ".length() << " ".length() ^ 0x6A ^ 0x43) & ("   ".length() << ((0x62 ^ 0x67) << " ".length() ^ 0xCB ^ 0xC4) ^ -" ".length());
    lIllllIIllllII[1] = " ".length();
    lIllllIIllllII[2] = "   ".length();
    lIllllIIllllII[3] = " ".length() << " ".length();
    lIllllIIllllII[4] = " ".length() << " ".length() << " ".length();
    lIllllIIllllII[5] = 0x5A ^ 0x5F;
    lIllllIIllllII[6] = "   ".length() << " ".length();
    lIllllIIllllII[7] = 0x1F ^ 0x18;
    lIllllIIllllII[8] = " ".length() << "   ".length();
    lIllllIIllllII[9] = (0x5F ^ 0x50) << " ".length() ^ 0xB8 ^ 0xAF;
    lIllllIIllllII[10] = (0x9B ^ 0x9E) << " ".length();
    lIllllIIllllII[11] = (0x99 ^ 0x92) << "   ".length() ^ 0x9 ^ 0x5A;
    lIllllIIllllII[12] = "   ".length() << " ".length() << " ".length();
    lIllllIIllllII[13] = 0xB6 ^ 0xBB;
  }
  
  private static boolean llllllIllIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIllIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */