package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.MoverType;

public class f10000000000000 extends fs {
  MoverType type;
  
  public double x;
  
  public double y;
  
  public double z;
  
  private static String[] llIIlIlIlIlllI;
  
  private static Class[] llIIlIlIlIllll;
  
  private static final String[] llIIlIlIllIIIl;
  
  private static String[] llIIlIlIllIIlI;
  
  private static final int[] llIIlIlIllIlII;
  
  public f10000000000000(MoverType lllllllllllllllIllIIlIlIIIIllIlI, double lllllllllllllllIllIIlIlIIIIllIIl, double lllllllllllllllIllIIlIlIIIIllIII, double lllllllllllllllIllIIlIlIIIIlIlll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000;Lnet/minecraft/entity/MoverType;)V
    //   11: aload_0
    //   12: dload_2
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   18: aload_0
    //   19: dload #4
    //   21: <illegal opcode> 2 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   26: aload_0
    //   27: dload #6
    //   29: <illegal opcode> 3 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   34: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	35	0	lllllllllllllllIllIIlIlIIIIllIll	Lme/stupitdog/bhp/f10000000000000;
    //   0	35	1	lllllllllllllllIllIIlIlIIIIllIlI	Lnet/minecraft/entity/MoverType;
    //   0	35	2	lllllllllllllllIllIIlIlIIIIllIIl	D
    //   0	35	4	lllllllllllllllIllIIlIlIIIIllIII	D
    //   0	35	6	lllllllllllllllIllIIlIlIIIIlIlll	D
  }
  
  public MoverType getType() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/f10000000000000;)Lnet/minecraft/entity/MoverType;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlIlIIIIlIllI	Lme/stupitdog/bhp/f10000000000000;
  }
  
  public void setType(MoverType lllllllllllllllIllIIlIlIIIIlIlII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000;Lnet/minecraft/entity/MoverType;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlIlIIIIlIlIl	Lme/stupitdog/bhp/f10000000000000;
    //   0	8	1	lllllllllllllllIllIIlIlIIIIlIlII	Lnet/minecraft/entity/MoverType;
  }
  
  public double getX() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lme/stupitdog/bhp/f10000000000000;)D
    //   6: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlIlIIIIlIIll	Lme/stupitdog/bhp/f10000000000000;
  }
  
  public double getY() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lme/stupitdog/bhp/f10000000000000;)D
    //   6: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlIlIIIIlIIlI	Lme/stupitdog/bhp/f10000000000000;
  }
  
  public double getZ() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 7 : (Lme/stupitdog/bhp/f10000000000000;)D
    //   6: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlIlIIIIlIIIl	Lme/stupitdog/bhp/f10000000000000;
  }
  
  public void setX(double lllllllllllllllIllIIlIlIIIIIllll) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlIlIIIIlIIII	Lme/stupitdog/bhp/f10000000000000;
    //   0	8	1	lllllllllllllllIllIIlIlIIIIIllll	D
  }
  
  public void setY(double lllllllllllllllIllIIlIlIIIIIllIl) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: <illegal opcode> 2 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlIlIIIIIlllI	Lme/stupitdog/bhp/f10000000000000;
    //   0	8	1	lllllllllllllllIllIIlIlIIIIIllIl	D
  }
  
  public void setZ(double lllllllllllllllIllIIlIlIIIIIlIll) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: <illegal opcode> 3 : (Lme/stupitdog/bhp/f10000000000000;D)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlIlIIIIIllII	Lme/stupitdog/bhp/f10000000000000;
    //   0	8	1	lllllllllllllllIllIIlIlIIIIIlIll	D
  }
  
  static {
    lIIIIllllIIllIII();
    lIIIIllllIIlIlll();
    lIIIIllllIIlIllI();
    lIIIIllllIIlIIIl();
  }
  
  private static CallSite lIIIIllllIIIllll(MethodHandles.Lookup lllllllllllllllIllIIlIlIIIIIIIlI, String lllllllllllllllIllIIlIlIIIIIIIIl, MethodType lllllllllllllllIllIIlIlIIIIIIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlIlIIIIIlIII = llIIlIlIlIlllI[Integer.parseInt(lllllllllllllllIllIIlIlIIIIIIIIl)].split(llIIlIlIllIIIl[llIIlIlIllIlII[0]]);
      Class<?> lllllllllllllllIllIIlIlIIIIIIlll = Class.forName(lllllllllllllllIllIIlIlIIIIIlIII[llIIlIlIllIlII[0]]);
      String lllllllllllllllIllIIlIlIIIIIIllI = lllllllllllllllIllIIlIlIIIIIlIII[llIIlIlIllIlII[1]];
      MethodHandle lllllllllllllllIllIIlIlIIIIIIlIl = null;
      int lllllllllllllllIllIIlIlIIIIIIlII = lllllllllllllllIllIIlIlIIIIIlIII[llIIlIlIllIlII[2]].length();
      if (lIIIIllllIIllIIl(lllllllllllllllIllIIlIlIIIIIIlII, llIIlIlIllIlII[3])) {
        MethodType lllllllllllllllIllIIlIlIIIIIlIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlIlIIIIIlIII[llIIlIlIllIlII[3]], f10000000000000.class.getClassLoader());
        if (lIIIIllllIIllIlI(lllllllllllllllIllIIlIlIIIIIIlII, llIIlIlIllIlII[3])) {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findVirtual(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIlI);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findStatic(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIlI);
        } 
        "".length();
        if (" ".length() >= " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlIlIIIIIlIIl = llIIlIlIlIllll[Integer.parseInt(lllllllllllllllIllIIlIlIIIIIlIII[llIIlIlIllIlII[3]])];
        if (lIIIIllllIIllIlI(lllllllllllllllIllIIlIlIIIIIIlII, llIIlIlIllIlII[2])) {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findGetter(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIllllIIllIlI(lllllllllllllllIllIIlIlIIIIIIlII, llIIlIlIllIlII[4])) {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findStaticGetter(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIIl);
          "".length();
          if (" ".length() < -" ".length())
            return null; 
        } else if (lIIIIllllIIllIlI(lllllllllllllllIllIIlIlIIIIIIlII, llIIlIlIllIlII[5])) {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findSetter(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIIl);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlIlIIIIIIlIl = lllllllllllllllIllIIlIlIIIIIIIlI.findStaticSetter(lllllllllllllllIllIIlIlIIIIIIlll, lllllllllllllllIllIIlIlIIIIIIllI, lllllllllllllllIllIIlIlIIIIIlIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlIlIIIIIIlIl);
    } catch (Exception lllllllllllllllIllIIlIlIIIIIIIll) {
      lllllllllllllllIllIIlIlIIIIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllllIIlIIIl() {
    llIIlIlIlIlllI = new String[llIIlIlIllIlII[6]];
    llIIlIlIlIlllI[llIIlIlIllIlII[3]] = llIIlIlIllIIIl[llIIlIlIllIlII[1]];
    llIIlIlIlIlllI[llIIlIlIllIlII[1]] = llIIlIlIllIIIl[llIIlIlIllIlII[3]];
    llIIlIlIlIlllI[llIIlIlIllIlII[7]] = llIIlIlIllIIIl[llIIlIlIllIlII[2]];
    llIIlIlIlIlllI[llIIlIlIllIlII[8]] = llIIlIlIllIIIl[llIIlIlIllIlII[4]];
    llIIlIlIlIlllI[llIIlIlIllIlII[5]] = llIIlIlIllIIIl[llIIlIlIllIlII[5]];
    llIIlIlIlIlllI[llIIlIlIllIlII[2]] = llIIlIlIllIIIl[llIIlIlIllIlII[8]];
    llIIlIlIlIlllI[llIIlIlIllIlII[0]] = llIIlIlIllIIIl[llIIlIlIllIlII[7]];
    llIIlIlIlIlllI[llIIlIlIllIlII[4]] = llIIlIlIllIIIl[llIIlIlIllIlII[6]];
    llIIlIlIlIllll = new Class[llIIlIlIllIlII[3]];
    llIIlIlIlIllll[llIIlIlIllIlII[1]] = double.class;
    llIIlIlIlIllll[llIIlIlIllIlII[0]] = MoverType.class;
  }
  
  private static void lIIIIllllIIlIllI() {
    llIIlIlIllIIIl = new String[llIIlIlIllIlII[9]];
    llIIlIlIllIIIl[llIIlIlIllIlII[0]] = lIIIIllllIIlIIll(llIIlIlIllIIlI[llIIlIlIllIlII[0]], llIIlIlIllIIlI[llIIlIlIllIlII[1]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[1]] = lIIIIllllIIlIlII(llIIlIlIllIIlI[llIIlIlIllIlII[3]], llIIlIlIllIIlI[llIIlIlIllIlII[2]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[3]] = lIIIIllllIIlIlII(llIIlIlIllIIlI[llIIlIlIllIlII[4]], llIIlIlIllIIlI[llIIlIlIllIlII[5]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[2]] = lIIIIllllIIlIIll(llIIlIlIllIIlI[llIIlIlIllIlII[8]], llIIlIlIllIIlI[llIIlIlIllIlII[7]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[4]] = lIIIIllllIIlIlII(llIIlIlIllIIlI[llIIlIlIllIlII[6]], llIIlIlIllIIlI[llIIlIlIllIlII[9]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[5]] = lIIIIllllIIlIlII(llIIlIlIllIIlI[llIIlIlIllIlII[10]], llIIlIlIllIIlI[llIIlIlIllIlII[11]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[8]] = lIIIIllllIIlIlII(llIIlIlIllIIlI[llIIlIlIllIlII[12]], llIIlIlIllIIlI[llIIlIlIllIlII[13]]);
    llIIlIlIllIIIl[llIIlIlIllIlII[7]] = lIIIIllllIIlIlIl("DB96ITkUCj0mKQ4dejAlEVQyY31RSmRifVFKZGJ9UUpuJjQRH25id0FadHJt", "azTRM");
    llIIlIlIllIIIl[llIIlIlIllIlII[6]] = lIIIIllllIIlIlII("Y9N3LO9Hxxz5kYDWwaT/jolmTKxO7w56Vqok/1y9We+b6ukrZOy7T9fYvMJ/4gNP", "iZaGD");
    llIIlIlIllIIlI = null;
  }
  
  private static void lIIIIllllIIlIlll() {
    String str = (new Exception()).getStackTrace()[llIIlIlIllIlII[0]].getFileName();
    llIIlIlIllIIlI = str.substring(str.indexOf("ä") + llIIlIlIllIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllllIIlIIll(String lllllllllllllllIllIIlIIlllllllII, String lllllllllllllllIllIIlIIllllllIll) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIlllllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIllllllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIIllllllllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIIllllllllI.init(llIIlIlIllIlII[3], lllllllllllllllIllIIlIIlllllllll);
      return new String(lllllllllllllllIllIIlIIllllllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlllllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIlllllllIl) {
      lllllllllllllllIllIIlIIlllllllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllllIIlIlIl(String lllllllllllllllIllIIlIIllllllIIl, String lllllllllllllllIllIIlIIllllllIII) {
    lllllllllllllllIllIIlIIllllllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIIllllllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIIlllllIlll = new StringBuilder();
    char[] lllllllllllllllIllIIlIIlllllIllI = lllllllllllllllIllIIlIIllllllIII.toCharArray();
    int lllllllllllllllIllIIlIIlllllIlIl = llIIlIlIllIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlIIllllllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIlIllIlII[0];
    while (lIIIIllllIIllIll(j, i)) {
      char lllllllllllllllIllIIlIIllllllIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlIIlllllIlIl++;
      j++;
      "".length();
      if (((0x2A ^ 0x47 ^ (0x76 ^ 0x6F) << " ".length() << " ".length()) << "   ".length() & ((0x55 ^ 0x74 ^ (0x2C ^ 0x29) << "   ".length()) << "   ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlIIlllllIlll);
  }
  
  private static String lIIIIllllIIlIlII(String lllllllllllllllIllIIlIIlllllIIIl, String lllllllllllllllIllIIlIIlllllIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIlllllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIlllllIIII.getBytes(StandardCharsets.UTF_8)), llIIlIlIllIlII[6]), "DES");
      Cipher lllllllllllllllIllIIlIIlllllIIll = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIIlllllIIll.init(llIIlIlIllIlII[3], lllllllllllllllIllIIlIIlllllIlII);
      return new String(lllllllllllllllIllIIlIIlllllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlllllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIlllllIIlI) {
      lllllllllllllllIllIIlIIlllllIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllllIIllIII() {
    llIIlIlIllIlII = new int[14];
    llIIlIlIllIlII[0] = ((0x8D ^ 0x86) << " ".length() << " ".length() ^ 0xFB ^ 0xB4) & (0x3D ^ 0xC ^ (0xA9 ^ 0x80) << " ".length() ^ -" ".length());
    llIIlIlIllIlII[1] = " ".length();
    llIIlIlIllIlII[2] = "   ".length();
    llIIlIlIllIlII[3] = " ".length() << " ".length();
    llIIlIlIllIlII[4] = " ".length() << " ".length() << " ".length();
    llIIlIlIllIlII[5] = 0x3C ^ 0x39;
    llIIlIlIllIlII[6] = " ".length() << "   ".length();
    llIIlIlIllIlII[7] = 0x6C ^ 0x73 ^ "   ".length() << "   ".length();
    llIIlIlIllIlII[8] = "   ".length() << " ".length();
    llIIlIlIllIlII[9] = 0x24 ^ 0x2D;
    llIIlIlIllIlII[10] = (0x5A ^ 0x5F) << " ".length();
    llIIlIlIllIlII[11] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0xBF ^ 0x84;
    llIIlIlIllIlII[12] = "   ".length() << " ".length() << " ".length();
    llIIlIlIllIlII[13] = 0xA1 ^ 0xAC;
  }
  
  private static boolean lIIIIllllIIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllllIIllIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllllIIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */