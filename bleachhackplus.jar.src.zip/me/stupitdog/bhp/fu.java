package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.world.GameType;

public class fu extends au {
  private EntityOtherPlayerMP clonedPlayer;
  
  private static String[] llIIlIIIIIllll;
  
  private static Class[] llIIlIIIIlIIII;
  
  private static final String[] llIIlIIIlllllI;
  
  private static String[] llIIlIIIllllll;
  
  private static final int[] llIIlIIlIIIIII;
  
  public fu() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fu.llIIlIIIlllllI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fu.llIIlIIIlllllI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fu.llIIlIIIlllllI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIllIlllIllIIl	Lme/stupitdog/bhp/fu;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIllIIlllIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 37
    //   16: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   31: invokestatic lIIIIllIIlllIIIl : (I)Z
    //   34: ifeq -> 44
    //   37: aload_0
    //   38: <illegal opcode> 4 : (Lme/stupitdog/bhp/fu;)V
    //   43: return
    //   44: aload_0
    //   45: new net/minecraft/client/entity/EntityOtherPlayerMP
    //   48: dup
    //   49: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   54: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   59: new com/mojang/authlib/GameProfile
    //   62: dup
    //   63: getstatic me/stupitdog/bhp/fu.llIIlIIIlllllI : [Ljava/lang/String;
    //   66: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   69: iconst_3
    //   70: iaload
    //   71: aaload
    //   72: <illegal opcode> 6 : (Ljava/lang/String;)Ljava/util/UUID;
    //   77: getstatic me/stupitdog/bhp/fu.llIIlIIIlllllI : [Ljava/lang/String;
    //   80: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   83: iconst_4
    //   84: iaload
    //   85: aaload
    //   86: invokespecial <init> : (Ljava/util/UUID;Ljava/lang/String;)V
    //   89: invokespecial <init> : (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
    //   92: <illegal opcode> 7 : (Lme/stupitdog/bhp/fu;Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   97: aload_0
    //   98: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   103: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   108: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   113: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;Lnet/minecraft/entity/Entity;)V
    //   118: aload_0
    //   119: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   124: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   129: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   134: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   139: putfield field_70759_as : F
    //   142: aload_0
    //   143: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   148: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   153: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   158: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   163: putfield field_70177_z : F
    //   166: aload_0
    //   167: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   172: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   177: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   182: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   187: putfield field_70125_A : F
    //   190: aload_0
    //   191: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   196: <illegal opcode> 13 : ()Lnet/minecraft/world/GameType;
    //   201: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;Lnet/minecraft/world/GameType;)V
    //   206: aload_0
    //   207: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   212: ldc 20.0
    //   214: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;F)V
    //   219: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   224: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   229: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   232: iconst_5
    //   233: iaload
    //   234: aload_0
    //   235: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   240: <illegal opcode> 16 : (Lnet/minecraft/client/multiplayer/WorldClient;ILnet/minecraft/entity/Entity;)V
    //   245: aload_0
    //   246: <illegal opcode> 8 : (Lme/stupitdog/bhp/fu;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   251: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   256: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	257	0	lllllllllllllllIllIIllIlllIllIII	Lme/stupitdog/bhp/fu;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: invokestatic lIIIIllIIlllIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 42
    //   16: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   26: getstatic me/stupitdog/bhp/fu.llIIlIIlIIIIII : [I
    //   29: iconst_5
    //   30: iaload
    //   31: <illegal opcode> 18 : (Lnet/minecraft/client/multiplayer/WorldClient;I)Lnet/minecraft/entity/Entity;
    //   36: ldc ''
    //   38: invokevirtual length : ()I
    //   41: pop2
    //   42: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	43	0	lllllllllllllllIllIIllIlllIlIlll	Lme/stupitdog/bhp/fu;
  }
  
  static {
    lIIIIllIIllIllll();
    lIIIIllIIllIlllI();
    lIIIIllIIllIllIl();
    lIIIIllIIllIlIIl();
  }
  
  private static CallSite lIIIIlIllllllIlI(MethodHandles.Lookup lllllllllllllllIllIIllIlllIIlllI, String lllllllllllllllIllIIllIlllIIllIl, MethodType lllllllllllllllIllIIllIlllIIllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIlllIlIlII = llIIlIIIIIllll[Integer.parseInt(lllllllllllllllIllIIllIlllIIllIl)].split(llIIlIIIlllllI[llIIlIIlIIIIII[6]]);
      Class<?> lllllllllllllllIllIIllIlllIlIIll = Class.forName(lllllllllllllllIllIIllIlllIlIlII[llIIlIIlIIIIII[0]]);
      String lllllllllllllllIllIIllIlllIlIIlI = lllllllllllllllIllIIllIlllIlIlII[llIIlIIlIIIIII[1]];
      MethodHandle lllllllllllllllIllIIllIlllIlIIIl = null;
      int lllllllllllllllIllIIllIlllIlIIII = lllllllllllllllIllIIllIlllIlIlII[llIIlIIlIIIIII[3]].length();
      if (lIIIIllIIlllIIlI(lllllllllllllllIllIIllIlllIlIIII, llIIlIIlIIIIII[2])) {
        MethodType lllllllllllllllIllIIllIlllIlIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIlllIlIlII[llIIlIIlIIIIII[2]], fu.class.getClassLoader());
        if (lIIIIllIIlllIIll(lllllllllllllllIllIIllIlllIlIIII, llIIlIIlIIIIII[2])) {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findVirtual(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIllI);
          "".length();
          if (("   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findStatic(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIllI);
        } 
        "".length();
        if ((((0x1D ^ 0x5A) << " ".length() ^ 117 + 134 - 210 + 106) & ((0xA2 ^ 0x8F) << " ".length() << " ".length() ^ 56 + 28 - -31 + 54 ^ -" ".length())) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIlllIlIlIl = llIIlIIIIlIIII[Integer.parseInt(lllllllllllllllIllIIllIlllIlIlII[llIIlIIlIIIIII[2]])];
        if (lIIIIllIIlllIIll(lllllllllllllllIllIIllIlllIlIIII, llIIlIIlIIIIII[3])) {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findGetter(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIlIl);
          "".length();
          if (" ".length() << " ".length() < ((0x8B ^ 0xAC) & (0x5C ^ 0x7B ^ 0xFFFFFFFF)))
            return null; 
        } else if (lIIIIllIIlllIIll(lllllllllllllllIllIIllIlllIlIIII, llIIlIIlIIIIII[4])) {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findStaticGetter(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIlIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() == " ".length() << " ".length())
            return null; 
        } else if (lIIIIllIIlllIIll(lllllllllllllllIllIIllIlllIlIIII, llIIlIIlIIIIII[6])) {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findSetter(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIlIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() == ((0xDD ^ 0x86 ^ (0xC1 ^ 0xC4) << " ".length() << " ".length()) & ((0x9C ^ 0xA7) << " ".length() << " ".length() ^ 158 + 68 - 166 + 103 ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIIllIlllIlIIIl = lllllllllllllllIllIIllIlllIIlllI.findStaticSetter(lllllllllllllllIllIIllIlllIlIIll, lllllllllllllllIllIIllIlllIlIIlI, lllllllllllllllIllIIllIlllIlIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIlllIlIIIl);
    } catch (Exception lllllllllllllllIllIIllIlllIIllll) {
      lllllllllllllllIllIIllIlllIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIllIlIIl() {
    llIIlIIIIIllll = new String[llIIlIIlIIIIII[7]];
    llIIlIIIIIllll[llIIlIIlIIIIII[1]] = llIIlIIIlllllI[llIIlIIlIIIIII[8]];
    llIIlIIIIIllll[llIIlIIlIIIIII[9]] = llIIlIIIlllllI[llIIlIIlIIIIII[10]];
    llIIlIIIIIllll[llIIlIIlIIIIII[11]] = llIIlIIIlllllI[llIIlIIlIIIIII[12]];
    llIIlIIIIIllll[llIIlIIlIIIIII[8]] = llIIlIIIlllllI[llIIlIIlIIIIII[13]];
    llIIlIIIIIllll[llIIlIIlIIIIII[14]] = llIIlIIIlllllI[llIIlIIlIIIIII[15]];
    llIIlIIIIIllll[llIIlIIlIIIIII[16]] = llIIlIIIlllllI[llIIlIIlIIIIII[17]];
    llIIlIIIIIllll[llIIlIIlIIIIII[6]] = llIIlIIIlllllI[llIIlIIlIIIIII[11]];
    llIIlIIIIIllll[llIIlIIlIIIIII[10]] = llIIlIIIlllllI[llIIlIIlIIIIII[16]];
    llIIlIIIIIllll[llIIlIIlIIIIII[18]] = llIIlIIIlllllI[llIIlIIlIIIIII[14]];
    llIIlIIIIIllll[llIIlIIlIIIIII[15]] = llIIlIIIlllllI[llIIlIIlIIIIII[19]];
    llIIlIIIIIllll[llIIlIIlIIIIII[3]] = llIIlIIIlllllI[llIIlIIlIIIIII[18]];
    llIIlIIIIIllll[llIIlIIlIIIIII[20]] = llIIlIIIlllllI[llIIlIIlIIIIII[20]];
    llIIlIIIIIllll[llIIlIIlIIIIII[4]] = llIIlIIIlllllI[llIIlIIlIIIIII[9]];
    llIIlIIIIIllll[llIIlIIlIIIIII[13]] = llIIlIIIlllllI[llIIlIIlIIIIII[7]];
    llIIlIIIIIllll[llIIlIIlIIIIII[17]] = llIIlIIIlllllI[llIIlIIlIIIIII[21]];
    llIIlIIIIIllll[llIIlIIlIIIIII[0]] = llIIlIIIlllllI[llIIlIIlIIIIII[22]];
    llIIlIIIIIllll[llIIlIIlIIIIII[2]] = llIIlIIIlllllI[llIIlIIlIIIIII[23]];
    llIIlIIIIIllll[llIIlIIlIIIIII[12]] = llIIlIIIlllllI[llIIlIIlIIIIII[24]];
    llIIlIIIIIllll[llIIlIIlIIIIII[19]] = llIIlIIIlllllI[llIIlIIlIIIIII[25]];
    llIIlIIIIlIIII = new Class[llIIlIIlIIIIII[12]];
    llIIlIIIIlIIII[llIIlIIlIIIIII[6]] = EntityOtherPlayerMP.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[4]] = WorldClient.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[1]] = Minecraft.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[2]] = EntityPlayerSP.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[10]] = GameType.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[0]] = f13.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[8]] = float.class;
    llIIlIIIIlIIII[llIIlIIlIIIIII[3]] = boolean.class;
  }
  
  private static void lIIIIllIIllIllIl() {
    llIIlIIIlllllI = new String[llIIlIIlIIIIII[26]];
    llIIlIIIlllllI[llIIlIIlIIIIII[0]] = lIIIIllIIllIlIlI(llIIlIIIllllll[llIIlIIlIIIIII[0]], llIIlIIIllllll[llIIlIIlIIIIII[1]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[1]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[2]], llIIlIIIllllll[llIIlIIlIIIIII[3]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[2]] = lIIIIllIIllIlIlI(llIIlIIIllllll[llIIlIIlIIIIII[4]], llIIlIIIllllll[llIIlIIlIIIIII[6]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[3]] = lIIIIllIIllIllII(llIIlIIIllllll[llIIlIIlIIIIII[8]], llIIlIIIllllll[llIIlIIlIIIIII[10]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[4]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[12]], llIIlIIIllllll[llIIlIIlIIIIII[13]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[6]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[15]], llIIlIIIllllll[llIIlIIlIIIIII[17]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[8]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[11]], llIIlIIIllllll[llIIlIIlIIIIII[16]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[10]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[14]], llIIlIIIllllll[llIIlIIlIIIIII[19]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[12]] = lIIIIllIIllIlIll(llIIlIIIllllll[llIIlIIlIIIIII[18]], llIIlIIIllllll[llIIlIIlIIIIII[20]]);
    llIIlIIIlllllI[llIIlIIlIIIIII[13]] = lIIIIllIIllIlIlI("JycxMEE4Mi49QRgTDhVVKzQoPDw5NC4/CHduCzsOOydoPQ4jIWgCGz8vKTZUZAotMBksaTIlBiFpEgQmCX19cQ==", "MFGQo");
    llIIlIIIlllllI[llIIlIIlIIIIII[15]] = lIIIIllIIllIlIlI("DBMwSRQLGCEECwMQMEkaDh8hCQ1MEyoTEBYPaiIXFh8wHjYWHiEVKQ4XPQILLyZ+AQwMFRtQSFJFdzgYWF4ICRwWWSkOFwcVNgYfFlkzCAsOEmsgGA8TEB4JB01tMUNCVg==", "bvDgy");
    llIIlIIIlllllI[llIIlIIlIIIIII[17]] = lIIIIllIIllIlIll("JQ5TgSL27b7gj0iPgdYvYnx4MSpoLwFWTkdwsI3RMS3RtjnJbPbjcCl5+PivYX+Y", "iQugc");
    llIIlIIIlllllI[llIIlIIlIIIIII[11]] = lIIIIllIIllIllII("FpWCpqlrhl1qZ2p0mOkLssxacpDRhPu4QrAOvCCQWGNOK1hvoPpX6HCg77wwEi9UBlI0xdtEoNQ=", "tlARN");
    llIIlIIIlllllI[llIIlIIlIIIIII[16]] = lIIIIllIIllIllII("jQESKtF2oVSA1Fp0azQ7yOk/e1QNuthnX026eMRQIiEfmt50QLaWfFnd2Dq3hvPk", "IOuYU");
    llIIlIIIlllllI[llIIlIIlIIIIII[14]] = lIIIIllIIllIlIll("9YGH5D5WYYW36SBHniub0bwzf7cZY5Beis+FfFSmfITFsC0b5TQRaOAk81aRGvNDY1TYqi2Gsjpl6pwSetCSXNXsD0wUYMYs823BTS5CLCcAIGMfK7qBp5in/N5wQ6fu", "ENeet");
    llIIlIIIlllllI[llIIlIIlIIIIII[19]] = lIIIIllIIllIlIll("JG3PazO6EfDDywROPWtrjokyjcr/SDICLzvSBYN6t8j1AG07LdGhShqJYngSN4lhLXv6PJUENwVtxGrHToL/Jw==", "ExqLn");
    llIIlIIIlllllI[llIIlIIlIIIIII[18]] = lIIIIllIIllIllII("GGglcv6vMY01AsmI1DywoOxOtlDR8ibot9Zg8mnmc+7lpyQVP4JdgKDYqOK5CiFRX49vbCAXjSgg/7xQ8Uvvgw==", "Orkwi");
    llIIlIIIlllllI[llIIlIIlIIIIII[20]] = lIIIIllIIllIlIlI("OxEuRwU8Gj8KGjQSLkcLOR0/Bxx7ETQdASENdCwGIR0uECchHD8bODkVIwwaGCRgDx07FwVeWGNHbDYMb1xzP1J1VA==", "UtZih");
    llIIlIIIlllllI[llIIlIIlIIIIII[9]] = lIIIIllIIllIlIll("DApRvEjsJYiHFv+90oxTxqd8I8LIvPcEdH9G/dkVvzxBSceh7UoQtQ==", "OxlTb");
    llIIlIIIlllllI[llIIlIIlIIIIII[7]] = lIIIIllIIllIlIlI("OioyRh49ISMLATUpMkYQOCYjBgd6KigcGiA2aC0dICYyETwgJyMaIzguPw0BGR98DgY6LBlQQWV7fzcZbmcKBhYgYCsBHTEsNAkVIGAjBgc9Oz9HNjo7LxwKb2YQUlN0", "TOFhs");
    llIIlIIIlllllI[llIIlIIlIIIIII[21]] = lIIIIllIIllIllII("x3P/HR5ZuIvvoPTbthR3nf9lrik5+7STeAZOXrcGlr0x49+zN4OoeNs5ka1boQadhCJmpPelDC4WY1r9K5hQpQ==", "JQCXT");
    llIIlIIIlllllI[llIIlIIlIIIIII[22]] = lIIIIllIIllIlIlI("OitBIBoiPgYnCjgpQTEGJ2AJYl1tCzcDIhgHOwBUZ3RPc053", "WNoSn");
    llIIlIIIlllllI[llIIlIIlIIIIII[23]] = lIIIIllIIllIlIlI("BiktdyMBIjw6PAkqLXctBCU8NzpGATA3Kws+OD86UiowPCIME25oelt1Bj50WnZ5eW4=", "hLYYN");
    llIIlIIIlllllI[llIIlIIlIIIIII[24]] = lIIIIllIIllIlIlI("JD9kOBM8KiM/AyY9ZCkPOXQsPl0qNiUlAi0KJioeLChwfl1pemo=", "IZJKg");
    llIIlIIIlllllI[llIIlIIlIIIIII[25]] = lIIIIllIIllIllII("0qHqvNSnH900vaPVVXMbc1yju48/4oZNkO/kQIk96iEwG4Nj1bMdCYumY7G5HuOeF+24Z7M4mITWLVvgxij4DdZGkT3Tjwzt", "MjKxJ");
    llIIlIIIllllll = null;
  }
  
  private static void lIIIIllIIllIlllI() {
    String str = (new Exception()).getStackTrace()[llIIlIIlIIIIII[0]].getFileName();
    llIIlIIIllllll = str.substring(str.indexOf("ä") + llIIlIIlIIIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIIllIlIlI(String lllllllllllllllIllIIllIlllIIlIlI, String lllllllllllllllIllIIllIlllIIlIIl) {
    lllllllllllllllIllIIllIlllIIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllIlllIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllIlllIIlIII = new StringBuilder();
    char[] lllllllllllllllIllIIllIlllIIIlll = lllllllllllllllIllIIllIlllIIlIIl.toCharArray();
    int lllllllllllllllIllIIllIlllIIIllI = llIIlIIlIIIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIllIlllIIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIlIIIIII[0];
    while (lIIIIllIIlllIlII(j, i)) {
      char lllllllllllllllIllIIllIlllIIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllIlllIIIllI++;
      j++;
      "".length();
      if (((0x21 ^ 0x2C) & (0x8A ^ 0x87 ^ 0xFFFFFFFF)) < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllIlllIIlIII);
  }
  
  private static String lIIIIllIIllIllII(String lllllllllllllllIllIIllIlllIIIIlI, String lllllllllllllllIllIIllIlllIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlllIIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlllIIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIlllIIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIlllIIIlII.init(llIIlIIlIIIIII[2], lllllllllllllllIllIIllIlllIIIlIl);
      return new String(lllllllllllllllIllIIllIlllIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlllIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIlllIIIIll) {
      lllllllllllllllIllIIllIlllIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIIllIlIll(String lllllllllllllllIllIIllIllIllllIl, String lllllllllllllllIllIIllIllIllllII) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlllIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIllIllllII.getBytes(StandardCharsets.UTF_8)), llIIlIIlIIIIII[12]), "DES");
      Cipher lllllllllllllllIllIIllIllIllllll = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIllIllllll.init(llIIlIIlIIIIII[2], lllllllllllllllIllIIllIlllIIIIII);
      return new String(lllllllllllllllIllIIllIllIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIllIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIllIlllllI) {
      lllllllllllllllIllIIllIllIlllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIllIllll() {
    llIIlIIlIIIIII = new int[27];
    llIIlIIlIIIIII[0] = (0x43 ^ 0x50) << " ".length() << " ".length() & ((0x67 ^ 0x74) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    llIIlIIlIIIIII[1] = " ".length();
    llIIlIIlIIIIII[2] = " ".length() << " ".length();
    llIIlIIlIIIIII[3] = "   ".length();
    llIIlIIlIIIIII[4] = " ".length() << " ".length() << " ".length();
    llIIlIIlIIIIII[5] = -(297 + 32 - 111 + 451 + 574 + 294 - 709 + 528 - (1 + 539 - 156 + 243 << " ".length()) + (116 + 212 - 318 + 273 << " ".length() << " ".length()));
    llIIlIIlIIIIII[6] = 0x20 ^ 0x25;
    llIIlIIlIIIIII[7] = 0xAC ^ 0xBF;
    llIIlIIlIIIIII[8] = "   ".length() << " ".length();
    llIIlIIlIIIIII[9] = ((0x4B ^ 0x6E) << " ".length() ^ 0x64 ^ 0x27) << " ".length();
    llIIlIIlIIIIII[10] = 0x56 ^ 0x51;
    llIIlIIlIIIIII[11] = "   ".length() << " ".length() << " ".length();
    llIIlIIlIIIIII[12] = " ".length() << "   ".length();
    llIIlIIlIIIIII[13] = 8 + 178 - 66 + 83 ^ (0x6 ^ 0x67) << " ".length();
    llIIlIIlIIIIII[14] = (0x26 ^ 0x21) << " ".length();
    llIIlIIlIIIIII[15] = (0xE0 ^ 0x8B ^ (0x35 ^ 0x2) << " ".length()) << " ".length();
    llIIlIIlIIIIII[16] = "   ".length() << (0x97 ^ 0x92) ^ 0xC2 ^ 0xAF;
    llIIlIIlIIIIII[17] = 0xBF ^ 0xB4;
    llIIlIIlIIIIII[18] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIlIIIIII[19] = 0x10 ^ 0x1F;
    llIIlIIlIIIIII[20] = 0x10 ^ 0x43 ^ (0x68 ^ 0x49) << " ".length();
    llIIlIIlIIIIII[21] = ((0x4A ^ 0x5F) << " ".length() ^ 0x80 ^ 0xAF) << " ".length() << " ".length();
    llIIlIIlIIIIII[22] = 0x53 ^ 0x46;
    llIIlIIlIIIIII[23] = (0x52 ^ 0x65 ^ (0xBC ^ 0xB3) << " ".length() << " ".length()) << " ".length();
    llIIlIIlIIIIII[24] = 0x4F ^ 0x18 ^ " ".length() << "   ".length() << " ".length();
    llIIlIIlIIIIII[25] = "   ".length() << "   ".length();
    llIIlIIlIIIIII[26] = 0x5A ^ 0x43;
  }
  
  private static boolean lIIIIllIIlllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIIlllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIIlllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIIlllIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIllIIlllIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */