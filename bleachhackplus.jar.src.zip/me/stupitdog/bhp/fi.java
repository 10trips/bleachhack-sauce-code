package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraftforge.client.event.ClientChatEvent;

public class fi {
  public String prefix;
  
  public ArrayList<fh> commands;
  
  @EventHandler
  public Listener<ClientChatEvent> listener;
  
  private static String[] lIlllIIlIIIlII;
  
  private static Class[] lIlllIIlIIIlIl;
  
  private static final String[] lIlllIIlIIIllI;
  
  private static String[] lIlllIIlIIIlll;
  
  private static final int[] lIlllIIlIIlIII;
  
  public fi() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/fi.lIlllIIlIIIllI : [Ljava/lang/String;
    //   8: getstatic me/stupitdog/bhp/fi.lIlllIIlIIlIII : [I
    //   11: iconst_0
    //   12: iaload
    //   13: aaload
    //   14: <illegal opcode> 0 : (Lme/stupitdog/bhp/fi;Ljava/lang/String;)V
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: <illegal opcode> 1 : (Lme/stupitdog/bhp/fi;Ljava/util/ArrayList;)V
    //   32: aload_0
    //   33: new me/zero/alpine/listener/Listener
    //   36: dup
    //   37: aload_0
    //   38: <illegal opcode> invoke : (Lme/stupitdog/bhp/fi;)Lme/zero/alpine/listener/EventHook;
    //   43: getstatic me/stupitdog/bhp/fi.lIlllIIlIIlIII : [I
    //   46: iconst_0
    //   47: iaload
    //   48: anewarray java/util/function/Predicate
    //   51: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   54: <illegal opcode> 2 : (Lme/stupitdog/bhp/fi;Lme/zero/alpine/listener/Listener;)V
    //   59: <illegal opcode> 3 : ()Lme/zero/alpine/EventManager;
    //   64: aload_0
    //   65: <illegal opcode> 4 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   70: aload_0
    //   71: <illegal opcode> 5 : (Lme/stupitdog/bhp/fi;)V
    //   76: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIlllIlllIIIlIllll	Lme/stupitdog/bhp/fi;
  }
  
  public void init() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   6: new me/stupitdog/bhp/ah
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop2
    //   24: aload_0
    //   25: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   30: new me/stupitdog/bhp/ff
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   42: ldc ''
    //   44: invokevirtual length : ()I
    //   47: pop2
    //   48: aload_0
    //   49: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   54: new me/stupitdog/bhp/f100000000000000000000000000000000
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   66: ldc ''
    //   68: invokevirtual length : ()I
    //   71: pop2
    //   72: aload_0
    //   73: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   78: new me/stupitdog/bhp/f04
    //   81: dup
    //   82: invokespecial <init> : ()V
    //   85: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   90: ldc ''
    //   92: invokevirtual length : ()I
    //   95: pop2
    //   96: aload_0
    //   97: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   102: new me/stupitdog/bhp/ag
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   114: ldc ''
    //   116: invokevirtual length : ()I
    //   119: pop2
    //   120: aload_0
    //   121: <illegal opcode> 6 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   126: new me/stupitdog/bhp/f100000000000000000000000000000000000
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: <illegal opcode> 7 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	145	0	lllllllllllllllIlllIlllIIIlIlllI	Lme/stupitdog/bhp/fi;
  }
  
  static {
    lllllIIIlIIIIll();
    lllllIIIlIIIIlI();
    lllllIIIlIIIIIl();
    lllllIIIIlllIIl();
  }
  
  private static CallSite lllllIIIIlIllIl(MethodHandles.Lookup lllllllllllllllIlllIlllIIIlIIIIl, String lllllllllllllllIlllIlllIIIlIIIII, MethodType lllllllllllllllIlllIlllIIIIlllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlllIIIlIIlll = lIlllIIlIIIlII[Integer.parseInt(lllllllllllllllIlllIlllIIIlIIIII)].split(lIlllIIlIIIllI[lIlllIIlIIlIII[3]]);
      Class<?> lllllllllllllllIlllIlllIIIlIIllI = Class.forName(lllllllllllllllIlllIlllIIIlIIlll[lIlllIIlIIlIII[0]]);
      String lllllllllllllllIlllIlllIIIlIIlIl = lllllllllllllllIlllIlllIIIlIIlll[lIlllIIlIIlIII[1]];
      MethodHandle lllllllllllllllIlllIlllIIIlIIlII = null;
      int lllllllllllllllIlllIlllIIIlIIIll = lllllllllllllllIlllIlllIIIlIIlll[lIlllIIlIIlIII[3]].length();
      if (lllllIIIlIIIlIl(lllllllllllllllIlllIlllIIIlIIIll, lIlllIIlIIlIII[2])) {
        MethodType lllllllllllllllIlllIlllIIIlIlIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlllIIIlIIlll[lIlllIIlIIlIII[2]], fi.class.getClassLoader());
        if (lllllIIIlIIIllI(lllllllllllllllIlllIlllIIIlIIIll, lIlllIIlIIlIII[2])) {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findVirtual(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIIl);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findStatic(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIIl);
        } 
        "".length();
        if (" ".length() << " ".length() == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlllIIIlIlIII = lIlllIIlIIIlIl[Integer.parseInt(lllllllllllllllIlllIlllIIIlIIlll[lIlllIIlIIlIII[2]])];
        if (lllllIIIlIIIllI(lllllllllllllllIlllIlllIIIlIIIll, lIlllIIlIIlIII[3])) {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findGetter(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIII);
          "".length();
          if (((0x8 ^ 0x13 ^ (0x25 ^ 0x38) << " ".length()) & ((0x51 ^ 0x5E) << " ".length() ^ 0x30 ^ 0xF ^ -" ".length())) > 0)
            return null; 
        } else if (lllllIIIlIIIllI(lllllllllllllllIlllIlllIIIlIIIll, lIlllIIlIIlIII[4])) {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findStaticGetter(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIIIlIIIllI(lllllllllllllllIlllIlllIIIlIIIll, lIlllIIlIIlIII[5])) {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findSetter(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIII);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIlllIIIlIIlII = lllllllllllllllIlllIlllIIIlIIIIl.findStaticSetter(lllllllllllllllIlllIlllIIIlIIllI, lllllllllllllllIlllIlllIIIlIIlIl, lllllllllllllllIlllIlllIIIlIlIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlllIIIlIIlII);
    } catch (Exception lllllllllllllllIlllIlllIIIlIIIlI) {
      lllllllllllllllIlllIlllIIIlIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIIlllIIl() {
    lIlllIIlIIIlII = new String[lIlllIIlIIlIII[6]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[7]] = lIlllIIlIIIllI[lIlllIIlIIlIII[4]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[8]] = lIlllIIlIIIllI[lIlllIIlIIlIII[5]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[9]] = lIlllIIlIIIllI[lIlllIIlIIlIII[10]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[11]] = lIlllIIlIIIllI[lIlllIIlIIlIII[12]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[13]] = lIlllIIlIIIllI[lIlllIIlIIlIII[14]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[5]] = lIlllIIlIIIllI[lIlllIIlIIlIII[15]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[3]] = lIlllIIlIIIllI[lIlllIIlIIlIII[9]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[16]] = lIlllIIlIIIllI[lIlllIIlIIlIII[11]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[17]] = lIlllIIlIIIllI[lIlllIIlIIlIII[17]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[12]] = lIlllIIlIIIllI[lIlllIIlIIlIII[18]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[19]] = lIlllIIlIIIllI[lIlllIIlIIlIII[13]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[10]] = lIlllIIlIIIllI[lIlllIIlIIlIII[20]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[14]] = lIlllIIlIIIllI[lIlllIIlIIlIII[21]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[15]] = lIlllIIlIIIllI[lIlllIIlIIlIII[22]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[0]] = lIlllIIlIIIllI[lIlllIIlIIlIII[7]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[20]] = lIlllIIlIIIllI[lIlllIIlIIlIII[16]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[22]] = lIlllIIlIIIllI[lIlllIIlIIlIII[8]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[1]] = lIlllIIlIIIllI[lIlllIIlIIlIII[19]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[4]] = lIlllIIlIIIllI[lIlllIIlIIlIII[6]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[18]] = lIlllIIlIIIllI[lIlllIIlIIlIII[23]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[21]] = lIlllIIlIIIllI[lIlllIIlIIlIII[24]];
    lIlllIIlIIIlII[lIlllIIlIIlIII[2]] = lIlllIIlIIIllI[lIlllIIlIIlIII[25]];
    lIlllIIlIIIlIl = new Class[lIlllIIlIIlIII[4]];
    lIlllIIlIIIlIl[lIlllIIlIIlIII[2]] = Listener.class;
    lIlllIIlIIIlIl[lIlllIIlIIlIII[0]] = String.class;
    lIlllIIlIIIlIl[lIlllIIlIIlIII[3]] = EventManager.class;
    lIlllIIlIIIlIl[lIlllIIlIIlIII[1]] = ArrayList.class;
  }
  
  private static void lllllIIIlIIIIIl() {
    lIlllIIlIIIllI = new String[lIlllIIlIIlIII[26]];
    lIlllIIlIIIllI[lIlllIIlIIlIII[0]] = lllllIIIIlllIlI(lIlllIIlIIIlll[lIlllIIlIIlIII[0]], lIlllIIlIIIlll[lIlllIIlIIlIII[1]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[1]] = lllllIIIIllllll(lIlllIIlIIIlll[lIlllIIlIIlIII[2]], lIlllIIlIIIlll[lIlllIIlIIlIII[3]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[2]] = lllllIIIlIIIIII(lIlllIIlIIIlll[lIlllIIlIIlIII[4]], lIlllIIlIIIlll[lIlllIIlIIlIII[5]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[3]] = lllllIIIIllllll(lIlllIIlIIIlll[lIlllIIlIIlIII[10]], lIlllIIlIIIlll[lIlllIIlIIlIII[12]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[4]] = lllllIIIIlllIlI(lIlllIIlIIIlll[lIlllIIlIIlIII[14]], lIlllIIlIIIlll[lIlllIIlIIlIII[15]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[5]] = lllllIIIIllllll(lIlllIIlIIIlll[lIlllIIlIIlIII[9]], lIlllIIlIIIlll[lIlllIIlIIlIII[11]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[10]] = lllllIIIIlllIlI(lIlllIIlIIIlll[lIlllIIlIIlIII[17]], lIlllIIlIIIlll[lIlllIIlIIlIII[18]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[12]] = lllllIIIlIIIIII(lIlllIIlIIIlll[lIlllIIlIIlIII[13]], lIlllIIlIIIlll[lIlllIIlIIlIII[20]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[14]] = lllllIIIIllllll(lIlllIIlIIIlll[lIlllIIlIIlIII[21]], lIlllIIlIIIlll[lIlllIIlIIlIII[22]]);
    lIlllIIlIIIllI[lIlllIIlIIlIII[15]] = lllllIIIIllllll("LAJlPCE0FyI7MS4AZS09MUktJm8oCSI7b2lOHXV1YQ==", "AgKOU");
    lIlllIIlIIIllI[lIlllIIlIIlIII[9]] = lllllIIIIllllll("IjdEAg06IgMFHSA1RBMRP3wMSEMKBC8/LRAQPyJDfGhKUVlv", "ORjqy");
    lIlllIIlIIIllI[lIlllIIlIIlIII[11]] = lllllIIIlIIIIII("AlbHLgVzRVOVUhwhR8LCFANOXL5WuKN6isRTzjAG8DNxmq48kSzpYX/ua1QXMQfwxVu7IDJ3BC7/STIqc1Tazw==", "dfVeB");
    lIlllIIlIIIllI[lIlllIIlIIlIII[17]] = lllllIIIlIIIIII("VdV5mfskwBMXwaFaYA5ploJD7kHz5J5SMdiH2pd3nSQGwrW76GAkPrPaDnX+rTvQtoYgmIzsxXfW75oUqqyeQox3LHmBlMn2", "GeMam");
    lIlllIIlIIIllI[lIlllIIlIIlIII[18]] = lllllIIIIlllIlI("y5ix0J+49kuj8+px/EA428wFQn+CiT3+LxqeO3TnTMTDGb6RgkrzhzUi+2mOGURLczOsOfY8JJs=", "qEBcj");
    lIlllIIlIIIllI[lIlllIIlIIlIII[13]] = lllllIIIIlllIlI("GfFacO/cNU0hDK5lYgx098SqAkUHZUyS4rq5Gb4xTWLQvSZOwchsHynUNi37cPE/au4pnCzrwZP+BWZScJth9A==", "WDoyC");
    lIlllIIlIIIllI[lIlllIIlIIlIII[20]] = lllllIIIlIIIIII("iTy3KWFWRR0zmA86tGuxe1GalVr6PuWFfXKMPMun3MDlRiZtmYDaSg==", "nSnyM");
    lIlllIIlIIIllI[lIlllIIlIIlIII[21]] = lllllIIIIllllll("JhQeSB0hHw8FAikXHgAfOhYPSBMkGA8IBGYUHAMePF8pChktHx4lGCkFLxAVJgVQARU8PA8VAykWD1xYYT0ABwYpXgYHHi9eORICIR8NXUpoUQ==", "Hqjfp");
    lIlllIIlIIIllI[lIlllIIlIIlIII[22]] = lllllIIIIlllIlI("Ax5NOnEn0QkLo0pOnY+Vr0Gfeq9umxdf1kc8D8cDVM2DwGacX7JbCASeNUbYzL11OY2THzhoPpEoFmvRgw07YjQ+D4rNL1So", "CMAwg");
    lIlllIIlIIIllI[lIlllIIlIIlIII[7]] = lllllIIIIllllll("CQBXNB8RFRAzDwsCVyUDFEsfLlEUFxwhAhxfSX1LREVZZw==", "deyGk");
    lIlllIIlIIIllI[lIlllIIlIIlIII[16]] = lllllIIIIlllIlI("vc+CboOiallgvtcgBdgm6RVn0+Vx1S8Ii3tZJ3MuTx5MyKYNIo9Imy5I446H0fzk", "WGEqI");
    lIlllIIlIIIllI[lIlllIIlIIlIII[8]] = lllllIIIIllllll("BA5nEA0cGyAXHQYMZwERGUUvC0MODj0tGAQOc0tQJQEoFRhGBygNHkY4PREQBwxyWVlJ", "ikIcy");
    lIlllIIlIIIllI[lIlllIIlIIlIII[19]] = lllllIIIIllllll("LgpdHzk2HxoYKSwIXQ4lM0EVBXcgAB4BLC0LAFZ8eU9TTG1j", "CoslM");
    lIlllIIlIIIllI[lIlllIIlIIlIII[6]] = lllllIIIIllllll("KDFMDh83O0wVFjU9DBFUACIHGg4INQwVHSAmWAcPJycBBhMnMVhcNi81FBVVKTUME1UKNggRGTFvSyJAZXQ=", "ETbtz");
    lIlllIIlIIIllI[lIlllIIlIIlIII[23]] = lllllIIIIllllll("LhIGAnsxBxkPewUBAgIsCBoDF28tBxURNDAcAll9bT8aAiMlXAUXPChcORcwNhIEDCd/SVBD", "DspcU");
    lIlllIIlIIIllI[lIlllIIlIIlIII[24]] = lllllIIIIlllIlI("2/y7EJXnOhU9Pv6WD3DDuB9XhHxH92hjvd48PXH7xtKlhIR6WjQUo8JKWfqFjc+OQNgkY1wOKOXKm/tNuF5pR8GppSNZzI4C7Hi2RVSu2wY=", "ZBAhp");
    lIlllIIlIIIllI[lIlllIIlIIlIII[25]] = lllllIIIIlllIlI("b16Yl4Am/QtP90UQLdIt4NJz8NqD3yOB/qq6OVWJs6sikKIiSPFTuQ==", "VucLl");
    lIlllIIlIIIlll = null;
  }
  
  private static void lllllIIIlIIIIlI() {
    String str = (new Exception()).getStackTrace()[lIlllIIlIIlIII[0]].getFileName();
    lIlllIIlIIIlll = str.substring(str.indexOf("ä") + lIlllIIlIIlIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIIIlllIlI(String lllllllllllllllIlllIlllIIIIllIll, String lllllllllllllllIlllIlllIIIIllIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIIIIllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIIIIllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllIIIIlllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllIIIIlllIl.init(lIlllIIlIIlIII[2], lllllllllllllllIlllIlllIIIIllllI);
      return new String(lllllllllllllllIlllIlllIIIIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIIIIlllII) {
      lllllllllllllllIlllIlllIIIIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIIIllllll(String lllllllllllllllIlllIlllIIIIllIII, String lllllllllllllllIlllIlllIIIIlIlll) {
    lllllllllllllllIlllIlllIIIIllIII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlllIIIIlIllI = new StringBuilder();
    char[] lllllllllllllllIlllIlllIIIIlIlIl = lllllllllllllllIlllIlllIIIIlIlll.toCharArray();
    int lllllllllllllllIlllIlllIIIIlIlII = lIlllIIlIIlIII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlllIIIIllIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlIIlIII[0];
    while (lllllIIIlIIIlll(j, i)) {
      char lllllllllllllllIlllIlllIIIIllIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlllIIIIlIlII++;
      j++;
      "".length();
      if (" ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlllIIIIlIllI);
  }
  
  private static String lllllIIIlIIIIII(String lllllllllllllllIlllIlllIIIIlIIII, String lllllllllllllllIlllIlllIIIIIllll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIIIIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIIIIIllll.getBytes(StandardCharsets.UTF_8)), lIlllIIlIIlIII[14]), "DES");
      Cipher lllllllllllllllIlllIlllIIIIlIIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIlllIIIIlIIlI.init(lIlllIIlIIlIII[2], lllllllllllllllIlllIlllIIIIlIIll);
      return new String(lllllllllllllllIlllIlllIIIIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIIIIlIIIl) {
      lllllllllllllllIlllIlllIIIIlIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIlIIIIll() {
    lIlllIIlIIlIII = new int[27];
    lIlllIIlIIlIII[0] = (0x44 ^ 0x1) & (0x70 ^ 0x35 ^ 0xFFFFFFFF);
    lIlllIIlIIlIII[1] = " ".length();
    lIlllIIlIIlIII[2] = " ".length() << " ".length();
    lIlllIIlIIlIII[3] = "   ".length();
    lIlllIIlIIlIII[4] = " ".length() << " ".length() << " ".length();
    lIlllIIlIIlIII[5] = 0xA3 ^ 0xA6;
    lIlllIIlIIlIII[6] = (0x26 ^ 0x2D) << " ".length();
    lIlllIIlIIlIII[7] = (0x5B ^ 0x52) << " ".length();
    lIlllIIlIIlIII[8] = ((0x3A ^ 0x25) << " ".length() ^ 0x32 ^ 0x9) << " ".length() << " ".length();
    lIlllIIlIIlIII[9] = (0x1F ^ 0x1A) << " ".length();
    lIlllIIlIIlIII[10] = "   ".length() << " ".length();
    lIlllIIlIIlIII[11] = 0x47 ^ 0x58 ^ (0x51 ^ 0x54) << " ".length() << " ".length();
    lIlllIIlIIlIII[12] = 0x7B ^ 0x7C;
    lIlllIIlIIlIII[13] = (0x7C ^ 0x7B) << " ".length();
    lIlllIIlIIlIII[14] = " ".length() << "   ".length();
    lIlllIIlIIlIII[15] = (0x9C ^ 0xC3) << " ".length() ^ 162 + 133 - 182 + 70;
    lIlllIIlIIlIII[16] = 0x4B ^ 0x58;
    lIlllIIlIIlIII[17] = "   ".length() << " ".length() << " ".length();
    lIlllIIlIIlIII[18] = 0x4B ^ 0x46;
    lIlllIIlIIlIII[19] = 0xD5 ^ 0xC0;
    lIlllIIlIIlIII[20] = 0x7F ^ 0x70;
    lIlllIIlIIlIII[21] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIIlIII[22] = 0x7F ^ 0x6E;
    lIlllIIlIIlIII[23] = 0x52 ^ 0x45;
    lIlllIIlIIlIII[24] = "   ".length() << "   ".length();
    lIlllIIlIIlIII[25] = 0xB1 ^ 0xA8;
    lIlllIIlIIlIII[26] = (0x19 ^ 0x52 ^ (0x50 ^ 0x73) << " ".length()) << " ".length();
  }
  
  private static boolean lllllIIIlIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIIlIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIIlIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIIlIIIlII(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */