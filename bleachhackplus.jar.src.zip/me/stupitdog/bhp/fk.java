package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.CPacketUseEntity;

public class fk extends au {
  @EventHandler
  private Listener<f100> PacketEvent;
  
  private static String[] lIllllIIIllIIl;
  
  private static Class[] lIllllIIIllIlI;
  
  private static final String[] lIllllIlIIlIIl;
  
  private static String[] lIllllIlIIlllI;
  
  private static final int[] lIllllIlIIllll;
  
  public fk() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fk.lIllllIlIIlIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fk.lIllllIlIIllll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fk.lIllllIlIIlIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fk.lIllllIlIIllll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fk.lIllllIlIIlIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fk.lIllllIlIIllll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fk.lIllllIlIIllll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/fk.lIllllIlIIllll : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/fk;Lme/zero/alpine/listener/Listener;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	68	0	lllllllllllllllIlllIIlIlIlIlIlll	Lme/stupitdog/bhp/fk;
  }
  
  static {
    llllllIllllIllI();
    llllllIllllIlII();
    llllllIllllIIll();
    llllllIlllIIlll();
  }
  
  private static CallSite llllllIIllllIlI(MethodHandles.Lookup lllllllllllllllIlllIIlIlIlIIllII, String lllllllllllllllIlllIIlIlIlIIlIll, MethodType lllllllllllllllIlllIIlIlIlIIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIlIlIlIIlI = lIllllIIIllIIl[Integer.parseInt(lllllllllllllllIlllIIlIlIlIIlIll)].split(lIllllIlIIlIIl[lIllllIlIIllll[3]]);
      Class<?> lllllllllllllllIlllIIlIlIlIlIIIl = Class.forName(lllllllllllllllIlllIIlIlIlIlIIlI[lIllllIlIIllll[0]]);
      String lllllllllllllllIlllIIlIlIlIlIIII = lllllllllllllllIlllIIlIlIlIlIIlI[lIllllIlIIllll[1]];
      MethodHandle lllllllllllllllIlllIIlIlIlIIllll = null;
      int lllllllllllllllIlllIIlIlIlIIlllI = lllllllllllllllIlllIIlIlIlIlIIlI[lIllllIlIIllll[3]].length();
      if (llllllIlllllIlI(lllllllllllllllIlllIIlIlIlIIlllI, lIllllIlIIllll[2])) {
        MethodType lllllllllllllllIlllIIlIlIlIlIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIlIlIlIIlI[lIllllIlIIllll[2]], fk.class.getClassLoader());
        if (llllllIlllllIll(lllllllllllllllIlllIIlIlIlIIlllI, lIllllIlIIllll[2])) {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findVirtual(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIlII);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findStatic(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIlII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIlIlIlIIll = lIllllIIIllIlI[Integer.parseInt(lllllllllllllllIlllIIlIlIlIlIIlI[lIllllIlIIllll[2]])];
        if (llllllIlllllIll(lllllllllllllllIlllIIlIlIlIIlllI, lIllllIlIIllll[3])) {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findGetter(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIIll);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else if (llllllIlllllIll(lllllllllllllllIlllIIlIlIlIIlllI, lIllllIlIIllll[4])) {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findStaticGetter(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIIll);
          "".length();
          if (null != null)
            return null; 
        } else if (llllllIlllllIll(lllllllllllllllIlllIIlIlIlIIlllI, lIllllIlIIllll[5])) {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findSetter(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIIll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIIlIlIlIIllll = lllllllllllllllIlllIIlIlIlIIllII.findStaticSetter(lllllllllllllllIlllIIlIlIlIlIIIl, lllllllllllllllIlllIIlIlIlIlIIII, lllllllllllllllIlllIIlIlIlIlIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIlIlIIllll);
    } catch (Exception lllllllllllllllIlllIIlIlIlIIllIl) {
      lllllllllllllllIlllIIlIlIlIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIlllIIlll() {
    lIllllIIIllIIl = new String[lIllllIlIIllll[6]];
    lIllllIIIllIIl[lIllllIlIIllll[7]] = lIllllIlIIlIIl[lIllllIlIIllll[4]];
    lIllllIIIllIIl[lIllllIlIIllll[8]] = lIllllIlIIlIIl[lIllllIlIIllll[5]];
    lIllllIIIllIIl[lIllllIlIIllll[0]] = lIllllIlIIlIIl[lIllllIlIIllll[9]];
    lIllllIIIllIIl[lIllllIlIIllll[2]] = lIllllIlIIlIIl[lIllllIlIIllll[7]];
    lIllllIIIllIIl[lIllllIlIIllll[1]] = lIllllIlIIlIIl[lIllllIlIIllll[10]];
    lIllllIIIllIIl[lIllllIlIIllll[11]] = lIllllIlIIlIIl[lIllllIlIIllll[11]];
    lIllllIIIllIIl[lIllllIlIIllll[12]] = lIllllIlIIlIIl[lIllllIlIIllll[12]];
    lIllllIIIllIIl[lIllllIlIIllll[13]] = lIllllIlIIlIIl[lIllllIlIIllll[14]];
    lIllllIIIllIIl[lIllllIlIIllll[15]] = lIllllIlIIlIIl[lIllllIlIIllll[8]];
    lIllllIIIllIIl[lIllllIlIIllll[4]] = lIllllIlIIlIIl[lIllllIlIIllll[16]];
    lIllllIIIllIIl[lIllllIlIIllll[5]] = lIllllIlIIlIIl[lIllllIlIIllll[13]];
    lIllllIIIllIIl[lIllllIlIIllll[10]] = lIllllIlIIlIIl[lIllllIlIIllll[17]];
    lIllllIIIllIIl[lIllllIlIIllll[16]] = lIllllIlIIlIIl[lIllllIlIIllll[18]];
    lIllllIIIllIIl[lIllllIlIIllll[3]] = lIllllIlIIlIIl[lIllllIlIIllll[15]];
    lIllllIIIllIIl[lIllllIlIIllll[18]] = lIllllIlIIlIIl[lIllllIlIIllll[6]];
    lIllllIIIllIIl[lIllllIlIIllll[9]] = lIllllIlIIlIIl[lIllllIlIIllll[19]];
    lIllllIIIllIIl[lIllllIlIIllll[17]] = lIllllIlIIlIIl[lIllllIlIIllll[20]];
    lIllllIIIllIIl[lIllllIlIIllll[14]] = lIllllIlIIlIIl[lIllllIlIIllll[21]];
    lIllllIIIllIlI = new Class[lIllllIlIIllll[14]];
    lIllllIIIllIlI[lIllllIlIIllll[1]] = Listener.class;
    lIllllIIIllIlI[lIllllIlIIllll[11]] = NetHandlerPlayClient.class;
    lIllllIIIllIlI[lIllllIlIIllll[7]] = GameSettings.class;
    lIllllIIIllIlI[lIllllIlIIllll[0]] = f13.class;
    lIllllIIIllIlI[lIllllIlIIllll[5]] = EntityPlayerSP.class;
    lIllllIIIllIlI[lIllllIlIIllll[3]] = Minecraft.class;
    lIllllIIIllIlI[lIllllIlIIllll[12]] = double.class;
    lIllllIIIllIlI[lIllllIlIIllll[2]] = CPacketUseEntity.Action.class;
    lIllllIIIllIlI[lIllllIlIIllll[9]] = boolean.class;
    lIllllIIIllIlI[lIllllIlIIllll[10]] = KeyBinding.class;
    lIllllIIIllIlI[lIllllIlIIllll[4]] = WorldClient.class;
  }
  
  private static void llllllIllllIIll() {
    lIllllIlIIlIIl = new String[lIllllIlIIllll[22]];
    lIllllIlIIlIIl[lIllllIlIIllll[0]] = llllllIlllIlIII(lIllllIlIIlllI[lIllllIlIIllll[0]], lIllllIlIIlllI[lIllllIlIIllll[1]]);
    lIllllIlIIlIIl[lIllllIlIIllll[1]] = llllllIlllIlIIl(lIllllIlIIlllI[lIllllIlIIllll[2]], lIllllIlIIlllI[lIllllIlIIllll[3]]);
    lIllllIlIIlIIl[lIllllIlIIllll[2]] = llllllIlllIlIIl(lIllllIlIIlllI[lIllllIlIIllll[4]], lIllllIlIIlllI[lIllllIlIIllll[5]]);
    lIllllIlIIlIIl[lIllllIlIIllll[3]] = llllllIlllIlIIl(lIllllIlIIlllI[lIllllIlIIllll[9]], lIllllIlIIlllI[lIllllIlIIllll[7]]);
    lIllllIlIIlIIl[lIllllIlIIllll[4]] = llllllIlllIlIIl(lIllllIlIIlllI[lIllllIlIIllll[10]], lIllllIlIIlllI[lIllllIlIIllll[11]]);
    lIllllIlIIlIIl[lIllllIlIIllll[5]] = llllllIlllIlIII(lIllllIlIIlllI[lIllllIlIIllll[12]], lIllllIlIIlllI[lIllllIlIIllll[14]]);
    lIllllIlIIlIIl[lIllllIlIIllll[9]] = llllllIlllIlIIl(lIllllIlIIlllI[lIllllIlIIllll[8]], lIllllIlIIlllI[lIllllIlIIllll[16]]);
    lIllllIlIIlIIl[lIllllIlIIllll[7]] = llllllIlllIlIII(lIllllIlIIlllI[lIllllIlIIllll[13]], lIllllIlIIlllI[lIllllIlIIllll[17]]);
    lIllllIlIIlIIl[lIllllIlIIllll[10]] = llllllIlllIlIIl("KhRMEDEyAQsXISgWTAEtN18ECH8XEAEIIDM0FAYrM0tTWWVnUUJD", "GqbcE");
    lIllllIlIIlIIl[lIllllIlIIllll[11]] = llllllIlllIlIlI("/jCJbbrS/7GJWNJOrjgtdLZEBjZuE3Pg7gOMwcAO8U6WVrv7/FromEzirrCSScYZtO1TM7XK3cUkdscDoNl/uw==", "Cdmzw");
    lIllllIlIIlIIl[lIllllIlIIllll[12]] = llllllIlllIlIlI("WAEe2hS8+PCYqDf0PTJW0FOwyF1lKZUtKHENDBU9xOv52uS/mrmK0lqlMGYO+RwGpyDcAe4iXAk=", "EcYpA");
    lIllllIlIIlIIl[lIllllIlIIllll[14]] = llllllIlllIlIlI("3nB2ysbsnMSN3q5zuIOWAr1p0lJC8Cq7IsA5ighVutLHhRCpIRgyojEWqbxkyZMoX5hYcPhJ04REFihcBgOT3g==", "mKRBp");
    lIllllIlIIlIIl[lIllllIlIIllll[8]] = llllllIlllIlIII("TSfkKB+dJIVNKieEBieHqepwnufnqPrxlMZIUa8byz875msWPY7fn5an0I4ssP1qq5hMZPBup7VQ7GUgpmC/7UszbY/zExKPAJb/ArDSh36LN1GdQ/QrHE3UkWlC7mln3Vx5izWbVks=", "ZqTot");
    lIllllIlIIlIIl[lIllllIlIIllll[16]] = llllllIlllIlIlI("Gcuc/ISuuRTy3gWWF7g/3N8+jVlgZlnVSWi9tvSXEM89kfIxfyzLahuo7wVg7bIXliNmGgCxctajFFqJn8JEcTCy3jbSxKaW", "sBzNf");
    lIllllIlIIlIIl[lIllllIlIIllll[13]] = llllllIlllIlIII("QB/tveKX9dFhtrhAFII9IqdqfeXEU1PEcezSuqptU5c=", "CSVmx");
    lIllllIlIIlIIl[lIllllIlIIllll[17]] = llllllIlllIlIlI("gRAhH5l0owo9S3WfSWJG3IxKEZrXC8SsfkLPTulwgofygFli0RK1zL/yGwZIlLdvzyMY8oNqghg=", "uGDqf");
    lIllllIlIIlIIl[lIllllIlIIllll[18]] = llllllIlllIlIlI("O1VWYxxeHZI1JN1KpQAcgXFe20UcINkZnBH5UVaPY3T3/CUg67gKmkWTX6vrxn8eIK1YXrR1Vm3e7XB6QgK5uQ==", "whwXU");
    lIllllIlIIlIIl[lIllllIlIIllll[15]] = llllllIlllIlIlI("hCn/bFlCXNtsmZcELJPWUf67gJBwCbFvU50K5mY6xiaX+zNkQrIRRezXBVShk4Lay++gKwjJDW2cnwIkPqpJpuoCnYNs8fmrRofCElAs3AjYyQGwR7aYweeKSmfCHMEsJsGWzssVPTk/VVxFNB/IuAJjLSPVnLseuXqaZAsR25LenPxWT/xPZg==", "wnKKz");
    lIllllIlIIlIIl[lIllllIlIIllll[6]] = llllllIlllIlIII("iXIRoTUtcObVd3tK4BhBGkbNITDQw1hF5Nw6Zr4OJVH8fDMYpUiAdaKRahvN3qYdbw+fJ8Fi8wp6SCdpA9K5pA==", "hIbLT");
    lIllllIlIIlIIl[lIllllIlIIllll[19]] = llllllIlllIlIlI("VaW9nJdKcu6Aq0M5tTNytmmTL3D6rcrVVWwNlFLFG93xd5t9AL0VB2rvwqAn1zqgwoKzvMJ4b4A=", "dwhHX");
    lIllllIlIIlIIl[lIllllIlIIllll[20]] = llllllIlllIlIII("BSs0irIpKG8RDM0tqtd5SD6EvKRQp0sCPYivUBke13T5EJ48uQcsTr39WUvCwFNxbL10HR5VSQDePPJ5f4N2bA==", "zvkcg");
    lIllllIlIIlIIl[lIllllIlIIllll[21]] = llllllIlllIlIlI("ttTI9azFkX/EqsAf541zEvPOjkE9rvbdxyu+OtvhLc1jkh60SsT5qdJMHxmhl6oMzfq6++996NU2lkSjPaFQSA==", "VZiRF");
    lIllllIlIIlllI = null;
  }
  
  private static void llllllIllllIlII() {
    String str = (new Exception()).getStackTrace()[lIllllIlIIllll[0]].getFileName();
    lIllllIlIIlllI = str.substring(str.indexOf("ä") + lIllllIlIIllll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIlllIlIII(String lllllllllllllllIlllIIlIlIlIIIllI, String lllllllllllllllIlllIIlIlIlIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIlIlIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIlIlIIIlIl.getBytes(StandardCharsets.UTF_8)), lIllllIlIIllll[10]), "DES");
      Cipher lllllllllllllllIlllIIlIlIlIIlIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIlIlIIlIII.init(lIllllIlIIllll[2], lllllllllllllllIlllIIlIlIlIIlIIl);
      return new String(lllllllllllllllIlllIIlIlIlIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIlIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIlIlIIIlll) {
      lllllllllllllllIlllIIlIlIlIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlllIlIIl(String lllllllllllllllIlllIIlIlIlIIIIll, String lllllllllllllllIlllIIlIlIlIIIIlI) {
    lllllllllllllllIlllIIlIlIlIIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIlIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIlIlIIIIIl = new StringBuilder();
    char[] lllllllllllllllIlllIIlIlIlIIIIII = lllllllllllllllIlllIIlIlIlIIIIlI.toCharArray();
    int lllllllllllllllIlllIIlIlIIllllll = lIllllIlIIllll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIlIlIIIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlIIllll[0];
    while (llllllIllllllII(j, i)) {
      char lllllllllllllllIlllIIlIlIlIIIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIlIIllllll++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() == "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIlIlIIIIIl);
  }
  
  private static String llllllIlllIlIlI(String lllllllllllllllIlllIIlIlIIlllIll, String lllllllllllllllIlllIIlIlIIlllIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIlIIlllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIlIIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIlIIllllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIlIIllllIl.init(lIllllIlIIllll[2], lllllllllllllllIlllIIlIlIIlllllI);
      return new String(lllllllllllllllIlllIIlIlIIllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIlIIllllII) {
      lllllllllllllllIlllIIlIlIIllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIllllIllI() {
    lIllllIlIIllll = new int[23];
    lIllllIlIIllll[0] = (0xF0 ^ 0xB7) & (0xC5 ^ 0x82 ^ 0xFFFFFFFF);
    lIllllIlIIllll[1] = " ".length();
    lIllllIlIIllll[2] = " ".length() << " ".length();
    lIllllIlIIllll[3] = "   ".length();
    lIllllIlIIllll[4] = " ".length() << " ".length() << " ".length();
    lIllllIlIIllll[5] = (0x1B ^ 0x1C) << " ".length() ^ 0x3A ^ 0x31;
    lIllllIlIIllll[6] = (0xAB ^ 0xA2) << " ".length();
    lIllllIlIIllll[7] = 0xB2 ^ 0xB5;
    lIllllIlIIllll[8] = "   ".length() << " ".length() << " ".length();
    lIllllIlIIllll[9] = "   ".length() << " ".length();
    lIllllIlIIllll[10] = " ".length() << "   ".length();
    lIllllIlIIllll[11] = 4 + 140 - 127 + 160 ^ (0x26 ^ 0x31) << "   ".length();
    lIllllIlIIllll[12] = (76 + 77 - 137 + 153 ^ (0x2E ^ 0x5) << " ".length() << " ".length()) << " ".length();
    lIllllIlIIllll[13] = (0xA ^ 0xD) << " ".length();
    lIllllIlIIllll[14] = 0x78 ^ 0x73;
    lIllllIlIIllll[15] = 0xA5 ^ 0xB4;
    lIllllIlIIllll[16] = (0xB7 ^ 0xB2) << " ".length() << " ".length() << " ".length() ^ 0x1A ^ 0x47;
    lIllllIlIIllll[17] = (0x15 ^ 0x12) << " ".length() << " ".length() << " ".length() ^ 22 + 7 - -11 + 87;
    lIllllIlIIllll[18] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIlIIllll[19] = (0x57 ^ 0x44) << " ".length() << " ".length() ^ 0xF5 ^ 0xAA;
    lIllllIlIIllll[20] = (0xBB ^ 0xBE) << " ".length() << " ".length();
    lIllllIlIIllll[21] = 0x94 ^ 0x81;
    lIllllIlIIllll[22] = (0x73 ^ 0x78) << " ".length();
  }
  
  private static boolean llllllIlllllIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIllllllII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIlllllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllIlllllIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllllIllllIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllllIlllllIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */