package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;

public class f1000000000000000000000000000000000 extends au {
  public static final HashMap<String, Integer> totemPopCounter = new HashMap<>();
  
  @EventHandler
  private final Listener<f100000000000.Receive> packetEvent;
  
  private static String[] lIllIlIllllIIl;
  
  private static Class[] lIllIlIllllIlI;
  
  private static final String[] lIllIlIlllllIl;
  
  private static String[] lIllIllIIIIIII;
  
  private static final int[] lIllIllIIIIIIl;
  
  public f1000000000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIlIlllllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIllIIIIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIlIlllllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIllIIIIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIlIlllllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIllIIIIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIllIIIIIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000.lIllIllIIIIIIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: putfield packetEvent : Lme/zero/alpine/listener/Listener;
    //   65: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	66	0	lllllllllllllllIllllIlIIlIIlIIIl	Lme/stupitdog/bhp/f1000000000000000000000000000000000;
  }
  
  private static CallSite llllIlIIIlllIlI(MethodHandles.Lookup lllllllllllllllIllllIlIIlIIIIIlI, String lllllllllllllllIllllIlIIlIIIIIIl, MethodType lllllllllllllllIllllIlIIlIIIIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIlIIlIIIlIII = lIllIlIllllIIl[Integer.parseInt(lllllllllllllllIllllIlIIlIIIIIIl)].split(lIllIlIlllllIl[lIllIllIIIIIIl[5]]);
      Class<?> lllllllllllllllIllllIlIIlIIIIlll = Class.forName(lllllllllllllllIllllIlIIlIIIlIII[lIllIllIIIIIIl[0]]);
      String lllllllllllllllIllllIlIIlIIIIllI = lllllllllllllllIllllIlIIlIIIlIII[lIllIllIIIIIIl[1]];
      MethodHandle lllllllllllllllIllllIlIIlIIIIlIl = null;
      int lllllllllllllllIllllIlIIlIIIIlII = lllllllllllllllIllllIlIIlIIIlIII[lIllIllIIIIIIl[4]].length();
      if (llllIlIIlIIlllI(lllllllllllllllIllllIlIIlIIIIlII, lIllIllIIIIIIl[2])) {
        MethodType lllllllllllllllIllllIlIIlIIIlIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlIIlIIIlIII[lIllIllIIIIIIl[2]], f1000000000000000000000000000000000.class.getClassLoader());
        if (llllIlIIlIIllII(lllllllllllllllIllllIlIIlIIIIlII, lIllIllIIIIIIl[2])) {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findVirtual(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIlI);
          "".length();
          if (-" ".length() == "   ".length())
            return null; 
        } else {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findStatic(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIlI);
        } 
        "".length();
        if (" ".length() >= "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIlIIlIIIlIIl = lIllIlIllllIlI[Integer.parseInt(lllllllllllllllIllllIlIIlIIIlIII[lIllIllIIIIIIl[2]])];
        if (llllIlIIlIIllII(lllllllllllllllIllllIlIIlIIIIlII, lIllIllIIIIIIl[4])) {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findGetter(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIIl);
          "".length();
          if (((0xCC ^ 0x87) & (0x2D ^ 0x66 ^ 0xFFFFFFFF)) < 0)
            return null; 
        } else if (llllIlIIlIIllII(lllllllllllllllIllllIlIIlIIIIlII, lIllIllIIIIIIl[5])) {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findStaticGetter(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIIl);
          "".length();
          if (((0xED ^ 0xC0) & (0x43 ^ 0x6E ^ 0xFFFFFFFF)) < 0)
            return null; 
        } else if (llllIlIIlIIllII(lllllllllllllllIllllIlIIlIIIIlII, lIllIllIIIIIIl[6])) {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findSetter(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllllIlIIlIIIIlIl = lllllllllllllllIllllIlIIlIIIIIlI.findStaticSetter(lllllllllllllllIllllIlIIlIIIIlll, lllllllllllllllIllllIlIIlIIIIllI, lllllllllllllllIllllIlIIlIIIlIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIlIIlIIIIlIl);
    } catch (Exception lllllllllllllllIllllIlIIlIIIIIll) {
      lllllllllllllllIllllIlIIlIIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIIllllII() {
    lIllIlIllllIIl = new String[lIllIllIIIIIIl[7]];
    lIllIlIllllIIl[lIllIllIIIIIIl[1]] = lIllIlIlllllIl[lIllIllIIIIIIl[6]];
    lIllIlIllllIIl[lIllIllIIIIIIl[8]] = lIllIlIlllllIl[lIllIllIIIIIIl[9]];
    lIllIlIllllIIl[lIllIllIIIIIIl[10]] = lIllIlIlllllIl[lIllIllIIIIIIl[11]];
    lIllIlIllllIIl[lIllIllIIIIIIl[12]] = lIllIlIlllllIl[lIllIllIIIIIIl[13]];
    lIllIlIllllIIl[lIllIllIIIIIIl[11]] = lIllIlIlllllIl[lIllIllIIIIIIl[14]];
    lIllIlIllllIIl[lIllIllIIIIIIl[14]] = lIllIlIlllllIl[lIllIllIIIIIIl[15]];
    lIllIlIllllIIl[lIllIllIIIIIIl[0]] = lIllIlIlllllIl[lIllIllIIIIIIl[10]];
    lIllIlIllllIIl[lIllIllIIIIIIl[16]] = lIllIlIlllllIl[lIllIllIIIIIIl[17]];
    lIllIlIllllIIl[lIllIllIIIIIIl[9]] = lIllIlIlllllIl[lIllIllIIIIIIl[18]];
    lIllIlIllllIIl[lIllIllIIIIIIl[17]] = lIllIlIlllllIl[lIllIllIIIIIIl[16]];
    lIllIlIllllIIl[lIllIllIIIIIIl[4]] = lIllIlIlllllIl[lIllIllIIIIIIl[19]];
    lIllIlIllllIIl[lIllIllIIIIIIl[18]] = lIllIlIlllllIl[lIllIllIIIIIIl[8]];
    lIllIlIllllIIl[lIllIllIIIIIIl[5]] = lIllIlIlllllIl[lIllIllIIIIIIl[20]];
    lIllIlIllllIIl[lIllIllIIIIIIl[13]] = lIllIlIlllllIl[lIllIllIIIIIIl[12]];
    lIllIlIllllIIl[lIllIllIIIIIIl[2]] = lIllIlIlllllIl[lIllIllIIIIIIl[7]];
    lIllIlIllllIIl[lIllIllIIIIIIl[6]] = lIllIlIlllllIl[lIllIllIIIIIIl[21]];
    lIllIlIllllIIl[lIllIllIIIIIIl[15]] = lIllIlIlllllIl[lIllIllIIIIIIl[22]];
    lIllIlIllllIIl[lIllIllIIIIIIl[19]] = lIllIlIlllllIl[lIllIllIIIIIIl[23]];
    lIllIlIllllIIl[lIllIllIIIIIIl[20]] = lIllIlIlllllIl[lIllIllIIIIIIl[24]];
    lIllIlIllllIlI = new Class[lIllIllIIIIIIl[11]];
    lIllIlIllllIlI[lIllIllIIIIIIl[6]] = EntityPlayerSP.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[5]] = HashMap.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[0]] = f13.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[4]] = WorldClient.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[2]] = Minecraft.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[1]] = Listener.class;
    lIllIlIllllIlI[lIllIllIIIIIIl[9]] = EventManager.class;
  }
  
  private static void llllIlIIlIIIllI() {
    lIllIlIlllllIl = new String[lIllIllIIIIIIl[25]];
    lIllIlIlllllIl[lIllIllIIIIIIl[0]] = llllIlIIIllllIl(lIllIllIIIIIII[lIllIllIIIIIIl[0]], lIllIllIIIIIII[lIllIllIIIIIIl[1]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[1]] = llllIlIIIllllIl(lIllIllIIIIIII[lIllIllIIIIIIl[2]], lIllIllIIIIIII[lIllIllIIIIIIl[4]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[2]] = llllIlIIIlllllI(lIllIllIIIIIII[lIllIllIIIIIIl[5]], lIllIllIIIIIII[lIllIllIIIIIIl[6]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[4]] = llllIlIIIllllIl(lIllIllIIIIIII[lIllIllIIIIIIl[9]], lIllIllIIIIIII[lIllIllIIIIIIl[11]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[5]] = llllIlIIIllllIl(lIllIllIIIIIII[lIllIllIIIIIIl[13]], lIllIllIIIIIII[lIllIllIIIIIIl[14]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[6]] = llllIlIIIlllllI(lIllIllIIIIIII[lIllIllIIIIIIl[15]], lIllIllIIIIIII[lIllIllIIIIIIl[10]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[9]] = llllIlIIlIIIIll(lIllIllIIIIIII[lIllIllIIIIIIl[17]], lIllIllIIIIIII[lIllIllIIIIIIl[18]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[11]] = llllIlIIIllllIl(lIllIllIIIIIII[lIllIllIIIIIIl[16]], lIllIllIIIIIII[lIllIllIIIIIIl[19]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[13]] = llllIlIIlIIIIll(lIllIllIIIIIII[lIllIllIIIIIIl[8]], lIllIllIIIIIII[lIllIllIIIIIIl[20]]);
    lIllIlIlllllIl[lIllIllIIIIIIl[14]] = llllIlIIIlllllI("SfN4N3oAsFPXygUJMuXuQ67u1yIQcf423BZ3MWieRnFxPQXXzPh95JdvgPfWB1nVafTV2UAZ3YrK3rlQeUpcP7XKH8li6RGV", "bdbrl");
    lIllIlIlllllIl[lIllIllIIIIIIl[15]] = llllIlIIIlllllI("DkvkSOkrcme3QqcGtbAOlAZG9Hia2w/Hy5ZGNth2Oy1V0Fo+N0w9fR4YdmSwmtd35jecwwReOcncGJtJVPcm7A==", "jRaoA");
    lIllIlIlllllIl[lIllIllIIIIIIl[10]] = llllIlIIIllllIl("IxRsNjw7ASsxLCEWbCcgPl8kdHt0Mg0ICg8leHVyblFiZQ==", "NqBEH");
    lIllIlIlllllIl[lIllIllIIIIIIl[17]] = llllIlIIIlllllI("gciq2m+5LyJhL4QIXQUHLD5qVC4f5KrYMWMW4JjzUwgBvVX0pT0qFg==", "gQjCN");
    lIllIlIlllllIl[lIllIllIIIIIIl[18]] = llllIlIIIllllIl("Agt2ICQaHjEnNAAJdjE4H0A+YmBfXmhjYF9eaGNgX15oY2BfXmhjYF9eaGNgX15oY2BfXmInPxsLNQM/Hy03Jj4bCyppZFVOeHNw", "onXSP");
    lIllIlIlllllIl[lIllIllIIIIIIl[16]] = llllIlIIIlllllI("gA9Pi3aqpn9/J/E5eAyfrmlgAidSJJyi/AIIAKZBf23RpZOcfkndBouYOGObL3uVvQ7ZFdmK1TAAiTp30lP9p3lI8dlprIA/U3oM7+13y276qvxwppQ5mQ==", "ASoXS");
    lIllIlIlllllIl[lIllIllIIIIIIl[19]] = llllIlIIIlllllI("3Y3yFB6kyxzYQk6mUUdFs9BTZMuXzu2lXHbvd6i8HRVcdu93qLwdFVx273eovB0VI4X7eN9oE1nvsMehgz+aMg==", "TrnPz");
    lIllIlIlllllIl[lIllIllIIIIIIl[8]] = llllIlIIIlllllI("YTF0vGEI1ebxsMGZ60vqx1iUgbN3Qh17D37uTqa9w9mt+7GInblARzYSbw2oeCtQOdzCK/rS+8c=", "YAGwS");
    lIllIlIlllllIl[lIllIllIIIIIIl[20]] = llllIlIIIllllIl("BDcEVz0DPBUaIgs0BFczBjsVFyREHxkXNQkgER8kUDQZHDwODUdIZF5jLxxqWWhQWXA=", "jRpyP");
    lIllIlIlllllIl[lIllIllIIIIIIl[12]] = llllIlIIIlllllI("iPKoeYzCIMCzqrwkFLQKTiUmuXDjprvriBnyHcJXpbCJQkVn67cy6qgBwV6I3stmlc/68DOLaao=", "xWNta");
    lIllIlIlllllIl[lIllIllIIIIIIl[7]] = llllIlIIIlllllI("GS9a2ewvHoM14HjD9ZyZNyzjSwIIm5TqPQ4MI1a4FGFhQ9cgdnaj91oBrarGKyEMB9P/3VVWpY4czzNRweOpG6cbNynziUsb8j6jxF3oHlo=", "MSFTB");
    lIllIlIlllllIl[lIllIllIIIIIIl[21]] = llllIlIIlIIIIll("t5a51wyqCDmCyn74AWZjExHP38j7yYeWjTgirF/w2f9gmNxCipAjxSnfvySqWoTAKEG7WyF0tWMOkslL5FCpoNuWEStUoBOpD73Xtdtd1z7huXJSZwxx1WXEcMGrt0nu8L2jCLFC9rQ8U506IQ6EX1KBP9K+y41gWTHrfjEocEmtOOecZCTMdQ==", "sOiXN");
    lIllIlIlllllIl[lIllIllIIIIIIl[22]] = llllIlIIlIIIIll("530BLCBKtESCkk9BHIlyxKbk01TK+9xuzJLe5hxVqam1utFJigro9g==", "fxOcs");
    lIllIlIlllllIl[lIllIllIIIIIIl[23]] = llllIlIIIlllllI("6GIVme5i+OXF8zEadfjJwv/K2kKVSfjhJ0KvtxQi0wHVRYce27qkCs/YDhC66sN+2FU5WCAF2SX/ykAnNAR4dA==", "diwNX");
    lIllIlIlllllIl[lIllIllIIIIIIl[24]] = llllIlIIIllllIl("Jy0+GUkhLSYfSR44OhEJKg49EQspKTpCEyIfPAoOIytyUE4BJikOBmIgKRYAYh88Cg4jK3NCR20=", "MLHxg");
    lIllIllIIIIIII = null;
  }
  
  private static void llllIlIIlIIIlll() {
    String str = (new Exception()).getStackTrace()[lIllIllIIIIIIl[0]].getFileName();
    lIllIllIIIIIII = str.substring(str.indexOf("ä") + lIllIllIIIIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIIIllllIl(String lllllllllllllllIllllIlIIIllllllI, String lllllllllllllllIllllIlIIIlllllIl) {
    lllllllllllllllIllllIlIIIllllllI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIlIIIllllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIlIIIlllllII = new StringBuilder();
    char[] lllllllllllllllIllllIlIIIllllIll = lllllllllllllllIllllIlIIIlllllIl.toCharArray();
    int lllllllllllllllIllllIlIIIllllIlI = lIllIllIIIIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIlIIIllllllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllIIIIIIl[0];
    while (llllIlIIlIIllll(j, i)) {
      char lllllllllllllllIllllIlIIIlllllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIlIIIllllIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() == -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIlIIIlllllII);
  }
  
  private static String llllIlIIIlllllI(String lllllllllllllllIllllIlIIIlllIllI, String lllllllllllllllIllllIlIIIlllIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIIIllllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIIIlllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIlIIIllllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIlIIIllllIII.init(lIllIllIIIIIIl[2], lllllllllllllllIllllIlIIIllllIIl);
      return new String(lllllllllllllllIllllIlIIIllllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIIIlllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIIIlllIlll) {
      lllllllllllllllIllllIlIIIlllIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIIlIIIIll(String lllllllllllllllIllllIlIIIlllIIIl, String lllllllllllllllIllllIlIIIlllIIII) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIIIlllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIIIlllIIII.getBytes(StandardCharsets.UTF_8)), lIllIllIIIIIIl[13]), "DES");
      Cipher lllllllllllllllIllllIlIIIlllIIll = Cipher.getInstance("DES");
      lllllllllllllllIllllIlIIIlllIIll.init(lIllIllIIIIIIl[2], lllllllllllllllIllllIlIIIlllIlII);
      return new String(lllllllllllllllIllllIlIIIlllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIIIlllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIIIlllIIlI) {
      lllllllllllllllIllllIlIIIlllIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIlIIlIlI() {
    lIllIllIIIIIIl = new int[26];
    lIllIllIIIIIIl[0] = (0x16 ^ 0x3D) << " ".length() & ((0xC ^ 0x27) << " ".length() ^ 0xFFFFFFFF);
    lIllIllIIIIIIl[1] = " ".length();
    lIllIllIIIIIIl[2] = " ".length() << " ".length();
    lIllIllIIIIIIl[3] = (0x54 ^ 0x43) << " ".length() << " ".length() ^ 99 + 29 - 5 + 4;
    lIllIllIIIIIIl[4] = "   ".length();
    lIllIllIIIIIIl[5] = " ".length() << " ".length() << " ".length();
    lIllIllIIIIIIl[6] = 0x4B ^ 0x4E;
    lIllIllIIIIIIl[7] = 87 + 103 - 60 + 23 ^ (0x47 ^ 0x2) << " ".length();
    lIllIllIIIIIIl[8] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIllIIIIIIl[9] = "   ".length() << " ".length();
    lIllIllIIIIIIl[10] = 0x6E ^ 0x65;
    lIllIllIIIIIIl[11] = (0xF9 ^ 0xA6) << " ".length() ^ 7 + 78 - -100 + 0;
    lIllIllIIIIIIl[12] = (0x27 ^ 0x2E) << " ".length();
    lIllIllIIIIIIl[13] = " ".length() << "   ".length();
    lIllIllIIIIIIl[14] = 0x44 ^ 0x4D;
    lIllIllIIIIIIl[15] = (0x1A ^ 0x5 ^ (0x26 ^ 0x2B) << " ".length()) << " ".length();
    lIllIllIIIIIIl[16] = (0x90 ^ 0x97) << " ".length();
    lIllIllIIIIIIl[17] = "   ".length() << " ".length() << " ".length();
    lIllIllIIIIIIl[18] = (0x6C ^ 0x3D) << " ".length() ^ 71 + 52 - 28 + 80;
    lIllIllIIIIIIl[19] = 0x30 ^ 0x3F;
    lIllIllIIIIIIl[20] = 0x9A ^ 0x8B;
    lIllIllIIIIIIl[21] = (0x68 ^ 0x6D) << " ".length() << " ".length();
    lIllIllIIIIIIl[22] = 0xB5 ^ 0xA0;
    lIllIllIIIIIIl[23] = (0x44 ^ 0x4F) << " ".length();
    lIllIllIIIIIIl[24] = 0x35 ^ 0x22;
    lIllIllIIIIIIl[25] = "   ".length() << "   ".length();
  }
  
  private static boolean llllIlIIlIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIIlIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIIlIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIIlIIllIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllIlIIlIIlIll(int paramInt) {
    return (paramInt != 0);
  }
  
  static {
    llllIlIIlIIlIlI();
    llllIlIIlIIIlll();
    llllIlIIlIIIllI();
    llllIlIIIllllII();
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */