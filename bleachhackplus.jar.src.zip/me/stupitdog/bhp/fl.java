package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fl extends au {
  private static String[] lIllllIIllllIl;
  
  private static Class[] lIllllIIlllllI;
  
  private static final String[] lIllllIIllllll;
  
  private static String[] lIllllIlIIIIII;
  
  private static final int[] lIllllIlIIIIIl;
  
  public fl() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fl.lIllllIIllllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fl.lIllllIlIIIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fl.lIllllIIllllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fl.lIllllIlIIIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fl.lIllllIIllllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fl.lIllllIlIIIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fl.lIllllIlIIIIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIlIllIIlIlIl	Lme/stupitdog/bhp/fl;
  }
  
  static {
    llllllIllIlIlll();
    llllllIllIlIllI();
    llllllIllIlIlIl();
    llllllIllIlIIlI();
  }
  
  private static CallSite llllllIllIlIIIl(MethodHandles.Lookup lllllllllllllllIlllIIlIllIIIllII, String lllllllllllllllIlllIIlIllIIIlIll, MethodType lllllllllllllllIlllIIlIllIIIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIllIIlIIlI = lIllllIIllllIl[Integer.parseInt(lllllllllllllllIlllIIlIllIIIlIll)].split(lIllllIIllllll[lIllllIlIIIIIl[3]]);
      Class<?> lllllllllllllllIlllIIlIllIIlIIIl = Class.forName(lllllllllllllllIlllIIlIllIIlIIlI[lIllllIlIIIIIl[0]]);
      String lllllllllllllllIlllIIlIllIIlIIII = lllllllllllllllIlllIIlIllIIlIIlI[lIllllIlIIIIIl[1]];
      MethodHandle lllllllllllllllIlllIIlIllIIIllll = null;
      int lllllllllllllllIlllIIlIllIIIlllI = lllllllllllllllIlllIIlIllIIlIIlI[lIllllIlIIIIIl[3]].length();
      if (llllllIllIllIII(lllllllllllllllIlllIIlIllIIIlllI, lIllllIlIIIIIl[2])) {
        MethodType lllllllllllllllIlllIIlIllIIlIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIllIIlIIlI[lIllllIlIIIIIl[2]], fl.class.getClassLoader());
        if (llllllIllIllIIl(lllllllllllllllIlllIIlIllIIIlllI, lIllllIlIIIIIl[2])) {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findVirtual(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIlII);
          "".length();
          if (((0xA0 ^ 0xA5 ^ (0xAB ^ 0xA2) << " ".length()) << " ".length() << " ".length() & ((62 + 52 - -42 + 3 ^ (0x72 ^ 0x63) << "   ".length()) << " ".length() << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findStatic(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIlII);
        } 
        "".length();
        if (((0xB ^ 0x24) << " ".length() & ((0x43 ^ 0x6C) << " ".length() ^ 0xFFFFFFFF)) != ((0x1E ^ 0x1) << " ".length() & ((0x37 ^ 0x28) << " ".length() ^ 0xFFFFFFFF)))
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIllIIlIIll = lIllllIIlllllI[Integer.parseInt(lllllllllllllllIlllIIlIllIIlIIlI[lIllllIlIIIIIl[2]])];
        if (llllllIllIllIIl(lllllllllllllllIlllIIlIllIIIlllI, lIllllIlIIIIIl[3])) {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findGetter(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIIll);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (llllllIllIllIIl(lllllllllllllllIlllIIlIllIIIlllI, lIllllIlIIIIIl[4])) {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findStaticGetter(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIIll);
          "".length();
          if (((223 + 166 - 372 + 226 ^ (0xC3 ^ 0xA2) << " ".length()) & ("   ".length() << " ".length() << " ".length() ^ 0x7F ^ 0x42 ^ -" ".length())) >= " ".length())
            return null; 
        } else if (llllllIllIllIIl(lllllllllllllllIlllIIlIllIIIlllI, lIllllIlIIIIIl[5])) {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findSetter(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIIll);
          "".length();
          if (" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIllIIIllll = lllllllllllllllIlllIIlIllIIIllII.findStaticSetter(lllllllllllllllIlllIIlIllIIlIIIl, lllllllllllllllIlllIIlIllIIlIIII, lllllllllllllllIlllIIlIllIIlIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIllIIIllll);
    } catch (Exception lllllllllllllllIlllIIlIllIIIllIl) {
      lllllllllllllllIlllIIlIllIIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIllIlIIlI() {
    lIllllIIllllIl = new String[lIllllIlIIIIIl[1]];
    lIllllIIllllIl[lIllllIlIIIIIl[0]] = lIllllIIllllll[lIllllIlIIIIIl[4]];
    lIllllIIlllllI = new Class[lIllllIlIIIIIl[1]];
    lIllllIIlllllI[lIllllIlIIIIIl[0]] = f13.class;
  }
  
  private static void llllllIllIlIlIl() {
    lIllllIIllllll = new String[lIllllIlIIIIIl[5]];
    lIllllIIllllll[lIllllIlIIIIIl[0]] = llllllIllIlIIll(lIllllIlIIIIII[lIllllIlIIIIIl[0]], lIllllIlIIIIII[lIllllIlIIIIIl[1]]);
    lIllllIIllllll[lIllllIlIIIIIl[1]] = llllllIllIlIlII(lIllllIlIIIIII[lIllllIlIIIIIl[2]], lIllllIlIIIIII[lIllllIlIIIIIl[3]]);
    lIllllIIllllll[lIllllIlIIIIIl[2]] = llllllIllIlIIll(lIllllIlIIIIII[lIllllIlIIIIIl[4]], lIllllIlIIIIII[lIllllIlIIIIIl[5]]);
    lIllllIIllllll[lIllllIlIIIIIl[3]] = llllllIllIlIIll(lIllllIlIIIIII[lIllllIlIIIIIl[6]], lIllllIlIIIIII[lIllllIlIIIIIl[7]]);
    lIllllIIllllll[lIllllIlIIIIIl[4]] = llllllIllIlIIll(lIllllIlIIIIII[lIllllIlIIIIIl[8]], lIllllIlIIIIII[lIllllIlIIIIIl[9]]);
    lIllllIlIIIIII = null;
  }
  
  private static void llllllIllIlIllI() {
    String str = (new Exception()).getStackTrace()[lIllllIlIIIIIl[0]].getFileName();
    lIllllIlIIIIII = str.substring(str.indexOf("ä") + lIllllIlIIIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIllIlIlII(String lllllllllllllllIlllIIlIllIIIIllI, String lllllllllllllllIlllIIlIllIIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIllIIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIllIIIIlIl.getBytes(StandardCharsets.UTF_8)), lIllllIlIIIIIl[8]), "DES");
      Cipher lllllllllllllllIlllIIlIllIIIlIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIllIIIlIII.init(lIllllIlIIIIIl[2], lllllllllllllllIlllIIlIllIIIlIIl);
      return new String(lllllllllllllllIlllIIlIllIIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIllIIIIlll) {
      lllllllllllllllIlllIIlIllIIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIllIlIIll(String lllllllllllllllIlllIIlIllIIIIIll, String lllllllllllllllIlllIIlIllIIIIIlI) {
    lllllllllllllllIlllIIlIllIIIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllIIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIllIIIIIIl = new StringBuilder();
    char[] lllllllllllllllIlllIIlIllIIIIIII = lllllllllllllllIlllIIlIllIIIIIlI.toCharArray();
    int lllllllllllllllIlllIIlIlIlllllll = lIllllIlIIIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIllIIIIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlIIIIIl[0];
    while (llllllIllIllIlI(j, i)) {
      char lllllllllllllllIlllIIlIllIIIIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIlIlllllll++;
      j++;
      "".length();
      if (" ".length() << " ".length() >= "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIllIIIIIIl);
  }
  
  private static void llllllIllIlIlll() {
    lIllllIlIIIIIl = new int[10];
    lIllllIlIIIIIl[0] = (0x40 ^ 0x4B) & (0x3D ^ 0x36 ^ 0xFFFFFFFF);
    lIllllIlIIIIIl[1] = " ".length();
    lIllllIlIIIIIl[2] = " ".length() << " ".length();
    lIllllIlIIIIIl[3] = "   ".length();
    lIllllIlIIIIIl[4] = " ".length() << " ".length() << " ".length();
    lIllllIlIIIIIl[5] = (0xB9 ^ 0x8C) << " ".length() ^ 0x9 ^ 0x66;
    lIllllIlIIIIIl[6] = "   ".length() << " ".length();
    lIllllIlIIIIIl[7] = 0x11 ^ 0x16;
    lIllllIlIIIIIl[8] = " ".length() << "   ".length();
    lIllllIlIIIIIl[9] = (0x4B ^ 0x44) << " ".length() ^ 0xBD ^ 0xAA;
  }
  
  private static boolean llllllIllIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIllIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIllIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */