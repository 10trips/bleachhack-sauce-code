package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.text.TextFormatting;

public class ah extends fh {
  private static String[] lIlllllIIlIlII;
  
  private static Class[] lIlllllIIlIlIl;
  
  private static final String[] lIlllllIIlllII;
  
  private static String[] lIlllllIIlllIl;
  
  private static final int[] lIlllllIIllllI;
  
  public ah() {
    super(lIlllllIIlllII[lIlllllIIllllI[0]], lIlllllIIlllII[lIlllllIIllllI[1]], lIlllllIIlllII[lIlllllIIllllI[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIlllIIIlIIlIlIIll) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f9;
    //   5: <illegal opcode> 1 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/fi;
    //   10: <illegal opcode> 2 : (Lme/stupitdog/bhp/fi;)Ljava/util/ArrayList;
    //   15: <illegal opcode> 3 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   27: invokestatic lllllllllIIlIll : (I)Z
    //   30: ifeq -> 156
    //   33: aload_2
    //   34: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast me/stupitdog/bhp/fh
    //   42: astore_3
    //   43: new java/lang/StringBuilder
    //   46: dup
    //   47: invokespecial <init> : ()V
    //   50: <illegal opcode> 6 : ()Lnet/minecraft/util/text/TextFormatting;
    //   55: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   60: aload_3
    //   61: <illegal opcode> 8 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   66: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: <illegal opcode> 10 : ()Lnet/minecraft/util/text/TextFormatting;
    //   76: <illegal opcode> 7 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   81: getstatic me/stupitdog/bhp/ah.lIlllllIIlllII : [Ljava/lang/String;
    //   84: getstatic me/stupitdog/bhp/ah.lIlllllIIllllI : [I
    //   87: iconst_3
    //   88: iaload
    //   89: aaload
    //   90: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: aload_3
    //   96: <illegal opcode> 11 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   101: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: getstatic me/stupitdog/bhp/ah.lIlllllIIlllII : [Ljava/lang/String;
    //   109: getstatic me/stupitdog/bhp/ah.lIlllllIIllllI : [I
    //   112: iconst_4
    //   113: iaload
    //   114: aaload
    //   115: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: aload_3
    //   121: <illegal opcode> 12 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   126: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   131: <illegal opcode> 13 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   136: <illegal opcode> 14 : (Ljava/lang/String;)V
    //   141: ldc ''
    //   143: invokevirtual length : ()I
    //   146: pop
    //   147: ldc ' '
    //   149: invokevirtual length : ()I
    //   152: ifne -> 21
    //   155: return
    //   156: ldc ''
    //   158: invokevirtual length : ()I
    //   161: pop
    //   162: aconst_null
    //   163: ifnull -> 168
    //   166: return
    //   167: astore_2
    //   168: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	98	3	lllllllllllllllIlllIIIlIIlIlIlIl	Lme/stupitdog/bhp/fh;
    //   0	169	0	lllllllllllllllIlllIIIlIIlIlIlII	Lme/stupitdog/bhp/ah;
    //   0	169	1	lllllllllllllllIlllIIIlIIlIlIIll	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	156	167	java/lang/Exception
  }
  
  static {
    lllllllllIIlIlI();
    lllllllllIIlIIl();
    lllllllllIIlIII();
    lllllllllIIIlII();
  }
  
  private static CallSite llllllllIlIlIlI(MethodHandles.Lookup lllllllllllllllIlllIIIlIIlIIlIlI, String lllllllllllllllIlllIIIlIIlIIlIIl, MethodType lllllllllllllllIlllIIIlIIlIIlIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIlIIlIlIIII = lIlllllIIlIlII[Integer.parseInt(lllllllllllllllIlllIIIlIIlIIlIIl)].split(lIlllllIIlllII[lIlllllIIllllI[5]]);
      Class<?> lllllllllllllllIlllIIIlIIlIIllll = Class.forName(lllllllllllllllIlllIIIlIIlIlIIII[lIlllllIIllllI[0]]);
      String lllllllllllllllIlllIIIlIIlIIlllI = lllllllllllllllIlllIIIlIIlIlIIII[lIlllllIIllllI[1]];
      MethodHandle lllllllllllllllIlllIIIlIIlIIllIl = null;
      int lllllllllllllllIlllIIIlIIlIIllII = lllllllllllllllIlllIIIlIIlIlIIII[lIlllllIIllllI[3]].length();
      if (lllllllllIIllII(lllllllllllllllIlllIIIlIIlIIllII, lIlllllIIllllI[2])) {
        MethodType lllllllllllllllIlllIIIlIIlIlIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIlIIlIlIIII[lIlllllIIllllI[2]], ah.class.getClassLoader());
        if (lllllllllIIllIl(lllllllllllllllIlllIIIlIIlIIllII, lIlllllIIllllI[2])) {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findVirtual(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIlI);
          "".length();
          if (-(0xBC ^ 0xB8) >= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findStatic(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIlI);
        } 
        "".length();
        if (-" ".length() > -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIlIIlIlIIIl = lIlllllIIlIlIl[Integer.parseInt(lllllllllllllllIlllIIIlIIlIlIIII[lIlllllIIllllI[2]])];
        if (lllllllllIIllIl(lllllllllllllllIlllIIIlIIlIIllII, lIlllllIIllllI[3])) {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findGetter(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIIl);
          "".length();
          if ((0x1B ^ 0x1E) == 0)
            return null; 
        } else if (lllllllllIIllIl(lllllllllllllllIlllIIIlIIlIIllII, lIlllllIIllllI[4])) {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findStaticGetter(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else if (lllllllllIIllIl(lllllllllllllllIlllIIIlIIlIIllII, lIlllllIIllllI[5])) {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findSetter(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIIl);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIlIIlIIllIl = lllllllllllllllIlllIIIlIIlIIlIlI.findStaticSetter(lllllllllllllllIlllIIIlIIlIIllll, lllllllllllllllIlllIIIlIIlIIlllI, lllllllllllllllIlllIIIlIIlIlIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIlIIlIIllIl);
    } catch (Exception lllllllllllllllIlllIIIlIIlIIlIll) {
      lllllllllllllllIlllIIIlIIlIIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllllIIIlII() {
    lIlllllIIlIlII = new String[lIlllllIIllllI[6]];
    lIlllllIIlIlII[lIlllllIIllllI[7]] = lIlllllIIlllII[lIlllllIIllllI[8]];
    lIlllllIIlIlII[lIlllllIIllllI[9]] = lIlllllIIlllII[lIlllllIIllllI[10]];
    lIlllllIIlIlII[lIlllllIIllllI[8]] = lIlllllIIlllII[lIlllllIIllllI[11]];
    lIlllllIIlIlII[lIlllllIIllllI[12]] = lIlllllIIlllII[lIlllllIIllllI[13]];
    lIlllllIIlIlII[lIlllllIIllllI[10]] = lIlllllIIlllII[lIlllllIIllllI[14]];
    lIlllllIIlIlII[lIlllllIIllllI[1]] = lIlllllIIlllII[lIlllllIIllllI[12]];
    lIlllllIIlIlII[lIlllllIIllllI[0]] = lIlllllIIlllII[lIlllllIIllllI[15]];
    lIlllllIIlIlII[lIlllllIIllllI[3]] = lIlllllIIlllII[lIlllllIIllllI[9]];
    lIlllllIIlIlII[lIlllllIIllllI[14]] = lIlllllIIlllII[lIlllllIIllllI[7]];
    lIlllllIIlIlII[lIlllllIIllllI[13]] = lIlllllIIlllII[lIlllllIIllllI[6]];
    lIlllllIIlIlII[lIlllllIIllllI[11]] = lIlllllIIlllII[lIlllllIIllllI[16]];
    lIlllllIIlIlII[lIlllllIIllllI[5]] = lIlllllIIlllII[lIlllllIIllllI[17]];
    lIlllllIIlIlII[lIlllllIIllllI[4]] = lIlllllIIlllII[lIlllllIIllllI[18]];
    lIlllllIIlIlII[lIlllllIIllllI[2]] = lIlllllIIlllII[lIlllllIIllllI[19]];
    lIlllllIIlIlII[lIlllllIIllllI[15]] = lIlllllIIlllII[lIlllllIIllllI[20]];
    lIlllllIIlIlIl = new Class[lIlllllIIllllI[4]];
    lIlllllIIlIlIl[lIlllllIIllllI[1]] = fi.class;
    lIlllllIIlIlIl[lIlllllIIllllI[2]] = ArrayList.class;
    lIlllllIIlIlIl[lIlllllIIllllI[0]] = f9.class;
    lIlllllIIlIlIl[lIlllllIIllllI[3]] = TextFormatting.class;
  }
  
  private static void lllllllllIIlIII() {
    lIlllllIIlllII = new String[lIlllllIIllllI[21]];
    lIlllllIIlllII[lIlllllIIllllI[0]] = lllllllllIIIlIl(lIlllllIIlllIl[lIlllllIIllllI[0]], lIlllllIIlllIl[lIlllllIIllllI[1]]);
    lIlllllIIlllII[lIlllllIIllllI[1]] = lllllllllIIIllI(lIlllllIIlllIl[lIlllllIIllllI[2]], lIlllllIIlllIl[lIlllllIIllllI[3]]);
    lIlllllIIlllII[lIlllllIIllllI[2]] = lllllllllIIIlll(lIlllllIIlllIl[lIlllllIIllllI[4]], lIlllllIIlllIl[lIlllllIIllllI[5]]);
    lIlllllIIlllII[lIlllllIIllllI[3]] = lllllllllIIIlIl(lIlllllIIlllIl[lIlllllIIllllI[8]], lIlllllIIlllIl[lIlllllIIllllI[10]]);
    lIlllllIIlllII[lIlllllIIllllI[4]] = lllllllllIIIllI(lIlllllIIlllIl[lIlllllIIllllI[11]], lIlllllIIlllIl[lIlllllIIllllI[13]]);
    lIlllllIIlllII[lIlllllIIllllI[5]] = lllllllllIIIllI(lIlllllIIlllIl[lIlllllIIllllI[14]], lIlllllIIlllIl[lIlllllIIllllI[12]]);
    lIlllllIIlllII[lIlllllIIllllI[8]] = lllllllllIIIlIl(lIlllllIIlllIl[lIlllllIIllllI[15]], lIlllllIIlllIl[lIlllllIIllllI[9]]);
    lIlllllIIlllII[lIlllllIIllllI[10]] = lllllllllIIIllI(lIlllllIIlllIl[lIlllllIIllllI[7]], lIlllllIIlllIl[lIlllllIIllllI[6]]);
    lIlllllIIlllII[lIlllllIIllllI[11]] = lllllllllIIIlIl(lIlllllIIlllIl[lIlllllIIllllI[16]], lIlllllIIlllIl[lIlllllIIllllI[17]]);
    lIlllllIIlllII[lIlllllIIllllI[13]] = lllllllllIIIlll("Ag9mGT8aGiEeLwANZggjH0QuAnEIDzwuLhwJOgM7GwMnBHFHQwQAKhkLZwYqAQ1nOT8dAyYNcFVKaA==", "ojHjK");
    lIlllllIIlllII[lIlllllIIllllI[14]] = lllllllllIIIlIl("wrq/ijDvWUTjce+j/ZWE1ECxXc70yFPnMY+shs7YFwrW3qrTwqSoDme+EtWdv9lygqbMmO9tnsaxfca2/of+UNo4uRvwDUIou38UFjabJuA=", "fOyoJ");
    lIlllllIIlllII[lIlllllIIllllI[12]] = lllllllllIIIlll("AR9+MCwZCjk3PAMdfiEwHFQ2emIPFT0uOQIeHSI2DR01MWJdQHBjeA==", "lzPCX");
    lIlllllIIlllII[lIlllllIIllllI[15]] = lllllllllIIIlll("LjVPJTc2IAgiJyw3TzQrM34Hb3kqPhIiIi0zBGxzeXBBdmM=", "CPaVC");
    lIlllllIIlllII[lIlllllIIllllI[9]] = lllllllllIIIlIl("C3Dhdhirae1TmoEosZqcd1DkoooiSMx0WnHMe3xHNA0gG3arrSFLJtCjK6WHXGnpC2yBEoddo1A=", "IPIlk");
    lIlllllIIlllII[lIlllllIIllllI[7]] = lllllllllIIIlIl("RMhJaQ1yRc3y4mtA2rCgHGR7BKLjL+uGZuWp+3ts+37gI4GKEacSbHIZ6spbLG/XVKGy7ZDX5Os=", "zDXDE");
    lIlllllIIlllII[lIlllllIIllllI[6]] = lllllllllIIIlIl("4Rwu20Cnz7pOn2Zt217DqhutwJsOLMULAlI74KX3NE7l/8GzLe5Z/J7NGOjPkdd2dAPSrez6YBcekW95LrW97WAM6fqm00hE5jqrf1SFxxE=", "cBZPv");
    lIlllllIIlllII[lIlllllIIllllI[16]] = lllllllllIIIllI("2Kanm8oups7TaPPp7Te8978ldxoNkjJG/Za7YuXBiRTtyvHiscriIdZdcfND8oJy6/x2VIkuNvg=", "xwFJn");
    lIlllllIIlllII[lIlllllIIllllI[17]] = lllllllllIIIllI("Ioo/ml8HWfR6dtBs7wDRI0ECQHLMFiNm+ca/rBmXPjIjw6m5kIDuCm7mVJbW+REr", "SGXfF");
    lIlllllIIlllII[lIlllllIIllllI[18]] = lllllllllIIIllI("Y/MFkXKj12HkSBDH9OolSPZCQpy4NTlGZft3Sae/lziip5IGDWyeNQ==", "MsOKw");
    lIlllllIIlllII[lIlllllIIllllI[19]] = lllllllllIIIlll("GyJ7FyQDNzwQNBkgewY4BmkzDWoVKDgJMRgjJl5iTGd1RA==", "vGUdP");
    lIlllllIIlllII[lIlllllIIllllI[20]] = lllllllllIIIllI("Av1CczmuTysi6ryKD6sV7kZ7UWaBiPy2oHAAxIHrQ2w89Wab7yXP/Y0LTjVz1WhiXa6yYHVRQ1Y=", "pbqBy");
    lIlllllIIlllIl = null;
  }
  
  private static void lllllllllIIlIIl() {
    String str = (new Exception()).getStackTrace()[lIlllllIIllllI[0]].getFileName();
    lIlllllIIlllIl = str.substring(str.indexOf("ä") + lIlllllIIllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllllIIIlIl(String lllllllllllllllIlllIIIlIIlIIIlII, String lllllllllllllllIlllIIIlIIlIIIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIIlIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIIlIIIIll.getBytes(StandardCharsets.UTF_8)), lIlllllIIllllI[11]), "DES");
      Cipher lllllllllllllllIlllIIIlIIlIIIllI = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIlIIlIIIllI.init(lIlllllIIllllI[2], lllllllllllllllIlllIIIlIIlIIIlll);
      return new String(lllllllllllllllIlllIIIlIIlIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIlIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIIlIIIlIl) {
      lllllllllllllllIlllIIIlIIlIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllllIIIllI(String lllllllllllllllIlllIIIlIIIllllll, String lllllllllllllllIlllIIIlIIIlllllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIIlIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIIIlllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIlIIlIIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIlIIlIIIIIl.init(lIlllllIIllllI[2], lllllllllllllllIlllIIIlIIlIIIIlI);
      return new String(lllllllllllllllIlllIIIlIIlIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIIlIIIIII) {
      lllllllllllllllIlllIIIlIIlIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllllIIIlll(String lllllllllllllllIlllIIIlIIIllllII, String lllllllllllllllIlllIIIlIIIlllIll) {
    lllllllllllllllIlllIIIlIIIllllII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIllllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIlIIIlllIlI = new StringBuilder();
    char[] lllllllllllllllIlllIIIlIIIlllIIl = lllllllllllllllIlllIIIlIIIlllIll.toCharArray();
    int lllllllllllllllIlllIIIlIIIlllIII = lIlllllIIllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIlIIIllllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllIIllllI[0];
    while (lllllllllIIlllI(j, i)) {
      char lllllllllllllllIlllIIIlIIIllllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIlIIIlllIII++;
      j++;
      "".length();
      if ("   ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIlIIIlllIlI);
  }
  
  private static void lllllllllIIlIlI() {
    lIlllllIIllllI = new int[22];
    lIlllllIIllllI[0] = ((0x2D ^ 0x3C) << " ".length() ^ 0x35 ^ 0xE) << " ".length() & (((0x6C ^ 0x59) << " ".length() ^ 0x37 ^ 0x44) << " ".length() ^ -" ".length());
    lIlllllIIllllI[1] = " ".length();
    lIlllllIIllllI[2] = " ".length() << " ".length();
    lIlllllIIllllI[3] = "   ".length();
    lIlllllIIllllI[4] = " ".length() << " ".length() << " ".length();
    lIlllllIIllllI[5] = 0x38 ^ 0x11 ^ (0xAB ^ 0xA0) << " ".length() << " ".length();
    lIlllllIIllllI[6] = 107 + 97 - 126 + 91 ^ (0x3C ^ 0x6F) << " ".length();
    lIlllllIIllllI[7] = ((0x2E ^ 0x3D) << "   ".length() ^ 85 + 154 - 82 + 2) << " ".length();
    lIlllllIIllllI[8] = "   ".length() << " ".length();
    lIlllllIIllllI[9] = 0xB3 ^ 0xBE;
    lIlllllIIllllI[10] = 0x7B ^ 0x7C;
    lIlllllIIllllI[11] = " ".length() << "   ".length();
    lIlllllIIllllI[12] = 0x5C ^ 0x57;
    lIlllllIIllllI[13] = 0x0 ^ 0x51 ^ (0x3E ^ 0x35) << "   ".length();
    lIlllllIIllllI[14] = (0x4C ^ 0x9 ^ " ".length() << "   ".length() << " ".length()) << " ".length();
    lIlllllIIllllI[15] = "   ".length() << " ".length() << " ".length();
    lIlllllIIllllI[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllllIIllllI[17] = 0x62 ^ 0x73;
    lIlllllIIllllI[18] = ((0x57 ^ 0x6A) << " ".length() ^ 0xE9 ^ 0x9A) << " ".length();
    lIlllllIIllllI[19] = 0xD6 ^ 0xC5;
    lIlllllIIllllI[20] = (0x5E ^ 0x5B) << " ".length() << " ".length();
    lIlllllIIllllI[21] = (0x11 ^ 0x32) << " ".length() ^ 0xF3 ^ 0xA0;
  }
  
  private static boolean lllllllllIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllllIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllllIIlIll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ah.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */