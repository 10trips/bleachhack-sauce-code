package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;

public class f1000 extends au {
  private static String[] lIlllIllllIlII;
  
  private static Class[] lIlllIllllIlIl;
  
  private static final String[] lIlllIllllllII;
  
  private static String[] lIlllIllllllIl;
  
  private static final int[] lIlllIlllllllI;
  
  public f1000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000.lIlllIllllllII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000.lIlllIlllllllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000.lIlllIllllllII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000.lIlllIlllllllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000.lIlllIllllllII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000.lIlllIlllllllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000.lIlllIlllllllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIllllIIlIlll	Lme/stupitdog/bhp/f1000;
  }
  
  public static boolean shouldBlock() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)Z
    //   15: ireturn
  }
  
  static {
    llllllIIIlIIllI();
    llllllIIIlIIlIl();
    llllllIIIlIIlII();
    llllllIIIlIIIII();
  }
  
  private static CallSite llllllIIIIIlIII(MethodHandles.Lookup lllllllllllllllIlllIIllllIIIlllI, String lllllllllllllllIlllIIllllIIIllIl, MethodType lllllllllllllllIlllIIllllIIIllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIllllIIlIlII = lIlllIllllIlII[Integer.parseInt(lllllllllllllllIlllIIllllIIIllIl)].split(lIlllIllllllII[lIlllIlllllllI[3]]);
      Class<?> lllllllllllllllIlllIIllllIIlIIll = Class.forName(lllllllllllllllIlllIIllllIIlIlII[lIlllIlllllllI[0]]);
      String lllllllllllllllIlllIIllllIIlIIlI = lllllllllllllllIlllIIllllIIlIlII[lIlllIlllllllI[1]];
      MethodHandle lllllllllllllllIlllIIllllIIlIIIl = null;
      int lllllllllllllllIlllIIllllIIlIIII = lllllllllllllllIlllIIllllIIlIlII[lIlllIlllllllI[3]].length();
      if (llllllIIIlIIlll(lllllllllllllllIlllIIllllIIlIIII, lIlllIlllllllI[2])) {
        MethodType lllllllllllllllIlllIIllllIIlIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIllllIIlIlII[lIlllIlllllllI[2]], f1000.class.getClassLoader());
        if (llllllIIIlIlIII(lllllllllllllllIlllIIllllIIlIIII, lIlllIlllllllI[2])) {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findVirtual(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIllI);
          "".length();
          if (-((0x35 ^ 0x26) << "   ".length() ^ (0x8B ^ 0xAC) << " ".length() << " ".length()) > 0)
            return null; 
        } else {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findStatic(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIllI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() <= " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIllllIIlIlIl = lIlllIllllIlIl[Integer.parseInt(lllllllllllllllIlllIIllllIIlIlII[lIlllIlllllllI[2]])];
        if (llllllIIIlIlIII(lllllllllllllllIlllIIllllIIlIIII, lIlllIlllllllI[3])) {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findGetter(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIlIl);
          "".length();
          if (-" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else if (llllllIIIlIlIII(lllllllllllllllIlllIIllllIIlIIII, lIlllIlllllllI[4])) {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findStaticGetter(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIlIl);
          "".length();
          if (" ".length() <= (((0xDC ^ 0x8B) << " ".length() ^ 168 + 118 - 257 + 148) & ((0x6E ^ 0x63) << " ".length() ^ 0xC6 ^ 0xC3 ^ -" ".length())))
            return null; 
        } else if (llllllIIIlIlIII(lllllllllllllllIlllIIllllIIlIIII, lIlllIlllllllI[5])) {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findSetter(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIlIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIllllIIlIIIl = lllllllllllllllIlllIIllllIIIlllI.findStaticSetter(lllllllllllllllIlllIIllllIIlIIll, lllllllllllllllIlllIIllllIIlIIlI, lllllllllllllllIlllIIllllIIlIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIllllIIlIIIl);
    } catch (Exception lllllllllllllllIlllIIllllIIIllll) {
      lllllllllllllllIlllIIllllIIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIIlIIIII() {
    lIlllIllllIlII = new String[lIlllIlllllllI[4]];
    lIlllIllllIlII[lIlllIlllllllI[2]] = lIlllIllllllII[lIlllIlllllllI[4]];
    lIlllIllllIlII[lIlllIlllllllI[3]] = lIlllIllllllII[lIlllIlllllllI[5]];
    lIlllIllllIlII[lIlllIlllllllI[0]] = lIlllIllllllII[lIlllIlllllllI[6]];
    lIlllIllllIlII[lIlllIlllllllI[1]] = lIlllIllllllII[lIlllIlllllllI[7]];
    lIlllIllllIlIl = new Class[lIlllIlllllllI[4]];
    lIlllIllllIlIl[lIlllIlllllllI[2]] = PlayerControllerMP.class;
    lIlllIllllIlIl[lIlllIlllllllI[1]] = Minecraft.class;
    lIlllIllllIlIl[lIlllIlllllllI[3]] = boolean.class;
    lIlllIllllIlIl[lIlllIlllllllI[0]] = f13.class;
  }
  
  private static void llllllIIIlIIlII() {
    lIlllIllllllII = new String[lIlllIlllllllI[8]];
    lIlllIllllllII[lIlllIlllllllI[0]] = llllllIIIlIIIIl(lIlllIllllllIl[lIlllIlllllllI[0]], lIlllIllllllIl[lIlllIlllllllI[1]]);
    lIlllIllllllII[lIlllIlllllllI[1]] = llllllIIIlIIIIl(lIlllIllllllIl[lIlllIlllllllI[2]], lIlllIllllllIl[lIlllIlllllllI[3]]);
    lIlllIllllllII[lIlllIlllllllI[2]] = llllllIIIlIIIlI(lIlllIllllllIl[lIlllIlllllllI[4]], lIlllIllllllIl[lIlllIlllllllI[5]]);
    lIlllIllllllII[lIlllIlllllllI[3]] = llllllIIIlIIIlI(lIlllIllllllIl[lIlllIlllllllI[6]], lIlllIllllllIl[lIlllIlllllllI[7]]);
    lIlllIllllllII[lIlllIlllllllI[4]] = llllllIIIlIIIll(lIlllIllllllIl[lIlllIlllllllI[8]], lIlllIllllllIl[lIlllIlllllllI[9]]);
    lIlllIllllllII[lIlllIlllllllI[5]] = llllllIIIlIIIll(lIlllIllllllIl[lIlllIlllllllI[10]], lIlllIllllllIl[lIlllIlllllllI[11]]);
    lIlllIllllllII[lIlllIlllllllI[6]] = llllllIIIlIIIll(lIlllIllllllIl[lIlllIlllllllI[12]], lIlllIllllllIl[lIlllIlllllllI[13]]);
    lIlllIllllllII[lIlllIlllllllI[7]] = llllllIIIlIIIIl(lIlllIllllllIl[lIlllIlllllllI[14]], lIlllIllllllIl[lIlllIlllllllI[15]]);
    lIlllIllllllIl = null;
  }
  
  private static void llllllIIIlIIlIl() {
    String str = (new Exception()).getStackTrace()[lIlllIlllllllI[0]].getFileName();
    lIlllIllllllIl = str.substring(str.indexOf("ä") + lIlllIlllllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIIIlIIIIl(String lllllllllllllllIlllIIllllIIIlIlI, String lllllllllllllllIlllIIllllIIIlIIl) {
    lllllllllllllllIlllIIllllIIIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllllIIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIllllIIIlIII = new StringBuilder();
    char[] lllllllllllllllIlllIIllllIIIIlll = lllllllllllllllIlllIIllllIIIlIIl.toCharArray();
    int lllllllllllllllIlllIIllllIIIIllI = lIlllIlllllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIllllIIIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlllllllI[0];
    while (llllllIIIlIlIIl(j, i)) {
      char lllllllllllllllIlllIIllllIIIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIllllIIIIllI++;
      j++;
      "".length();
      if ("   ".length() < " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIllllIIIlIII);
  }
  
  private static String llllllIIIlIIIlI(String lllllllllllllllIlllIIllllIIIIIlI, String lllllllllllllllIlllIIllllIIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllllIIIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllllIIIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIllllIIIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIllllIIIIlII.init(lIlllIlllllllI[2], lllllllllllllllIlllIIllllIIIIlIl);
      return new String(lllllllllllllllIlllIIllllIIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllllIIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllllIIIIIll) {
      lllllllllllllllIlllIIllllIIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIIlIIIll(String lllllllllllllllIlllIIlllIlllllIl, String lllllllllllllllIlllIIlllIlllllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllllIIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlllIlllllII.getBytes(StandardCharsets.UTF_8)), lIlllIlllllllI[8]), "DES");
      Cipher lllllllllllllllIlllIIlllIlllllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlllIlllllll.init(lIlllIlllllllI[2], lllllllllllllllIlllIIllllIIIIIII);
      return new String(lllllllllllllllIlllIIlllIlllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlllIlllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlllIllllllI) {
      lllllllllllllllIlllIIlllIllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIIlIIllI() {
    lIlllIlllllllI = new int[16];
    lIlllIlllllllI[0] = (62 + 38 - 48 + 115 ^ (0x4F ^ 0x1E) << " ".length()) << "   ".length() & ((60 + 37 - 95 + 147 ^ (0x30 ^ 0x39) << " ".length() << " ".length() << " ".length()) << "   ".length() ^ -" ".length());
    lIlllIlllllllI[1] = " ".length();
    lIlllIlllllllI[2] = " ".length() << " ".length();
    lIlllIlllllllI[3] = "   ".length();
    lIlllIlllllllI[4] = " ".length() << " ".length() << " ".length();
    lIlllIlllllllI[5] = 0x95 ^ 0x90;
    lIlllIlllllllI[6] = "   ".length() << " ".length();
    lIlllIlllllllI[7] = 0x7E ^ 0x79;
    lIlllIlllllllI[8] = " ".length() << "   ".length();
    lIlllIlllllllI[9] = 0xA3 ^ 0xAA;
    lIlllIlllllllI[10] = (0x3 ^ 0x6) << " ".length();
    lIlllIlllllllI[11] = 0x10 ^ 0x1B;
    lIlllIlllllllI[12] = "   ".length() << " ".length() << " ".length();
    lIlllIlllllllI[13] = (0x85 ^ 0xA6) << " ".length() ^ 0xEE ^ 0xA5;
    lIlllIlllllllI[14] = (0xC0 ^ 0xC7) << " ".length();
    lIlllIlllllllI[15] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x20 ^ 0x1F;
  }
  
  private static boolean llllllIIIlIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIIIlIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIIIlIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */