/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.f10000000000000;
/*    */ import me.stupitdog.bhp.f100000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.entity.MoverType;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({EntityPlayerSP.class})
/*    */ public abstract class MixinEntityPlayerSP
/*    */   extends AbstractClientPlayer
/*    */ {
/*    */   public MixinEntityPlayerSP() {
/* 20 */     super(null, null);
/*    */   }
/*    */   
/*    */   @Redirect(method = {"move"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"))
/*    */   public void move(AbstractClientPlayer player, MoverType type, double x, double y, double z) {
/* 25 */     f10000000000000 moveEvent = new f10000000000000(type, x, y, z);
/* 26 */     f9.EVENT_BUS.post(moveEvent);
/* 27 */     func_70091_d(type, moveEvent.x, moveEvent.y, moveEvent.z);
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"onUpdate"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onUpdate(CallbackInfo p_Info) {
/* 33 */     f100000000000000 event = new f100000000000000();
/* 34 */     f9.EVENT_BUS.post(event);
/* 35 */     if (event.isCancelled())
/* 36 */       p_Info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinEntityPlayerSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */