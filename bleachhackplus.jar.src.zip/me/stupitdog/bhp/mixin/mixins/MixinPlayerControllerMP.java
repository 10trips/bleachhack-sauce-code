/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.f1000000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import me.stupitdog.bhp.fm;
/*    */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({PlayerControllerMP.class})
/*    */ public abstract class MixinPlayerControllerMP
/*    */ {
/*    */   @Inject(method = {"resetBlockRemoving"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void resetBlock(CallbackInfo callbackInfo) {
/* 20 */     if (f9.instance.moduleManager.getModule("MultiTask").isToggled()) {
/* 21 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"getBlockReachDistance"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private void getReachDistanceHook(CallbackInfoReturnable<Float> distance) {
/* 27 */     if (f9.instance.moduleManager.getModule("Reach").isToggled()) {
/* 28 */       distance.setReturnValue(Float.valueOf((float)f1000000000000000.reach.getValue()));
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"onPlayerDamageBlock(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Z"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
/* 34 */     fm event = new fm(posBlock, directionFacing);
/* 35 */     f9.EVENT_BUS.post(event);
/* 36 */     if (event.isCancelled())
/* 37 */       callbackInfoReturnable.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinPlayerControllerMP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */