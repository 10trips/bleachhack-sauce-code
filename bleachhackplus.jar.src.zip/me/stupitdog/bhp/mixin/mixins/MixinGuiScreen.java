/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.annotation.Nonnull;
/*    */ import me.stupitdog.bhp.f10000000000000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ @Mixin({GuiScreen.class})
/*    */ public class MixinGuiScreen {
/*    */   @Shadow
/*    */   public Minecraft field_146297_k;
/*    */   @Shadow
/*    */   public int field_146294_l;
/*    */   @Shadow
/*    */   protected List<GuiButton> field_146292_n;
/*    */   
/*    */   @Shadow
/*    */   protected <T extends GuiButton> T func_189646_b(T buttonIn) {
/* 31 */     this.field_146292_n.add((GuiButton)buttonIn);
/* 32 */     return buttonIn;
/*    */   }
/*    */   
/*    */   @Inject(method = {"sendChatMessage(Ljava/lang/String;Z)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onChat(String msg, boolean addToChat, @Nonnull CallbackInfo ci) {
/* 37 */     if (msg.startsWith(".") && msg.length() > 1) {
/* 38 */       ci.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderToolTip"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderToolTip(ItemStack stack, int x, int y, CallbackInfo callbackInfo) {
/* 44 */     if (f9.instance.moduleManager.getModule("ShulkerView").isToggled() && stack.func_77973_b() instanceof net.minecraft.item.ItemShulkerBox && 
/* 45 */       stack.func_77978_p() != null && stack.func_77978_p().func_150297_b("BlockEntityTag", 10) && 
/* 46 */       stack.func_77978_p().func_74775_l("BlockEntityTag").func_150297_b("Items", 9)) {
/* 47 */       callbackInfo.cancel();
/* 48 */       f10000000000000000000000.renderShulkerPreview(stack, x + 6, y - 33, 162, 66);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinGuiScreen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */