package me.stupitdog.bhp.mixin.mixins;

import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({Entity.class})
public abstract class MixinEntity {
  @Shadow
  public double field_70165_t;
  
  @Shadow
  public double field_70163_u;
  
  @Shadow
  public double field_70161_v;
  
  @Shadow
  public double field_70169_q;
  
  @Shadow
  public double field_70167_r;
  
  @Shadow
  public double field_70166_s;
  
  @Shadow
  public double field_70142_S;
  
  @Shadow
  public double field_70137_T;
  
  @Shadow
  public double field_70136_U;
  
  @Shadow
  public float field_70126_B;
  
  @Shadow
  public float field_70127_C;
  
  @Shadow
  public float field_70125_A;
  
  @Shadow
  public float field_70177_z;
  
  @Shadow
  public boolean field_70122_E;
  
  @Shadow
  public double field_70159_w;
  
  @Shadow
  public double field_70181_x;
  
  @Shadow
  public double field_70179_y;
  
  @Shadow
  public abstract boolean equals(Object paramObject);
  
  @Shadow
  public abstract boolean func_70051_ag();
  
  @Shadow
  public abstract boolean func_184218_aH();
  
  @Shadow
  public void func_70091_d(MoverType type, double x, double y, double z) {}
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */