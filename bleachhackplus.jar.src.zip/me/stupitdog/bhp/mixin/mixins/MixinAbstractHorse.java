/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.al;
/*    */ import me.stupitdog.bhp.f10000000000000000000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.entity.passive.AbstractHorse;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({AbstractHorse.class})
/*    */ public class MixinAbstractHorse
/*    */ {
/*    */   @Inject(method = {"canBeSteered"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void canBeSteered(CallbackInfoReturnable<Boolean> cir) {
/* 19 */     f10000000000000000000000000000 l_Event = new f10000000000000000000000000000();
/* 20 */     f9.EVENT_BUS.post(l_Event);
/*    */     
/* 22 */     if (l_Event.isCancelled()) {
/*    */       
/* 24 */       cir.cancel();
/* 25 */       cir.setReturnValue(Boolean.valueOf(true));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"isHorseSaddled"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void isHorseSaddled(CallbackInfoReturnable<Boolean> cir) {
/* 32 */     al l_Event = new al();
/* 33 */     f9.EVENT_BUS.post(l_Event);
/*    */     
/* 35 */     if (l_Event.isCancelled()) {
/*    */       
/* 37 */       cir.cancel();
/* 38 */       cir.setReturnValue(Boolean.valueOf(true));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinAbstractHorse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */