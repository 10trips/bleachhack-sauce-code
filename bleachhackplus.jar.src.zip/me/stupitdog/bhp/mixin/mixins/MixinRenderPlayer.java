/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.f10000000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.entity.RenderPlayer;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderPlayer.class})
/*    */ public class MixinRenderPlayer
/*    */ {
/*    */   @Inject(method = {"renderEntityName"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderLivingLabel(AbstractClientPlayer entityIn, double x, double y, double z, String name, double distanceSq, CallbackInfo info) {
/* 19 */     f10000000000000000 eventRenderName = new f10000000000000000(entityIn, x, y, z, name, distanceSq);
/*    */     
/* 21 */     f9.EVENT_BUS.post(eventRenderName);
/*    */     
/* 23 */     if (eventRenderName.isCancelled())
/* 24 */       info.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinRenderPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */