/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.f10000000000000000000000000000;
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.entity.passive.EntityLlama;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({EntityLlama.class})
/*    */ public class MixinEntityLlama
/*    */ {
/*    */   @Inject(method = {"canBeSteered"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void canBeSteered(CallbackInfoReturnable<Boolean> cir) {
/* 18 */     f10000000000000000000000000000 event = new f10000000000000000000000000000();
/* 19 */     f9.EVENT_BUS.post(event);
/*    */     
/* 21 */     if (event.isCancelled()) {
/*    */       
/* 23 */       cir.cancel();
/* 24 */       cir.setReturnValue(Boolean.valueOf(true));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinEntityLlama.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */