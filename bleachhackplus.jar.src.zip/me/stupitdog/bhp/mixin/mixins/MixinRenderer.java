package me.stupitdog.bhp.mixin.mixins;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({Render.class})
abstract class MixinRenderer<T extends Entity> {
  @Shadow
  protected abstract boolean func_180548_c(T paramT);
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */