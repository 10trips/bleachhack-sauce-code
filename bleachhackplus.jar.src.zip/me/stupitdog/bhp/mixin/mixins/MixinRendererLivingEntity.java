/*     */ package me.stupitdog.bhp.mixin.mixins;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import me.stupitdog.bhp.f10000000000;
/*     */ import me.stupitdog.bhp.f9;
/*     */ import me.stupitdog.bhp.fr;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Overwrite;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({RenderLivingBase.class})
/*     */ public abstract class MixinRendererLivingEntity<T extends EntityLivingBase>
/*     */   extends MixinRenderer<T>
/*     */ {
/*     */   @Shadow
/*     */   protected ModelBase field_77045_g;
/*     */   
/*     */   @Inject(method = {"doRender"}, at = {@At("HEAD")})
/*     */   private <T extends EntityLivingBase> void injectChamsPre(T a, double b, double c, double d, float e, float f, CallbackInfo g) {
/*  37 */     if (f9.instance.moduleManager.getModule("Chams") != null && f9.instance.moduleManager.getModule("Chams").isToggled()) {
/*  38 */       GL11.glEnable(32823);
/*  39 */       GL11.glPolygonOffset(1.0F, -1000000.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Inject(method = {"doRender"}, at = {@At("RETURN")})
/*     */   private <T extends EntityLivingBase> void injectChamsPost(T a, double b, double c, double d, float e, float f, CallbackInfo g) {
/*  45 */     if (f9.instance.moduleManager.getModule("Chams") != null && f9.instance.moduleManager.getModule("Chams").isToggled()) {
/*  46 */       GL11.glPolygonOffset(1.0F, 1000000.0F);
/*  47 */       GL11.glDisable(32823);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Overwrite
/*     */   protected void func_77036_a(T entitylivingbaseIn, float p_77036_2_, float p_77036_3_, float p_77036_4_, float p_77036_5_, float p_77036_6_, float scaleFactor) {
/*  53 */     boolean flag = !entitylivingbaseIn.func_82150_aj();
/*  54 */     boolean flag1 = (!flag && !entitylivingbaseIn.func_98034_c((EntityPlayer)(Minecraft.func_71410_x()).field_71439_g));
/*     */     
/*  56 */     if (flag || flag1) {
/*  57 */       if (!func_180548_c(entitylivingbaseIn)) {
/*     */         return;
/*     */       }
/*     */       
/*  61 */       if (flag1) {
/*  62 */         GlStateManager.func_179094_E();
/*  63 */         GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 0.15F);
/*  64 */         GlStateManager.func_179132_a(false);
/*  65 */         GlStateManager.func_179147_l();
/*  66 */         GlStateManager.func_179112_b(770, 771);
/*  67 */         GlStateManager.func_179092_a(516, 0.003921569F);
/*     */       } 
/*     */       
/*  70 */       if (f9.instance.moduleManager.getModule("ESP") != null && f9.instance.moduleManager.getModule("ESP").isToggled() && fr.mode.getValue().equalsIgnoreCase("Outline")) {
/*  71 */         if (entitylivingbaseIn instanceof EntityPlayer && entitylivingbaseIn != (Minecraft.func_71410_x()).field_71439_g && fr.player.getValue()) {
/*  72 */           Color n = new Color(fr.plrColor.getValue().getRGB());
/*  73 */           f10000000000.setColor(n);
/*  74 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  75 */           f10000000000.renderOne();
/*  76 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  77 */           f10000000000.renderTwo();
/*  78 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  79 */           f10000000000.renderThree();
/*  80 */           f10000000000.renderFour();
/*  81 */           f10000000000.setColor(n);
/*  82 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  83 */           f10000000000.renderFive();
/*  84 */           f10000000000.setColor(Color.WHITE);
/*     */         } 
/*  86 */         if (entitylivingbaseIn instanceof net.minecraft.entity.passive.EntityAnimal && entitylivingbaseIn != (Minecraft.func_71410_x()).field_71439_g && fr.animal.getValue()) {
/*  87 */           Color n = new Color(fr.animalColor.getValue().getRGB());
/*  88 */           f10000000000.setColor(n);
/*  89 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  90 */           f10000000000.renderOne();
/*  91 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  92 */           f10000000000.renderTwo();
/*  93 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  94 */           f10000000000.renderThree();
/*  95 */           f10000000000.renderFour();
/*  96 */           f10000000000.setColor(n);
/*  97 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*  98 */           f10000000000.renderFive();
/*  99 */           f10000000000.setColor(Color.WHITE);
/*     */         } 
/* 101 */         if (entitylivingbaseIn instanceof net.minecraft.entity.monster.EntityMob && entitylivingbaseIn != (Minecraft.func_71410_x()).field_71439_g && fr.mob.getValue()) {
/* 102 */           Color n = new Color(fr.mobColor.getValue().getRGB());
/* 103 */           f10000000000.setColor(n);
/* 104 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 105 */           f10000000000.renderOne();
/* 106 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 107 */           f10000000000.renderTwo();
/* 108 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 109 */           f10000000000.renderThree();
/* 110 */           f10000000000.renderFour();
/* 111 */           f10000000000.setColor(n);
/* 112 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 113 */           f10000000000.renderFive();
/* 114 */           f10000000000.setColor(Color.WHITE);
/*     */         } 
/* 116 */         if (entitylivingbaseIn instanceof net.minecraft.entity.passive.AbstractHorse && entitylivingbaseIn != (Minecraft.func_71410_x()).field_71439_g && fr.donkey.getValue()) {
/* 117 */           Color n = new Color(fr.donkeyColor.getValue().getRGB());
/* 118 */           f10000000000.setColor(n);
/* 119 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 120 */           f10000000000.renderOne();
/* 121 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 122 */           f10000000000.renderTwo();
/* 123 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 124 */           f10000000000.renderThree();
/* 125 */           f10000000000.renderFour();
/* 126 */           f10000000000.setColor(n);
/* 127 */           this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/* 128 */           f10000000000.renderFive();
/* 129 */           f10000000000.setColor(Color.WHITE);
/*     */         } 
/*     */       } 
/* 132 */       this.field_77045_g.func_78088_a((Entity)entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
/*     */       
/* 134 */       if (flag1) {
/* 135 */         GlStateManager.func_179084_k();
/* 136 */         GlStateManager.func_179092_a(516, 0.1F);
/* 137 */         GlStateManager.func_179121_F();
/* 138 */         GlStateManager.func_179132_a(true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinRendererLivingEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */