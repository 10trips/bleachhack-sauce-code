/*    */ package me.stupitdog.bhp.mixin.mixins;
/*    */ 
/*    */ import me.stupitdog.bhp.f9;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.util.MovementInput;
/*    */ import net.minecraft.util.MovementInputFromOptions;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ @Mixin(value = {MovementInputFromOptions.class}, priority = 10000)
/*    */ public abstract class MixinMovementInputFromOptions
/*    */   extends MovementInput
/*    */ {
/*    */   @Redirect(method = {"updatePlayerMoveState"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/settings/KeyBinding;isKeyDown()Z"))
/*    */   public boolean isKeyPressed(KeyBinding keyBinding) {
/* 20 */     if (f9.instance.moduleManager.getModule("GuiMove").isToggled() && 
/* 21 */       (Minecraft.func_71410_x()).field_71462_r != null && 
/* 22 */       !((Minecraft.func_71410_x()).field_71462_r instanceof net.minecraft.client.gui.GuiChat) && 
/* 23 */       (Minecraft.func_71410_x()).field_71439_g != null) {
/* 24 */       return Keyboard.isKeyDown(keyBinding.func_151463_i());
/*    */     }
/* 26 */     return keyBinding.func_151470_d();
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\mixins\MixinMovementInputFromOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */