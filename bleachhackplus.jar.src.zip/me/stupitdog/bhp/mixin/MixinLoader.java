/*    */ package me.stupitdog.bhp.mixin;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
/*    */ import org.spongepowered.asm.launch.MixinBootstrap;
/*    */ import org.spongepowered.asm.mixin.Mixins;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MixinLoader
/*    */   implements IFMLLoadingPlugin
/*    */ {
/*    */   public MixinLoader() {
/* 15 */     MixinBootstrap.init();
/* 16 */     Mixins.addConfiguration("mixins.bhp.json");
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getASMTransformerClass() {
/* 21 */     return new String[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModContainerClass() {
/* 26 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getSetupClass() {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void injectData(Map<String, Object> data) {}
/*    */ 
/*    */   
/*    */   public String getAccessTransformerClass() {
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\mixin\MixinLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */