package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f100000000 extends au {
  public static String lastNotification;
  
  private static String[] lIllllIlllIIlI;
  
  private static Class[] lIllllIlllIIll;
  
  private static final String[] lIllllIlllIlII;
  
  private static String[] lIllllIlllIlIl;
  
  private static final int[] lIllllIlllIllI;
  
  public f100000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIlII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIlII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f100000000.lIllllIlllIllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIlIIIIIIIIIl	Lme/stupitdog/bhp/f100000000;
  }
  
  static {
    lllllllIllIIIII();
    lllllllIlIlllll();
    lllllllIlIllllI();
    lllllllIlIllIlI();
  }
  
  private static CallSite lllllllIlIllIIl(MethodHandles.Lookup lllllllllllllllIlllIIIlllllllIII, String lllllllllllllllIlllIIIllllllIlll, MethodType lllllllllllllllIlllIIIllllllIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIlllllllllI = lIllllIlllIIlI[Integer.parseInt(lllllllllllllllIlllIIIllllllIlll)].split(lIllllIlllIlII[lIllllIlllIllI[3]]);
      Class<?> lllllllllllllllIlllIIIllllllllIl = Class.forName(lllllllllllllllIlllIIIlllllllllI[lIllllIlllIllI[0]]);
      String lllllllllllllllIlllIIIllllllllII = lllllllllllllllIlllIIIlllllllllI[lIllllIlllIllI[1]];
      MethodHandle lllllllllllllllIlllIIIlllllllIll = null;
      int lllllllllllllllIlllIIIlllllllIlI = lllllllllllllllIlllIIIlllllllllI[lIllllIlllIllI[3]].length();
      if (lllllllIllIIIIl(lllllllllllllllIlllIIIlllllllIlI, lIllllIlllIllI[2])) {
        MethodType lllllllllllllllIlllIIlIIIIIIIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIlllllllllI[lIllllIlllIllI[2]], f100000000.class.getClassLoader());
        if (lllllllIllIIIlI(lllllllllllllllIlllIIIlllllllIlI, lIllllIlllIllI[2])) {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findVirtual(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIlIIIIIIIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findStatic(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIlIIIIIIIIII);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() == " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIllllllllll = lIllllIlllIIll[Integer.parseInt(lllllllllllllllIlllIIIlllllllllI[lIllllIlllIllI[2]])];
        if (lllllllIllIIIlI(lllllllllllllllIlllIIIlllllllIlI, lIllllIlllIllI[3])) {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findGetter(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIIllllllllll);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (lllllllIllIIIlI(lllllllllllllllIlllIIIlllllllIlI, lIllllIlllIllI[4])) {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findStaticGetter(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIIllllllllll);
          "".length();
          if ((((0xB5 ^ 0x84) << " ".length() ^ " ".length()) & ((0x31 ^ 0xE) << " ".length() << " ".length() ^ 72 + 75 - 14 + 26 ^ -" ".length())) != ((0x17 ^ 0x5E ^ (0x47 ^ 0x60) << " ".length()) << "   ".length() & ((29 + 100 - 107 + 163 ^ (0x28 ^ 0x77) << " ".length()) << "   ".length() ^ -" ".length())))
            return null; 
        } else if (lllllllIllIIIlI(lllllllllllllllIlllIIIlllllllIlI, lIllllIlllIllI[5])) {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findSetter(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIIllllllllll);
          "".length();
          if (-" ".length() > ((0x1B ^ 0x6C ^ (0x20 ^ 0x27) << " ".length() << " ".length() << " ".length()) & (49 + 27 - 58 + 165 ^ (0x77 ^ 0x7C) << " ".length() << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIlllIIIlllllllIll = lllllllllllllllIlllIIIlllllllIII.findStaticSetter(lllllllllllllllIlllIIIllllllllIl, lllllllllllllllIlllIIIllllllllII, lllllllllllllllIlllIIIllllllllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIlllllllIll);
    } catch (Exception lllllllllllllllIlllIIIlllllllIIl) {
      lllllllllllllllIlllIIIlllllllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIlIllIlI() {
    lIllllIlllIIlI = new String[lIllllIlllIllI[1]];
    lIllllIlllIIlI[lIllllIlllIllI[0]] = lIllllIlllIlII[lIllllIlllIllI[4]];
    lIllllIlllIIll = new Class[lIllllIlllIllI[1]];
    lIllllIlllIIll[lIllllIlllIllI[0]] = f13.class;
  }
  
  private static void lllllllIlIllllI() {
    lIllllIlllIlII = new String[lIllllIlllIllI[5]];
    lIllllIlllIlII[lIllllIlllIllI[0]] = lllllllIlIllIll(lIllllIlllIlIl[lIllllIlllIllI[0]], lIllllIlllIlIl[lIllllIlllIllI[1]]);
    lIllllIlllIlII[lIllllIlllIllI[1]] = lllllllIlIlllII(lIllllIlllIlIl[lIllllIlllIllI[2]], lIllllIlllIlIl[lIllllIlllIllI[3]]);
    lIllllIlllIlII[lIllllIlllIllI[2]] = lllllllIlIlllII(lIllllIlllIlIl[lIllllIlllIllI[4]], lIllllIlllIlIl[lIllllIlllIllI[5]]);
    lIllllIlllIlII[lIllllIlllIllI[3]] = lllllllIlIlllIl(lIllllIlllIlIl[lIllllIlllIllI[6]], lIllllIlllIlIl[lIllllIlllIllI[7]]);
    lIllllIlllIlII[lIllllIlllIllI[4]] = lllllllIlIlllIl(lIllllIlllIlIl[lIllllIlllIllI[8]], lIllllIlllIlIl[lIllllIlllIllI[9]]);
    lIllllIlllIlIl = null;
  }
  
  private static void lllllllIlIlllll() {
    String str = (new Exception()).getStackTrace()[lIllllIlllIllI[0]].getFileName();
    lIllllIlllIlIl = str.substring(str.indexOf("ä") + lIllllIlllIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIlIlllIl(String lllllllllllllllIlllIIIllllllIIlI, String lllllllllllllllIlllIIIllllllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllllllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllllllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIllllllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIllllllIlII.init(lIllllIlllIllI[2], lllllllllllllllIlllIIIllllllIlIl);
      return new String(lllllllllllllllIlllIIIllllllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllllllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllllllIIll) {
      lllllllllllllllIlllIIIllllllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIlIllIll(String lllllllllllllllIlllIIIlllllIllIl, String lllllllllllllllIlllIIIlllllIllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllllllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlllllIllII.getBytes(StandardCharsets.UTF_8)), lIllllIlllIllI[8]), "DES");
      Cipher lllllllllllllllIlllIIIlllllIllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIlllllIllll.init(lIllllIlllIllI[2], lllllllllllllllIlllIIIllllllIIII);
      return new String(lllllllllllllllIlllIIIlllllIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlllllIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlllllIlllI) {
      lllllllllllllllIlllIIIlllllIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIlIlllII(String lllllllllllllllIlllIIIlllllIlIlI, String lllllllllllllllIlllIIIlllllIlIIl) {
    lllllllllllllllIlllIIIlllllIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIlllllIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIlllllIlIII = new StringBuilder();
    char[] lllllllllllllllIlllIIIlllllIIlll = lllllllllllllllIlllIIIlllllIlIIl.toCharArray();
    int lllllllllllllllIlllIIIlllllIIllI = lIllllIlllIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIlllllIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlllIllI[0];
    while (lllllllIllIIIll(j, i)) {
      char lllllllllllllllIlllIIIlllllIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIlllllIIllI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIlllllIlIII);
  }
  
  private static void lllllllIllIIIII() {
    lIllllIlllIllI = new int[10];
    lIllllIlllIllI[0] = (0x9F ^ 0xC6) & (0x4 ^ 0x5D ^ 0xFFFFFFFF);
    lIllllIlllIllI[1] = " ".length();
    lIllllIlllIllI[2] = " ".length() << " ".length();
    lIllllIlllIllI[3] = "   ".length();
    lIllllIlllIllI[4] = " ".length() << " ".length() << " ".length();
    lIllllIlllIllI[5] = 0x3C ^ 0x39;
    lIllllIlllIllI[6] = "   ".length() << " ".length();
    lIllllIlllIllI[7] = 0x77 ^ 0x70;
    lIllllIlllIllI[8] = " ".length() << "   ".length();
    lIllllIlllIllI[9] = 78 + 111 - 92 + 70 ^ (0x52 ^ 0x5) << " ".length();
  }
  
  private static boolean lllllllIllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIllIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */