package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;
import net.minecraft.util.math.Vec3d;

public class fq {
  private static final Minecraft mc;
  
  private static final Map<String, String> uuidNameCache;
  
  private static String[] lIllIllIIlIllI;
  
  private static Class[] lIllIllIIlIlll;
  
  private static final String[] lIlllIIlIllIlI;
  
  private static String[] lIlllIIlIlllIl;
  
  private static final int[] lIlllIIlIllllI;
  
  public static boolean isPassive(Entity lllllllllllllllIlllIllIlllIllIll) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof net/minecraft/entity/passive/EntityWolf
    //   4: invokestatic lllllIIIllIIIIl : (I)Z
    //   7: ifeq -> 31
    //   10: aload_0
    //   11: checkcast net/minecraft/entity/passive/EntityWolf
    //   14: <illegal opcode> 0 : (Lnet/minecraft/entity/passive/EntityWolf;)Z
    //   19: invokestatic lllllIIIllIIIIl : (I)Z
    //   22: ifeq -> 31
    //   25: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   28: iconst_0
    //   29: iaload
    //   30: ireturn
    //   31: aload_0
    //   32: instanceof net/minecraft/entity/passive/EntityAnimal
    //   35: invokestatic lllllIIIllIIIlI : (I)Z
    //   38: ifeq -> 81
    //   41: aload_0
    //   42: instanceof net/minecraft/entity/EntityAgeable
    //   45: invokestatic lllllIIIllIIIlI : (I)Z
    //   48: ifeq -> 81
    //   51: aload_0
    //   52: instanceof net/minecraft/entity/passive/EntityTameable
    //   55: invokestatic lllllIIIllIIIlI : (I)Z
    //   58: ifeq -> 81
    //   61: aload_0
    //   62: instanceof net/minecraft/entity/passive/EntityAmbientCreature
    //   65: invokestatic lllllIIIllIIIlI : (I)Z
    //   68: ifeq -> 81
    //   71: aload_0
    //   72: instanceof net/minecraft/entity/passive/EntitySquid
    //   75: invokestatic lllllIIIllIIIIl : (I)Z
    //   78: ifeq -> 87
    //   81: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   84: iconst_1
    //   85: iaload
    //   86: ireturn
    //   87: aload_0
    //   88: instanceof net/minecraft/entity/monster/EntityIronGolem
    //   91: invokestatic lllllIIIllIIIIl : (I)Z
    //   94: ifeq -> 162
    //   97: aload_0
    //   98: checkcast net/minecraft/entity/monster/EntityIronGolem
    //   101: <illegal opcode> 1 : (Lnet/minecraft/entity/monster/EntityIronGolem;)Lnet/minecraft/entity/EntityLivingBase;
    //   106: invokestatic lllllIIIllIIIll : (Ljava/lang/Object;)Z
    //   109: ifeq -> 162
    //   112: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   115: iconst_1
    //   116: iaload
    //   117: ldc ''
    //   119: invokevirtual length : ()I
    //   122: pop
    //   123: ldc ' '
    //   125: invokevirtual length : ()I
    //   128: ldc ' '
    //   130: invokevirtual length : ()I
    //   133: ldc ' '
    //   135: invokevirtual length : ()I
    //   138: ishl
    //   139: ishl
    //   140: ldc ' '
    //   142: invokevirtual length : ()I
    //   145: ineg
    //   146: if_icmpge -> 167
    //   149: bipush #76
    //   151: bipush #87
    //   153: ixor
    //   154: iconst_3
    //   155: bipush #24
    //   157: ixor
    //   158: iconst_m1
    //   159: ixor
    //   160: iand
    //   161: ireturn
    //   162: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   165: iconst_0
    //   166: iaload
    //   167: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	168	0	lllllllllllllllIlllIllIlllIllIll	Lnet/minecraft/entity/Entity;
  }
  
  public static boolean isLiving(Entity lllllllllllllllIlllIllIlllIllIlI) {
    return lllllllllllllllIlllIllIlllIllIlI instanceof EntityLivingBase;
  }
  
  public static boolean isFakeLocalPlayer(Entity lllllllllllllllIlllIllIlllIllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   4: ifeq -> 161
    //   7: aload_0
    //   8: <illegal opcode> 2 : (Lnet/minecraft/entity/Entity;)I
    //   13: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   16: iconst_2
    //   17: iaload
    //   18: invokestatic lllllIIIllIIlIl : (II)Z
    //   21: ifeq -> 161
    //   24: <illegal opcode> 3 : ()Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: aload_0
    //   30: invokestatic lllllIIIllIIllI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   33: ifeq -> 161
    //   36: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   39: iconst_1
    //   40: iaload
    //   41: ldc ''
    //   43: invokevirtual length : ()I
    //   46: pop
    //   47: bipush #13
    //   49: bipush #8
    //   51: ixor
    //   52: ldc ' '
    //   54: invokevirtual length : ()I
    //   57: ldc ' '
    //   59: invokevirtual length : ()I
    //   62: ldc ' '
    //   64: invokevirtual length : ()I
    //   67: ishl
    //   68: ishl
    //   69: ishl
    //   70: sipush #249
    //   73: sipush #160
    //   76: ixor
    //   77: ixor
    //   78: bipush #11
    //   80: bipush #60
    //   82: ixor
    //   83: bipush #55
    //   85: bipush #40
    //   87: ixor
    //   88: ldc ' '
    //   90: invokevirtual length : ()I
    //   93: ishl
    //   94: ixor
    //   95: ldc ' '
    //   97: invokevirtual length : ()I
    //   100: ineg
    //   101: ixor
    //   102: iand
    //   103: ldc '   '
    //   105: invokevirtual length : ()I
    //   108: if_icmple -> 166
    //   111: bipush #32
    //   113: bipush #75
    //   115: ixor
    //   116: bipush #112
    //   118: bipush #103
    //   120: ixor
    //   121: ldc ' '
    //   123: invokevirtual length : ()I
    //   126: ldc ' '
    //   128: invokevirtual length : ()I
    //   131: ishl
    //   132: ishl
    //   133: ixor
    //   134: bipush #78
    //   136: iconst_3
    //   137: ixor
    //   138: sipush #248
    //   141: sipush #197
    //   144: ixor
    //   145: ldc ' '
    //   147: invokevirtual length : ()I
    //   150: ishl
    //   151: ixor
    //   152: ldc ' '
    //   154: invokevirtual length : ()I
    //   157: ineg
    //   158: ixor
    //   159: iand
    //   160: ireturn
    //   161: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   164: iconst_0
    //   165: iaload
    //   166: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	167	0	lllllllllllllllIlllIllIlllIllIIl	Lnet/minecraft/entity/Entity;
  }
  
  public static Vec3d getInterpolatedAmount(Entity lllllllllllllllIlllIllIlllIllIII, double lllllllllllllllIlllIllIlllIlIlll, double lllllllllllllllIlllIllIlllIlIllI, double lllllllllllllllIlllIllIlllIlIlIl) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   10: aload_0
    //   11: <illegal opcode> 5 : (Lnet/minecraft/entity/Entity;)D
    //   16: dsub
    //   17: dload_1
    //   18: dmul
    //   19: aload_0
    //   20: <illegal opcode> 6 : (Lnet/minecraft/entity/Entity;)D
    //   25: aload_0
    //   26: <illegal opcode> 7 : (Lnet/minecraft/entity/Entity;)D
    //   31: dsub
    //   32: dload_3
    //   33: dmul
    //   34: aload_0
    //   35: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   40: aload_0
    //   41: <illegal opcode> 9 : (Lnet/minecraft/entity/Entity;)D
    //   46: dsub
    //   47: dload #5
    //   49: dmul
    //   50: invokespecial <init> : (DDD)V
    //   53: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	54	0	lllllllllllllllIlllIllIlllIllIII	Lnet/minecraft/entity/Entity;
    //   0	54	1	lllllllllllllllIlllIllIlllIlIlll	D
    //   0	54	3	lllllllllllllllIlllIllIlllIlIllI	D
    //   0	54	5	lllllllllllllllIlllIllIlllIlIlIl	D
  }
  
  public static Vec3d getInterpolatedRenderPos(Entity lllllllllllllllIlllIllIlllIlIlII, float lllllllllllllllIlllIllIlllIlIIll) {
    // Byte code:
    //   0: aload_0
    //   1: fload_1
    //   2: <illegal opcode> 10 : (Lnet/minecraft/entity/Entity;F)Lnet/minecraft/util/math/Vec3d;
    //   7: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   12: <illegal opcode> 12 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   17: <illegal opcode> 13 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   22: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   27: <illegal opcode> 12 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   32: <illegal opcode> 14 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   37: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   42: <illegal opcode> 12 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   47: <illegal opcode> 15 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   52: <illegal opcode> 16 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   57: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	58	0	lllllllllllllllIlllIllIlllIlIlII	Lnet/minecraft/entity/Entity;
    //   0	58	1	lllllllllllllllIlllIllIlllIlIIll	F
  }
  
  public static String getNameFromUUID(String lllllllllllllllIlllIllIlllIlIIII) {
    // Byte code:
    //   0: new java/net/URL
    //   3: dup
    //   4: new java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial <init> : ()V
    //   11: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   17: iconst_0
    //   18: iaload
    //   19: aaload
    //   20: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: aload_0
    //   26: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   29: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   32: iconst_1
    //   33: iaload
    //   34: aaload
    //   35: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   38: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   41: iconst_3
    //   42: iaload
    //   43: aaload
    //   44: <illegal opcode> 18 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   49: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   57: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   60: iconst_4
    //   61: iaload
    //   62: aaload
    //   63: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: <illegal opcode> 19 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: <illegal opcode> 20 : (Ljava/net/URL;)Ljava/lang/String;
    //   81: astore_1
    //   82: new com/google/gson/JsonParser
    //   85: dup
    //   86: invokespecial <init> : ()V
    //   89: astore_2
    //   90: aload_2
    //   91: aload_1
    //   92: <illegal opcode> 21 : (Lcom/google/gson/JsonParser;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   97: <illegal opcode> 22 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonArray;
    //   102: aload_2
    //   103: aload_1
    //   104: <illegal opcode> 21 : (Lcom/google/gson/JsonParser;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   109: <illegal opcode> 22 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonArray;
    //   114: <illegal opcode> 23 : (Lcom/google/gson/JsonArray;)I
    //   119: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   122: iconst_1
    //   123: iaload
    //   124: isub
    //   125: <illegal opcode> 24 : (Lcom/google/gson/JsonArray;I)Lcom/google/gson/JsonElement;
    //   130: <illegal opcode> 25 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonObject;
    //   135: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   138: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   141: iconst_5
    //   142: iaload
    //   143: aaload
    //   144: <illegal opcode> 26 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   149: <illegal opcode> 27 : (Lcom/google/gson/JsonElement;)Ljava/lang/String;
    //   154: areturn
    //   155: astore_1
    //   156: aconst_null
    //   157: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   82	73	1	lllllllllllllllIlllIllIlllIlIIlI	Ljava/lang/String;
    //   90	65	2	lllllllllllllllIlllIllIlllIlIIIl	Lcom/google/gson/JsonParser;
    //   0	158	0	lllllllllllllllIlllIllIlllIlIIII	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   0	154	155	java/io/IOException
  }
  
  public static String resolveName(String lllllllllllllllIlllIllIlllIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   7: bipush #6
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   17: bipush #7
    //   19: iaload
    //   20: aaload
    //   21: <illegal opcode> 18 : (Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   26: astore_0
    //   27: <illegal opcode> 28 : ()Ljava/util/Map;
    //   32: aload_0
    //   33: <illegal opcode> 29 : (Ljava/util/Map;Ljava/lang/Object;)Z
    //   38: invokestatic lllllIIIllIIIIl : (I)Z
    //   41: ifeq -> 59
    //   44: <illegal opcode> 28 : ()Ljava/util/Map;
    //   49: aload_0
    //   50: <illegal opcode> 30 : (Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: areturn
    //   59: new java/lang/StringBuilder
    //   62: dup
    //   63: invokespecial <init> : ()V
    //   66: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   69: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   72: bipush #8
    //   74: iaload
    //   75: aaload
    //   76: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: aload_0
    //   82: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   90: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   93: bipush #9
    //   95: iaload
    //   96: aaload
    //   97: <illegal opcode> 17 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: <illegal opcode> 19 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   107: astore_1
    //   108: new java/net/URL
    //   111: dup
    //   112: aload_1
    //   113: invokespecial <init> : (Ljava/lang/String;)V
    //   116: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   119: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   122: bipush #10
    //   124: iaload
    //   125: aaload
    //   126: <illegal opcode> 31 : (Ljava/net/URL;Ljava/lang/String;)Ljava/lang/String;
    //   131: astore_2
    //   132: aload_2
    //   133: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   136: ifeq -> 225
    //   139: aload_2
    //   140: <illegal opcode> 32 : (Ljava/lang/String;)I
    //   145: invokestatic lllllIIIllIIlll : (I)Z
    //   148: ifeq -> 225
    //   151: new com/google/gson/JsonParser
    //   154: dup
    //   155: invokespecial <init> : ()V
    //   158: astore_3
    //   159: aload_3
    //   160: aload_2
    //   161: <illegal opcode> 21 : (Lcom/google/gson/JsonParser;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   166: <illegal opcode> 22 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonArray;
    //   171: aload_3
    //   172: aload_2
    //   173: <illegal opcode> 21 : (Lcom/google/gson/JsonParser;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   178: <illegal opcode> 22 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonArray;
    //   183: <illegal opcode> 23 : (Lcom/google/gson/JsonArray;)I
    //   188: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   191: iconst_1
    //   192: iaload
    //   193: isub
    //   194: <illegal opcode> 24 : (Lcom/google/gson/JsonArray;I)Lcom/google/gson/JsonElement;
    //   199: <illegal opcode> 25 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonObject;
    //   204: getstatic me/stupitdog/bhp/fq.lIlllIIlIllIlI : [Ljava/lang/String;
    //   207: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   210: bipush #11
    //   212: iaload
    //   213: aaload
    //   214: <illegal opcode> 26 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   219: <illegal opcode> 27 : (Lcom/google/gson/JsonElement;)Ljava/lang/String;
    //   224: areturn
    //   225: ldc ''
    //   227: invokevirtual length : ()I
    //   230: pop
    //   231: aconst_null
    //   232: ifnull -> 244
    //   235: aconst_null
    //   236: areturn
    //   237: astore_2
    //   238: aload_2
    //   239: <illegal opcode> 33 : (Ljava/lang/Exception;)V
    //   244: aconst_null
    //   245: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   159	66	3	lllllllllllllllIlllIllIlllIIllll	Lcom/google/gson/JsonParser;
    //   132	93	2	lllllllllllllllIlllIllIlllIIlllI	Ljava/lang/String;
    //   238	6	2	lllllllllllllllIlllIllIlllIIllIl	Ljava/lang/Exception;
    //   0	246	0	lllllllllllllllIlllIllIlllIIllII	Ljava/lang/String;
    //   108	138	1	lllllllllllllllIlllIllIlllIIlIll	Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   108	224	237	java/lang/Exception
  }
  
  public static Block isColliding(double lllllllllllllllIlllIllIlllIIIllI, double lllllllllllllllIlllIllIlllIIIlIl, double lllllllllllllllIlllIllIlllIIIlII) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #6
    //   3: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   8: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   13: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   16: ifeq -> 282
    //   19: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   34: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   37: ifeq -> 89
    //   40: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   45: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   50: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   55: <illegal opcode> 36 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   60: dconst_0
    //   61: dconst_0
    //   62: dconst_0
    //   63: <illegal opcode> 37 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   68: dload_0
    //   69: dload_2
    //   70: dload #4
    //   72: <illegal opcode> 38 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   77: ldc ''
    //   79: invokevirtual length : ()I
    //   82: pop
    //   83: aconst_null
    //   84: ifnull -> 121
    //   87: aconst_null
    //   88: areturn
    //   89: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   94: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   99: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   104: dconst_0
    //   105: dconst_0
    //   106: dconst_0
    //   107: <illegal opcode> 37 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   112: dload_0
    //   113: dload_2
    //   114: dload #4
    //   116: <illegal opcode> 38 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   121: astore #7
    //   123: aload #7
    //   125: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   130: d2i
    //   131: istore #8
    //   133: aload #7
    //   135: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   140: <illegal opcode> 42 : (D)I
    //   145: istore #9
    //   147: iload #9
    //   149: aload #7
    //   151: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   156: <illegal opcode> 42 : (D)I
    //   161: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   164: iconst_1
    //   165: iaload
    //   166: iadd
    //   167: invokestatic lllllIIIllIlIII : (II)Z
    //   170: ifeq -> 282
    //   173: aload #7
    //   175: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   180: <illegal opcode> 42 : (D)I
    //   185: istore #10
    //   187: iload #10
    //   189: aload #7
    //   191: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   196: <illegal opcode> 42 : (D)I
    //   201: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   204: iconst_1
    //   205: iaload
    //   206: iadd
    //   207: invokestatic lllllIIIllIlIII : (II)Z
    //   210: ifeq -> 263
    //   213: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   218: <illegal opcode> 46 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   223: new net/minecraft/util/math/BlockPos
    //   226: dup
    //   227: iload #9
    //   229: iload #8
    //   231: iload #10
    //   233: invokespecial <init> : (III)V
    //   236: <illegal opcode> 47 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   241: <illegal opcode> 48 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   246: astore #6
    //   248: iinc #10, 1
    //   251: ldc ''
    //   253: invokevirtual length : ()I
    //   256: pop
    //   257: aconst_null
    //   258: ifnull -> 187
    //   261: aconst_null
    //   262: areturn
    //   263: iinc #9, 1
    //   266: ldc ''
    //   268: invokevirtual length : ()I
    //   271: pop
    //   272: ldc ' '
    //   274: invokevirtual length : ()I
    //   277: ifge -> 147
    //   280: aconst_null
    //   281: areturn
    //   282: aload #6
    //   284: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   187	76	10	lllllllllllllllIlllIllIlllIIlIlI	I
    //   147	135	9	lllllllllllllllIlllIllIlllIIlIIl	I
    //   123	159	7	lllllllllllllllIlllIllIlllIIlIII	Lnet/minecraft/util/math/AxisAlignedBB;
    //   133	149	8	lllllllllllllllIlllIllIlllIIIlll	I
    //   0	285	0	lllllllllllllllIlllIllIlllIIIllI	D
    //   0	285	2	lllllllllllllllIlllIllIlllIIIlIl	D
    //   0	285	4	lllllllllllllllIlllIllIlllIIIlII	D
    //   3	282	6	lllllllllllllllIlllIllIlllIIIIll	Lnet/minecraft/block/Block;
  }
  
  public static double getBaseMoveSpeed() {
    // Byte code:
    //   0: ldc2_w 0.2873
    //   3: dstore_0
    //   4: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   17: ifeq -> 101
    //   20: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   25: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   30: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   33: iconst_1
    //   34: iaload
    //   35: <illegal opcode> 49 : (I)Lnet/minecraft/potion/Potion;
    //   40: <illegal opcode> 50 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   45: invokestatic lllllIIIllIIIIl : (I)Z
    //   48: ifeq -> 101
    //   51: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   64: iconst_1
    //   65: iaload
    //   66: <illegal opcode> 49 : (I)Lnet/minecraft/potion/Potion;
    //   71: <illegal opcode> 51 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;
    //   76: <illegal opcode> 52 : (Lnet/minecraft/potion/PotionEffect;)I
    //   81: istore_2
    //   82: dload_0
    //   83: ldc2_w 1.1
    //   86: ldc2_w 0.2
    //   89: iload_2
    //   90: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   93: iconst_1
    //   94: iaload
    //   95: iadd
    //   96: i2d
    //   97: dmul
    //   98: dadd
    //   99: dmul
    //   100: dstore_0
    //   101: dload_0
    //   102: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   82	19	2	lllllllllllllllIlllIllIlllIIIIlI	I
    //   4	99	0	lllllllllllllllIlllIllIlllIIIIIl	D
  }
  
  public static boolean isInLiquid() {
    // Byte code:
    //   0: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 557
    //   16: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 53 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   31: ldc_w 3.0
    //   34: invokestatic lllllIIIllIlIIl : (FF)I
    //   37: invokestatic lllllIIIllIlIlI : (I)Z
    //   40: ifeq -> 49
    //   43: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   46: iconst_0
    //   47: iaload
    //   48: ireturn
    //   49: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   52: iconst_0
    //   53: iaload
    //   54: istore_0
    //   55: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   60: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   65: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   70: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   73: ifeq -> 178
    //   76: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   81: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   86: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   91: <illegal opcode> 36 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   96: ldc ''
    //   98: invokevirtual length : ()I
    //   101: pop
    //   102: ldc ' '
    //   104: invokevirtual length : ()I
    //   107: ldc ' '
    //   109: invokevirtual length : ()I
    //   112: if_icmpeq -> 193
    //   115: bipush #60
    //   117: bipush #45
    //   119: ixor
    //   120: sipush #191
    //   123: sipush #186
    //   126: ixor
    //   127: ldc ' '
    //   129: invokevirtual length : ()I
    //   132: ldc ' '
    //   134: invokevirtual length : ()I
    //   137: ishl
    //   138: ishl
    //   139: ixor
    //   140: bipush #44
    //   142: bipush #25
    //   144: ixor
    //   145: ldc '   '
    //   147: invokevirtual length : ()I
    //   150: ldc ' '
    //   152: invokevirtual length : ()I
    //   155: ldc ' '
    //   157: invokevirtual length : ()I
    //   160: ldc ' '
    //   162: invokevirtual length : ()I
    //   165: ishl
    //   166: ishl
    //   167: ishl
    //   168: ixor
    //   169: ldc ' '
    //   171: invokevirtual length : ()I
    //   174: ineg
    //   175: ixor
    //   176: iand
    //   177: ireturn
    //   178: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   183: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   188: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   193: astore_1
    //   194: aload_1
    //   195: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   200: d2i
    //   201: istore_2
    //   202: aload_1
    //   203: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   208: <illegal opcode> 42 : (D)I
    //   213: istore_3
    //   214: iload_3
    //   215: aload_1
    //   216: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   221: <illegal opcode> 42 : (D)I
    //   226: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   229: iconst_1
    //   230: iaload
    //   231: iadd
    //   232: invokestatic lllllIIIllIlIII : (II)Z
    //   235: ifeq -> 555
    //   238: aload_1
    //   239: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   244: <illegal opcode> 42 : (D)I
    //   249: istore #4
    //   251: iload #4
    //   253: aload_1
    //   254: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   259: <illegal opcode> 42 : (D)I
    //   264: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   267: iconst_1
    //   268: iaload
    //   269: iadd
    //   270: invokestatic lllllIIIllIlIII : (II)Z
    //   273: ifeq -> 483
    //   276: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   281: <illegal opcode> 46 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   286: new net/minecraft/util/math/BlockPos
    //   289: dup
    //   290: iload_3
    //   291: iload_2
    //   292: iload #4
    //   294: invokespecial <init> : (III)V
    //   297: <illegal opcode> 47 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   302: <illegal opcode> 48 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   307: astore #5
    //   309: aload #5
    //   311: instanceof net/minecraft/block/BlockAir
    //   314: invokestatic lllllIIIllIIIlI : (I)Z
    //   317: ifeq -> 343
    //   320: aload #5
    //   322: instanceof net/minecraft/block/BlockLiquid
    //   325: invokestatic lllllIIIllIIIlI : (I)Z
    //   328: ifeq -> 337
    //   331: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   334: iconst_0
    //   335: iaload
    //   336: ireturn
    //   337: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   340: iconst_1
    //   341: iaload
    //   342: istore_0
    //   343: iinc #4, 1
    //   346: ldc ''
    //   348: invokevirtual length : ()I
    //   351: pop
    //   352: ldc ' '
    //   354: invokevirtual length : ()I
    //   357: ineg
    //   358: ldc ' '
    //   360: invokevirtual length : ()I
    //   363: ldc ' '
    //   365: invokevirtual length : ()I
    //   368: ishl
    //   369: sipush #150
    //   372: sipush #161
    //   375: ixor
    //   376: ixor
    //   377: bipush #26
    //   379: bipush #91
    //   381: ixor
    //   382: ldc ' '
    //   384: invokevirtual length : ()I
    //   387: ishl
    //   388: sipush #137
    //   391: sipush #178
    //   394: iadd
    //   395: sipush #233
    //   398: isub
    //   399: bipush #101
    //   401: iadd
    //   402: ixor
    //   403: ldc ' '
    //   405: invokevirtual length : ()I
    //   408: ineg
    //   409: ixor
    //   410: iand
    //   411: if_icmplt -> 251
    //   414: bipush #102
    //   416: bipush #97
    //   418: ixor
    //   419: ldc ' '
    //   421: invokevirtual length : ()I
    //   424: ldc ' '
    //   426: invokevirtual length : ()I
    //   429: ishl
    //   430: ishl
    //   431: sipush #222
    //   434: sipush #199
    //   437: ixor
    //   438: ixor
    //   439: ldc ' '
    //   441: invokevirtual length : ()I
    //   444: ishl
    //   445: bipush #110
    //   447: bipush #13
    //   449: ixor
    //   450: ldc ' '
    //   452: invokevirtual length : ()I
    //   455: ishl
    //   456: bipush #67
    //   458: bipush #85
    //   460: iadd
    //   461: bipush #-14
    //   463: isub
    //   464: bipush #29
    //   466: iadd
    //   467: ixor
    //   468: ldc ' '
    //   470: invokevirtual length : ()I
    //   473: ishl
    //   474: ldc ' '
    //   476: invokevirtual length : ()I
    //   479: ineg
    //   480: ixor
    //   481: iand
    //   482: ireturn
    //   483: iinc #3, 1
    //   486: ldc ''
    //   488: invokevirtual length : ()I
    //   491: pop
    //   492: ldc '   '
    //   494: invokevirtual length : ()I
    //   497: ifgt -> 214
    //   500: ldc ' '
    //   502: invokevirtual length : ()I
    //   505: ldc ' '
    //   507: invokevirtual length : ()I
    //   510: ldc ' '
    //   512: invokevirtual length : ()I
    //   515: ldc ' '
    //   517: invokevirtual length : ()I
    //   520: ishl
    //   521: ishl
    //   522: ishl
    //   523: ldc ' '
    //   525: invokevirtual length : ()I
    //   528: ldc ' '
    //   530: invokevirtual length : ()I
    //   533: ldc ' '
    //   535: invokevirtual length : ()I
    //   538: ldc ' '
    //   540: invokevirtual length : ()I
    //   543: ishl
    //   544: ishl
    //   545: ishl
    //   546: ldc ' '
    //   548: invokevirtual length : ()I
    //   551: ineg
    //   552: ixor
    //   553: iand
    //   554: ireturn
    //   555: iload_0
    //   556: ireturn
    //   557: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   560: iconst_0
    //   561: iaload
    //   562: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   309	34	5	lllllllllllllllIlllIllIlllIIIIII	Lnet/minecraft/block/Block;
    //   251	232	4	lllllllllllllllIlllIllIllIllllll	I
    //   214	341	3	lllllllllllllllIlllIllIllIlllllI	I
    //   55	502	0	lllllllllllllllIlllIllIllIllllIl	Z
    //   194	363	1	lllllllllllllllIlllIllIllIllllII	Lnet/minecraft/util/math/AxisAlignedBB;
    //   202	355	2	lllllllllllllllIlllIllIllIlllIll	I
  }
  
  public static boolean isOnLiquidOffset(double lllllllllllllllIlllIllIllIllIlII) {
    // Byte code:
    //   0: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   5: astore_2
    //   6: aload_2
    //   7: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   12: <illegal opcode> 53 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   17: ldc_w 3.0
    //   20: invokestatic lllllIIIllIlIll : (FF)I
    //   23: invokestatic lllllIIIllIlIlI : (I)Z
    //   26: ifeq -> 35
    //   29: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   32: iconst_0
    //   33: iaload
    //   34: ireturn
    //   35: aload_2
    //   36: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   41: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   44: ifeq -> 466
    //   47: aload_2
    //   48: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   53: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   58: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   61: ifeq -> 155
    //   64: aload_2
    //   65: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   70: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   75: <illegal opcode> 36 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   80: dconst_0
    //   81: dconst_0
    //   82: dconst_0
    //   83: <illegal opcode> 37 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   88: dconst_0
    //   89: dload_0
    //   90: dneg
    //   91: dconst_0
    //   92: <illegal opcode> 38 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   97: ldc ''
    //   99: invokevirtual length : ()I
    //   102: pop
    //   103: aconst_null
    //   104: ifnull -> 183
    //   107: iconst_2
    //   108: bipush #73
    //   110: ixor
    //   111: sipush #130
    //   114: sipush #175
    //   117: ixor
    //   118: ldc ' '
    //   120: invokevirtual length : ()I
    //   123: ishl
    //   124: ixor
    //   125: sipush #173
    //   128: sipush #130
    //   131: ixor
    //   132: ldc ' '
    //   134: invokevirtual length : ()I
    //   137: ishl
    //   138: sipush #216
    //   141: sipush #151
    //   144: ixor
    //   145: ixor
    //   146: ldc ' '
    //   148: invokevirtual length : ()I
    //   151: ineg
    //   152: ixor
    //   153: iand
    //   154: ireturn
    //   155: aload_2
    //   156: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   161: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   166: dconst_0
    //   167: dconst_0
    //   168: dconst_0
    //   169: <illegal opcode> 37 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   174: dconst_0
    //   175: dload_0
    //   176: dneg
    //   177: dconst_0
    //   178: <illegal opcode> 38 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   183: astore_3
    //   184: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   187: iconst_0
    //   188: iaload
    //   189: istore #4
    //   191: aload_3
    //   192: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   197: d2i
    //   198: istore #5
    //   200: aload_3
    //   201: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   206: <illegal opcode> 42 : (D)I
    //   211: istore #6
    //   213: iload #6
    //   215: aload_3
    //   216: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   221: dconst_1
    //   222: dadd
    //   223: <illegal opcode> 42 : (D)I
    //   228: invokestatic lllllIIIllIlIII : (II)Z
    //   231: ifeq -> 463
    //   234: aload_3
    //   235: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   240: <illegal opcode> 42 : (D)I
    //   245: istore #7
    //   247: iload #7
    //   249: aload_3
    //   250: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   255: dconst_1
    //   256: dadd
    //   257: <illegal opcode> 42 : (D)I
    //   262: invokestatic lllllIIIllIlIII : (II)Z
    //   265: ifeq -> 403
    //   268: aload_2
    //   269: <illegal opcode> 46 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   274: new net/minecraft/util/math/BlockPos
    //   277: dup
    //   278: iload #6
    //   280: iload #5
    //   282: iload #7
    //   284: invokespecial <init> : (III)V
    //   287: <illegal opcode> 47 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   292: <illegal opcode> 48 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   297: astore #8
    //   299: aload #8
    //   301: <illegal opcode> 55 : ()Lnet/minecraft/block/Block;
    //   306: invokestatic lllllIIIllIIllI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   309: ifeq -> 336
    //   312: aload #8
    //   314: instanceof net/minecraft/block/BlockLiquid
    //   317: invokestatic lllllIIIllIIIlI : (I)Z
    //   320: ifeq -> 329
    //   323: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   326: iconst_0
    //   327: iaload
    //   328: ireturn
    //   329: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   332: iconst_1
    //   333: iaload
    //   334: istore #4
    //   336: iinc #7, 1
    //   339: ldc ''
    //   341: invokevirtual length : ()I
    //   344: pop
    //   345: aconst_null
    //   346: ifnull -> 247
    //   349: bipush #98
    //   351: bipush #47
    //   353: iadd
    //   354: bipush #-39
    //   356: isub
    //   357: iconst_5
    //   358: iadd
    //   359: ldc ' '
    //   361: invokevirtual length : ()I
    //   364: bipush #49
    //   366: bipush #54
    //   368: ixor
    //   369: ishl
    //   370: ixor
    //   371: bipush #110
    //   373: bipush #105
    //   375: ixor
    //   376: ldc ' '
    //   378: invokevirtual length : ()I
    //   381: ldc ' '
    //   383: invokevirtual length : ()I
    //   386: ishl
    //   387: ishl
    //   388: bipush #76
    //   390: bipush #109
    //   392: ixor
    //   393: ixor
    //   394: ldc ' '
    //   396: invokevirtual length : ()I
    //   399: ineg
    //   400: ixor
    //   401: iand
    //   402: ireturn
    //   403: iinc #6, 1
    //   406: ldc ''
    //   408: invokevirtual length : ()I
    //   411: pop
    //   412: ldc '   '
    //   414: invokevirtual length : ()I
    //   417: ldc ' '
    //   419: invokevirtual length : ()I
    //   422: ldc ' '
    //   424: invokevirtual length : ()I
    //   427: ldc ' '
    //   429: invokevirtual length : ()I
    //   432: ishl
    //   433: ishl
    //   434: if_icmplt -> 213
    //   437: bipush #97
    //   439: bipush #102
    //   441: ixor
    //   442: ldc ' '
    //   444: invokevirtual length : ()I
    //   447: ishl
    //   448: bipush #17
    //   450: bipush #22
    //   452: ixor
    //   453: ldc ' '
    //   455: invokevirtual length : ()I
    //   458: ishl
    //   459: iconst_m1
    //   460: ixor
    //   461: iand
    //   462: ireturn
    //   463: iload #4
    //   465: ireturn
    //   466: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   469: iconst_0
    //   470: iaload
    //   471: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   299	37	8	lllllllllllllllIlllIllIllIlllIlI	Lnet/minecraft/block/Block;
    //   247	156	7	lllllllllllllllIlllIllIllIlllIIl	I
    //   213	250	6	lllllllllllllllIlllIllIllIlllIII	I
    //   184	282	3	lllllllllllllllIlllIllIllIllIlll	Lnet/minecraft/util/math/AxisAlignedBB;
    //   191	275	4	lllllllllllllllIlllIllIllIllIllI	Z
    //   200	266	5	lllllllllllllllIlllIllIllIllIlIl	I
    //   0	472	0	lllllllllllllllIlllIllIllIllIlII	D
    //   6	466	2	lllllllllllllllIlllIllIllIllIIll	Lnet/minecraft/client/Minecraft;
  }
  
  public static void setTimer(float lllllllllllllllIlllIllIllIllIIlI) {
    // Byte code:
    //   0: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 56 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   10: ldc_w 50.0
    //   13: fload_0
    //   14: fdiv
    //   15: putfield field_194149_e : F
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIlllIllIllIllIIlI	F
  }
  
  public static void resetTimer() {
    // Byte code:
    //   0: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 56 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   10: ldc_w 50.0
    //   13: putfield field_194149_e : F
    //   16: return
  }
  
  public static Vec3d getInterpolatedAmount(Entity lllllllllllllllIlllIllIllIllIIIl, Vec3d lllllllllllllllIlllIllIllIllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 57 : (Lnet/minecraft/util/math/Vec3d;)D
    //   7: aload_1
    //   8: <illegal opcode> 58 : (Lnet/minecraft/util/math/Vec3d;)D
    //   13: aload_1
    //   14: <illegal opcode> 59 : (Lnet/minecraft/util/math/Vec3d;)D
    //   19: <illegal opcode> 60 : (Lnet/minecraft/entity/Entity;DDD)Lnet/minecraft/util/math/Vec3d;
    //   24: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	0	lllllllllllllllIlllIllIllIllIIIl	Lnet/minecraft/entity/Entity;
    //   0	25	1	lllllllllllllllIlllIllIllIllIIII	Lnet/minecraft/util/math/Vec3d;
  }
  
  public static Vec3d getInterpolatedAmount(Entity lllllllllllllllIlllIllIllIlIllll, double lllllllllllllllIlllIllIllIlIlllI) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: dload_1
    //   3: dload_1
    //   4: <illegal opcode> 60 : (Lnet/minecraft/entity/Entity;DDD)Lnet/minecraft/util/math/Vec3d;
    //   9: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	10	0	lllllllllllllllIlllIllIllIlIllll	Lnet/minecraft/entity/Entity;
    //   0	10	1	lllllllllllllllIlllIllIllIlIlllI	D
  }
  
  public static double[] forward(double lllllllllllllllIlllIllIllIlIllIl) {
    // Byte code:
    //   0: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   15: <illegal opcode> 62 : (Lnet/minecraft/util/MovementInput;)F
    //   20: fstore_2
    //   21: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   26: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   31: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   36: <illegal opcode> 63 : (Lnet/minecraft/util/MovementInput;)F
    //   41: fstore_3
    //   42: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   47: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   52: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   57: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   62: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   67: <illegal opcode> 65 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   72: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   77: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   82: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   87: fsub
    //   88: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   93: <illegal opcode> 66 : (Lnet/minecraft/client/Minecraft;)F
    //   98: fmul
    //   99: fadd
    //   100: fstore #4
    //   102: fload_2
    //   103: fconst_0
    //   104: invokestatic lllllIIIllIllII : (FF)I
    //   107: invokestatic lllllIIIllIIIIl : (I)Z
    //   110: ifeq -> 327
    //   113: fload_3
    //   114: fconst_0
    //   115: invokestatic lllllIIIllIllII : (FF)I
    //   118: invokestatic lllllIIIllIIlll : (I)Z
    //   121: ifeq -> 208
    //   124: fload #4
    //   126: fload_2
    //   127: fconst_0
    //   128: invokestatic lllllIIIllIllII : (FF)I
    //   131: invokestatic lllllIIIllIIlll : (I)Z
    //   134: ifeq -> 165
    //   137: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   140: bipush #12
    //   142: iaload
    //   143: ldc ''
    //   145: invokevirtual length : ()I
    //   148: pop
    //   149: ldc ' '
    //   151: invokevirtual length : ()I
    //   154: ineg
    //   155: ldc ' '
    //   157: invokevirtual length : ()I
    //   160: if_icmpne -> 171
    //   163: aconst_null
    //   164: areturn
    //   165: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   168: bipush #13
    //   170: iaload
    //   171: i2f
    //   172: fadd
    //   173: fstore #4
    //   175: ldc ''
    //   177: invokevirtual length : ()I
    //   180: pop
    //   181: ldc ' '
    //   183: invokevirtual length : ()I
    //   186: ldc ' '
    //   188: invokevirtual length : ()I
    //   191: ldc ' '
    //   193: invokevirtual length : ()I
    //   196: ishl
    //   197: ishl
    //   198: ldc '   '
    //   200: invokevirtual length : ()I
    //   203: if_icmpgt -> 264
    //   206: aconst_null
    //   207: areturn
    //   208: fload_3
    //   209: fconst_0
    //   210: invokestatic lllllIIIllIllIl : (FF)I
    //   213: invokestatic lllllIIIllIlllI : (I)Z
    //   216: ifeq -> 264
    //   219: fload #4
    //   221: fload_2
    //   222: fconst_0
    //   223: invokestatic lllllIIIllIllII : (FF)I
    //   226: invokestatic lllllIIIllIIlll : (I)Z
    //   229: ifeq -> 254
    //   232: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   235: bipush #13
    //   237: iaload
    //   238: ldc ''
    //   240: invokevirtual length : ()I
    //   243: pop
    //   244: ldc '   '
    //   246: invokevirtual length : ()I
    //   249: ifgt -> 260
    //   252: aconst_null
    //   253: areturn
    //   254: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   257: bipush #12
    //   259: iaload
    //   260: i2f
    //   261: fadd
    //   262: fstore #4
    //   264: fconst_0
    //   265: fstore_3
    //   266: fload_2
    //   267: fconst_0
    //   268: invokestatic lllllIIIllIllII : (FF)I
    //   271: invokestatic lllllIIIllIIlll : (I)Z
    //   274: ifeq -> 312
    //   277: fconst_1
    //   278: fstore_2
    //   279: ldc ''
    //   281: invokevirtual length : ()I
    //   284: pop
    //   285: ldc ' '
    //   287: invokevirtual length : ()I
    //   290: ldc ' '
    //   292: invokevirtual length : ()I
    //   295: ishl
    //   296: ldc ' '
    //   298: invokevirtual length : ()I
    //   301: ldc ' '
    //   303: invokevirtual length : ()I
    //   306: ishl
    //   307: if_icmple -> 327
    //   310: aconst_null
    //   311: areturn
    //   312: fload_2
    //   313: fconst_0
    //   314: invokestatic lllllIIIllIllIl : (FF)I
    //   317: invokestatic lllllIIIllIlllI : (I)Z
    //   320: ifeq -> 327
    //   323: ldc_w -1.0
    //   326: fstore_2
    //   327: fload #4
    //   329: ldc_w 90.0
    //   332: fadd
    //   333: f2d
    //   334: <illegal opcode> 67 : (D)D
    //   339: <illegal opcode> 68 : (D)D
    //   344: dstore #5
    //   346: fload #4
    //   348: ldc_w 90.0
    //   351: fadd
    //   352: f2d
    //   353: <illegal opcode> 67 : (D)D
    //   358: <illegal opcode> 69 : (D)D
    //   363: dstore #7
    //   365: fload_2
    //   366: f2d
    //   367: dload_0
    //   368: dmul
    //   369: dload #7
    //   371: dmul
    //   372: fload_3
    //   373: f2d
    //   374: dload_0
    //   375: dmul
    //   376: dload #5
    //   378: dmul
    //   379: dadd
    //   380: dstore #9
    //   382: fload_2
    //   383: f2d
    //   384: dload_0
    //   385: dmul
    //   386: dload #5
    //   388: dmul
    //   389: fload_3
    //   390: f2d
    //   391: dload_0
    //   392: dmul
    //   393: dload #7
    //   395: dmul
    //   396: dsub
    //   397: dstore #11
    //   399: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   402: iconst_3
    //   403: iaload
    //   404: newarray double
    //   406: dup
    //   407: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   410: iconst_0
    //   411: iaload
    //   412: dload #9
    //   414: dastore
    //   415: dup
    //   416: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   419: iconst_1
    //   420: iaload
    //   421: dload #11
    //   423: dastore
    //   424: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	425	0	lllllllllllllllIlllIllIllIlIllIl	D
    //   21	404	2	lllllllllllllllIlllIllIllIlIllII	F
    //   42	383	3	lllllllllllllllIlllIllIllIlIlIll	F
    //   102	323	4	lllllllllllllllIlllIllIllIlIlIlI	F
    //   346	79	5	lllllllllllllllIlllIllIllIlIlIIl	D
    //   365	60	7	lllllllllllllllIlllIllIllIlIlIII	D
    //   382	43	9	lllllllllllllllIlllIllIllIlIIlll	D
    //   399	26	11	lllllllllllllllIlllIllIllIlIIllI	D
  }
  
  public static boolean isMobAggressive(Entity lllllllllllllllIlllIllIllIlIIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof net/minecraft/entity/monster/EntityPigZombie
    //   4: invokestatic lllllIIIllIIIIl : (I)Z
    //   7: ifeq -> 46
    //   10: aload_0
    //   11: checkcast net/minecraft/entity/monster/EntityPigZombie
    //   14: <illegal opcode> 70 : (Lnet/minecraft/entity/monster/EntityPigZombie;)Z
    //   19: invokestatic lllllIIIllIIIlI : (I)Z
    //   22: ifeq -> 40
    //   25: aload_0
    //   26: checkcast net/minecraft/entity/monster/EntityPigZombie
    //   29: <illegal opcode> 71 : (Lnet/minecraft/entity/monster/EntityPigZombie;)Z
    //   34: invokestatic lllllIIIllIIIIl : (I)Z
    //   37: ifeq -> 181
    //   40: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   43: iconst_1
    //   44: iaload
    //   45: ireturn
    //   46: aload_0
    //   47: instanceof net/minecraft/entity/passive/EntityWolf
    //   50: invokestatic lllllIIIllIIIIl : (I)Z
    //   53: ifeq -> 161
    //   56: aload_0
    //   57: checkcast net/minecraft/entity/passive/EntityWolf
    //   60: <illegal opcode> 0 : (Lnet/minecraft/entity/passive/EntityWolf;)Z
    //   65: invokestatic lllllIIIllIIIIl : (I)Z
    //   68: ifeq -> 155
    //   71: <illegal opcode> 3 : ()Lnet/minecraft/client/entity/EntityPlayerSP;
    //   76: aload_0
    //   77: checkcast net/minecraft/entity/passive/EntityWolf
    //   80: <illegal opcode> 72 : (Lnet/minecraft/entity/passive/EntityWolf;)Lnet/minecraft/entity/EntityLivingBase;
    //   85: <illegal opcode> 73 : (Lnet/minecraft/client/entity/EntityPlayerSP;Ljava/lang/Object;)Z
    //   90: invokestatic lllllIIIllIIIlI : (I)Z
    //   93: ifeq -> 155
    //   96: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   99: iconst_1
    //   100: iaload
    //   101: ldc ''
    //   103: invokevirtual length : ()I
    //   106: pop
    //   107: ldc_w '  '
    //   110: invokevirtual length : ()I
    //   113: ineg
    //   114: ifle -> 160
    //   117: ldc ' '
    //   119: invokevirtual length : ()I
    //   122: ldc '   '
    //   124: invokevirtual length : ()I
    //   127: ldc ' '
    //   129: invokevirtual length : ()I
    //   132: ishl
    //   133: ishl
    //   134: ldc ' '
    //   136: invokevirtual length : ()I
    //   139: ldc '   '
    //   141: invokevirtual length : ()I
    //   144: ldc ' '
    //   146: invokevirtual length : ()I
    //   149: ishl
    //   150: ishl
    //   151: iconst_m1
    //   152: ixor
    //   153: iand
    //   154: ireturn
    //   155: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   158: iconst_0
    //   159: iaload
    //   160: ireturn
    //   161: aload_0
    //   162: instanceof net/minecraft/entity/monster/EntityEnderman
    //   165: invokestatic lllllIIIllIIIIl : (I)Z
    //   168: ifeq -> 181
    //   171: aload_0
    //   172: checkcast net/minecraft/entity/monster/EntityEnderman
    //   175: <illegal opcode> 74 : (Lnet/minecraft/entity/monster/EntityEnderman;)Z
    //   180: ireturn
    //   181: aload_0
    //   182: <illegal opcode> 75 : (Lnet/minecraft/entity/Entity;)Z
    //   187: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	188	0	lllllllllllllllIlllIllIllIlIIlIl	Lnet/minecraft/entity/Entity;
  }
  
  public static boolean isNeutralMob(Entity lllllllllllllllIlllIllIllIlIIlII) {
    if (!lllllIIIllIIIlI(lllllllllllllllIlllIllIllIlIIlII instanceof net.minecraft.entity.monster.EntityPigZombie) || !lllllIIIllIIIlI(lllllllllllllllIlllIllIllIlIIlII instanceof net.minecraft.entity.passive.EntityWolf) || lllllIIIllIIIIl(lllllllllllllllIlllIllIllIlIIlII instanceof net.minecraft.entity.monster.EntityEnderman)) {
      "".length();
      if (-(0xC5 ^ 0xC0) >= 0)
        return (0x9 ^ 0x6A) & (0x4F ^ 0x2C ^ 0xFFFFFFFF); 
    } else {
    
    } 
    return lIlllIIlIllllI[0];
  }
  
  public static boolean isFriendlyMob(Entity lllllllllllllllIlllIllIllIlIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 76 : ()Lnet/minecraft/entity/EnumCreatureType;
    //   6: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   9: iconst_0
    //   10: iaload
    //   11: <illegal opcode> 77 : (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EnumCreatureType;Z)Z
    //   16: invokestatic lllllIIIllIIIIl : (I)Z
    //   19: ifeq -> 34
    //   22: aload_0
    //   23: <illegal opcode> 78 : (Lnet/minecraft/entity/Entity;)Z
    //   28: invokestatic lllllIIIllIIIIl : (I)Z
    //   31: ifeq -> 100
    //   34: aload_0
    //   35: <illegal opcode> 79 : ()Lnet/minecraft/entity/EnumCreatureType;
    //   40: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   43: iconst_0
    //   44: iaload
    //   45: <illegal opcode> 77 : (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EnumCreatureType;Z)Z
    //   50: invokestatic lllllIIIllIIIlI : (I)Z
    //   53: ifeq -> 100
    //   56: aload_0
    //   57: instanceof net/minecraft/entity/passive/EntityVillager
    //   60: invokestatic lllllIIIllIIIlI : (I)Z
    //   63: ifeq -> 100
    //   66: aload_0
    //   67: instanceof net/minecraft/entity/monster/EntityIronGolem
    //   70: invokestatic lllllIIIllIIIlI : (I)Z
    //   73: ifeq -> 100
    //   76: aload_0
    //   77: <illegal opcode> 78 : (Lnet/minecraft/entity/Entity;)Z
    //   82: invokestatic lllllIIIllIIIIl : (I)Z
    //   85: ifeq -> 146
    //   88: aload_0
    //   89: <illegal opcode> 80 : (Lnet/minecraft/entity/Entity;)Z
    //   94: invokestatic lllllIIIllIIIlI : (I)Z
    //   97: ifeq -> 146
    //   100: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   103: iconst_1
    //   104: iaload
    //   105: ldc ''
    //   107: invokevirtual length : ()I
    //   110: pop
    //   111: ldc ' '
    //   113: invokevirtual length : ()I
    //   116: ineg
    //   117: ifle -> 151
    //   120: bipush #21
    //   122: bipush #54
    //   124: ixor
    //   125: ldc ' '
    //   127: invokevirtual length : ()I
    //   130: ishl
    //   131: bipush #45
    //   133: bipush #14
    //   135: ixor
    //   136: ldc ' '
    //   138: invokevirtual length : ()I
    //   141: ishl
    //   142: iconst_m1
    //   143: ixor
    //   144: iand
    //   145: ireturn
    //   146: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   149: iconst_0
    //   150: iaload
    //   151: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	152	0	lllllllllllllllIlllIllIllIlIIIll	Lnet/minecraft/entity/Entity;
  }
  
  public static boolean isHostileMob(Entity lllllllllllllllIlllIllIllIlIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 81 : ()Lnet/minecraft/entity/EnumCreatureType;
    //   6: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   9: iconst_0
    //   10: iaload
    //   11: <illegal opcode> 77 : (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EnumCreatureType;Z)Z
    //   16: invokestatic lllllIIIllIIIIl : (I)Z
    //   19: ifeq -> 107
    //   22: aload_0
    //   23: <illegal opcode> 78 : (Lnet/minecraft/entity/Entity;)Z
    //   28: invokestatic lllllIIIllIIIlI : (I)Z
    //   31: ifeq -> 107
    //   34: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   37: iconst_1
    //   38: iaload
    //   39: ldc ''
    //   41: invokevirtual length : ()I
    //   44: pop
    //   45: aconst_null
    //   46: ifnull -> 112
    //   49: sipush #196
    //   52: sipush #141
    //   55: ixor
    //   56: ldc ' '
    //   58: invokevirtual length : ()I
    //   61: ishl
    //   62: bipush #60
    //   64: bipush #40
    //   66: iadd
    //   67: bipush #37
    //   69: isub
    //   70: sipush #128
    //   73: iadd
    //   74: ixor
    //   75: bipush #122
    //   77: bipush #127
    //   79: ixor
    //   80: bipush #42
    //   82: bipush #47
    //   84: ixor
    //   85: ishl
    //   86: bipush #86
    //   88: bipush #112
    //   90: iadd
    //   91: bipush #105
    //   93: isub
    //   94: bipush #48
    //   96: iadd
    //   97: ixor
    //   98: ldc ' '
    //   100: invokevirtual length : ()I
    //   103: ineg
    //   104: ixor
    //   105: iand
    //   106: ireturn
    //   107: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   110: iconst_0
    //   111: iaload
    //   112: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	113	0	lllllllllllllllIlllIllIllIlIIIlI	Lnet/minecraft/entity/Entity;
  }
  
  public static Vec3d getInterpolatedPos(Entity lllllllllllllllIlllIllIllIlIIIIl, float lllllllllllllllIlllIllIllIlIIIII) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 5 : (Lnet/minecraft/entity/Entity;)D
    //   10: aload_0
    //   11: <illegal opcode> 7 : (Lnet/minecraft/entity/Entity;)D
    //   16: aload_0
    //   17: <illegal opcode> 9 : (Lnet/minecraft/entity/Entity;)D
    //   22: invokespecial <init> : (DDD)V
    //   25: aload_0
    //   26: fload_1
    //   27: f2d
    //   28: <illegal opcode> 82 : (Lnet/minecraft/entity/Entity;D)Lnet/minecraft/util/math/Vec3d;
    //   33: <illegal opcode> 83 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   38: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	39	0	lllllllllllllllIlllIllIllIlIIIIl	Lnet/minecraft/entity/Entity;
    //   0	39	1	lllllllllllllllIlllIllIllIlIIIII	F
  }
  
  public static Vec3d interpolateEntity(Entity lllllllllllllllIlllIllIllIIlllll, float lllllllllllllllIlllIllIllIIllllI) {
    // Byte code:
    //   0: new net/minecraft/util/math/Vec3d
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 5 : (Lnet/minecraft/entity/Entity;)D
    //   10: aload_0
    //   11: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   16: aload_0
    //   17: <illegal opcode> 5 : (Lnet/minecraft/entity/Entity;)D
    //   22: dsub
    //   23: fload_1
    //   24: f2d
    //   25: dmul
    //   26: dadd
    //   27: aload_0
    //   28: <illegal opcode> 7 : (Lnet/minecraft/entity/Entity;)D
    //   33: aload_0
    //   34: <illegal opcode> 6 : (Lnet/minecraft/entity/Entity;)D
    //   39: aload_0
    //   40: <illegal opcode> 7 : (Lnet/minecraft/entity/Entity;)D
    //   45: dsub
    //   46: fload_1
    //   47: f2d
    //   48: dmul
    //   49: dadd
    //   50: aload_0
    //   51: <illegal opcode> 9 : (Lnet/minecraft/entity/Entity;)D
    //   56: aload_0
    //   57: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   62: aload_0
    //   63: <illegal opcode> 9 : (Lnet/minecraft/entity/Entity;)D
    //   68: dsub
    //   69: fload_1
    //   70: f2d
    //   71: dmul
    //   72: dadd
    //   73: invokespecial <init> : (DDD)V
    //   76: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIlllIllIllIIlllll	Lnet/minecraft/entity/Entity;
    //   0	77	1	lllllllllllllllIlllIllIllIIllllI	F
  }
  
  public static boolean isMoving(EntityLivingBase lllllllllllllllIlllIllIllIIlllIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 84 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   6: fconst_0
    //   7: invokestatic lllllIIIllIllll : (FF)I
    //   10: invokestatic lllllIIIllIIIlI : (I)Z
    //   13: ifeq -> 32
    //   16: aload_0
    //   17: <illegal opcode> 85 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   22: fconst_0
    //   23: invokestatic lllllIIIllIllll : (FF)I
    //   26: invokestatic lllllIIIllIIIIl : (I)Z
    //   29: ifeq -> 170
    //   32: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   35: iconst_1
    //   36: iaload
    //   37: ldc ''
    //   39: invokevirtual length : ()I
    //   42: pop
    //   43: bipush #49
    //   45: bipush #62
    //   47: ixor
    //   48: ldc ' '
    //   50: invokevirtual length : ()I
    //   53: ishl
    //   54: bipush #127
    //   56: bipush #120
    //   58: ixor
    //   59: ixor
    //   60: ldc ' '
    //   62: invokevirtual length : ()I
    //   65: ishl
    //   66: sipush #251
    //   69: sipush #160
    //   72: ixor
    //   73: bipush #30
    //   75: bipush #63
    //   77: ixor
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ishl
    //   84: ixor
    //   85: ldc ' '
    //   87: invokevirtual length : ()I
    //   90: ishl
    //   91: ldc ' '
    //   93: invokevirtual length : ()I
    //   96: ineg
    //   97: ixor
    //   98: iand
    //   99: ldc '   '
    //   101: invokevirtual length : ()I
    //   104: if_icmpne -> 175
    //   107: bipush #97
    //   109: bipush #40
    //   111: ixor
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ishl
    //   118: bipush #47
    //   120: bipush #51
    //   122: iadd
    //   123: bipush #-19
    //   125: isub
    //   126: bipush #14
    //   128: iadd
    //   129: ixor
    //   130: ldc ' '
    //   132: invokevirtual length : ()I
    //   135: ishl
    //   136: bipush #98
    //   138: bipush #83
    //   140: ixor
    //   141: ldc ' '
    //   143: invokevirtual length : ()I
    //   146: ishl
    //   147: sipush #212
    //   150: sipush #167
    //   153: ixor
    //   154: ixor
    //   155: ldc ' '
    //   157: invokevirtual length : ()I
    //   160: ishl
    //   161: ldc ' '
    //   163: invokevirtual length : ()I
    //   166: ineg
    //   167: ixor
    //   168: iand
    //   169: ireturn
    //   170: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   173: iconst_0
    //   174: iaload
    //   175: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	176	0	lllllllllllllllIlllIllIllIIlllIl	Lnet/minecraft/entity/EntityLivingBase;
  }
  
  public static boolean isInWater(Entity lllllllllllllllIlllIllIllIIllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic lllllIIIllIIIll : (Ljava/lang/Object;)Z
    //   4: ifeq -> 13
    //   7: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: ireturn
    //   13: aload_0
    //   14: <illegal opcode> 6 : (Lnet/minecraft/entity/Entity;)D
    //   19: ldc2_w 0.01
    //   22: dadd
    //   23: dstore_1
    //   24: aload_0
    //   25: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   30: <illegal opcode> 42 : (D)I
    //   35: istore_3
    //   36: iload_3
    //   37: aload_0
    //   38: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   43: <illegal opcode> 86 : (D)I
    //   48: invokestatic lllllIIIllIlIII : (II)Z
    //   51: ifeq -> 252
    //   54: aload_0
    //   55: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   60: <illegal opcode> 42 : (D)I
    //   65: istore #4
    //   67: iload #4
    //   69: aload_0
    //   70: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   75: <illegal opcode> 86 : (D)I
    //   80: invokestatic lllllIIIllIlIII : (II)Z
    //   83: ifeq -> 214
    //   86: new net/minecraft/util/math/BlockPos
    //   89: dup
    //   90: iload_3
    //   91: dload_1
    //   92: d2i
    //   93: iload #4
    //   95: invokespecial <init> : (III)V
    //   98: astore #5
    //   100: <illegal opcode> 87 : ()Lnet/minecraft/world/World;
    //   105: aload #5
    //   107: <illegal opcode> 88 : (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   112: <illegal opcode> 48 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   117: instanceof net/minecraft/block/BlockLiquid
    //   120: invokestatic lllllIIIllIIIIl : (I)Z
    //   123: ifeq -> 132
    //   126: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   129: iconst_1
    //   130: iaload
    //   131: ireturn
    //   132: iinc #4, 1
    //   135: ldc ''
    //   137: invokevirtual length : ()I
    //   140: pop
    //   141: ldc '   '
    //   143: invokevirtual length : ()I
    //   146: ldc ' '
    //   148: invokevirtual length : ()I
    //   151: ldc ' '
    //   153: invokevirtual length : ()I
    //   156: ishl
    //   157: if_icmpgt -> 67
    //   160: bipush #10
    //   162: bipush #125
    //   164: ixor
    //   165: sipush #181
    //   168: sipush #146
    //   171: ixor
    //   172: ldc ' '
    //   174: invokevirtual length : ()I
    //   177: ishl
    //   178: ixor
    //   179: bipush #92
    //   181: bipush #89
    //   183: ixor
    //   184: sipush #175
    //   187: sipush #170
    //   190: ixor
    //   191: ishl
    //   192: sipush #145
    //   195: bipush #52
    //   197: iadd
    //   198: bipush #66
    //   200: isub
    //   201: bipush #22
    //   203: iadd
    //   204: ixor
    //   205: ldc ' '
    //   207: invokevirtual length : ()I
    //   210: ineg
    //   211: ixor
    //   212: iand
    //   213: ireturn
    //   214: iinc #3, 1
    //   217: ldc ''
    //   219: invokevirtual length : ()I
    //   222: pop
    //   223: ldc ' '
    //   225: invokevirtual length : ()I
    //   228: ldc '   '
    //   230: invokevirtual length : ()I
    //   233: if_icmplt -> 36
    //   236: sipush #210
    //   239: sipush #153
    //   242: ixor
    //   243: bipush #107
    //   245: bipush #32
    //   247: ixor
    //   248: iconst_m1
    //   249: ixor
    //   250: iand
    //   251: ireturn
    //   252: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   255: iconst_0
    //   256: iaload
    //   257: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   100	32	5	lllllllllllllllIlllIllIllIIlllII	Lnet/minecraft/util/math/BlockPos;
    //   67	147	4	lllllllllllllllIlllIllIllIIllIll	I
    //   36	216	3	lllllllllllllllIlllIllIllIIllIlI	I
    //   0	258	0	lllllllllllllllIlllIllIllIIllIIl	Lnet/minecraft/entity/Entity;
    //   24	234	1	lllllllllllllllIlllIllIllIIllIII	D
  }
  
  public static boolean isDrivenByPlayer(Entity lllllllllllllllIlllIllIllIIlIlll) {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/client/entity/EntityPlayerSP;
    //   5: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   8: ifeq -> 146
    //   11: aload_0
    //   12: invokestatic lllllIIIllIIlII : (Ljava/lang/Object;)Z
    //   15: ifeq -> 146
    //   18: aload_0
    //   19: <illegal opcode> 3 : ()Lnet/minecraft/client/entity/EntityPlayerSP;
    //   24: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   29: <illegal opcode> 89 : (Lnet/minecraft/entity/Entity;Ljava/lang/Object;)Z
    //   34: invokestatic lllllIIIllIIIIl : (I)Z
    //   37: ifeq -> 146
    //   40: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   43: iconst_1
    //   44: iaload
    //   45: ldc ''
    //   47: invokevirtual length : ()I
    //   50: pop
    //   51: ldc '   '
    //   53: invokevirtual length : ()I
    //   56: ldc '   '
    //   58: invokevirtual length : ()I
    //   61: ldc ' '
    //   63: invokevirtual length : ()I
    //   66: ineg
    //   67: ixor
    //   68: iand
    //   69: ldc '   '
    //   71: invokevirtual length : ()I
    //   74: ldc '   '
    //   76: invokevirtual length : ()I
    //   79: ldc ' '
    //   81: invokevirtual length : ()I
    //   84: ineg
    //   85: ixor
    //   86: iand
    //   87: if_icmpeq -> 151
    //   90: sipush #214
    //   93: sipush #149
    //   96: ixor
    //   97: ldc ' '
    //   99: invokevirtual length : ()I
    //   102: ishl
    //   103: sipush #143
    //   106: bipush #34
    //   108: iadd
    //   109: sipush #143
    //   112: isub
    //   113: sipush #133
    //   116: iadd
    //   117: ixor
    //   118: bipush #50
    //   120: bipush #53
    //   122: ixor
    //   123: ldc '   '
    //   125: invokevirtual length : ()I
    //   128: ishl
    //   129: sipush #223
    //   132: sipush #198
    //   135: ixor
    //   136: ixor
    //   137: ldc ' '
    //   139: invokevirtual length : ()I
    //   142: ineg
    //   143: ixor
    //   144: iand
    //   145: ireturn
    //   146: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   149: iconst_0
    //   150: iaload
    //   151: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	152	0	lllllllllllllllIlllIllIllIIlIlll	Lnet/minecraft/entity/Entity;
  }
  
  public static boolean isAboveWater(Entity lllllllllllllllIlllIllIllIIlIllI) {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 90 : (Lnet/minecraft/entity/Entity;Z)Z
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIllIllIIlIllI	Lnet/minecraft/entity/Entity;
  }
  
  public static boolean isAboveWater(Entity lllllllllllllllIlllIllIllIIlIIlI, boolean lllllllllllllllIlllIllIllIIlIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic lllllIIIllIIIll : (Ljava/lang/Object;)Z
    //   4: ifeq -> 13
    //   7: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: ireturn
    //   13: aload_0
    //   14: <illegal opcode> 6 : (Lnet/minecraft/entity/Entity;)D
    //   19: iload_1
    //   20: invokestatic lllllIIIllIIIIl : (I)Z
    //   23: ifeq -> 132
    //   26: ldc2_w 0.03
    //   29: ldc ''
    //   31: invokevirtual length : ()I
    //   34: pop
    //   35: ldc '   '
    //   37: invokevirtual length : ()I
    //   40: ldc '   '
    //   42: invokevirtual length : ()I
    //   45: if_icmpeq -> 195
    //   48: bipush #97
    //   50: sipush #165
    //   53: iadd
    //   54: sipush #236
    //   57: isub
    //   58: sipush #163
    //   61: iadd
    //   62: bipush #94
    //   64: bipush #115
    //   66: ixor
    //   67: ldc ' '
    //   69: invokevirtual length : ()I
    //   72: ldc ' '
    //   74: invokevirtual length : ()I
    //   77: ishl
    //   78: ishl
    //   79: ixor
    //   80: ldc '   '
    //   82: invokevirtual length : ()I
    //   85: ishl
    //   86: sipush #141
    //   89: sipush #148
    //   92: ixor
    //   93: ldc ' '
    //   95: invokevirtual length : ()I
    //   98: ldc ' '
    //   100: invokevirtual length : ()I
    //   103: ldc ' '
    //   105: invokevirtual length : ()I
    //   108: ldc ' '
    //   110: invokevirtual length : ()I
    //   113: ishl
    //   114: ishl
    //   115: ishl
    //   116: ixor
    //   117: ldc '   '
    //   119: invokevirtual length : ()I
    //   122: ishl
    //   123: ldc ' '
    //   125: invokevirtual length : ()I
    //   128: ineg
    //   129: ixor
    //   130: iand
    //   131: ireturn
    //   132: aload_0
    //   133: <illegal opcode> 91 : (Lnet/minecraft/entity/Entity;)Z
    //   138: invokestatic lllllIIIllIIIIl : (I)Z
    //   141: ifeq -> 192
    //   144: ldc2_w 0.2
    //   147: ldc ''
    //   149: invokevirtual length : ()I
    //   152: pop
    //   153: ldc '   '
    //   155: invokevirtual length : ()I
    //   158: ldc '   '
    //   160: invokevirtual length : ()I
    //   163: if_icmple -> 195
    //   166: bipush #85
    //   168: bipush #92
    //   170: ixor
    //   171: ldc '   '
    //   173: invokevirtual length : ()I
    //   176: ishl
    //   177: bipush #22
    //   179: bipush #31
    //   181: ixor
    //   182: ldc '   '
    //   184: invokevirtual length : ()I
    //   187: ishl
    //   188: iconst_m1
    //   189: ixor
    //   190: iand
    //   191: ireturn
    //   192: ldc2_w 0.5
    //   195: dsub
    //   196: dstore_2
    //   197: aload_0
    //   198: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   203: <illegal opcode> 42 : (D)I
    //   208: istore #4
    //   210: iload #4
    //   212: aload_0
    //   213: <illegal opcode> 4 : (Lnet/minecraft/entity/Entity;)D
    //   218: <illegal opcode> 86 : (D)I
    //   223: invokestatic lllllIIIllIlIII : (II)Z
    //   226: ifeq -> 406
    //   229: aload_0
    //   230: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   235: <illegal opcode> 42 : (D)I
    //   240: istore #5
    //   242: iload #5
    //   244: aload_0
    //   245: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;)D
    //   250: <illegal opcode> 86 : (D)I
    //   255: invokestatic lllllIIIllIlIII : (II)Z
    //   258: ifeq -> 379
    //   261: new net/minecraft/util/math/BlockPos
    //   264: dup
    //   265: iload #4
    //   267: dload_2
    //   268: <illegal opcode> 42 : (D)I
    //   273: iload #5
    //   275: invokespecial <init> : (III)V
    //   278: astore #6
    //   280: <illegal opcode> 87 : ()Lnet/minecraft/world/World;
    //   285: aload #6
    //   287: <illegal opcode> 88 : (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   292: <illegal opcode> 48 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   297: instanceof net/minecraft/block/BlockLiquid
    //   300: invokestatic lllllIIIllIIIIl : (I)Z
    //   303: ifeq -> 312
    //   306: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   309: iconst_1
    //   310: iaload
    //   311: ireturn
    //   312: iinc #5, 1
    //   315: ldc ''
    //   317: invokevirtual length : ()I
    //   320: pop
    //   321: bipush #28
    //   323: iconst_5
    //   324: ixor
    //   325: ldc ' '
    //   327: invokevirtual length : ()I
    //   330: ishl
    //   331: bipush #88
    //   333: bipush #65
    //   335: ixor
    //   336: ldc ' '
    //   338: invokevirtual length : ()I
    //   341: ishl
    //   342: iconst_m1
    //   343: ixor
    //   344: iand
    //   345: bipush #106
    //   347: bipush #83
    //   349: ixor
    //   350: sipush #254
    //   353: sipush #199
    //   356: ixor
    //   357: iconst_m1
    //   358: ixor
    //   359: iand
    //   360: if_icmpeq -> 242
    //   363: bipush #106
    //   365: bipush #49
    //   367: ixor
    //   368: sipush #226
    //   371: sipush #185
    //   374: ixor
    //   375: iconst_m1
    //   376: ixor
    //   377: iand
    //   378: ireturn
    //   379: iinc #4, 1
    //   382: ldc ''
    //   384: invokevirtual length : ()I
    //   387: pop
    //   388: aconst_null
    //   389: ifnull -> 210
    //   392: bipush #87
    //   394: bipush #12
    //   396: ixor
    //   397: bipush #122
    //   399: bipush #33
    //   401: ixor
    //   402: iconst_m1
    //   403: ixor
    //   404: iand
    //   405: ireturn
    //   406: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   409: iconst_0
    //   410: iaload
    //   411: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   280	32	6	lllllllllllllllIlllIllIllIIlIlIl	Lnet/minecraft/util/math/BlockPos;
    //   242	137	5	lllllllllllllllIlllIllIllIIlIlII	I
    //   210	196	4	lllllllllllllllIlllIllIllIIlIIll	I
    //   0	412	0	lllllllllllllllIlllIllIllIIlIIlI	Lnet/minecraft/entity/Entity;
    //   0	412	1	lllllllllllllllIlllIllIllIIlIIIl	Z
    //   197	215	2	lllllllllllllllIlllIllIllIIlIIII	D
  }
  
  public static double[] calculateLookAt(double lllllllllllllllIlllIllIllIIIllll, double lllllllllllllllIlllIllIllIIIlllI, double lllllllllllllllIlllIllIllIIIllIl, EntityPlayer lllllllllllllllIlllIllIllIIIllII) {
    // Byte code:
    //   0: aload #6
    //   2: <illegal opcode> 92 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   7: dload_0
    //   8: dsub
    //   9: dstore #7
    //   11: aload #6
    //   13: <illegal opcode> 93 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   18: dload_2
    //   19: dsub
    //   20: dstore #9
    //   22: aload #6
    //   24: <illegal opcode> 94 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   29: dload #4
    //   31: dsub
    //   32: dstore #11
    //   34: dload #7
    //   36: dload #7
    //   38: dmul
    //   39: dload #9
    //   41: dload #9
    //   43: dmul
    //   44: dadd
    //   45: dload #11
    //   47: dload #11
    //   49: dmul
    //   50: dadd
    //   51: <illegal opcode> 95 : (D)D
    //   56: dstore #13
    //   58: dload #7
    //   60: dload #13
    //   62: ddiv
    //   63: dstore #7
    //   65: dload #9
    //   67: dload #13
    //   69: ddiv
    //   70: dstore #9
    //   72: dload #11
    //   74: dload #13
    //   76: ddiv
    //   77: dstore #11
    //   79: dload #9
    //   81: <illegal opcode> 96 : (D)D
    //   86: dstore #15
    //   88: dload #11
    //   90: dload #7
    //   92: <illegal opcode> 97 : (DD)D
    //   97: dstore #17
    //   99: dload #15
    //   101: ldc2_w 180.0
    //   104: dmul
    //   105: ldc2_w 3.141592653589793
    //   108: ddiv
    //   109: dstore #15
    //   111: dload #17
    //   113: ldc2_w 180.0
    //   116: dmul
    //   117: ldc2_w 3.141592653589793
    //   120: ddiv
    //   121: dstore #17
    //   123: dload #17
    //   125: ldc2_w 90.0
    //   128: dadd
    //   129: dstore #17
    //   131: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   134: iconst_3
    //   135: iaload
    //   136: newarray double
    //   138: dup
    //   139: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   142: iconst_0
    //   143: iaload
    //   144: dload #17
    //   146: dastore
    //   147: dup
    //   148: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   151: iconst_1
    //   152: iaload
    //   153: dload #15
    //   155: dastore
    //   156: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	157	0	lllllllllllllllIlllIllIllIIIllll	D
    //   0	157	2	lllllllllllllllIlllIllIllIIIlllI	D
    //   0	157	4	lllllllllllllllIlllIllIllIIIllIl	D
    //   0	157	6	lllllllllllllllIlllIllIllIIIllII	Lnet/minecraft/entity/player/EntityPlayer;
    //   11	146	7	lllllllllllllllIlllIllIllIIIlIll	D
    //   22	135	9	lllllllllllllllIlllIllIllIIIlIlI	D
    //   34	123	11	lllllllllllllllIlllIllIllIIIlIIl	D
    //   58	99	13	lllllllllllllllIlllIllIllIIIlIII	D
    //   88	69	15	lllllllllllllllIlllIllIllIIIIlll	D
    //   99	58	17	lllllllllllllllIlllIllIllIIIIllI	D
  }
  
  public static boolean isPlayer(Entity lllllllllllllllIlllIllIllIIIIlIl) {
    return lllllllllllllllIlllIllIllIIIIlIl instanceof EntityPlayer;
  }
  
  public static double getRelativeX(float lllllllllllllllIlllIllIllIIIIlII) {
    // Byte code:
    //   0: fload_0
    //   1: fneg
    //   2: ldc_w 0.017453292
    //   5: fmul
    //   6: <illegal opcode> 98 : (F)F
    //   11: f2d
    //   12: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIlllIllIllIIIIlII	F
  }
  
  public static double getRelativeZ(float lllllllllllllllIlllIllIllIIIIIll) {
    // Byte code:
    //   0: fload_0
    //   1: ldc_w 0.017453292
    //   4: fmul
    //   5: <illegal opcode> 99 : (F)F
    //   10: f2d
    //   11: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIllIllIIIIIll	F
  }
  
  public static float clamp(float lllllllllllllllIlllIllIllIIIIIlI, float lllllllllllllllIlllIllIllIIIIIIl, float lllllllllllllllIlllIllIllIIIIIII) {
    if (lllllIIIlllIIlI(lllllIIIlllIIII(lllllllllllllllIlllIllIllIIIIIlI, lllllllllllllllIlllIllIllIIIIIIl)))
      lllllllllllllllIlllIllIllIIIIIlI = lllllllllllllllIlllIllIllIIIIIIl; 
    if (lllllIIIllIlIlI(lllllIIIlllIIIl(lllllllllllllllIlllIllIllIIIIIlI, lllllllllllllllIlllIllIllIIIIIII)))
      lllllllllllllllIlllIllIllIIIIIlI = lllllllllllllllIlllIllIllIIIIIII; 
    return lllllllllllllllIlllIllIllIIIIIlI;
  }
  
  public static double getSpeed() {
    // Byte code:
    //   0: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 100 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   15: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   20: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   25: <illegal opcode> 101 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   30: dsub
    //   31: dstore_0
    //   32: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   37: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   42: <illegal opcode> 102 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   47: <illegal opcode> 11 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 103 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   62: dsub
    //   63: dstore_2
    //   64: ldc_w 0.02
    //   67: fstore #4
    //   69: dload_0
    //   70: dload_0
    //   71: dmul
    //   72: dload_2
    //   73: dload_2
    //   74: dmul
    //   75: dadd
    //   76: <illegal opcode> 104 : (D)F
    //   81: ldc_w 0.02
    //   84: fdiv
    //   85: f2d
    //   86: dstore #5
    //   88: dload #5
    //   90: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   32	59	0	lllllllllllllllIlllIllIlIlllllll	D
    //   64	27	2	lllllllllllllllIlllIllIlIllllllI	D
    //   69	22	4	lllllllllllllllIlllIllIlIlllllIl	F
    //   88	3	5	lllllllllllllllIlllIllIlIlllllII	D
  }
  
  public static double[] directionSpeed(double lllllllllllllllIlllIllIlIllllIll) {
    // Byte code:
    //   0: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   5: astore_2
    //   6: aload_2
    //   7: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   12: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   17: <illegal opcode> 62 : (Lnet/minecraft/util/MovementInput;)F
    //   22: fstore_3
    //   23: aload_2
    //   24: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/MovementInput;
    //   34: <illegal opcode> 63 : (Lnet/minecraft/util/MovementInput;)F
    //   39: fstore #4
    //   41: aload_2
    //   42: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   47: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   52: aload_2
    //   53: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   58: <illegal opcode> 65 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   63: aload_2
    //   64: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   69: <illegal opcode> 64 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   74: fsub
    //   75: aload_2
    //   76: <illegal opcode> 66 : (Lnet/minecraft/client/Minecraft;)F
    //   81: fmul
    //   82: fadd
    //   83: fstore #5
    //   85: fload_3
    //   86: fconst_0
    //   87: invokestatic lllllIIIlllIIll : (FF)I
    //   90: invokestatic lllllIIIllIIIIl : (I)Z
    //   93: ifeq -> 356
    //   96: fload #4
    //   98: fconst_0
    //   99: invokestatic lllllIIIlllIIll : (FF)I
    //   102: invokestatic lllllIIIllIIlll : (I)Z
    //   105: ifeq -> 204
    //   108: fload #5
    //   110: fload_3
    //   111: fconst_0
    //   112: invokestatic lllllIIIlllIIll : (FF)I
    //   115: invokestatic lllllIIIllIIlll : (I)Z
    //   118: ifeq -> 160
    //   121: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   124: bipush #12
    //   126: iaload
    //   127: ldc ''
    //   129: invokevirtual length : ()I
    //   132: pop
    //   133: ldc ' '
    //   135: invokevirtual length : ()I
    //   138: ldc ' '
    //   140: invokevirtual length : ()I
    //   143: ldc ' '
    //   145: invokevirtual length : ()I
    //   148: ldc ' '
    //   150: invokevirtual length : ()I
    //   153: ishl
    //   154: ishl
    //   155: if_icmple -> 166
    //   158: aconst_null
    //   159: areturn
    //   160: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   163: bipush #13
    //   165: iaload
    //   166: i2f
    //   167: fadd
    //   168: fstore #5
    //   170: ldc ''
    //   172: invokevirtual length : ()I
    //   175: pop
    //   176: ldc ' '
    //   178: invokevirtual length : ()I
    //   181: ldc ' '
    //   183: invokevirtual length : ()I
    //   186: ldc ' '
    //   188: invokevirtual length : ()I
    //   191: ishl
    //   192: ishl
    //   193: ldc ' '
    //   195: invokevirtual length : ()I
    //   198: ineg
    //   199: if_icmpgt -> 284
    //   202: aconst_null
    //   203: areturn
    //   204: fload #4
    //   206: fconst_0
    //   207: invokestatic lllllIIIlllIlII : (FF)I
    //   210: invokestatic lllllIIIllIlllI : (I)Z
    //   213: ifeq -> 284
    //   216: fload #5
    //   218: fload_3
    //   219: fconst_0
    //   220: invokestatic lllllIIIlllIIll : (FF)I
    //   223: invokestatic lllllIIIllIIlll : (I)Z
    //   226: ifeq -> 274
    //   229: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   232: bipush #13
    //   234: iaload
    //   235: ldc ''
    //   237: invokevirtual length : ()I
    //   240: pop
    //   241: ldc ' '
    //   243: invokevirtual length : ()I
    //   246: ldc ' '
    //   248: invokevirtual length : ()I
    //   251: ishl
    //   252: ldc ' '
    //   254: invokevirtual length : ()I
    //   257: ldc ' '
    //   259: invokevirtual length : ()I
    //   262: ldc ' '
    //   264: invokevirtual length : ()I
    //   267: ishl
    //   268: ishl
    //   269: if_icmplt -> 280
    //   272: aconst_null
    //   273: areturn
    //   274: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   277: bipush #12
    //   279: iaload
    //   280: i2f
    //   281: fadd
    //   282: fstore #5
    //   284: fconst_0
    //   285: fstore #4
    //   287: fload_3
    //   288: fconst_0
    //   289: invokestatic lllllIIIlllIIll : (FF)I
    //   292: invokestatic lllllIIIllIIlll : (I)Z
    //   295: ifeq -> 341
    //   298: fconst_1
    //   299: fstore_3
    //   300: ldc ''
    //   302: invokevirtual length : ()I
    //   305: pop
    //   306: ldc '   '
    //   308: invokevirtual length : ()I
    //   311: ldc ' '
    //   313: invokevirtual length : ()I
    //   316: ldc ' '
    //   318: invokevirtual length : ()I
    //   321: ishl
    //   322: ishl
    //   323: ldc ' '
    //   325: invokevirtual length : ()I
    //   328: ldc '   '
    //   330: invokevirtual length : ()I
    //   333: ishl
    //   334: ixor
    //   335: ineg
    //   336: ifle -> 356
    //   339: aconst_null
    //   340: areturn
    //   341: fload_3
    //   342: fconst_0
    //   343: invokestatic lllllIIIlllIlII : (FF)I
    //   346: invokestatic lllllIIIllIlllI : (I)Z
    //   349: ifeq -> 356
    //   352: ldc_w -1.0
    //   355: fstore_3
    //   356: fload #5
    //   358: ldc_w 90.0
    //   361: fadd
    //   362: f2d
    //   363: <illegal opcode> 67 : (D)D
    //   368: <illegal opcode> 68 : (D)D
    //   373: dstore #6
    //   375: fload #5
    //   377: ldc_w 90.0
    //   380: fadd
    //   381: f2d
    //   382: <illegal opcode> 67 : (D)D
    //   387: <illegal opcode> 69 : (D)D
    //   392: dstore #8
    //   394: fload_3
    //   395: f2d
    //   396: dload_0
    //   397: dmul
    //   398: dload #8
    //   400: dmul
    //   401: fload #4
    //   403: f2d
    //   404: dload_0
    //   405: dmul
    //   406: dload #6
    //   408: dmul
    //   409: dadd
    //   410: dstore #10
    //   412: fload_3
    //   413: f2d
    //   414: dload_0
    //   415: dmul
    //   416: dload #6
    //   418: dmul
    //   419: fload #4
    //   421: f2d
    //   422: dload_0
    //   423: dmul
    //   424: dload #8
    //   426: dmul
    //   427: dsub
    //   428: dstore #12
    //   430: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   433: iconst_3
    //   434: iaload
    //   435: newarray double
    //   437: dup
    //   438: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   441: iconst_0
    //   442: iaload
    //   443: dload #10
    //   445: dastore
    //   446: dup
    //   447: getstatic me/stupitdog/bhp/fq.lIlllIIlIllllI : [I
    //   450: iconst_1
    //   451: iaload
    //   452: dload #12
    //   454: dastore
    //   455: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	456	0	lllllllllllllllIlllIllIlIllllIll	D
    //   6	450	2	lllllllllllllllIlllIllIlIllllIlI	Lnet/minecraft/client/Minecraft;
    //   23	433	3	lllllllllllllllIlllIllIlIllllIIl	F
    //   41	415	4	lllllllllllllllIlllIllIlIllllIII	F
    //   85	371	5	lllllllllllllllIlllIllIlIlllIlll	F
    //   375	81	6	lllllllllllllllIlllIllIlIlllIllI	D
    //   394	62	8	lllllllllllllllIlllIllIlIlllIlIl	D
    //   412	44	10	lllllllllllllllIlllIllIlIlllIlII	D
    //   430	26	12	lllllllllllllllIlllIllIlIlllIIll	D
  }
  
  static {
    // Byte code:
    //   0: invokestatic lllllIIIllIIIII : ()V
    //   3: invokestatic lllllIIIlIlllll : ()V
    //   6: invokestatic lllllIIIlIllllI : ()V
    //   9: invokestatic lllllIIIlIllIIl : ()V
    //   12: <illegal opcode> 54 : ()Lnet/minecraft/client/Minecraft;
    //   17: putstatic me/stupitdog/bhp/fq.mc : Lnet/minecraft/client/Minecraft;
    //   20: <illegal opcode> 105 : ()Ljava/util/concurrent/ConcurrentMap;
    //   25: putstatic me/stupitdog/bhp/fq.uuidNameCache : Ljava/util/Map;
    //   28: return
  }
  
  private static CallSite llllIlIlIIIIIII(MethodHandles.Lookup lllllllllllllllIlllIllIlIllIlIlI, String lllllllllllllllIlllIllIlIllIlIIl, MethodType lllllllllllllllIlllIllIlIllIlIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllIlIlllIIII = lIllIllIIlIllI[Integer.parseInt(lllllllllllllllIlllIllIlIllIlIIl)].split(lIlllIIlIllIlI[lIlllIIlIllllI[14]]);
      Class<?> lllllllllllllllIlllIllIlIllIllll = Class.forName(lllllllllllllllIlllIllIlIlllIIII[lIlllIIlIllllI[0]]);
      String lllllllllllllllIlllIllIlIllIlllI = lllllllllllllllIlllIllIlIlllIIII[lIlllIIlIllllI[1]];
      MethodHandle lllllllllllllllIlllIllIlIllIllIl = null;
      int lllllllllllllllIlllIllIlIllIllII = lllllllllllllllIlllIllIlIlllIIII[lIlllIIlIllllI[4]].length();
      if (lllllIIIlllIlIl(lllllllllllllllIlllIllIlIllIllII, lIlllIIlIllllI[3])) {
        MethodType lllllllllllllllIlllIllIlIlllIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllIlIlllIIII[lIlllIIlIllllI[3]], fq.class.getClassLoader());
        if (lllllIIIllIIlIl(lllllllllllllllIlllIllIlIllIllII, lIlllIIlIllllI[3])) {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findVirtual(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIlI);
          "".length();
          if (-" ".length() >= ((0x2 ^ 0x2B) & (0x9D ^ 0xB4 ^ 0xFFFFFFFF)))
            return null; 
        } else {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findStatic(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIlI);
        } 
        "".length();
        if (((" ".length() << " ".length() << " ".length() ^ 0x4D ^ 0x40) << " ".length() << " ".length() & ((" ".length() << " ".length() ^ 0xB ^ 0x0) << " ".length() << " ".length() ^ -" ".length())) > "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllIlIlllIIIl = lIllIllIIlIlll[Integer.parseInt(lllllllllllllllIlllIllIlIlllIIII[lIlllIIlIllllI[3]])];
        if (lllllIIIllIIlIl(lllllllllllllllIlllIllIlIllIllII, lIlllIIlIllllI[4])) {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findGetter(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIIl);
          "".length();
          if (" ".length() == " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lllllIIIllIIlIl(lllllllllllllllIlllIllIlIllIllII, lIlllIIlIllllI[5])) {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findStaticGetter(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIIIllIIlIl(lllllllllllllllIlllIllIlIllIllII, lIlllIIlIllllI[6])) {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findSetter(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIIl);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIllIlIllIllIl = lllllllllllllllIlllIllIlIllIlIlI.findStaticSetter(lllllllllllllllIlllIllIlIllIllll, lllllllllllllllIlllIllIlIllIlllI, lllllllllllllllIlllIllIlIlllIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllIlIllIllIl);
    } catch (Exception lllllllllllllllIlllIllIlIllIlIll) {
      lllllllllllllllIlllIllIlIllIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIlIllIIl() {
    lIllIllIIlIllI = new String[lIlllIIlIllllI[15]];
    lIllIllIIlIllI[lIlllIIlIllllI[6]] = lIlllIIlIllIlI[lIlllIIlIllllI[16]];
    lIllIllIIlIllI[lIlllIIlIllllI[17]] = lIlllIIlIllIlI[lIlllIIlIllllI[18]];
    lIllIllIIlIllI[lIlllIIlIllllI[19]] = lIlllIIlIllIlI[lIlllIIlIllllI[20]];
    lIllIllIIlIllI[lIlllIIlIllllI[21]] = lIlllIIlIllIlI[lIlllIIlIllllI[22]];
    lIllIllIIlIllI[lIlllIIlIllllI[23]] = lIlllIIlIllIlI[lIlllIIlIllllI[24]];
    lIllIllIIlIllI[lIlllIIlIllllI[8]] = lIlllIIlIllIlI[lIlllIIlIllllI[25]];
    lIllIllIIlIllI[lIlllIIlIllllI[26]] = lIlllIIlIllIlI[lIlllIIlIllllI[27]];
    lIllIllIIlIllI[lIlllIIlIllllI[28]] = lIlllIIlIllIlI[lIlllIIlIllllI[29]];
    lIllIllIIlIllI[lIlllIIlIllllI[30]] = lIlllIIlIllIlI[lIlllIIlIllllI[31]];
    lIllIllIIlIllI[lIlllIIlIllllI[32]] = lIlllIIlIllIlI[lIlllIIlIllllI[33]];
    lIllIllIIlIllI[lIlllIIlIllllI[34]] = lIlllIIlIllIlI[lIlllIIlIllllI[35]];
    lIllIllIIlIllI[lIlllIIlIllllI[36]] = lIlllIIlIllIlI[lIlllIIlIllllI[17]];
    lIllIllIIlIllI[lIlllIIlIllllI[37]] = lIlllIIlIllIlI[lIlllIIlIllllI[38]];
    lIllIllIIlIllI[lIlllIIlIllllI[39]] = lIlllIIlIllIlI[lIlllIIlIllllI[40]];
    lIllIllIIlIllI[lIlllIIlIllllI[33]] = lIlllIIlIllIlI[lIlllIIlIllllI[41]];
    lIllIllIIlIllI[lIlllIIlIllllI[22]] = lIlllIIlIllIlI[lIlllIIlIllllI[42]];
    lIllIllIIlIllI[lIlllIIlIllllI[43]] = lIlllIIlIllIlI[lIlllIIlIllllI[44]];
    lIllIllIIlIllI[lIlllIIlIllllI[31]] = lIlllIIlIllIlI[lIlllIIlIllllI[45]];
    lIllIllIIlIllI[lIlllIIlIllllI[10]] = lIlllIIlIllIlI[lIlllIIlIllllI[46]];
    lIllIllIIlIllI[lIlllIIlIllllI[24]] = lIlllIIlIllIlI[lIlllIIlIllllI[47]];
    lIllIllIIlIllI[lIlllIIlIllllI[48]] = lIlllIIlIllIlI[lIlllIIlIllllI[49]];
    lIllIllIIlIllI[lIlllIIlIllllI[16]] = lIlllIIlIllIlI[lIlllIIlIllllI[50]];
    lIllIllIIlIllI[lIlllIIlIllllI[4]] = lIlllIIlIllIlI[lIlllIIlIllllI[51]];
    lIllIllIIlIllI[lIlllIIlIllllI[52]] = lIlllIIlIllIlI[lIlllIIlIllllI[53]];
    lIllIllIIlIllI[lIlllIIlIllllI[45]] = lIlllIIlIllIlI[lIlllIIlIllllI[54]];
    lIllIllIIlIllI[lIlllIIlIllllI[55]] = lIlllIIlIllIlI[lIlllIIlIllllI[56]];
    lIllIllIIlIllI[lIlllIIlIllllI[57]] = lIlllIIlIllIlI[lIlllIIlIllllI[58]];
    lIllIllIIlIllI[lIlllIIlIllllI[59]] = lIlllIIlIllIlI[lIlllIIlIllllI[60]];
    lIllIllIIlIllI[lIlllIIlIllllI[35]] = lIlllIIlIllIlI[lIlllIIlIllllI[61]];
    lIllIllIIlIllI[lIlllIIlIllllI[58]] = lIlllIIlIllIlI[lIlllIIlIllllI[62]];
    lIllIllIIlIllI[lIlllIIlIllllI[1]] = lIlllIIlIllIlI[lIlllIIlIllllI[63]];
    lIllIllIIlIllI[lIlllIIlIllllI[64]] = lIlllIIlIllIlI[lIlllIIlIllllI[65]];
    lIllIllIIlIllI[lIlllIIlIllllI[66]] = lIlllIIlIllIlI[lIlllIIlIllllI[67]];
    lIllIllIIlIllI[lIlllIIlIllllI[40]] = lIlllIIlIllIlI[lIlllIIlIllllI[13]];
    lIllIllIIlIllI[lIlllIIlIllllI[51]] = lIlllIIlIllIlI[lIlllIIlIllllI[68]];
    lIllIllIIlIllI[lIlllIIlIllllI[69]] = lIlllIIlIllIlI[lIlllIIlIllllI[70]];
    lIllIllIIlIllI[lIlllIIlIllllI[18]] = lIlllIIlIllIlI[lIlllIIlIllllI[30]];
    lIllIllIIlIllI[lIlllIIlIllllI[71]] = lIlllIIlIllIlI[lIlllIIlIllllI[26]];
    lIllIllIIlIllI[lIlllIIlIllllI[72]] = lIlllIIlIllIlI[lIlllIIlIllllI[43]];
    lIllIllIIlIllI[lIlllIIlIllllI[73]] = lIlllIIlIllIlI[lIlllIIlIllllI[74]];
    lIllIllIIlIllI[lIlllIIlIllllI[7]] = lIlllIIlIllIlI[lIlllIIlIllllI[75]];
    lIllIllIIlIllI[lIlllIIlIllllI[42]] = lIlllIIlIllIlI[lIlllIIlIllllI[28]];
    lIllIllIIlIllI[lIlllIIlIllllI[75]] = lIlllIIlIllIlI[lIlllIIlIllllI[23]];
    lIllIllIIlIllI[lIlllIIlIllllI[76]] = lIlllIIlIllIlI[lIlllIIlIllllI[77]];
    lIllIllIIlIllI[lIlllIIlIllllI[78]] = lIlllIIlIllIlI[lIlllIIlIllllI[79]];
    lIllIllIIlIllI[lIlllIIlIllllI[56]] = lIlllIIlIllIlI[lIlllIIlIllllI[39]];
    lIllIllIIlIllI[lIlllIIlIllllI[49]] = lIlllIIlIllIlI[lIlllIIlIllllI[80]];
    lIllIllIIlIllI[lIlllIIlIllllI[81]] = lIlllIIlIllIlI[lIlllIIlIllllI[82]];
    lIllIllIIlIllI[lIlllIIlIllllI[29]] = lIlllIIlIllIlI[lIlllIIlIllllI[83]];
    lIllIllIIlIllI[lIlllIIlIllllI[84]] = lIlllIIlIllIlI[lIlllIIlIllllI[85]];
    lIllIllIIlIllI[lIlllIIlIllllI[86]] = lIlllIIlIllIlI[lIlllIIlIllllI[87]];
    lIllIllIIlIllI[lIlllIIlIllllI[68]] = lIlllIIlIllIlI[lIlllIIlIllllI[73]];
    lIllIllIIlIllI[lIlllIIlIllllI[88]] = lIlllIIlIllIlI[lIlllIIlIllllI[89]];
    lIllIllIIlIllI[lIlllIIlIllllI[25]] = lIlllIIlIllIlI[lIlllIIlIllllI[84]];
    lIllIllIIlIllI[lIlllIIlIllllI[79]] = lIlllIIlIllIlI[lIlllIIlIllllI[86]];
    lIllIllIIlIllI[lIlllIIlIllllI[90]] = lIlllIIlIllIlI[lIlllIIlIllllI[91]];
    lIllIllIIlIllI[lIlllIIlIllllI[89]] = lIlllIIlIllIlI[lIlllIIlIllllI[76]];
    lIllIllIIlIllI[lIlllIIlIllllI[92]] = lIlllIIlIllIlI[lIlllIIlIllllI[81]];
    lIllIllIIlIllI[lIlllIIlIllllI[93]] = lIlllIIlIllIlI[lIlllIIlIllllI[94]];
    lIllIllIIlIllI[lIlllIIlIllllI[77]] = lIlllIIlIllIlI[lIlllIIlIllllI[59]];
    lIllIllIIlIllI[lIlllIIlIllllI[94]] = lIlllIIlIllIlI[lIlllIIlIllllI[71]];
    lIllIllIIlIllI[lIlllIIlIllllI[82]] = lIlllIIlIllIlI[lIlllIIlIllllI[90]];
    lIllIllIIlIllI[lIlllIIlIllllI[95]] = lIlllIIlIllIlI[lIlllIIlIllllI[96]];
    lIllIllIIlIllI[lIlllIIlIllllI[61]] = lIlllIIlIllIlI[lIlllIIlIllllI[37]];
    lIllIllIIlIllI[lIlllIIlIllllI[60]] = lIlllIIlIllIlI[lIlllIIlIllllI[97]];
    lIllIllIIlIllI[lIlllIIlIllllI[85]] = lIlllIIlIllIlI[lIlllIIlIllllI[98]];
    lIllIllIIlIllI[lIlllIIlIllllI[44]] = lIlllIIlIllIlI[lIlllIIlIllllI[32]];
    lIllIllIIlIllI[lIlllIIlIllllI[99]] = lIlllIIlIllIlI[lIlllIIlIllllI[78]];
    lIllIllIIlIllI[lIlllIIlIllllI[91]] = lIlllIIlIllIlI[lIlllIIlIllllI[92]];
    lIllIllIIlIllI[lIlllIIlIllllI[74]] = lIlllIIlIllIlI[lIlllIIlIllllI[36]];
    lIllIllIIlIllI[lIlllIIlIllllI[47]] = lIlllIIlIllIlI[lIlllIIlIllllI[48]];
    lIllIllIIlIllI[lIlllIIlIllllI[14]] = lIlllIIlIllIlI[lIlllIIlIllllI[99]];
    lIllIllIIlIllI[lIlllIIlIllllI[53]] = lIlllIIlIllIlI[lIlllIIlIllllI[100]];
    lIllIllIIlIllI[lIlllIIlIllllI[9]] = lIlllIIlIllIlI[lIlllIIlIllllI[101]];
    lIllIllIIlIllI[lIlllIIlIllllI[98]] = lIlllIIlIllIlI[lIlllIIlIllllI[102]];
    lIllIllIIlIllI[lIlllIIlIllllI[46]] = lIlllIIlIllIlI[lIlllIIlIllllI[34]];
    lIllIllIIlIllI[lIlllIIlIllllI[3]] = lIlllIIlIllIlI[lIlllIIlIllllI[21]];
    lIllIllIIlIllI[lIlllIIlIllllI[13]] = lIlllIIlIllIlI[lIlllIIlIllllI[95]];
    lIllIllIIlIllI[lIlllIIlIllllI[54]] = lIlllIIlIllIlI[lIlllIIlIllllI[64]];
    lIllIllIIlIllI[lIlllIIlIllllI[0]] = lIlllIIlIllIlI[lIlllIIlIllllI[103]];
    lIllIllIIlIllI[lIlllIIlIllllI[103]] = lIlllIIlIllIlI[lIlllIIlIllllI[57]];
    lIllIllIIlIllI[lIlllIIlIllllI[11]] = lIlllIIlIllIlI[lIlllIIlIllllI[55]];
    lIllIllIIlIllI[lIlllIIlIllllI[63]] = lIlllIIlIllIlI[lIlllIIlIllllI[104]];
    lIllIllIIlIllI[lIlllIIlIllllI[83]] = lIlllIIlIllIlI[lIlllIIlIllllI[69]];
    lIllIllIIlIllI[lIlllIIlIllllI[104]] = lIlllIIlIllIlI[lIlllIIlIllllI[19]];
    lIllIllIIlIllI[lIlllIIlIllllI[38]] = lIlllIIlIllIlI[lIlllIIlIllllI[88]];
    lIllIllIIlIllI[lIlllIIlIllllI[105]] = lIlllIIlIllIlI[lIlllIIlIllllI[66]];
    lIllIllIIlIllI[lIlllIIlIllllI[50]] = lIlllIIlIllIlI[lIlllIIlIllllI[106]];
    lIllIllIIlIllI[lIlllIIlIllllI[101]] = lIlllIIlIllIlI[lIlllIIlIllllI[105]];
    lIllIllIIlIllI[lIlllIIlIllllI[107]] = lIlllIIlIllIlI[lIlllIIlIllllI[52]];
    lIllIllIIlIllI[lIlllIIlIllllI[102]] = lIlllIIlIllIlI[lIlllIIlIllllI[107]];
    lIllIllIIlIllI[lIlllIIlIllllI[5]] = lIlllIIlIllIlI[lIlllIIlIllllI[93]];
    lIllIllIIlIllI[lIlllIIlIllllI[65]] = lIlllIIlIllIlI[lIlllIIlIllllI[108]];
    lIllIllIIlIllI[lIlllIIlIllllI[70]] = lIlllIIlIllIlI[lIlllIIlIllllI[72]];
    lIllIllIIlIllI[lIlllIIlIllllI[106]] = lIlllIIlIllIlI[lIlllIIlIllllI[15]];
    lIllIllIIlIllI[lIlllIIlIllllI[20]] = lIlllIIlIllIlI[lIlllIIlIllllI[109]];
    lIllIllIIlIllI[lIlllIIlIllllI[41]] = lIlllIIlIllIlI[lIlllIIlIllllI[110]];
    lIllIllIIlIllI[lIlllIIlIllllI[80]] = lIlllIIlIllIlI[lIlllIIlIllllI[111]];
    lIllIllIIlIllI[lIlllIIlIllllI[97]] = lIlllIIlIllIlI[lIlllIIlIllllI[112]];
    lIllIllIIlIllI[lIlllIIlIllllI[87]] = lIlllIIlIllIlI[lIlllIIlIllllI[113]];
    lIllIllIIlIllI[lIlllIIlIllllI[62]] = lIlllIIlIllIlI[lIlllIIlIllllI[114]];
    lIllIllIIlIllI[lIlllIIlIllllI[96]] = lIlllIIlIllIlI[lIlllIIlIllllI[115]];
    lIllIllIIlIllI[lIlllIIlIllllI[67]] = lIlllIIlIllIlI[lIlllIIlIllllI[116]];
    lIllIllIIlIllI[lIlllIIlIllllI[100]] = lIlllIIlIllIlI[lIlllIIlIllllI[117]];
    lIllIllIIlIllI[lIlllIIlIllllI[27]] = lIlllIIlIllIlI[lIlllIIlIllllI[118]];
    lIllIllIIlIllI[lIlllIIlIllllI[108]] = lIlllIIlIllIlI[lIlllIIlIllllI[119]];
    lIllIllIIlIlll = new Class[lIlllIIlIllllI[11]];
    lIllIllIIlIlll[lIlllIIlIllllI[5]] = WorldClient.class;
    lIllIllIIlIlll[lIlllIIlIllllI[7]] = Block.class;
    lIllIllIIlIlll[lIlllIIlIllllI[6]] = float.class;
    lIllIllIIlIlll[lIlllIIlIllllI[9]] = MovementInput.class;
    lIllIllIIlIlll[lIlllIIlIllllI[3]] = Map.class;
    lIllIllIIlIlll[lIlllIIlIllllI[8]] = Timer.class;
    lIllIllIIlIlll[lIlllIIlIllllI[1]] = Minecraft.class;
    lIllIllIIlIlll[lIlllIIlIllllI[4]] = EntityPlayerSP.class;
    lIllIllIIlIlll[lIlllIIlIllllI[0]] = double.class;
    lIllIllIIlIlll[lIlllIIlIllllI[10]] = EnumCreatureType.class;
  }
  
  private static void lllllIIIlIllllI() {
    lIlllIIlIllIlI = new String[lIlllIIlIllllI[120]];
    lIlllIIlIllIlI[lIlllIIlIllllI[0]] = lllllIIIlIllIlI(lIlllIIlIlllIl[lIlllIIlIllllI[0]], lIlllIIlIlllIl[lIlllIIlIllllI[1]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[1]] = lllllIIIlIllIlI(lIlllIIlIlllIl[lIlllIIlIllllI[3]], lIlllIIlIlllIl[lIlllIIlIllllI[4]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[3]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[5]], lIlllIIlIlllIl[lIlllIIlIllllI[6]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[4]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[7]], lIlllIIlIlllIl[lIlllIIlIllllI[8]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[5]] = lllllIIIlIlllII(lIlllIIlIlllIl[lIlllIIlIllllI[9]], lIlllIIlIlllIl[lIlllIIlIllllI[10]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[6]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[11]], lIlllIIlIlllIl[lIlllIIlIllllI[14]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[7]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[16]], lIlllIIlIlllIl[lIlllIIlIllllI[18]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[8]] = lllllIIIlIllIlI(lIlllIIlIlllIl[lIlllIIlIllllI[20]], lIlllIIlIlllIl[lIlllIIlIllllI[22]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[9]] = lllllIIIlIllIlI(lIlllIIlIlllIl[lIlllIIlIllllI[24]], lIlllIIlIlllIl[lIlllIIlIllllI[25]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[10]] = lllllIIIlIlllII(lIlllIIlIlllIl[lIlllIIlIllllI[27]], lIlllIIlIlllIl[lIlllIIlIllllI[29]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[11]] = lllllIIIlIllIlI(lIlllIIlIlllIl[lIlllIIlIllllI[31]], lIlllIIlIlllIl[lIlllIIlIllllI[33]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[14]] = lllllIIIlIlllII(lIlllIIlIlllIl[lIlllIIlIllllI[35]], lIlllIIlIlllIl[lIlllIIlIllllI[17]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[16]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[38]], lIlllIIlIlllIl[lIlllIIlIllllI[40]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[18]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[41]], lIlllIIlIlllIl[lIlllIIlIllllI[42]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[20]] = lllllIIIlIllIll(lIlllIIlIlllIl[lIlllIIlIllllI[44]], lIlllIIlIlllIl[lIlllIIlIllllI[45]]);
    lIlllIIlIllIlI[lIlllIIlIllllI[22]] = lllllIIIlIlllII("SJw2Y0ggqhWjlxdqCzx15bNEbd2J47ETsHRYT55vkga9dsWvgzOUzsYkZrazgMrtwzFwaFGGYLs6QVHz2LQvS8UlIPzR7Czrz5udlsOXPgMixPul4UcXNlFScLHSKMBpK2d1xkb1NbLqT8X2p45g3x+WC4bLaIvn", "HIMIk");
    lIlllIIlIllIlI[lIlllIIlIllllI[24]] = lllllIIIlIlllII("YcBrRZsZxVVsLt76tNq4RxARwA11drhhuVV2bbO+O5jaJwF2gV4qrkjksPZp4n4CFroDrvTOFQAqUAqmyH8Nh7xEtM4dGxvmrfADgxKR1GmLcvl8y/CRqA==", "fNmaB");
    lIlllIIlIllIlI[lIlllIIlIllllI[25]] = lllllIIIlIllIll("OyDtD84DGRdRr/FfXQaepZCBiUExme2iLXoJ5Z3BkgJqGSB7NXzGQ/1/xZcAqlar", "TJYbK");
    lIlllIIlIllIlI[lIlllIIlIllllI[27]] = lllllIIIlIllIlI("IA0VexgnBgQ2By8OFXsFIRwIOhtgOA4hHCEGWzMAIAs+ZE12XFBnKi9SSRxcAgYEIVojAQ8wFjwJByFaPgcVPBogRzE6AScHD25Pbg==", "NhaUu");
    lIlllIIlIllIlI[lIlllIIlIllllI[29]] = lllllIIIlIllIll("uv60fmKsk7ux10JZpgGhZGB72FL1rAZH1kCEhS1DtxgzuXBFz+rfczFzJdYYEwF5HL+0c84GfBLXE6yPGSEurQ==", "QtQba");
    lIlllIIlIllIlI[lIlllIIlIllllI[31]] = lllllIIIlIllIlI("JB0aQx0jFgsOAiseGkMSJhcNBl45DA8ZFWQxLAEfKRM9GRE+HVQLBSQbMVxHfUpdXS8pQkZEPCQdGkIdIxYLDgIrHhpCEiYXDQZfCBQBDhtxQk5N", "Jxnmp");
    lIlllIIlIllIlI[lIlllIIlIllllI[33]] = lllllIIIlIllIll("Wz+lSfGrHoEKq7dFjFS9Q9qWSNOAcEeuGT5hxdDBAjMpHkOkol33CI09ZqfScWp1ijQtHoRbqrtfpyQ1QJ6pKXnfyO9Ed9y4", "NjklP");
    lIlllIIlIllIlI[lIlllIIlIllllI[35]] = lllllIIIlIllIll("Gu22td1xmemRiRLAzmVHG/Q0iUJK8z2y8MQHVPOnebbwxAdU86d5tvDEB1Tzp3m28MQHVPOnebY+jYv+DbD3EEcGVJyEC5/vauYxk8lgTiSpgB83MhMIxWmQbrhtuTQDAl5rs2Dt85c=", "VxVDO");
    lIlllIIlIllIlI[lIlllIIlIllllI[17]] = lllllIIIlIlllII("DUac+AAzfMFYdw2NK48ZUrOBYWqCBWTbcBR61gvdwW+g0RymP2NbsRM10m0Yp5d7jUDLwc8mBzE=", "aAgqE");
    lIlllIIlIllIlI[lIlllIIlIllllI[38]] = lllllIIIlIlllII("0ggUV1pids2LjiTOfQpWO+aZix8+Qc1KAPzV7P6yp89chBGdywm8LePnyxsFmu4FZ40rzbUiwBE0yysUljtKBf7Cnymib70S", "IEBDJ");
    lIlllIIlIllIlI[lIlllIIlIllllI[40]] = lllllIIIlIlllII("g2LSOznSK2yu5PyaG8X/zeAGTWrD7VTqf1TGMYwdVqFPB+/3XE2IYie1lPV+J6bbVC32XN0LSrU=", "sGbJq");
    lIlllIIlIllIlI[lIlllIIlIllllI[41]] = lllllIIIlIllIll("M6erV9q2z1uPwEEIYncwUnuObYNuCS6hfFkJ2QUyDsO1JscO/WpA4FS12VWIrmrkKKbcMUyYBfgCBtmaQ9NxJ5gVGzAcEb9BdwLumr/TRQuZ0IS6Fx2T6g==", "ldaWv");
    lIlllIIlIllIlI[lIlllIIlIllllI[42]] = lllllIIIlIllIlI("DDw2Sh4LNycHAQM/NkoQDjAnCgdMKycKFwcrJxZdBzc2DQcbdxABHQY8MCkSDDglAQFYPysBHwYGdVxEUGodAElSY2JEUw==", "bYBds");
    lIlllIIlIllIlI[lIlllIIlIllllI[44]] = lllllIIIlIllIll("DGXjwfPiHw2BfK4Pvqw2AP17olzlzl31m/GtlaeEZ/BvON5atV1Xr0fCtkWvFVFR3pCSgQ+9TppPB5t15+pS2CYNseyhYQwH7CEEB6Ysa4lMhuOTUFCqGTJ3QmUgOHq3", "LRCfI");
    lIlllIIlIllIlI[lIlllIIlIllllI[45]] = lllllIIIlIllIlI("FiQGZzsJNwIhP1c1DiQ3FjgSZzMWeCgGDw0/DTpgDTkyPSgQOAZzcjU8AD87VjgEPXUsBC1yczU8AD87VjoAJz1WBRU7MxcxWnN6", "yVaIZ");
    lIlllIIlIllIlI[lIlllIIlIllllI[46]] = lllllIIIlIlllII("hyfQomemt9XB1eyd/ZoORO1ipjRrjFCI8KrdD9fHUSbOJQ57Ecuw9jUF8pwL3TG/", "ruyAu");
    lIlllIIlIllIlI[lIlllIIlIllllI[47]] = lllllIIIlIllIlI("OSoAXTo+IREQJTYpAF0iIyYYXTo2OxxdATIsRxdtMToaEAhmeExEb2EQFUl/EwswWhs5KgBcOj4hERAlNikAXCIjJhhcOjY7HFwBMixHF2xtb1Q=", "WOtsW");
    lIlllIIlIllIlI[lIlllIIlIllllI[49]] = lllllIIIlIlllII("qc8uY0ws/6NfIPmKhB5zWvPzJtrdv1BBSz40S0GvgqRrSnmadfktDd3w7GEBgUOSz7vM9su2oSrBsxZr9fEpZ0U8bbZyC13ZhE1kX0yqzW4qGfLZAe7mDUylGW+HyxjNPVZmIv5UYMX3aG9+sx4Q2w==", "QtHHS");
    lIlllIIlIllIlI[lIlllIIlIllllI[50]] = lllllIIIlIllIll("SG0Hn969ayeTSZRWzmr5fRwFx6TQ2tQgD+RwZtKyh8fYRpl9zyYrESl+ygU+B0RxMo7rnLHC2QI51Xn5e+vmZkXUOoYzLbdly3FSL3krSwX9ltp2oU2xcyq9ydQiXNpncu+YYL2Qe4g=", "ppkeT");
    lIlllIIlIllIlI[lIlllIIlIllllI[51]] = lllllIIIlIllIlI("GAJBBS4AFwYCPhoAQRQyBUkJR2pFV19GakVXX0ZqRVdfRmpFV19GakVXX0ZqRVdfRmpFV19GakVXVRE/ATcDFyMQFVVeczkJCgJ1GA4BEzkHBgkCdRYLBhM0AUgKGC4cExZZHxsTBgIjJQsODz8HND9NYFU=", "ugovZ");
    lIlllIIlIllIlI[lIlllIIlIllllI[53]] = lllllIIIlIlllII("EhCLSYOHDliWVY29C2dT7J1m7JiJv2XsCW/RGTC8XPBp0X8Xl/mlgX5szfoRkZrOq72PBazKsh/AAmHQDlmWww==", "zsEoW");
    lIlllIIlIllIlI[lIlllIIlIllllI[54]] = lllllIIIlIlllII("wiM0LeDxtT2puhpcfatDckzKMSXUrOB6Dh8wlU0MFjXKRyUUwKqr5lhj6pKPmouKrUoZmi3GbSc=", "xjIkV");
    lIlllIIlIllIlI[lIlllIIlIllllI[56]] = lllllIIIlIllIlI("GAICfBofCRMxBRcBAnwSGBMfJg5YFxozDhMVWBcZAg4CKycaBg83BUwBHzcbEjhBYkZAVCknTUZdVnJX", "vgvRw");
    lIlllIIlIllIlI[lIlllIIlIllllI[58]] = lllllIIIlIllIlI("IQomdjQmATc7Ky4JJnY8IRs7LCBhHz45ICodfB03OwYmIQkjDis9K3UJOz01KzBlaGh5Wg0sY39Vcnh5", "OoRXY");
    lIlllIIlIllIlI[lIlllIIlIllllI[60]] = lllllIIIlIllIlI("AAQ/WwsHDy4WFA8HP1sDABUiAR9ADCQbFRoEOVsjABUiAR8+CCwvCQMDIhBcCBQlFjlfVn5BU1k+KB5cRkgRT0ZO", "naKuf");
    lIlllIIlIllIlI[lIlllIIlIllllI[61]] = lllllIIIlIlllII("2v3/5B1vQHYZch8xImKh3n2Acv79zoQhlgclbZXnVzINx9r2vtD7Sxlh5qP1IimPGxlzdTAIqzdWEP0fyJBj/RBjzG0v9LsawOD0BO/BlOg=", "ctqWy");
    lIlllIIlIllIlI[lIlllIIlIllllI[62]] = lllllIIIlIllIlI("CTAfWTkOOw4UJgYzH1khEzwHWTkGIQNZFR88GDY4DjIFEjAlF1ERIQk2NEBmVGRcKDBdfS8zEE4ZBRIgSDgCGTEEJwoRIEggHx44SDgKAzxIFBMeJyY5AhA6AjEpNW9ddUs=", "gUkwT");
    lIlllIIlIllIlI[lIlllIIlIllllI[63]] = lllllIIIlIlllII("rJQUT83CXptMLNKIZ4Lfm2bJa5rKTa/RxW9/Jr5Jkti+VYsQUwTgmY0HMxpPfLRtvgQzdrvcRHFT5lDDh45vkJkPDbSIWPktoaAWta1R4LKVabfDEUikIig6KKD//UZyM2rczHg5Ums=", "bnkpF");
    lIlllIIlIllIlI[lIlllIIlIllllI[65]] = lllllIIIlIlllII("X2Vy3k9GQQEENVpbOWcdb/91ar5Zi692G6nrkdh6s8WZIAneatbpIEZJ7cALSn8AGCk9dMmfrxn88KbzsAXlYfIT/DPjWZpL", "wGBLY");
    lIlllIIlIllIlI[lIlllIIlIllllI[67]] = lllllIIIlIllIlI("HCsRXxUbIAASChMoEV8NBicJXxUTOg1fNRM6DTkdHj4AA0IUOwsSJ0V4VENOLS9fWT5bCF9R", "rNeqx");
    lIlllIIlIllIlI[lIlllIIlIllllI[13]] = lllllIIIlIllIlI("KT87TTAlPzEPMmQ3JQw5ZBolDDkPPDMOMiQkbAQyPhElKSQlPhkBPS8zIll/Yxw1DDplNzkMMCY1eQQkJT55KSQlPhkBPS8zIlhtanA=", "JPVcW");
    lIlllIIlIllIlI[lIlllIIlIllllI[68]] = lllllIIIlIllIlI("Bg0uWR4BBj8UAQkOLlkQBAE/GQdGJTMZFgsaOxEHUg4zEh8MN21GR1tRBRBJW1J6V1M=", "hhZws");
    lIlllIIlIllIlI[lIlllIIlIllllI[70]] = lllllIIIlIllIlI("MwIkLkA1AjwoQBQCJidUKhIgO1RxJ3sLVHk=", "YcROn");
    lIlllIIlIllIlI[lIlllIIlIllllI[30]] = lllllIIIlIllIll("LwvyqSZc9hKl0qK3VlJi3aIFV49koDZPKHf5A7uiDm2oKaoQupi9U1WZCNTJ7Gc++u7JCAMc9549w+5Er8N2O3q75639Rfxd", "dViTr");
    lIlllIIlIllIlI[lIlllIIlIllllI[26]] = lllllIIIlIllIlI("Ow8FZxQ8BBQqCzQMBWccOx4YPQB7GhA6CjwcFGc8Ox4YPQACBR0vQzMfHyomYlpIeUsKG0thUBkEFD1WOAMfLBonCxc9VjAEBSANLEU0Jw08HggFECMDHy47NBkUckN1Sg==", "UjqIy");
    lIlllIIlIllIlI[lIlllIIlIllllI[43]] = lllllIIIlIllIlI("DhkMahQCGQYoFkMVDikeAhhPJxwBGgQnB0M7ADQAVxgEMzACGAIxAR8TDzA+DAZbbFohHAAyEkIDFS0fQhUOKhAYBBMhHRlZIisdDgMTNhYDAiwlA1ZMQQ==", "mvaDs");
    lIlllIIlIllIlI[lIlllIIlIllllI[74]] = lllllIIIlIllIlI("Jjw/ejshNy43JCk/P3ojPDAnehsnLy45MyYtAjomPS1xMj8tNS8LYXBge2YJKWN+bnZoeQ==", "HYKTV");
    lIlllIIlIllIlI[lIlllIIlIllllI[75]] = lllllIIIlIllIll("WdIvwVF8jMjOwQWLijtIUJFkkEzgn6MJDFyjcSmq1cPLLmgrwJe4fnMd1PqcJJ/F", "tgyNh");
    lIlllIIlIllIlI[lIlllIIlIllllI[28]] = lllllIIIlIllIll("Qk9I3y1ATBSm4tlD/XSXXev/elSiYxZ2j73WKiYzrc9etwGq27K/MoMJFH3ajmHHh8OWGN7sDeAl03UclJysmA==", "cxQVZ");
    lIlllIIlIllIlI[lIlllIIlIllllI[23]] = lllllIIIlIllIll("ZTWiSFtui5FkEzomAWTBUKFka1MhB2ePUDaUkEu/A8kj7U2npM4riguCyX/NasZryKBtn7XvGIQ=", "EUKMB");
    lIlllIIlIllIlI[lIlllIIlIllllI[77]] = lllllIIIlIllIll("JKlqLAeanbXzPjPlg4ix5+FMZF8Ud1EneMTQOLSRknM=", "ojiYY");
    lIlllIIlIllIlI[lIlllIIlIllllI[79]] = lllllIIIlIllIll("pJ1dndUAfi1zWAWR7TmStjrfIGumSgNdxQ6Q/UkTxW7V7xv3UQmdPga4INXa2r1D6MG50N19YnA=", "ImSvj");
    lIlllIIlIllIlI[lIlllIIlIllllI[39]] = lllllIIIlIllIll("gV5Ic/XKRmNip3CDNRRALo+AdeEedJpIkungvMP4MEBXx9lHLsXq5adt5JnibfbswQzrX66Uk4MQ/pDbLseaZ8ZA5vVTxu/aovWiSS46fknhfsiTdEg25proBNzUuxWvSyz0yDGCqGY=", "aSQRs");
    lIlllIIlIllIlI[lIlllIIlIllllI[80]] = lllllIIIlIllIlI("DjEbCWkIMQMPaTckHwEpA2oBDSkDJAVSb00ZV0hn", "dPmhG");
    lIlllIIlIllIlI[lIlllIIlIllllI[82]] = lllllIIIlIllIlI("MBA0NmM2ECwwYxcQNj93OR4xbWUeWAZtbQ==", "ZqBWM");
    lIlllIIlIllIlI[lIlllIIlIllllI[83]] = lllllIIIlIlllII("K5wTNyDj4ccXmvbRiO1zqrDa3P/xXxcrg5gEkiJzvuZURrP8zekgmC0iBgTvPYHFq//LdVJdrTvjdZwEHE0vKQ==", "PoUvc");
    lIlllIIlIllIlI[lIlllIIlIllllI[85]] = lllllIIIlIllIll("5+dmkvoNUlXGjxO3ULL3pate1Ej7AR9Trnt/VPNM4fmL/u4DdkVVuT08pqMOseMKRUGQkBy1fKo/wgI2ODLJVg==", "pbNhS");
    lIlllIIlIllIlI[lIlllIIlIllllI[87]] = lllllIIIlIlllII("kzm54DAXODb/0aD7/Jo9Q0wvCyuVhAideHnUxtMsljCCh0kW2q+6OtV7p4FBFcwQ90vBeetIpPQ=", "vImNX");
    lIlllIIlIllIlI[lIlllIIlIllllI[73]] = lllllIIIlIlllII("zitZzt+94Slf1zQUi1GvoUs8bKWQFycDk1jt9GX/eK3b4dEbSqaYZ6kzJlV8vBEW1ke4BMp8ffQ=", "cCayR");
    lIlllIIlIllIlI[lIlllIIlIllllI[89]] = lllllIIIlIllIll("Z4gkwfwBSmMzutjeJZLnQeReWExl1jfYBIV/mhrqYDE=", "wKRLp");
    lIlllIIlIllIlI[lIlllIIlIllllI[84]] = lllllIIIlIlllII("k5+cxgWMdwPzzpcEQw7h30BHOeYSyFCsr/qqzPqSzy9ye3mTUNGGjZdNPp9ZAb/M839pNNMptNa4C069hLqlc4yvZHTiqZ05KMf0us7P2fY=", "YUKRS");
    lIlllIIlIllIlI[lIlllIIlIllllI[86]] = lllllIIIlIllIlI("HSEYVDgaKgkZJxIiGFQ2Hy0JFCFdCQUUMBA2DRwhSSIFHzkXG1tLYUF8My5vRH5MWnU=", "sDlzU");
    lIlllIIlIllIlI[lIlllIIlIllllI[91]] = lllllIIIlIlllII("F66eLf5I92V7cjnJl0hXOAlmriKD7ciOkt64nYhtfxc6cTDmb986YoI6TqP6yK6kKrX/j45OHnMHe34J9HDkqhe18y+AKr1KNAhTpGP3Nok=", "nKwGa");
    lIlllIIlIllIlI[lIlllIIlIllllI[76]] = lllllIIIlIlllII("7JtOyS4tUadPsKB+5/dcaktw8wBvBNn1ZOg8/jPmZasl1pGQj6qy71F710IJwHePBOG8RdunFdCS3dlaZtQZPQ==", "TGtSh");
    lIlllIIlIllIlI[lIlllIIlIllllI[81]] = lllllIIIlIllIlI("HxVLGRMHAAweAx0XSwgPAl4DG10bAygFBTMXAhgCAQMMHAJIWCkEAgZfCAMJFxMXCwEGXwAEExsEHEUiHAQMHh5JWT9QRw==", "rpejg");
    lIlllIIlIllIlI[lIlllIIlIllllI[94]] = lllllIIIlIlllII("GKDxa3A/uRw2PCArraCGWSz4weB7pMW4TIdVR9+TDfeESt0PGDMnmUBaLob/vM1hgJMf6TvUHWIgHOLhj/J1Kg==", "DuuTG");
    lIlllIIlIllIlI[lIlllIIlIllllI[59]] = lllllIIIlIllIlI("FwsifwMQADMyHBgIIn8HFwcifywVATU6HUMIPzQCHTFnZF5KW2YOD0NYbHFOWU4=", "ynVQn");
    lIlllIIlIllIlI[lIlllIIlIllllI[71]] = lllllIIIlIlllII("Q/usf77CPHXURwwBZqCnzDv5PMO28khrctEhDPzDY9q+uxNMZ8NXRHVjDL+aVRbIAHzEP11UaZ3pt/izsXR2151v3hOP1c8J", "txWeH");
    lIlllIIlIllIlI[lIlllIIlIllllI[90]] = lllllIIIlIllIll("jILw1wZC6n2h+TswKKQU8kumewm2kAL0OFfXEmGwJRnxZgAW0nwyWRTl5F1etd249xM688tB4r0=", "lIkhB");
    lIlllIIlIllIlI[lIlllIIlIllllI[96]] = lllllIIIlIlllII("4blOMYh1i8ZDuPOb9zneXg0M9Yaxy9YHk+9zXY24wYrWa1y5DdGOOyoKNMEx4QUhsIJ5p9441OGhjX40JcPztg==", "APvGQ");
    lIlllIIlIllIlI[lIlllIIlIllllI[37]] = lllllIIIlIllIll("3cfOJtgHEH49+u8IqiYZQ2sokW8oKbQIl77p9V5Ho5kTg5zfjX9qXXba6epp5eoGO/Sx1intuTt9SKHKLVUtFQ==", "MOcIx");
    lIlllIIlIllIlI[lIlllIIlIllllI[97]] = lllllIIIlIllIll("d9FsLdquFsyUyHbQu+zhF9rlqoAhytdda3O857//rR2HK0YaitDrpobLKtblhrlUbNOQl/ezHp12x2aomcZVCw6BY3988N6xYgc/1laPr3h2uA1djx71XNGzWtPtNQjX4CECVhARjos=", "nUKOT");
    lIlllIIlIllIlI[lIlllIIlIllllI[98]] = lllllIIIlIllIlI("LDYOfDcrPR8xKCM1Dnw5LjofPC5sNhQmMzYqVBc0NjoOKwouMgM3KBEDQDQzJz8eDW1zYk9qBSBpQmh6YnM=", "BSzRZ");
    lIlllIIlIllIlI[lIlllIIlIllllI[32]] = lllllIIIlIllIll("NgRaO5V6vC31+Psqd7m9vjftlnCYSM9lc0Hy6XB0rY6ETES1y2LnjdGmTMBSlorb", "qdYRj");
    lIlllIIlIllIlI[lIlllIIlIllllI[78]] = lllllIIIlIlllII("i9Er65uVy4wg3ncyNfMwhfVJLNBZVfWOYzVafUpt0p/q1boOddrG/Nimc519OXvZFG8+S+gT4mw0PLyTVwe1JhdY6EgrN1wQLnCFNuzEiD8Ubz5L6BPibDQ8vJNXB7UmF1joSCs3XBCDd4Q5f1Fqhg==", "rMLKY");
    lIlllIIlIllIlI[lIlllIIlIllllI[92]] = lllllIIIlIlllII("rvQcod9X2LIEUDG7s6Xcu3pcKs6pEOdYlqcgu18onAs=", "kEdsj");
    lIlllIIlIllIlI[lIlllIIlIllllI[36]] = lllllIIIlIlllII("HmX6NnokWpc5eyyNIpnI51Z3sZAs8JCUh1ia2nx9mmVOtdmDtbt+f/Vlg8u2cKZ877duyPUJ7AQhAO1hTHXffjvIFx+sk5rYEo59YoWpZPvJyJJIKoBHxdNf3wMru/nlpI+qFwy4JytlR/wwr5ghkhfThRxVMagvfchVNd12OqA=", "yDQcP");
    lIlllIIlIllIlI[lIlllIIlIllllI[48]] = lllllIIIlIllIll("BeaKGjKoaExsUEzzmy/wA1pHhcwtBq8Nw9CdOnBhh/sDC33zGFQ8KzvdbjaDnTzqUKSrPscPYAthX5MY1+GTj+qItoUsIHlzaEXVtw4pH5NFiLdXDgCjyzCn9HwIiQDQ", "DSAlS");
    lIlllIIlIllIlI[lIlllIIlIllllI[99]] = lllllIIIlIllIlI("HS5fNxwFOxgwDB8sXyYAAGUXNVIdKEt1UlBrUWQ=", "pKqDh");
    lIlllIIlIllIlI[lIlllIIlIllllI[100]] = lllllIIIlIllIll("ZJokfPltcjz57jPfHFy/IYN+PoVWwq4RHwDkBks8n9VJQNfw0IVRMVArwFG2EgwZXeSQHVJjIGTaCk4rl6CgVxz33tLf9j2BRg6b8R28OV6fEfiHABRrpgg/gazlPKi+", "VgTAq");
    lIlllIIlIllIlI[lIlllIIlIllllI[101]] = lllllIIIlIllIlI("KCIkWyQvKTUWOychJFssKDM5ATBoAj4BIDI+ahMgIys0Kn52dmZEFjB9YE9pZmc=", "FGPuI");
    lIlllIIlIllIlI[lIlllIIlIllllI[102]] = lllllIIIlIlllII("CyVbaTEbQ09UJKsN0e5mPNDflOpyFyr4vsgPurHeIXiKyhhmF2J4aTQjvc5tYmS5fhBnQUPyZuxrCCPJHOQreIyMAbj8ReIYisoYZhdieGlDJkuL/v++BS03dNXBc9L2", "IZAxj");
    lIlllIIlIllIlI[lIlllIIlIllllI[34]] = lllllIIIlIllIll("gbuOJjoLqKftwjGbFIxwVHAcA58xHqp/xFqnYBv2wXF1YU1Zd7mAYP/I1XFaQ/68vbRPzlpN0a05Z+Q1yBWsuQ==", "VUvma");
    lIlllIIlIllIlI[lIlllIIlIllllI[21]] = lllllIIIlIlllII("FF0I8rXxg3xEgkXpxZoRjxM2iaxgg3zJ+rQ5/25BXXKoFXRuV+8I+eEXDDFUOtIPBIv+mEeUukc=", "jCjzv");
    lIlllIIlIllIlI[lIlllIIlIllllI[95]] = lllllIIIlIllIll("1PTs0mNx5o5YZx8gJytbwBjx7EOznJ+HxS81NTZ6Ry07lWt5x1AJbgIH7JTf3iZluqkcvYke2uba3OCtjvJKrg==", "fLZAw");
    lIlllIIlIllIlI[lIlllIIlIllllI[64]] = lllllIIIlIlllII("pJGloa6A1F68XSNqUROi7AWt4oHUVOdvhz1LK18IYj/Y73tkd2ClJQ5wpKmVljm0HnItHZAs8smjY+VhPYiWyAylD0/P29jbno80lKXimlZ7UBGgEZEevg==", "uqdsu");
    lIlllIIlIllIlI[lIlllIIlIllllI[103]] = lllllIIIlIllIlI("OzQSbx88PwMiADQ3Em8XOyUPNQt7IQcyATwnA283OyUPNQsCPgonSDMkCCItYmFfcEsKMxN7WnwLXGFS", "UQfAr");
    lIlllIIlIllIlI[lIlllIIlIllllI[57]] = lllllIIIlIllIlI("ICxeADY4ORkHJiIuXhEqPWcWAngkOiAfIzQsAklqAScVB20gIB4WIT8oFgdtKCcEGjY0ZjUdNiQ9CUhrF3NQ", "MIpsB");
    lIlllIIlIllIlI[lIlllIIlIllllI[55]] = lllllIIIlIllIlI("ICRIIxw4MQ8kDCImSDIAPW8AIVIqJBIZBjkkFCAHISASNQwdLhVqQAEvAyRHICgINQs/IAAkRygvEjkcNG4jPhwkNR9rLmQNCDUcYiwPPg0uMwc2HGI0EjkEYiwHJABiFwMzWyl6XHA=", "MAfPh");
    lIlllIIlIllIlI[lIlllIIlIllllI[104]] = lllllIIIlIllIll("ycktXaT+x8hXNCfTn0y9c8CNpzR2d160FyEi/cv7q2umqbNZu3fRlr6xrRALSkOua6Qsv+6IfaU=", "GvAnI");
    lIlllIIlIllIlI[lIlllIIlIllllI[69]] = lllllIIIlIllIll("Q/2YgvRI05R21CgT9vVbRmXv/p+bPE9hTcReM/cmZfb4+lGuUa/mJESdlE+uArw8rhtvxYwmBnJAXoJ9bpz1VOBIsF1bnM8mSiNmG4uOiOsEEqbh2XkotI/JWrkGeTAW26IUTJjoLA/Endngqa1KXg==", "eZqVc");
    lIlllIIlIllIlI[lIlllIIlIllllI[19]] = lllllIIIlIllIlI("PycOYSE4LB8sPjAkDmEpPzYTOzV/MhYuNTQwVAoiJSsONhw9IwMqPmskEyogNR1Nf31ncyU5dmF4Wm9s", "QBzOL");
    lIlllIIlIllIlI[lIlllIIlIllllI[88]] = lllllIIIlIlllII("SkmEhBoc8gUtiDVjkOA/JqsCe5WYafUKd0kcJzsDJX61soRy89C0ABRvkpK4Sd9rzs//el0EUHJuPSPoOBE5d79YSgRywn90", "LXURV");
    lIlllIIlIllIlI[lIlllIIlIllllI[66]] = lllllIIIlIllIlI("JC4naxQjJTYmCystJ2saJiI2Kw1kLj0xED4yfQAXPiInPCkmKiogCxkbaSMQLyc3Gk56emVwJj5xY39Zams=", "JKSEy");
    lIlllIIlIllIlI[lIlllIIlIllllI[106]] = lllllIIIlIllIlI("DRQSN2ALFAoxYCINBzM+ExwLOHQXBw04OjQBBTUlMwcFNStdXU0AdEdV", "gudVN");
    lIlllIIlIllIlI[lIlllIIlIllllI[105]] = lllllIIIlIllIlI("BA8NQCEDBBwNPgsMDUApBB4QGjVELxcaJR4TNQc6AwQeLC0ZD0MIJQ8GHTF7Wl1JXBMIGENbdkpKWQ==", "jjynL");
    lIlllIIlIllIlI[lIlllIIlIllllI[52]] = lllllIIIlIllIlI("JhwVYzUhFwQuKikfFWM7JBAEIyxmHA85MTwATwg2PBAVNAgkGBgoKhspWysxLRUFEm94SFd8Bz5DUXd4aFk=", "HyaMX");
    lIlllIIlIllIlI[lIlllIIlIllllI[107]] = lllllIIIlIlllII("vz94elpcokCOCAj6kV95IZN32o4tYI2qTlvCT4i5F3WyRbdktPukJhBpp0QIAIrpJbaDzwDXnFo=", "QzbCJ");
    lIlllIIlIllIlI[lIlllIIlIllllI[93]] = lllllIIIlIllIll("/JNWVe/zLCp3mpiAYcGTAG5jPIXYLur0riJiRA48DUsDk0wE6vvGfl9kjmgohlyt", "vtRqN");
    lIlllIIlIllIlI[lIlllIIlIllllI[108]] = lllllIIIlIllIll("qCIKVAadFjOGTtTt9pZDhkk1adGLp54Buz9qaUnBmkWQC/F3prdqOJLnG8UO0EToG1mUl/9f8jS6FRLVeU3+xA==", "ScMQM");
    lIlllIIlIllIlI[lIlllIIlIllllI[72]] = lllllIIIlIllIlI("CBUBdikPHhA7NgcWAXYnChkQNjBIHQA0MA8AGTk9AwJbDysUHBEbKA8VGyx+AAUbOxtXSEVsfVMvBWJsKh4QLGsLGRs9JxQREyxrEwQcNGsLEQEwayQcGjsvNh8GY20qHhAsawsZGz0nFBETLGsEHBo7L0kDATkwA188GigJEx4LMAcEEGN+RlA=", "fpuXD");
    lIlllIIlIllIlI[lIlllIIlIllllI[15]] = lllllIIIlIllIll("OKa5+GjfYCPbafrNZZJ1E0+riTHDYhPsDBvTnERshVfbID6ldE4JwFna0YH9yKY+BsnIHkR7fmU=", "KPDly");
    lIlllIIlIllIlI[lIlllIIlIllllI[109]] = lllllIIIlIllIll("8VpUYXRiiFIvqJyBXHQCycFVaErWUfuzTpeBbvMxgYP6RXrH3rOeFktdTPbbWcudi9Z75RdOZT7nbJMFD9GlBdo1W6qyaHeP", "OXCcf");
    lIlllIIlIllIlI[lIlllIIlIllllI[110]] = lllllIIIlIlllII("zIDHXjo7LNeF9If6CwudC9xXW8hFZc9arYwHmRlz4t/2Rac91ovRcWNSS02MiQECF/iMQQBogpZZAvd1LfhrjmJw//kZqcpnxQ3Xy2UtRWMeZ7GOuIsfBg==", "yehxM");
    lIlllIIlIllIlI[lIlllIIlIllllI[111]] = lllllIIIlIllIlI("Ni8BVwExJBAaHjksAVcZLCMZVwE5Ph1XOj0pRh1WPiMQFQgHfUdNWGAVF0NcYmpVWQ==", "XJuyl");
    lIlllIIlIllIlI[lIlllIIlIllllI[112]] = lllllIIIlIllIlI("ATIWXTkGOQcQJg4xFl0xASMLBy1BEgwGOSwlBxIgGiUHJy0fMlgwBioWNiYGKm1bSXRPd0I=", "oWbsT");
    lIlllIIlIllIlI[lIlllIIlIllllI[113]] = lllllIIIlIllIll("Jh4um+25mM1gTG2UIiLbvlkgw4Uwbk5b6ZMbvZSrJIikSRcN+s6TbyY3SYJwApoAI7teNnk+PsI=", "NySoW");
    lIlllIIlIllIlI[lIlllIIlIllllI[114]] = lllllIIIlIlllII("n2CrCUOd5fCUVF6WFhRsAxNxVB8pUdX1A9ysqf17xtm8wqc94wUL87QYYvpTplA3S+p0gTVQVE9b8alRhAQSiw==", "ZcvVF");
    lIlllIIlIllIlI[lIlllIIlIllllI[115]] = lllllIIIlIlllII("SGSzqKb+H+ESEb8L2sAfppicBqmdtUzQfwVRp8uSiPwRpwQe1wnuiW2XJqvvcHHaGcYQsopuH+A61e2RUrZIBw==", "vOzFk");
    lIlllIIlIllIlI[lIlllIIlIllllI[116]] = lllllIIIlIllIlI("CSMYQyEOKAkOPgYgGEM5Ey8AQyEGMgRDDR8vHywgDiECCCglBFYLJQIqCDJ7VXVfVBMEfFxXbEdm", "gFlmL");
    lIlllIIlIllIlI[lIlllIIlIllllI[117]] = lllllIIIlIllIll("LJUNRrpc7xGY53p5g/G5J5OrfelWMXMMjLhaygNGATTcSA8o2FNmeUdg0CFk6Hd7xB2l1+od7JwlLY8FxF5Tsg==", "PoQrs");
    lIlllIIlIllIlI[lIlllIIlIllllI[118]] = lllllIIIlIlllII("b4mfPa4rHCFVWv6MZWkVDrmKEVxY8rws+GbuHxMuWr6pLlc7OUP8yi2Kfd7/K9kVwzzwZhgtaEKpLlc7OUP8yi2Kfd7/K9kVtOVrHvazbJGtgPQpgh9NhEm5dCBQ0DIJp9n2GLirZOI=", "hHccX");
    lIlllIIlIllIlI[lIlllIIlIllllI[119]] = lllllIIIlIllIll("Yv4eHo2vB8llzIKiADZzL1KT8+bXSVXtDc6lZLnoqsfd5izEjC+QVD43shSqHde/N680B9sUg58=", "VMJMM");
    lIlllIIlIlllIl = null;
  }
  
  private static void lllllIIIlIlllll() {
    String str = (new Exception()).getStackTrace()[lIlllIIlIllllI[0]].getFileName();
    lIlllIIlIlllIl = str.substring(str.indexOf("ä") + lIlllIIlIllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIIlIllIlI(String lllllllllllllllIlllIllIlIllIIllI, String lllllllllllllllIlllIllIlIllIIlIl) {
    lllllllllllllllIlllIllIlIllIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIlIllIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIlIllIIlII = new StringBuilder();
    char[] lllllllllllllllIlllIllIlIllIIIll = lllllllllllllllIlllIllIlIllIIlIl.toCharArray();
    int lllllllllllllllIlllIllIlIllIIIlI = lIlllIIlIllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIllIlIllIIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlIllllI[0];
    while (lllllIIIllIlIII(j, i)) {
      char lllllllllllllllIlllIllIlIllIIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllIlIllIIIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() < -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllIlIllIIlII);
  }
  
  private static String lllllIIIlIllIll(String lllllllllllllllIlllIllIlIlIllllI, String lllllllllllllllIlllIllIlIlIlllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIlIllIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIlIlIlllIl.getBytes(StandardCharsets.UTF_8)), lIlllIIlIllllI[9]), "DES");
      Cipher lllllllllllllllIlllIllIlIllIIIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIlIllIIIII.init(lIlllIIlIllllI[3], lllllllllllllllIlllIllIlIllIIIIl);
      return new String(lllllllllllllllIlllIllIlIllIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIlIlIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIlIlIlllll) {
      lllllllllllllllIlllIllIlIlIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIIlIlllII(String lllllllllllllllIlllIllIlIlIllIIl, String lllllllllllllllIlllIllIlIlIllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIlIlIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIlIlIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIlIlIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIlIlIllIll.init(lIlllIIlIllllI[3], lllllllllllllllIlllIllIlIlIlllII);
      return new String(lllllllllllllllIlllIllIlIlIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIlIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIlIlIllIlI) {
      lllllllllllllllIlllIllIlIlIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIllIIIII() {
    lIlllIIlIllllI = new int[121];
    lIlllIIlIllllI[0] = "   ".length() << " ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() << " ".length() ^ -" ".length());
    lIlllIIlIllllI[1] = " ".length();
    lIlllIIlIllllI[2] = -(0x9B ^ 0x9C ^ 0x69 ^ 0xA);
    lIlllIIlIllllI[3] = " ".length() << " ".length();
    lIlllIIlIllllI[4] = "   ".length();
    lIlllIIlIllllI[5] = " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[6] = 0x30 ^ 0x35;
    lIlllIIlIllllI[7] = "   ".length() << " ".length();
    lIlllIIlIllllI[8] = 155 + 114 - 208 + 98 ^ (0x5A ^ 0x49) << "   ".length();
    lIlllIIlIllllI[9] = " ".length() << "   ".length();
    lIlllIIlIllllI[10] = 0xCA ^ 0xC3;
    lIlllIIlIllllI[11] = (0x2A ^ 0x2F) << " ".length();
    lIlllIIlIllllI[12] = -(0xA8 ^ 0x85);
    lIlllIIlIllllI[13] = 0x6 ^ 0x1B ^ "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[14] = (0x61 ^ 0x20) << " ".length() ^ 76 + 15 - -35 + 11;
    lIlllIIlIllllI[15] = ((0xA1 ^ 0xB0) << "   ".length() ^ 90 + 65 - 71 + 105) << " ".length();
    lIlllIIlIllllI[16] = "   ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[17] = 109 + 124 - 138 + 42 ^ (0xE7 ^ 0xA8) << " ".length();
    lIlllIIlIllllI[18] = 0x25 ^ 0x6E ^ (0xAA ^ 0x89) << " ".length();
    lIlllIIlIllllI[19] = "   ".length() << ("   ".length() << " ".length() << " ".length() ^ 0xB0 ^ 0xB9);
    lIlllIIlIllllI[20] = (0x3B ^ 0x3C) << " ".length();
    lIlllIIlIllllI[21] = ((0x64 ^ 0x43) << " ".length() ^ 0x7B ^ 0x3E) << "   ".length();
    lIlllIIlIllllI[22] = 0x98 ^ 0x97;
    lIlllIIlIllllI[23] = (" ".length() << "   ".length() << " ".length() ^ 0x52 ^ 0x9) << " ".length();
    lIlllIIlIllllI[24] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[25] = (0x6D ^ 0x26) << " ".length() ^ 46 + 5 - 30 + 114;
    lIlllIIlIllllI[26] = (0x76 ^ 0x41) << " ".length() ^ 0x3E ^ 0x61;
    lIlllIIlIllllI[27] = (0x97 ^ 0x9E) << " ".length();
    lIlllIIlIllllI[28] = (0x63 ^ 0x5E) << " ".length() << " ".length() ^ 182 + 128 - 276 + 159;
    lIlllIIlIllllI[29] = 0xA9 ^ 0xBA;
    lIlllIIlIllllI[30] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[31] = (0x1D ^ 0x18) << " ".length() << " ".length();
    lIlllIIlIllllI[32] = (0xA4 ^ 0x83) << " ".length();
    lIlllIIlIllllI[33] = 0x31 ^ 0x24;
    lIlllIIlIllllI[34] = (0x91 ^ 0x8C) << " ".length() << " ".length() ^ 0x80 ^ 0xA3;
    lIlllIIlIllllI[35] = ((0x64 ^ 0x73) << " ".length() ^ 0x29 ^ 0xC) << " ".length();
    lIlllIIlIllllI[36] = 0x56 ^ 0x11 ^ (0x79 ^ 0x72) << " ".length();
    lIlllIIlIllllI[37] = 49 + 49 - 86 + 181 ^ (0xD7 ^ 0x92) << " ".length();
    lIlllIIlIllllI[38] = "   ".length() << "   ".length();
    lIlllIIlIllllI[39] = 0x9F ^ 0xA6;
    lIlllIIlIllllI[40] = 0x81 ^ 0x8A ^ (0x53 ^ 0x5A) << " ".length();
    lIlllIIlIllllI[41] = ((0x32 ^ 0x1D) << " ".length() ^ 0x10 ^ 0x43) << " ".length();
    lIlllIIlIllllI[42] = 0x15 ^ 0xE;
    lIlllIIlIllllI[43] = (0xFB ^ 0xB8 ^ (0x3A ^ 0x17) << " ".length()) << " ".length();
    lIlllIIlIllllI[44] = (0xB9 ^ 0xBE) << " ".length() << " ".length();
    lIlllIIlIllllI[45] = 0x90 ^ 0x8D;
    lIlllIIlIllllI[46] = (49 + 101 - 120 + 127 ^ (0x4D ^ 0x4) << " ".length()) << " ".length();
    lIlllIIlIllllI[47] = 30 + 145 - 76 + 60 ^ " ".length() << (0x66 ^ 0x61);
    lIlllIIlIllllI[48] = ((0x2A ^ 0xF) << " ".length() ^ 0xC5 ^ 0xA6) << " ".length();
    lIlllIIlIllllI[49] = " ".length() << ((0x40 ^ 0x23) << " ".length() ^ 57 + 86 - -33 + 19);
    lIlllIIlIllllI[50] = 0x63 ^ 0x42;
    lIlllIIlIllllI[51] = ((0xDB ^ 0xC0) << " ".length() << " ".length() ^ 0x25 ^ 0x58) << " ".length();
    lIlllIIlIllllI[52] = 0x74 ^ 0x11;
    lIlllIIlIllllI[53] = 0x88 ^ 0xAB;
    lIlllIIlIllllI[54] = (0x43 ^ 0x4A) << " ".length() << " ".length();
    lIlllIIlIllllI[55] = (0xB4 ^ 0xB9) << "   ".length() ^ 0x45 ^ 0x70;
    lIlllIIlIllllI[56] = 0x7A ^ 0x5F;
    lIlllIIlIllllI[57] = (0x5F ^ 0x56 ^ (0x20 ^ 0x2F) << " ".length()) << " ".length() << " ".length();
    lIlllIIlIllllI[58] = ((0x1F ^ 0x2C) << " ".length() ^ 0x2B ^ 0x5E) << " ".length();
    lIlllIIlIllllI[59] = 0x2D ^ 0x6A;
    lIlllIIlIllllI[60] = 0x5C ^ 0x63 ^ "   ".length() << "   ".length();
    lIlllIIlIllllI[61] = (0x6D ^ 0x68) << "   ".length();
    lIlllIIlIllllI[62] = 0x67 ^ 0x60 ^ (0x3A ^ 0x2D) << " ".length();
    lIlllIIlIllllI[63] = (0xE ^ 0x1B) << " ".length();
    lIlllIIlIllllI[64] = ((0x1A ^ 0x7) << " ".length() << " ".length() ^ 0xF9 ^ 0xA0) << " ".length();
    lIlllIIlIllllI[65] = 0x9D ^ 0xB6;
    lIlllIIlIllllI[66] = (0x73 ^ 0x2C ^ (0xF ^ 0x38) << " ".length()) << " ".length();
    lIlllIIlIllllI[67] = ((0x5B ^ 0x7E) << " ".length() << " ".length() ^ 114 + 63 - 123 + 105) << " ".length() << " ".length();
    lIlllIIlIllllI[68] = (0x48 ^ 0x5F ^ (0x6B ^ 0x74) & (0xA6 ^ 0xB9 ^ 0xFFFFFFFF)) << " ".length();
    lIlllIIlIllllI[69] = (0x6C ^ 0x5D) << " ".length() << " ".length() ^ 123 + 4 - -22 + 6;
    lIlllIIlIllllI[70] = 200 + 153 - 191 + 71 ^ (0xD7 ^ 0xB4) << " ".length();
    lIlllIIlIllllI[71] = (0xBB ^ 0xB2) << "   ".length();
    lIlllIIlIllllI[72] = 0x5B ^ 0x32;
    lIlllIIlIllllI[73] = 94 + 144 - 203 + 110 ^ (0x70 ^ 0x27) << " ".length();
    lIlllIIlIllllI[74] = 0x37 ^ 0x4;
    lIlllIIlIllllI[75] = (0x28 ^ 0x25) << " ".length() << " ".length();
    lIlllIIlIllllI[76] = ((0x16 ^ 0xD) << " ".length() ^ 0x57 ^ 0x70) << " ".length() << " ".length();
    lIlllIIlIllllI[77] = 0x23 ^ 0x14;
    lIlllIIlIllllI[78] = 0xC9 ^ 0x86;
    lIlllIIlIllllI[79] = (" ".length() ^ "   ".length() << " ".length()) << "   ".length();
    lIlllIIlIllllI[80] = (0x4E ^ 0x53) << " ".length();
    lIlllIIlIllllI[81] = 0xD1 ^ 0x94;
    lIlllIIlIllllI[82] = 0xF ^ 0x34;
    lIlllIIlIllllI[83] = (0x97 ^ 0xC4 ^ (0xD7 ^ 0xC0) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIlIllllI[84] = 0x5B ^ 0x1A;
    lIlllIIlIllllI[85] = 0x96 ^ 0xAB;
    lIlllIIlIllllI[86] = (154 + 18 - 137 + 192 ^ (0x5B ^ 0x3A) << " ".length()) << " ".length();
    lIlllIIlIllllI[87] = (203 + 97 - 274 + 195 ^ (0xE6 ^ 0x87) << " ".length()) << " ".length();
    lIlllIIlIllllI[88] = (0xAF ^ 0xBC) << " ".length() << " ".length() ^ 0x57 ^ 0x7A;
    lIlllIIlIllllI[89] = " ".length() << "   ".length() << " ".length();
    lIlllIIlIllllI[90] = 0xF7 ^ 0xBE;
    lIlllIIlIllllI[91] = 0x81 ^ 0xC2;
    lIlllIIlIllllI[92] = ("   ".length() << (0x60 ^ 0x65) ^ 0x5D ^ 0x38) << " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[93] = (0x51 ^ 0x54) << " ".length() ^ 0x1F ^ 0x72;
    lIlllIIlIllllI[94] = (0x56 ^ 0x75) << " ".length();
    lIlllIIlIllllI[95] = 0x52 ^ 0xB;
    lIlllIIlIllllI[96] = (0x1D ^ 0x38) << " ".length();
    lIlllIIlIllllI[97] = ((0xE ^ 0x3) << " ".length() << " ".length() << " ".length() ^ 172 + 21 - 146 + 148) << " ".length() << " ".length();
    lIlllIIlIllllI[98] = 0x4D ^ 0x0;
    lIlllIIlIllllI[99] = (0xB0 ^ 0x9F) << " ".length() ^ 0x5D ^ 0x50;
    lIlllIIlIllllI[100] = (0x3F ^ 0x2A) << " ".length() << " ".length();
    lIlllIIlIllllI[101] = 0x6D ^ 0x38;
    lIlllIIlIllllI[102] = (0x8B ^ 0xA0) << " ".length();
    lIlllIIlIllllI[103] = 0x36 ^ 0x77 ^ (0x1C ^ 0x11) << " ".length();
    lIlllIIlIllllI[104] = (0xB2 ^ 0x9D) << " ".length();
    lIlllIIlIllllI[105] = (0x43 ^ 0x5A) << " ".length() << " ".length();
    lIlllIIlIllllI[106] = 0x4C ^ 0x2F;
    lIlllIIlIllllI[107] = (0x22 ^ 0x11) << " ".length();
    lIlllIIlIllllI[108] = (0xA ^ 0x61 ^ (0x2C ^ 0x1F) << " ".length()) << "   ".length();
    lIlllIIlIllllI[109] = 0x7D ^ 0x16;
    lIlllIIlIllllI[110] = (0x14 ^ 0xF) << " ".length() << " ".length();
    lIlllIIlIllllI[111] = 0x39 ^ 0x54;
    lIlllIIlIllllI[112] = (0xFF ^ 0x8E ^ (0x1A ^ 0x39) << " ".length()) << " ".length();
    lIlllIIlIllllI[113] = 0x32 ^ 0x5D;
    lIlllIIlIllllI[114] = ((0xEB ^ 0xC2) << " ".length() << " ".length() ^ 27 + 142 - 120 + 114) << " ".length() << " ".length() << " ".length();
    lIlllIIlIllllI[115] = 0x14 ^ 0x65;
    lIlllIIlIllllI[116] = ((0x58 ^ 0x63) << " ".length() ^ 0x89 ^ 0xC6) << " ".length();
    lIlllIIlIllllI[117] = 0xD3 ^ 0xA0;
    lIlllIIlIllllI[118] = (0x49 ^ 0x54) << " ".length() << " ".length();
    lIlllIIlIllllI[119] = 0xD2 ^ 0xA7;
    lIlllIIlIllllI[120] = ((0x1B ^ 0x14) << " ".length() << " ".length() ^ 0x15 ^ 0x12) << " ".length();
  }
  
  private static boolean lllllIIIllIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIIllIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIIlllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIIllIIllI(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lllllIIIllIIlII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lllllIIIllIIIll(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lllllIIIllIIIIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIIIllIIIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIIIllIlIlI(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lllllIIIllIlllI(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lllllIIIlllIIlI(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lllllIIIllIIlll(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllIIIllIlIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIllIlIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIllIllII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIllIllIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIllIllll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIlllIIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIlllIIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIlllIIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIlllIlII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fq.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */