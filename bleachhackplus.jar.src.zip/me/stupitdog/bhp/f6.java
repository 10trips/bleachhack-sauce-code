package me.stupitdog.bhp;

import java.io.PrintStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class f6 extends au {
  f100000000000000000000.Double playerrange;
  
  f100000000000000000000.Integer blockspertick;
  
  f100000000000000000000.Boolean render;
  
  f100000000000000000000.ColorSetting color;
  
  private ArrayList<BlockPos> renderBlock;
  
  private boolean hasPlaced;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private List<Vec3d> autoTrap;
  
  private static String[] lIlllIlIIIIlII;
  
  private static Class[] lIlllIlIIIIlIl;
  
  private static final String[] lIlllIlIIlIIlI;
  
  private static String[] lIlllIlIIlIlIl;
  
  private static final int[] lIlllIlIIlIllI;
  
  public f6() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new java/util/ArrayList
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f6;Ljava/util/ArrayList;)V
    //   54: aload_0
    //   55: new me/zero/alpine/listener/Listener
    //   58: dup
    //   59: aload_0
    //   60: <illegal opcode> invoke : (Lme/stupitdog/bhp/f6;)Lme/zero/alpine/listener/EventHook;
    //   65: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   68: iconst_0
    //   69: iaload
    //   70: anewarray java/util/function/Predicate
    //   73: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   76: <illegal opcode> 2 : (Lme/stupitdog/bhp/f6;Lme/zero/alpine/listener/Listener;)V
    //   81: aload_0
    //   82: new java/util/ArrayList
    //   85: dup
    //   86: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   89: iconst_3
    //   90: iaload
    //   91: anewarray net/minecraft/util/math/Vec3d
    //   94: dup
    //   95: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   98: iconst_0
    //   99: iaload
    //   100: new net/minecraft/util/math/Vec3d
    //   103: dup
    //   104: dconst_0
    //   105: ldc2_w -1.0
    //   108: ldc2_w -1.0
    //   111: invokespecial <init> : (DDD)V
    //   114: aastore
    //   115: dup
    //   116: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   119: iconst_1
    //   120: iaload
    //   121: new net/minecraft/util/math/Vec3d
    //   124: dup
    //   125: dconst_1
    //   126: ldc2_w -1.0
    //   129: dconst_0
    //   130: invokespecial <init> : (DDD)V
    //   133: aastore
    //   134: dup
    //   135: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   138: iconst_2
    //   139: iaload
    //   140: new net/minecraft/util/math/Vec3d
    //   143: dup
    //   144: dconst_0
    //   145: ldc2_w -1.0
    //   148: dconst_1
    //   149: invokespecial <init> : (DDD)V
    //   152: aastore
    //   153: dup
    //   154: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   157: iconst_4
    //   158: iaload
    //   159: new net/minecraft/util/math/Vec3d
    //   162: dup
    //   163: ldc2_w -1.0
    //   166: ldc2_w -1.0
    //   169: dconst_0
    //   170: invokespecial <init> : (DDD)V
    //   173: aastore
    //   174: dup
    //   175: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   178: iconst_5
    //   179: iaload
    //   180: new net/minecraft/util/math/Vec3d
    //   183: dup
    //   184: dconst_0
    //   185: dconst_0
    //   186: ldc2_w -1.0
    //   189: invokespecial <init> : (DDD)V
    //   192: aastore
    //   193: dup
    //   194: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   197: bipush #6
    //   199: iaload
    //   200: new net/minecraft/util/math/Vec3d
    //   203: dup
    //   204: dconst_1
    //   205: dconst_0
    //   206: dconst_0
    //   207: invokespecial <init> : (DDD)V
    //   210: aastore
    //   211: dup
    //   212: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   215: bipush #7
    //   217: iaload
    //   218: new net/minecraft/util/math/Vec3d
    //   221: dup
    //   222: dconst_0
    //   223: dconst_0
    //   224: dconst_1
    //   225: invokespecial <init> : (DDD)V
    //   228: aastore
    //   229: dup
    //   230: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   233: bipush #8
    //   235: iaload
    //   236: new net/minecraft/util/math/Vec3d
    //   239: dup
    //   240: ldc2_w -1.0
    //   243: dconst_0
    //   244: dconst_0
    //   245: invokespecial <init> : (DDD)V
    //   248: aastore
    //   249: <illegal opcode> 3 : ([Ljava/lang/Object;)Ljava/util/List;
    //   254: invokespecial <init> : (Ljava/util/Collection;)V
    //   257: <illegal opcode> 4 : (Lme/stupitdog/bhp/f6;Ljava/util/List;)V
    //   262: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	263	0	lllllllllllllllIlllIlIllIlIlIIlI	Lme/stupitdog/bhp/f6;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   8: iconst_4
    //   9: iaload
    //   10: aaload
    //   11: ldc2_w 4.4
    //   14: ldc2_w 4.4
    //   17: ldc2_w 10.0
    //   20: <illegal opcode> 5 : (Lme/stupitdog/bhp/f6;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   25: <illegal opcode> 6 : (Lme/stupitdog/bhp/f6;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   30: aload_0
    //   31: aload_0
    //   32: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   35: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   38: iconst_5
    //   39: iaload
    //   40: aaload
    //   41: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   44: iconst_1
    //   45: iaload
    //   46: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   49: iconst_1
    //   50: iaload
    //   51: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   54: bipush #9
    //   56: iaload
    //   57: <illegal opcode> 7 : (Lme/stupitdog/bhp/f6;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   62: <illegal opcode> 8 : (Lme/stupitdog/bhp/f6;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   67: aload_0
    //   68: aload_0
    //   69: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   72: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   75: bipush #6
    //   77: iaload
    //   78: aaload
    //   79: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   82: iconst_1
    //   83: iaload
    //   84: <illegal opcode> 9 : (Lme/stupitdog/bhp/f6;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   89: <illegal opcode> 10 : (Lme/stupitdog/bhp/f6;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   94: aload_0
    //   95: aload_0
    //   96: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIIlI : [Ljava/lang/String;
    //   99: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   102: bipush #7
    //   104: iaload
    //   105: aaload
    //   106: new me/stupitdog/bhp/f01
    //   109: dup
    //   110: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   113: bipush #10
    //   115: iaload
    //   116: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   119: bipush #10
    //   121: iaload
    //   122: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   125: bipush #10
    //   127: iaload
    //   128: invokespecial <init> : (III)V
    //   131: <illegal opcode> 11 : (Lme/stupitdog/bhp/f6;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   136: <illegal opcode> 12 : (Lme/stupitdog/bhp/f6;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   141: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	142	0	lllllllllllllllIlllIlIllIlIlIIIl	Lme/stupitdog/bhp/f6;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onEnable : ()V
    //   4: aload_0
    //   5: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 13 : (Lme/stupitdog/bhp/f6;Z)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIlIllIlIlIIII	Lme/stupitdog/bhp/f6;
  }
  
  public void update() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore_1
    //   6: aload_0
    //   7: <illegal opcode> 14 : (Lme/stupitdog/bhp/f6;)Ljava/util/ArrayList;
    //   12: <illegal opcode> 15 : (Ljava/util/ArrayList;)V
    //   17: aload_0
    //   18: <illegal opcode> 16 : (Lme/stupitdog/bhp/f6;)Ljava/util/List;
    //   23: <illegal opcode> 17 : (Ljava/util/List;)Ljava/util/Iterator;
    //   28: astore_2
    //   29: aload_2
    //   30: <illegal opcode> 18 : (Ljava/util/Iterator;)Z
    //   35: invokestatic lllllIIllllllIl : (I)Z
    //   38: ifeq -> 444
    //   41: aload_2
    //   42: <illegal opcode> 19 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   47: checkcast net/minecraft/util/math/Vec3d
    //   50: astore_3
    //   51: aload_0
    //   52: invokespecial getClosestPlayer : ()Lnet/minecraft/entity/player/EntityPlayer;
    //   55: astore #4
    //   57: aload #4
    //   59: invokestatic lllllIIlllllllI : (Ljava/lang/Object;)Z
    //   62: ifeq -> 414
    //   65: new net/minecraft/util/math/BlockPos
    //   68: dup
    //   69: aload_3
    //   70: aload_0
    //   71: invokespecial getClosestPlayer : ()Lnet/minecraft/entity/player/EntityPlayer;
    //   74: <illegal opcode> 20 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   79: <illegal opcode> 21 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   84: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   87: astore #5
    //   89: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   94: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   99: aload #5
    //   101: <illegal opcode> 24 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   106: <illegal opcode> 25 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   111: <illegal opcode> 26 : ()Lnet/minecraft/block/Block;
    //   116: <illegal opcode> 27 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   121: invokestatic lllllIIllllllIl : (I)Z
    //   124: ifeq -> 414
    //   127: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   132: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   137: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   142: <illegal opcode> 30 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   147: istore #6
    //   149: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   152: iconst_0
    //   153: iaload
    //   154: istore #7
    //   156: iload #7
    //   158: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   161: bipush #11
    //   163: iaload
    //   164: invokestatic lllllIIllllllll : (II)Z
    //   167: ifeq -> 333
    //   170: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   175: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   180: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   185: iload #7
    //   187: <illegal opcode> 32 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   192: <illegal opcode> 33 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   197: astore #8
    //   199: aload #8
    //   201: instanceof net/minecraft/item/ItemBlock
    //   204: invokestatic lllllIIllllllIl : (I)Z
    //   207: ifeq -> 256
    //   210: aload #8
    //   212: checkcast net/minecraft/item/ItemBlock
    //   215: <illegal opcode> 34 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   220: <illegal opcode> 35 : ()Lnet/minecraft/block/Block;
    //   225: <illegal opcode> 27 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   230: invokestatic lllllIIllllllIl : (I)Z
    //   233: ifeq -> 256
    //   236: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   241: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   246: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   251: iload #7
    //   253: putfield field_70461_c : I
    //   256: iinc #7, 1
    //   259: ldc_w ''
    //   262: invokevirtual length : ()I
    //   265: pop
    //   266: ldc_w '   '
    //   269: invokevirtual length : ()I
    //   272: ldc_w ' '
    //   275: invokevirtual length : ()I
    //   278: ldc_w ' '
    //   281: invokevirtual length : ()I
    //   284: ldc_w ' '
    //   287: invokevirtual length : ()I
    //   290: ishl
    //   291: ishl
    //   292: ishl
    //   293: ldc_w '   '
    //   296: invokevirtual length : ()I
    //   299: ldc_w ' '
    //   302: invokevirtual length : ()I
    //   305: ldc_w ' '
    //   308: invokevirtual length : ()I
    //   311: ldc_w ' '
    //   314: invokevirtual length : ()I
    //   317: ishl
    //   318: ishl
    //   319: ishl
    //   320: ldc_w ' '
    //   323: invokevirtual length : ()I
    //   326: ineg
    //   327: ixor
    //   328: iand
    //   329: ifeq -> 156
    //   332: return
    //   333: <illegal opcode> 36 : ()Ljava/io/PrintStream;
    //   338: aload #5
    //   340: <illegal opcode> 37 : (Ljava/io/PrintStream;Ljava/lang/Object;)V
    //   345: aload #5
    //   347: <illegal opcode> 38 : (Lnet/minecraft/util/math/BlockPos;)V
    //   352: aload_0
    //   353: <illegal opcode> 14 : (Lme/stupitdog/bhp/f6;)Ljava/util/ArrayList;
    //   358: aload #5
    //   360: <illegal opcode> 39 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   365: ldc_w ''
    //   368: invokevirtual length : ()I
    //   371: pop2
    //   372: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   377: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   382: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   387: iload #6
    //   389: putfield field_70461_c : I
    //   392: iinc #1, 1
    //   395: iload_1
    //   396: aload_0
    //   397: <illegal opcode> 40 : (Lme/stupitdog/bhp/f6;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   402: <illegal opcode> 41 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   407: invokestatic lllllIlIIIIIIII : (II)Z
    //   410: ifeq -> 414
    //   413: return
    //   414: ldc_w ''
    //   417: invokevirtual length : ()I
    //   420: pop
    //   421: bipush #43
    //   423: bipush #22
    //   425: ixor
    //   426: bipush #41
    //   428: bipush #20
    //   430: ixor
    //   431: iconst_m1
    //   432: ixor
    //   433: iand
    //   434: ldc_w '   '
    //   437: invokevirtual length : ()I
    //   440: if_icmpne -> 29
    //   443: return
    //   444: iload_1
    //   445: invokestatic lllllIlIIIIIIIl : (I)Z
    //   448: ifeq -> 462
    //   451: aload_0
    //   452: getstatic me/stupitdog/bhp/f6.lIlllIlIIlIllI : [I
    //   455: iconst_1
    //   456: iaload
    //   457: <illegal opcode> 13 : (Lme/stupitdog/bhp/f6;Z)V
    //   462: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   199	57	8	lllllllllllllllIlllIlIllIlIIllll	Lnet/minecraft/item/Item;
    //   156	177	7	lllllllllllllllIlllIlIllIlIIlllI	I
    //   149	265	6	lllllllllllllllIlllIlIllIlIIllIl	I
    //   89	325	5	lllllllllllllllIlllIlIllIlIIllII	Lnet/minecraft/util/math/BlockPos;
    //   57	357	4	lllllllllllllllIlllIlIllIlIIlIll	Lnet/minecraft/entity/player/EntityPlayer;
    //   51	363	3	lllllllllllllllIlllIlIllIlIIlIlI	Lnet/minecraft/util/math/Vec3d;
    //   0	463	0	lllllllllllllllIlllIlIllIlIIlIIl	Lme/stupitdog/bhp/f6;
    //   6	457	1	lllllllllllllllIlllIlIllIlIIlIII	I
  }
  
  private EntityPlayer getClosestPlayer() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   7: <illegal opcode> 23 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   12: <illegal opcode> 42 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   17: <illegal opcode> 17 : (Ljava/util/List;)Ljava/util/Iterator;
    //   22: astore_2
    //   23: aload_2
    //   24: <illegal opcode> 18 : (Ljava/util/Iterator;)Z
    //   29: invokestatic lllllIIllllllIl : (I)Z
    //   32: ifeq -> 137
    //   35: aload_2
    //   36: <illegal opcode> 19 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   41: checkcast net/minecraft/entity/player/EntityPlayer
    //   44: astore_3
    //   45: aload_3
    //   46: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   51: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   56: invokestatic lllllIlIIIIIIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   59: ifeq -> 105
    //   62: <illegal opcode> 22 : ()Lnet/minecraft/client/Minecraft;
    //   67: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   72: aload_3
    //   73: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;)F
    //   78: f2d
    //   79: dstore #4
    //   81: dload #4
    //   83: aload_0
    //   84: <illegal opcode> 44 : (Lme/stupitdog/bhp/f6;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   89: <illegal opcode> 45 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   94: invokestatic lllllIlIIIIIIlI : (DD)I
    //   97: invokestatic lllllIlIIIIIlII : (I)Z
    //   100: ifeq -> 105
    //   103: aload_3
    //   104: astore_1
    //   105: ldc_w ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: ldc_w ' '
    //   115: invokevirtual length : ()I
    //   118: ldc_w ' '
    //   121: invokevirtual length : ()I
    //   124: ldc_w ' '
    //   127: invokevirtual length : ()I
    //   130: ishl
    //   131: ishl
    //   132: ifgt -> 23
    //   135: aconst_null
    //   136: areturn
    //   137: aload_1
    //   138: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   81	24	4	lllllllllllllllIlllIlIllIlIIIlll	D
    //   45	60	3	lllllllllllllllIlllIlIllIlIIIllI	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	139	0	lllllllllllllllIlllIlIllIlIIIlIl	Lme/stupitdog/bhp/f6;
    //   2	137	1	lllllllllllllllIlllIlIllIlIIIlII	Lnet/minecraft/entity/player/EntityPlayer;
  }
  
  static {
    lllllIIllllllII();
    lllllIIlllllIll();
    lllllIIlllllIlI();
    lllllIIllllIlIl();
  }
  
  private static CallSite lllllIIllIIlIlI(MethodHandles.Lookup lllllllllllllllIlllIlIllIIlllIII, String lllllllllllllllIlllIlIllIIllIlll, MethodType lllllllllllllllIlllIlIllIIllIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIllIIlllllI = lIlllIlIIIIlII[Integer.parseInt(lllllllllllllllIlllIlIllIIllIlll)].split(lIlllIlIIlIIlI[lIlllIlIIlIllI[8]]);
      Class<?> lllllllllllllllIlllIlIllIIllllIl = Class.forName(lllllllllllllllIlllIlIllIIlllllI[lIlllIlIIlIllI[0]]);
      String lllllllllllllllIlllIlIllIIllllII = lllllllllllllllIlllIlIllIIlllllI[lIlllIlIIlIllI[1]];
      MethodHandle lllllllllllllllIlllIlIllIIlllIll = null;
      int lllllllllllllllIlllIlIllIIlllIlI = lllllllllllllllIlllIlIllIIlllllI[lIlllIlIIlIllI[4]].length();
      if (lllllIlIIIIIlIl(lllllllllllllllIlllIlIllIIlllIlI, lIlllIlIIlIllI[2])) {
        MethodType lllllllllllllllIlllIlIllIlIIIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIllIIlllllI[lIlllIlIIlIllI[2]], f6.class.getClassLoader());
        if (lllllIlIIIIIIII(lllllllllllllllIlllIlIllIIlllIlI, lIlllIlIIlIllI[2])) {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findVirtual(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIlIIIIII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findStatic(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIlIIIIII);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIllIIllllll = lIlllIlIIIIlIl[Integer.parseInt(lllllllllllllllIlllIlIllIIlllllI[lIlllIlIIlIllI[2]])];
        if (lllllIlIIIIIIII(lllllllllllllllIlllIlIllIIlllIlI, lIlllIlIIlIllI[4])) {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findGetter(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIIllllll);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else if (lllllIlIIIIIIII(lllllllllllllllIlllIlIllIIlllIlI, lIlllIlIIlIllI[5])) {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findStaticGetter(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIIllllll);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (lllllIlIIIIIIII(lllllllllllllllIlllIlIllIIlllIlI, lIlllIlIIlIllI[6])) {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findSetter(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIIllllll);
          "".length();
          if (-" ".length() >= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIllIIlllIll = lllllllllllllllIlllIlIllIIlllIII.findStaticSetter(lllllllllllllllIlllIlIllIIllllIl, lllllllllllllllIlllIlIllIIllllII, lllllllllllllllIlllIlIllIIllllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIllIIlllIll);
    } catch (Exception lllllllllllllllIlllIlIllIIlllIIl) {
      lllllllllllllllIlllIlIllIIlllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIllllIlIl() {
    lIlllIlIIIIlII = new String[lIlllIlIIlIllI[12]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[13]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[3]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[14]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[11]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[15]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[9]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[0]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[16]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[17]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[18]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[19]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[20]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[8]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[15]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[21]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[22]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[23]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[24]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[25]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[26]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[27]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[28]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[29]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[14]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[26]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[30]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[31]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[32]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[33]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[34]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[28]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[19]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[35]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[36]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[37]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[38]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[39]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[25]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[20]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[40]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[41]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[33]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[36]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[42]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[30]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[43]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[44]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[37]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[45]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[46]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[38]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[47]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[34]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[48]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[16]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[23]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[49]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[50]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[5]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[51]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[52]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[53]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[54]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[49]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[32]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[39]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[53]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[55]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[51]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[45]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[24]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[31]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[55]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[21]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[18]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[54]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[56]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[35]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[57]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[52]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[40]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[58]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[59]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[44]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[43]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[57]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[2]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[59]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[60]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[27]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[58]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[13]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[61]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[60]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[42]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[17]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[3]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[61]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[4]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[56]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[48]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[41]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[11]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[29]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[47]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[12]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[50]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[62]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[6]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[63]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[9]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[64]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[46]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[65]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[7]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[66]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[22]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[67]];
    lIlllIlIIIIlII[lIlllIlIIlIllI[1]] = lIlllIlIIlIIlI[lIlllIlIIlIllI[68]];
    lIlllIlIIIIlIl = new Class[lIlllIlIIlIllI[24]];
    lIlllIlIIIIlIl[lIlllIlIIlIllI[16]] = Block.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[6]] = f100000000000000000000.Integer.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[8]] = f100000000000000000000.ColorSetting.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[0]] = f13.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[11]] = Minecraft.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[3]] = boolean.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[18]] = EntityPlayerSP.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[2]] = Listener.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[4]] = List.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[22]] = PrintStream.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[9]] = WorldClient.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[15]] = int.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[7]] = f100000000000000000000.Boolean.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[20]] = InventoryPlayer.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[5]] = f100000000000000000000.Double.class;
    lIlllIlIIIIlIl[lIlllIlIIlIllI[1]] = ArrayList.class;
  }
  
  private static void lllllIIlllllIlI() {
    lIlllIlIIlIIlI = new String[lIlllIlIIlIllI[69]];
    lIlllIlIIlIIlI[lIlllIlIIlIllI[0]] = lllllIIllllIllI(lIlllIlIIlIlIl[lIlllIlIIlIllI[0]], lIlllIlIIlIlIl[lIlllIlIIlIllI[1]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[1]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[2]], lIlllIlIIlIlIl[lIlllIlIIlIllI[4]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[2]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[5]], lIlllIlIIlIlIl[lIlllIlIIlIllI[6]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[4]] = lllllIIllllIllI(lIlllIlIIlIlIl[lIlllIlIIlIllI[7]], lIlllIlIIlIlIl[lIlllIlIIlIllI[8]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[5]] = lllllIIlllllIII(lIlllIlIIlIlIl[lIlllIlIIlIllI[3]], lIlllIlIIlIlIl[lIlllIlIIlIllI[11]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[6]] = lllllIIlllllIII(lIlllIlIIlIlIl[lIlllIlIIlIllI[9]], lIlllIlIIlIlIl[lIlllIlIIlIllI[16]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[7]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[18]], lIlllIlIIlIlIl[lIlllIlIIlIllI[20]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[8]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[15]], lIlllIlIIlIlIl[lIlllIlIIlIllI[22]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[3]] = lllllIIlllllIII(lIlllIlIIlIlIl[lIlllIlIIlIllI[24]], lIlllIlIIlIlIl[lIlllIlIIlIllI[26]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[11]] = lllllIIlllllIII(lIlllIlIIlIlIl[lIlllIlIIlIllI[28]], lIlllIlIIlIlIl[lIlllIlIIlIllI[14]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[9]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[30]], lIlllIlIIlIlIl[lIlllIlIIlIllI[32]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[16]] = lllllIIllllIllI(lIlllIlIIlIlIl[lIlllIlIIlIllI[34]], lIlllIlIIlIlIl[lIlllIlIIlIllI[19]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[18]] = lllllIIllllIlll(lIlllIlIIlIlIl[lIlllIlIIlIllI[36]], lIlllIlIIlIlIl[lIlllIlIIlIllI[38]]);
    lIlllIlIIlIIlI[lIlllIlIIlIllI[20]] = lllllIIlllllIII("UiuB17XhX5QzCFsZs1PkyqoRoILxacSc9X6VAtoUvhdWSDnethN9TwQelkayenzQKUQcyjdr8wI=", "iubfT");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[15]] = lllllIIlllllIII("GlR7EO+sYJxayytTGyiFQyqOIt4y5C/cJKzmsrx7qo9Mq0jmK+gzWY9ooUG8x4sOqdOEmBFy24BA2TuYo2AzB5SDMQlVb+oIfJrvnVHHwt7r5d2qtAYh6Ovl3aq0BiHoq6IG6/aS5mAPKZ/p/S4Jyw==", "Euhtf");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[22]] = lllllIIllllIlll("BylrFTgfPCwSKAUrawQkGmIjUHYaICQfKRg+JAgrD3ZxXGxKbA==", "jLEfL");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[24]] = lllllIIllllIllI("kwWDZQGLIFXbX5ZjAC2S0h/mg0eGC/C+ObE/pjYzJOJsCxcth3klGZtcbrCW09ut5YhSqi7z5kI=", "rXPMa");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[26]] = lllllIIllllIlll("IyQ5XzokLygSJSwnOV8+Iyg5XxUhLi4aJHcnJBQ7KR58RGd+dH0uNndwfEt3bWFt", "MAMqW");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[28]] = lllllIIllllIlll("IjF6GgU6JD0dFSAzegsZP3oyWEF/ZGRZQX9kZFlBf2RkWUF/bjMMHyomNR0UDRZuQTsFHn0lHyogewQYITE3GxApIHscBSY4ewQQOzx7KAkmJxUFGCg6MQ0zDW9uSQ==", "OTTiq");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[14]] = lllllIIlllllIII("Fbg030vPxb6WI528y4LP9CDzkLREZdR5fD6lmf+R/hrigcrKX97Cm1dMfMUtoLgOW99FVQAnNs5wqkZXAKvIZX/wd1fq6mQ6BAU+qpDXgFvyFMsSUGm1fSnE6V0v+U9thhFrH1xv0/A=", "ZaeZJ");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[30]] = lllllIIllllIllI("qlLfju09DdCexm4gqTdWPu8GtdC3341aAEdVkx0QzuHk/5E/6tqVLTtKbTOuqxzYgU6RSA/vlVE=", "WKyWm");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[32]] = lllllIIlllllIII("ir4GlU2OYMG8HiQXj/w/RW1NL0/7fTGb15gMLa+T1YJW2xwCj95Xmth1YnBr1JFspE3P+GcdS0gb7rCWWkY/X72dwU5pnBFdTTvisfv4xKl+NaD8ZlHvgaljGu/W1cbp", "lHlAx");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[34]] = lllllIIllllIllI("fGxGHbhs0YvMRLDfFZUiiyFHXculio3DAnNFIWUcorKi3D2CHSyK8KYVfmYyBSYy/kfWLJOvSW0=", "iQYGj");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[19]] = lllllIIlllllIII("3SCb4nLdLMLB0mXJHGqUbPyeEREq2lpZCnOv6/3qjQ4QvvK0t0w3Lw==", "WKRjk");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[36]] = lllllIIlllllIII("PPBKvBtbFpvJF3c2OtjxntjYRv4mW1mISKgzickrCBbFtv+7T8x59w==", "DsfEb");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[38]] = lllllIIlllllIII("a9KYeEPphUfYypuDDerSVY+buzEUPzdbi9AcWJsiEnzGuCmbKsO6G/SJlitG/M+oME6cRA2el+4QVljwqaPv3x5597l6yPbp6UJAMsHx4CEoViBdmepmhg==", "nrMLa");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[25]] = lllllIIlllllIII("oJzn7hxSYuYK8OwEatQPnnX//ZLXvmxxpDNy2eDXhnvc7j67Alk2DA==", "GlJSG");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[40]] = lllllIIllllIlll("IiBcCiY6NRsNNiAiXBs6P2sUT2gnJAEpPi4mFx1od39SWXJvZQ==", "OEryR");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[33]] = lllllIIllllIlll("OCpKBjwgPw0BLDooShcgJWECRHhlf1RFeGV/VEV4ZX9URXhldQAHKSINCw1yfQMKEDx6Ig0bLTY9BRM8ejoQHCR6IgUBIHoOHBw7FCMNEiYwKyY3cxMJIjNhA3VE", "UOduH");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[42]] = lllllIIlllllIII("Rqj/wAY31K1H6XUWpXVRw5ff5gVL24CVWfaCLyBaRA4/1xS0zCaIc1xBLnAIiTuSqt/FnenzHQUQVHYEWwHOI9Prl32bBS8GxFfzKDNaz8N+sekyxQm8RvgXQNMm6ycNUgxNJ4neL9iJnTcP11SwD5rWkD74s/ZmDxJkBWfGeqS4RI5oAF/YpZil1Gtes9HF", "RbkSY");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[43]] = lllllIIllllIlll("DyMWfjsIKAczJAAgFn4zDzILJC9PNg4xLwQ0TBU4FS8WKQYNJxs1JFsgFz41PndVZGFYdz00bElvLj4zFWkPOTgEJRAxMBVpFyQ/DWkPMSIJaTQ1NVIiWWp2QQ==", "aFbPV");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[37]] = lllllIIllllIlll("LA8NZAArBBwpHyMMDWQYNgMVZAAjHhFkLy4FGiE9LRlDLBgsCSZ7WnVTTHIyLFBRYyR4Slk=", "BjyJm");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[46]] = lllllIIllllIllI("fr6StRbhdB7cEsPI8y1B0M6TYPLiHFKEIkJxccEChRJ8Xu+9MQ6oUMXQxRCfNI7sji0cq9WJ4btJ5NMM+Mw/GvZykHfDuB7Z", "twtOd");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[47]] = lllllIIllllIlll("Fic7WRsRLCoUBBkkO1kUFC0sHFgLNi4DE1YLDRsZGykcAxcMJ3URAxYhEEZBT3B8RykbeGdeOhYnO1gbESwqFAQZJDtYFBQtLBxZOi4gFB1DeG9X", "xBOwv");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[48]] = lllllIIllllIlll("OzxWOh4jKRE9Djk+VisCJncef1A7OkJwUHZ5WGk=", "VYxIj");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[23]] = lllllIIllllIllI("ltGalbmqo2Kc1o7tsPQdQu0BDv0ivesgfBS/U9wfJu5pKv1eAK3S2STphw7lARI78kvxg+sYi6drxweG0Hh6obmgSrjmy6DJpRiEa5AHjUx97f9Cex+/HwzMytofFpBSr3klf+zUPg+veSV/7NQ+D/hy/bz1Tih8Ex8ZVm/XqxkIr7RQ1F1Ydw==", "ppXqm");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[50]] = lllllIIllllIllI("on9DTMXnKlOxBPoA1OwcVF+4CLlb2YsMmmWxWZaMcjL6EdDSbw1136CFAGJqBN9ebg8WB1fDBEY=", "MgWgU");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[51]] = lllllIIlllllIII("3VvOfJvw4kZsC5yL9QXHJS4uxPbY3yhekJhIa1EPP2mHAFnmK83mWw==", "eVqPU");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[53]] = lllllIIlllllIII("a3DNlt3DZwbmPIaW6nqE9Pofg/HIQecvM6sQqVPtxNaEnNmHOP6OW9D/9AkpfduSPXYJ6/1zVphx+SRMZwsmrw==", "ILYrz");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[49]] = lllllIIllllIllI("Z96FhNQT7CzspW7AuL1iQ5UlllazvbnFEUoIarmz9pikMfYiEaTeaDZIpApUNxe/E5Wc1bv0cB8hzGo42X2A7A==", "RXwrG");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[39]] = lllllIIllllIlll("BycVQicALAQPOAgkFUI/HSsNQicINglCHAwhUghwDzcPDxVYdVlbcl4dBFZiJSwEGGUEKw8JKRsjBxhlHDYIAGUEIxUEZT8nAl8uUmstAi8dbQwFJAwhEw0sHW0UGCMFbQwNPgFtNwkpWiZaVmpJ", "iBalJ");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[55]] = lllllIIllllIlll("ITdkHhs5IiMZCyM1ZA8HPHwsXVl2IiYMDCkQJgIMJ2hiIQEpJmUABiI3KR8OKiZlGBslPmUADjg6ZS8DIzEhPQA/aWM7VWw=", "LRJmo");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[45]] = lllllIIllllIllI("SvjeXy2lQ4EAJt1LvN2bnFFw+xZLNc/+JvBAObleI7OX6bKLntO6Vsl7BjoOTsAWZ90oti7eE1A=", "uuOeG");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[31]] = lllllIIlllllIII("rqs1LmAdJOLBkJXCjSGkWfohoWAf3JzT3IP4xSzQ30acTj1IjI73IA==", "lABRI");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[21]] = lllllIIllllIlll("ICBgEjk4NScVKSIiYAMlPWsoUH19dX5RfX11flF9fXV+UX19dX5RaQQrOgQqKDd0Big5Ey8NOCh/ZkgEd2Vu", "MENaM");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[54]] = lllllIIlllllIII("KBM+Msbnyos1UQ6LUUp3iKc/tTWbhnlDVK64OwMumMuKz+1q4k3Fxg==", "DOdaC");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[35]] = lllllIIllllIllI("y+hSiN1eJvoy1JfV10kUOUR7OYlHDfyd/87zxz/NVGEnWtQt5grk+A==", "ztSmq");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[52]] = lllllIIlllllIII("7+ErQcXTz3CIjAfhLoCFirwRufoTdkAhaQaTqJ2kcDFaCPBi4q6xLE5TH9mE9iaU351qaY8tahc=", "sHDKR");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[58]] = lllllIIlllllIII("iLsNqx8IxzjATNVgWktYh2FY13J5Qbi1D15sAcgAauyoyVHIolK5jq/G+ZYSEggPZY3AUH73ako=", "iAmHs");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[44]] = lllllIIllllIlll("JTETSR4iOgIEASoyE0kGPz0LSR4qIA9JMSc7BAwjJCddAQYlNzhWRHxtUlUsO25PTjpxdEc=", "KTggs");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[57]] = lllllIIllllIlll("CxAhWRoMGzAUBQQTIVkSCwE8Aw5LBTkWDgAHez4ZExA7AxgXDAUbFhwQJ00RDBA5EyhSRWFBRjoWb0ZDX1V1Vw==", "euUww");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[59]] = lllllIIllllIlll("BQ10IyMdGDMkMwcPdDI/GEY8Zm0EASkkMgYNKGplUkh6cHdI", "hhZPW");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[27]] = lllllIIllllIlll("FzxhFxYPKSYQBhU+YQYKCncpVVJKaX9UUkppf1RSSml/VFJKaX9URjk2IwsQKTw7EAsUPnUDBw4PLggXH2NnTS4XPGAXFg8pJhAGFT5gBgoKdilUU0Fjb0Q=", "zYOdb");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[13]] = lllllIIllllIllI("j2wb0hPeQegipRJwZVaeJv7pZxykQp2sbFWnCRzai9I47jr4Is1EpCL+UXI5hWvT1u82BFebXBQ=", "YeyIb");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[60]] = lllllIIlllllIII("4BXMXJWDWUWliCERkw+zzDVxL37tvvA3klkkf7fn/FW/xZUaMM3r/A==", "jnwPS");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[17]] = lllllIIlllllIII("glE+viYGml8ldISxZs8HdTASPtVWlLZ06O1kJadm+AKpun0Lys1TtwjGClQByAXh7ugHsiADyIiXMRREEHSS0n8Bdpk68VzG", "mAEwh");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[61]] = lllllIIlllllIII("ryj2LxQVzBqo1ZNRUGSUXy/kcnzEjVNWsC1c4vxRrIh1fwAtAzUKQ1dmK2nGsrNw", "cTZQJ");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[56]] = lllllIIllllIlll("JTAPGFQ6JRAVVA4jCxgDPGsYCjYmIg1DUhQdExgMLn4VGBQofjYbECoyDUJTAzsYDxtgJA0QFmAdEAoOdGtZ", "OQyyz");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[41]] = lllllIIllllIlll("KQkcYTkuAg0sJiYKHGE9MwkFYR0zCQUNOCgPA3UyMgILEGVwVVp9ZxgIUmd9CwINO3sqBQYqNzUNDjt7JQAHLD9oLgQgNyxXUm90", "GlhOT");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[29]] = lllllIIllllIllI("uGkRUSxKbgV3RoPOkYwV3151udOwD1BSXZ+2kUZr8VJHDOZDSSNCVXx939h82t17kuI0LvhBtqwnB4XMZvJILBeJ3BxArrJopknAcSZfLIDOp3xKkFSRqc6nfEqQVJGpTDXYoRwsYhgccZYPRu/WaQ==", "MWNwf");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[12]] = lllllIIllllIlll("PSEkbSo6KjUgNTIiJG0uJyE9bQ4nIT0QMzInO3khJiozHHBkfWdwGDF+eGoLPSEkbCo6KjUgNTIiJGwuJyE9bA4nIT14fXNk", "SDPCG");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[62]] = lllllIIllllIlll("CyosDmINKjQIYjIyKRspDHE1Gjhbem9VbEFreg==", "aKZoL");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[63]] = lllllIIllllIlll("OgJcAi0iFxsFPTgAXBMxJ0kUR2MlAhUYKiMCADU2IgUeFGN/KxgQLzZIHhA3MEghBSs+CRVKHRMjWz00MkgBBSwnDgYVNjBIEBkpeAFDQWlnV0JBaWdXQkFpZ1dCQWlnV0JVHTgSEB08bF1SUQ==", "WgrqY");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[64]] = lllllIIllllIlll("BwNLISwfFgwmPAUBSzAwGkgDZGIYAws2PRhcU2h4SkZFcg==", "jfeRX");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[65]] = lllllIIllllIllI("2Q2xINp04wwEmnyXR+zIyS5ncO6M2ktq9aUqTLVku3LoE1kweLGhF0xDlAx4s+30+tGiWmEsPThgpYEFRo8uWhnm2/zfywZ/ArJqAaXBd6HB6QqCzGe2kg9hKgVh+P/W", "IjwRE");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[66]] = lllllIIlllllIII("UXZoP2S1sUr8BLBy90fVkeYugO1brVw0evx5ACzif19ZFH2eq1f3sA==", "UCfrs");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[67]] = lllllIIllllIllI("xo1v8KFOAONTz45GtZCbck6RWGMkm4WyLtNOp37SEhMqfxJanhEohg==", "ixDtv");
    lIlllIlIIlIIlI[lIlllIlIIlIllI[68]] = lllllIIllllIlll("BTZvNBsdIygzCwc0byUHGH0ncVUaNi8jChoRLSgMA2lwfU9Ic2Fn", "hSAGo");
    lIlllIlIIlIlIl = null;
  }
  
  private static void lllllIIlllllIll() {
    String str = (new Exception()).getStackTrace()[lIlllIlIIlIllI[0]].getFileName();
    lIlllIlIIlIlIl = str.substring(str.indexOf("ä") + lIlllIlIIlIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIllllIllI(String lllllllllllllllIlllIlIllIIllIIlI, String lllllllllllllllIlllIlIllIIllIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIllIIllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIIllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIllIIllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIllIIllIlII.init(lIlllIlIIlIllI[2], lllllllllllllllIlllIlIllIIllIlIl);
      return new String(lllllllllllllllIlllIlIllIIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIIllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIIllIIll) {
      lllllllllllllllIlllIlIllIIllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlllllIII(String lllllllllllllllIlllIlIllIIlIllIl, String lllllllllllllllIlllIlIllIIlIllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIllIIllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIIlIllII.getBytes(StandardCharsets.UTF_8)), lIlllIlIIlIllI[3]), "DES");
      Cipher lllllllllllllllIlllIlIllIIlIllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIllIIlIllll.init(lIlllIlIIlIllI[2], lllllllllllllllIlllIlIllIIllIIII);
      return new String(lllllllllllllllIlllIlIllIIlIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIIlIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIIlIlllI) {
      lllllllllllllllIlllIlIllIIlIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIllllIlll(String lllllllllllllllIlllIlIllIIlIlIlI, String lllllllllllllllIlllIlIllIIlIlIIl) {
    lllllllllllllllIlllIlIllIIlIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIIlIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIllIIlIlIII = new StringBuilder();
    char[] lllllllllllllllIlllIlIllIIlIIlll = lllllllllllllllIlllIlIllIIlIlIIl.toCharArray();
    int lllllllllllllllIlllIlIllIIlIIllI = lIlllIlIIlIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIllIIlIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIIlIllI[0];
    while (lllllIIllllllll(j, i)) {
      char lllllllllllllllIlllIlIllIIlIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIllIIlIIllI++;
      j++;
      "".length();
      if (((0x9C ^ 0xB9) & (0x69 ^ 0x4C ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIllIIlIlIII);
  }
  
  private static void lllllIIllllllII() {
    lIlllIlIIlIllI = new int[70];
    lIlllIlIIlIllI[0] = " ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ -" ".length());
    lIlllIlIIlIllI[1] = " ".length();
    lIlllIlIIlIllI[2] = " ".length() << " ".length();
    lIlllIlIIlIllI[3] = " ".length() << "   ".length();
    lIlllIlIIlIllI[4] = "   ".length();
    lIlllIlIIlIllI[5] = " ".length() << " ".length() << " ".length();
    lIlllIlIIlIllI[6] = 0x21 ^ 0x78 ^ (0x7C ^ 0x6B) << " ".length() << " ".length();
    lIlllIlIIlIllI[7] = "   ".length() << " ".length();
    lIlllIlIIlIllI[8] = 0x6B ^ 0x6C;
    lIlllIlIIlIllI[9] = (0x40 ^ 0x39 ^ (0x5C ^ 0x43) << " ".length() << " ".length()) << " ".length();
    lIlllIlIIlIllI[10] = 137 + 204 - 107 + 21;
    lIlllIlIIlIllI[11] = 0x5 ^ 0xC;
    lIlllIlIIlIllI[12] = (0x5A ^ 0x63 ^ (0x52 ^ 0x49) << " ".length()) << " ".length() << " ".length();
    lIlllIlIIlIllI[13] = 0x6F ^ 0x5A;
    lIlllIlIIlIllI[14] = 0x9E ^ 0x8D;
    lIlllIlIIlIllI[15] = (0x6 ^ 0x1) << " ".length();
    lIlllIlIIlIllI[16] = 0x70 ^ 0x13 ^ (0xA8 ^ 0xA5) << "   ".length();
    lIlllIlIIlIllI[17] = 0x35 ^ 0x2;
    lIlllIlIIlIllI[18] = "   ".length() << " ".length() << " ".length();
    lIlllIlIIlIllI[19] = (0xF3 ^ 0xBE) << " ".length() ^ 50 + 60 - 83 + 114;
    lIlllIlIIlIllI[20] = 0x4B ^ 0x46;
    lIlllIlIIlIllI[21] = ((0x54 ^ 0xB) << " ".length() ^ 62 + 168 - 81 + 32) << " ".length() << " ".length();
    lIlllIlIIlIllI[22] = (0x26 ^ 0x2D) << " ".length() ^ 0x8D ^ 0x94;
    lIlllIlIIlIllI[23] = 0x2B ^ 0x8;
    lIlllIlIIlIllI[24] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIlIllI[25] = (0x8F ^ 0x82) << " ".length();
    lIlllIlIIlIllI[26] = 0x5F ^ 0x2A ^ (0xD9 ^ 0xC0) << " ".length() << " ".length();
    lIlllIlIIlIllI[27] = (0x5C ^ 0x51) << " ".length() << " ".length();
    lIlllIlIIlIllI[28] = (0x3A ^ 0x33) << " ".length();
    lIlllIlIIlIllI[29] = (0x60 ^ 0x69) << " ".length() << " ".length() ^ 0xA1 ^ 0xBE;
    lIlllIlIIlIllI[30] = (0x3 ^ 0x6) << " ".length() << " ".length();
    lIlllIlIIlIllI[31] = (0x75 ^ 0x2A) << " ".length() ^ 121 + 93 - 156 + 91;
    lIlllIlIIlIllI[32] = 0x55 ^ 0x40;
    lIlllIlIIlIllI[33] = (0x1F ^ 0x18) << " ".length() << " ".length();
    lIlllIlIIlIllI[34] = ((0xAC ^ 0xA1) << " ".length() ^ 0x53 ^ 0x42) << " ".length();
    lIlllIlIIlIllI[35] = (0x77 ^ 0x60) << " ".length();
    lIlllIlIIlIllI[36] = "   ".length() << "   ".length();
    lIlllIlIIlIllI[37] = 0x6F ^ 0x70;
    lIlllIlIIlIllI[38] = 0x46 ^ 0x5F;
    lIlllIlIIlIllI[39] = (0xA5 ^ 0xBC ^ (0x5C ^ 0x5B) << " ".length() << " ".length()) << "   ".length();
    lIlllIlIIlIllI[40] = 0x7D ^ 0x66;
    lIlllIlIIlIllI[41] = (0xC8 ^ 0xB9 ^ (0x46 ^ 0x5D) << " ".length() << " ".length()) << " ".length();
    lIlllIlIIlIllI[42] = 0x12 ^ 0xF;
    lIlllIlIIlIllI[43] = ((0x34 ^ 0x3B) << " ".length() ^ 0x5C ^ 0x4D) << " ".length();
    lIlllIlIIlIllI[44] = (0xA7 ^ 0xB0) << "   ".length() ^ 7 + 69 - 29 + 90;
    lIlllIlIIlIllI[45] = (0x82 ^ 0x97) << " ".length();
    lIlllIlIIlIllI[46] = " ".length() << (0xC5 ^ 0xC0);
    lIlllIlIIlIllI[47] = 0x21 ^ 0x0;
    lIlllIlIIlIllI[48] = (0x85 ^ 0x98 ^ "   ".length() << " ".length() << " ".length()) << " ".length();
    lIlllIlIIlIllI[49] = 83 + 112 - 173 + 105 ^ (0xA0 ^ 0xAB) << "   ".length();
    lIlllIlIIlIllI[50] = (0x62 ^ 0x6B) << " ".length() << " ".length();
    lIlllIlIIlIllI[51] = 0x4 ^ 0x2B ^ (0x83 ^ 0x86) << " ".length();
    lIlllIlIIlIllI[52] = 0x72 ^ 0x2F ^ (0x8 ^ 0x31) << " ".length();
    lIlllIlIIlIllI[53] = (0x7D ^ 0x6E) << " ".length();
    lIlllIlIIlIllI[54] = 0x41 ^ 0x6C;
    lIlllIlIIlIllI[55] = 0x5B ^ 0x72;
    lIlllIlIIlIllI[56] = (0x10 ^ 0x19) << " ".length() << " ".length() << " ".length() ^ 99 + 29 - -1 + 40;
    lIlllIlIIlIllI[57] = ((0x77 ^ 0x5A) << " ".length() ^ 0x21 ^ 0x62) << " ".length();
    lIlllIlIIlIllI[58] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIlIllI[59] = 0x87 ^ 0xB4;
    lIlllIlIIlIllI[60] = ((0xAC ^ 0xA9) << " ".length() << " ".length() ^ 0xCB ^ 0xC4) << " ".length();
    lIlllIlIIlIllI[61] = (0x69 ^ 0x6E) << "   ".length();
    lIlllIlIIlIllI[62] = 45 + 40 - -30 + 60 ^ (0xD8 ^ 0x91) << " ".length();
    lIlllIlIIlIllI[63] = (0xB4 ^ 0xAB) << " ".length();
    lIlllIlIIlIllI[64] = 0xB5 ^ 0x8A;
    lIlllIlIIlIllI[65] = " ".length() << "   ".length() << " ".length();
    lIlllIlIIlIllI[66] = 0x40 ^ 0x1;
    lIlllIlIIlIllI[67] = (0x55 ^ 0x74) << " ".length();
    lIlllIlIIlIllI[68] = 0x2 ^ 0x23 ^ (0xF7 ^ 0xC6) << " ".length();
    lIlllIlIIlIllI[69] = ((0xB9 ^ 0xBC) << " ".length() ^ 0x1E ^ 0x5) << " ".length() << " ".length();
  }
  
  private static boolean lllllIlIIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIllllllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIlIIIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIlIIIIIIll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lllllIIlllllllI(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lllllIIllllllIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIlIIIIIIIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIlIIIIIlII(int paramInt) {
    return (paramInt < 0);
  }
  
  private static int lllllIlIIIIIIlI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */