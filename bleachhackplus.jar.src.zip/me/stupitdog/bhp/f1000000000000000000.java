package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class f1000000000000000000 extends au {
  private static String[] llIIllIIIlIlIl;
  
  private static Class[] llIIllIIIlIllI;
  
  private static final String[] llIIllIIlIlIlI;
  
  private static String[] llIIllIIlIlIll;
  
  private static final int[] llIIllIIlIllII;
  
  public f1000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIlIlI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIllII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIlIlI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIllII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIlIlI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIllII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000.llIIllIIlIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIIlIllIllIllI	Lme/stupitdog/bhp/f1000000000000000000;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   15: invokestatic lIIIlIIIlllIIIII : (I)Z
    //   18: ifeq -> 105
    //   21: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   26: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   31: <illegal opcode> 4 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   36: invokestatic lIIIlIIIlllIIIIl : (I)Z
    //   39: ifeq -> 105
    //   42: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   47: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   52: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   57: invokestatic lIIIlIIIlllIIIIl : (I)Z
    //   60: ifeq -> 105
    //   63: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   68: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   73: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   78: invokestatic lIIIlIIIlllIIIIl : (I)Z
    //   81: ifeq -> 105
    //   84: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   89: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   94: dup
    //   95: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   100: dconst_1
    //   101: dsub
    //   102: putfield field_70181_x : D
    //   105: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	106	0	lllllllllllllllIllIIIlIllIllIlIl	Lme/stupitdog/bhp/f1000000000000000000;
  }
  
  static {
    lIIIlIIIllIlllll();
    lIIIlIIIllIllllI();
    lIIIlIIIllIlllIl();
    lIIIlIIIllIllIIl();
  }
  
  private static CallSite lIIIlIIIlIlIllll(MethodHandles.Lookup lllllllllllllllIllIIIlIllIlIllII, String lllllllllllllllIllIIIlIllIlIlIll, MethodType lllllllllllllllIllIIIlIllIlIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIlIllIllIIlI = llIIllIIIlIlIl[Integer.parseInt(lllllllllllllllIllIIIlIllIlIlIll)].split(llIIllIIlIlIlI[llIIllIIlIllII[3]]);
      Class<?> lllllllllllllllIllIIIlIllIllIIIl = Class.forName(lllllllllllllllIllIIIlIllIllIIlI[llIIllIIlIllII[0]]);
      String lllllllllllllllIllIIIlIllIllIIII = lllllllllllllllIllIIIlIllIllIIlI[llIIllIIlIllII[1]];
      MethodHandle lllllllllllllllIllIIIlIllIlIllll = null;
      int lllllllllllllllIllIIIlIllIlIlllI = lllllllllllllllIllIIIlIllIllIIlI[llIIllIIlIllII[3]].length();
      if (lIIIlIIIlllIIIlI(lllllllllllllllIllIIIlIllIlIlllI, llIIllIIlIllII[2])) {
        MethodType lllllllllllllllIllIIIlIllIllIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIlIllIllIIlI[llIIllIIlIllII[2]], f1000000000000000000.class.getClassLoader());
        if (lIIIlIIIlllIIIll(lllllllllllllllIllIIIlIllIlIlllI, llIIllIIlIllII[2])) {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findVirtual(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIlII);
          "".length();
          if (" ".length() < -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findStatic(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIlII);
        } 
        "".length();
        if ("   ".length() < "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIlIllIllIIll = llIIllIIIlIllI[Integer.parseInt(lllllllllllllllIllIIIlIllIllIIlI[llIIllIIlIllII[2]])];
        if (lIIIlIIIlllIIIll(lllllllllllllllIllIIIlIllIlIlllI, llIIllIIlIllII[3])) {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findGetter(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIIll);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (lIIIlIIIlllIIIll(lllllllllllllllIllIIIlIllIlIlllI, llIIllIIlIllII[4])) {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findStaticGetter(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIIll);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (lIIIlIIIlllIIIll(lllllllllllllllIllIIIlIllIlIlllI, llIIllIIlIllII[5])) {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findSetter(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIIll);
          "".length();
          if ("   ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIlIllIlIllll = lllllllllllllllIllIIIlIllIlIllII.findStaticSetter(lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIllIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIlIllIlIllll);
    } catch (Exception lllllllllllllllIllIIIlIllIlIllIl) {
      lllllllllllllllIllIIIlIllIlIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIllIllIIl() {
    llIIllIIIlIlIl = new String[llIIllIIlIllII[6]];
    llIIllIIIlIlIl[llIIllIIlIllII[2]] = llIIllIIlIlIlI[llIIllIIlIllII[4]];
    llIIllIIIlIlIl[llIIllIIlIllII[7]] = llIIllIIlIlIlI[llIIllIIlIllII[5]];
    llIIllIIIlIlIl[llIIllIIlIllII[0]] = llIIllIIlIlIlI[llIIllIIlIllII[7]];
    llIIllIIIlIlIl[llIIllIIlIllII[3]] = llIIllIIlIlIlI[llIIllIIlIllII[8]];
    llIIllIIIlIlIl[llIIllIIlIllII[5]] = llIIllIIlIlIlI[llIIllIIlIllII[6]];
    llIIllIIIlIlIl[llIIllIIlIllII[4]] = llIIllIIlIlIlI[llIIllIIlIllII[9]];
    llIIllIIIlIlIl[llIIllIIlIllII[1]] = llIIllIIlIlIlI[llIIllIIlIllII[10]];
    llIIllIIIlIlIl[llIIllIIlIllII[8]] = llIIllIIlIlIlI[llIIllIIlIllII[11]];
    llIIllIIIlIllI = new Class[llIIllIIlIllII[5]];
    llIIllIIIlIllI[llIIllIIlIllII[4]] = double.class;
    llIIllIIIlIllI[llIIllIIlIllII[3]] = boolean.class;
    llIIllIIIlIllI[llIIllIIlIllII[0]] = f13.class;
    llIIllIIIlIllI[llIIllIIlIllII[1]] = Minecraft.class;
    llIIllIIIlIllI[llIIllIIlIllII[2]] = EntityPlayerSP.class;
  }
  
  private static void lIIIlIIIllIlllIl() {
    llIIllIIlIlIlI = new String[llIIllIIlIllII[12]];
    llIIllIIlIlIlI[llIIllIIlIllII[0]] = lIIIlIIIllIllIlI(llIIllIIlIlIll[llIIllIIlIllII[0]], llIIllIIlIlIll[llIIllIIlIllII[1]]);
    llIIllIIlIlIlI[llIIllIIlIllII[1]] = lIIIlIIIllIllIll(llIIllIIlIlIll[llIIllIIlIllII[2]], llIIllIIlIlIll[llIIllIIlIllII[3]]);
    llIIllIIlIlIlI[llIIllIIlIllII[2]] = lIIIlIIIllIlllII(llIIllIIlIlIll[llIIllIIlIllII[4]], llIIllIIlIlIll[llIIllIIlIllII[5]]);
    llIIllIIlIlIlI[llIIllIIlIllII[3]] = lIIIlIIIllIllIll(llIIllIIlIlIll[llIIllIIlIllII[7]], llIIllIIlIlIll[llIIllIIlIllII[8]]);
    llIIllIIlIlIlI[llIIllIIlIllII[4]] = lIIIlIIIllIllIlI(llIIllIIlIlIll[llIIllIIlIllII[6]], llIIllIIlIlIll[llIIllIIlIllII[9]]);
    llIIllIIlIlIlI[llIIllIIlIllII[5]] = lIIIlIIIllIllIlI(llIIllIIlIlIll[llIIllIIlIllII[10]], llIIllIIlIlIll[llIIllIIlIllII[11]]);
    llIIllIIlIlIlI[llIIllIIlIllII[7]] = lIIIlIIIllIllIlI(llIIllIIlIlIll[llIIllIIlIllII[12]], llIIllIIlIlIll[llIIllIIlIllII[13]]);
    llIIllIIlIlIlI[llIIllIIlIllII[8]] = lIIIlIIIllIlllII(llIIllIIlIlIll[llIIllIIlIllII[14]], llIIllIIlIlIll[llIIllIIlIllII[15]]);
    llIIllIIlIlIlI[llIIllIIlIllII[6]] = lIIIlIIIllIlllII("xWByg7IipdH4D6+Nz/4WOIYjCoSSdPhSyTT6jObKrLZ0MA3sdEeBT68XWvk5D2PKnyHM7cxGfxXA2ujVJf/vteqHvIz/7qX1", "iRPiq");
    llIIllIIlIlIlI[llIIllIIlIllII[9]] = lIIIlIIIllIllIlI("CVGCv6AIwyV/qvHMRUgDSQm1I7R0U/AcYi81WJFsEN+apdQ4eatbIJavfrRlzBuAbmRHahoYNjDKsm2ufWrgPQ==", "JnAIB");
    llIIllIIlIlIlI[llIIllIIlIllII[10]] = lIIIlIIIllIlllII("UdQpEMHuXATSzU9/qCXdFfc5fEjQN1sSQfc3SRz8vYJuyHBR/CQj+ciKAOXFtXk4", "ZBgsn");
    llIIllIIlIlIlI[llIIllIIlIllII[11]] = lIIIlIIIllIllIlI("SigaZ3YI34Xd2H8Tmmw1m7HFl/B25KM0Y8nVYZDj6YL721oYH/Q60QnTWdtemGjxW2ysocjmBuNPK+cCjNQi1g==", "lasft");
    llIIllIIlIlIll = null;
  }
  
  private static void lIIIlIIIllIllllI() {
    String str = (new Exception()).getStackTrace()[llIIllIIlIllII[0]].getFileName();
    llIIllIIlIlIll = str.substring(str.indexOf("ä") + llIIllIIlIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIllIllIll(String lllllllllllllllIllIIIlIllIlIlIII, String lllllllllllllllIllIIIlIllIlIIlll) {
    lllllllllllllllIllIIIlIllIlIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIlIllIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIlIllIlIIllI = new StringBuilder();
    char[] lllllllllllllllIllIIIlIllIlIIlIl = lllllllllllllllIllIIIlIllIlIIlll.toCharArray();
    int lllllllllllllllIllIIIlIllIlIIlII = llIIllIIlIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIlIllIlIlIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIIlIllII[0];
    while (lIIIlIIIlllIIlII(j, i)) {
      char lllllllllllllllIllIIIlIllIlIlIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIlIllIlIIlII++;
      j++;
      "".length();
      if (((0x23 ^ 0x0) & (0x5 ^ 0x26 ^ 0xFFFFFFFF)) >= " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIlIllIlIIllI);
  }
  
  private static String lIIIlIIIllIlllII(String lllllllllllllllIllIIIlIllIlIIIII, String lllllllllllllllIllIIIlIllIIlllll) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlIllIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlIllIIlllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIlIllIlIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIlIllIlIIIlI.init(llIIllIIlIllII[2], lllllllllllllllIllIIIlIllIlIIIll);
      return new String(lllllllllllllllIllIIIlIllIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlIllIlIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlIllIlIIIIl) {
      lllllllllllllllIllIIIlIllIlIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIllIllIlI(String lllllllllllllllIllIIIlIllIIllIll, String lllllllllllllllIllIIIlIllIIllIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlIllIIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlIllIIllIlI.getBytes(StandardCharsets.UTF_8)), llIIllIIlIllII[6]), "DES");
      Cipher lllllllllllllllIllIIIlIllIIlllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIIlIllIIlllIl.init(llIIllIIlIllII[2], lllllllllllllllIllIIIlIllIIllllI);
      return new String(lllllllllllllllIllIIIlIllIIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlIllIIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlIllIIlllII) {
      lllllllllllllllIllIIIlIllIIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIllIlllll() {
    llIIllIIlIllII = new int[16];
    llIIllIIlIllII[0] = ((0xA6 ^ 0x89) << " ".length() << " ".length() ^ 42 + 87 - 23 + 75) << " ".length() << " ".length() & (((0x8 ^ 0x45) << " ".length() ^ 8 + 128 - -8 + 3) << " ".length() << " ".length() ^ -" ".length());
    llIIllIIlIllII[1] = " ".length();
    llIIllIIlIllII[2] = " ".length() << " ".length();
    llIIllIIlIllII[3] = "   ".length();
    llIIllIIlIllII[4] = " ".length() << " ".length() << " ".length();
    llIIllIIlIllII[5] = (0xE4 ^ 0x87) << " ".length() ^ 76 + 184 - 161 + 96;
    llIIllIIlIllII[6] = " ".length() << "   ".length();
    llIIllIIlIllII[7] = "   ".length() << " ".length();
    llIIllIIlIllII[8] = (0x1F ^ 0x16) << " ".length() ^ 0x45 ^ 0x50;
    llIIllIIlIllII[9] = " ".length() << (0x11 ^ 0x14) ^ 0x8A ^ 0xA3;
    llIIllIIlIllII[10] = (0x6E ^ 0x6B) << " ".length();
    llIIllIIlIllII[11] = (0x45 ^ 0x0) << " ".length() ^ 89 + 44 - 89 + 85;
    llIIllIIlIllII[12] = "   ".length() << " ".length() << " ".length();
    llIIllIIlIllII[13] = 0x3C ^ 0x31;
    llIIllIIlIllII[14] = ((0x2F ^ 0x36) << " ".length() << " ".length() ^ 0x25 ^ 0x46) << " ".length();
    llIIllIIlIllII[15] = 0xF ^ 0x0;
  }
  
  private static boolean lIIIlIIIlllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIlllIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIlllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIIlllIIIII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIlIIIlllIIIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */