package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.util.NonNullList;

public class f1000000000 extends au {
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Mode fallback;
  
  f100000000000000000000.Boolean gapOnSword;
  
  f100000000000000000000.Integer totemHealth;
  
  f100000000000000000000.Integer totemDistance;
  
  private static String[] llIIIllIllIlII;
  
  private static Class[] llIIIllIllIlIl;
  
  private static final String[] llIIlIlIllIlIl;
  
  private static String[] llIIlIlIlllIIl;
  
  private static final int[] llIIlIlIlllIlI;
  
  public f1000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIlIIlIIlllIlI	Lme/stupitdog/bhp/f1000000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_1
    //   51: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   54: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   57: iconst_5
    //   58: iaload
    //   59: aaload
    //   60: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   65: ldc ''
    //   67: invokevirtual length : ()I
    //   70: pop2
    //   71: new java/util/ArrayList
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore_2
    //   79: aload_2
    //   80: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   83: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   86: bipush #6
    //   88: iaload
    //   89: aaload
    //   90: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   95: ldc ''
    //   97: invokevirtual length : ()I
    //   100: pop2
    //   101: aload_2
    //   102: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   105: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   108: bipush #7
    //   110: iaload
    //   111: aaload
    //   112: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   117: ldc ''
    //   119: invokevirtual length : ()I
    //   122: pop2
    //   123: aload_2
    //   124: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   127: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   130: bipush #8
    //   132: iaload
    //   133: aaload
    //   134: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   139: ldc ''
    //   141: invokevirtual length : ()I
    //   144: pop2
    //   145: aload_0
    //   146: aload_0
    //   147: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   150: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   153: bipush #9
    //   155: iaload
    //   156: aaload
    //   157: aload_1
    //   158: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   161: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   164: bipush #10
    //   166: iaload
    //   167: aaload
    //   168: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000000;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   173: <illegal opcode> 3 : (Lme/stupitdog/bhp/f1000000000;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   178: aload_0
    //   179: aload_0
    //   180: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   183: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   186: bipush #11
    //   188: iaload
    //   189: aaload
    //   190: aload_2
    //   191: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   194: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   197: bipush #12
    //   199: iaload
    //   200: aaload
    //   201: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1000000000;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   206: <illegal opcode> 4 : (Lme/stupitdog/bhp/f1000000000;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   211: aload_0
    //   212: aload_0
    //   213: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   216: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   219: bipush #13
    //   221: iaload
    //   222: aaload
    //   223: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   226: iconst_1
    //   227: iaload
    //   228: <illegal opcode> 5 : (Lme/stupitdog/bhp/f1000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   233: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   238: aload_0
    //   239: aload_0
    //   240: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   243: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   246: bipush #14
    //   248: iaload
    //   249: aaload
    //   250: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   253: bipush #10
    //   255: iaload
    //   256: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   259: iconst_0
    //   260: iaload
    //   261: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   264: bipush #15
    //   266: iaload
    //   267: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1000000000;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   272: <illegal opcode> 8 : (Lme/stupitdog/bhp/f1000000000;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   277: aload_0
    //   278: aload_0
    //   279: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   282: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   285: bipush #16
    //   287: iaload
    //   288: aaload
    //   289: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   292: bipush #10
    //   294: iaload
    //   295: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   298: iconst_0
    //   299: iaload
    //   300: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   303: bipush #15
    //   305: iaload
    //   306: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1000000000;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   311: <illegal opcode> 9 : (Lme/stupitdog/bhp/f1000000000;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   316: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	317	0	lllllllllllllllIllIIlIIlIIlllIIl	Lme/stupitdog/bhp/f1000000000;
    //   8	309	1	lllllllllllllllIllIIlIIlIIlllIII	Ljava/util/ArrayList;
    //   79	238	2	lllllllllllllllIllIIlIIlIIllIlll	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	309	1	lllllllllllllllIllIIlIIlIIlllIII	Ljava/util/ArrayList<Ljava/lang/String;>;
    //   79	238	2	lllllllllllllllIllIIlIIlIIllIlll	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIlllllIIlIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 542
    //   16: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   31: aload_0
    //   32: <illegal opcode> 13 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   37: <illegal opcode> 14 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   42: i2f
    //   43: invokestatic lIIIIlllllIIIllI : (FF)I
    //   46: invokestatic lIIIIlllllIIlIIl : (I)Z
    //   49: ifeq -> 88
    //   52: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   57: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   62: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   67: aload_0
    //   68: <illegal opcode> 16 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   73: <illegal opcode> 14 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   78: i2f
    //   79: invokestatic lIIIIlllllIIIlll : (FF)I
    //   82: invokestatic lIIIIlllllIIlIlI : (I)Z
    //   85: ifeq -> 149
    //   88: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   93: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   98: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   103: <illegal opcode> 18 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   108: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   111: iconst_0
    //   112: iaload
    //   113: <illegal opcode> 19 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   118: checkcast net/minecraft/item/ItemStack
    //   121: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   126: <illegal opcode> 21 : ()Lnet/minecraft/item/Item;
    //   131: invokestatic lIIIIlllllIIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   134: ifeq -> 148
    //   137: aload_0
    //   138: <illegal opcode> 21 : ()Lnet/minecraft/item/Item;
    //   143: <illegal opcode> 22 : (Lme/stupitdog/bhp/f1000000000;Lnet/minecraft/item/Item;)V
    //   148: return
    //   149: aload_0
    //   150: <illegal opcode> 23 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   155: <illegal opcode> 24 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   160: invokestatic lIIIIlllllIIllII : (I)Z
    //   163: ifeq -> 263
    //   166: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   171: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   176: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   181: <illegal opcode> 25 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/item/ItemStack;
    //   186: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   191: <illegal opcode> 26 : ()Lnet/minecraft/item/Item;
    //   196: invokestatic lIIIIlllllIIllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   199: ifeq -> 263
    //   202: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   207: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   212: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   217: <illegal opcode> 18 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   222: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   225: iconst_0
    //   226: iaload
    //   227: <illegal opcode> 19 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   232: checkcast net/minecraft/item/ItemStack
    //   235: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   240: <illegal opcode> 27 : ()Lnet/minecraft/item/Item;
    //   245: invokestatic lIIIIlllllIIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   248: ifeq -> 262
    //   251: aload_0
    //   252: <illegal opcode> 27 : ()Lnet/minecraft/item/Item;
    //   257: <illegal opcode> 22 : (Lme/stupitdog/bhp/f1000000000;Lnet/minecraft/item/Item;)V
    //   262: return
    //   263: aload_0
    //   264: <illegal opcode> 28 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   269: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   274: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   277: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   280: bipush #17
    //   282: iaload
    //   283: aaload
    //   284: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   289: invokestatic lIIIIlllllIIllII : (I)Z
    //   292: ifeq -> 356
    //   295: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   300: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   305: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   310: <illegal opcode> 18 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   315: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   318: iconst_0
    //   319: iaload
    //   320: <illegal opcode> 19 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   325: checkcast net/minecraft/item/ItemStack
    //   328: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   333: <illegal opcode> 31 : ()Lnet/minecraft/item/Item;
    //   338: invokestatic lIIIIlllllIIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   341: ifeq -> 355
    //   344: aload_0
    //   345: <illegal opcode> 31 : ()Lnet/minecraft/item/Item;
    //   350: <illegal opcode> 22 : (Lme/stupitdog/bhp/f1000000000;Lnet/minecraft/item/Item;)V
    //   355: return
    //   356: aload_0
    //   357: <illegal opcode> 28 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   362: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   367: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   370: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   373: bipush #18
    //   375: iaload
    //   376: aaload
    //   377: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   382: invokestatic lIIIIlllllIIllII : (I)Z
    //   385: ifeq -> 449
    //   388: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   393: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   398: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   403: <illegal opcode> 18 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   408: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   411: iconst_0
    //   412: iaload
    //   413: <illegal opcode> 19 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   418: checkcast net/minecraft/item/ItemStack
    //   421: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   426: <illegal opcode> 27 : ()Lnet/minecraft/item/Item;
    //   431: invokestatic lIIIIlllllIIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   434: ifeq -> 448
    //   437: aload_0
    //   438: <illegal opcode> 27 : ()Lnet/minecraft/item/Item;
    //   443: <illegal opcode> 22 : (Lme/stupitdog/bhp/f1000000000;Lnet/minecraft/item/Item;)V
    //   448: return
    //   449: aload_0
    //   450: <illegal opcode> 28 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   455: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   460: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   463: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   466: bipush #19
    //   468: iaload
    //   469: aaload
    //   470: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   475: invokestatic lIIIIlllllIIllII : (I)Z
    //   478: ifeq -> 542
    //   481: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   486: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   491: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   496: <illegal opcode> 18 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   501: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   504: iconst_0
    //   505: iaload
    //   506: <illegal opcode> 19 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   511: checkcast net/minecraft/item/ItemStack
    //   514: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   519: <illegal opcode> 21 : ()Lnet/minecraft/item/Item;
    //   524: invokestatic lIIIIlllllIIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   527: ifeq -> 541
    //   530: aload_0
    //   531: <illegal opcode> 21 : ()Lnet/minecraft/item/Item;
    //   536: <illegal opcode> 22 : (Lme/stupitdog/bhp/f1000000000;Lnet/minecraft/item/Item;)V
    //   541: return
    //   542: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	543	0	lllllllllllllllIllIIlIIlIIllIllI	Lme/stupitdog/bhp/f1000000000;
  }
  
  private int getItemSlot(Item lllllllllllllllIllIIlIIlIIllIIlI) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore_2
    //   6: iload_2
    //   7: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   10: bipush #15
    //   12: iaload
    //   13: invokestatic lIIIIlllllIIlllI : (II)Z
    //   16: ifeq -> 129
    //   19: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   29: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   34: iload_2
    //   35: <illegal opcode> 32 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   40: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   45: astore_3
    //   46: aload_3
    //   47: aload_1
    //   48: invokestatic lIIIIlllllIIllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   51: ifeq -> 72
    //   54: iload_2
    //   55: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   58: bipush #9
    //   60: iaload
    //   61: invokestatic lIIIIlllllIIlllI : (II)Z
    //   64: ifeq -> 70
    //   67: iinc #2, 36
    //   70: iload_2
    //   71: ireturn
    //   72: iinc #2, 1
    //   75: ldc ''
    //   77: invokevirtual length : ()I
    //   80: pop
    //   81: ldc ' '
    //   83: invokevirtual length : ()I
    //   86: ineg
    //   87: bipush #24
    //   89: bipush #69
    //   91: ixor
    //   92: bipush #73
    //   94: bipush #20
    //   96: ixor
    //   97: iconst_m1
    //   98: ixor
    //   99: iand
    //   100: if_icmple -> 6
    //   103: bipush #107
    //   105: bipush #114
    //   107: ixor
    //   108: ldc ' '
    //   110: invokevirtual length : ()I
    //   113: ishl
    //   114: bipush #72
    //   116: bipush #81
    //   118: ixor
    //   119: ldc ' '
    //   121: invokevirtual length : ()I
    //   124: ishl
    //   125: iconst_m1
    //   126: ixor
    //   127: iand
    //   128: ireturn
    //   129: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   132: bipush #20
    //   134: iaload
    //   135: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   46	26	3	lllllllllllllllIllIIlIIlIIllIlIl	Lnet/minecraft/item/Item;
    //   6	123	2	lllllllllllllllIllIIlIIlIIllIlII	I
    //   0	136	0	lllllllllllllllIllIIlIIlIIllIIll	Lme/stupitdog/bhp/f1000000000;
    //   0	136	1	lllllllllllllllIllIIlIIlIIllIIlI	Lnet/minecraft/item/Item;
  }
  
  public void switchTo(Item lllllllllllllllIllIIlIIlIIllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial getItemSlot : (Lnet/minecraft/item/Item;)I
    //   5: istore_2
    //   6: iload_2
    //   7: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   10: bipush #20
    //   12: iaload
    //   13: invokestatic lIIIIlllllIIllll : (II)Z
    //   16: ifeq -> 281
    //   19: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 33 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   29: instanceof net/minecraft/client/gui/inventory/GuiInventory
    //   32: invokestatic lIIIIlllllIlIIII : (I)Z
    //   35: ifeq -> 281
    //   38: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   43: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   48: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   53: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   58: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   63: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   68: iload_2
    //   69: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   72: iconst_0
    //   73: iaload
    //   74: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   79: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   84: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   89: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop2
    //   100: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   105: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   110: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   115: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   120: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   125: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   130: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   133: bipush #21
    //   135: iaload
    //   136: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   139: iconst_0
    //   140: iaload
    //   141: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   146: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   151: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   156: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   161: ldc ''
    //   163: invokevirtual length : ()I
    //   166: pop2
    //   167: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   172: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   177: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   182: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   187: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   192: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   197: iload_2
    //   198: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   201: iconst_0
    //   202: iaload
    //   203: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   208: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   213: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   218: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   223: ldc ''
    //   225: invokevirtual length : ()I
    //   228: pop2
    //   229: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   234: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   239: <illegal opcode> 39 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   244: ldc ''
    //   246: invokevirtual length : ()I
    //   249: pop
    //   250: bipush #119
    //   252: bipush #56
    //   254: iadd
    //   255: sipush #167
    //   258: isub
    //   259: sipush #133
    //   262: iadd
    //   263: bipush #7
    //   265: bipush #22
    //   267: ixor
    //   268: ldc_w '   '
    //   271: invokevirtual length : ()I
    //   274: ishl
    //   275: ixor
    //   276: ineg
    //   277: iflt -> 1121
    //   280: return
    //   281: aload_0
    //   282: <illegal opcode> 40 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   287: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   292: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   295: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   298: bipush #22
    //   300: iaload
    //   301: aaload
    //   302: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   307: invokestatic lIIIIlllllIIllII : (I)Z
    //   310: ifeq -> 561
    //   313: aload_0
    //   314: <illegal opcode> 31 : ()Lnet/minecraft/item/Item;
    //   319: invokespecial getItemSlot : (Lnet/minecraft/item/Item;)I
    //   322: istore_2
    //   323: iload_2
    //   324: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   327: bipush #20
    //   329: iaload
    //   330: invokestatic lIIIIlllllIIllll : (II)Z
    //   333: ifeq -> 561
    //   336: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   341: <illegal opcode> 33 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   346: instanceof net/minecraft/client/gui/inventory/GuiInventory
    //   349: invokestatic lIIIIlllllIlIIII : (I)Z
    //   352: ifeq -> 561
    //   355: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   360: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   365: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   370: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   375: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   380: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   385: iload_2
    //   386: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   389: iconst_0
    //   390: iaload
    //   391: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   396: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   401: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   406: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   411: ldc ''
    //   413: invokevirtual length : ()I
    //   416: pop2
    //   417: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   422: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   427: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   432: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   437: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   442: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   447: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   450: bipush #21
    //   452: iaload
    //   453: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   456: iconst_0
    //   457: iaload
    //   458: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   463: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   468: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   473: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   478: ldc ''
    //   480: invokevirtual length : ()I
    //   483: pop2
    //   484: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   489: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   494: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   499: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   504: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   509: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   514: iload_2
    //   515: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   518: iconst_0
    //   519: iaload
    //   520: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   525: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   530: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   535: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   540: ldc ''
    //   542: invokevirtual length : ()I
    //   545: pop2
    //   546: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   551: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   556: <illegal opcode> 39 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   561: aload_0
    //   562: <illegal opcode> 40 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   567: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   572: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   575: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   578: bipush #23
    //   580: iaload
    //   581: aaload
    //   582: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   587: invokestatic lIIIIlllllIIllII : (I)Z
    //   590: ifeq -> 841
    //   593: aload_0
    //   594: <illegal opcode> 27 : ()Lnet/minecraft/item/Item;
    //   599: invokespecial getItemSlot : (Lnet/minecraft/item/Item;)I
    //   602: istore_2
    //   603: iload_2
    //   604: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   607: bipush #20
    //   609: iaload
    //   610: invokestatic lIIIIlllllIIllll : (II)Z
    //   613: ifeq -> 841
    //   616: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   621: <illegal opcode> 33 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   626: instanceof net/minecraft/client/gui/inventory/GuiInventory
    //   629: invokestatic lIIIIlllllIlIIII : (I)Z
    //   632: ifeq -> 841
    //   635: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   640: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   645: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   650: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   655: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   660: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   665: iload_2
    //   666: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   669: iconst_0
    //   670: iaload
    //   671: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   676: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   681: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   686: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   691: ldc ''
    //   693: invokevirtual length : ()I
    //   696: pop2
    //   697: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   702: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   707: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   712: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   717: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   722: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   727: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   730: bipush #21
    //   732: iaload
    //   733: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   736: iconst_0
    //   737: iaload
    //   738: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   743: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   748: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   753: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   758: ldc ''
    //   760: invokevirtual length : ()I
    //   763: pop2
    //   764: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   769: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   774: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   779: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   784: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   789: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   794: iload_2
    //   795: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   798: iconst_0
    //   799: iaload
    //   800: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   805: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   810: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   815: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   820: ldc ''
    //   822: invokevirtual length : ()I
    //   825: pop2
    //   826: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   831: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   836: <illegal opcode> 39 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   841: aload_0
    //   842: <illegal opcode> 40 : (Lme/stupitdog/bhp/f1000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   847: <illegal opcode> 29 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   852: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIllIlIl : [Ljava/lang/String;
    //   855: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   858: bipush #24
    //   860: iaload
    //   861: aaload
    //   862: <illegal opcode> 30 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   867: invokestatic lIIIIlllllIIllII : (I)Z
    //   870: ifeq -> 1121
    //   873: aload_0
    //   874: <illegal opcode> 21 : ()Lnet/minecraft/item/Item;
    //   879: invokespecial getItemSlot : (Lnet/minecraft/item/Item;)I
    //   882: istore_2
    //   883: iload_2
    //   884: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   887: bipush #20
    //   889: iaload
    //   890: invokestatic lIIIIlllllIIllll : (II)Z
    //   893: ifeq -> 1121
    //   896: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   901: <illegal opcode> 33 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   906: instanceof net/minecraft/client/gui/inventory/GuiInventory
    //   909: invokestatic lIIIIlllllIlIIII : (I)Z
    //   912: ifeq -> 1121
    //   915: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   920: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   925: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   930: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   935: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   940: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   945: iload_2
    //   946: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   949: iconst_0
    //   950: iaload
    //   951: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   956: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   961: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   966: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   971: ldc ''
    //   973: invokevirtual length : ()I
    //   976: pop2
    //   977: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   982: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   987: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   992: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   997: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   1002: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   1007: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   1010: bipush #21
    //   1012: iaload
    //   1013: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   1016: iconst_0
    //   1017: iaload
    //   1018: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   1023: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1028: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1033: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   1038: ldc ''
    //   1040: invokevirtual length : ()I
    //   1043: pop2
    //   1044: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1049: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   1054: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1059: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1064: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   1069: <illegal opcode> 36 : (Lnet/minecraft/inventory/Container;)I
    //   1074: iload_2
    //   1075: getstatic me/stupitdog/bhp/f1000000000.llIIlIlIlllIlI : [I
    //   1078: iconst_0
    //   1079: iaload
    //   1080: <illegal opcode> 37 : ()Lnet/minecraft/inventory/ClickType;
    //   1085: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1090: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1095: <illegal opcode> 38 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   1100: ldc ''
    //   1102: invokevirtual length : ()I
    //   1105: pop2
    //   1106: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1111: <illegal opcode> 34 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   1116: <illegal opcode> 39 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   1121: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1122	0	lllllllllllllllIllIIlIIlIIllIIIl	Lme/stupitdog/bhp/f1000000000;
    //   0	1122	1	lllllllllllllllIllIIlIIlIIllIIII	Lnet/minecraft/item/Item;
    //   6	1116	2	lllllllllllllllIllIIlIIlIIlIllll	I
  }
  
  static {
    lIIIIlllllIIIlIl();
    lIIIIlllllIIIlII();
    lIIIIlllllIIIIll();
    lIIIIllllIllIlII();
  }
  
  private static CallSite lIIIIlIlIIlIIlII(MethodHandles.Lookup lllllllllllllllIllIIlIIlIIlIIllI, String lllllllllllllllIllIIlIIlIIlIIlIl, MethodType lllllllllllllllIllIIlIIlIIlIIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlIIlIIlIllII = llIIIllIllIlII[Integer.parseInt(lllllllllllllllIllIIlIIlIIlIIlIl)].split(llIIlIlIllIlIl[llIIlIlIlllIlI[25]]);
      Class<?> lllllllllllllllIllIIlIIlIIlIlIll = Class.forName(lllllllllllllllIllIIlIIlIIlIllII[llIIlIlIlllIlI[0]]);
      String lllllllllllllllIllIIlIIlIIlIlIlI = lllllllllllllllIllIIlIIlIIlIllII[llIIlIlIlllIlI[1]];
      MethodHandle lllllllllllllllIllIIlIIlIIlIlIIl = null;
      int lllllllllllllllIllIIlIIlIIlIlIII = lllllllllllllllIllIIlIIlIIlIllII[llIIlIlIlllIlI[3]].length();
      if (lIIIIlllllIlIIIl(lllllllllllllllIllIIlIIlIIlIlIII, llIIlIlIlllIlI[2])) {
        MethodType lllllllllllllllIllIIlIIlIIlIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlIIlIIlIllII[llIIlIlIlllIlI[2]], f1000000000.class.getClassLoader());
        if (lIIIIlllllIlIIlI(lllllllllllllllIllIIlIIlIIlIlIII, llIIlIlIlllIlI[2])) {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findVirtual(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIlllI);
          "".length();
          if ("   ".length() < (" ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findStatic(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIlllI);
        } 
        "".length();
        if (((0x72 ^ 0x6D) & (0x9F ^ 0x80 ^ 0xFFFFFFFF)) > " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlIIlIIlIllIl = llIIIllIllIlIl[Integer.parseInt(lllllllllllllllIllIIlIIlIIlIllII[llIIlIlIlllIlI[2]])];
        if (lIIIIlllllIlIIlI(lllllllllllllllIllIIlIIlIIlIlIII, llIIlIlIlllIlI[3])) {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findGetter(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIllIl);
          "".length();
          if (" ".length() << " ".length() == " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIlllllIlIIlI(lllllllllllllllIllIIlIIlIIlIlIII, llIIlIlIlllIlI[4])) {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findStaticGetter(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIllIl);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else if (lIIIIlllllIlIIlI(lllllllllllllllIllIIlIIlIIlIlIII, llIIlIlIlllIlI[5])) {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findSetter(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIllIl);
          "".length();
          if (((0xF1 ^ 0xB4) & (0x2B ^ 0x6E ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllIIlIIlIIlIlIIl = lllllllllllllllIllIIlIIlIIlIIllI.findStaticSetter(lllllllllllllllIllIIlIIlIIlIlIll, lllllllllllllllIllIIlIIlIIlIlIlI, lllllllllllllllIllIIlIIlIIlIllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlIIlIIlIlIIl);
    } catch (Exception lllllllllllllllIllIIlIIlIIlIIlll) {
      lllllllllllllllIllIIlIIlIIlIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllllIllIlII() {
    llIIIllIllIlII = new String[llIIlIlIlllIlI[26]];
    llIIIllIllIlII[llIIlIlIlllIlI[12]] = llIIlIlIllIlIl[llIIlIlIlllIlI[27]];
    llIIIllIllIlII[llIIlIlIlllIlI[28]] = llIIlIlIllIlIl[llIIlIlIlllIlI[29]];
    llIIIllIllIlII[llIIlIlIlllIlI[29]] = llIIlIlIllIlIl[llIIlIlIlllIlI[30]];
    llIIIllIllIlII[llIIlIlIlllIlI[22]] = llIIlIlIllIlIl[llIIlIlIlllIlI[31]];
    llIIIllIllIlII[llIIlIlIlllIlI[5]] = llIIlIlIllIlIl[llIIlIlIlllIlI[32]];
    llIIIllIllIlII[llIIlIlIlllIlI[10]] = llIIlIlIllIlIl[llIIlIlIlllIlI[33]];
    llIIIllIllIlII[llIIlIlIlllIlI[14]] = llIIlIlIllIlIl[llIIlIlIlllIlI[34]];
    llIIIllIllIlII[llIIlIlIlllIlI[7]] = llIIlIlIllIlIl[llIIlIlIlllIlI[35]];
    llIIIllIllIlII[llIIlIlIlllIlI[36]] = llIIlIlIllIlIl[llIIlIlIlllIlI[37]];
    llIIIllIllIlII[llIIlIlIlllIlI[23]] = llIIlIlIllIlIl[llIIlIlIlllIlI[28]];
    llIIIllIllIlII[llIIlIlIlllIlI[27]] = llIIlIlIllIlIl[llIIlIlIlllIlI[38]];
    llIIIllIllIlII[llIIlIlIlllIlI[39]] = llIIlIlIllIlIl[llIIlIlIlllIlI[40]];
    llIIIllIllIlII[llIIlIlIlllIlI[41]] = llIIlIlIllIlIl[llIIlIlIlllIlI[41]];
    llIIIllIllIlII[llIIlIlIlllIlI[4]] = llIIlIlIllIlIl[llIIlIlIlllIlI[15]];
    llIIIllIllIlII[llIIlIlIlllIlI[0]] = llIIlIlIllIlIl[llIIlIlIlllIlI[42]];
    llIIIllIllIlII[llIIlIlIlllIlI[9]] = llIIlIlIllIlIl[llIIlIlIlllIlI[39]];
    llIIIllIllIlII[llIIlIlIlllIlI[38]] = llIIlIlIllIlIl[llIIlIlIlllIlI[36]];
    llIIIllIllIlII[llIIlIlIlllIlI[35]] = llIIlIlIllIlIl[llIIlIlIlllIlI[43]];
    llIIIllIllIlII[llIIlIlIlllIlI[30]] = llIIlIlIllIlIl[llIIlIlIlllIlI[26]];
    llIIIllIllIlII[llIIlIlIlllIlI[37]] = llIIlIlIllIlIl[llIIlIlIlllIlI[44]];
    llIIIllIllIlII[llIIlIlIlllIlI[40]] = llIIlIlIllIlIl[llIIlIlIlllIlI[45]];
    llIIIllIllIlII[llIIlIlIlllIlI[13]] = llIIlIlIllIlIl[llIIlIlIlllIlI[46]];
    llIIIllIllIlII[llIIlIlIlllIlI[33]] = llIIlIlIllIlIl[llIIlIlIlllIlI[21]];
    llIIIllIllIlII[llIIlIlIlllIlI[34]] = llIIlIlIllIlIl[llIIlIlIlllIlI[47]];
    llIIIllIllIlII[llIIlIlIlllIlI[25]] = llIIlIlIllIlIl[llIIlIlIlllIlI[48]];
    llIIIllIllIlII[llIIlIlIlllIlI[15]] = llIIlIlIllIlIl[llIIlIlIlllIlI[49]];
    llIIIllIllIlII[llIIlIlIlllIlI[17]] = llIIlIlIllIlIl[llIIlIlIlllIlI[50]];
    llIIIllIllIlII[llIIlIlIlllIlI[2]] = llIIlIlIllIlIl[llIIlIlIlllIlI[51]];
    llIIIllIllIlII[llIIlIlIlllIlI[8]] = llIIlIlIllIlIl[llIIlIlIlllIlI[52]];
    llIIIllIllIlII[llIIlIlIlllIlI[3]] = llIIlIlIllIlIl[llIIlIlIlllIlI[53]];
    llIIIllIllIlII[llIIlIlIlllIlI[24]] = llIIlIlIllIlIl[llIIlIlIlllIlI[54]];
    llIIIllIllIlII[llIIlIlIlllIlI[18]] = llIIlIlIllIlIl[llIIlIlIlllIlI[55]];
    llIIIllIllIlII[llIIlIlIlllIlI[32]] = llIIlIlIllIlIl[llIIlIlIlllIlI[56]];
    llIIIllIllIlII[llIIlIlIlllIlI[42]] = llIIlIlIllIlIl[llIIlIlIlllIlI[57]];
    llIIIllIllIlII[llIIlIlIlllIlI[43]] = llIIlIlIllIlIl[llIIlIlIlllIlI[58]];
    llIIIllIllIlII[llIIlIlIlllIlI[11]] = llIIlIlIllIlIl[llIIlIlIlllIlI[59]];
    llIIIllIllIlII[llIIlIlIlllIlI[19]] = llIIlIlIllIlIl[llIIlIlIlllIlI[60]];
    llIIIllIllIlII[llIIlIlIlllIlI[16]] = llIIlIlIllIlIl[llIIlIlIlllIlI[61]];
    llIIIllIllIlII[llIIlIlIlllIlI[1]] = llIIlIlIllIlIl[llIIlIlIlllIlI[62]];
    llIIIllIllIlII[llIIlIlIlllIlI[6]] = llIIlIlIllIlIl[llIIlIlIlllIlI[63]];
    llIIIllIllIlII[llIIlIlIlllIlI[31]] = llIIlIlIllIlIl[llIIlIlIlllIlI[64]];
    llIIIllIllIlIl = new Class[llIIlIlIlllIlI[16]];
    llIIIllIllIlIl[llIIlIlIlllIlI[2]] = f100000000000000000000.Boolean.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[7]] = InventoryPlayer.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[1]] = f100000000000000000000.Mode.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[6]] = float.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[11]] = PlayerControllerMP.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[14]] = ClickType.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[3]] = f100000000000000000000.Integer.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[13]] = int.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[8]] = NonNullList.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[4]] = Minecraft.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[9]] = Item.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[0]] = f13.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[5]] = EntityPlayerSP.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[12]] = Container.class;
    llIIIllIllIlIl[llIIlIlIlllIlI[10]] = GuiScreen.class;
  }
  
  private static void lIIIIlllllIIIIll() {
    llIIlIlIllIlIl = new String[llIIlIlIlllIlI[65]];
    llIIlIlIllIlIl[llIIlIlIlllIlI[0]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[0]], llIIlIlIlllIIl[llIIlIlIlllIlI[1]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[1]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[2]], llIIlIlIlllIIl[llIIlIlIlllIlI[3]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[2]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[4]], llIIlIlIlllIIl[llIIlIlIlllIlI[5]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[3]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[6]], llIIlIlIlllIIl[llIIlIlIlllIlI[7]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[4]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[8]], llIIlIlIlllIIl[llIIlIlIlllIlI[9]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[5]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[10]], llIIlIlIlllIIl[llIIlIlIlllIlI[11]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[6]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[12]], llIIlIlIlllIIl[llIIlIlIlllIlI[13]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[7]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[14]], llIIlIlIlllIIl[llIIlIlIlllIlI[16]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[8]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[17]], llIIlIlIlllIIl[llIIlIlIlllIlI[18]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[9]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[19]], llIIlIlIlllIIl[llIIlIlIlllIlI[22]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[10]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[23]], llIIlIlIlllIIl[llIIlIlIlllIlI[24]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[11]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[25]], llIIlIlIlllIIl[llIIlIlIlllIlI[27]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[12]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[29]], llIIlIlIlllIIl[llIIlIlIlllIlI[30]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[13]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[31]], llIIlIlIlllIIl[llIIlIlIlllIlI[32]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[14]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[33]], llIIlIlIlllIIl[llIIlIlIlllIlI[34]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[16]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[35]], llIIlIlIlllIIl[llIIlIlIlllIlI[37]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[17]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[28]], llIIlIlIlllIIl[llIIlIlIlllIlI[38]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[18]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[40]], llIIlIlIlllIIl[llIIlIlIlllIlI[41]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[19]] = lIIIIllllIllIllI(llIIlIlIlllIIl[llIIlIlIlllIlI[15]], llIIlIlIlllIIl[llIIlIlIlllIlI[42]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[22]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[39]], llIIlIlIlllIIl[llIIlIlIlllIlI[36]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[23]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[43]], llIIlIlIlllIIl[llIIlIlIlllIlI[26]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[24]] = lIIIIllllIllIlll(llIIlIlIlllIIl[llIIlIlIlllIlI[44]], llIIlIlIlllIIl[llIIlIlIlllIlI[45]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[25]] = lIIIIllllIllIlIl(llIIlIlIlllIIl[llIIlIlIlllIlI[46]], llIIlIlIlllIIl[llIIlIlIlllIlI[21]]);
    llIIlIlIllIlIl[llIIlIlIlllIlI[27]] = lIIIIllllIllIllI("jFZetIZ/Z1gMuPncxuAukP/hj3Fd0YWgyHiGof//QdDl3H4a+m1/aVXrG/rJEIDaR53nO/vOTswFS0y7/aXwL4bRgEOQDkua", "JGdjG");
    llIIlIlIllIlIl[llIIlIlIlllIlI[29]] = lIIIIllllIllIllI("1PaOOoHdihlRsfaeTn2fHtEACQicFSOBN+L/2HoAFQrKwdOcB9TXiFOFOwqbJGWavT54RPgdVL03c9kgVDPoTXNjAmVrK7BcOfkqInt9mc005gqkyiUbdKxidgIaU91G", "oPurH");
    llIIlIlIllIlIl[llIIlIlIlllIlI[30]] = lIIIIllllIllIlIl("Gh14KjUCCD8tJRgfeDspB1YwaHFHSGZpcUdIZmlxR0hmaXFHSGZpZTUXOTUkFhZsPiQDLjc1NBJCfnAbTVh2", "wxVYA");
    llIIlIlIllIlIl[llIIlIlIlllIlI[31]] = lIIIIllllIllIlIl("CSIudz8OKT86IAYhLncnEy42dxwIKRQsPgsLMyomXSA/LWhPDnMVOAYxO3Y+Bik9dh0FLT86Jlx9enk=", "gGZYR");
    llIIlIlIllIlIl[llIIlIlIlllIlI[32]] = lIIIIllllIllIlIl("JQpKGxY9Hw0cBicISgoKOEECWVJ4X1RYUnhfVFIQLQgNGxYtHSYHDSQKBQZYYCMOCRQpQAgJDC9ANxwQIQEDUzhhIwkNTTsbERgLPAsLD00qBxRHBHlfVFhSeF9UWFJ4X1RYUnhfVFhSeEsmBw0kCgUGWXJPRA==", "Hodhb");
    llIIlIlIllIlIl[llIIlIlIlllIlI[33]] = lIIIIllllIllIlIl("Ly9FMg43OgI1Hi0tRSMSMmQNcEpyeltxSnJ6W3sXIXBfe1piaks=", "BJkAz");
    llIIlIlIllIlIl[llIIlIlIlllIlI[34]] = lIIIIllllIllIllI("lBNxdUze5YpOWUu5+akxGWqhxAqBaxnF9a7xKzjoQiFT0l2w0y/NcvdV6EbHh+YRfnZ1VVT1yd1AiWrBZMsQAA==", "hkXLj");
    llIIlIlIllIlIl[llIIlIlIlllIlI[35]] = lIIIIllllIllIlll("qvbWl4CjkAFhadBs/dZdKRXbzGLjqbZVEppE4Rwi+Om335zwRl2fJiTpvNP9mVfrrDXGzoraIZHlKMUh+ZbPbS+z2PYoYNdkJYFHrutmf3MTxsJLu/z6jqHTLaiLKFmLodMtqIsoWYtwcp5TTv807LE8evm6jn6Jsh9hTVivdxU=", "mcvGf");
    llIIlIlIllIlIl[llIIlIlIlllIlI[37]] = lIIIIllllIllIllI("/DYxWO7emr5Sp5y36BID7n1MkY+9NqJMtlkgRueSVuImGBQaTz3hR4PK5i0jCRy4ux4yT/7VdZtcbr2RPH8twzNixPGyk71Q", "eenWW");
    llIIlIlIllIlIl[llIIlIlIlllIlI[28]] = lIIIIllllIllIlll("wBWHLFmLij5rtY/WTejmDgk9bmgZ/854tZfKp5aG6j48cGKcKQubwCiO0qRpAZSTXjO34dTA6eka6qENhVo16NJpAtZWc7jhm+0ZF47IgNo=", "INWQe");
    llIIlIlIllIlIl[llIIlIlIlllIlI[38]] = lIIIIllllIllIlll("zcynrR9I64hBFF/ICat2H0lpFnVnCvvAuI87BivofPKnzvHjWWneg8EiQ8XMlxMY", "cLbaG");
    llIIlIlIllIlIl[llIIlIlIlllIlI[40]] = lIIIIllllIllIlll("RtZPZCEJ8b8TvBgyYJSxKnDuNUjKiJWAAR3JVCsbdxMsr4mbRr+frc/v+kHXvOUZbyQLYkcBIu/RhJGyCQSW4Ss71LkNMQCikIMshoEj2rD7vfdky23kp5+n4hmc3svYspCAvNCMEtZ4ieI8DIqXuqoV71sKoMVsokEnGM00CfADjs8svtZJc+7FV2z27olwLc+EIH/k1axAk9CWHiuSgg7fU2y28fMhhI5A1GILmPnEU0z4uHcnaA==", "rpFOU");
    llIIlIlIllIlIl[llIIlIlIlllIlI[41]] = lIIIIllllIllIllI("c/q2x8c7HMAYMJyGD8F+PaVBf4hS1W5QTIDPakrUGnRJJ6Gi6atlUFOhH3CirVwHqYORuGo8KxP7hBrzQpw2h+iSMUKd0SGh", "hTiAG");
    llIIlIlIllIlIl[llIIlIlIlllIlI[15]] = lIIIIllllIllIlIl("ITxpIhk5KS4lCSM+aTMFPHchYF18aXdhXXxpd2sLLTUrMwwvMn1gV2x5Z3FN", "LYGQm");
    llIIlIlIllIlIl[llIIlIlIlllIlI[42]] = lIIIIllllIllIllI("UPAnpL9cl41Jj7rawHZM6pJqZSRddZWjs/RZCFjuqUkBM44uBAAQHw==", "BIUpP");
    llIIlIlIllIlIl[llIIlIlIlllIlI[39]] = lIIIIllllIllIllI("V5CbkKCRISXqzB0GUWsiXnGrXjUJLVMELFGmRMFoVjngBeAccul0KepyydUWTBCaLrsMr5nfeGY=", "HlUZo");
    llIIlIlIllIlIl[llIIlIlIlllIlI[36]] = lIIIIllllIllIlIl("HBEBaxkbGhAmBhMSAWsXHh0QKwBcORwrEREGFCMASBIcIBgWK0J0QERGKjdOQ0RPZVRS", "rtuEt");
    llIIlIlIllIlIl[llIIlIlIlllIlI[43]] = lIIIIllllIllIlll("D1E21mQWfRjzFuMdXPc/3wUG0XLjMJauZNLJ8pYYX7ZpUKGFEH4sDTnmlc8PJLEXCDJOJvYYaJQ7BsuEzLv7TQ==", "YDQkl");
    llIIlIlIllIlIl[llIIlIlIlllIlI[26]] = lIIIIllllIllIlll("bjcZ6GUk/+nVX8Hp7agNvBsa8H3jdYZooU6j4K/RqFlKUeKY3x7I5cZzFJWwEtVJ5BkU4x+Mhl0dqpHtKOG9PzXdzN9ZMRi/iCE6cS2RqfYmjUZ3Ik73EJ+rOVnVOW6Q", "rzuPr");
    llIIlIlIllIlIl[llIIlIlIlllIlI[44]] = lIIIIllllIllIlIl("IzMhVAokODAZFSwwIVQOIz8hVC45MzgJXSs/MBYDEmdtT1Z4bgoZN3dvb1pHbXY=", "MVUzg");
    llIIlIlIllIlIl[llIIlIlIlllIlI[45]] = lIIIIllllIllIlIl("ADE3SikHOiYHNg8yN0onAj0mCjBAGSoKIQ0mIgIwVDIqASgKC3RVcFpmHAZ+X2V5RGRO", "nTCdD");
    llIIlIlIllIlIl[llIIlIlIlllIlI[46]] = lIIIIllllIllIlll("rY1hR+q0Bhhm5kS1eNMQhkRSMsun+tvKYOoFQ0FMKj1RTkr7Yqpfbc4KUGkpOIPW", "JJKjW");
    llIIlIlIllIlIl[llIIlIlIlllIlI[21]] = lIIIIllllIllIlIl("AyRMJiMbMQshMwEmTDc/Hm8EZGdecVJlZ15xUm86ASUHb2ZUYUJ1", "nAbUW");
    llIIlIlIllIlIl[llIIlIlIlllIlI[47]] = lIIIIllllIllIlIl("Owt9GiwjHjodPDkJfQswJkA1WGhmXmNZaGZeY1loZl5jWWhmXmNZfBsBNwxiMQsnPzk6GzZTcH8iOQguN0E/CDYxQQAdKj8ANFJidk4=", "VnSiX");
    llIIlIlIllIlIl[llIIlIlIlllIlI[48]] = lIIIIllllIllIlll("njVqvSNZAHyKjSDGJn/lzsMhpTx95KQ0KO28TUFMjg6Xs3uAYPOKhBFv03LP8lRMyXR8KsD4q8S31B+vnDRaiqg0/vWycSgs", "UqjLD");
    llIIlIlIllIlIl[llIIlIlIlllIlI[49]] = lIIIIllllIllIlIl("HCIYbD4bKQkhIRMhGGw6HDEJLCcdNRVsEB0pGCM6HCIeeDUbIgAmDEVyXXdhLSRWc2BIZ0xi", "rGlBS");
    llIIlIlIllIlIl[llIIlIlIlllIlI[50]] = lIIIIllllIllIllI("in/qBgbWXOLlHkSE5V5/4VMRrW2WonrsEjZQVLwczz63s6apTKG03rPQx9/+QYZbCfdSVIOkE8w=", "NRBNT");
    llIIlIlIllIlIl[llIIlIlIlllIlI[51]] = lIIIIllllIllIlIl("NDNCNzosJgUwKjYxQiYmKXgKdX5pZlx0fmlmXH48PDEFNzo8JCErKjxsRAgkOCANayI4OAtrHS0kBSopYhoGJTg4eRkwJzV5IC09LW0gLi8vN0MoLzcxQxc6Kz8CI3VwGgEhYSoiGTQnLTIDI2E7PhxrKGhmXHR+aWZcdH5pZlx0fmlmXHR+aXIhKyo8bVZkbg==", "YVlDN");
    llIIlIlIllIlIl[llIIlIlIlllIlI[52]] = lIIIIllllIllIllI("88vAKqnknHdM5+cCQS5Oy3LOsRSfT2MNPicQMJU8rLRwCCzCoTb6rxOGqGSFq4RnKYdm0Ynj4nA=", "VdQta");
    llIIlIlIllIlIl[llIIlIlIlllIlI[53]] = lIIIIllllIllIllI("RlErl0vaa5chOa+5edoF4C//Zqz8/1j8xM+m3CJF0dTCG09CoKjyPouaVcJVjfuc", "jHyFB");
    llIIlIlIllIlIl[llIIlIlIlllIlI[54]] = lIIIIllllIllIlIl("GCMHQQEfKBYMHhcgB0EFGC8HQSUCIx4cVhAvFgMIKXdKX1VEfywMNUx/SU9MVmY=", "vFsol");
    llIIlIlIllIlIl[llIIlIlIlllIlI[55]] = lIIIIllllIllIlIl("JBAsYgUjGz0vGisTLGILJhw9IhxkEDY4AT4MdgkGPhwsNTgmFCEpGhklYioBLxk8E197RW99NygMYntSalV4", "JuXLh");
    llIIlIlIllIlIl[llIIlIlIlllIlI[56]] = lIIIIllllIllIllI("tmS1YskjZ5oqCTcCLT/iEiVSwZQJdM3vaTqxcGLfb5Bbl61ors6HTzAsliXR/BZ4", "UrmEh");
    llIIlIlIllIlIl[llIIlIlIlllIlI[57]] = lIIIIllllIllIlll("jVIS+tNyyUImmahSyU8gkTnIcg7fReNy6XR+eulxjEiF5pI05smX+EGgamke1oszv1w2/NeLSHU=", "MIHKz");
    llIIlIlIllIlIl[llIIlIlIlllIlI[58]] = lIIIIllllIllIlIl("IyF2AgI7NDEFEiEjdhMePmo+QEZ+dGhBRn50aEsQLyg0ExctL2JATG5keA==", "NDXqv");
    llIIlIlIllIlIl[llIIlIlIlllIlI[59]] = lIIIIllllIllIlIl("BgkVaAYBAgQlGQkKFWgIBAUEKB9GIQgoDgseACAfUgoIIwcMM1Z3X1tVPiFRXVZBZks=", "hlaFk");
    llIIlIlIllIlIl[llIIlIlIlllIlI[60]] = lIIIIllllIllIlll("LMHcapxOic+SFGgcthk7fOaOWFgslvTGwUvRHVslljBP7PQdql74l5MPkyhquf70M2qJP41TcSApVHL4lbU8p12060hoEWCw", "wIVLO");
    llIIlIlIllIlIl[llIIlIlIlllIlI[61]] = lIIIIllllIllIlIl("Iz81YhgkNCQvByw8NWIWITMkIgFjPy84HDkjbwkbOTM1NSUhOzgpBx4KeyocKDYlE0J9a3V/Kh9gd3ZVbXo=", "MZALu");
    llIIlIlIllIlIl[llIIlIlIlllIlI[62]] = lIIIIllllIllIllI("KJ8RkFDYEohrIvCGt4jkzS9nW2Hs0E64dW7WNgUgyE2tExMUvtAVcLxRmAHztAHgqO37wlAwyQ8=", "nRQiZ");
    llIIlIlIllIlIl[llIIlIlIlllIlI[63]] = lIIIIllllIllIllI("pGd68YgEW/3PrxhjWav1XJlBcvjuRWN8tsCtKY+3ZWZT0ihKFJEqgtyVs/KjPhLC", "VzfJb");
    llIIlIlIllIlIl[llIIlIlIlllIlI[64]] = lIIIIllllIllIlll("9Qp/j3AhiLXfi5P4YNl6DeCAuBoMBrg1i3wo5neV1tFzoHK+vtAVjLn0DbFFYpfF", "lZLQX");
    llIIlIlIlllIIl = null;
  }
  
  private static void lIIIIlllllIIIlII() {
    String str = (new Exception()).getStackTrace()[llIIlIlIlllIlI[0]].getFileName();
    llIIlIlIlllIIl = str.substring(str.indexOf("ä") + llIIlIlIlllIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllllIllIllI(String lllllllllllllllIllIIlIIlIIlIIIII, String lllllllllllllllIllIIlIIlIIIlllll) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIlIIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIlIIIlllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIIlIIlIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIIlIIlIIIlI.init(llIIlIlIlllIlI[2], lllllllllllllllIllIIlIIlIIlIIIll);
      return new String(lllllllllllllllIllIIlIIlIIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlIIlIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIlIIlIIIIl) {
      lllllllllllllllIllIIlIIlIIlIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllllIllIlll(String lllllllllllllllIllIIlIIlIIIllIll, String lllllllllllllllIllIIlIIlIIIllIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIlIIlIIIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIlIIIllIlI.getBytes(StandardCharsets.UTF_8)), llIIlIlIlllIlI[8]), "DES");
      Cipher lllllllllllllllIllIIlIIlIIIlllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIIlIIIlllIl.init(llIIlIlIlllIlI[2], lllllllllllllllIllIIlIIlIIIllllI);
      return new String(lllllllllllllllIllIIlIIlIIIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlIIIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlIIlIIIlllII) {
      lllllllllllllllIllIIlIIlIIIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllllIllIlIl(String lllllllllllllllIllIIlIIlIIIllIII, String lllllllllllllllIllIIlIIlIIIlIlll) {
    lllllllllllllllIllIIlIIlIIIllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlIIIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIIlIIIlIllI = new StringBuilder();
    char[] lllllllllllllllIllIIlIIlIIIlIlIl = lllllllllllllllIllIIlIIlIIIlIlll.toCharArray();
    int lllllllllllllllIllIIlIIlIIIlIlII = llIIlIlIlllIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlIIlIIIllIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIlIlllIlI[0];
    while (lIIIIlllllIIlllI(j, i)) {
      char lllllllllllllllIllIIlIIlIIIllIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlIIlIIIlIlII++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlIIlIIIlIllI);
  }
  
  private static void lIIIIlllllIIIlIl() {
    llIIlIlIlllIlI = new int[66];
    llIIlIlIlllIlI[0] = "   ".length() << (" ".length() << " ".length() << " ".length() ^ " ".length()) & ("   ".length() << (0xD ^ 0x22 ^ (0x99 ^ 0x8C) << " ".length()) ^ -" ".length());
    llIIlIlIlllIlI[1] = " ".length();
    llIIlIlIlllIlI[2] = " ".length() << " ".length();
    llIIlIlIlllIlI[3] = "   ".length();
    llIIlIlIlllIlI[4] = " ".length() << " ".length() << " ".length();
    llIIlIlIlllIlI[5] = 0x5C ^ 0x59;
    llIIlIlIlllIlI[6] = "   ".length() << " ".length();
    llIIlIlIlllIlI[7] = 0x20 ^ 0x27;
    llIIlIlIlllIlI[8] = " ".length() << "   ".length();
    llIIlIlIlllIlI[9] = 0x9F ^ 0x96;
    llIIlIlIlllIlI[10] = (0x1E ^ 0x1B) << " ".length();
    llIIlIlIlllIlI[11] = 0x11 ^ 0x44 ^ (0xA9 ^ 0x86) << " ".length();
    llIIlIlIlllIlI[12] = "   ".length() << " ".length() << " ".length();
    llIIlIlIlllIlI[13] = 0x58 ^ 0x55;
    llIIlIlIlllIlI[14] = ((0x4E ^ 0x45) << " ".length() ^ 0x70 ^ 0x61) << " ".length();
    llIIlIlIlllIlI[15] = (73 + 72 - 107 + 89 ^ (0x98 ^ 0xA3) << " ".length()) << " ".length() << " ".length();
    llIIlIlIlllIlI[16] = 0x20 ^ 0x27 ^ " ".length() << "   ".length();
    llIIlIlIlllIlI[17] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIlllIlI[18] = (0x29 ^ 0x2C) << " ".length() << " ".length() ^ 0x9A ^ 0x9F;
    llIIlIlIlllIlI[19] = ((0x58 ^ 0x6D) << " ".length() ^ 0x43 ^ 0x20) << " ".length();
    llIIlIlIlllIlI[20] = -" ".length();
    llIIlIlIlllIlI[21] = 0x13 ^ 0x24 ^ (0x68 ^ 0x65) << " ".length();
    llIIlIlIlllIlI[22] = (0xFD ^ 0xC6) << " ".length() ^ 0xFC ^ 0x99;
    llIIlIlIlllIlI[23] = (0xB2 ^ 0xC3 ^ (0x18 ^ 0x5) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIlIlIlllIlI[24] = 0x70 ^ 0x65;
    llIIlIlIlllIlI[25] = ((0x92 ^ 0x87) << "   ".length() ^ 84 + 110 - 135 + 104) << " ".length();
    llIIlIlIlllIlI[26] = 156 + 162 - 305 + 160 ^ (0xB0 ^ 0x91) << " ".length() << " ".length();
    llIIlIlIlllIlI[27] = 0x98 ^ 0x8F;
    llIIlIlIlllIlI[28] = " ".length() << (0x3B ^ 0x3E);
    llIIlIlIlllIlI[29] = "   ".length() << "   ".length();
    llIIlIlIlllIlI[30] = 134 + 18 - 7 + 22 ^ (0x7C ^ 0x23) << " ".length();
    llIIlIlIlllIlI[31] = (0x8B ^ 0x86) << " ".length();
    llIIlIlIlllIlI[32] = 0xEE ^ 0xB1 ^ (0xA2 ^ 0xB3) << " ".length() << " ".length();
    llIIlIlIlllIlI[33] = ((0x84 ^ 0xA7) << " ".length() ^ 0x7F ^ 0x3E) << " ".length() << " ".length();
    llIIlIlIlllIlI[34] = 145 + 54 - 134 + 88 ^ (0xAD ^ 0x8C) << " ".length() << " ".length();
    llIIlIlIlllIlI[35] = (0x2D ^ 0x22) << " ".length();
    llIIlIlIlllIlI[36] = 0x8D ^ 0xA4 ^ (0xC7 ^ 0xC0) << " ".length();
    llIIlIlIlllIlI[37] = (0xAA ^ 0x87) << " ".length() << " ".length() ^ 114 + 138 - 159 + 78;
    llIIlIlIlllIlI[38] = 0x8D ^ 0xAC;
    llIIlIlIlllIlI[39] = (0xAE ^ 0xBD) << " ".length();
    llIIlIlIlllIlI[40] = ((0xB2 ^ 0xA1) << "   ".length() ^ 40 + 39 - -37 + 21) << " ".length();
    llIIlIlIlllIlI[41] = "   ".length() << " ".length() << " ".length() ^ 0x13 ^ 0x3C;
    llIIlIlIlllIlI[42] = 0xE6 ^ 0xC3;
    llIIlIlIlllIlI[43] = (0x97 ^ 0x92) << "   ".length();
    llIIlIlIlllIlI[44] = ((0xAC ^ 0x9D) << " ".length() ^ 0x13 ^ 0x64) << " ".length();
    llIIlIlIlllIlI[45] = (0x4 ^ 0x73) << " ".length() ^ 7 + 149 - 89 + 130;
    llIIlIlIlllIlI[46] = (0x1F ^ 0x14) << " ".length() << " ".length();
    llIIlIlIlllIlI[47] = (0x13 ^ 0x4) << " ".length();
    llIIlIlIlllIlI[48] = 0x60 ^ 0x4F;
    llIIlIlIlllIlI[49] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIlIlIlllIlI[50] = 114 + 94 - 165 + 106 ^ (0x8E ^ 0xA7) << " ".length() << " ".length();
    llIIlIlIlllIlI[51] = (0x66 ^ 0x7F) << " ".length();
    llIIlIlIlllIlI[52] = (0x42 ^ 0xF) << " ".length() ^ 51 + 147 - 43 + 14;
    llIIlIlIlllIlI[53] = (0x21 ^ 0x4C ^ "   ".length() << (0x6 ^ 0x3)) << " ".length() << " ".length();
    llIIlIlIlllIlI[54] = 0x1 ^ 0x34;
    llIIlIlIlllIlI[55] = (0x2F ^ 0x34) << " ".length();
    llIIlIlIlllIlI[56] = 0xAB ^ 0x9C;
    llIIlIlIlllIlI[57] = (0x86 ^ 0x81) << "   ".length();
    llIIlIlIlllIlI[58] = 0xB4 ^ 0x8D;
    llIIlIlIlllIlI[59] = (0xB8 ^ 0xA5) << " ".length();
    llIIlIlIlllIlI[60] = 20 + 135 - 52 + 50 ^ (0x45 ^ 0x14) << " ".length();
    llIIlIlIlllIlI[61] = (0x6C ^ 0x63) << " ".length() << " ".length();
    llIIlIlIlllIlI[62] = (0x2B ^ 0x14) << " ".length() ^ 0x3D ^ 0x7E;
    llIIlIlIlllIlI[63] = ((0xE ^ 0x2D) << " ".length() << " ".length() ^ 21 + 66 - 77 + 137) << " ".length();
    llIIlIlIlllIlI[64] = 0x1A ^ 0x25;
    llIIlIlIlllIlI[65] = " ".length() << "   ".length() << " ".length();
  }
  
  private static boolean lIIIIlllllIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlllllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlllllIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlllllIIlIll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIlllllIIlIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIlllllIIllIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIlllllIIllII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlllllIlIIII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlllllIIlIIl(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lIIIIlllllIIlIlI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static boolean lIIIIlllllIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIlllllIIIlll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIlllllIIIllI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */