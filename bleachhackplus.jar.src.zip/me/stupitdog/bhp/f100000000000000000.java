package me.stupitdog.bhp;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class f100000000000000000 {
  protected static Minecraft mc;
  
  private static String[] llIIIllIIIlllI;
  
  private static Class[] llIIIllIIIllll;
  
  private static final String[] llIIIllIlIIIll;
  
  private static String[] llIIIllIlIIlIl;
  
  private static final int[] llIIIllIlIIllI;
  
  public static void prepareGL() {
    // Byte code:
    //   0: <illegal opcode> 0 : ()V
    //   5: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   8: iconst_0
    //   9: iaload
    //   10: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   13: iconst_1
    //   14: iaload
    //   15: <illegal opcode> 1 : (II)V
    //   20: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   23: iconst_2
    //   24: iaload
    //   25: <illegal opcode> 2 : (I)V
    //   30: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   33: iconst_3
    //   34: iaload
    //   35: <illegal opcode> 3 : (I)V
    //   40: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   43: iconst_4
    //   44: iaload
    //   45: <illegal opcode> 3 : (I)V
    //   50: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   53: iconst_5
    //   54: iaload
    //   55: <illegal opcode> 4 : (Z)V
    //   60: fconst_2
    //   61: <illegal opcode> 5 : (F)V
    //   66: return
  }
  
  public static void releaseGL() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   3: iconst_3
    //   4: iaload
    //   5: <illegal opcode> 2 : (I)V
    //   10: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   13: iconst_4
    //   14: iaload
    //   15: <illegal opcode> 2 : (I)V
    //   20: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   23: bipush #6
    //   25: iaload
    //   26: <illegal opcode> 4 : (Z)V
    //   31: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   34: iconst_2
    //   35: iaload
    //   36: <illegal opcode> 3 : (I)V
    //   41: <illegal opcode> 6 : ()V
    //   46: return
  }
  
  public static AxisAlignedBB generateBB(long lllllllllllllllIllIlIIlIllIIlIll, long lllllllllllllllIllIlIIlIllIIlIlI, long lllllllllllllllIllIlIIlIllIIlIIl) {
    // Byte code:
    //   0: new net/minecraft/util/math/BlockPos
    //   3: dup
    //   4: lload_0
    //   5: l2d
    //   6: lload_2
    //   7: l2d
    //   8: lload #4
    //   10: l2d
    //   11: invokespecial <init> : (DDD)V
    //   14: astore #6
    //   16: new net/minecraft/util/math/AxisAlignedBB
    //   19: dup
    //   20: aload #6
    //   22: <illegal opcode> 7 : (Lnet/minecraft/util/math/BlockPos;)I
    //   27: i2d
    //   28: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   38: <illegal opcode> 10 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   43: dsub
    //   44: aload #6
    //   46: <illegal opcode> 11 : (Lnet/minecraft/util/math/BlockPos;)I
    //   51: i2d
    //   52: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   57: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   62: <illegal opcode> 12 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   67: dsub
    //   68: aload #6
    //   70: <illegal opcode> 13 : (Lnet/minecraft/util/math/BlockPos;)I
    //   75: i2d
    //   76: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   81: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   86: <illegal opcode> 14 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   91: dsub
    //   92: aload #6
    //   94: <illegal opcode> 7 : (Lnet/minecraft/util/math/BlockPos;)I
    //   99: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   102: bipush #6
    //   104: iaload
    //   105: iadd
    //   106: i2d
    //   107: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   112: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   117: <illegal opcode> 10 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   122: dsub
    //   123: aload #6
    //   125: <illegal opcode> 11 : (Lnet/minecraft/util/math/BlockPos;)I
    //   130: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   133: bipush #6
    //   135: iaload
    //   136: iadd
    //   137: i2d
    //   138: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   143: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   148: <illegal opcode> 12 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   153: dsub
    //   154: aload #6
    //   156: <illegal opcode> 13 : (Lnet/minecraft/util/math/BlockPos;)I
    //   161: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   164: bipush #6
    //   166: iaload
    //   167: iadd
    //   168: i2d
    //   169: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   174: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   179: <illegal opcode> 14 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   184: dsub
    //   185: invokespecial <init> : (DDDDDD)V
    //   188: astore #7
    //   190: aload #7
    //   192: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	193	0	lllllllllllllllIllIlIIlIllIIlIll	J
    //   0	193	2	lllllllllllllllIllIlIIlIllIIlIlI	J
    //   0	193	4	lllllllllllllllIllIlIIlIllIIlIIl	J
    //   16	177	6	lllllllllllllllIllIlIIlIllIIlIII	Lnet/minecraft/util/math/BlockPos;
    //   190	3	7	lllllllllllllllIllIlIIlIllIIIlll	Lnet/minecraft/util/math/AxisAlignedBB;
  }
  
  public static void draw2DRect(int lllllllllllllllIllIlIIlIllIIIllI, int lllllllllllllllIllIlIIlIllIIIlIl, int lllllllllllllllIllIlIIlIllIIIlII, int lllllllllllllllIllIlIIlIllIIIIll, int lllllllllllllllIllIlIIlIllIIIIlI, f01 lllllllllllllllIllIlIIlIllIIIIIl) {
    // Byte code:
    //   0: <illegal opcode> 15 : ()Lnet/minecraft/client/renderer/Tessellator;
    //   5: astore #6
    //   7: aload #6
    //   9: <illegal opcode> 16 : (Lnet/minecraft/client/renderer/Tessellator;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   14: astore #7
    //   16: <illegal opcode> 17 : ()V
    //   21: <illegal opcode> 18 : ()V
    //   26: <illegal opcode> 19 : ()Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
    //   31: <illegal opcode> 20 : ()Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
    //   36: <illegal opcode> 21 : ()Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
    //   41: <illegal opcode> 22 : ()Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
    //   46: <illegal opcode> 23 : (Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
    //   51: aload #5
    //   53: <illegal opcode> 24 : (Lme/stupitdog/bhp/f01;)V
    //   58: aload #7
    //   60: getstatic me/stupitdog/bhp/f100000000000000000.llIIIllIlIIllI : [I
    //   63: bipush #7
    //   65: iaload
    //   66: <illegal opcode> 25 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   71: <illegal opcode> 26 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   76: aload #7
    //   78: iload_0
    //   79: i2d
    //   80: iload_1
    //   81: iload_3
    //   82: iadd
    //   83: i2d
    //   84: iload #4
    //   86: i2d
    //   87: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   92: <illegal opcode> 28 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   97: aload #7
    //   99: iload_0
    //   100: iload_2
    //   101: iadd
    //   102: i2d
    //   103: iload_1
    //   104: iload_3
    //   105: iadd
    //   106: i2d
    //   107: iload #4
    //   109: i2d
    //   110: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   115: <illegal opcode> 28 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   120: aload #7
    //   122: iload_0
    //   123: iload_2
    //   124: iadd
    //   125: i2d
    //   126: iload_1
    //   127: i2d
    //   128: iload #4
    //   130: i2d
    //   131: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   136: <illegal opcode> 28 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   141: aload #7
    //   143: iload_0
    //   144: i2d
    //   145: iload_1
    //   146: i2d
    //   147: iload #4
    //   149: i2d
    //   150: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   155: <illegal opcode> 28 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   160: aload #6
    //   162: <illegal opcode> 29 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   167: <illegal opcode> 30 : ()V
    //   172: <illegal opcode> 31 : ()V
    //   177: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	178	0	lllllllllllllllIllIlIIlIllIIIllI	I
    //   0	178	1	lllllllllllllllIllIlIIlIllIIIlIl	I
    //   0	178	2	lllllllllllllllIllIlIIlIllIIIlII	I
    //   0	178	3	lllllllllllllllIllIlIIlIllIIIIll	I
    //   0	178	4	lllllllllllllllIllIlIIlIllIIIIlI	I
    //   0	178	5	lllllllllllllllIllIlIIlIllIIIIIl	Lme/stupitdog/bhp/f01;
    //   7	171	6	lllllllllllllllIllIlIIlIllIIIIII	Lnet/minecraft/client/renderer/Tessellator;
    //   16	162	7	lllllllllllllllIllIlIIlIlIllllll	Lnet/minecraft/client/renderer/BufferBuilder;
  }
  
  public static void drawBox(AxisAlignedBB lllllllllllllllIllIlIIlIlIlllllI, float lllllllllllllllIllIlIIlIlIllllIl, float lllllllllllllllIllIlIIlIlIllllII, float lllllllllllllllIllIlIIlIlIlllIll, float lllllllllllllllIllIlIIlIlIlllIlI) {
    // Byte code:
    //   0: <illegal opcode> 32 : ()V
    //   5: aload_0
    //   6: fload_1
    //   7: fload_2
    //   8: fload_3
    //   9: fload #4
    //   11: <illegal opcode> 33 : (Lnet/minecraft/util/math/AxisAlignedBB;FFFF)V
    //   16: <illegal opcode> 34 : ()V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIllIlIIlIlIlllllI	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	22	1	lllllllllllllllIllIlIIlIlIllllIl	F
    //   0	22	2	lllllllllllllllIllIlIIlIlIllllII	F
    //   0	22	3	lllllllllllllllIllIlIIlIlIlllIll	F
    //   0	22	4	lllllllllllllllIllIlIIlIlIlllIlI	F
  }
  
  public static void drawBoxOutline(AxisAlignedBB lllllllllllllllIllIlIIlIlIlllIIl, float lllllllllllllllIllIlIIlIlIlllIII, float lllllllllllllllIllIlIIlIlIllIlll, float lllllllllllllllIllIlIIlIlIllIllI, float lllllllllllllllIllIlIIlIlIllIlIl) {
    // Byte code:
    //   0: <illegal opcode> 32 : ()V
    //   5: aload_0
    //   6: fload_1
    //   7: fload_2
    //   8: fload_3
    //   9: fload #4
    //   11: <illegal opcode> 33 : (Lnet/minecraft/util/math/AxisAlignedBB;FFFF)V
    //   16: aload_0
    //   17: fload_1
    //   18: fload_2
    //   19: fload_3
    //   20: fload #4
    //   22: ldc 1.5
    //   24: fmul
    //   25: <illegal opcode> 35 : (Lnet/minecraft/util/math/AxisAlignedBB;FFFF)V
    //   30: <illegal opcode> 34 : ()V
    //   35: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	36	0	lllllllllllllllIllIlIIlIlIlllIIl	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	36	1	lllllllllllllllIllIlIIlIlIlllIII	F
    //   0	36	2	lllllllllllllllIllIlIIlIlIllIlll	F
    //   0	36	3	lllllllllllllllIllIlIIlIlIllIllI	F
    //   0	36	4	lllllllllllllllIllIlIIlIlIllIlIl	F
  }
  
  public static void drawOutline(AxisAlignedBB lllllllllllllllIllIlIIlIlIllIlII, float lllllllllllllllIllIlIIlIlIllIIll, float lllllllllllllllIllIlIIlIlIllIIlI, float lllllllllllllllIllIlIIlIlIllIIIl, float lllllllllllllllIllIlIIlIlIllIIII) {
    // Byte code:
    //   0: <illegal opcode> 32 : ()V
    //   5: aload_0
    //   6: fload_1
    //   7: fload_2
    //   8: fload_3
    //   9: fload #4
    //   11: ldc 1.5
    //   13: fmul
    //   14: <illegal opcode> 35 : (Lnet/minecraft/util/math/AxisAlignedBB;FFFF)V
    //   19: <illegal opcode> 34 : ()V
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	0	lllllllllllllllIllIlIIlIlIllIlII	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	25	1	lllllllllllllllIllIlIIlIlIllIIll	F
    //   0	25	2	lllllllllllllllIllIlIIlIlIllIIlI	F
    //   0	25	3	lllllllllllllllIllIlIIlIlIllIIIl	F
    //   0	25	4	lllllllllllllllIllIlIIlIlIllIIII	F
  }
  
  public static void drawGradientFilledBox(BlockPos lllllllllllllllIllIlIIlIlIlIllll, Color lllllllllllllllIllIlIIlIlIlIlllI, Color lllllllllllllllIllIlIIlIlIlIllIl) {
    // Byte code:
    //   0: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 36 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: aload_0
    //   11: <illegal opcode> 37 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   16: astore_3
    //   17: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 38 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   32: <illegal opcode> 39 : (Lnet/minecraft/client/Minecraft;)F
    //   37: <illegal opcode> 40 : (Lnet/minecraft/entity/Entity;F)Lnet/minecraft/util/math/Vec3d;
    //   42: astore #4
    //   44: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	45	0	lllllllllllllllIllIlIIlIlIlIllll	Lnet/minecraft/util/math/BlockPos;
    //   0	45	1	lllllllllllllllIllIlIIlIlIlIlllI	Ljava/awt/Color;
    //   0	45	2	lllllllllllllllIllIlIIlIlIlIllIl	Ljava/awt/Color;
    //   17	28	3	lllllllllllllllIllIlIIlIlIlIllII	Lnet/minecraft/block/state/IBlockState;
    //   44	1	4	lllllllllllllllIllIlIIlIlIlIlIll	Lnet/minecraft/util/math/Vec3d;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIlIlIIIIIIlI : ()V
    //   3: invokestatic lIIIIlIIlllllllI : ()V
    //   6: invokestatic lIIIIlIIllllllIl : ()V
    //   9: invokestatic lIIIIlIIllllIlII : ()V
    //   12: <illegal opcode> 41 : ()Lnet/minecraft/client/Minecraft;
    //   17: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)V
    //   22: return
  }
  
  private static CallSite lIIIIlIIllIIIIIl(MethodHandles.Lookup lllllllllllllllIllIlIIlIlIlIIIlI, String lllllllllllllllIllIlIIlIlIlIIIIl, MethodType lllllllllllllllIllIlIIlIlIlIIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIlIlIlIlIII = llIIIllIIIlllI[Integer.parseInt(lllllllllllllllIllIlIIlIlIlIIIIl)].split(llIIIllIlIIIll[llIIIllIlIIllI[5]]);
      Class<?> lllllllllllllllIllIlIIlIlIlIIlll = Class.forName(lllllllllllllllIllIlIIlIlIlIlIII[llIIIllIlIIllI[5]]);
      String lllllllllllllllIllIlIIlIlIlIIllI = lllllllllllllllIllIlIIlIlIlIlIII[llIIIllIlIIllI[6]];
      MethodHandle lllllllllllllllIllIlIIlIlIlIIlIl = null;
      int lllllllllllllllIllIlIIlIlIlIIlII = lllllllllllllllIllIlIIlIlIlIlIII[llIIIllIlIIllI[8]].length();
      if (lIIIIlIlIIIIIllI(lllllllllllllllIllIlIIlIlIlIIlII, llIIIllIlIIllI[9])) {
        MethodType lllllllllllllllIllIlIIlIlIlIlIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIlIlIlIlIII[llIIIllIlIIllI[9]], f100000000000000000.class.getClassLoader());
        if (lIIIIlIlIIIIIlll(lllllllllllllllIllIlIIlIlIlIIlII, llIIIllIlIIllI[9])) {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findVirtual(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIlI);
          "".length();
          if (" ".length() << " ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findStatic(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIlI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() < -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIlIlIlIlIIl = llIIIllIIIllll[Integer.parseInt(lllllllllllllllIllIlIIlIlIlIlIII[llIIIllIlIIllI[9]])];
        if (lIIIIlIlIIIIIlll(lllllllllllllllIllIlIIlIlIlIIlII, llIIIllIlIIllI[8])) {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findGetter(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIIl);
          "".length();
          if (-" ".length() > " ".length())
            return null; 
        } else if (lIIIIlIlIIIIIlll(lllllllllllllllIllIlIIlIlIlIIlII, llIIIllIlIIllI[10])) {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findStaticGetter(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIIl);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (lIIIIlIlIIIIIlll(lllllllllllllllIllIlIIlIlIlIIlII, llIIIllIlIIllI[11])) {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findSetter(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIIl);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIlIlIlIIlIl = lllllllllllllllIllIlIIlIlIlIIIlI.findStaticSetter(lllllllllllllllIllIlIIlIlIlIIlll, lllllllllllllllIllIlIIlIlIlIIllI, lllllllllllllllIllIlIIlIlIlIlIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIlIlIlIIlIl);
    } catch (Exception lllllllllllllllIllIlIIlIlIlIIIll) {
      lllllllllllllllIllIlIIlIlIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIllllIlII() {
    llIIIllIIIlllI = new String[llIIIllIlIIllI[12]];
    llIIIllIIIlllI[llIIIllIlIIllI[13]] = llIIIllIlIIIll[llIIIllIlIIllI[6]];
    llIIIllIIIlllI[llIIIllIlIIllI[14]] = llIIIllIlIIIll[llIIIllIlIIllI[9]];
    llIIIllIIIlllI[llIIIllIlIIllI[15]] = llIIIllIlIIIll[llIIIllIlIIllI[8]];
    llIIIllIIIlllI[llIIIllIlIIllI[16]] = llIIIllIlIIIll[llIIIllIlIIllI[10]];
    llIIIllIIIlllI[llIIIllIlIIllI[17]] = llIIIllIlIIIll[llIIIllIlIIllI[11]];
    llIIIllIIIlllI[llIIIllIlIIllI[18]] = llIIIllIlIIIll[llIIIllIlIIllI[19]];
    llIIIllIIIlllI[llIIIllIlIIllI[20]] = llIIIllIlIIIll[llIIIllIlIIllI[7]];
    llIIIllIIIlllI[llIIIllIlIIllI[21]] = llIIIllIlIIIll[llIIIllIlIIllI[14]];
    llIIIllIIIlllI[llIIIllIlIIllI[19]] = llIIIllIlIIIll[llIIIllIlIIllI[22]];
    llIIIllIIIlllI[llIIIllIlIIllI[23]] = llIIIllIlIIIll[llIIIllIlIIllI[24]];
    llIIIllIIIlllI[llIIIllIlIIllI[9]] = llIIIllIlIIIll[llIIIllIlIIllI[25]];
    llIIIllIIIlllI[llIIIllIlIIllI[26]] = llIIIllIlIIIll[llIIIllIlIIllI[26]];
    llIIIllIIIlllI[llIIIllIlIIllI[27]] = llIIIllIlIIIll[llIIIllIlIIllI[28]];
    llIIIllIIIlllI[llIIIllIlIIllI[29]] = llIIIllIlIIIll[llIIIllIlIIllI[30]];
    llIIIllIIIlllI[llIIIllIlIIllI[31]] = llIIIllIlIIIll[llIIIllIlIIllI[32]];
    llIIIllIIIlllI[llIIIllIlIIllI[8]] = llIIIllIlIIIll[llIIIllIlIIllI[33]];
    llIIIllIIIlllI[llIIIllIlIIllI[11]] = llIIIllIlIIIll[llIIIllIlIIllI[34]];
    llIIIllIIIlllI[llIIIllIlIIllI[35]] = llIIIllIlIIIll[llIIIllIlIIllI[36]];
    llIIIllIIIlllI[llIIIllIlIIllI[37]] = llIIIllIlIIIll[llIIIllIlIIllI[35]];
    llIIIllIIIlllI[llIIIllIlIIllI[34]] = llIIIllIlIIIll[llIIIllIlIIllI[38]];
    llIIIllIIIlllI[llIIIllIlIIllI[36]] = llIIIllIlIIIll[llIIIllIlIIllI[29]];
    llIIIllIIIlllI[llIIIllIlIIllI[39]] = llIIIllIlIIIll[llIIIllIlIIllI[40]];
    llIIIllIIIlllI[llIIIllIlIIllI[30]] = llIIIllIlIIIll[llIIIllIlIIllI[41]];
    llIIIllIIIlllI[llIIIllIlIIllI[42]] = llIIIllIlIIIll[llIIIllIlIIllI[23]];
    llIIIllIIIlllI[llIIIllIlIIllI[43]] = llIIIllIlIIIll[llIIIllIlIIllI[37]];
    llIIIllIIIlllI[llIIIllIlIIllI[10]] = llIIIllIlIIIll[llIIIllIlIIllI[27]];
    llIIIllIIIlllI[llIIIllIlIIllI[40]] = llIIIllIlIIIll[llIIIllIlIIllI[18]];
    llIIIllIIIlllI[llIIIllIlIIllI[5]] = llIIIllIlIIIll[llIIIllIlIIllI[44]];
    llIIIllIIIlllI[llIIIllIlIIllI[45]] = llIIIllIlIIIll[llIIIllIlIIllI[17]];
    llIIIllIIIlllI[llIIIllIlIIllI[6]] = llIIIllIlIIIll[llIIIllIlIIllI[21]];
    llIIIllIIIlllI[llIIIllIlIIllI[28]] = llIIIllIlIIIll[llIIIllIlIIllI[46]];
    llIIIllIIIlllI[llIIIllIlIIllI[46]] = llIIIllIlIIIll[llIIIllIlIIllI[39]];
    llIIIllIIIlllI[llIIIllIlIIllI[38]] = llIIIllIlIIIll[llIIIllIlIIllI[47]];
    llIIIllIIIlllI[llIIIllIlIIllI[7]] = llIIIllIlIIIll[llIIIllIlIIllI[48]];
    llIIIllIIIlllI[llIIIllIlIIllI[44]] = llIIIllIlIIIll[llIIIllIlIIllI[20]];
    llIIIllIIIlllI[llIIIllIlIIllI[48]] = llIIIllIlIIIll[llIIIllIlIIllI[42]];
    llIIIllIIIlllI[llIIIllIlIIllI[47]] = llIIIllIlIIIll[llIIIllIlIIllI[15]];
    llIIIllIIIlllI[llIIIllIlIIllI[24]] = llIIIllIlIIIll[llIIIllIlIIllI[13]];
    llIIIllIIIlllI[llIIIllIlIIllI[32]] = llIIIllIlIIIll[llIIIllIlIIllI[45]];
    llIIIllIIIlllI[llIIIllIlIIllI[25]] = llIIIllIlIIIll[llIIIllIlIIllI[16]];
    llIIIllIIIlllI[llIIIllIlIIllI[33]] = llIIIllIlIIIll[llIIIllIlIIllI[43]];
    llIIIllIIIlllI[llIIIllIlIIllI[22]] = llIIIllIlIIIll[llIIIllIlIIllI[31]];
    llIIIllIIIlllI[llIIIllIlIIllI[41]] = llIIIllIlIIIll[llIIIllIlIIllI[12]];
    llIIIllIIIllll = new Class[llIIIllIlIIllI[7]];
    llIIIllIIIllll[llIIIllIlIIllI[11]] = WorldClient.class;
    llIIIllIIIllll[llIIIllIlIIllI[9]] = GlStateManager.SourceFactor.class;
    llIIIllIIIllll[llIIIllIlIIllI[19]] = EntityPlayerSP.class;
    llIIIllIIIllll[llIIIllIlIIllI[5]] = Minecraft.class;
    llIIIllIIIllll[llIIIllIlIIllI[6]] = double.class;
    llIIIllIIIllll[llIIIllIlIIllI[8]] = GlStateManager.DestFactor.class;
    llIIIllIIIllll[llIIIllIlIIllI[10]] = VertexFormat.class;
  }
  
  private static void lIIIIlIIllllllIl() {
    llIIIllIlIIIll = new String[llIIIllIlIIllI[49]];
    llIIIllIlIIIll[llIIIllIlIIllI[5]] = lIIIIlIIllllIllI(llIIIllIlIIlIl[llIIIllIlIIllI[5]], llIIIllIlIIlIl[llIIIllIlIIllI[6]]);
    llIIIllIlIIIll[llIIIllIlIIllI[6]] = lIIIIlIIllllIllI(llIIIllIlIIlIl[llIIIllIlIIllI[9]], llIIIllIlIIlIl[llIIIllIlIIllI[8]]);
    llIIIllIlIIIll[llIIIllIlIIllI[9]] = lIIIIlIIllllIlll(llIIIllIlIIlIl[llIIIllIlIIllI[10]], llIIIllIlIIlIl[llIIIllIlIIllI[11]]);
    llIIIllIlIIIll[llIIIllIlIIllI[8]] = lIIIIlIIlllllIII(llIIIllIlIIlIl[llIIIllIlIIllI[19]], llIIIllIlIIlIl[llIIIllIlIIllI[7]]);
    llIIIllIlIIIll[llIIIllIlIIllI[10]] = lIIIIlIIlllllIII(llIIIllIlIIlIl[llIIIllIlIIllI[14]], "VbDTp");
    llIIIllIlIIIll[llIIIllIlIIllI[11]] = lIIIIlIIllllIllI("JTceeSgiPA80Nyo0HnkmJzsPOTFlIA85IS4gDyVrHzcZJCAnPgsjKjloDCIrKA1db3ZzYzU2f2N7PG1law==", "KRjWE");
    llIIIllIlIIIll[llIIIllIlIIllI[19]] = lIIIIlIIllllIllI("CS41fS8OJSQwMAYtNX0hCyIkPTZJOSQ9JgI5JCFsJT4nNScVCTQ6LgMuM2kkEiUiDHNfendlcDgpe3sGIw9oHywCP24+KwkuIiEjAT9uMC4OLi8nbRUuLzcnFS4zfAASLSc2MCU+KD8mAjl6aWJH", "gKASB");
    llIIIllIlIIIll[llIIIllIlIIllI[7]] = lIIIIlIIllllIlll("jAufaNYqMlgVINiFBkfjuv2ye2f1LeNdMATTbLwx//YdmXs0fujwPJqr2XTUBAYW7W/JiC38cISapw2jM07UctGj2dgwo/caXuSNyd7rYz9VXlCAZvy1hmQANRPEnNqdFYLBEUA8UaNcMRXvx8Hp2g==", "PEExB");
    llIIIllIlIIIll[llIIIllIlIIllI[14]] = lIIIIlIIllllIllI("KBA7ZhsvGyorBCcTO2YVKhwqJgJoByomEiMHKjpYARkcPBcyEAIpGCcSKjpMIAAhKyl3QnZ4T34qOHJebyN1aA==", "FuOHv");
    llIIIllIlIIIll[llIIIllIlIIllI[22]] = lIIIIlIIllllIlll("fByayiyxvSen9y9ZROsEDLoS8Qc2FjAUoAG5h6eifpHUlQRFufvWLw==", "VViOa");
    llIIIllIlIIIll[llIIIllIlIIllI[24]] = lIIIIlIIlllllIII("VlL144Q6qc62HqLlHcIkVkHUQhAA8sIilKtRdD8tTRYNWMangqfYEw==", "UUZyF");
    llIIIllIlIIIll[llIIIllIlIIllI[25]] = lIIIIlIIllllIllI("DDEpbAgUKSkuSgwzKywDD20JDlVSeSkuIQ0iLC4BWWsHazJZYw==", "cCNBd");
    llIIIllIlIIIll[llIIIllIlIIllI[26]] = lIIIIlIIllllIllI("HCsAfSwbIBEwMxMoAH0iHicRPTVcPBE9JRc8ESFvFyAAOjULYCY2LxYrBh4gHC8TNjNIKB02LRYRQ2t2QX8rPntDdFRzYQ==", "rNtSA");
    llIIIllIlIIIll[llIIIllIlIIllI[28]] = lIIIIlIIllllIllI("ORQ5fDw+HygxIzYXOXwyOxgoPCV5Ayg8NTIDKCB/FQQrNDQlMzg7PTMUP2g3Ih8uDWBvQHtkaQgQd3oYGx8oJn46GCM3MiUQKyZ+NB0kNz8jXj83PzMUPzcjeAcoICUyCWIENCUFKCoXOAMgMyVsWBtocXc=", "WqMRQ");
    llIIIllIlIIIll[llIIIllIlIIllI[30]] = lIIIIlIIllllIllI("HSEgaBUaKjElChIiIGgbHy0xKAxdNjEoHBY2MTRWNCgHMhkHIRknFhIjMTRcICshNBsWAjUlDBw2bgk2Nn5mfFhTZHQ=", "sDTFx");
    llIIIllIlIIIll[llIIIllIlIIllI[32]] = lIIIIlIIlllllIII("Vb+h55MThzrWCfUu+Rc24PowmXJO+AQkQ0MRTQkzWE/LtgsnBS6DXEPDBXXKS2tCSYNb7eYXDDM=", "uBmOU");
    llIIIllIlIIIll[llIIIllIlIIllI[33]] = lIIIIlIIllllIlll("ueSYJCTqrTKAOviVubzEsPnHFkG0KVBpZe7zgVMuOsTVKAP9t5nzZQ==", "DUAGL");
    llIIIllIlIIIll[llIIIllIlIIllI[34]] = lIIIIlIIllllIllI("IhYNRwg6Dg0FSiIUDwcDIUotJVV8Xg0FKCQKDz4NKRACU0wLTTxTRA==", "Mdjid");
    llIIIllIlIIIll[llIIIllIlIIllI[36]] = lIIIIlIIlllllIII("FcKQZzXFd2NvRgbJPY8mScfJ/qOEwJryPSmVepNYpn/Kd5m35zCKUHe2zYgv9T2maQb69OjtGsiJ71fAaqwntCPU51FDvFJwO0ehaY5C9EQ=", "kzHWf");
    llIIIllIlIIIll[llIIIllIlIIllI[35]] = lIIIIlIIlllllIII("iePud7C5O3v2EONNXWFO+VYnL43g6lFFv6Qub5JmII7saf8/JWbXgrseC/6LuVAYMFTkP+m3JjcdvX0Y6ku8PHAnjI/K2RU9+ddBRyRWJjs=", "XoUee");
    llIIIllIlIIIll[llIIIllIlIIllI[38]] = lIIIIlIIllllIllI("OA0magk/BjcnFjcOJmoHOgE3KhB4GjcqADMaNzZKEQQBMAUiDR8lCjcPNzZeMB08JztnX2t1UGE3Pn5Mfz5oZA==", "VhRDd");
    llIIIllIlIIIll[llIIIllIlIIllI[29]] = lIIIIlIIllllIlll("uTTiJROVKnLoHIH6EehQqxtq0bxwvswgrZ8iaugVAyL43JpErewar5o8Eg3qJhJUGAgjSM50y4ItTX9KeL5OU/js0563Nbaf", "DLsXc");
    llIIIllIlIIIll[llIIIllIlIIllI[40]] = lIIIIlIIllllIllI("JTZPIzo9IwgkKic0TzImOH0HYX54Y1FgfnhjUWB+eGNRYH54aREiKzgyEzUJBGlJeRhycw==", "HSaPN");
    llIIIllIlIIIll[llIIIllIlIIllI[41]] = lIIIIlIIlllllIII("qg6NqP1R7o4vKlq9tJuAYMNlfU5woaU+tN9PLDbdp9FVos4oTuSc/N3CWQsuHbsmMoiDKRr+5hORWzGLjHFmvOtPbRuRiUDI", "myFlO");
    llIIIllIlIIIll[llIIIllIlIIllI[23]] = lIIIIlIIllllIllI("HDIGeBgbORc1BxMxBngWHj4XOAFcGhs4EBElEzABSDEbMxkWCEVnQUZmLTNPR21SdlU=", "rWrVu");
    llIIIllIlIIIll[llIIIllIlIIllI[37]] = lIIIIlIIllllIlll("RS1oFdSojvd0hCKYn+vFtwTWVDs8aYCLePzdXDH7z5x+Er3zcaucb2DV7JrhdoMIFzOiLk+RGj3dZUkQOBSRKIHv3GYpY/c0XpZOtcGrM5WBLwOgqiuiXQ==", "rqTah");
    llIIIllIlIIIll[llIIIllIlIIllI[27]] = lIIIIlIIlllllIII("ph5cw/iTX6DmgMChwXiZUrOC6DLU6ATdTBKf0opIEhKYQkRtLxRsU6lQhpMyRdVB", "BVUrR");
    llIIIllIlIIIll[llIIIllIlIIllI[18]] = lIIIIlIIlllllIII("yxe62MLuHNLWT20bIHlU2LqAjP8njh8p9omVY+iDB2GzahiMk8asbIpFnKNLj+ruwhnWiKV37SHHQKJWAMbnmWANCO2a5CSi", "KzkgH");
    llIIIllIlIIIll[llIIIllIlIIllI[44]] = lIIIIlIIllllIllI("DhURRhkWDREEWw4XEwYSDUkxJERQXREEJRQUHiUUFRUfEE9JTiBSVQ==", "agvhu");
    llIIIllIlIIIll[llIIIllIlIIllI[17]] = lIIIIlIIlllllIII("P6WKI0dx9Psmk9yzE9M9loshzKtLJAFhkZrS7d7UoSSPgf1lpQjuEoaRtl5SF3bXqj8YOgpuhWQ=", "HKsnN");
    llIIIllIlIIIll[llIIIllIlIIllI[21]] = lIIIIlIIllllIlll("OoHMjzu2jjLuZ0radgKqiX+kZrq1Advj1xqd/t+o3T01R42B+5MAGf5tF11uoCFM", "eKbUQ");
    llIIIllIlIIIll[llIIIllIlIIllI[46]] = lIIIIlIIllllIllI("KTYCRQEuPRMIHiY1AkUZMzoaRQEmJx5FLis8FQA8KCBMDRkpMClaW3BqQ1kzN2leQiV9c1Y=", "GSvkl");
    llIIIllIlIIIll[llIIIllIlIIllI[39]] = lIIIIlIIlllllIII("nZ0AbrF/Q9ge4hM3x+Ql9IXdaP2N1vsYlU1wwe7u0W4vEmGD8LOvy+ACNBGPNZnoR3Wk/0PJkd3/TrXbdck+RtsTZqxsSl4b", "MYhxb");
    llIIIllIlIIIll[llIIIllIlIIllI[47]] = lIIIIlIIllllIlll("uUNaz/3AjvO3S5c8LmDfxXvc4aOv3W5fK0nptXKm6yIHGQbsK0j1+mB9imJOJt1ScnmPPyCh41muaIMwDDG+8iViXU8BvS2nBfVnustobPEAJ+c+I3sWbQ==", "uzBNt");
    llIIIllIlIIIll[llIIIllIlIIllI[48]] = lIIIIlIIllllIlll("7HkTmHaBec8AT3+/6C1Z3NBj1HOu3KEiwZm8efAX7N2Xx+qP772XWdfSDvWoZDR+k5vIHUYCg8c=", "ZLyeT");
    llIIIllIlIIIll[llIIIllIlIIllI[20]] = lIIIIlIIllllIlll("WGKAIfScT2WSUwpGmaJRBWibbiyQL3K2GU9ZSfYCErxf69PMAWXIBZ7aYdU/XuAYgaJN/ywCshvQ77m+taydor6ToASi4Qgd", "zefDN");
    llIIIllIlIIIll[llIIIllIlIIllI[42]] = lIIIIlIIllllIlll("tzaXw7Sd8N1nyK9bETnSHVa85wgpDo5BRqQthVGpjpWzvtjxU99+1T3z2ZM+RUGExbxUw3uKd50=", "xUvAR");
    llIIIllIlIIIll[llIIIllIlIIllI[15]] = lIIIIlIIlllllIII("NkUUTFZordtXaGTsYxGD38/A3BYEjA6Qty0uZc3fBUalXY6Hq0mf6nC+RnGzTuELPagHfTK2yhl2iDbp/LSrA2KxDWiMZiocYHD4hjh9bMFijJrr7vmUfriRw2wKfKBAtuzVMMVK3XxJ8tAQVR3SeQ==", "NabWg");
    llIIIllIlIIIll[llIIIllIlIIllI[13]] = lIIIIlIIllllIlll("jU2FwHrUEO9gY3xhcFSVaUX54xkRNF42Vaoexl7EBbUiVHPqB/xczj3ImpcpwtD2bS0UxEPYqz7ZF5rcxj32qwJ5svttcB6e", "ThRaC");
    llIIIllIlIIIll[llIIIllIlIIllI[45]] = lIIIIlIIlllllIII("4qGZAgFn82W2m/gt6ODaLQg4gpkav9EYhqNbqOFr+zNyrDG7VskfTtoq0IA+NLuyP+qThqcS5L7O4Jx0jD5JmXEVC+L40BY1HnDAwF8d8Uj9XGFSiH3kHXY52iI9aukItXYRB0gzPTE=", "iTigD");
    llIIIllIlIIIll[llIIIllIlIIllI[16]] = lIIIIlIIlllllIII("TIFgKmFmCFFqXaHWRMlAixqX6dFrqW/wh3V7PrNHmOf1wwsoP7GNPXXeE6gW5OqV6dEq20xHAyk=", "knEBL");
    llIIIllIlIIIll[llIIIllIlIIllI[43]] = lIIIIlIIlllllIII("h7rcPoAOjmoN2ftulcncllIi/1HjxESQpe9RFRizFbL/O34Wno/XCuV7XT25UeGHmXwhEKhWnRGAz7u9zN1N58G+/Imt+o7jOg26ChiLjnG8RnIQvlgAwA0XXCaIQmudoavtCF20U6xsoJYi0w7msA==", "wLPME");
    llIIIllIlIIIll[llIIIllIlIIllI[31]] = lIIIIlIIllllIllI("ChQOeiYNHx83OQUXDnooCBgfOj9KPBM6LgcDGzI/XhcPOig7QE1hfl1JJTUuXllTGCUBBVU5IgoUGSYqAgVVNycNFBQgZBYUFDAuFhQIey4KBRMgMksjHzovAQM3NSUFFh8mcF5RWg==", "dqzTK");
    llIIIllIlIIIll[llIIIllIlIIllI[12]] = lIIIIlIIllllIllI("DT8ZehcKNAg3CAI8GXoZDzMIOg5NKAg6HgYoCCZUJDY+IBsXPyA1FAI9CCZABS8DNyVSYlpgSFsFDG5SLzQIIFUOMwMxGRE7CyBVADYEMRQXdR8xFAc/HzEITB0BBw4CLggZGw07CjEIRwkCIQgAPys1GRc1H282DT8ZexcKNAg3CAI8GXsZDzMIOg5MKAg6HgYoCCZVJDY+IBsXPyA1FAI9CCZeJz8eIDwCORk7CFgWAzEOTDcEOh8AKAwyDkw5AT0fDS5CJh8NPggmHxF1KjgpFzsZMTcCNAwzHxF+PjsPETkIEhsALgImQS80CCBVDjMDMRkROwsgVQA2BDEUF3UfMRQHPx8xCEwdAQcOAi4IGRsNOwoxCEceCCcOJTsOIBURYUQCQEM=", "cZmTz");
    llIIIllIlIIlIl = null;
  }
  
  private static void lIIIIlIIlllllllI() {
    String str = (new Exception()).getStackTrace()[llIIIllIlIIllI[5]].getFileName();
    llIIIllIlIIlIl = str.substring(str.indexOf("ä") + llIIIllIlIIllI[6], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIlllllIII(String lllllllllllllllIllIlIIlIlIIlllII, String lllllllllllllllIllIlIIlIlIIllIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlIlIIlllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIlIIllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIlIlIIllllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIlIlIIllllI.init(llIIIllIlIIllI[9], lllllllllllllllIllIlIIlIlIIlllll);
      return new String(lllllllllllllllIllIlIIlIlIIllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIlIIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlIlIIlllIl) {
      lllllllllllllllIllIlIIlIlIIlllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIllllIlll(String lllllllllllllllIllIlIIlIlIIlIlll, String lllllllllllllllIllIlIIlIlIIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIlIlIIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIlIIlIllI.getBytes(StandardCharsets.UTF_8)), llIIIllIlIIllI[14]), "DES");
      Cipher lllllllllllllllIllIlIIlIlIIllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIlIlIIllIIl.init(llIIIllIlIIllI[9], lllllllllllllllIllIlIIlIlIIllIlI);
      return new String(lllllllllllllllIllIlIIlIlIIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIlIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIlIlIIllIII) {
      lllllllllllllllIllIlIIlIlIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIllllIllI(String lllllllllllllllIllIlIIlIlIIlIlII, String lllllllllllllllIllIlIIlIlIIlIIll) {
    lllllllllllllllIllIlIIlIlIIlIlII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIlIIlIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIlIlIIlIIlI = new StringBuilder();
    char[] lllllllllllllllIllIlIIlIlIIlIIIl = lllllllllllllllIllIlIIlIlIIlIIll.toCharArray();
    int lllllllllllllllIllIlIIlIlIIlIIII = llIIIllIlIIllI[5];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIlIlIIlIlII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIlIIllI[5];
    while (lIIIIlIlIIIIlIII(j, i)) {
      char lllllllllllllllIllIlIIlIlIIlIlIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIlIlIIlIIII++;
      j++;
      "".length();
      if (-(0x6D ^ 0x68) >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIlIlIIlIIlI);
  }
  
  private static void lIIIIlIlIIIIIIlI() {
    llIIIllIlIIllI = new int[50];
    llIIIllIlIIllI[0] = 330 + 348 - 320 + 27 << " ".length();
    llIIIllIlIIllI[1] = 345 + 356 - 191 + 261;
    llIIIllIlIIllI[2] = ((0x15 ^ 0x68) << " ".length()) + (322 + 88 - 244 + 181 << " ".length() << " ".length()) - (74 + 98 - 42 + 13 << " ".length() << " ".length()) + 82 + 333 - 391 + 431 << " ".length();
    llIIIllIlIIllI[3] = 3211 + 1476 - 2883 + 1749;
    llIIIllIlIIllI[4] = 924 + 1939 - 1275 + 1341;
    llIIIllIlIIllI[5] = (4 + 101 - -8 + 14 ^ (0x3D ^ 0x6) << " ".length()) & ((0x8 ^ 0x2D) << " ".length() ^ 0x16 ^ 0x55 ^ -" ".length());
    llIIIllIlIIllI[6] = " ".length();
    llIIIllIlIIllI[7] = 31 + 67 - 3 + 54 ^ (0x3D ^ 0x74) << " ".length();
    llIIIllIlIIllI[8] = "   ".length();
    llIIIllIlIIllI[9] = " ".length() << " ".length();
    llIIIllIlIIllI[10] = " ".length() << " ".length() << " ".length();
    llIIIllIlIIllI[11] = 0x92 ^ 0x97;
    llIIIllIlIIllI[12] = 0x2A ^ 0x1;
    llIIIllIlIIllI[13] = (0x88 ^ 0xA7 ^ (0x3B ^ 0x34) << " ".length() << " ".length()) << " ".length();
    llIIIllIlIIllI[14] = " ".length() << "   ".length();
    llIIIllIlIIllI[15] = (0xE ^ 0x29) << " ".length() << " ".length() ^ 35 + 127 - 57 + 80;
    llIIIllIlIIllI[16] = (64 + 3 - 1 + 63 ^ (0xB9 ^ 0x98) << " ".length() << " ".length()) << "   ".length();
    llIIIllIlIIllI[17] = 0x15 ^ 0x8;
    llIIIllIlIIllI[18] = 105 + 153 - 177 + 92 ^ (0xE6 ^ 0xBD) << " ".length();
    llIIIllIlIIllI[19] = "   ".length() << " ".length();
    llIIIllIlIIllI[20] = 0x39 ^ 0x1A;
    llIIIllIlIIllI[21] = (0xAF ^ 0xA0) << " ".length();
    llIIIllIlIIllI[22] = 0xB4 ^ 0xBD;
    llIIIllIlIIllI[23] = "   ".length() << "   ".length();
    llIIIllIlIIllI[24] = ("   ".length() << "   ".length() << " ".length() ^ 49 + 162 - 147 + 133) << " ".length();
    llIIIllIlIIllI[25] = 121 + 41 - 64 + 61 ^ (0x5E ^ 0x7B) << " ".length() << " ".length();
    llIIIllIlIIllI[26] = "   ".length() << " ".length() << " ".length();
    llIIIllIlIIllI[27] = (0x10 ^ 0x1D) << " ".length();
    llIIIllIlIIllI[28] = (0xA6 ^ 0xAF) << " ".length() << " ".length() ^ 0x4B ^ 0x62;
    llIIIllIlIIllI[29] = 0x13 ^ 0x6;
    llIIIllIlIIllI[30] = ((0x9A ^ 0x91) << "   ".length() ^ 0xD0 ^ 0x8F) << " ".length();
    llIIIllIlIIllI[31] = (0xA2 ^ 0xB7) << " ".length();
    llIIIllIlIIllI[32] = 109 + 196 - 190 + 92 ^ "   ".length() << "   ".length() << " ".length();
    llIIIllIlIIllI[33] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIlIIllI[34] = 0x1B ^ 0x42 ^ (0xAB ^ 0xA2) << "   ".length();
    llIIIllIlIIllI[35] = 0x9A ^ 0x89;
    llIIIllIlIIllI[36] = (0x7B ^ 0x72) << " ".length();
    llIIIllIlIIllI[37] = 0xB8 ^ 0xA1;
    llIIIllIlIIllI[38] = ("   ".length() << "   ".length() ^ 0x2E ^ 0x33) << " ".length() << " ".length();
    llIIIllIlIIllI[39] = " ".length() << (0x5E ^ 0x5B);
    llIIIllIlIIllI[40] = (0x7D ^ 0x76) << " ".length();
    llIIIllIlIIllI[41] = 97 + 118 - 64 + 8 ^ (0x20 ^ 0x31) << "   ".length();
    llIIIllIlIIllI[42] = (0x86 ^ 0x8F) << " ".length() << " ".length();
    llIIIllIlIIllI[43] = (0x4C ^ 0xB) << " ".length() ^ 101 + 109 - 77 + 34;
    llIIIllIlIIllI[44] = (0x43 ^ 0x14 ^ (0xC1 ^ 0xC4) << " ".length() << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIllIlIIllI[45] = 0x22 ^ 0x5;
    llIIIllIlIIllI[46] = 0x62 ^ 0x7D;
    llIIIllIlIIllI[47] = 0xD3 ^ 0xB4 ^ (0x95 ^ 0xB6) << " ".length();
    llIIIllIlIIllI[48] = ((0x85 ^ 0xAA) << " ".length() ^ 0x21 ^ 0x6E) << " ".length();
    llIIIllIlIIllI[49] = (0xE7 ^ 0xA8 ^ (0x9B ^ 0x8A) << " ".length() << " ".length()) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIlIlIIIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIlIIIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIlIIIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */