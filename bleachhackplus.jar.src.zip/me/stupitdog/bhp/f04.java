package me.stupitdog.bhp;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f04 extends fh {
  private static String[] lIlllIIllIIlIl;
  
  private static Class[] lIlllIIllIIllI;
  
  private static final String[] lIlllIIlllIIlI;
  
  private static String[] lIlllIIlllIIll;
  
  private static final int[] lIlllIIlllIlII;
  
  public f04() {
    super(lIlllIIlllIIlI[lIlllIIlllIlII[0]], lIlllIIlllIIlI[lIlllIIlllIlII[1]], lIlllIIlllIIlI[lIlllIIlllIlII[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIlllIllIIlIlIIlll) {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   5: iconst_2
    //   6: iaload
    //   7: invokestatic lllllIIlIllIIIl : (II)Z
    //   10: ifeq -> 280
    //   13: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f9;
    //   18: <illegal opcode> 1 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   23: <illegal opcode> 2 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   28: <illegal opcode> 3 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   33: astore_2
    //   34: aload_2
    //   35: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   40: invokestatic lllllIIlIllIIlI : (I)Z
    //   43: ifeq -> 253
    //   46: aload_2
    //   47: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   52: checkcast me/stupitdog/bhp/au
    //   55: astore_3
    //   56: aload_3
    //   57: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   62: aload_1
    //   63: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   66: iconst_1
    //   67: iaload
    //   68: aaload
    //   69: <illegal opcode> 7 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   74: invokestatic lllllIIlIllIIlI : (I)Z
    //   77: ifeq -> 238
    //   80: aload_3
    //   81: aload_1
    //   82: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   85: iconst_2
    //   86: iaload
    //   87: aaload
    //   88: <illegal opcode> 8 : (Ljava/lang/String;)Ljava/lang/String;
    //   93: <illegal opcode> 9 : (Ljava/lang/String;)I
    //   98: <illegal opcode> 10 : (Lme/stupitdog/bhp/au;I)V
    //   103: new java/lang/StringBuilder
    //   106: dup
    //   107: invokespecial <init> : ()V
    //   110: <illegal opcode> 11 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   115: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   120: aload_3
    //   121: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   126: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   131: <illegal opcode> 14 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   136: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   141: getstatic me/stupitdog/bhp/f04.lIlllIIlllIIlI : [Ljava/lang/String;
    //   144: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   147: iconst_3
    //   148: iaload
    //   149: aaload
    //   150: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: <illegal opcode> 11 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   160: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   165: aload_1
    //   166: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   169: iconst_2
    //   170: iaload
    //   171: aaload
    //   172: <illegal opcode> 15 : (Ljava/lang/String;)I
    //   177: <illegal opcode> 16 : (I)Ljava/lang/String;
    //   182: <illegal opcode> 8 : (Ljava/lang/String;)Ljava/lang/String;
    //   187: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: <illegal opcode> 17 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   197: <illegal opcode> 18 : (Ljava/lang/String;)V
    //   202: ldc ''
    //   204: invokevirtual length : ()I
    //   207: pop
    //   208: ldc ' '
    //   210: invokevirtual length : ()I
    //   213: ldc ' '
    //   215: invokevirtual length : ()I
    //   218: ishl
    //   219: bipush #73
    //   221: bipush #42
    //   223: ixor
    //   224: bipush #13
    //   226: bipush #110
    //   228: ixor
    //   229: iconst_m1
    //   230: ixor
    //   231: iand
    //   232: if_icmpgt -> 238
    //   235: return
    //   236: astore #4
    //   238: ldc ''
    //   240: invokevirtual length : ()I
    //   243: pop
    //   244: ldc ' '
    //   246: invokevirtual length : ()I
    //   249: ifge -> 34
    //   252: return
    //   253: ldc ''
    //   255: invokevirtual length : ()I
    //   258: pop
    //   259: ldc ' '
    //   261: invokevirtual length : ()I
    //   264: ldc ' '
    //   266: invokevirtual length : ()I
    //   269: ldc ' '
    //   271: invokevirtual length : ()I
    //   274: ishl
    //   275: ishl
    //   276: ifne -> 294
    //   279: return
    //   280: getstatic me/stupitdog/bhp/f04.lIlllIIlllIIlI : [Ljava/lang/String;
    //   283: getstatic me/stupitdog/bhp/f04.lIlllIIlllIlII : [I
    //   286: iconst_4
    //   287: iaload
    //   288: aaload
    //   289: <illegal opcode> 19 : (Ljava/lang/String;)V
    //   294: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   56	182	3	lllllllllllllllIlllIllIIlIlIlIIl	Lme/stupitdog/bhp/au;
    //   0	295	0	lllllllllllllllIlllIllIIlIlIlIII	Lme/stupitdog/bhp/f04;
    //   0	295	1	lllllllllllllllIlllIllIIlIlIIlll	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   80	202	236	java/lang/Exception
  }
  
  static {
    lllllIIlIllIIII();
    lllllIIlIlIllll();
    lllllIIlIlIlllI();
    lllllIIlIlIIlIl();
  }
  
  private static CallSite lllllIIlIIIIlII(MethodHandles.Lookup lllllllllllllllIlllIllIIlIIllllI, String lllllllllllllllIlllIllIIlIIlllIl, MethodType lllllllllllllllIlllIllIIlIIlllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllIIlIlIIlII = lIlllIIllIIlIl[Integer.parseInt(lllllllllllllllIlllIllIIlIIlllIl)].split(lIlllIIlllIIlI[lIlllIIlllIlII[5]]);
      Class<?> lllllllllllllllIlllIllIIlIlIIIll = Class.forName(lllllllllllllllIlllIllIIlIlIIlII[lIlllIIlllIlII[0]]);
      String lllllllllllllllIlllIllIIlIlIIIlI = lllllllllllllllIlllIllIIlIlIIlII[lIlllIIlllIlII[1]];
      MethodHandle lllllllllllllllIlllIllIIlIlIIIIl = null;
      int lllllllllllllllIlllIllIIlIlIIIII = lllllllllllllllIlllIllIIlIlIIlII[lIlllIIlllIlII[3]].length();
      if (lllllIIlIllIIll(lllllllllllllllIlllIllIIlIlIIIII, lIlllIIlllIlII[2])) {
        MethodType lllllllllllllllIlllIllIIlIlIIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllIIlIlIIlII[lIlllIIlllIlII[2]], f04.class.getClassLoader());
        if (lllllIIlIllIlII(lllllllllllllllIlllIllIIlIlIIIII, lIlllIIlllIlII[2])) {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findVirtual(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIllI);
          "".length();
          if ("   ".length() < "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findStatic(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIllI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() > " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllIIlIlIIlIl = lIlllIIllIIllI[Integer.parseInt(lllllllllllllllIlllIllIIlIlIIlII[lIlllIIlllIlII[2]])];
        if (lllllIIlIllIlII(lllllllllllllllIlllIllIIlIlIIIII, lIlllIIlllIlII[3])) {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findGetter(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIlIl);
          "".length();
          if (-" ".length() > ((0xB7 ^ 0xB0) << " ".length() & ((0x6E ^ 0x69) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllIIlIllIlII(lllllllllllllllIlllIllIIlIlIIIII, lIlllIIlllIlII[4])) {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findStaticGetter(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIlIl);
          "".length();
          if (((0xE6 ^ 0xBF) & (0x42 ^ 0x1B ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (lllllIIlIllIlII(lllllllllllllllIlllIllIIlIlIIIII, lIlllIIlllIlII[5])) {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findSetter(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIlIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIllIIlIlIIIIl = lllllllllllllllIlllIllIIlIIllllI.findStaticSetter(lllllllllllllllIlllIllIIlIlIIIll, lllllllllllllllIlllIllIIlIlIIIlI, lllllllllllllllIlllIllIIlIlIIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIllIIlIlIIIIl);
    } catch (Exception lllllllllllllllIlllIllIIlIIlllll) {
      lllllllllllllllIlllIllIIlIIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlIlIIlIl() {
    lIlllIIllIIlIl = new String[lIlllIIlllIlII[6]];
    lIlllIIllIIlIl[lIlllIIlllIlII[7]] = lIlllIIlllIIlI[lIlllIIlllIlII[7]];
    lIlllIIllIIlIl[lIlllIIlllIlII[8]] = lIlllIIlllIIlI[lIlllIIlllIlII[9]];
    lIlllIIllIIlIl[lIlllIIlllIlII[9]] = lIlllIIlllIIlI[lIlllIIlllIlII[10]];
    lIlllIIllIIlIl[lIlllIIlllIlII[11]] = lIlllIIlllIIlI[lIlllIIlllIlII[12]];
    lIlllIIllIIlIl[lIlllIIlllIlII[13]] = lIlllIIlllIIlI[lIlllIIlllIlII[14]];
    lIlllIIllIIlIl[lIlllIIlllIlII[3]] = lIlllIIlllIIlI[lIlllIIlllIlII[15]];
    lIlllIIllIIlIl[lIlllIIlllIlII[2]] = lIlllIIlllIIlI[lIlllIIlllIlII[16]];
    lIlllIIllIIlIl[lIlllIIlllIlII[5]] = lIlllIIlllIIlI[lIlllIIlllIlII[17]];
    lIlllIIllIIlIl[lIlllIIlllIlII[18]] = lIlllIIlllIIlI[lIlllIIlllIlII[8]];
    lIlllIIllIIlIl[lIlllIIlllIlII[15]] = lIlllIIlllIIlI[lIlllIIlllIlII[19]];
    lIlllIIllIIlIl[lIlllIIlllIlII[12]] = lIlllIIlllIIlI[lIlllIIlllIlII[18]];
    lIlllIIllIIlIl[lIlllIIlllIlII[17]] = lIlllIIlllIIlI[lIlllIIlllIlII[11]];
    lIlllIIllIIlIl[lIlllIIlllIlII[19]] = lIlllIIlllIIlI[lIlllIIlllIlII[13]];
    lIlllIIllIIlIl[lIlllIIlllIlII[0]] = lIlllIIlllIIlI[lIlllIIlllIlII[20]];
    lIlllIIllIIlIl[lIlllIIlllIlII[10]] = lIlllIIlllIIlI[lIlllIIlllIlII[6]];
    lIlllIIllIIlIl[lIlllIIlllIlII[16]] = lIlllIIlllIIlI[lIlllIIlllIlII[21]];
    lIlllIIllIIlIl[lIlllIIlllIlII[4]] = lIlllIIlllIIlI[lIlllIIlllIlII[22]];
    lIlllIIllIIlIl[lIlllIIlllIlII[20]] = lIlllIIlllIIlI[lIlllIIlllIlII[23]];
    lIlllIIllIIlIl[lIlllIIlllIlII[1]] = lIlllIIlllIIlI[lIlllIIlllIlII[24]];
    lIlllIIllIIlIl[lIlllIIlllIlII[14]] = lIlllIIlllIIlI[lIlllIIlllIlII[25]];
    lIlllIIllIIllI = new Class[lIlllIIlllIlII[4]];
    lIlllIIllIIllI[lIlllIIlllIlII[0]] = f9.class;
    lIlllIIllIIllI[lIlllIIlllIlII[3]] = ChatFormatting.class;
    lIlllIIllIIllI[lIlllIIlllIlII[1]] = av.class;
    lIlllIIllIIllI[lIlllIIlllIlII[2]] = ArrayList.class;
  }
  
  private static void lllllIIlIlIlllI() {
    lIlllIIlllIIlI = new String[lIlllIIlllIlII[26]];
    lIlllIIlllIIlI[lIlllIIlllIlII[0]] = lllllIIlIlIIllI(lIlllIIlllIIll[lIlllIIlllIlII[0]], lIlllIIlllIIll[lIlllIIlllIlII[1]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[1]] = lllllIIlIlIIllI(lIlllIIlllIIll[lIlllIIlllIlII[2]], lIlllIIlllIIll[lIlllIIlllIlII[3]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[2]] = lllllIIlIlIIllI(lIlllIIlllIIll[lIlllIIlllIlII[4]], lIlllIIlllIIll[lIlllIIlllIlII[5]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[3]] = lllllIIlIlIIlll(lIlllIIlllIIll[lIlllIIlllIlII[7]], lIlllIIlllIIll[lIlllIIlllIlII[9]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[4]] = lllllIIlIlIlIII(lIlllIIlllIIll[lIlllIIlllIlII[10]], lIlllIIlllIIll[lIlllIIlllIlII[12]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[5]] = lllllIIlIlIIllI(lIlllIIlllIIll[lIlllIIlllIlII[14]], lIlllIIlllIIll[lIlllIIlllIlII[15]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[7]] = lllllIIlIlIIlll(lIlllIIlllIIll[lIlllIIlllIlII[16]], lIlllIIlllIIll[lIlllIIlllIlII[17]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[9]] = lllllIIlIlIIlll(lIlllIIlllIIll[lIlllIIlllIlII[8]], lIlllIIlllIIll[lIlllIIlllIlII[19]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[10]] = lllllIIlIlIIlll(lIlllIIlllIIll[lIlllIIlllIlII[18]], lIlllIIlllIIll[lIlllIIlllIlII[11]]);
    lIlllIIlllIIlI[lIlllIIlllIlII[12]] = lllllIIlIlIIllI("MAQsMn42BDQ0fgkRKDo+PScvOjw+AChpJDU2LiE5NAJge3kWDzslMXUJOz03dTYuITk0AmFpcHo=", "ZeZSP");
    lIlllIIlllIIlI[lIlllIIlllIlII[14]] = lllllIIlIlIIlll("IomABJ2TFgHdfmIt4oZSqG4X5+NGkVy0EewSvgSrPUyHaWMFncXV7Wb1/vA3myD5dWIrTNoh0WZjuNeDFAfYzQ==", "aGKqw");
    lIlllIIlllIIlI[lIlllIIlllIlII[15]] = lllllIIlIlIlIII("0bOwimV9Iq/ojDyF4GVx5NQ0JBHINEgjpuagNK4ZNBWiTK15uhBsgAtc83qWf9UZ6ECnsIvB47A=", "DHUHQ");
    lIlllIIlllIIlI[lIlllIIlllIlII[16]] = lllllIIlIlIIlll("U5iBmKwIx9x7SDFhSr6RHr1TfVTRohr5geYR50f2yDHFR/6p8vmffQ==", "upmiJ");
    lIlllIIlllIIlI[lIlllIIlllIlII[17]] = lllllIIlIlIIllI("JQIsNFs6FzM5WwYXPycUOwwobxsqGy5vXWYvMDQDLkw2NBsoTBU3HyoALm5Pb0M=", "OcZUu");
    lIlllIIlllIIlI[lIlllIIlllIlII[8]] = lllllIIlIlIIlll("s9SSRGE84wKHqkYIexoNom3IAX34Sr2pH7fsyTzbUAIU72+T2w/k+qbuacKWTQljB446jmaE2flTlEa7cliaGg==", "Hcnng");
    lIlllIIlllIIlI[lIlllIIlllIlII[19]] = lllllIIlIlIIlll("3FcLBfdQkWj0WXafFVNHkGmJkMpXpXKKT4fV554mQTB7VLtYBbH7HrGz86kd9fEuaBz81W4zQ1Q=", "SAVAz");
    lIlllIIlllIIlI[lIlllIIlllIlII[18]] = lllllIIlIlIlIII("YP373fq1MacOYjVCDNalVabgLDAMZK7CkZBGZaJQol1rvXFugFwOvJQMGYDRVrXXcubzVUuehKuNMBToHV6IDQ==", "Echah");
    lIlllIIlllIIlI[lIlllIIlllIlII[11]] = lllllIIlIlIlIII("JrxZbPKxsxt2RyGyfTIEqmM41XHE3fuUB80lYGbD1Im+oSBa8PvdZJiTR2052l/ZXnrK4aRzm/XOae9mmV/dwvhb0Djl8kiJpxp+2w6ypVQ=", "rxAWm");
    lIlllIIlllIIlI[lIlllIIlllIlII[13]] = lllllIIlIlIIllI("MDEhLGE2MTkqYRM+IygoPyJtPS4oIzIEIS5qfwElOyY2YiM7PjBiHC4iPiMoYXked28=", "ZPWMO");
    lIlllIIlllIIlI[lIlllIIlllIlII[20]] = lllllIIlIlIlIII("twD/1MMGWeMxG8ifMy3gScAdwfYI4xuyR0lJ7tywf3+oOIuYFtdbmA==", "wreId");
    lIlllIIlllIIlI[lIlllIIlllIlII[6]] = lllllIIlIlIIllI("Pg0QAH44DQgGfgcYFAg+M1YSDgUkHAMTEzUfA1t4fSAMACY1QwoAPjNDNRUiPQIBWmp0TA==", "TlfaP");
    lIlllIIlllIIlI[lIlllIIlllIlII[21]] = lllllIIlIlIIlll("HUxFGq0EAsz9T7HIldOKUpl0AAQe+QZV2fwA00mpSjavwyh/FEVGRR293Gx13HNu23YUOiVAY2AVOZZdoqaKz/1ZPvW0p5rM1O0H/vPTXHo=", "TysAN");
    lIlllIIlllIIlI[lIlllIIlllIlII[22]] = lllllIIlIlIlIII("2j4QM2uoFmMP7KZVt3cJZLCwiU0amHoKxrs4lKh1FK79cAIj5YFSxA==", "ldzMz");
    lIlllIIlllIIlI[lIlllIIlllIlII[23]] = lllllIIlIlIIllI("PA5fNCIkGxgzMj4MXyU+IUUQM2wiDh8jFTkKBQIkIwQDCjMiGBAgM2tDPS03JwpeKzc/DF4UIiMCHyBteD1LZw==", "QkqGV");
    lIlllIIlllIIlI[lIlllIIlllIlII[24]] = lllllIIlIlIlIII("CfM55lJywbjRljbCEhdBOtZCf05Bb6P7Zg7F2acrYIiKodDUXc2+EQ==", "qwuUL");
    lIlllIIlllIIlI[lIlllIIlllIlII[25]] = lllllIIlIlIIllI("AyRYATwbMR8GLAEmWBAgHm8XB3IdJAI5LRd7XjthOHtWUg==", "nAvrH");
    lIlllIIlllIIll = null;
  }
  
  private static void lllllIIlIlIllll() {
    String str = (new Exception()).getStackTrace()[lIlllIIlllIlII[0]].getFileName();
    lIlllIIlllIIll = str.substring(str.indexOf("ä") + lIlllIIlllIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIlIlIIlll(String lllllllllllllllIlllIllIIlIIllIII, String lllllllllllllllIlllIllIIlIIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIlIIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIlIIlIlll.getBytes(StandardCharsets.UTF_8)), lIlllIIlllIlII[10]), "DES");
      Cipher lllllllllllllllIlllIllIIlIIllIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIIlIIllIlI.init(lIlllIIlllIlII[2], lllllllllllllllIlllIllIIlIIllIll);
      return new String(lllllllllllllllIlllIllIIlIIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIlIIllIIl) {
      lllllllllllllllIlllIllIIlIIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlIlIIllI(String lllllllllllllllIlllIllIIlIIlIlIl, String lllllllllllllllIlllIllIIlIIlIlII) {
    lllllllllllllllIlllIllIIlIIlIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIIlIIlIIll = new StringBuilder();
    char[] lllllllllllllllIlllIllIIlIIlIIlI = lllllllllllllllIlllIllIIlIIlIlII.toCharArray();
    int lllllllllllllllIlllIllIIlIIlIIIl = lIlllIIlllIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIllIIlIIlIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlllIlII[0];
    while (lllllIIlIllIlIl(j, i)) {
      char lllllllllllllllIlllIllIIlIIlIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIllIIlIIlIIIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() == 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIllIIlIIlIIll);
  }
  
  private static String lllllIIlIlIlIII(String lllllllllllllllIlllIllIIlIIIllIl, String lllllllllllllllIlllIllIIlIIIllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIllIIlIIlIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIIlIIIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIIlIIIllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIIlIIIllll.init(lIlllIIlllIlII[2], lllllllllllllllIlllIllIIlIIlIIII);
      return new String(lllllllllllllllIlllIllIIlIIIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIIlIIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIllIIlIIIlllI) {
      lllllllllllllllIlllIllIIlIIIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlIllIIII() {
    lIlllIIlllIlII = new int[27];
    lIlllIIlllIlII[0] = (0x77 ^ 0x66) & (0x91 ^ 0x80 ^ 0xFFFFFFFF);
    lIlllIIlllIlII[1] = " ".length();
    lIlllIIlllIlII[2] = " ".length() << " ".length();
    lIlllIIlllIlII[3] = "   ".length();
    lIlllIIlllIlII[4] = " ".length() << " ".length() << " ".length();
    lIlllIIlllIlII[5] = 0x4C ^ 0x49;
    lIlllIIlllIlII[6] = (0x40 ^ 0x45) << " ".length() << " ".length();
    lIlllIIlllIlII[7] = "   ".length() << " ".length();
    lIlllIIlllIlII[8] = (0x77 ^ 0x64 ^ (0x9E ^ 0x9B) << " ".length() << " ".length()) << " ".length();
    lIlllIIlllIlII[9] = 0x98 ^ 0x9F;
    lIlllIIlllIlII[10] = " ".length() << "   ".length();
    lIlllIIlllIlII[11] = 0x8D ^ 0x9C;
    lIlllIIlllIlII[12] = 0x24 ^ 0x79 ^ (0xA1 ^ 0xB4) << " ".length() << " ".length();
    lIlllIIlllIlII[13] = (0x59 ^ 0x50) << " ".length();
    lIlllIIlllIlII[14] = (0x59 ^ 0x5C) << " ".length();
    lIlllIIlllIlII[15] = 26 + 108 - 44 + 63 ^ (0xE1 ^ 0xA8) << " ".length();
    lIlllIIlllIlII[16] = "   ".length() << " ".length() << " ".length();
    lIlllIIlllIlII[17] = 0x4 ^ 0x13 ^ (0xCF ^ 0xC2) << " ".length();
    lIlllIIlllIlII[18] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlllIlII[19] = (0x81 ^ 0xB8) << " ".length() ^ 0xD9 ^ 0xA4;
    lIlllIIlllIlII[20] = 0x72 ^ 0x61;
    lIlllIIlllIlII[21] = 0x99 ^ 0x8C;
    lIlllIIlllIlII[22] = ((0xB4 ^ 0xAD) << "   ".length() ^ 70 + 104 - 110 + 131) << " ".length();
    lIlllIIlllIlII[23] = 0x8C ^ 0x9B;
    lIlllIIlllIlII[24] = "   ".length() << "   ".length();
    lIlllIIlllIlII[25] = (0x9A ^ 0xB7) << " ".length() ^ 0x29 ^ 0x6A;
    lIlllIIlllIlII[26] = (0xAB ^ 0xA6) << " ".length();
  }
  
  private static boolean lllllIIlIllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIlIllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIlIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIlIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lllllIIlIllIIlI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f04.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */