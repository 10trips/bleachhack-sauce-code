package me.stupitdog.bhp;

import java.awt.Color;
import java.awt.Font;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.texture.DynamicTexture;

public class f14 {
  private final float imgSize = 512.0F;
  
  protected CharData[] charData;
  
  protected Font font;
  
  protected boolean antiAlias;
  
  protected boolean fractionalMetrics;
  
  protected int fontHeight;
  
  protected int charOffset;
  
  protected DynamicTexture tex;
  
  private static String[] llIIIlIllIlIIl;
  
  private static Class[] llIIIlIllIlIlI;
  
  private static final String[] llIIIllIIIIllI;
  
  private static String[] llIIIllIIIlIlI;
  
  private static final int[] llIIIllIIlIIII;
  
  public f14(Font lllllllllllllllIllIlIIlllIIIIIll, boolean lllllllllllllllIllIlIIlllIIIIIlI, boolean lllllllllllllllIllIlIIlllIIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: ldc 512.0
    //   7: putfield imgSize : F
    //   10: aload_0
    //   11: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   14: iconst_0
    //   15: iaload
    //   16: anewarray me/stupitdog/bhp/f14$CharData
    //   19: <illegal opcode> 0 : (Lme/stupitdog/bhp/f14;[Lme/stupitdog/bhp/f14$CharData;)V
    //   24: aload_0
    //   25: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   28: iconst_1
    //   29: iaload
    //   30: <illegal opcode> 1 : (Lme/stupitdog/bhp/f14;I)V
    //   35: aload_0
    //   36: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   39: iconst_2
    //   40: iaload
    //   41: <illegal opcode> 2 : (Lme/stupitdog/bhp/f14;I)V
    //   46: aload_0
    //   47: aload_1
    //   48: <illegal opcode> 3 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;)V
    //   53: aload_0
    //   54: iload_2
    //   55: <illegal opcode> 4 : (Lme/stupitdog/bhp/f14;Z)V
    //   60: aload_0
    //   61: iload_3
    //   62: <illegal opcode> 5 : (Lme/stupitdog/bhp/f14;Z)V
    //   67: aload_0
    //   68: aload_0
    //   69: aload_1
    //   70: iload_2
    //   71: iload_3
    //   72: aload_0
    //   73: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   78: <illegal opcode> 7 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   83: <illegal opcode> 8 : (Lme/stupitdog/bhp/f14;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   88: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	89	0	lllllllllllllllIllIlIIlllIIIIlII	Lme/stupitdog/bhp/f14;
    //   0	89	1	lllllllllllllllIllIlIIlllIIIIIll	Ljava/awt/Font;
    //   0	89	2	lllllllllllllllIllIlIIlllIIIIIlI	Z
    //   0	89	3	lllllllllllllllIllIlIIlllIIIIIIl	Z
  }
  
  protected DynamicTexture setupTexture(Font lllllllllllllllIllIlIIllIllllllI, boolean lllllllllllllllIllIlIIllIlllllIl, boolean lllllllllllllllIllIlIIllIlllllII, CharData[] lllllllllllllllIllIlIIllIllllIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: iload_3
    //   4: aload #4
    //   6: <illegal opcode> 9 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Ljava/awt/image/BufferedImage;
    //   11: astore #5
    //   13: new net/minecraft/client/renderer/texture/DynamicTexture
    //   16: dup
    //   17: aload #5
    //   19: invokespecial <init> : (Ljava/awt/image/BufferedImage;)V
    //   22: areturn
    //   23: astore #6
    //   25: aload #6
    //   27: <illegal opcode> 10 : (Ljava/lang/Exception;)V
    //   32: aconst_null
    //   33: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   25	7	6	lllllllllllllllIllIlIIlllIIIIIII	Ljava/lang/Exception;
    //   0	34	0	lllllllllllllllIllIlIIllIlllllll	Lme/stupitdog/bhp/f14;
    //   0	34	1	lllllllllllllllIllIlIIllIllllllI	Ljava/awt/Font;
    //   0	34	2	lllllllllllllllIllIlIIllIlllllIl	Z
    //   0	34	3	lllllllllllllllIllIlIIllIlllllII	Z
    //   0	34	4	lllllllllllllllIllIlIIllIllllIll	[Lme/stupitdog/bhp/f14$CharData;
    //   13	21	5	lllllllllllllllIllIlIIllIllllIlI	Ljava/awt/image/BufferedImage;
    // Exception table:
    //   from	to	target	type
    //   13	22	23	java/lang/Exception
  }
  
  protected BufferedImage generateFontImage(Font lllllllllllllllIllIlIIllIlllIlII, boolean lllllllllllllllIllIlIIllIlllIIll, boolean lllllllllllllllIllIlIIllIlllIIlI, CharData[] lllllllllllllllIllIlIIllIlllIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 11 : (Ljava/lang/Object;)Ljava/lang/Class;
    //   6: ldc ''
    //   8: invokevirtual length : ()I
    //   11: pop2
    //   12: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   15: iconst_3
    //   16: iaload
    //   17: istore #5
    //   19: new java/awt/image/BufferedImage
    //   22: dup
    //   23: iload #5
    //   25: iload #5
    //   27: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   30: iconst_4
    //   31: iaload
    //   32: invokespecial <init> : (III)V
    //   35: astore #6
    //   37: aload #6
    //   39: <illegal opcode> 12 : (Ljava/awt/image/BufferedImage;)Ljava/awt/Graphics;
    //   44: checkcast java/awt/Graphics2D
    //   47: astore #7
    //   49: aload #7
    //   51: aload_1
    //   52: <illegal opcode> 13 : (Ljava/awt/Graphics2D;Ljava/awt/Font;)V
    //   57: aload #7
    //   59: new java/awt/Color
    //   62: dup
    //   63: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   66: iconst_5
    //   67: iaload
    //   68: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   71: iconst_5
    //   72: iaload
    //   73: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   76: iconst_5
    //   77: iaload
    //   78: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   81: iconst_2
    //   82: iaload
    //   83: invokespecial <init> : (IIII)V
    //   86: <illegal opcode> 14 : (Ljava/awt/Graphics2D;Ljava/awt/Color;)V
    //   91: aload #7
    //   93: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   96: iconst_2
    //   97: iaload
    //   98: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   101: iconst_2
    //   102: iaload
    //   103: iload #5
    //   105: iload #5
    //   107: <illegal opcode> 15 : (Ljava/awt/Graphics2D;IIII)V
    //   112: aload #7
    //   114: <illegal opcode> 16 : ()Ljava/awt/Color;
    //   119: <illegal opcode> 14 : (Ljava/awt/Graphics2D;Ljava/awt/Color;)V
    //   124: aload #7
    //   126: <illegal opcode> 17 : ()Ljava/awt/RenderingHints$Key;
    //   131: iload_3
    //   132: invokestatic lIIIIlIIllIIIllI : (I)Z
    //   135: ifeq -> 164
    //   138: <illegal opcode> 18 : ()Ljava/lang/Object;
    //   143: ldc ''
    //   145: invokevirtual length : ()I
    //   148: pop
    //   149: ldc '   '
    //   151: invokevirtual length : ()I
    //   154: ldc '   '
    //   156: invokevirtual length : ()I
    //   159: if_icmpge -> 169
    //   162: aconst_null
    //   163: areturn
    //   164: <illegal opcode> 19 : ()Ljava/lang/Object;
    //   169: <illegal opcode> 20 : (Ljava/awt/Graphics2D;Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
    //   174: aload #7
    //   176: <illegal opcode> 21 : ()Ljava/awt/RenderingHints$Key;
    //   181: iload_2
    //   182: invokestatic lIIIIlIIllIIIllI : (I)Z
    //   185: ifeq -> 211
    //   188: <illegal opcode> 22 : ()Ljava/lang/Object;
    //   193: ldc ''
    //   195: invokevirtual length : ()I
    //   198: pop
    //   199: sipush #143
    //   202: sipush #138
    //   205: ixor
    //   206: ifne -> 216
    //   209: aconst_null
    //   210: areturn
    //   211: <illegal opcode> 23 : ()Ljava/lang/Object;
    //   216: <illegal opcode> 20 : (Ljava/awt/Graphics2D;Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
    //   221: aload #7
    //   223: <illegal opcode> 24 : ()Ljava/awt/RenderingHints$Key;
    //   228: iload_2
    //   229: invokestatic lIIIIlIIllIIIllI : (I)Z
    //   232: ifeq -> 252
    //   235: <illegal opcode> 25 : ()Ljava/lang/Object;
    //   240: ldc ''
    //   242: invokevirtual length : ()I
    //   245: pop
    //   246: aconst_null
    //   247: ifnull -> 257
    //   250: aconst_null
    //   251: areturn
    //   252: <illegal opcode> 26 : ()Ljava/lang/Object;
    //   257: <illegal opcode> 20 : (Ljava/awt/Graphics2D;Ljava/awt/RenderingHints$Key;Ljava/lang/Object;)V
    //   262: aload #7
    //   264: <illegal opcode> 27 : (Ljava/awt/Graphics2D;)Ljava/awt/FontMetrics;
    //   269: astore #8
    //   271: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   274: iconst_2
    //   275: iaload
    //   276: istore #9
    //   278: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   281: iconst_2
    //   282: iaload
    //   283: istore #10
    //   285: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   288: bipush #6
    //   290: iaload
    //   291: istore #11
    //   293: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   296: iconst_2
    //   297: iaload
    //   298: istore #12
    //   300: iload #12
    //   302: aload #4
    //   304: arraylength
    //   305: invokestatic lIIIIlIIllIIlIII : (II)Z
    //   308: ifeq -> 584
    //   311: iload #12
    //   313: i2c
    //   314: istore #13
    //   316: new me/stupitdog/bhp/f14$CharData
    //   319: dup
    //   320: invokespecial <init> : ()V
    //   323: astore #14
    //   325: aload #8
    //   327: iload #13
    //   329: <illegal opcode> 28 : (C)Ljava/lang/String;
    //   334: aload #7
    //   336: <illegal opcode> 29 : (Ljava/awt/FontMetrics;Ljava/lang/String;Ljava/awt/Graphics;)Ljava/awt/geom/Rectangle2D;
    //   341: astore #15
    //   343: aload #14
    //   345: aload #15
    //   347: <illegal opcode> 30 : (Ljava/awt/geom/Rectangle2D;)Ljava/awt/Rectangle;
    //   352: <illegal opcode> 31 : (Ljava/awt/Rectangle;)I
    //   357: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   360: bipush #7
    //   362: iaload
    //   363: iadd
    //   364: <illegal opcode> 32 : (Lme/stupitdog/bhp/f14$CharData;I)V
    //   369: aload #14
    //   371: aload #15
    //   373: <illegal opcode> 30 : (Ljava/awt/geom/Rectangle2D;)Ljava/awt/Rectangle;
    //   378: <illegal opcode> 33 : (Ljava/awt/Rectangle;)I
    //   383: <illegal opcode> 34 : (Lme/stupitdog/bhp/f14$CharData;I)V
    //   388: iload #10
    //   390: aload #14
    //   392: <illegal opcode> 35 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   397: iadd
    //   398: iload #5
    //   400: invokestatic lIIIIlIIllIIlIIl : (II)Z
    //   403: ifeq -> 427
    //   406: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   409: iconst_2
    //   410: iaload
    //   411: istore #10
    //   413: iload #11
    //   415: iload #9
    //   417: iadd
    //   418: istore #11
    //   420: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   423: iconst_2
    //   424: iaload
    //   425: istore #9
    //   427: aload #14
    //   429: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   434: iload #9
    //   436: invokestatic lIIIIlIIllIIlIlI : (II)Z
    //   439: ifeq -> 451
    //   442: aload #14
    //   444: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   449: istore #9
    //   451: aload #14
    //   453: iload #10
    //   455: <illegal opcode> 37 : (Lme/stupitdog/bhp/f14$CharData;I)V
    //   460: aload #14
    //   462: iload #11
    //   464: <illegal opcode> 38 : (Lme/stupitdog/bhp/f14$CharData;I)V
    //   469: aload #14
    //   471: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   476: aload_0
    //   477: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14;)I
    //   482: invokestatic lIIIIlIIllIIlIlI : (II)Z
    //   485: ifeq -> 501
    //   488: aload_0
    //   489: aload #14
    //   491: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   496: <illegal opcode> 1 : (Lme/stupitdog/bhp/f14;I)V
    //   501: aload #4
    //   503: iload #12
    //   505: aload #14
    //   507: aastore
    //   508: aload #7
    //   510: iload #13
    //   512: <illegal opcode> 28 : (C)Ljava/lang/String;
    //   517: iload #10
    //   519: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   522: iconst_4
    //   523: iaload
    //   524: iadd
    //   525: iload #11
    //   527: aload #8
    //   529: <illegal opcode> 40 : (Ljava/awt/FontMetrics;)I
    //   534: iadd
    //   535: <illegal opcode> 41 : (Ljava/awt/Graphics2D;Ljava/lang/String;II)V
    //   540: iload #10
    //   542: aload #14
    //   544: <illegal opcode> 35 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   549: iadd
    //   550: istore #10
    //   552: iinc #12, 1
    //   555: ldc ''
    //   557: invokevirtual length : ()I
    //   560: pop
    //   561: ldc '   '
    //   563: invokevirtual length : ()I
    //   566: ldc_w ' '
    //   569: invokevirtual length : ()I
    //   572: ldc_w ' '
    //   575: invokevirtual length : ()I
    //   578: ishl
    //   579: if_icmpgt -> 300
    //   582: aconst_null
    //   583: areturn
    //   584: aload #6
    //   586: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   316	236	13	lllllllllllllllIllIlIIllIllllIIl	C
    //   325	227	14	lllllllllllllllIllIlIIllIllllIII	Lme/stupitdog/bhp/f14$CharData;
    //   343	209	15	lllllllllllllllIllIlIIllIlllIlll	Ljava/awt/geom/Rectangle2D;
    //   300	284	12	lllllllllllllllIllIlIIllIlllIllI	I
    //   0	587	0	lllllllllllllllIllIlIIllIlllIlIl	Lme/stupitdog/bhp/f14;
    //   0	587	1	lllllllllllllllIllIlIIllIlllIlII	Ljava/awt/Font;
    //   0	587	2	lllllllllllllllIllIlIIllIlllIIll	Z
    //   0	587	3	lllllllllllllllIllIlIIllIlllIIlI	Z
    //   0	587	4	lllllllllllllllIllIlIIllIlllIIIl	[Lme/stupitdog/bhp/f14$CharData;
    //   19	568	5	lllllllllllllllIllIlIIllIlllIIII	I
    //   37	550	6	lllllllllllllllIllIlIIllIllIllll	Ljava/awt/image/BufferedImage;
    //   49	538	7	lllllllllllllllIllIlIIllIllIlllI	Ljava/awt/Graphics2D;
    //   271	316	8	lllllllllllllllIllIlIIllIllIllIl	Ljava/awt/FontMetrics;
    //   278	309	9	lllllllllllllllIllIlIIllIllIllII	I
    //   285	302	10	lllllllllllllllIllIlIIllIllIlIll	I
    //   293	294	11	lllllllllllllllIllIlIIllIllIlIlI	I
  }
  
  public void drawChar(CharData[] lllllllllllllllIllIlIIllIllIIlll, char lllllllllllllllIllIlIIllIllIIllI, float lllllllllllllllIllIlIIllIllIIlIl, float lllllllllllllllIllIlIIllIllIIlII) throws ArrayIndexOutOfBoundsException {
    // Byte code:
    //   0: aload_0
    //   1: fload_3
    //   2: fload #4
    //   4: aload_1
    //   5: iload_2
    //   6: aaload
    //   7: <illegal opcode> 35 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   12: i2f
    //   13: aload_1
    //   14: iload_2
    //   15: aaload
    //   16: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   21: i2f
    //   22: aload_1
    //   23: iload_2
    //   24: aaload
    //   25: <illegal opcode> 42 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   30: i2f
    //   31: aload_1
    //   32: iload_2
    //   33: aaload
    //   34: <illegal opcode> 43 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   39: i2f
    //   40: aload_1
    //   41: iload_2
    //   42: aaload
    //   43: <illegal opcode> 35 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   48: i2f
    //   49: aload_1
    //   50: iload_2
    //   51: aaload
    //   52: <illegal opcode> 36 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   57: i2f
    //   58: <illegal opcode> 44 : (Lme/stupitdog/bhp/f14;FFFFFFFF)V
    //   63: ldc ''
    //   65: invokevirtual length : ()I
    //   68: pop
    //   69: ldc '   '
    //   71: invokevirtual length : ()I
    //   74: ldc_w ' '
    //   77: invokevirtual length : ()I
    //   80: if_icmpgt -> 93
    //   83: return
    //   84: astore #5
    //   86: aload #5
    //   88: <illegal opcode> 10 : (Ljava/lang/Exception;)V
    //   93: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   86	7	5	lllllllllllllllIllIlIIllIllIlIIl	Ljava/lang/Exception;
    //   0	94	0	lllllllllllllllIllIlIIllIllIlIII	Lme/stupitdog/bhp/f14;
    //   0	94	1	lllllllllllllllIllIlIIllIllIIlll	[Lme/stupitdog/bhp/f14$CharData;
    //   0	94	2	lllllllllllllllIllIlIIllIllIIllI	C
    //   0	94	3	lllllllllllllllIllIlIIllIllIIlIl	F
    //   0	94	4	lllllllllllllllIllIlIIllIllIIlII	F
    // Exception table:
    //   from	to	target	type
    //   0	63	84	java/lang/Exception
  }
  
  protected void drawQuad(float lllllllllllllllIllIlIIllIllIIIlI, float lllllllllllllllIllIlIIllIllIIIIl, float lllllllllllllllIllIlIIllIllIIIII, float lllllllllllllllIllIlIIllIlIlllll, float lllllllllllllllIllIlIIllIlIllllI, float lllllllllllllllIllIlIIllIlIlllIl, float lllllllllllllllIllIlIIllIlIlllII, float lllllllllllllllIllIlIIllIlIllIll) {
    // Byte code:
    //   0: fload #5
    //   2: ldc 512.0
    //   4: fdiv
    //   5: fstore #9
    //   7: fload #6
    //   9: ldc 512.0
    //   11: fdiv
    //   12: fstore #10
    //   14: fload #7
    //   16: ldc 512.0
    //   18: fdiv
    //   19: fstore #11
    //   21: fload #8
    //   23: ldc 512.0
    //   25: fdiv
    //   26: fstore #12
    //   28: fload #9
    //   30: fload #11
    //   32: fadd
    //   33: fload #10
    //   35: <illegal opcode> 45 : (FF)V
    //   40: fload_1
    //   41: fload_3
    //   42: fadd
    //   43: f2d
    //   44: fload_2
    //   45: f2d
    //   46: <illegal opcode> 46 : (DD)V
    //   51: fload #9
    //   53: fload #10
    //   55: <illegal opcode> 45 : (FF)V
    //   60: fload_1
    //   61: f2d
    //   62: fload_2
    //   63: f2d
    //   64: <illegal opcode> 46 : (DD)V
    //   69: fload #9
    //   71: fload #10
    //   73: fload #12
    //   75: fadd
    //   76: <illegal opcode> 45 : (FF)V
    //   81: fload_1
    //   82: f2d
    //   83: fload_2
    //   84: fload #4
    //   86: fadd
    //   87: f2d
    //   88: <illegal opcode> 46 : (DD)V
    //   93: fload #9
    //   95: fload #10
    //   97: fload #12
    //   99: fadd
    //   100: <illegal opcode> 45 : (FF)V
    //   105: fload_1
    //   106: f2d
    //   107: fload_2
    //   108: fload #4
    //   110: fadd
    //   111: f2d
    //   112: <illegal opcode> 46 : (DD)V
    //   117: fload #9
    //   119: fload #11
    //   121: fadd
    //   122: fload #10
    //   124: fload #12
    //   126: fadd
    //   127: <illegal opcode> 45 : (FF)V
    //   132: fload_1
    //   133: fload_3
    //   134: fadd
    //   135: f2d
    //   136: fload_2
    //   137: fload #4
    //   139: fadd
    //   140: f2d
    //   141: <illegal opcode> 46 : (DD)V
    //   146: fload #9
    //   148: fload #11
    //   150: fadd
    //   151: fload #10
    //   153: <illegal opcode> 45 : (FF)V
    //   158: fload_1
    //   159: fload_3
    //   160: fadd
    //   161: f2d
    //   162: fload_2
    //   163: f2d
    //   164: <illegal opcode> 46 : (DD)V
    //   169: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	170	0	lllllllllllllllIllIlIIllIllIIIll	Lme/stupitdog/bhp/f14;
    //   0	170	1	lllllllllllllllIllIlIIllIllIIIlI	F
    //   0	170	2	lllllllllllllllIllIlIIllIllIIIIl	F
    //   0	170	3	lllllllllllllllIllIlIIllIllIIIII	F
    //   0	170	4	lllllllllllllllIllIlIIllIlIlllll	F
    //   0	170	5	lllllllllllllllIllIlIIllIlIllllI	F
    //   0	170	6	lllllllllllllllIllIlIIllIlIlllIl	F
    //   0	170	7	lllllllllllllllIllIlIIllIlIlllII	F
    //   0	170	8	lllllllllllllllIllIlIIllIlIllIll	F
    //   7	163	9	lllllllllllllllIllIlIIllIlIllIlI	F
    //   14	156	10	lllllllllllllllIllIlIIllIlIllIIl	F
    //   21	149	11	lllllllllllllllIllIlIIllIlIllIII	F
    //   28	142	12	lllllllllllllllIllIlIIllIlIlIlll	F
  }
  
  public int getStringHeight(String lllllllllllllllIllIlIIllIlIlIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 47 : (Lme/stupitdog/bhp/f14;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIllIlIlIllI	Lme/stupitdog/bhp/f14;
    //   0	7	1	lllllllllllllllIllIlIIllIlIlIlIl	Ljava/lang/String;
  }
  
  public int getHeight() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 39 : (Lme/stupitdog/bhp/f14;)I
    //   6: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   9: bipush #7
    //   11: iaload
    //   12: isub
    //   13: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   16: iconst_4
    //   17: iaload
    //   18: idiv
    //   19: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIlIIllIlIlIlII	Lme/stupitdog/bhp/f14;
  }
  
  public int getStringWidth(String lllllllllllllllIllIlIIllIlIlIIIl) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   3: iconst_2
    //   4: iaload
    //   5: istore_2
    //   6: aload_1
    //   7: <illegal opcode> 48 : (Ljava/lang/String;)[C
    //   12: astore_3
    //   13: aload_3
    //   14: arraylength
    //   15: istore #4
    //   17: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   20: iconst_2
    //   21: iaload
    //   22: istore #5
    //   24: iload #5
    //   26: iload #4
    //   28: invokestatic lIIIIlIIllIIlIII : (II)Z
    //   31: ifeq -> 200
    //   34: aload_3
    //   35: iload #5
    //   37: caload
    //   38: istore #6
    //   40: iload #6
    //   42: aload_0
    //   43: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   48: arraylength
    //   49: invokestatic lIIIIlIIllIIlIII : (II)Z
    //   52: ifeq -> 94
    //   55: iload #6
    //   57: invokestatic lIIIIlIIllIIlIll : (I)Z
    //   60: ifeq -> 94
    //   63: iload_2
    //   64: aload_0
    //   65: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   70: iload #6
    //   72: aaload
    //   73: <illegal opcode> 35 : (Lme/stupitdog/bhp/f14$CharData;)I
    //   78: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   81: bipush #7
    //   83: iaload
    //   84: isub
    //   85: aload_0
    //   86: <illegal opcode> 49 : (Lme/stupitdog/bhp/f14;)I
    //   91: iadd
    //   92: iadd
    //   93: istore_2
    //   94: iinc #5, 1
    //   97: ldc ''
    //   99: invokevirtual length : ()I
    //   102: pop
    //   103: ldc_w ' '
    //   106: invokevirtual length : ()I
    //   109: ldc_w ' '
    //   112: invokevirtual length : ()I
    //   115: ishl
    //   116: ldc_w ' '
    //   119: invokevirtual length : ()I
    //   122: ldc_w ' '
    //   125: invokevirtual length : ()I
    //   128: ishl
    //   129: if_icmpeq -> 24
    //   132: bipush #13
    //   134: bipush #100
    //   136: ixor
    //   137: sipush #130
    //   140: sipush #145
    //   143: ixor
    //   144: ldc_w ' '
    //   147: invokevirtual length : ()I
    //   150: ldc_w ' '
    //   153: invokevirtual length : ()I
    //   156: ishl
    //   157: ishl
    //   158: ixor
    //   159: bipush #39
    //   161: bipush #12
    //   163: ixor
    //   164: ldc_w ' '
    //   167: invokevirtual length : ()I
    //   170: ldc_w ' '
    //   173: invokevirtual length : ()I
    //   176: ishl
    //   177: ishl
    //   178: bipush #29
    //   180: bipush #44
    //   182: iadd
    //   183: bipush #35
    //   185: isub
    //   186: bipush #99
    //   188: iadd
    //   189: ixor
    //   190: ldc_w ' '
    //   193: invokevirtual length : ()I
    //   196: ineg
    //   197: ixor
    //   198: iand
    //   199: ireturn
    //   200: iload_2
    //   201: getstatic me/stupitdog/bhp/f14.llIIIllIIlIIII : [I
    //   204: iconst_4
    //   205: iaload
    //   206: idiv
    //   207: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   40	54	6	lllllllllllllllIllIlIIllIlIlIIll	C
    //   0	208	0	lllllllllllllllIllIlIIllIlIlIIlI	Lme/stupitdog/bhp/f14;
    //   0	208	1	lllllllllllllllIllIlIIllIlIlIIIl	Ljava/lang/String;
    //   6	202	2	lllllllllllllllIllIlIIllIlIlIIII	I
  }
  
  public boolean isAntiAlias() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 50 : (Lme/stupitdog/bhp/f14;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIllIlIIllll	Lme/stupitdog/bhp/f14;
  }
  
  public void setAntiAlias(boolean lllllllllllllllIllIlIIllIlIIllIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 50 : (Lme/stupitdog/bhp/f14;)Z
    //   6: iload_1
    //   7: invokestatic lIIIIlIIllIIllII : (II)Z
    //   10: ifeq -> 51
    //   13: aload_0
    //   14: iload_1
    //   15: <illegal opcode> 4 : (Lme/stupitdog/bhp/f14;Z)V
    //   20: aload_0
    //   21: aload_0
    //   22: aload_0
    //   23: <illegal opcode> 51 : (Lme/stupitdog/bhp/f14;)Ljava/awt/Font;
    //   28: iload_1
    //   29: aload_0
    //   30: <illegal opcode> 52 : (Lme/stupitdog/bhp/f14;)Z
    //   35: aload_0
    //   36: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   41: <illegal opcode> 7 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   46: <illegal opcode> 8 : (Lme/stupitdog/bhp/f14;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   51: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	52	0	lllllllllllllllIllIlIIllIlIIlllI	Lme/stupitdog/bhp/f14;
    //   0	52	1	lllllllllllllllIllIlIIllIlIIllIl	Z
  }
  
  public boolean isFractionalMetrics() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 52 : (Lme/stupitdog/bhp/f14;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIllIlIIllII	Lme/stupitdog/bhp/f14;
  }
  
  public void setFractionalMetrics(boolean lllllllllllllllIllIlIIllIlIIlIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 52 : (Lme/stupitdog/bhp/f14;)Z
    //   6: iload_1
    //   7: invokestatic lIIIIlIIllIIllII : (II)Z
    //   10: ifeq -> 51
    //   13: aload_0
    //   14: iload_1
    //   15: <illegal opcode> 5 : (Lme/stupitdog/bhp/f14;Z)V
    //   20: aload_0
    //   21: aload_0
    //   22: aload_0
    //   23: <illegal opcode> 51 : (Lme/stupitdog/bhp/f14;)Ljava/awt/Font;
    //   28: aload_0
    //   29: <illegal opcode> 50 : (Lme/stupitdog/bhp/f14;)Z
    //   34: iload_1
    //   35: aload_0
    //   36: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   41: <illegal opcode> 7 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   46: <illegal opcode> 8 : (Lme/stupitdog/bhp/f14;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   51: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	52	0	lllllllllllllllIllIlIIllIlIIlIll	Lme/stupitdog/bhp/f14;
    //   0	52	1	lllllllllllllllIllIlIIllIlIIlIlI	Z
  }
  
  public Font getFont() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 51 : (Lme/stupitdog/bhp/f14;)Ljava/awt/Font;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIllIlIIlIIl	Lme/stupitdog/bhp/f14;
  }
  
  public void setFont(Font lllllllllllllllIllIlIIllIlIIIlll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 3 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;)V
    //   7: aload_0
    //   8: aload_0
    //   9: aload_1
    //   10: aload_0
    //   11: <illegal opcode> 50 : (Lme/stupitdog/bhp/f14;)Z
    //   16: aload_0
    //   17: <illegal opcode> 52 : (Lme/stupitdog/bhp/f14;)Z
    //   22: aload_0
    //   23: <illegal opcode> 6 : (Lme/stupitdog/bhp/f14;)[Lme/stupitdog/bhp/f14$CharData;
    //   28: <illegal opcode> 7 : (Lme/stupitdog/bhp/f14;Ljava/awt/Font;ZZ[Lme/stupitdog/bhp/f14$CharData;)Lnet/minecraft/client/renderer/texture/DynamicTexture;
    //   33: <illegal opcode> 8 : (Lme/stupitdog/bhp/f14;Lnet/minecraft/client/renderer/texture/DynamicTexture;)V
    //   38: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	39	0	lllllllllllllllIllIlIIllIlIIlIII	Lme/stupitdog/bhp/f14;
    //   0	39	1	lllllllllllllllIllIlIIllIlIIIlll	Ljava/awt/Font;
  }
  
  static {
    lIIIIlIIllIIIlIl();
    lIIIIlIIlIllllIl();
    lIIIIlIIlIllllII();
    lIIIIlIIlIllIIll();
  }
  
  private static CallSite lIIIIlIIIllIIllI(MethodHandles.Lookup lllllllllllllllIllIlIIllIIlllllI, String lllllllllllllllIllIlIIllIIllllIl, MethodType lllllllllllllllIllIlIIllIIllllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIllIlIIIlII = llIIIlIllIlIIl[Integer.parseInt(lllllllllllllllIllIlIIllIIllllIl)].split(llIIIllIIIIllI[llIIIllIIlIIII[2]]);
      Class<?> lllllllllllllllIllIlIIllIlIIIIll = Class.forName(lllllllllllllllIllIlIIllIlIIIlII[llIIIllIIlIIII[2]]);
      String lllllllllllllllIllIlIIllIlIIIIlI = lllllllllllllllIllIlIIllIlIIIlII[llIIIllIIlIIII[6]];
      MethodHandle lllllllllllllllIllIlIIllIlIIIIIl = null;
      int lllllllllllllllIllIlIIllIlIIIIII = lllllllllllllllIllIlIIllIlIIIlII[llIIIllIIlIIII[8]].length();
      if (lIIIIlIIllIIllIl(lllllllllllllllIllIlIIllIlIIIIII, llIIIllIIlIIII[4])) {
        MethodType lllllllllllllllIllIlIIllIlIIIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIllIlIIIlII[llIIIllIIlIIII[4]], f14.class.getClassLoader());
        if (lIIIIlIIllIIlllI(lllllllllllllllIllIlIIllIlIIIIII, llIIIllIIlIIII[4])) {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findVirtual(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findStatic(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIllI);
        } 
        "".length();
        if (((0xB ^ 0xE) & (0x92 ^ 0x97 ^ 0xFFFFFFFF)) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIllIlIIIlIl = llIIIlIllIlIlI[Integer.parseInt(lllllllllllllllIllIlIIllIlIIIlII[llIIIllIIlIIII[4]])];
        if (lIIIIlIIllIIlllI(lllllllllllllllIllIlIIllIlIIIIII, llIIIllIIlIIII[8])) {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findGetter(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIlIl);
          "".length();
          if ("   ".length() < " ".length())
            return null; 
        } else if (lIIIIlIIllIIlllI(lllllllllllllllIllIlIIllIlIIIIII, llIIIllIIlIIII[9])) {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findStaticGetter(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIlIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIIllIIlllI(lllllllllllllllIllIlIIllIlIIIIII, llIIIllIIlIIII[10])) {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findSetter(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIlIl);
          "".length();
          if (-((0x4E ^ 0x53) << " ".length() << " ".length() ^ 0x73 ^ 0x2) >= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIllIlIIIIIl = lllllllllllllllIllIlIIllIIlllllI.findStaticSetter(lllllllllllllllIllIlIIllIlIIIIll, lllllllllllllllIllIlIIllIlIIIIlI, lllllllllllllllIllIlIIllIlIIIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIllIlIIIIIl);
    } catch (Exception lllllllllllllllIllIlIIllIIllllll) {
      lllllllllllllllIllIlIIllIIllllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIlIllIIll() {
    llIIIlIllIlIIl = new String[llIIIllIIlIIII[11]];
    llIIIlIllIlIIl[llIIIllIIlIIII[12]] = llIIIllIIIIllI[llIIIllIIlIIII[6]];
    llIIIlIllIlIIl[llIIIllIIlIIII[13]] = llIIIllIIIIllI[llIIIllIIlIIII[4]];
    llIIIlIllIlIIl[llIIIllIIlIIII[14]] = llIIIllIIIIllI[llIIIllIIlIIII[8]];
    llIIIlIllIlIIl[llIIIllIIlIIII[15]] = llIIIllIIIIllI[llIIIllIIlIIII[9]];
    llIIIlIllIlIIl[llIIIllIIlIIII[16]] = llIIIllIIIIllI[llIIIllIIlIIII[10]];
    llIIIlIllIlIIl[llIIIllIIlIIII[17]] = llIIIllIIIIllI[llIIIllIIlIIII[18]];
    llIIIlIllIlIIl[llIIIllIIlIIII[19]] = llIIIllIIIIllI[llIIIllIIlIIII[13]];
    llIIIlIllIlIIl[llIIIllIIlIIII[20]] = llIIIllIIIIllI[llIIIllIIlIIII[7]];
    llIIIlIllIlIIl[llIIIllIIlIIII[21]] = llIIIllIIIIllI[llIIIllIIlIIII[22]];
    llIIIlIllIlIIl[llIIIllIIlIIII[9]] = llIIIllIIIIllI[llIIIllIIlIIII[12]];
    llIIIlIllIlIIl[llIIIllIIlIIII[23]] = llIIIllIIIIllI[llIIIllIIlIIII[24]];
    llIIIlIllIlIIl[llIIIllIIlIIII[25]] = llIIIllIIIIllI[llIIIllIIlIIII[26]];
    llIIIlIllIlIIl[llIIIllIIlIIII[27]] = llIIIllIIIIllI[llIIIllIIlIIII[28]];
    llIIIlIllIlIIl[llIIIllIIlIIII[29]] = llIIIllIIIIllI[llIIIllIIlIIII[30]];
    llIIIlIllIlIIl[llIIIllIIlIIII[31]] = llIIIllIIIIllI[llIIIllIIlIIII[32]];
    llIIIlIllIlIIl[llIIIllIIlIIII[8]] = llIIIllIIIIllI[llIIIllIIlIIII[33]];
    llIIIlIllIlIIl[llIIIllIIlIIII[34]] = llIIIllIIIIllI[llIIIllIIlIIII[35]];
    llIIIlIllIlIIl[llIIIllIIlIIII[36]] = llIIIllIIIIllI[llIIIllIIlIIII[17]];
    llIIIlIllIlIIl[llIIIllIIlIIII[37]] = llIIIllIIIIllI[llIIIllIIlIIII[38]];
    llIIIlIllIlIIl[llIIIllIIlIIII[6]] = llIIIllIIIIllI[llIIIllIIlIIII[39]];
    llIIIlIllIlIIl[llIIIllIIlIIII[4]] = llIIIllIIIIllI[llIIIllIIlIIII[40]];
    llIIIlIllIlIIl[llIIIllIIlIIII[41]] = llIIIllIIIIllI[llIIIllIIlIIII[37]];
    llIIIlIllIlIIl[llIIIllIIlIIII[40]] = llIIIllIIIIllI[llIIIllIIlIIII[42]];
    llIIIlIllIlIIl[llIIIllIIlIIII[43]] = llIIIllIIIIllI[llIIIllIIlIIII[25]];
    llIIIlIllIlIIl[llIIIllIIlIIII[44]] = llIIIllIIIIllI[llIIIllIIlIIII[31]];
    llIIIlIllIlIIl[llIIIllIIlIIII[30]] = llIIIllIIIIllI[llIIIllIIlIIII[45]];
    llIIIlIllIlIIl[llIIIllIIlIIII[46]] = llIIIllIIIIllI[llIIIllIIlIIII[47]];
    llIIIlIllIlIIl[llIIIllIIlIIII[47]] = llIIIllIIIIllI[llIIIllIIlIIII[34]];
    llIIIlIllIlIIl[llIIIllIIlIIII[7]] = llIIIllIIIIllI[llIIIllIIlIIII[43]];
    llIIIlIllIlIIl[llIIIllIIlIIII[48]] = llIIIllIIIIllI[llIIIllIIlIIII[23]];
    llIIIlIllIlIIl[llIIIllIIlIIII[38]] = llIIIllIIIIllI[llIIIllIIlIIII[49]];
    llIIIlIllIlIIl[llIIIllIIlIIII[28]] = llIIIllIIIIllI[llIIIllIIlIIII[50]];
    llIIIlIllIlIIl[llIIIllIIlIIII[18]] = llIIIllIIIIllI[llIIIllIIlIIII[21]];
    llIIIlIllIlIIl[llIIIllIIlIIII[49]] = llIIIllIIIIllI[llIIIllIIlIIII[46]];
    llIIIlIllIlIIl[llIIIllIIlIIII[45]] = llIIIllIIIIllI[llIIIllIIlIIII[51]];
    llIIIlIllIlIIl[llIIIllIIlIIII[26]] = llIIIllIIIIllI[llIIIllIIlIIII[36]];
    llIIIlIllIlIIl[llIIIllIIlIIII[35]] = llIIIllIIIIllI[llIIIllIIlIIII[27]];
    llIIIlIllIlIIl[llIIIllIIlIIII[52]] = llIIIllIIIIllI[llIIIllIIlIIII[53]];
    llIIIlIllIlIIl[llIIIllIIlIIII[42]] = llIIIllIIIIllI[llIIIllIIlIIII[54]];
    llIIIlIllIlIIl[llIIIllIIlIIII[32]] = llIIIllIIIIllI[llIIIllIIlIIII[55]];
    llIIIlIllIlIIl[llIIIllIIlIIII[2]] = llIIIllIIIIllI[llIIIllIIlIIII[56]];
    llIIIlIllIlIIl[llIIIllIIlIIII[51]] = llIIIllIIIIllI[llIIIllIIlIIII[15]];
    llIIIlIllIlIIl[llIIIllIIlIIII[39]] = llIIIllIIIIllI[llIIIllIIlIIII[41]];
    llIIIlIllIlIIl[llIIIllIIlIIII[55]] = llIIIllIIIIllI[llIIIllIIlIIII[14]];
    llIIIlIllIlIIl[llIIIllIIlIIII[50]] = llIIIllIIIIllI[llIIIllIIlIIII[29]];
    llIIIlIllIlIIl[llIIIllIIlIIII[54]] = llIIIllIIIIllI[llIIIllIIlIIII[44]];
    llIIIlIllIlIIl[llIIIllIIlIIII[56]] = llIIIllIIIIllI[llIIIllIIlIIII[52]];
    llIIIlIllIlIIl[llIIIllIIlIIII[10]] = llIIIllIIIIllI[llIIIllIIlIIII[16]];
    llIIIlIllIlIIl[llIIIllIIlIIII[22]] = llIIIllIIIIllI[llIIIllIIlIIII[19]];
    llIIIlIllIlIIl[llIIIllIIlIIII[24]] = llIIIllIIIIllI[llIIIllIIlIIII[57]];
    llIIIlIllIlIIl[llIIIllIIlIIII[53]] = llIIIllIIIIllI[llIIIllIIlIIII[20]];
    llIIIlIllIlIIl[llIIIllIIlIIII[57]] = llIIIllIIIIllI[llIIIllIIlIIII[48]];
    llIIIlIllIlIIl[llIIIllIIlIIII[33]] = llIIIllIIIIllI[llIIIllIIlIIII[11]];
    llIIIlIllIlIlI = new Class[llIIIllIIlIIII[22]];
    llIIIlIllIlIlI[llIIIllIIlIIII[9]] = boolean.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[10]] = DynamicTexture.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[4]] = int.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[6]] = CharData[].class;
    llIIIlIllIlIlI[llIIIllIIlIIII[7]] = Object.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[13]] = RenderingHints.Key.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[2]] = float.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[18]] = Color.class;
    llIIIlIllIlIlI[llIIIllIIlIIII[8]] = Font.class;
  }
  
  private static void lIIIIlIIlIllllII() {
    llIIIllIIIIllI = new String[llIIIllIIlIIII[58]];
    llIIIllIIIIllI[llIIIllIIlIIII[2]] = lIIIIlIIlIllIlII(llIIIllIIIlIlI[llIIIllIIlIIII[2]], llIIIllIIIlIlI[llIIIllIIlIIII[6]]);
    llIIIllIIIIllI[llIIIllIIlIIII[6]] = lIIIIlIIlIllIlII(llIIIllIIIlIlI[llIIIllIIlIIII[4]], llIIIllIIIlIlI[llIIIllIIlIIII[8]]);
    llIIIllIIIIllI[llIIIllIIlIIII[4]] = lIIIIlIIlIllIlII(llIIIllIIIlIlI[llIIIllIIlIIII[9]], llIIIllIIIlIlI[llIIIllIIlIIII[10]]);
    llIIIllIIIIllI[llIIIllIIlIIII[8]] = lIIIIlIIlIllIlIl(llIIIllIIIlIlI[llIIIllIIlIIII[18]], llIIIllIIIlIlI[llIIIllIIlIIII[13]]);
    llIIIllIIIIllI[llIIIllIIlIIII[9]] = lIIIIlIIlIllIlIl(llIIIllIIIlIlI[llIIIllIIlIIII[7]], llIIIllIIIlIlI[llIIIllIIlIIII[22]]);
    llIIIllIIIIllI[llIIIllIIlIIII[10]] = lIIIIlIIlIllIllI(llIIIllIIIlIlI[llIIIllIIlIIII[12]], llIIIllIIIlIlI[llIIIllIIlIIII[24]]);
    llIIIllIIIIllI[llIIIllIIlIIII[18]] = lIIIIlIIlIllIlII("AywyG30IOjBUAQwjIB8hACMjMjoHOTdABSgBET8MLx8FOQcgAgo7HyQIECgaKh4bNR1TdX5ac0lt", "iMDzS");
    llIIIllIIIIllI[llIIIllIIlIIII[13]] = lIIIIlIIlIllIlIl("Iu3/hdYbJMBnbEbQtKcuLniWNtDwKGEaPqvLLSw2u/pyv6IVqV3CfA==", "hMUGz");
    llIIIllIIIIllI[llIIIllIIlIIII[7]] = lIIIIlIIlIllIlII("KQhHERAxHQAWACsKRwAMNEMPU1B+CwYMEH5eU0JEZA==", "Dmibd");
    llIIIllIIIIllI[llIIIllIIlIIII[22]] = lIIIIlIIlIllIlII("GyMTKEAQNRFnPBQhESgAFi4AcwYUKwIhGktwX2lOUQ==", "qBeIn");
    llIIIllIIIIllI[llIIIllIIlIIII[12]] = lIIIIlIIlIllIllI("H295uVECB6t9M0xoC074CP7wxVixlgsb0X9/ziAT9VCrXvWULSOa4A==", "BojIb");
    llIIIllIIIIllI[llIIIllIIlIIII[24]] = lIIIIlIIlIllIlIl("+rsqJcaJCAc/JYauaO3zcOlziiGq7w2B45BniNaoB5UAKQ23DNbanLJbgUrM7he5B7v/RfRPrYb2sycynraC8g==", "DTzOI");
    llIIIllIIIIllI[llIIIllIIlIIII[26]] = lIIIIlIIlIllIlII("DBkhK3oHDyNkBgMWMy8mDxYwAj0IDCRwHyMhCAsaMjEWBh0nKx4EE1xPbWp0Rlg=", "fxWJT");
    llIIIllIIIIllI[llIIIllIIlIIII[28]] = lIIIIlIIlIllIllI("njApuj3SwxvvPuKdRwpId4O+Dm7zgzDb66UE1MyyYiXn7NF64B+3er9KyTG1vFme", "vJWgz");
    llIIIllIIIIllI[llIIIllIIlIIII[30]] = lIIIIlIIlIllIllI("dolKUGG73FivstvkavHjanpRwlnYQucMdMTv+XxT7JSSB2TpNKI0Nd12AKndkYSF", "WOcHe");
    llIIIllIIIIllI[llIIIllIIlIIII[32]] = lIIIIlIIlIllIllI("+m1/w9umlj2iyGFRJ99gtncrF2WC6uLeqFp+UdIFMUNys0NjVHPrhAeps1OAkimh1wLa0nxxjhE=", "DQXUm");
    llIIIllIIIIllI[llIIIllIIlIIII[33]] = lIIIIlIIlIllIlII("ID1JFAU4KA4TFSI/SQUZPXYBVkV3PggJBXdrXUdRbXhH", "MXggq");
    llIIIllIIIIllI[llIIIllIIlIIII[35]] = lIIIIlIIlIllIllI("Vv5Z0ia3RNoqrn4c7XxGKHMwh+pzigla9UyRO3Itl+Ra6sX7CbvwOXComzDSV+Zrud4KjPvRaLk=", "gpYfU");
    llIIIllIIIIllI[llIIIllIIlIIII[17]] = lIIIIlIIlIllIllI("ArXlRsogrT3kYz68IfSfdiiUdSAuRRLDq+hgVBAeZZocwTQLe3NROgMVafm5VYT8", "NmLVi");
    llIIIllIIIIllI[llIIIllIIlIIII[38]] = lIIIIlIIlIllIlIl("W+aqXrD3M6jOWQg9dC6BpMTl9idK+k8rbZtxzosmtNOyPENXZDBanLfQ9UzRX5DxTjTsLRqJB9E=", "QALSp");
    llIIIllIIIIllI[llIIIllIIlIIII[39]] = lIIIIlIIlIllIlIl("wnClpVYSVwrXLUhYvd2PDUzgviP8HIA32uNrBkV++SMllr1mKQuQlQ==", "uWzPD");
    llIIIllIIIIllI[llIIIllIIlIIII[40]] = lIIIIlIIlIllIllI("hWLsiB6grDUvJZfcBfgMVHtvKutz89r0Kyf8A84tHEnVXaXMsmbQoQ==", "iRoCH");
    llIIIllIIIIllI[llIIIllIIlIIII[37]] = lIIIIlIIlIllIlII("BQ5tPT0dGyo6LQcMbSwhGEUlf31MKCsvOywKNy9zGx8sPCwMMnl8c0hLYw==", "hkCNI");
    llIIIllIIIIllI[llIIIllIIlIIII[42]] = lIIIIlIIlIllIllI("pRWRSflzlIIw6n+9ZMuOLUyAincJoqZaozzACbzdHSdndeYSX/htJTJ6Vxc1sQmx/hUxDmDx5D4=", "PNQue");
    llIIIllIIIIllI[llIIIllIIlIIII[25]] = lIIIIlIIlIllIlII("BzMSCU0MJRBGJQI8ECUGGSANCxBXNQEcMBkgDQYELz0RBgceaEwkCQwkBUcPDDwDRzAZIA0GBFYeDgkVDH0FHxdCFRYJEwU7BxtYRB4OCRUMfQUfF0I1AQcOQgABCxcMPAMEBl8WX1JDTQ==", "mRdhc");
    llIIIllIIIIllI[llIIIllIIlIIII[31]] = lIIIIlIIlIllIlIl("jV2VLtW1pSAJM5Y7Rq78SR+RtN241uPxlm3vVtQhnjd9bEp5cWPE9girLXYGiVwq", "BlHdE");
    llIIIllIIIIllI[llIIIllIIlIIII[45]] = lIIIIlIIlIllIlIl("R9aSzkXw9aQijsFSWP3JKk56l9fKNITL+z0C8xNKCA0EWSCTdm8s6zezNWRAls9Mc/6cwvGHUVM=", "OJYGl");
    llIIIllIIIIllI[llIIIllIIlIIII[47]] = lIIIIlIIlIllIlII("IhNDFD46BgQTLiARQwUiP1gLVn5rNQUGOAsXGQZwJxMEACI7TF9dam9WTUc=", "OvmgJ");
    llIIIllIIIIllI[llIIIllIIlIIII[34]] = lIIIIlIIlIllIllI("cYAvA1t72UJOnsjZ+CtjbvdeM0JZ5DAPichag5FIQshiIYN7r2HORxNlkKeHHp+lichag5FIQsht9gQzjIwFhg==", "skdVH");
    llIIIllIIIIllI[llIIIllIIlIIII[43]] = lIIIIlIIlIllIlII("ARF4HzsZBD8YKwMTeA4nHFowXXtWADMUdVlOdkxvTFQ=", "ltVlO");
    llIIIllIIIIllI[llIIIllIIlIIII[23]] = lIIIIlIIlIllIlIl("bRXDZoReFVmQIFq8z5T6+RDxDtxpRGuxEjyj3bAg2npnwwLGn59mYCWztHWBory8", "qLIWT");
    llIIIllIIIIllI[llIIIllIIlIIII[49]] = lIIIIlIIlIllIllI("QXUgHvTFzC0ypwJ0yWzM+QfNu6TUGrH4H5DWTDF61iapBCtcEmfgKdR8oYD5zx7Q2GNhB2ZRGHZ8KwAHHMv1lA==", "gkQeT");
    llIIIllIIIIllI[llIIIllIIlIIII[50]] = lIIIIlIIlIllIlII("BwUCD28MEwBABh8FBAYoDhdGKnseAQAoLgMQTkYNBwUCD24MEwBBBwIKAFVoO15UTg==", "mdtnA");
    llIIIllIIIIllI[llIIIllIIlIIII[21]] = lIIIIlIIlIllIlII("HzBEHC0HJQMbPR0yRA0xAnsMXm1INgIOKzY0Hg5jQ29KT3k=", "rUjoY");
    llIIIllIIIIllI[llIIIllIIlIIII[46]] = lIIIIlIIlIllIllI("baK52DE63IxxwB+k/dRUpgd9SsGksDocg7d7ESrI13A=", "aIqDa");
    llIIIllIIIIllI[llIIIllIIlIIII[51]] = lIIIIlIIlIllIllI("PYqilpCwo0RDpVfeIb6rkNEYcrYvKQC5G0DQxeKou/O4aPpk47fRJ7BtNgBhbT23bo7g+ChX/8Y=", "Zyvbo");
    llIIIllIIIIllI[llIIIllIIlIIII[36]] = lIIIIlIIlIllIllI("49n+r2Eu3G9hvFjfRnLybAaPIOoFlvYyat2Dm9vomDnQUrn2XfO1fg8OHrizudsAbNQluVuzABIEtDmAUp7caXr28/d+H/Bx", "LDJZq");
    llIIIllIIIIllI[llIIIllIIlIIII[27]] = lIIIIlIIlIllIlII("Hi0/IkUVOz1tOREiLSYZHSIuCwIaODp5IDEVFgU5NQ8dCiQ6DQUOLiAeAAA4TntzY0tUbA==", "tLICk");
    llIIIllIIIIllI[llIIIllIIlIIII[53]] = lIIIIlIIlIllIlIl("enMMafHkdoAMzqafiplc/H9j8IB13UMNIz30OGCL6FM2r0SXZ43s2Q==", "GokOO");
    llIIIllIIIIllI[llIIIllIIlIIII[54]] = lIIIIlIIlIllIllI("RG9ZXm5mJi/TaFt1d5/BQ0ZEBxxI1Iu7pkalqHlYJtFxUIsibjLKkqu4nx5rnjszr/hUHec9Quk=", "LbVoO");
    llIIIllIIIIllI[llIIIllIIlIIII[55]] = lIIIIlIIlIllIlII("Pi0/DXg1Oz1CESYtOQQ/Nz97KGwyJSUABDEvPVZ+HQUAJX8CdmlM", "TLIlV");
    llIIIllIIIIllI[llIIIllIIlIIII[56]] = lIIIIlIIlIllIllI("BAjWwqG+EQ2Y7zNSS4xFqRvXg3x/OFj4YlN6N8P5KuwVxiJMmF7B3w==", "vGMPU");
    llIIIllIIIIllI[llIIIllIIlIIII[15]] = lIIIIlIIlIllIllI("EUBy8/eQBn8BjSwGU17khsAXkc+M2MUf/eU0dWguMxYfdD9rboa27VPIwDB0xACE", "lVhLz");
    llIIIllIIIIllI[llIIIllIIlIIII[41]] = lIIIIlIIlIllIlIl("+dOdCNRz/AZkLBSGB68DhkUYv6o/zt4+5SBYIyQhsBS+o9Y1vjTSFhg1o7LdB8U+4/ayZWTv4Z1I5YajNWukvBZkD+7qRXgjj4d4qpDpnUu89APYLoV2MsyaorHXnpNl", "LnIlc");
    llIIIllIIIIllI[llIIIllIIlIIII[14]] = lIIIIlIIlIllIlIl("roYC9/Xd7VOw+IupcCqvUClJrjZp2OsQLT9mbgFtJk8Jdz7FfPvBzw==", "FLyqa");
    llIIIllIIIIllI[llIIIllIIlIIII[29]] = lIIIIlIIlIllIlIl("dJ6YVkvEb90GE1UdvmMI55WYMOPae8qm3g1s3f+g6T9qyman3nIf77eK/rk/W1Nm", "vOIVA");
    llIIIllIIIIllI[llIIIllIIlIIII[44]] = lIIIIlIIlIllIllI("Zh5BQvv9DRlY3hIe+7UBhwbsUWXJ8PGN54u1xvKo5ilKGBxE95i41w==", "ePYDW");
    llIIIllIIIIllI[llIIIllIIlIIII[52]] = lIIIIlIIlIllIlII("BiohJH4NPCNrFx4qJy05DzhlAWoIOTYyAxg5Pis3VmMbLzEaKngpMQIseBYkHiI5ImslAn4Takxr", "lKWEP");
    llIIIllIIIIllI[llIIIllIIlIIII[16]] = lIIIIlIIlIllIllI("gcB02dO8rsn4tvHSigWpND1+k0d7zFBf08iXsNF1wod+ETId+thd4xQH7DQIzbz4", "fDoCQ");
    llIIIllIIIIllI[llIIIllIIlIIII[19]] = lIIIIlIIlIllIllI("QWm+eZ6sujQpOvgWRoCtyHWknTRxuZ1oLwXRUg5gZJ2MI+KRO8/tc2PPrWyJoLARX4xnOWH8o4Ca+crHiEpcNGdTD+19AFLkPbISQfYd4/g8goOjqLX+GNL0YrJMP3CAjzqzu+tEKyFkqkFXu5x2dsrJf1xUYW2yUKWOeHeeJPQ=", "xlUUu");
    llIIIllIIIIllI[llIIIllIIlIIII[57]] = lIIIIlIIlIllIllI("BXanuLSnXsShHVdadKElp9fnAe+H8EODFBjXKP3xJZ3WxAtDCBfzpnWiuuyVhtum4oBP22vjkBo=", "kFHtX");
    llIIIllIIIIllI[llIIIllIIlIIII[20]] = lIIIIlIIlIllIlII("ACx4BzsYOT8AKwIueBYnHWcwRXtJCj4VPSkoIhV1Hj05BioJEGxGdU1pdlRv", "mIVtO");
    llIIIllIIIIllI[llIIIllIIlIIII[48]] = lIIIIlIIlIllIlIl("lcljqQBqa+XHntENtubaN/A6zDj6onhUN2d4cS5L6Qn6tNMeUJtNsA==", "CLsuh");
    llIIIllIIIIllI[llIIIllIIlIIII[11]] = lIIIIlIIlIllIlIl("vk7kEQOPyGAypP6BSXuAZwnBWKHzV/O9nsY3kVwandY=", "MDufn");
    llIIIllIIIlIlI = null;
  }
  
  private static void lIIIIlIIlIllllIl() {
    String str = (new Exception()).getStackTrace()[llIIIllIIlIIII[2]].getFileName();
    llIIIllIIIlIlI = str.substring(str.indexOf("ä") + llIIIllIIlIIII[6], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIlIllIlIl(String lllllllllllllllIllIlIIllIIlllIII, String lllllllllllllllIllIlIIllIIllIlll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIllIIlllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIllIIllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIllIIlllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIllIIlllIlI.init(llIIIllIIlIIII[4], lllllllllllllllIllIlIIllIIlllIll);
      return new String(lllllllllllllllIllIlIIllIIlllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIllIIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIllIIlllIIl) {
      lllllllllllllllIllIlIIllIIlllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIlIllIllI(String lllllllllllllllIllIlIIllIIllIIll, String lllllllllllllllIllIlIIllIIllIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIllIIllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIllIIllIIlI.getBytes(StandardCharsets.UTF_8)), llIIIllIIlIIII[7]), "DES");
      Cipher lllllllllllllllIllIlIIllIIllIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIllIIllIlIl.init(llIIIllIIlIIII[4], lllllllllllllllIllIlIIllIIllIllI);
      return new String(lllllllllllllllIllIlIIllIIllIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIllIIllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIllIIllIlII) {
      lllllllllllllllIllIlIIllIIllIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIlIllIlII(String lllllllllllllllIllIlIIllIIllIIII, String lllllllllllllllIllIlIIllIIlIllll) {
    lllllllllllllllIllIlIIllIIllIIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIllIIllIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIllIIlIlllI = new StringBuilder();
    char[] lllllllllllllllIllIlIIllIIlIllIl = lllllllllllllllIllIlIIllIIlIllll.toCharArray();
    int lllllllllllllllIllIlIIllIIlIllII = llIIIllIIlIIII[2];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIllIIllIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIIlIIII[2];
    while (lIIIIlIIllIIlIII(j, i)) {
      char lllllllllllllllIllIlIIllIIllIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIllIIlIllII++;
      j++;
      "".length();
      if ("   ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIllIIlIlllI);
  }
  
  private static void lIIIIlIIllIIIlIl() {
    llIIIllIIlIIII = new int[59];
    llIIIllIIlIIII[0] = " ".length() << " ".length() << "   ".length();
    llIIIllIIlIIII[1] = -" ".length();
    llIIIllIIlIIII[2] = ((0xA8 ^ 0xA3) << " ".length() << " ".length() ^ 0x27 ^ 0x0) << "   ".length() & (((0x9 ^ 0x12) << " ".length() ^ 0x21 ^ 0x1C) << "   ".length() ^ -" ".length());
    llIIIllIIlIIII[3] = " ".length() << (0x3E ^ 0x37);
    llIIIllIIlIIII[4] = " ".length() << " ".length();
    llIIIllIIlIIII[5] = ((0xD0 ^ 0xC1) << " ".length() << " ".length()) + 4 + 163 - 39 + 51 - (0x20 ^ 0x6F) + (0x1 ^ 0x56);
    llIIIllIIlIIII[6] = " ".length();
    llIIIllIIlIIII[7] = " ".length() << "   ".length();
    llIIIllIIlIIII[8] = "   ".length();
    llIIIllIIlIIII[9] = " ".length() << " ".length() << " ".length();
    llIIIllIIlIIII[10] = 0x44 ^ 0xF ^ (0x99 ^ 0xBE) << " ".length();
    llIIIllIIlIIII[11] = 0x2F ^ 0x7A ^ "   ".length() << (0xBD ^ 0xB8);
    llIIIllIIlIIII[12] = (45 + 8 - 3 + 111 ^ (0x15 ^ 0x3C) << " ".length() << " ".length()) << " ".length();
    llIIIllIIlIIII[13] = 0xF9 ^ 0x9C ^ (0x20 ^ 0x11) << " ".length();
    llIIIllIIlIIII[14] = ((0x7F ^ 0x76) << " ".length() << " ".length() << " ".length() ^ 34 + 72 - -2 + 47) << " ".length() << " ".length();
    llIIIllIIlIIII[15] = (62 + 120 - 92 + 85 ^ (0xC7 ^ 0x9A) << " ".length()) << " ".length();
    llIIIllIIlIIII[16] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIIlIIII[17] = (0x10 ^ 0x2F ^ (0x28 ^ 0x33) << " ".length()) << " ".length();
    llIIIllIIlIIII[18] = "   ".length() << " ".length();
    llIIIllIIlIIII[19] = (0x3F ^ 0x18) << " ".length() << " ".length() ^ 46 + 110 - 122 + 139;
    llIIIllIIlIIII[20] = 152 + 139 - 266 + 218 ^ "   ".length() << "   ".length() << " ".length();
    llIIIllIIlIIII[21] = 0x3E ^ 0x1D ^ " ".length() << " ".length();
    llIIIllIIlIIII[22] = 0x45 ^ 0x4C;
    llIIIllIIlIIII[23] = (0x88 ^ 0x87) << " ".length();
    llIIIllIIlIIII[24] = 0xB9 ^ 0xB2;
    llIIIllIIlIIII[25] = "   ".length() << "   ".length();
    llIIIllIIlIIII[26] = "   ".length() << " ".length() << " ".length();
    llIIIllIIlIIII[27] = (0x7A ^ 0x41) << " ".length() ^ 0xD9 ^ 0x8A;
    llIIIllIIlIIII[28] = 0x81 ^ 0x8C;
    llIIIllIIlIIII[29] = 0x21 ^ 0x3C ^ "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIIlIIII[30] = ((0x13 ^ 0x1C) << " ".length() << " ".length() ^ 0xFC ^ 0xC7) << " ".length();
    llIIIllIIlIIII[31] = 0xE1 ^ 0xB6 ^ (0xA5 ^ 0x82) << " ".length();
    llIIIllIIlIIII[32] = 44 + 52 - 52 + 107 ^ (0xBB ^ 0xA8) << "   ".length();
    llIIIllIIlIIII[33] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIllIIlIIII[34] = (0x9A ^ 0x9D) << " ".length() << " ".length();
    llIIIllIIlIIII[35] = 0x1F ^ 0xE;
    llIIIllIIlIIII[36] = ((0x4 ^ 0x37) << " ".length() ^ 0xF5 ^ 0x9A) << " ".length() << " ".length();
    llIIIllIIlIIII[37] = ((0x75 ^ 0x70) << " ".length() ^ " ".length()) << " ".length();
    llIIIllIIlIIII[38] = (0x89 ^ 0x9A) << "   ".length() ^ 102 + 44 - 47 + 40;
    llIIIllIIlIIII[39] = (0x4F ^ 0x76 ^ (0x87 ^ 0x88) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIllIIlIIII[40] = " ".length() << " ".length() << " ".length() ^ 0x93 ^ 0x82;
    llIIIllIIlIIII[41] = (0x92 ^ 0x89) << " ".length() << " ".length() ^ 0xEE ^ 0xA9;
    llIIIllIIlIIII[42] = 0xE ^ 0x19;
    llIIIllIIlIIII[43] = 0xA7 ^ 0xBA;
    llIIIllIIlIIII[44] = ((0x49 ^ 0x58) << " ".length() << " ".length() ^ 0x37 ^ 0x64) << " ".length();
    llIIIllIIlIIII[45] = (0x3D ^ 0x30) << " ".length();
    llIIIllIIlIIII[46] = (0x29 ^ 0x38) << " ".length();
    llIIIllIIlIIII[47] = 0xB0 ^ 0xAB;
    llIIIllIIlIIII[48] = (0xBA ^ 0xB7) << " ".length() << " ".length();
    llIIIllIIlIIII[49] = (0x7F ^ 0x6E) << " ".length() << " ".length() ^ 0x21 ^ 0x7A;
    llIIIllIIlIIII[50] = " ".length() << (0x38 ^ 0x3D);
    llIIIllIIlIIII[51] = (0x6D ^ 0x38) << " ".length() ^ 70 + 49 - 32 + 50;
    llIIIllIIlIIII[52] = (0x7D ^ 0x7A) << " ".length() ^ 0xD ^ 0x2C;
    llIIIllIIlIIII[53] = (116 + 81 - 109 + 125 ^ (0xE3 ^ 0x80) << " ".length()) << " ".length();
    llIIIllIIlIIII[54] = 107 + 28 - 7 + 59 ^ (0x3B ^ 0x1C) << " ".length() << " ".length();
    llIIIllIIlIIII[55] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xBD ^ 0xA8) << "   ".length();
    llIIIllIIlIIII[56] = 0x6 ^ 0x2F;
    llIIIllIIlIIII[57] = ((0x8 ^ 0x19) << "   ".length() ^ 118 + 110 - 144 + 61) << " ".length();
    llIIIllIIlIIII[58] = (0x78 ^ 0x63) << " ".length();
  }
  
  private static boolean lIIIIlIIllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIllIIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 >= paramInt2);
  }
  
  private static boolean lIIIIlIIllIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIllIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIIllIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lIIIIlIIllIIIllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIlIIllIIlIll(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lIIIIlIIllIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  protected static class CharData {
    public int width;
    
    public int height;
    
    public int storedX;
    
    public int storedY;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f14.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */