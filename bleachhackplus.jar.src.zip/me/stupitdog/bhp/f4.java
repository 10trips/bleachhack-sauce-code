package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.InventoryPlayer;

public class f4 extends au {
  f100000000000000000000.Boolean switchBack;
  
  boolean shouldMoveBack;
  
  int lastSlot;
  
  long lastChange;
  
  @EventHandler
  private final Listener<fm> leftClickListener;
  
  private static String[] lIlllllIIIIllI;
  
  private static Class[] lIlllllIIIIlll;
  
  private static final String[] lIllllllIIllIl;
  
  private static String[] lIllllllIlIIII;
  
  private static final int[] lIllllllIlIIll;
  
  public f4() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f4.lIllllllIIllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f4.lIllllllIIllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f4.lIllllllIIllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   45: iconst_0
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f4;Z)V
    //   52: aload_0
    //   53: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   56: iconst_0
    //   57: iaload
    //   58: <illegal opcode> 2 : (Lme/stupitdog/bhp/f4;I)V
    //   63: aload_0
    //   64: lconst_0
    //   65: <illegal opcode> 3 : (Lme/stupitdog/bhp/f4;J)V
    //   70: aload_0
    //   71: new me/zero/alpine/listener/Listener
    //   74: dup
    //   75: aload_0
    //   76: <illegal opcode> invoke : (Lme/stupitdog/bhp/f4;)Lme/zero/alpine/listener/EventHook;
    //   81: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   84: iconst_0
    //   85: iaload
    //   86: anewarray java/util/function/Predicate
    //   89: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   92: putfield leftClickListener : Lme/zero/alpine/listener/Listener;
    //   95: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	96	0	lllllllllllllllIlllIIIIIIlIIlIIl	Lme/stupitdog/bhp/f4;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f4.lIllllllIIllIl : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   14: iconst_1
    //   15: iaload
    //   16: <illegal opcode> 4 : (Lme/stupitdog/bhp/f4;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   21: <illegal opcode> 5 : (Lme/stupitdog/bhp/f4;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   26: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	27	0	lllllllllllllllIlllIIIIIIlIIlIII	Lme/stupitdog/bhp/f4;
  }
  
  public void onUpdate() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lme/stupitdog/bhp/f4;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: invokestatic lIIIIIIIIlIlIIll : (I)Z
    //   14: ifeq -> 28
    //   17: aload_0
    //   18: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   21: iconst_0
    //   22: iaload
    //   23: <illegal opcode> 1 : (Lme/stupitdog/bhp/f4;Z)V
    //   28: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   38: invokestatic lIIIIIIIIlIlIlII : (Ljava/lang/Object;)Z
    //   41: ifeq -> 61
    //   44: aload_0
    //   45: <illegal opcode> 6 : (Lme/stupitdog/bhp/f4;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   50: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   55: invokestatic lIIIIIIIIlIlIIll : (I)Z
    //   58: ifeq -> 62
    //   61: return
    //   62: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   65: iconst_0
    //   66: iaload
    //   67: <illegal opcode> 10 : (I)Z
    //   72: istore_1
    //   73: iload_1
    //   74: invokestatic lIIIIIIIIlIlIllI : (I)Z
    //   77: ifeq -> 170
    //   80: aload_0
    //   81: <illegal opcode> 11 : (Lme/stupitdog/bhp/f4;)Z
    //   86: invokestatic lIIIIIIIIlIlIIll : (I)Z
    //   89: ifeq -> 170
    //   92: aload_0
    //   93: <illegal opcode> 12 : ()J
    //   98: <illegal opcode> 3 : (Lme/stupitdog/bhp/f4;J)V
    //   103: aload_0
    //   104: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   107: iconst_1
    //   108: iaload
    //   109: <illegal opcode> 1 : (Lme/stupitdog/bhp/f4;Z)V
    //   114: aload_0
    //   115: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   120: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   125: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   130: <illegal opcode> 15 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   135: <illegal opcode> 2 : (Lme/stupitdog/bhp/f4;I)V
    //   140: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   145: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   150: <illegal opcode> 17 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   155: ldc ''
    //   157: invokevirtual length : ()I
    //   160: pop
    //   161: ldc ' '
    //   163: invokevirtual length : ()I
    //   166: ifgt -> 239
    //   169: return
    //   170: iload_1
    //   171: invokestatic lIIIIIIIIlIlIIll : (I)Z
    //   174: ifeq -> 239
    //   177: aload_0
    //   178: <illegal opcode> 11 : (Lme/stupitdog/bhp/f4;)Z
    //   183: invokestatic lIIIIIIIIlIlIllI : (I)Z
    //   186: ifeq -> 239
    //   189: aload_0
    //   190: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   193: iconst_0
    //   194: iaload
    //   195: <illegal opcode> 1 : (Lme/stupitdog/bhp/f4;Z)V
    //   200: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   205: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   210: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   215: aload_0
    //   216: <illegal opcode> 18 : (Lme/stupitdog/bhp/f4;)I
    //   221: putfield field_70461_c : I
    //   224: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   229: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   234: <illegal opcode> 17 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   239: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	240	0	lllllllllllllllIlllIIIIIIlIIIlll	Lme/stupitdog/bhp/f4;
    //   73	167	1	lllllllllllllllIlllIIIIIIlIIIllI	Z
  }
  
  private void equipBestTool(IBlockState lllllllllllllllIlllIIIIIIlIIIIII) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   3: iconst_4
    //   4: iaload
    //   5: istore_2
    //   6: dconst_0
    //   7: dstore_3
    //   8: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   11: iconst_0
    //   12: iaload
    //   13: istore #5
    //   15: iload #5
    //   17: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   20: iconst_5
    //   21: iaload
    //   22: invokestatic lIIIIIIIIlIllIIl : (II)Z
    //   25: ifeq -> 228
    //   28: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   38: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   43: iload #5
    //   45: <illegal opcode> 19 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   50: astore #6
    //   52: aload #6
    //   54: <illegal opcode> 20 : (Lnet/minecraft/item/ItemStack;)Z
    //   59: invokestatic lIIIIIIIIlIlIllI : (I)Z
    //   62: ifeq -> 100
    //   65: ldc ''
    //   67: invokevirtual length : ()I
    //   70: pop
    //   71: bipush #123
    //   73: bipush #118
    //   75: ixor
    //   76: ldc ' '
    //   78: invokevirtual length : ()I
    //   81: ishl
    //   82: bipush #53
    //   84: bipush #56
    //   86: ixor
    //   87: ldc ' '
    //   89: invokevirtual length : ()I
    //   92: ishl
    //   93: iconst_m1
    //   94: ixor
    //   95: iand
    //   96: ifeq -> 209
    //   99: return
    //   100: aload #6
    //   102: aload_1
    //   103: <illegal opcode> 21 : (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F
    //   108: fstore #7
    //   110: fload #7
    //   112: fconst_1
    //   113: invokestatic lIIIIIIIIlIlIlll : (FF)I
    //   116: invokestatic lIIIIIIIIlIllIlI : (I)Z
    //   119: ifeq -> 209
    //   122: fload #7
    //   124: f2d
    //   125: <illegal opcode> 22 : ()Lnet/minecraft/enchantment/Enchantment;
    //   130: aload #6
    //   132: <illegal opcode> 23 : (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I
    //   137: dup
    //   138: istore #8
    //   140: invokestatic lIIIIIIIIlIllIlI : (I)Z
    //   143: ifeq -> 184
    //   146: iload #8
    //   148: i2d
    //   149: ldc2_w 2.0
    //   152: <illegal opcode> 24 : (DD)D
    //   157: dconst_1
    //   158: dadd
    //   159: ldc ''
    //   161: invokevirtual length : ()I
    //   164: pop
    //   165: bipush #69
    //   167: bipush #110
    //   169: ixor
    //   170: sipush #130
    //   173: sipush #169
    //   176: ixor
    //   177: iconst_m1
    //   178: ixor
    //   179: iand
    //   180: ifeq -> 185
    //   183: return
    //   184: dconst_0
    //   185: dadd
    //   186: d2f
    //   187: fstore #7
    //   189: fload #7
    //   191: f2d
    //   192: dload_3
    //   193: invokestatic lIIIIIIIIlIllIII : (DD)I
    //   196: invokestatic lIIIIIIIIlIllIlI : (I)Z
    //   199: ifeq -> 209
    //   202: fload #7
    //   204: f2d
    //   205: dstore_3
    //   206: iload #5
    //   208: istore_2
    //   209: iinc #5, 1
    //   212: ldc ''
    //   214: invokevirtual length : ()I
    //   217: pop
    //   218: ldc '   '
    //   220: invokevirtual length : ()I
    //   223: ineg
    //   224: ifle -> 15
    //   227: return
    //   228: iload_2
    //   229: getstatic me/stupitdog/bhp/f4.lIllllllIlIIll : [I
    //   232: iconst_4
    //   233: iaload
    //   234: invokestatic lIIIIIIIIlIllIll : (II)Z
    //   237: ifeq -> 246
    //   240: iload_2
    //   241: <illegal opcode> 25 : (I)V
    //   246: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   52	157	6	lllllllllllllllIlllIIIIIIlIIIlIl	Lnet/minecraft/item/ItemStack;
    //   110	99	7	lllllllllllllllIlllIIIIIIlIIIlII	F
    //   140	69	8	lllllllllllllllIlllIIIIIIlIIIIll	I
    //   15	213	5	lllllllllllllllIlllIIIIIIlIIIIlI	I
    //   0	247	0	lllllllllllllllIlllIIIIIIlIIIIIl	Lme/stupitdog/bhp/f4;
    //   0	247	1	lllllllllllllllIlllIIIIIIlIIIIII	Lnet/minecraft/block/state/IBlockState;
    //   6	241	2	lllllllllllllllIlllIIIIIIIllllll	I
    //   8	239	3	lllllllllllllllIlllIIIIIIIlllllI	D
  }
  
  private static void equip(int lllllllllllllllIlllIIIIIIIllllIl) {
    // Byte code:
    //   0: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 13 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   15: iload_0
    //   16: putfield field_70461_c : I
    //   19: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   24: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   29: <illegal opcode> 17 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;)V
    //   34: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	35	0	lllllllllllllllIlllIIIIIIIllllIl	I
  }
  
  static {
    lIIIIIIIIlIlIIlI();
    lIIIIIIIIlIIlIll();
    lIIIIIIIIlIIlIlI();
    lIIIIIIIIIlllllI();
  }
  
  private static CallSite llllllllIIIIlII(MethodHandles.Lookup lllllllllllllllIlllIIIIIIIllIIlI, String lllllllllllllllIlllIIIIIIIllIIIl, MethodType lllllllllllllllIlllIIIIIIIllIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIIIIIlllIII = lIlllllIIIIllI[Integer.parseInt(lllllllllllllllIlllIIIIIIIllIIIl)].split(lIllllllIIllIl[lIllllllIlIIll[6]]);
      Class<?> lllllllllllllllIlllIIIIIIIllIlll = Class.forName(lllllllllllllllIlllIIIIIIIlllIII[lIllllllIlIIll[0]]);
      String lllllllllllllllIlllIIIIIIIllIllI = lllllllllllllllIlllIIIIIIIlllIII[lIllllllIlIIll[1]];
      MethodHandle lllllllllllllllIlllIIIIIIIllIlIl = null;
      int lllllllllllllllIlllIIIIIIIllIlII = lllllllllllllllIlllIIIIIIIlllIII[lIllllllIlIIll[3]].length();
      if (lIIIIIIIIlIlllII(lllllllllllllllIlllIIIIIIIllIlII, lIllllllIlIIll[2])) {
        MethodType lllllllllllllllIlllIIIIIIIlllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIIIIIlllIII[lIllllllIlIIll[2]], f4.class.getClassLoader());
        if (lIIIIIIIIlIlllIl(lllllllllllllllIlllIIIIIIIllIlII, lIllllllIlIIll[2])) {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findVirtual(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findStatic(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIlI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIIIIIlllIIl = lIlllllIIIIlll[Integer.parseInt(lllllllllllllllIlllIIIIIIIlllIII[lIllllllIlIIll[2]])];
        if (lIIIIIIIIlIlllIl(lllllllllllllllIlllIIIIIIIllIlII, lIllllllIlIIll[3])) {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findGetter(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIIIlIlllIl(lllllllllllllllIlllIIIIIIIllIlII, lIllllllIlIIll[6])) {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findStaticGetter(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIIl);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else if (lIIIIIIIIlIlllIl(lllllllllllllllIlllIIIIIIIllIlII, lIllllllIlIIll[7])) {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findSetter(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIIl);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIIllIlIl = lllllllllllllllIlllIIIIIIIllIIlI.findStaticSetter(lllllllllllllllIlllIIIIIIIllIlll, lllllllllllllllIlllIIIIIIIllIllI, lllllllllllllllIlllIIIIIIIlllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIIIIIllIlIl);
    } catch (Exception lllllllllllllllIlllIIIIIIIllIIll) {
      lllllllllllllllIlllIIIIIIIllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIIlllllI() {
    lIlllllIIIIllI = new String[lIllllllIlIIll[8]];
    lIlllllIIIIllI[lIllllllIlIIll[9]] = lIllllllIIllIl[lIllllllIlIIll[7]];
    lIlllllIIIIllI[lIllllllIlIIll[7]] = lIllllllIIllIl[lIllllllIlIIll[10]];
    lIlllllIIIIllI[lIllllllIlIIll[11]] = lIllllllIIllIl[lIllllllIlIIll[12]];
    lIlllllIIIIllI[lIllllllIlIIll[13]] = lIllllllIIllIl[lIllllllIlIIll[14]];
    lIlllllIIIIllI[lIllllllIlIIll[0]] = lIllllllIIllIl[lIllllllIlIIll[5]];
    lIlllllIIIIllI[lIllllllIlIIll[15]] = lIllllllIIllIl[lIllllllIlIIll[16]];
    lIlllllIIIIllI[lIllllllIlIIll[17]] = lIllllllIIllIl[lIllllllIlIIll[18]];
    lIlllllIIIIllI[lIllllllIlIIll[19]] = lIllllllIIllIl[lIllllllIlIIll[20]];
    lIlllllIIIIllI[lIllllllIlIIll[20]] = lIllllllIIllIl[lIllllllIlIIll[21]];
    lIlllllIIIIllI[lIllllllIlIIll[22]] = lIllllllIIllIl[lIllllllIlIIll[23]];
    lIlllllIIIIllI[lIllllllIlIIll[10]] = lIllllllIIllIl[lIllllllIlIIll[24]];
    lIlllllIIIIllI[lIllllllIlIIll[25]] = lIllllllIIllIl[lIllllllIlIIll[13]];
    lIlllllIIIIllI[lIllllllIlIIll[3]] = lIllllllIIllIl[lIllllllIlIIll[22]];
    lIlllllIIIIllI[lIllllllIlIIll[12]] = lIllllllIIllIl[lIllllllIlIIll[9]];
    lIlllllIIIIllI[lIllllllIlIIll[26]] = lIllllllIIllIl[lIllllllIlIIll[26]];
    lIlllllIIIIllI[lIllllllIlIIll[24]] = lIllllllIIllIl[lIllllllIlIIll[27]];
    lIlllllIIIIllI[lIllllllIlIIll[16]] = lIllllllIIllIl[lIllllllIlIIll[17]];
    lIlllllIIIIllI[lIllllllIlIIll[27]] = lIllllllIIllIl[lIllllllIlIIll[28]];
    lIlllllIIIIllI[lIllllllIlIIll[28]] = lIllllllIIllIl[lIllllllIlIIll[29]];
    lIlllllIIIIllI[lIllllllIlIIll[23]] = lIllllllIIllIl[lIllllllIlIIll[19]];
    lIlllllIIIIllI[lIllllllIlIIll[21]] = lIllllllIIllIl[lIllllllIlIIll[25]];
    lIlllllIIIIllI[lIllllllIlIIll[30]] = lIllllllIIllIl[lIllllllIlIIll[11]];
    lIlllllIIIIllI[lIllllllIlIIll[2]] = lIllllllIIllIl[lIllllllIlIIll[30]];
    lIlllllIIIIllI[lIllllllIlIIll[18]] = lIllllllIIllIl[lIllllllIlIIll[15]];
    lIlllllIIIIllI[lIllllllIlIIll[5]] = lIllllllIIllIl[lIllllllIlIIll[8]];
    lIlllllIIIIllI[lIllllllIlIIll[6]] = lIllllllIIllIl[lIllllllIlIIll[31]];
    lIlllllIIIIllI[lIllllllIlIIll[14]] = lIllllllIIllIl[lIllllllIlIIll[32]];
    lIlllllIIIIllI[lIllllllIlIIll[29]] = lIllllllIIllIl[lIllllllIlIIll[33]];
    lIlllllIIIIllI[lIllllllIlIIll[1]] = lIllllllIIllIl[lIllllllIlIIll[34]];
    lIlllllIIIIlll = new Class[lIllllllIlIIll[21]];
    lIlllllIIIIlll[lIllllllIlIIll[6]] = Listener.class;
    lIlllllIIIIlll[lIllllllIlIIll[1]] = boolean.class;
    lIlllllIIIIlll[lIllllllIlIIll[14]] = EntityPlayerSP.class;
    lIlllllIIIIlll[lIllllllIlIIll[10]] = Minecraft.class;
    lIlllllIIIIlll[lIllllllIlIIll[2]] = int.class;
    lIlllllIIIIlll[lIllllllIlIIll[5]] = InventoryPlayer.class;
    lIlllllIIIIlll[lIllllllIlIIll[16]] = PlayerControllerMP.class;
    lIlllllIIIIlll[lIllllllIlIIll[18]] = Enchantment.class;
    lIlllllIIIIlll[lIllllllIlIIll[20]] = WorldClient.class;
    lIlllllIIIIlll[lIllllllIlIIll[3]] = long.class;
    lIlllllIIIIlll[lIllllllIlIIll[0]] = f13.class;
    lIlllllIIIIlll[lIllllllIlIIll[7]] = f100000000000000000000.Boolean.class;
    lIlllllIIIIlll[lIllllllIlIIll[12]] = GuiScreen.class;
  }
  
  private static void lIIIIIIIIlIIlIlI() {
    lIllllllIIllIl = new String[lIllllllIlIIll[35]];
    lIllllllIIllIl[lIllllllIlIIll[0]] = lIIIIIIIIIllllll(lIllllllIlIIII[lIllllllIlIIll[0]], lIllllllIlIIII[lIllllllIlIIll[1]]);
    lIllllllIIllIl[lIllllllIlIIll[1]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[2]], lIllllllIlIIII[lIllllllIlIIll[3]]);
    lIllllllIIllIl[lIllllllIlIIll[2]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[6]], lIllllllIlIIII[lIllllllIlIIll[7]]);
    lIllllllIIllIl[lIllllllIlIIll[3]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[10]], lIllllllIlIIII[lIllllllIlIIll[12]]);
    lIllllllIIllIl[lIllllllIlIIll[6]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[14]], lIllllllIlIIII[lIllllllIlIIll[5]]);
    lIllllllIIllIl[lIllllllIlIIll[7]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[16]], lIllllllIlIIII[lIllllllIlIIll[18]]);
    lIllllllIIllIl[lIllllllIlIIll[10]] = lIIIIIIIIlIIIIII(lIllllllIlIIII[lIllllllIlIIll[20]], lIllllllIlIIII[lIllllllIlIIll[21]]);
    lIllllllIIllIl[lIllllllIlIIll[12]] = lIIIIIIIIlIIIIIl(lIllllllIlIIII[lIllllllIlIIll[23]], lIllllllIlIIII[lIllllllIlIIll[24]]);
    lIllllllIIllIl[lIllllllIlIIll[14]] = lIIIIIIIIIllllll(lIllllllIlIIII[lIllllllIlIIll[13]], lIllllllIlIIII[lIllllllIlIIll[22]]);
    lIllllllIIllIl[lIllllllIlIIll[5]] = lIIIIIIIIlIIIIIl(lIllllllIlIIII[lIllllllIlIIll[9]], lIllllllIlIIII[lIllllllIlIIll[26]]);
    lIllllllIIllIl[lIllllllIlIIll[16]] = lIIIIIIIIIllllll("QOiN+d98TparIbnY3BXmwOv+jK95aEwu5nXfsdjKcYjaYVs76FYF5jolj+oTwUwadYNvBpGqZaCl/V0Bsy8RnLDsE+G/qRcEpWVFwiXgkEvx5i6RHE6AmRDIH7cLpUG269gBhXSyHvz8jjHF7lHFepu739tPKolZjq9zi+q6GExsrF8SSKUlaGn0C3RmNlP8", "QFJlE");
    lIllllllIIllIl[lIllllllIlIIll[18]] = lIIIIIIIIlIIIIIl("hcCnHs5xzOAWNElToyGm4xkDylmCsimdYabi4l3VkSklRMTH+JrRLJr5hCKmZv/yN8WOmgxRbOUjSLMWeUbjhEA0pyTZm0+rGm+8+4voXUZv9eTmbkAzpeEllGLcdzsX", "WxRgl");
    lIllllllIIllIl[lIllllllIlIIll[20]] = lIIIIIIIIlIIIIII("GAoxCnweCikMfD8KMwNoAgQwUXo2L24vaFI=", "rkGkR");
    lIllllllIIllIl[lIllllllIlIIll[21]] = lIIIIIIIIlIIIIII("Hgs3OHoYCy8+eicTMi0xGVAiLCYGDy8tAB0HJBQ9GAYoKm5cQwtjdA==", "tjAYT");
    lIllllllIIllIl[lIllllllIlIIll[23]] = lIIIIIIIIlIIIIIl("EhDWfuYeZFc0KottnDfZWoo3mZy0L/y5CrZddXuYJxaUsO8tM3Wf7Lgef/3gZ/fjvJxxTkOUV81Eekl1T/l2ysO5N+coDG2F", "AAxPg");
    lIllllllIIllIl[lIllllllIlIIll[24]] = lIIIIIIIIlIIIIIl("FRUOpRbAtaW007pJJdWDKZp0hG1SVwpO+jQEFEd/aYQsq4bEPOswGQ==", "iQVst");
    lIllllllIIllIl[lIllllllIlIIll[13]] = lIIIIIIIIlIIIIII("JwxZPDY/GR47JiUOWS0qOkcRe3gvGAImMnBBPmYUcEk=", "JiwOB");
    lIllllllIIllIl[lIllllllIlIIll[22]] = lIIIIIIIIlIIIIII("OBdGNRogAgEyCjoVRiQGJVwOclQ5ExsyLT0TBiELb0FSZk51Ukg=", "UrhFn");
    lIllllllIIllIl[lIllllllIlIIll[9]] = lIIIIIIIIlIIIIII("KCddFB4wMhoTDiolXQUCNWwVVlp1ckNXWnVyQ1dadXJDV1p1ckNXTgctHAsPJCxJAA8xFBILHyB4W04wf2JT", "EBsgj");
    lIllllllIIllIl[lIllllllIlIIll[26]] = lIIIIIIIIlIIIIIl("/MrZzUViBe21iEvDY+i1OcEybjKfYcPR6rIAdkAp369fhdIEQ7VspjNnuUYjhqjQsLDnCGhi0JoybzVkKgRZQzOAir/w+ZQrnEpeeb3QRzTvnYllWE2Dz7yk8v+oMOuu", "BYTEq");
    lIllllllIIllIl[lIllllllIlIIll[27]] = lIIIIIIIIIllllll("kN4ROctp65C7hDLfu/++Flbjq5iUbpQNziji/zEoaiuqtORx8hOJ6CF/VgzklxWypjcCV18UtHBm3XTcOsW8rw==", "ZMChi");
    lIllllllIIllIl[lIllllllIlIIll[17]] = lIIIIIIIIlIIIIII("KzMuVBszKy4WWS0vOQ8DagwmDwQheyAJNTE1PRUZAC4+FE1sCGAgTWQ=", "DAIzw");
    lIllllllIIllIl[lIllllllIlIIll[28]] = lIIIIIIIIlIIIIII("NCQNaAgzLxwlFzsnDWgMLiQUaCwuJBQVETsiEnwDLy8aGVRjcUB0UwUjQ25MAHtZZg==", "ZAyFe");
    lIllllllIIllIl[lIllllllIlIIll[29]] = lIIIIIIIIlIIIIIl("/hPM7jgkDKXiAjBoGl0GL5NT14knYt1yI9C4kz514yymvRUc9AkVCfEi/cD2a70vLwH3GqGE8ZU=", "szQJl");
    lIllllllIIllIl[lIllllllIlIIll[19]] = lIIIIIIIIlIIIIIl("9pAVGIRt4s4h0tzs47Qd4dzmEmYZRbi9+/ZRBZWQ7vg9IZ0fWoTCHrH2XH7VTYq6HwKCR+HNoJmuD1EM3XuqLA==", "HCohH");
    lIllllllIIllIl[lIllllllIlIIll[25]] = lIIIIIIIIlIIIIII("IwkMQgYkAh0PGSwKDEIIIQUdAh9jIRECDi4eGQofdwoRCQcpM09dX35VJwtRdVZYTEs=", "Mlxlk");
    lIllllllIIllIl[lIllllllIlIIll[11]] = lIIIIIIIIlIIIIII("JgprFRM+HywSAyQIawQPO0EjC10sCjEkCyQMLjYIOFVtTyslCjFJCiIBIAUVKgkxSRI/BilJCiobLUklJwAmDTckHH5cR2s=", "KoEfg");
    lIllllllIIllIl[lIllllllIlIIll[30]] = lIIIIIIIIlIIIIII("IDdeIjY4IhklJiI1XjMqPXwWZXghMwMlESE9BGtwd3JQcWJt", "MRpQB");
    lIllllllIIllIl[lIllllllIlIIll[15]] = lIIIIIIIIlIIIIIl("Dli9pyiDs6sPHLTag/B6wZNtZHm3eSpv7sAs3eLTH6WpZYC5ImWVyZh4WokfRDsi", "oEAiP");
    lIllllllIIllIl[lIllllllIlIIll[8]] = lIIIIIIIIIllllll("6vRv4ack4oapCImrnnJ/+qXwYDIKpB6tWt93/J5lVXmmDaYshxShy8F7wQX1ViE3SzgKwYR1FoU=", "ffQjK");
    lIllllllIIllIl[lIllllllIlIIll[31]] = lIIIIIIIIlIIIIIl("yvEc4zCIRN8X+XlZWAqjEZAjTXybMTBuB2SOhJC7ePwKC8+5BC6VLv6lbTIkxVD/eOXNMLq+UzCt8TakNzD/3Ybzmd0LDxhVuloE5SpdgA/ADlEbE/nsoMAOURsT+eygQoTsrXDfvbd/ab0lBKmx8g==", "ABRYK");
    lIllllllIIllIl[lIllllllIlIIll[32]] = lIIIIIIIIIllllll("Kge7jozol7xzFBXzxT1OLCHrizk1qqdyxOVdBI9Shz8=", "hWcCX");
    lIllllllIIllIl[lIllllllIlIIll[33]] = lIIIIIIIIIllllll("A9lfAeik/lMmYwGt2GHYBNu2qfWb1409img9SdTcl2YqwXFehq++YRwU0X87IoypM9MyraWH0NtS8G8hixgEd8f4ihYcX5a+whjW7sBv7sO4wazb5vLQ2GuPmdtqs+hlF3POhkYRDxNkeip0Nr1C0bpNmJaprRA7vAdlo6lxSrQZ+lySxUTNCQ==", "SKsdw");
    lIllllllIIllIl[lIllllllIlIIll[34]] = lIIIIIIIIlIIIIIl("gXVVhpnpxWrqxcAWou+MvIHzgt06LG5l264vVtcv4zZzZ1RRpXGDnKkfu+k6+KwP", "PtsJD");
    lIllllllIlIIII = null;
  }
  
  private static void lIIIIIIIIlIIlIll() {
    String str = (new Exception()).getStackTrace()[lIllllllIlIIll[0]].getFileName();
    lIllllllIlIIII = str.substring(str.indexOf("ä") + lIllllllIlIIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIIIllllll(String lllllllllllllllIlllIIIIIIIlIllII, String lllllllllllllllIlllIIIIIIIlIlIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIIlIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIIlIlIll.getBytes(StandardCharsets.UTF_8)), lIllllllIlIIll[14]), "DES");
      Cipher lllllllllllllllIlllIIIIIIIlIlllI = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIIIIIlIlllI.init(lIllllllIlIIll[2], lllllllllllllllIlllIIIIIIIlIllll);
      return new String(lllllllllllllllIlllIIIIIIIlIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIlIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIIlIllIl) {
      lllllllllllllllIlllIIIIIIIlIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIlIIIIIl(String lllllllllllllllIlllIIIIIIIlIIlll, String lllllllllllllllIlllIIIIIIIlIIllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIIlIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIIlIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIIIIIlIlIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIIIIIlIlIIl.init(lIllllllIlIIll[2], lllllllllllllllIlllIIIIIIIlIlIlI);
      return new String(lllllllllllllllIlllIIIIIIIlIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIlIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIIlIlIII) {
      lllllllllllllllIlllIIIIIIIlIlIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIlIIIIII(String lllllllllllllllIlllIIIIIIIlIIlII, String lllllllllllllllIlllIIIIIIIlIIIll) {
    lllllllllllllllIlllIIIIIIIlIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIIIIIlIIIlI = new StringBuilder();
    char[] lllllllllllllllIlllIIIIIIIlIIIIl = lllllllllllllllIlllIIIIIIIlIIIll.toCharArray();
    int lllllllllllllllIlllIIIIIIIlIIIII = lIllllllIlIIll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIIIIIlIIlII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllllIlIIll[0];
    while (lIIIIIIIIlIllIIl(j, i)) {
      char lllllllllllllllIlllIIIIIIIlIIlIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIIIIIlIIIII++;
      j++;
      "".length();
      if ("   ".length() == " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIIIIIlIIIlI);
  }
  
  private static void lIIIIIIIIlIlIIlI() {
    lIllllllIlIIll = new int[36];
    lIllllllIlIIll[0] = (189 + 165 - 261 + 104 ^ "   ".length() << "   ".length() << " ".length()) << " ".length() & ((0x84 ^ 0xC5 ^ (0x98 ^ 0x89) << " ".length() << " ".length()) << " ".length() ^ -" ".length());
    lIllllllIlIIll[1] = " ".length();
    lIllllllIlIIll[2] = " ".length() << " ".length();
    lIllllllIlIIll[3] = "   ".length();
    lIllllllIlIIll[4] = -" ".length();
    lIllllllIlIIll[5] = 69 + 172 - 125 + 57 ^ (0x32 ^ 0x1B) << " ".length() << " ".length();
    lIllllllIlIIll[6] = " ".length() << " ".length() << " ".length();
    lIllllllIlIIll[7] = 0x89 ^ 0x8C;
    lIllllllIlIIll[8] = 0xFC ^ 0xA1 ^ " ".length() << "   ".length() << " ".length();
    lIllllllIlIIll[9] = (0x16 ^ 0x1F) << " ".length();
    lIllllllIlIIll[10] = "   ".length() << " ".length();
    lIllllllIlIIll[11] = (0xF7 ^ 0xC2 ^ (0x8C ^ 0x8B) << "   ".length()) << " ".length();
    lIllllllIlIIll[12] = 0xC3 ^ 0xC4;
    lIllllllIlIIll[13] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllllIlIIll[14] = " ".length() << "   ".length();
    lIllllllIlIIll[15] = (0xED ^ 0x94 ^ (0xB6 ^ 0x89) << " ".length()) << " ".length() << " ".length();
    lIllllllIlIIll[16] = (0x26 ^ 0x23) << " ".length();
    lIllllllIlIIll[17] = 0xAF ^ 0x90 ^ (0x21 ^ 0x34) << " ".length();
    lIllllllIlIIll[18] = 0x96 ^ 0x9D;
    lIllllllIlIIll[19] = "   ".length() << "   ".length();
    lIllllllIlIIll[20] = "   ".length() << " ".length() << " ".length();
    lIllllllIlIIll[21] = (0x34 ^ 0x17) << " ".length() << " ".length() ^ 31 + 27 - -16 + 55;
    lIllllllIlIIll[22] = (0x37 ^ 0xA) << " ".length() ^ 0xF ^ 0x64;
    lIllllllIlIIll[23] = ((0x54 ^ 0x45) << "   ".length() ^ 123 + 9 - 30 + 41) << " ".length();
    lIllllllIlIIll[24] = (0x28 ^ 0x21) << " ".length() ^ 0xB2 ^ 0xAF;
    lIllllllIlIIll[25] = 0xA1 ^ 0xB8;
    lIllllllIlIIll[26] = 0xB8 ^ 0xAB;
    lIllllllIlIIll[27] = (0x2C ^ 0x29) << " ".length() << " ".length();
    lIllllllIlIIll[28] = (0x6F ^ 0x64) << " ".length();
    lIllllllIlIIll[29] = 0x39 ^ 0x2E;
    lIllllllIlIIll[30] = 0x3D ^ 0x26;
    lIllllllIlIIll[31] = (0x92 ^ 0x9D) << " ".length();
    lIllllllIlIIll[32] = 0x65 ^ 0x7A;
    lIllllllIlIIll[33] = " ".length() << (0x66 ^ 0x63);
    lIllllllIlIIll[34] = 0x14 ^ 0x35;
    lIllllllIlIIll[35] = (0x68 ^ 0x79) << " ".length();
  }
  
  private static boolean lIIIIIIIIlIlllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIIlIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIIlIlllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIIlIlIlII(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIIIIlIlIllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIIIlIlIIll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIIIlIllIlI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static boolean lIIIIIIIIlIllIll(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIIIIIlIlIlll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIIIIlIllIII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */