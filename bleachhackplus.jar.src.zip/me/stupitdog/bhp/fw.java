package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public class fw {
  private static final Minecraft mc;
  
  private static String[] lIllIllIIllIIl;
  
  private static Class[] lIllIllIIllIlI;
  
  private static final String[] lIllIllIlIIlII;
  
  private static String[] lIllIllIlIIlIl;
  
  private static final int[] lIllIllIlIIllI;
  
  public static float drawStringWithShadow(String lllllllllllllllIllllIIllIIIlIIII, float lllllllllllllllIllllIIllIIIIllll, float lllllllllllllllIllllIIllIIIIlllI, f01 lllllllllllllllIllllIIllIIIIllIl) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Z
    //   5: invokestatic llllIlIlIlllIII : (I)Z
    //   8: ifeq -> 33
    //   11: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   16: <illegal opcode> 2 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/fa;
    //   21: aload_0
    //   22: fload_1
    //   23: f2d
    //   24: fload_2
    //   25: f2d
    //   26: aload_3
    //   27: <illegal opcode> 3 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;DDLme/stupitdog/bhp/f01;)F
    //   32: freturn
    //   33: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   38: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   43: aload_0
    //   44: fload_1
    //   45: fload_2
    //   46: aload_3
    //   47: <illegal opcode> 6 : (Lme/stupitdog/bhp/f01;)I
    //   52: <illegal opcode> 7 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   57: i2f
    //   58: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	59	0	lllllllllllllllIllllIIllIIIlIIII	Ljava/lang/String;
    //   0	59	1	lllllllllllllllIllllIIllIIIIllll	F
    //   0	59	2	lllllllllllllllIllllIIllIIIIlllI	F
    //   0	59	3	lllllllllllllllIllllIIllIIIIllIl	Lme/stupitdog/bhp/f01;
  }
  
  public static int getStringWidth(String lllllllllllllllIllllIIllIIIIllII) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()Z
    //   5: invokestatic llllIlIlIlllIII : (I)Z
    //   8: ifeq -> 28
    //   11: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   16: <illegal opcode> 2 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/fa;
    //   21: aload_0
    //   22: <illegal opcode> 8 : (Lme/stupitdog/bhp/fa;Ljava/lang/String;)I
    //   27: ireturn
    //   28: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   38: aload_0
    //   39: <illegal opcode> 9 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;)I
    //   44: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	45	0	lllllllllllllllIllllIIllIIIIllII	Ljava/lang/String;
  }
  
  public static int getFontHeight() {
    // Byte code:
    //   0: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   10: <illegal opcode> 10 : (Lnet/minecraft/client/gui/FontRenderer;)I
    //   15: ireturn
  }
  
  public static boolean customFont() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   5: <illegal opcode> 11 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   10: getstatic me/stupitdog/bhp/fw.lIllIllIlIIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fw.lIllIllIlIIllI : [I
    //   16: iconst_0
    //   17: iaload
    //   18: aaload
    //   19: <illegal opcode> 12 : (Lme/stupitdog/bhp/av;Ljava/lang/String;)Lme/stupitdog/bhp/au;
    //   24: <illegal opcode> 13 : (Lme/stupitdog/bhp/au;)Z
    //   29: ireturn
    //   30: astore_0
    //   31: getstatic me/stupitdog/bhp/fw.lIllIllIlIIllI : [I
    //   34: iconst_0
    //   35: iaload
    //   36: ireturn
    // Exception table:
    //   from	to	target	type
    //   0	29	30	java/lang/Exception
  }
  
  static {
    // Byte code:
    //   0: invokestatic llllIlIlIllIlll : ()V
    //   3: invokestatic llllIlIlIllIllI : ()V
    //   6: invokestatic llllIlIlIllIlIl : ()V
    //   9: invokestatic llllIlIlIllIIIl : ()V
    //   12: <illegal opcode> 14 : ()Lnet/minecraft/client/Minecraft;
    //   17: putstatic me/stupitdog/bhp/fw.mc : Lnet/minecraft/client/Minecraft;
    //   20: return
  }
  
  private static CallSite llllIlIlIIIIIll(MethodHandles.Lookup lllllllllllllllIllllIIllIIIIIIll, String lllllllllllllllIllllIIllIIIIIIlI, MethodType lllllllllllllllIllllIIllIIIIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIllIIIIlIIl = lIllIllIIllIIl[Integer.parseInt(lllllllllllllllIllllIIllIIIIIIlI)].split(lIllIllIlIIlII[lIllIllIlIIllI[1]]);
      Class<?> lllllllllllllllIllllIIllIIIIlIII = Class.forName(lllllllllllllllIllllIIllIIIIlIIl[lIllIllIlIIllI[0]]);
      String lllllllllllllllIllllIIllIIIIIlll = lllllllllllllllIllllIIllIIIIlIIl[lIllIllIlIIllI[1]];
      MethodHandle lllllllllllllllIllllIIllIIIIIllI = null;
      int lllllllllllllllIllllIIllIIIIIlIl = lllllllllllllllIllllIIllIIIIlIIl[lIllIllIlIIllI[2]].length();
      if (llllIlIlIlllIIl(lllllllllllllllIllllIIllIIIIIlIl, lIllIllIlIIllI[3])) {
        MethodType lllllllllllllllIllllIIllIIIIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIllIIIIlIIl[lIllIllIlIIllI[3]], fw.class.getClassLoader());
        if (llllIlIlIlllIlI(lllllllllllllllIllllIIllIIIIIlIl, lIllIllIlIIllI[3])) {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findVirtual(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIll);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findStatic(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIll);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIllIIIIlIlI = lIllIllIIllIlI[Integer.parseInt(lllllllllllllllIllllIIllIIIIlIIl[lIllIllIlIIllI[3]])];
        if (llllIlIlIlllIlI(lllllllllllllllIllllIIllIIIIIlIl, lIllIllIlIIllI[2])) {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findGetter(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIlI);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else if (llllIlIlIlllIlI(lllllllllllllllIllllIIllIIIIIlIl, lIllIllIlIIllI[4])) {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findStaticGetter(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIlI);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else if (llllIlIlIlllIlI(lllllllllllllllIllllIIllIIIIIlIl, lIllIllIlIIllI[5])) {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findSetter(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIlI);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllllIIllIIIIIllI = lllllllllllllllIllllIIllIIIIIIll.findStaticSetter(lllllllllllllllIllllIIllIIIIlIII, lllllllllllllllIllllIIllIIIIIlll, lllllllllllllllIllllIIllIIIIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIllIIIIIllI);
    } catch (Exception lllllllllllllllIllllIIllIIIIIlII) {
      lllllllllllllllIllllIIllIIIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIlIllIIIl() {
    lIllIllIIllIIl = new String[lIllIllIlIIllI[6]];
    lIllIllIIllIIl[lIllIllIlIIllI[3]] = lIllIllIlIIlII[lIllIllIlIIllI[3]];
    lIllIllIIllIIl[lIllIllIlIIllI[5]] = lIllIllIlIIlII[lIllIllIlIIllI[2]];
    lIllIllIIllIIl[lIllIllIlIIllI[4]] = lIllIllIlIIlII[lIllIllIlIIllI[4]];
    lIllIllIIllIIl[lIllIllIlIIllI[7]] = lIllIllIlIIlII[lIllIllIlIIllI[5]];
    lIllIllIIllIIl[lIllIllIlIIllI[8]] = lIllIllIlIIlII[lIllIllIlIIllI[7]];
    lIllIllIIllIIl[lIllIllIlIIllI[9]] = lIllIllIlIIlII[lIllIllIlIIllI[10]];
    lIllIllIIllIIl[lIllIllIlIIllI[1]] = lIllIllIlIIlII[lIllIllIlIIllI[11]];
    lIllIllIIllIIl[lIllIllIlIIllI[12]] = lIllIllIlIIlII[lIllIllIlIIllI[13]];
    lIllIllIIllIIl[lIllIllIlIIllI[14]] = lIllIllIlIIlII[lIllIllIlIIllI[14]];
    lIllIllIIllIIl[lIllIllIlIIllI[11]] = lIllIllIlIIlII[lIllIllIlIIllI[15]];
    lIllIllIIllIIl[lIllIllIlIIllI[15]] = lIllIllIlIIlII[lIllIllIlIIllI[9]];
    lIllIllIIllIIl[lIllIllIlIIllI[0]] = lIllIllIlIIlII[lIllIllIlIIllI[12]];
    lIllIllIIllIIl[lIllIllIlIIllI[2]] = lIllIllIlIIlII[lIllIllIlIIllI[8]];
    lIllIllIIllIIl[lIllIllIlIIllI[10]] = lIllIllIlIIlII[lIllIllIlIIllI[6]];
    lIllIllIIllIIl[lIllIllIlIIllI[13]] = lIllIllIlIIlII[lIllIllIlIIllI[16]];
    lIllIllIIllIlI = new Class[lIllIllIlIIllI[7]];
    lIllIllIIllIlI[lIllIllIlIIllI[2]] = FontRenderer.class;
    lIllIllIIllIlI[lIllIllIlIIllI[4]] = int.class;
    lIllIllIIllIlI[lIllIllIlIIllI[1]] = fa.class;
    lIllIllIIllIlI[lIllIllIlIIllI[0]] = f9.class;
    lIllIllIIllIlI[lIllIllIlIIllI[3]] = Minecraft.class;
    lIllIllIIllIlI[lIllIllIlIIllI[5]] = av.class;
  }
  
  private static void llllIlIlIllIlIl() {
    lIllIllIlIIlII = new String[lIllIllIlIIllI[17]];
    lIllIllIlIIlII[lIllIllIlIIllI[0]] = llllIlIlIllIIlI(lIllIllIlIIlIl[lIllIllIlIIllI[0]], lIllIllIlIIlIl[lIllIllIlIIllI[1]]);
    lIllIllIlIIlII[lIllIllIlIIllI[1]] = llllIlIlIllIIlI(lIllIllIlIIlIl[lIllIllIlIIllI[3]], lIllIllIlIIlIl[lIllIllIlIIllI[2]]);
    lIllIllIlIIlII[lIllIllIlIIllI[3]] = llllIlIlIllIIll(lIllIllIlIIlIl[lIllIllIlIIllI[4]], lIllIllIlIIlIl[lIllIllIlIIllI[5]]);
    lIllIllIlIIlII[lIllIllIlIIllI[2]] = llllIlIlIllIIll(lIllIllIlIIlIl[lIllIllIlIIllI[7]], lIllIllIlIIlIl[lIllIllIlIIllI[10]]);
    lIllIllIlIIlII[lIllIllIlIIllI[4]] = llllIlIlIllIlII(lIllIllIlIIlIl[lIllIllIlIIllI[11]], lIllIllIlIIlIl[lIllIllIlIIllI[13]]);
    lIllIllIlIIlII[lIllIllIlIIllI[5]] = llllIlIlIllIlII(lIllIllIlIIlIl[lIllIllIlIIllI[14]], lIllIllIlIIlIl[lIllIllIlIIllI[15]]);
    lIllIllIlIIlII[lIllIllIlIIllI[7]] = llllIlIlIllIIlI(lIllIllIlIIlIl[lIllIllIlIIllI[9]], lIllIllIlIIlIl[lIllIllIlIIllI[12]]);
    lIllIllIlIIlII[lIllIllIlIIllI[10]] = llllIlIlIllIIll("CxZcBD0TAxsDLQkUXBUhFl0TAXMBFgY6JgIGHhJzTj8YFj8HXB4WJwFcIQM7Dx0VTGAqHhdYOhIGAh49AhwVWCsOA10WPF1JUlc=", "fsrwI");
    lIllIllIlIIlII[lIllIllIlIIllI[11]] = llllIlIlIllIIll("AyBZPxgbNR44CAEiWS4EHmsRdVYHKwQ4DQAmEnZcVGVXbEw=", "nEwLl");
    lIllIllIlIIlII[lIllIllIlIIllI[13]] = llllIlIlIllIlII("IMpdvjEySfIbRoBR7kmMaYxkTQUbdxraojHrkQ1ZzTfdLA541QYtTQ==", "uHJrJ");
    lIllIllIlIIlII[lIllIllIlIIllI[14]] = llllIlIlIllIIlI("g5hyP+G9JH6Zb3r15IjAZofSXeMugQQTtswIeYm3JtxJBrYwAiQRg440xQQuOMhYSbPrhKL/bvrP01dj2wXyCA==", "OVKlZ");
    lIllIllIlIIlII[lIllIllIlIIllI[15]] = llllIlIlIllIlII("CSuijg1QNi7A4a7gRCO3jnr4N8gs2sQ6tNZObcotXdQjFfnSI3LlVLunGpxzRu2dVAJJYiGRtjrjY3merRWfWw==", "yTUJE");
    lIllIllIlIIlII[lIllIllIlIIllI[9]] = llllIlIlIllIlII("76XZL5N7ezy5DLxhXagXdJkQ6YdfgXAE6vOvb90nsO8D/lIr40tWdQ==", "EedSV");
    lIllIllIlIIlII[lIllIllIlIIllI[12]] = llllIlIlIllIlII("xRa6YEXluQjBWjUAi0aRixGV/PoyKzsIRr2UNHVtFcKSl3tUULPZhw==", "NgLcL");
    lIllIllIlIIlII[lIllIllIlIIllI[8]] = llllIlIlIllIIlI("+AftNQmSFCiwKjeQBRoKAkNuQygnF5cAK7Zt1OFxlvMb7R/3Q715NPa9H6EA7d4bygJ/jQ+3DWbwaf/1PAAQ3JLVHukBwo3DCfc2OJ+QSF4rjUbbH1NI06e+f08JGsqf", "qwxjp");
    lIllIllIlIIlII[lIllIllIlIIllI[6]] = llllIlIlIllIIll("JR0mQz8iFjcOICoeJkMxJxE3AyZlHycEfA0XPBkALhY2CCAuCmgLJyUbDVxlfkhkXg0qQnohOCoOM0I+KhY1QgE/CjsDNXA+FCR7AkJyTQ==", "KxRmR");
    lIllIllIlIIlII[lIllIllIlIIllI[16]] = llllIlIlIllIlII("gosb2jtgr6YBChvs52OjnPRqHfH1H/cYwWNCyNuT3dqb9vg+TqXneHn/GedIIH0AlgXIP3RprHMab7JU1d5hbIVIOSVaz11ZB8lcubIVHtw=", "eOJsN");
    lIllIllIlIIlIl = null;
  }
  
  private static void llllIlIlIllIllI() {
    String str = (new Exception()).getStackTrace()[lIllIllIlIIllI[0]].getFileName();
    lIllIllIlIIlIl = str.substring(str.indexOf("ä") + lIllIllIlIIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIlIllIlII(String lllllllllllllllIllllIIlIllllllIl, String lllllllllllllllIllllIIlIllllllII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIllIIIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlIllllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIlIllllllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIlIllllllll.init(lIllIllIlIIllI[3], lllllllllllllllIllllIIllIIIIIIII);
      return new String(lllllllllllllllIllllIIlIllllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlIllllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlIlllllllI) {
      lllllllllllllllIllllIIlIlllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIlIllIIlI(String lllllllllllllllIllllIIlIlllllIII, String lllllllllllllllIllllIIlIllllIlll) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlIlllllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlIllllIlll.getBytes(StandardCharsets.UTF_8)), lIllIllIlIIllI[11]), "DES");
      Cipher lllllllllllllllIllllIIlIlllllIlI = Cipher.getInstance("DES");
      lllllllllllllllIllllIIlIlllllIlI.init(lIllIllIlIIllI[3], lllllllllllllllIllllIIlIlllllIll);
      return new String(lllllllllllllllIllllIIlIlllllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlIlllllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlIlllllIIl) {
      lllllllllllllllIllllIIlIlllllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIlIllIIll(String lllllllllllllllIllllIIlIllllIlIl, String lllllllllllllllIllllIIlIllllIlII) {
    lllllllllllllllIllllIIlIllllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIlIllllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIlIllllIIll = new StringBuilder();
    char[] lllllllllllllllIllllIIlIllllIIlI = lllllllllllllllIllllIIlIllllIlII.toCharArray();
    int lllllllllllllllIllllIIlIllllIIIl = lIllIllIlIIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIlIllllIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllIlIIllI[0];
    while (llllIlIlIlllIll(j, i)) {
      char lllllllllllllllIllllIIlIllllIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIlIllllIIIl++;
      j++;
      "".length();
      if (-(0x44 ^ 0x77 ^ 0xAD ^ 0x9A) > 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIlIllllIIll);
  }
  
  private static void llllIlIlIllIlll() {
    lIllIllIlIIllI = new int[18];
    lIllIllIlIIllI[0] = (0x75 ^ 0x7C) << "   ".length() & ((0x1B ^ 0x12) << "   ".length() ^ 0xFFFFFFFF);
    lIllIllIlIIllI[1] = " ".length();
    lIllIllIlIIllI[2] = "   ".length();
    lIllIllIlIIllI[3] = " ".length() << " ".length();
    lIllIllIlIIllI[4] = " ".length() << " ".length() << " ".length();
    lIllIllIlIIllI[5] = (0x5C ^ 0x49) << " ".length() << " ".length() ^ 0xC9 ^ 0x98;
    lIllIllIlIIllI[6] = 0x6C ^ 0x63;
    lIllIllIlIIllI[7] = "   ".length() << " ".length();
    lIllIllIlIIllI[8] = (0x10 ^ 0x17) << " ".length();
    lIllIllIlIIllI[9] = "   ".length() << " ".length() << " ".length();
    lIllIllIlIIllI[10] = 0x5B ^ 0xE ^ (0x3D ^ 0x14) << " ".length();
    lIllIllIlIIllI[11] = " ".length() << "   ".length();
    lIllIllIlIIllI[12] = 0x4F ^ 0x18 ^ (0x7F ^ 0x52) << " ".length();
    lIllIllIlIIllI[13] = 0x86 ^ 0x8F;
    lIllIllIlIIllI[14] = ((0x2C ^ 0x15) << " ".length() ^ 0xDD ^ 0xAA) << " ".length();
    lIllIllIlIIllI[15] = 0x8D ^ 0x86;
    lIllIllIlIIllI[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIllIlIIllI[17] = (0xCB ^ 0x84) << " ".length() ^ 75 + 96 - 44 + 16;
  }
  
  private static boolean llllIlIlIlllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIlIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIlIlllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIlIlllIII(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fw.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */