package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;

public class ae extends au {
  private static String[] lIllllllllllIl;
  
  private static Class[] lIlllllllllllI;
  
  private static final String[] llIIIIIIllIIll;
  
  private static String[] llIIIIIIllIlII;
  
  private static final int[] llIIIIIIllIlIl;
  
  public ae() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ae.llIIIIIIllIIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/ae.llIIIIIIllIIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/ae.llIIIIIIllIIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlllIlIlIlIIlI	Lme/stupitdog/bhp/ae;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   10: invokestatic lIIIIIIlIllIIIlI : (Ljava/lang/Object;)Z
    //   13: ifeq -> 282
    //   16: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   26: instanceof net/minecraft/client/gui/GuiChat
    //   29: invokestatic lIIIIIIlIllIIIll : (I)Z
    //   32: ifeq -> 282
    //   35: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   38: iconst_3
    //   39: iaload
    //   40: <illegal opcode> 3 : (I)Z
    //   45: invokestatic lIIIIIIlIllIIlII : (I)Z
    //   48: ifeq -> 73
    //   51: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: dup
    //   62: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   67: ldc 5.0
    //   69: fsub
    //   70: putfield field_70125_A : F
    //   73: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   76: iconst_4
    //   77: iaload
    //   78: <illegal opcode> 3 : (I)Z
    //   83: invokestatic lIIIIIIlIllIIlII : (I)Z
    //   86: ifeq -> 111
    //   89: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   94: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   99: dup
    //   100: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   105: ldc 5.0
    //   107: fadd
    //   108: putfield field_70125_A : F
    //   111: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   114: iconst_5
    //   115: iaload
    //   116: <illegal opcode> 3 : (I)Z
    //   121: invokestatic lIIIIIIlIllIIlII : (I)Z
    //   124: ifeq -> 149
    //   127: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   132: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   137: dup
    //   138: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   143: ldc 5.0
    //   145: fadd
    //   146: putfield field_70177_z : F
    //   149: getstatic me/stupitdog/bhp/ae.llIIIIIIllIlIl : [I
    //   152: bipush #6
    //   154: iaload
    //   155: <illegal opcode> 3 : (I)Z
    //   160: invokestatic lIIIIIIlIllIIlII : (I)Z
    //   163: ifeq -> 188
    //   166: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   171: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   176: dup
    //   177: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   182: ldc 5.0
    //   184: fsub
    //   185: putfield field_70177_z : F
    //   188: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   193: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   198: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   203: ldc 90.0
    //   205: invokestatic lIIIIIIlIllIIIII : (FF)I
    //   208: invokestatic lIIIIIIlIllIIlIl : (I)Z
    //   211: ifeq -> 229
    //   214: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   219: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   224: ldc 90.0
    //   226: putfield field_70125_A : F
    //   229: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   234: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   239: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   244: ldc -90.0
    //   246: invokestatic lIIIIIIlIllIIIIl : (FF)I
    //   249: invokestatic lIIIIIIlIllIIllI : (I)Z
    //   252: ifeq -> 270
    //   255: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   260: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   265: ldc -90.0
    //   267: putfield field_70125_A : F
    //   270: ldc ''
    //   272: invokevirtual length : ()I
    //   275: pop
    //   276: aconst_null
    //   277: ifnull -> 282
    //   280: return
    //   281: astore_1
    //   282: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	283	0	lllllllllllllllIllIlllIlIlIlIIIl	Lme/stupitdog/bhp/ae;
    // Exception table:
    //   from	to	target	type
    //   35	270	281	java/lang/Exception
  }
  
  static {
    lIIIIIIlIlIlllll();
    lIIIIIIlIlIllllI();
    lIIIIIIlIlIlllIl();
    lIIIIIIlIlIllIIl();
  }
  
  private static CallSite lIIIIIIIllIIllll(MethodHandles.Lookup lllllllllllllllIllIlllIlIlIIlIII, String lllllllllllllllIllIlllIlIlIIIlll, MethodType lllllllllllllllIllIlllIlIlIIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIlIlIIlllI = lIllllllllllIl[Integer.parseInt(lllllllllllllllIllIlllIlIlIIIlll)].split(llIIIIIIllIIll[llIIIIIIllIlIl[7]]);
      Class<?> lllllllllllllllIllIlllIlIlIIllIl = Class.forName(lllllllllllllllIllIlllIlIlIIlllI[llIIIIIIllIlIl[0]]);
      String lllllllllllllllIllIlllIlIlIIllII = lllllllllllllllIllIlllIlIlIIlllI[llIIIIIIllIlIl[1]];
      MethodHandle lllllllllllllllIllIlllIlIlIIlIll = null;
      int lllllllllllllllIllIlllIlIlIIlIlI = lllllllllllllllIllIlllIlIlIIlllI[llIIIIIIllIlIl[7]].length();
      if (lIIIIIIlIllIIlll(lllllllllllllllIllIlllIlIlIIlIlI, llIIIIIIllIlIl[2])) {
        MethodType lllllllllllllllIllIlllIlIlIlIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIlIlIIlllI[llIIIIIIllIlIl[2]], ae.class.getClassLoader());
        if (lIIIIIIlIllIlIII(lllllllllllllllIllIlllIlIlIIlIlI, llIIIIIIllIlIl[2])) {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findVirtual(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIlIIII);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findStatic(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIlIIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIlIlIIllll = lIlllllllllllI[Integer.parseInt(lllllllllllllllIllIlllIlIlIIlllI[llIIIIIIllIlIl[2]])];
        if (lIIIIIIlIllIlIII(lllllllllllllllIllIlllIlIlIIlIlI, llIIIIIIllIlIl[7])) {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findGetter(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIIllll);
          "".length();
          if ((((0xA3 ^ 0xAE) << " ".length() ^ 0x44 ^ 0x13) & (66 + 6 - 9 + 140 ^ (0xFE ^ 0xBD) << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (lIIIIIIlIllIlIII(lllllllllllllllIllIlllIlIlIIlIlI, llIIIIIIllIlIl[8])) {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findStaticGetter(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIIllll);
          "".length();
          if (-" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIlIllIlIII(lllllllllllllllIllIlllIlIlIIlIlI, llIIIIIIllIlIl[9])) {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findSetter(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIIllll);
          "".length();
          if (-" ".length() > -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIlIlIIlIll = lllllllllllllllIllIlllIlIlIIlIII.findStaticSetter(lllllllllllllllIllIlllIlIlIIllIl, lllllllllllllllIllIlllIlIlIIllII, lllllllllllllllIllIlllIlIlIIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIlIlIIlIll);
    } catch (Exception lllllllllllllllIllIlllIlIlIIlIIl) {
      lllllllllllllllIllIlllIlIlIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIlIllIIl() {
    lIllllllllllIl = new String[llIIIIIIllIlIl[10]];
    lIllllllllllIl[llIIIIIIllIlIl[1]] = llIIIIIIllIIll[llIIIIIIllIlIl[8]];
    lIllllllllllIl[llIIIIIIllIlIl[11]] = llIIIIIIllIIll[llIIIIIIllIlIl[9]];
    lIllllllllllIl[llIIIIIIllIlIl[0]] = llIIIIIIllIIll[llIIIIIIllIlIl[11]];
    lIllllllllllIl[llIIIIIIllIlIl[2]] = llIIIIIIllIIll[llIIIIIIllIlIl[10]];
    lIllllllllllIl[llIIIIIIllIlIl[9]] = llIIIIIIllIIll[llIIIIIIllIlIl[12]];
    lIllllllllllIl[llIIIIIIllIlIl[8]] = llIIIIIIllIIll[llIIIIIIllIlIl[13]];
    lIllllllllllIl[llIIIIIIllIlIl[7]] = llIIIIIIllIIll[llIIIIIIllIlIl[14]];
    lIlllllllllllI = new Class[llIIIIIIllIlIl[9]];
    lIlllllllllllI[llIIIIIIllIlIl[2]] = GuiScreen.class;
    lIlllllllllllI[llIIIIIIllIlIl[0]] = f13.class;
    lIlllllllllllI[llIIIIIIllIlIl[7]] = EntityPlayerSP.class;
    lIlllllllllllI[llIIIIIIllIlIl[8]] = float.class;
    lIlllllllllllI[llIIIIIIllIlIl[1]] = Minecraft.class;
  }
  
  private static void lIIIIIIlIlIlllIl() {
    llIIIIIIllIIll = new String[llIIIIIIllIlIl[15]];
    llIIIIIIllIIll[llIIIIIIllIlIl[0]] = lIIIIIIlIlIllIlI(llIIIIIIllIlII[llIIIIIIllIlIl[0]], llIIIIIIllIlII[llIIIIIIllIlIl[1]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[1]] = lIIIIIIlIlIllIlI(llIIIIIIllIlII[llIIIIIIllIlIl[2]], llIIIIIIllIlII[llIIIIIIllIlIl[7]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[2]] = lIIIIIIlIlIllIll(llIIIIIIllIlII[llIIIIIIllIlIl[8]], llIIIIIIllIlII[llIIIIIIllIlIl[9]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[7]] = lIIIIIIlIlIlllII(llIIIIIIllIlII[llIIIIIIllIlIl[11]], llIIIIIIllIlII[llIIIIIIllIlIl[10]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[8]] = lIIIIIIlIlIllIlI(llIIIIIIllIlII[llIIIIIIllIlIl[12]], llIIIIIIllIlII[llIIIIIIllIlIl[13]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[9]] = lIIIIIIlIlIlllII(llIIIIIIllIlII[llIIIIIIllIlIl[14]], llIIIIIIllIlII[llIIIIIIllIlIl[15]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[11]] = lIIIIIIlIlIllIll(llIIIIIIllIlII[llIIIIIIllIlIl[16]], llIIIIIIllIlII[llIIIIIIllIlIl[17]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[10]] = lIIIIIIlIlIllIlI(llIIIIIIllIlII[llIIIIIIllIlIl[18]], llIIIIIIllIlII[llIIIIIIllIlIl[19]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[12]] = lIIIIIIlIlIlllII(llIIIIIIllIlII[llIIIIIIllIlIl[20]], llIIIIIIllIlII[llIIIIIIllIlIl[21]]);
    llIIIIIIllIIll[llIIIIIIllIlIl[13]] = lIIIIIIlIlIllIll("PATq32IqhzV98KcBp+uLaCuAjf2pFO+p4yppwhvL8uQcW4fXbbKn9GR9VnAZEexK/zz21gfAdjo=", "aFKzC");
    llIIIIIIllIIll[llIIIIIIllIlIl[14]] = lIIIIIIlIlIllIll("iPu6djcex5uCxT1SnxxGzI6sHL+987n6TgzS2bIBsNNHdNp6IhbqBHk6R1oxtIjK", "ulawt");
    llIIIIIIllIlII = null;
  }
  
  private static void lIIIIIIlIlIllllI() {
    String str = (new Exception()).getStackTrace()[llIIIIIIllIlIl[0]].getFileName();
    llIIIIIIllIlII = str.substring(str.indexOf("ä") + llIIIIIIllIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIlIllIlI(String lllllllllllllllIllIlllIlIlIIIlII, String lllllllllllllllIllIlllIlIlIIIIll) {
    lllllllllllllllIllIlllIlIlIIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIlIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIlIlIIIIlI = new StringBuilder();
    char[] lllllllllllllllIllIlllIlIlIIIIIl = lllllllllllllllIllIlllIlIlIIIIll.toCharArray();
    int lllllllllllllllIllIlllIlIlIIIIII = llIIIIIIllIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIlIlIIIlII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIllIlIl[0];
    while (lIIIIIIlIllIlIIl(j, i)) {
      char lllllllllllllllIllIlllIlIlIIIlIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIlIlIIIIII++;
      j++;
      "".length();
      if (((122 + 60 - 177 + 142 ^ (0x6D ^ 0x66) << " ".length() << " ".length() << " ".length()) & (93 + 3 - -38 + 31 ^ (0x33 ^ 0x70) << " ".length() ^ -" ".length())) < (((0x94 ^ 0x9B) << " ".length() ^ 0x3A ^ 0x61) & ((0x5 ^ 0x20) << " ".length() ^ 0x1B ^ 0x14 ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIlIlIIIIlI);
  }
  
  private static String lIIIIIIlIlIllIll(String lllllllllllllllIllIlllIlIIllllII, String lllllllllllllllIllIlllIlIIlllIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlIIllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlIIlllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIlIIlllllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIlIIlllllI.init(llIIIIIIllIlIl[2], lllllllllllllllIllIlllIlIIllllll);
      return new String(lllllllllllllllIllIlllIlIIlllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlIIllllIl) {
      lllllllllllllllIllIlllIlIIllllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIlIlllII(String lllllllllllllllIllIlllIlIIllIlll, String lllllllllllllllIllIlllIlIIllIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlIIlllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlIIllIllI.getBytes(StandardCharsets.UTF_8)), llIIIIIIllIlIl[12]), "DES");
      Cipher lllllllllllllllIllIlllIlIIlllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIlIIlllIIl.init(llIIIIIIllIlIl[2], lllllllllllllllIllIlllIlIIlllIlI);
      return new String(lllllllllllllllIllIlllIlIIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlIIlllIII) {
      lllllllllllllllIllIlllIlIIlllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIlIlllll() {
    llIIIIIIllIlIl = new int[22];
    llIIIIIIllIlIl[0] = " ".length() << " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() << " ".length() ^ -" ".length());
    llIIIIIIllIlIl[1] = " ".length();
    llIIIIIIllIlIl[2] = " ".length() << " ".length();
    llIIIIIIllIlIl[3] = ((0x71 ^ 0x5A) << " ".length() << " ".length() ^ 86 + 94 - 162 + 163) << "   ".length();
    llIIIIIIllIlIl[4] = (0xBD ^ 0xB0) << " ".length() << " ".length() << " ".length();
    llIIIIIIllIlIl[5] = ((0x2C ^ 0x29) << " ".length() << " ".length()) + (0x19 ^ 0x30) - ((0x9B ^ 0x9C) << "   ".length()) + ((0xA3 ^ 0xBA) << "   ".length());
    llIIIIIIllIlIl[6] = 174 + 45 - 40 + 24;
    llIIIIIIllIlIl[7] = "   ".length();
    llIIIIIIllIlIl[8] = " ".length() << " ".length() << " ".length();
    llIIIIIIllIlIl[9] = 0x88 ^ 0x8D;
    llIIIIIIllIlIl[10] = 0x55 ^ 0x52;
    llIIIIIIllIlIl[11] = "   ".length() << " ".length();
    llIIIIIIllIlIl[12] = " ".length() << "   ".length();
    llIIIIIIllIlIl[13] = (0x53 ^ 0x4A) << " ".length() ^ 0x89 ^ 0xB2;
    llIIIIIIllIlIl[14] = (" ".length() << "   ".length() << " ".length() ^ 0x48 ^ 0xD) << " ".length();
    llIIIIIIllIlIl[15] = 0x50 ^ 0x5B;
    llIIIIIIllIlIl[16] = "   ".length() << " ".length() << " ".length();
    llIIIIIIllIlIl[17] = 0x2F ^ 0x3A ^ "   ".length() << "   ".length();
    llIIIIIIllIlIl[18] = (0x28 ^ 0x2F) << " ".length();
    llIIIIIIllIlIl[19] = 0x47 ^ 0x48;
    llIIIIIIllIlIl[20] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIllIlIl[21] = " ".length() << " ".length() ^ 0x55 ^ 0x46;
  }
  
  private static boolean lIIIIIIlIllIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlIllIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlIllIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIlIllIIIlI(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIlIllIIlII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIlIllIIIll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIlIllIIllI(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lIIIIIIlIllIIlIl(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lIIIIIIlIllIIIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIIlIllIIIIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ae.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */