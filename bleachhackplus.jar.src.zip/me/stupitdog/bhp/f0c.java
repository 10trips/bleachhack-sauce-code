package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f0c extends au {
  private static String[] llIIIIIlIlIIIl;
  
  private static Class[] llIIIIIlIlIIlI;
  
  private static final String[] llIIIIIlIlIIll;
  
  private static String[] llIIIIIlIlIlII;
  
  private static final int[] llIIIIIlIlIlIl;
  
  public f0c() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0c.llIIIIIlIlIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlllIIIIlIIIII	Lme/stupitdog/bhp/f0c;
  }
  
  static {
    lIIIIIIlllIIIlIl();
    lIIIIIIlllIIIlII();
    lIIIIIIlllIIIIll();
    lIIIIIIlllIIIIII();
  }
  
  private static CallSite lIIIIIIllIllllll(MethodHandles.Lookup lllllllllllllllIllIlllIIIIIlIlll, String lllllllllllllllIllIlllIIIIIlIllI, MethodType lllllllllllllllIllIlllIIIIIlIlIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIIIIIlllIl = llIIIIIlIlIIIl[Integer.parseInt(lllllllllllllllIllIlllIIIIIlIllI)].split(llIIIIIlIlIIll[llIIIIIlIlIlIl[3]]);
      Class<?> lllllllllllllllIllIlllIIIIIlllII = Class.forName(lllllllllllllllIllIlllIIIIIlllIl[llIIIIIlIlIlIl[0]]);
      String lllllllllllllllIllIlllIIIIIllIll = lllllllllllllllIllIlllIIIIIlllIl[llIIIIIlIlIlIl[1]];
      MethodHandle lllllllllllllllIllIlllIIIIIllIlI = null;
      int lllllllllllllllIllIlllIIIIIllIIl = lllllllllllllllIllIlllIIIIIlllIl[llIIIIIlIlIlIl[3]].length();
      if (lIIIIIIlllIIIllI(lllllllllllllllIllIlllIIIIIllIIl, llIIIIIlIlIlIl[2])) {
        MethodType lllllllllllllllIllIlllIIIIIlllll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIIIIIlllIl[llIIIIIlIlIlIl[2]], f0c.class.getClassLoader());
        if (lIIIIIIlllIIIlll(lllllllllllllllIllIlllIIIIIllIIl, llIIIIIlIlIlIl[2])) {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findVirtual(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIlllll);
          "".length();
          if (-" ".length() > "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findStatic(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIlllll);
        } 
        "".length();
        if (-(78 + 94 - 136 + 159 ^ 75 + 184 - 200 + 140) > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIIIIIllllI = llIIIIIlIlIIlI[Integer.parseInt(lllllllllllllllIllIlllIIIIIlllIl[llIIIIIlIlIlIl[2]])];
        if (lIIIIIIlllIIIlll(lllllllllllllllIllIlllIIIIIllIIl, llIIIIIlIlIlIl[3])) {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findGetter(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIllllI);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else if (lIIIIIIlllIIIlll(lllllllllllllllIllIlllIIIIIllIIl, llIIIIIlIlIlIl[4])) {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findStaticGetter(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIllllI);
          "".length();
          if (((0x25 ^ 0x20) << " ".length() << " ".length() << " ".length() & ((0x22 ^ 0x27) << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length())
            return null; 
        } else if (lIIIIIIlllIIIlll(lllllllllllllllIllIlllIIIIIllIIl, llIIIIIlIlIlIl[5])) {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findSetter(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIllllI);
          "".length();
          if (" ".length() == "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIIIIIllIlI = lllllllllllllllIllIlllIIIIIlIlll.findStaticSetter(lllllllllllllllIllIlllIIIIIlllII, lllllllllllllllIllIlllIIIIIllIll, lllllllllllllllIllIlllIIIIIllllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIIIIIllIlI);
    } catch (Exception lllllllllllllllIllIlllIIIIIllIII) {
      lllllllllllllllIllIlllIIIIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlllIIIIII() {
    llIIIIIlIlIIIl = new String[llIIIIIlIlIlIl[1]];
    llIIIIIlIlIIIl[llIIIIIlIlIlIl[0]] = llIIIIIlIlIIll[llIIIIIlIlIlIl[4]];
    llIIIIIlIlIIlI = new Class[llIIIIIlIlIlIl[1]];
    llIIIIIlIlIIlI[llIIIIIlIlIlIl[0]] = f13.class;
  }
  
  private static void lIIIIIIlllIIIIll() {
    llIIIIIlIlIIll = new String[llIIIIIlIlIlIl[5]];
    llIIIIIlIlIIll[llIIIIIlIlIlIl[0]] = lIIIIIIlllIIIIIl(llIIIIIlIlIlII[llIIIIIlIlIlIl[0]], llIIIIIlIlIlII[llIIIIIlIlIlIl[1]]);
    llIIIIIlIlIIll[llIIIIIlIlIlIl[1]] = lIIIIIIlllIIIIlI(llIIIIIlIlIlII[llIIIIIlIlIlIl[2]], llIIIIIlIlIlII[llIIIIIlIlIlIl[3]]);
    llIIIIIlIlIIll[llIIIIIlIlIlIl[2]] = lIIIIIIlllIIIIIl(llIIIIIlIlIlII[llIIIIIlIlIlIl[4]], llIIIIIlIlIlII[llIIIIIlIlIlIl[5]]);
    llIIIIIlIlIIll[llIIIIIlIlIlIl[3]] = lIIIIIIlllIIIIlI(llIIIIIlIlIlII[llIIIIIlIlIlIl[6]], llIIIIIlIlIlII[llIIIIIlIlIlIl[7]]);
    llIIIIIlIlIIll[llIIIIIlIlIlIl[4]] = lIIIIIIlllIIIIlI(llIIIIIlIlIlII[llIIIIIlIlIlIl[8]], llIIIIIlIlIlII[llIIIIIlIlIlIl[9]]);
    llIIIIIlIlIlII = null;
  }
  
  private static void lIIIIIIlllIIIlII() {
    String str = (new Exception()).getStackTrace()[llIIIIIlIlIlIl[0]].getFileName();
    llIIIIIlIlIlII = str.substring(str.indexOf("ä") + llIIIIIlIlIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlllIIIIIl(String lllllllllllllllIllIlllIIIIIlIIIl, String lllllllllllllllIllIlllIIIIIlIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIIIIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIIIIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIIIIIlIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIIIIIlIIll.init(llIIIIIlIlIlIl[2], lllllllllllllllIllIlllIIIIIlIlII);
      return new String(lllllllllllllllIllIlllIIIIIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIIIIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIIIIIlIIlI) {
      lllllllllllllllIllIlllIIIIIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlllIIIIlI(String lllllllllllllllIllIlllIIIIIIlllI, String lllllllllllllllIllIlllIIIIIIllIl) {
    lllllllllllllllIllIlllIIIIIIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIIIIIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIIIIIIllII = new StringBuilder();
    char[] lllllllllllllllIllIlllIIIIIIlIll = lllllllllllllllIllIlllIIIIIIllIl.toCharArray();
    int lllllllllllllllIllIlllIIIIIIlIlI = llIIIIIlIlIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIIIIIIlllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIlIlIlIl[0];
    while (lIIIIIIlllIIlIII(j, i)) {
      char lllllllllllllllIllIlllIIIIIIllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIIIIIIlIlI++;
      j++;
      "".length();
      if (" ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIIIIIIllII);
  }
  
  private static void lIIIIIIlllIIIlIl() {
    llIIIIIlIlIlIl = new int[10];
    llIIIIIlIlIlIl[0] = (0x28 ^ 0xB) & (0x9 ^ 0x2A ^ 0xFFFFFFFF);
    llIIIIIlIlIlIl[1] = " ".length();
    llIIIIIlIlIlIl[2] = " ".length() << " ".length();
    llIIIIIlIlIlIl[3] = "   ".length();
    llIIIIIlIlIlIl[4] = " ".length() << " ".length() << " ".length();
    llIIIIIlIlIlIl[5] = 0xB9 ^ 0xBC;
    llIIIIIlIlIlIl[6] = "   ".length() << " ".length();
    llIIIIIlIlIlIl[7] = 0xA ^ 0x27 ^ (0xB9 ^ 0xAC) << " ".length();
    llIIIIIlIlIlIl[8] = " ".length() << "   ".length();
    llIIIIIlIlIlIl[9] = 0x80 ^ 0x89;
  }
  
  private static boolean lIIIIIIlllIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlllIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlllIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */