package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.text.TextFormatting;

public class ag extends fh {
  private static String[] lIllIlIIIIIlIl;
  
  private static Class[] lIllIlIIIIIllI;
  
  private static final String[] lIllIlIIllIIll;
  
  private static String[] lIllIlIIllIlII;
  
  private static final int[] lIllIlIIllIlIl;
  
  public ag() {
    super(lIllIlIIllIIll[lIllIlIIllIlIl[0]], lIllIlIIllIIll[lIllIlIIllIlIl[1]], lIllIlIIllIIll[lIllIlIIllIlIl[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIllllIllIIllIllll) {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: getstatic me/stupitdog/bhp/ag.lIllIlIIllIlIl : [I
    //   5: iconst_1
    //   6: iaload
    //   7: invokestatic llllIIllIIIllIl : (II)Z
    //   10: ifeq -> 360
    //   13: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   18: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   23: <illegal opcode> 2 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   28: <illegal opcode> 3 : (F)Lnet/minecraft/util/math/Vec3d;
    //   33: astore_2
    //   34: aload_1
    //   35: getstatic me/stupitdog/bhp/ag.lIllIlIIllIlIl : [I
    //   38: iconst_1
    //   39: iaload
    //   40: aaload
    //   41: <illegal opcode> 4 : (Ljava/lang/String;)I
    //   46: istore_3
    //   47: aload_2
    //   48: invokestatic llllIIllIIIlllI : (Ljava/lang/Object;)Z
    //   51: ifeq -> 261
    //   54: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   59: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   64: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   69: invokestatic llllIIllIIIllll : (I)Z
    //   72: ifeq -> 106
    //   75: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   80: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   85: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   90: ldc ''
    //   92: invokevirtual length : ()I
    //   95: pop
    //   96: ldc '   '
    //   98: invokevirtual length : ()I
    //   101: ineg
    //   102: ifle -> 116
    //   105: return
    //   106: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   111: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   116: astore #4
    //   118: aload #4
    //   120: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   125: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   130: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   135: aload_2
    //   136: <illegal opcode> 8 : (Lnet/minecraft/util/math/Vec3d;)D
    //   141: iload_3
    //   142: i2d
    //   143: dmul
    //   144: dadd
    //   145: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   150: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   155: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   160: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   165: <illegal opcode> 1 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   170: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   175: aload_2
    //   176: <illegal opcode> 11 : (Lnet/minecraft/util/math/Vec3d;)D
    //   181: iload_3
    //   182: i2d
    //   183: dmul
    //   184: dadd
    //   185: <illegal opcode> 12 : (Lnet/minecraft/entity/Entity;DDD)V
    //   190: new java/lang/StringBuilder
    //   193: dup
    //   194: invokespecial <init> : ()V
    //   197: getstatic me/stupitdog/bhp/ag.lIllIlIIllIIll : [Ljava/lang/String;
    //   200: getstatic me/stupitdog/bhp/ag.lIllIlIIllIlIl : [I
    //   203: iconst_3
    //   204: iaload
    //   205: aaload
    //   206: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: <illegal opcode> 14 : ()Lnet/minecraft/util/text/TextFormatting;
    //   216: <illegal opcode> 15 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   221: iload_3
    //   222: <illegal opcode> 16 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   227: <illegal opcode> 17 : ()Lnet/minecraft/util/text/TextFormatting;
    //   232: <illegal opcode> 15 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   237: getstatic me/stupitdog/bhp/ag.lIllIlIIllIIll : [Ljava/lang/String;
    //   240: getstatic me/stupitdog/bhp/ag.lIllIlIIllIlIl : [I
    //   243: iconst_4
    //   244: iaload
    //   245: aaload
    //   246: <illegal opcode> 13 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: <illegal opcode> 18 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   256: <illegal opcode> 19 : (Ljava/lang/String;)V
    //   261: ldc ''
    //   263: invokevirtual length : ()I
    //   266: pop
    //   267: ldc ' '
    //   269: invokevirtual length : ()I
    //   272: ldc ' '
    //   274: invokevirtual length : ()I
    //   277: ldc ' '
    //   279: invokevirtual length : ()I
    //   282: ishl
    //   283: ishl
    //   284: ldc ' '
    //   286: invokevirtual length : ()I
    //   289: ineg
    //   290: if_icmpge -> 374
    //   293: return
    //   294: astore_2
    //   295: ldc ''
    //   297: invokevirtual length : ()I
    //   300: pop
    //   301: bipush #125
    //   303: bipush #16
    //   305: iadd
    //   306: bipush #98
    //   308: isub
    //   309: bipush #88
    //   311: iadd
    //   312: sipush #149
    //   315: sipush #192
    //   318: ixor
    //   319: ldc ' '
    //   321: invokevirtual length : ()I
    //   324: ishl
    //   325: ixor
    //   326: bipush #46
    //   328: bipush #37
    //   330: ixor
    //   331: ldc ' '
    //   333: invokevirtual length : ()I
    //   336: ishl
    //   337: bipush #7
    //   339: bipush #56
    //   341: ixor
    //   342: ixor
    //   343: ldc ' '
    //   345: invokevirtual length : ()I
    //   348: ineg
    //   349: ixor
    //   350: iand
    //   351: ldc '   '
    //   353: invokevirtual length : ()I
    //   356: if_icmple -> 374
    //   359: return
    //   360: getstatic me/stupitdog/bhp/ag.lIllIlIIllIIll : [Ljava/lang/String;
    //   363: getstatic me/stupitdog/bhp/ag.lIllIlIIllIlIl : [I
    //   366: iconst_5
    //   367: iaload
    //   368: aaload
    //   369: <illegal opcode> 20 : (Ljava/lang/String;)V
    //   374: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   118	143	4	lllllllllllllllIllllIllIIlllIIll	Lnet/minecraft/entity/Entity;
    //   34	227	2	lllllllllllllllIllllIllIIlllIIlI	Lnet/minecraft/util/math/Vec3d;
    //   47	214	3	lllllllllllllllIllllIllIIlllIIIl	I
    //   0	375	0	lllllllllllllllIllllIllIIlllIIII	Lme/stupitdog/bhp/ag;
    //   0	375	1	lllllllllllllllIllllIllIIllIllll	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   13	261	294	java/lang/Exception
  }
  
  static {
    llllIIllIIIllII();
    llllIIllIIIlIll();
    llllIIllIIIlIlI();
    llllIIllIIIIllI();
  }
  
  private static CallSite llllIIlIIIlllII(MethodHandles.Lookup lllllllllllllllIllllIllIIllIIllI, String lllllllllllllllIllllIllIIllIIlIl, MethodType lllllllllllllllIllllIllIIllIIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIllIIllIllII = lIllIlIIIIIlIl[Integer.parseInt(lllllllllllllllIllllIllIIllIIlIl)].split(lIllIlIIllIIll[lIllIlIIllIlIl[6]]);
      Class<?> lllllllllllllllIllllIllIIllIlIll = Class.forName(lllllllllllllllIllllIllIIllIllII[lIllIlIIllIlIl[0]]);
      String lllllllllllllllIllllIllIIllIlIlI = lllllllllllllllIllllIllIIllIllII[lIllIlIIllIlIl[1]];
      MethodHandle lllllllllllllllIllllIllIIllIlIIl = null;
      int lllllllllllllllIllllIllIIllIlIII = lllllllllllllllIllllIllIIllIllII[lIllIlIIllIlIl[3]].length();
      if (llllIIllIIlIIII(lllllllllllllllIllllIllIIllIlIII, lIllIlIIllIlIl[2])) {
        MethodType lllllllllllllllIllllIllIIllIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIllIIllIllII[lIllIlIIllIlIl[2]], ag.class.getClassLoader());
        if (llllIIllIIlIIIl(lllllllllllllllIllllIllIIllIlIII, lIllIlIIllIlIl[2])) {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findVirtual(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIlllI);
          "".length();
          if ((0x55 ^ 0x4C ^ (0x82 ^ 0x85) << " ".length() << " ".length()) <= 0)
            return null; 
        } else {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findStatic(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIlllI);
        } 
        "".length();
        if (" ".length() != " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIllIIllIllIl = lIllIlIIIIIllI[Integer.parseInt(lllllllllllllllIllllIllIIllIllII[lIllIlIIllIlIl[2]])];
        if (llllIIllIIlIIIl(lllllllllllllllIllllIllIIllIlIII, lIllIlIIllIlIl[3])) {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findGetter(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else if (llllIIllIIlIIIl(lllllllllllllllIllllIllIIllIlIII, lIllIlIIllIlIl[4])) {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findStaticGetter(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIllIl);
          "".length();
          if (-"  ".length() > 0)
            return null; 
        } else if (llllIIllIIlIIIl(lllllllllllllllIllllIllIIllIlIII, lIllIlIIllIlIl[5])) {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findSetter(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIllIIllIlIIl = lllllllllllllllIllllIllIIllIIllI.findStaticSetter(lllllllllllllllIllllIllIIllIlIll, lllllllllllllllIllllIllIIllIlIlI, lllllllllllllllIllllIllIIllIllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIllIIllIlIIl);
    } catch (Exception lllllllllllllllIllllIllIIllIIlll) {
      lllllllllllllllIllllIllIIllIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIllIIIIllI() {
    lIllIlIIIIIlIl = new String[lIllIlIIllIlIl[7]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[3]] = lIllIlIIllIIll[lIllIlIIllIlIl[8]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[9]] = lIllIlIIllIIll[lIllIlIIllIlIl[10]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[11]] = lIllIlIIllIIll[lIllIlIIllIlIl[11]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[8]] = lIllIlIIllIIll[lIllIlIIllIlIl[12]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[5]] = lIllIlIIllIIll[lIllIlIIllIlIl[13]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[14]] = lIllIlIIllIIll[lIllIlIIllIlIl[15]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[16]] = lIllIlIIllIIll[lIllIlIIllIlIl[16]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[2]] = lIllIlIIllIIll[lIllIlIIllIlIl[17]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[18]] = lIllIlIIllIIll[lIllIlIIllIlIl[19]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[6]] = lIllIlIIllIIll[lIllIlIIllIlIl[14]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[15]] = lIllIlIIllIIll[lIllIlIIllIlIl[18]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[20]] = lIllIlIIllIIll[lIllIlIIllIlIl[9]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[4]] = lIllIlIIllIIll[lIllIlIIllIlIl[21]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[12]] = lIllIlIIllIIll[lIllIlIIllIlIl[20]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[0]] = lIllIlIIllIIll[lIllIlIIllIlIl[7]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[1]] = lIllIlIIllIIll[lIllIlIIllIlIl[22]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[17]] = lIllIlIIllIIll[lIllIlIIllIlIl[23]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[19]] = lIllIlIIllIIll[lIllIlIIllIlIl[24]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[21]] = lIllIlIIllIIll[lIllIlIIllIlIl[25]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[10]] = lIllIlIIllIIll[lIllIlIIllIlIl[26]];
    lIllIlIIIIIlIl[lIllIlIIllIlIl[13]] = lIllIlIIllIIll[lIllIlIIllIlIl[27]];
    lIllIlIIIIIllI = new Class[lIllIlIIllIlIl[4]];
    lIllIlIIIIIllI[lIllIlIIllIlIl[1]] = float.class;
    lIllIlIIIIIllI[lIllIlIIllIlIl[2]] = double.class;
    lIllIlIIIIIllI[lIllIlIIllIlIl[0]] = EntityPlayerSP.class;
    lIllIlIIIIIllI[lIllIlIIllIlIl[3]] = TextFormatting.class;
  }
  
  private static void llllIIllIIIlIlI() {
    lIllIlIIllIIll = new String[lIllIlIIllIlIl[28]];
    lIllIlIIllIIll[lIllIlIIllIlIl[0]] = llllIIllIIIIlll(lIllIlIIllIlII[lIllIlIIllIlIl[0]], lIllIlIIllIlII[lIllIlIIllIlIl[1]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[1]] = llllIIllIIIlIII(lIllIlIIllIlII[lIllIlIIllIlIl[2]], lIllIlIIllIlII[lIllIlIIllIlIl[3]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[2]] = llllIIllIIIlIII(lIllIlIIllIlII[lIllIlIIllIlIl[4]], lIllIlIIllIlII[lIllIlIIllIlIl[5]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[3]] = llllIIllIIIlIII(lIllIlIIllIlII[lIllIlIIllIlIl[6]], lIllIlIIllIlII[lIllIlIIllIlIl[8]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[4]] = llllIIllIIIIlll(lIllIlIIllIlII[lIllIlIIllIlIl[10]], lIllIlIIllIlII[lIllIlIIllIlIl[11]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[5]] = llllIIllIIIlIIl(lIllIlIIllIlII[lIllIlIIllIlIl[12]], lIllIlIIllIlII[lIllIlIIllIlIl[13]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[6]] = llllIIllIIIIlll(lIllIlIIllIlII[lIllIlIIllIlIl[15]], lIllIlIIllIlII[lIllIlIIllIlIl[16]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[8]] = llllIIllIIIIlll(lIllIlIIllIlII[lIllIlIIllIlIl[17]], lIllIlIIllIlII[lIllIlIIllIlIl[19]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[10]] = llllIIllIIIlIII(lIllIlIIllIlII[lIllIlIIllIlIl[14]], lIllIlIIllIlII[lIllIlIIllIlIl[18]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[11]] = llllIIllIIIlIIl(lIllIlIIllIlII[lIllIlIIllIlIl[9]], lIllIlIIllIlII[lIllIlIIllIlIl[21]]);
    lIllIlIIllIIll[lIllIlIIllIlIl[12]] = llllIIllIIIlIII("Jw0/TCogBi4BNSgOP0wkJQEuDDNnDSUWLj0RZScpPQE/GxclCTIHNRo4cQQuLAQvPXB5WX1XGD1SeVhnaUg=", "IhKbG");
    lIllIlIIllIIll[lIllIlIIllIlIl[13]] = llllIIllIIIlIII("PSkTSBg6IgIFBzIqE0gWPyUCCAF9KQkSHCc1SSMbJyUTHyU/LR4DBwAcXQAAPS84V01nflZeKjIEXU5cCXZHRg==", "SLgfu");
    lIllIlIIllIIll[lIllIlIIllIlIl[15]] = llllIIllIIIlIII("MzMOJ0A1MxYhQAomCi8APhANLwI9Nwp8DykiHSgKY3oxbyIzMw4nQTUzFiFBCiYKLwA+EA0vAj03Cn1UeXI=", "YRxFn");
    lIllIlIIllIIll[lIllIlIIllIlIl[16]] = llllIIllIIIlIII("OQITFkg/AgsQSAAXFx4INCEQHgo3BhdNByMTABkCaUspHQclAkobBz0ESiQSIQoLEF16Lw8WEDJMCRYINEw2AxQ6DQI1EzoPARIUaFlFVw==", "Scewf");
    lIllIlIIllIIll[lIllIlIIllIlIl[17]] = llllIIllIIIlIII("Fx8zViAQFCIbPxgcM1YuFRMiFjlXHykMJA0DaT0jDRMzAR0VGz4dPyoqfR4kHBYjJ3pJS3BPEgNAdkJtWVo=", "yzGxM");
    lIllIlIIllIIll[lIllIlIIllIlIl[19]] = llllIIllIIIIlll("FEMLSmvg90YPS/WucJusKNzqXN9M8xBhVfMA+DtQs6eDdzquTdbkDS8zT+fccbuHnzN28T7LqpE=", "sOPmv");
    lIllIlIIllIIll[lIllIlIIllIlIl[14]] = llllIIllIIIlIIl("YdJRTShjl/RvhGVQ/SZj2PNHGxB63hRcmhgq22wp7vFPfkwD30wSfo7FA0I/rh3ehIuMZE8tAzYEbTDF37FPI+zZX+zRzTyo4QUlIKBug55d/bywhsiqjyrsFyAJ1Qln", "qAOlv");
    lIllIlIIllIIll[lIllIlIIllIlIl[18]] = llllIIllIIIIlll("G9+VGK13VBInRpMV3d3H/tqXZAF9UNtB7UIG0RU+QPxidYJE9BXWbl5S1x28ZPBCmhsgPFCr8LA=", "MLnZm");
    lIllIlIIllIIll[lIllIlIIllIlIl[9]] = llllIIllIIIlIII("OyFoBBwjNC8DDDkjaBUAJmonA1IlISgTKz4lMjIaJCs0Og0lNycQDWxsCh0JICVpGwk4I2kkHCQtKBBTfxJ8Vw==", "VDFwh");
    lIllIlIIllIIll[lIllIlIIllIlIl[21]] = llllIIllIIIlIIl("3Q4UIiE/d6ZcDfia1KYeWcEetsTs8F2wLH2kFOv6o3/BUqJSR7qrQVqHDZr1hgj46uDJkWLkML0=", "Uibud");
    lIllIlIIllIIll[lIllIlIIllIlIl[20]] = llllIIllIIIIlll("XhJapFt3osYEL0M4nni68sWy56ug8DuMoKtxRljMN5nOU8XuAJQPfhjs+WSzQgc2XQe41xqEZddZVclqQGQOog==", "bruKY");
    lIllIlIIllIIll[lIllIlIIllIlIl[7]] = llllIIllIIIIlll("2AItGOABSerbu07aDP89/uZmoRfQ1xD5SMXCRGnfj8UEA+zKPLXlRlz2CsJF8n51ECqnTGbx1IX5jN0G7QinUosqVi9HgMj8jo/8D+pG/qjycvChOmCqGQ==", "bEMoK");
    lIllIlIIllIIll[lIllIlIIllIlIl[22]] = llllIIllIIIlIIl("gXlMfn+x9YLCF23kzEemEplZS4CeY8IlmeOTFt6T5TcP1xh8IYzpKE56aSBdSXQIQhBLVolCfsU=", "UjoRC");
    lIllIlIIllIIll[lIllIlIIllIlIl[23]] = llllIIllIIIlIII("DAgAeiALAxE3PwMLAHo4FgQYejkHFQB6GQcVABIiEAAVIDkLAxNuGiokIBF3UVdUdG1C", "bmtTM");
    lIllIlIIllIIll[lIllIlIIllIlIl[24]] = llllIIllIIIIlll("w8DHRB8/54W3jktrrJgNdZ3NoqHzE5/TVEe++4gnDGZ/p/xh0n0eOnrYBpeOpXC/1bS91K9orV7+jBLbHVqMriANoac4V0DxV7/eWtT6Gkc=", "pdEYx");
    lIllIlIIllIIll[lIllIlIIllIlIl[25]] = llllIIllIIIIlll("5F1NZq3CwbEFPjcFcLyDmhx/5cVlNsCYGFn5uiaNHwkiK59k3BVQsobHf389qS8utlv0CMHIB0J+CK4vk0lbZg==", "thazG");
    lIllIlIIllIIll[lIllIlIIllIlIl[26]] = llllIIllIIIlIIl("k9bn0DklyU5g/bWWfZe0t5QKTnHs76UJQwz7ldZALTe6/++TCFikbygCERqEZ0Z95syPcQO2a2U=", "QEYOP");
    lIllIlIIllIIll[lIllIlIIllIlIl[27]] = llllIIllIIIlIIl("WfStBP68JvT5gXipEZR64Ahr07R2mLGqiM3L6v8O5TDxbuWgp/5Am9DMW7+cBK5Jojwv+NjTz5k=", "iHkkG");
    lIllIlIIllIlII = null;
  }
  
  private static void llllIIllIIIlIll() {
    String str = (new Exception()).getStackTrace()[lIllIlIIllIlIl[0]].getFileName();
    lIllIlIIllIlII = str.substring(str.indexOf("ä") + lIllIlIIllIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIllIIIlIIl(String lllllllllllllllIllllIllIIllIIIII, String lllllllllllllllIllllIllIIlIlllll) {
    try {
      SecretKeySpec lllllllllllllllIllllIllIIllIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIIlIlllll.getBytes(StandardCharsets.UTF_8)), lIllIlIIllIlIl[10]), "DES");
      Cipher lllllllllllllllIllllIllIIllIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllllIllIIllIIIlI.init(lIllIlIIllIlIl[2], lllllllllllllllIllllIllIIllIIIll);
      return new String(lllllllllllllllIllllIllIIllIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIIllIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIllIIllIIIIl) {
      lllllllllllllllIllllIllIIllIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIllIIIIlll(String lllllllllllllllIllllIllIIlIllIll, String lllllllllllllllIllllIllIIlIllIlI) {
    try {
      SecretKeySpec lllllllllllllllIllllIllIIlIllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIIlIllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIllIIlIlllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIllIIlIlllIl.init(lIllIlIIllIlIl[2], lllllllllllllllIllllIllIIlIllllI);
      return new String(lllllllllllllllIllllIllIIlIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIIlIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIllIIlIlllII) {
      lllllllllllllllIllllIllIIlIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIllIIIlIII(String lllllllllllllllIllllIllIIlIllIII, String lllllllllllllllIllllIllIIlIlIlll) {
    lllllllllllllllIllllIllIIlIllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllllIllIIlIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIllIIlIlIllI = new StringBuilder();
    char[] lllllllllllllllIllllIllIIlIlIlIl = lllllllllllllllIllllIllIIlIlIlll.toCharArray();
    int lllllllllllllllIllllIllIIlIlIlII = lIllIlIIllIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIllIIlIllIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlIIllIlIl[0];
    while (llllIIllIIlIIlI(j, i)) {
      char lllllllllllllllIllllIllIIlIllIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIllIIlIlIlII++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIllIIlIlIllI);
  }
  
  private static void llllIIllIIIllII() {
    lIllIlIIllIlIl = new int[29];
    lIllIlIIllIlIl[0] = "   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIllIlIIllIlIl[1] = " ".length();
    lIllIlIIllIlIl[2] = " ".length() << " ".length();
    lIllIlIIllIlIl[3] = "   ".length();
    lIllIlIIllIlIl[4] = " ".length() << " ".length() << " ".length();
    lIllIlIIllIlIl[5] = 32 + 43 - -30 + 80 ^ (0xEF ^ 0xC0) << " ".length() << " ".length();
    lIllIlIIllIlIl[6] = "   ".length() << " ".length();
    lIllIlIIllIlIl[7] = 0xBE ^ 0xAB;
    lIllIlIIllIlIl[8] = 0x78 ^ 0x7F;
    lIllIlIIllIlIl[9] = (0x11 ^ 0x18) << " ".length();
    lIllIlIIllIlIl[10] = " ".length() << "   ".length();
    lIllIlIIllIlIl[11] = 0x52 ^ 0x5B;
    lIllIlIIllIlIl[12] = ((0x17 ^ 0x2) << " ".length() ^ 0xA4 ^ 0x8B) << " ".length();
    lIllIlIIllIlIl[13] = 0x4E ^ 0x45;
    lIllIlIIllIlIl[14] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIlIIllIlIl[15] = "   ".length() << " ".length() << " ".length();
    lIllIlIIllIlIl[16] = 0x1E ^ 0x13;
    lIllIlIIllIlIl[17] = ((0x5A ^ 0x5D) << " ".length() << " ".length() ^ 0x9F ^ 0x84) << " ".length();
    lIllIlIIllIlIl[18] = 0xAD ^ 0x98 ^ (0x98 ^ 0x91) << " ".length() << " ".length();
    lIllIlIIllIlIl[19] = 0x72 ^ 0x7D;
    lIllIlIIllIlIl[20] = (0x21 ^ 0x24) << " ".length() << " ".length();
    lIllIlIIllIlIl[21] = 0x57 ^ 0x22 ^ (0x4D ^ 0x7E) << " ".length();
    lIllIlIIllIlIl[22] = ((0x25 ^ 0x38) << " ".length() ^ 0x90 ^ 0xA1) << " ".length();
    lIllIlIIllIlIl[23] = (0xC5 ^ 0xC2) << " ".length() << " ".length() << " ".length() ^ 0xE8 ^ 0x8F;
    lIllIlIIllIlIl[24] = "   ".length() << "   ".length();
    lIllIlIIllIlIl[25] = 0xA6 ^ 0xBF;
    lIllIlIIllIlIl[26] = (0xB5 ^ 0xB8) << " ".length();
    lIllIlIIllIlIl[27] = 16 + 60 - 25 + 100 ^ (0x9E ^ 0xBD) << " ".length() << " ".length();
    lIllIlIIllIlIl[28] = ((0x7B ^ 0x64) << " ".length() << " ".length() ^ 0x3E ^ 0x45) << " ".length() << " ".length();
  }
  
  private static boolean llllIIllIIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIllIIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIllIIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIIllIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean llllIIllIIIlllI(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllIIllIIIllll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */