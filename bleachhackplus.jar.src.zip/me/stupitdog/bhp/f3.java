package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class f3 extends au {
  private static String[] lIllllIllIllIl;
  
  private static Class[] lIllllIllIlllI;
  
  private static final String[] lIllllIllIllll;
  
  private static String[] lIllllIlllIIII;
  
  private static final int[] lIllllIlllIIIl;
  
  public f3() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f3.lIllllIllIllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f3.lIllllIlllIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f3.lIllllIllIllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f3.lIllllIlllIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f3.lIllllIllIllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f3.lIllllIlllIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f3.lIllllIlllIIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIlIIIIIlllll	Lme/stupitdog/bhp/f3;
  }
  
  @SubscribeEvent
  public void onDisplayDeathScreen(GuiOpenEvent lllllllllllllllIlllIIlIIIIIlllIl) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lnet/minecraftforge/client/event/GuiOpenEvent;)Lnet/minecraft/client/gui/GuiScreen;
    //   6: instanceof net/minecraft/client/gui/GuiGameOver
    //   9: invokestatic lllllllIlIlIlIl : (I)Z
    //   12: ifeq -> 41
    //   15: aload_1
    //   16: getstatic me/stupitdog/bhp/f3.lIllllIlllIIIl : [I
    //   19: iconst_1
    //   20: iaload
    //   21: <illegal opcode> 2 : (Lnet/minecraftforge/client/event/GuiOpenEvent;Z)V
    //   26: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   31: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   36: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIlIIIIIllllI	Lme/stupitdog/bhp/f3;
    //   0	42	1	lllllllllllllllIlllIIlIIIIIlllIl	Lnet/minecraftforge/client/event/GuiOpenEvent;
  }
  
  static {
    lllllllIlIlIlII();
    lllllllIlIlIIll();
    lllllllIlIlIIlI();
    lllllllIlIIlllI();
  }
  
  private static CallSite lllllllIlIIIllI(MethodHandles.Lookup lllllllllllllllIlllIIlIIIIIlIlII, String lllllllllllllllIlllIIlIIIIIlIIll, MethodType lllllllllllllllIlllIIlIIIIIlIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIIIIIllIlI = lIllllIllIllIl[Integer.parseInt(lllllllllllllllIlllIIlIIIIIlIIll)].split(lIllllIllIllll[lIllllIlllIIIl[3]]);
      Class<?> lllllllllllllllIlllIIlIIIIIllIIl = Class.forName(lllllllllllllllIlllIIlIIIIIllIlI[lIllllIlllIIIl[0]]);
      String lllllllllllllllIlllIIlIIIIIllIII = lllllllllllllllIlllIIlIIIIIllIlI[lIllllIlllIIIl[1]];
      MethodHandle lllllllllllllllIlllIIlIIIIIlIlll = null;
      int lllllllllllllllIlllIIlIIIIIlIllI = lllllllllllllllIlllIIlIIIIIllIlI[lIllllIlllIIIl[3]].length();
      if (lllllllIlIlIllI(lllllllllllllllIlllIIlIIIIIlIllI, lIllllIlllIIIl[2])) {
        MethodType lllllllllllllllIlllIIlIIIIIlllII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIIIIIllIlI[lIllllIlllIIIl[2]], f3.class.getClassLoader());
        if (lllllllIlIlIlll(lllllllllllllllIlllIIlIIIIIlIllI, lIllllIlllIIIl[2])) {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findVirtual(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIlllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findStatic(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIlllII);
        } 
        "".length();
        if (" ".length() >= " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIIIIIllIll = lIllllIllIlllI[Integer.parseInt(lllllllllllllllIlllIIlIIIIIllIlI[lIllllIlllIIIl[2]])];
        if (lllllllIlIlIlll(lllllllllllllllIlllIIlIIIIIlIllI, lIllllIlllIIIl[3])) {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findGetter(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIllIll);
          "".length();
          if (" ".length() <= ((0x12 ^ 0x31) & (0x35 ^ 0x16 ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllllIlIlIlll(lllllllllllllllIlllIIlIIIIIlIllI, lIllllIlllIIIl[4])) {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findStaticGetter(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIllIll);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (lllllllIlIlIlll(lllllllllllllllIlllIIlIIIIIlIllI, lIllllIlllIIIl[5])) {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findSetter(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIllIll);
          "".length();
          if (-" ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIlIIIIIlIlll = lllllllllllllllIlllIIlIIIIIlIlII.findStaticSetter(lllllllllllllllIlllIIlIIIIIllIIl, lllllllllllllllIlllIIlIIIIIllIII, lllllllllllllllIlllIIlIIIIIllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIIIIIlIlll);
    } catch (Exception lllllllllllllllIlllIIlIIIIIlIlIl) {
      lllllllllllllllIlllIIlIIIIIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIlIIlllI() {
    lIllllIllIllIl = new String[lIllllIlllIIIl[6]];
    lIllllIllIllIl[lIllllIlllIIIl[5]] = lIllllIllIllll[lIllllIlllIIIl[4]];
    lIllllIllIllIl[lIllllIlllIIIl[1]] = lIllllIllIllll[lIllllIlllIIIl[5]];
    lIllllIllIllIl[lIllllIlllIIIl[2]] = lIllllIllIllll[lIllllIlllIIIl[6]];
    lIllllIllIllIl[lIllllIlllIIIl[3]] = lIllllIllIllll[lIllllIlllIIIl[7]];
    lIllllIllIllIl[lIllllIlllIIIl[0]] = lIllllIllIllll[lIllllIlllIIIl[8]];
    lIllllIllIllIl[lIllllIlllIIIl[4]] = lIllllIllIllll[lIllllIlllIIIl[9]];
    lIllllIllIlllI = new Class[lIllllIlllIIIl[3]];
    lIllllIllIlllI[lIllllIlllIIIl[0]] = f13.class;
    lIllllIllIlllI[lIllllIlllIIIl[1]] = Minecraft.class;
    lIllllIllIlllI[lIllllIlllIIIl[2]] = EntityPlayerSP.class;
  }
  
  private static void lllllllIlIlIIlI() {
    lIllllIllIllll = new String[lIllllIlllIIIl[10]];
    lIllllIllIllll[lIllllIlllIIIl[0]] = lllllllIlIIllll(lIllllIlllIIII[lIllllIlllIIIl[0]], lIllllIlllIIII[lIllllIlllIIIl[1]]);
    lIllllIllIllll[lIllllIlllIIIl[1]] = lllllllIlIlIIII(lIllllIlllIIII[lIllllIlllIIIl[2]], lIllllIlllIIII[lIllllIlllIIIl[3]]);
    lIllllIllIllll[lIllllIlllIIIl[2]] = lllllllIlIlIIII(lIllllIlllIIII[lIllllIlllIIIl[4]], lIllllIlllIIII[lIllllIlllIIIl[5]]);
    lIllllIllIllll[lIllllIlllIIIl[3]] = lllllllIlIIllll(lIllllIlllIIII[lIllllIlllIIIl[6]], lIllllIlllIIII[lIllllIlllIIIl[7]]);
    lIllllIllIllll[lIllllIlllIIIl[4]] = lllllllIlIIllll(lIllllIlllIIII[lIllllIlllIIIl[8]], lIllllIlllIIII[lIllllIlllIIIl[9]]);
    lIllllIllIllll[lIllllIlllIIIl[5]] = lllllllIlIIllll(lIllllIlllIIII[lIllllIlllIIIl[10]], lIllllIlllIIII[lIllllIlllIIIl[11]]);
    lIllllIllIllll[lIllllIlllIIIl[6]] = lllllllIlIIllll(lIllllIlllIIII[lIllllIlllIIIl[12]], lIllllIlllIIII[lIllllIlllIIIl[13]]);
    lIllllIllIllll[lIllllIlllIIIl[7]] = lllllllIlIlIIII(lIllllIlllIIII[lIllllIlllIIIl[14]], lIllllIlllIIII[lIllllIlllIIIl[15]]);
    lIllllIllIllll[lIllllIlllIIIl[8]] = lllllllIlIlIIIl("GyZMBSADMwsCMBkkTBQ8Bm0ER2dMDislF0xzWFZ0VmM=", "vCbvT");
    lIllllIllIllll[lIllllIlllIIIl[9]] = lllllllIlIIllll("MqvSeWHjWWZ5a/Cr8zWpg/LBEQ9hIqEjEcW5ZhtZdA4eTiThGFvF4M8njsFN0UGpRCmriltXNKc=", "BrIVx");
    lIllllIlllIIII = null;
  }
  
  private static void lllllllIlIlIIll() {
    String str = (new Exception()).getStackTrace()[lIllllIlllIIIl[0]].getFileName();
    lIllllIlllIIII = str.substring(str.indexOf("ä") + lIllllIlllIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllIlIlIIII(String lllllllllllllllIlllIIlIIIIIIlllI, String lllllllllllllllIlllIIlIIIIIIllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIIIIlIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIIIIIllIl.getBytes(StandardCharsets.UTF_8)), lIllllIlllIIIl[8]), "DES");
      Cipher lllllllllllllllIlllIIlIIIIIlIIII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIIIIIlIIII.init(lIllllIlllIIIl[2], lllllllllllllllIlllIIlIIIIIlIIIl);
      return new String(lllllllllllllllIlllIIlIIIIIlIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIIIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIIIIIllll) {
      lllllllllllllllIlllIIlIIIIIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllIlIlIIIl(String lllllllllllllllIlllIIlIIIIIIlIll, String lllllllllllllllIlllIIlIIIIIIlIlI) {
    lllllllllllllllIlllIIlIIIIIIlIll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIIIIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIIIIIIlIIl = new StringBuilder();
    char[] lllllllllllllllIlllIIlIIIIIIlIII = lllllllllllllllIlllIIlIIIIIIlIlI.toCharArray();
    int lllllllllllllllIlllIIlIIIIIIIlll = lIllllIlllIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIIIIIIlIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlllIIIl[0];
    while (lllllllIlIllIII(j, i)) {
      char lllllllllllllllIlllIIlIIIIIIllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIIIIIIIlll++;
      j++;
      "".length();
      if (-"   ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIIIIIIlIIl);
  }
  
  private static String lllllllIlIIllll(String lllllllllllllllIlllIIlIIIIIIIIll, String lllllllllllllllIlllIIlIIIIIIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIIIIIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIIIIIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIIIIIIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIIIIIIIlIl.init(lIllllIlllIIIl[2], lllllllllllllllIlllIIlIIIIIIIllI);
      return new String(lllllllllllllllIlllIIlIIIIIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIIIIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIIIIIIIlII) {
      lllllllllllllllIlllIIlIIIIIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllIlIlIlII() {
    lIllllIlllIIIl = new int[16];
    lIllllIlllIIIl[0] = (0xB3 ^ 0x9C) & (0x8C ^ 0xA3 ^ 0xFFFFFFFF);
    lIllllIlllIIIl[1] = " ".length();
    lIllllIlllIIIl[2] = " ".length() << " ".length();
    lIllllIlllIIIl[3] = "   ".length();
    lIllllIlllIIIl[4] = " ".length() << " ".length() << " ".length();
    lIllllIlllIIIl[5] = (0xAF ^ 0x98) << " ".length() ^ 0xD2 ^ 0xB9;
    lIllllIlllIIIl[6] = "   ".length() << " ".length();
    lIllllIlllIIIl[7] = 0x8 ^ 0x4F ^ " ".length() << "   ".length() << " ".length();
    lIllllIlllIIIl[8] = " ".length() << "   ".length();
    lIllllIlllIIIl[9] = 0x21 ^ 0x28 ^ (0x56 ^ 0x5D) << "   ".length() & ((0x1E ^ 0x15) << "   ".length() ^ 0xFFFFFFFF);
    lIllllIlllIIIl[10] = (0 + 67 - 65 + 177 ^ (0x1B ^ 0x40) << " ".length()) << " ".length();
    lIllllIlllIIIl[11] = 0x32 ^ 0x39;
    lIllllIlllIIIl[12] = "   ".length() << " ".length() << " ".length();
    lIllllIlllIIIl[13] = 0xC8 ^ 0xC5;
    lIllllIlllIIIl[14] = ((0xD9 ^ 0xC0) << " ".length() << " ".length() ^ 0x24 ^ 0x47) << " ".length();
    lIllllIlllIIIl[15] = 0x3B ^ 0x22 ^ (0x89 ^ 0x82) << " ".length();
  }
  
  private static boolean lllllllIlIlIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIlIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIlIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllIlIlIlIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */