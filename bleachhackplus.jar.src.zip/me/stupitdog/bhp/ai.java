package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ai extends au {
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Boolean oby;
  
  f100000000000000000000.Boolean bed;
  
  f100000000000000000000.ColorSetting o;
  
  f100000000000000000000.ColorSetting b;
  
  private static ak holeUtil;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private static String[] lIllllIlIIlIlI;
  
  private static Class[] lIllllIlIIlIll;
  
  private static final String[] lIllllIlIIllII;
  
  private static String[] lIllllIlIlIIII;
  
  private static final int[] lIllllIlIlIIlI;
  
  public ai() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: aload_0
    //   47: <illegal opcode> invoke : (Lme/stupitdog/bhp/ai;)Lme/zero/alpine/listener/EventHook;
    //   52: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   55: iconst_0
    //   56: iaload
    //   57: anewarray java/util/function/Predicate
    //   60: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   63: <illegal opcode> 1 : (Lme/stupitdog/bhp/ai;Lme/zero/alpine/listener/Listener;)V
    //   68: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	69	0	lllllllllllllllIlllIIlIlIIlllIIl	Lme/stupitdog/bhp/ai;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: aload_0
    //   52: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   58: iconst_5
    //   59: iaload
    //   60: aaload
    //   61: aload_1
    //   62: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   65: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   68: bipush #6
    //   70: iaload
    //   71: aaload
    //   72: <illegal opcode> 3 : (Lme/stupitdog/bhp/ai;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   77: <illegal opcode> 4 : (Lme/stupitdog/bhp/ai;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   82: aload_0
    //   83: aload_0
    //   84: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   87: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   90: bipush #7
    //   92: iaload
    //   93: aaload
    //   94: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   97: iconst_1
    //   98: iaload
    //   99: <illegal opcode> 5 : (Lme/stupitdog/bhp/ai;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   104: <illegal opcode> 6 : (Lme/stupitdog/bhp/ai;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   109: aload_0
    //   110: aload_0
    //   111: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   114: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   117: bipush #8
    //   119: iaload
    //   120: aaload
    //   121: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   124: iconst_1
    //   125: iaload
    //   126: <illegal opcode> 5 : (Lme/stupitdog/bhp/ai;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   131: <illegal opcode> 7 : (Lme/stupitdog/bhp/ai;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   136: aload_0
    //   137: aload_0
    //   138: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   141: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   144: bipush #9
    //   146: iaload
    //   147: aaload
    //   148: new me/stupitdog/bhp/f01
    //   151: dup
    //   152: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   155: bipush #10
    //   157: iaload
    //   158: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   161: iconst_0
    //   162: iaload
    //   163: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   166: bipush #11
    //   168: iaload
    //   169: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   172: bipush #11
    //   174: iaload
    //   175: invokespecial <init> : (IIII)V
    //   178: <illegal opcode> 8 : (Lme/stupitdog/bhp/ai;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   183: <illegal opcode> 9 : (Lme/stupitdog/bhp/ai;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   188: aload_0
    //   189: aload_0
    //   190: getstatic me/stupitdog/bhp/ai.lIllllIlIIllII : [Ljava/lang/String;
    //   193: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   196: bipush #12
    //   198: iaload
    //   199: aaload
    //   200: new me/stupitdog/bhp/f01
    //   203: dup
    //   204: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   207: bipush #11
    //   209: iaload
    //   210: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   213: bipush #11
    //   215: iaload
    //   216: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   219: bipush #11
    //   221: iaload
    //   222: getstatic me/stupitdog/bhp/ai.lIllllIlIlIIlI : [I
    //   225: bipush #11
    //   227: iaload
    //   228: invokespecial <init> : (IIII)V
    //   231: <illegal opcode> 8 : (Lme/stupitdog/bhp/ai;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   236: <illegal opcode> 10 : (Lme/stupitdog/bhp/ai;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   241: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	242	0	lllllllllllllllIlllIIlIlIIlllIII	Lme/stupitdog/bhp/ai;
    //   8	234	1	lllllllllllllllIlllIIlIlIIllIlll	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	234	1	lllllllllllllllIlllIIlIlIIllIlll	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lllllllIIIIIIIl : ()V
    //   3: invokestatic llllllIlllllllI : ()V
    //   6: invokestatic llllllIllllllIl : ()V
    //   9: invokestatic llllllIlllIllII : ()V
    //   12: new me/stupitdog/bhp/ak
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: <illegal opcode> 35 : (Lme/stupitdog/bhp/ak;)V
    //   24: return
  }
  
  private static CallSite llllllIlllIlIll(MethodHandles.Lookup lllllllllllllllIlllIIlIlIIlIlIII, String lllllllllllllllIlllIIlIlIIlIIlll, MethodType lllllllllllllllIlllIIlIlIIlIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIlIlIIlIlllI = lIllllIlIIlIlI[Integer.parseInt(lllllllllllllllIlllIIlIlIIlIIlll)].split(lIllllIlIIllII[lIllllIlIlIIlI[19]]);
      Class<?> lllllllllllllllIlllIIlIlIIlIllIl = Class.forName(lllllllllllllllIlllIIlIlIIlIlllI[lIllllIlIlIIlI[0]]);
      String lllllllllllllllIlllIIlIlIIlIllII = lllllllllllllllIlllIIlIlIIlIlllI[lIllllIlIlIIlI[1]];
      MethodHandle lllllllllllllllIlllIIlIlIIlIlIll = null;
      int lllllllllllllllIlllIIlIlIIlIlIlI = lllllllllllllllIlllIIlIlIIlIlllI[lIllllIlIlIIlI[3]].length();
      if (lllllllIIIIIIll(lllllllllllllllIlllIIlIlIIlIlIlI, lIllllIlIlIIlI[2])) {
        MethodType lllllllllllllllIlllIIlIlIIllIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIlIlIIlIlllI[lIllllIlIlIIlI[2]], ai.class.getClassLoader());
        if (lllllllIIIIIlII(lllllllllllllllIlllIIlIlIIlIlIlI, lIllllIlIlIIlI[2])) {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findVirtual(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIllIIII);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findStatic(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIllIIII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIlIlIIlIllll = lIllllIlIIlIll[Integer.parseInt(lllllllllllllllIlllIIlIlIIlIlllI[lIllllIlIlIIlI[2]])];
        if (lllllllIIIIIlII(lllllllllllllllIlllIIlIlIIlIlIlI, lIllllIlIlIIlI[3])) {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findGetter(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIlIllll);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else if (lllllllIIIIIlII(lllllllllllllllIlllIIlIlIIlIlIlI, lIllllIlIlIIlI[4])) {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findStaticGetter(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIlIllll);
          "".length();
          if (((0xE1 ^ 0xA4) & (0xEA ^ 0xAF ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (lllllllIIIIIlII(lllllllllllllllIlllIIlIlIIlIlIlI, lIllllIlIlIIlI[5])) {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findSetter(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIlIllll);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIlIlIIlIlIll = lllllllllllllllIlllIIlIlIIlIlIII.findStaticSetter(lllllllllllllllIlllIIlIlIIlIllIl, lllllllllllllllIlllIIlIlIIlIllII, lllllllllllllllIlllIIlIlIIlIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIlIlIIlIlIll);
    } catch (Exception lllllllllllllllIlllIIlIlIIlIlIIl) {
      lllllllllllllllIlllIIlIlIIlIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIlllIllII() {
    lIllllIlIIlIlI = new String[lIllllIlIlIIlI[20]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[6]] = lIllllIlIIllII[lIllllIlIlIIlI[21]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[22]] = lIllllIlIIllII[lIllllIlIlIIlI[23]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[24]] = lIllllIlIIllII[lIllllIlIlIIlI[25]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[7]] = lIllllIlIIllII[lIllllIlIlIIlI[26]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[27]] = lIllllIlIIllII[lIllllIlIlIIlI[28]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[21]] = lIllllIlIIllII[lIllllIlIlIIlI[29]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[2]] = lIllllIlIIllII[lIllllIlIlIIlI[30]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[4]] = lIllllIlIIllII[lIllllIlIlIIlI[31]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[3]] = lIllllIlIIllII[lIllllIlIlIIlI[27]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[26]] = lIllllIlIIllII[lIllllIlIlIIlI[32]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[0]] = lIllllIlIIllII[lIllllIlIlIIlI[33]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[12]] = lIllllIlIIllII[lIllllIlIlIIlI[24]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[16]] = lIllllIlIIllII[lIllllIlIlIIlI[34]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[13]] = lIllllIlIIllII[lIllllIlIlIIlI[35]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[19]] = lIllllIlIIllII[lIllllIlIlIIlI[36]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[29]] = lIllllIlIIllII[lIllllIlIlIIlI[37]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[25]] = lIllllIlIIllII[lIllllIlIlIIlI[22]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[34]] = lIllllIlIIllII[lIllllIlIlIIlI[38]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[18]] = lIllllIlIIllII[lIllllIlIlIIlI[20]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[14]] = lIllllIlIIllII[lIllllIlIlIIlI[39]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[9]] = lIllllIlIIllII[lIllllIlIlIIlI[40]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[5]] = lIllllIlIIllII[lIllllIlIlIIlI[41]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[36]] = lIllllIlIIllII[lIllllIlIlIIlI[42]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[35]] = lIllllIlIIllII[lIllllIlIlIIlI[43]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[37]] = lIllllIlIIllII[lIllllIlIlIIlI[44]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[30]] = lIllllIlIIllII[lIllllIlIlIIlI[45]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[32]] = lIllllIlIIllII[lIllllIlIlIIlI[46]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[15]] = lIllllIlIIllII[lIllllIlIlIIlI[47]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[38]] = lIllllIlIIllII[lIllllIlIlIIlI[48]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[33]] = lIllllIlIIllII[lIllllIlIlIIlI[49]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[8]] = lIllllIlIIllII[lIllllIlIlIIlI[50]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[31]] = lIllllIlIIllII[lIllllIlIlIIlI[51]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[17]] = lIllllIlIIllII[lIllllIlIlIIlI[52]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[23]] = lIllllIlIIllII[lIllllIlIlIIlI[53]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[28]] = lIllllIlIIllII[lIllllIlIlIIlI[54]];
    lIllllIlIIlIlI[lIllllIlIlIIlI[1]] = lIllllIlIIllII[lIllllIlIlIIlI[55]];
    lIllllIlIIlIll = new Class[lIllllIlIlIIlI[6]];
    lIllllIlIIlIll[lIllllIlIlIIlI[5]] = ak.class;
    lIllllIlIIlIll[lIllllIlIlIIlI[3]] = f100000000000000000000.Boolean.class;
    lIllllIlIIlIll[lIllllIlIlIIlI[4]] = f100000000000000000000.ColorSetting.class;
    lIllllIlIIlIll[lIllllIlIlIIlI[2]] = f100000000000000000000.Mode.class;
    lIllllIlIIlIll[lIllllIlIlIIlI[1]] = Listener.class;
    lIllllIlIIlIll[lIllllIlIlIIlI[0]] = f13.class;
  }
  
  private static void llllllIllllllIl() {
    lIllllIlIIllII = new String[lIllllIlIlIIlI[56]];
    lIllllIlIIllII[lIllllIlIlIIlI[0]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[0]], lIllllIlIlIIII[lIllllIlIlIIlI[1]]);
    lIllllIlIIllII[lIllllIlIlIIlI[1]] = llllllIlllIlllI(lIllllIlIlIIII[lIllllIlIlIIlI[2]], lIllllIlIlIIII[lIllllIlIlIIlI[3]]);
    lIllllIlIIllII[lIllllIlIlIIlI[2]] = llllllIlllIlllI(lIllllIlIlIIII[lIllllIlIlIIlI[4]], lIllllIlIlIIII[lIllllIlIlIIlI[5]]);
    lIllllIlIIllII[lIllllIlIlIIlI[3]] = llllllIlllIlllI(lIllllIlIlIIII[lIllllIlIlIIlI[6]], lIllllIlIlIIII[lIllllIlIlIIlI[7]]);
    lIllllIlIIllII[lIllllIlIlIIlI[4]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[8]], lIllllIlIlIIII[lIllllIlIlIIlI[9]]);
    lIllllIlIIllII[lIllllIlIlIIlI[5]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[12]], lIllllIlIlIIII[lIllllIlIlIIlI[13]]);
    lIllllIlIIllII[lIllllIlIlIIlI[6]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[14]], lIllllIlIlIIII[lIllllIlIlIIlI[15]]);
    lIllllIlIIllII[lIllllIlIlIIlI[7]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[16]], lIllllIlIlIIII[lIllllIlIlIIlI[17]]);
    lIllllIlIIllII[lIllllIlIlIIlI[8]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[18]], lIllllIlIlIIII[lIllllIlIlIIlI[19]]);
    lIllllIlIIllII[lIllllIlIlIIlI[9]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[21]], lIllllIlIlIIII[lIllllIlIlIIlI[23]]);
    lIllllIlIIllII[lIllllIlIlIIlI[12]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[25]], lIllllIlIlIIII[lIllllIlIlIIlI[26]]);
    lIllllIlIIllII[lIllllIlIlIIlI[13]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[28]], lIllllIlIlIIII[lIllllIlIlIIlI[29]]);
    lIllllIlIIllII[lIllllIlIlIIlI[14]] = llllllIlllIlllI(lIllllIlIlIIII[lIllllIlIlIIlI[30]], lIllllIlIlIIII[lIllllIlIlIIlI[31]]);
    lIllllIlIIllII[lIllllIlIlIIlI[15]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[27]], lIllllIlIlIIII[lIllllIlIlIIlI[32]]);
    lIllllIlIIllII[lIllllIlIlIIlI[16]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[33]], lIllllIlIlIIII[lIllllIlIlIIlI[24]]);
    lIllllIlIIllII[lIllllIlIlIIlI[17]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[34]], lIllllIlIlIIII[lIllllIlIlIIlI[35]]);
    lIllllIlIIllII[lIllllIlIlIIlI[18]] = llllllIlllIlllI(lIllllIlIlIIII[lIllllIlIlIIlI[36]], lIllllIlIlIIII[lIllllIlIlIIlI[37]]);
    lIllllIlIIllII[lIllllIlIlIIlI[19]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[22]], lIllllIlIlIIII[lIllllIlIlIIlI[38]]);
    lIllllIlIIllII[lIllllIlIlIIlI[21]] = llllllIlllIllIl(lIllllIlIlIIII[lIllllIlIlIIlI[20]], lIllllIlIlIIII[lIllllIlIlIIlI[39]]);
    lIllllIlIIllII[lIllllIlIlIIlI[23]] = llllllIlllIllll(lIllllIlIlIIII[lIllllIlIlIIlI[40]], lIllllIlIlIIII[lIllllIlIlIIlI[41]]);
    lIllllIlIIllII[lIllllIlIlIIlI[25]] = llllllIlllIllll("xNlP/frG9u9lT+qmI/Y4sOKYCwyQcomX6KZHXxiaAZ86aIAhBKSWLw==", "GYLfD");
    lIllllIlIIllII[lIllllIlIlIIlI[26]] = llllllIlllIllll("HrCn3D05s//YuBIoOfeuHyz0zLO98ZOMU/VIG9/KYGo=", "OrgAk");
    lIllllIlIIllII[lIllllIlIlIIlI[28]] = llllllIlllIlllI("kAjBXt/hCaLAwhphrKzxMRSY8ySdxpuWjou8Ggcvcwg=", "BJUbj");
    lIllllIlIIllII[lIllllIlIlIIlI[29]] = llllllIlllIllll("A3UZKphcPnAEGSedHXDJPvMdw9wPP6ShQLT7c7TxhGrLPK5tSSS6G53Vr8KjzHaFmp+8ykVCR/gdp8AxCyYjfg==", "gxjPZ");
    lIllllIlIIllII[lIllllIlIlIIlI[30]] = llllllIlllIlllI("YJ/ETFTKjP+4y1zPV4XjMH0G22fAf+qZGVnajWfnw0kbcH5AvOSYrWggCTi6PacsVhXLzmlHuFg=", "ELDzK");
    lIllllIlIIllII[lIllllIlIlIIlI[31]] = llllllIlllIllll("mi0tG7CPDuOm8jCPj3YVl3l9Z1rDpgzlfCVsUhJDITn4ndQJC3ER5w==", "zjNOw");
    lIllllIlIIllII[lIllllIlIlIIlI[27]] = llllllIlllIlllI("nurmAhZek/5o+CIAFx6PcYgA/X+Uvl3yIuLPmPH2gX9gRZm3+MWHbm75JU4uskXjP2zDs0fmuPc/m74MNJO+j33bOi3M0TL1Ib1M/SKIeMSlwBFbT3J8JTxSSOTc2gO4rjEbzWEWOMycjIl0Terw63RPaVwTCK0K63GS9wVn/0AqRlKNw5xT8kxlxr/KSxO1", "iHGPm");
    lIllllIlIIllII[lIllllIlIlIIlI[32]] = llllllIlllIllIl("LTUuDW0rNTYLbRQgKgUtIG49HTYmOCslJCk7KgkAJic9VmsLPjkaImg4OQIkaAcsHiopM2NFGX10eA==", "GTXlC");
    lIllllIlIIllII[lIllllIlIlIIlI[33]] = llllllIlllIllll("XzwFnCS0hJO+8105NR3BrYZHCXCFFxOg9CFKhbR+PO1crsqreemu1w==", "AlLKz");
    lIllllIlIIllII[lIllllIlIlIIlI[24]] = llllllIlllIlllI("z3pkkDzNCdOaf/6tR1CwFG7/DVO9zePvq5oJ0Eq7gyk=", "RVvjw");
    lIllllIlIIllII[lIllllIlIlIIlI[34]] = llllllIlllIlllI("ZVehMoyav2Ojr988ttuupGM5UBroHPF/5axlSEayid1adnr3gf8IAEhH0Gn5tDq615mrbKpyChk=", "brBbY");
    lIllllIlIIllII[lIllllIlIlIIlI[35]] = llllllIlllIlllI("vFQ2XeeD7aS2S3B//czte+Qa68HfMJbEO9B8aduDfXorVr3sRJEM+w==", "uRYet");
    lIllllIlIIllII[lIllllIlIlIIlI[36]] = llllllIlllIllIl("FQRiGRcNESUeBxcGYggLCE8tA1kXAzVQUEJBbEo=", "xaLjc");
    lIllllIlIIllII[lIllllIlIlIIlI[37]] = llllllIlllIllIl("JDITZAwjOQIpEysxE2QUPj4LZAwrIw9kIyY4BCExJSRdLBQkNDh7Vn1uUnw+JW1PYyhwd0c=", "JWgJa");
    lIllllIlIIllII[lIllllIlIlIIlI[22]] = llllllIlllIllIl("BzNoHA4fJi8bHgUxaA0SGnggXkpaZnZfSlpmdl9KWmZ2X0paZnZfXic5IgpADTMyORsGIyNVUkMaLA4MC3kqDhQNeRUbCAM4IVRASnY=", "jVFoz");
    lIllllIlIIllII[lIllllIlIlIIlI[38]] = llllllIlllIllll("LVcJbr5/RuMW5Dwg1VSrcZnKy2nX52pFK9cO926xg2IonyJg+U48aw==", "YOapt");
    lIllllIlIIllII[lIllllIlIlIIlI[20]] = llllllIlllIllll("FNW0opYGAIs9ZLxduGzfn+bpH5UsEBoVZmBlWLQpW3IF52tErE7QZzBdeclL2auf", "bjgrY");
    lIllllIlIIllII[lIllllIlIlIIlI[39]] = llllllIlllIllIl("NC99Kh0sOjotDTYtfTsBKWQyMlM/Iz09Jjs5Oj0AOCQbNgU8OWlxQBUgMi8Idj8nMAV2BjoqHWJwc3k=", "YJSYi");
    lIllllIlIIllII[lIllllIlIlIIlI[40]] = llllllIlllIllll("BpDKtLIu7tpy23zWI3d/0ruGs3SNwBDg67JLSWcKXU0=", "knbbx");
    lIllllIlIIllII[lIllllIlIlIIlI[41]] = llllllIlllIllll("b3LwJ+U+itxqCNDiV2nudgeUGhKwz25gCqQWCqpeM4XprO9Cv02zAoIP49UnaOLznd8TWAltrBFENUpQXmkxc+B3RF1T9KVQ40RmI1/J8dWbh7XqCRtpyZuHteoJG2nJonhOBv2/Gt3MCCuhTDzJfQ==", "sVHNt");
    lIllllIlIIllII[lIllllIlIlIIlI[42]] = llllllIlllIllll("3lUAmUgVmcjoDLy1BEOKzsQqYl1ashunw3Khd5dJDCusWzT+EYKkGi1Qke1tbW1KsUmm69xuT00YObUu20mJb4MRPa0kcaq8TmAJL3y/O3V/Un2/ryA2oHGaJ94r8BBK", "pSolO");
    lIllllIlIIllII[lIllllIlIlIIlI[43]] = llllllIlllIllIl("GiplOBICPyI/AhgoZSkOB2EtelZHf3t7Vkd/e3tWR397e1ZHdS85BwAAPj8KHiEucU47IS4/SRomJS4FBS4tP0kCOyInSRouPyNJNjciOCcbJiwlAxMNCXAgMQkNYjBNbw==", "wOKKf");
    lIllllIlIIllII[lIllllIlIlIIlI[44]] = llllllIlllIlllI("CN6BDP6zJwMjrJ8gC2MoEftSkLsBWmLdah0ubZe9oWc=", "zogrU");
    lIllllIlIIllII[lIllllIlIlIIlI[45]] = llllllIlllIlllI("Qm/1k7TcWAW8TdFZ+dKxBoObzxy3VkAwD4Y4k6+NpNcUOIb734Gk2obrQtoWN7rWiOWEZZCj+OE=", "CVKoF");
    lIllllIlIIllII[lIllllIlIlIIlI[46]] = llllllIlllIlllI("QiwSqzCJ9B/1t3gsa7r5pgGgvDiE3oEyCezDYkCEyNgSW+ljF/EgzJ8AoHat3KRy0iBfuK0SHcA3GFtebuO8PCl/IAZAmjjMmKVuV1vQ9+DRBa4sZUgUbkTEEJ1F2kiX", "UHntM");
    lIllllIlIIllII[lIllllIlIlIIlI[47]] = llllllIlllIlllI("vlh0uitxz4u9ZtDld/iK4/Eb/tgPD4pDL6G/V/O5Kr9eHfHls3NtHfCsAh7pZcx+FfqnFRDH8O9IUnCE7uE8jw==", "ENxbD");
    lIllllIlIIllII[lIllllIlIlIIlI[48]] = llllllIlllIlllI("4/BFrcOCpEMA5fbfsFlmquImlajTt2cT77RAIiflXJSixE8L878xZg==", "bgvqL");
    lIllllIlIIllII[lIllllIlIlIIlI[49]] = llllllIlllIllIl("JidcEjY+MhsVJiQlXAMqO2wUUXNxJRcVEC4mSElrAnhSQQ==", "KBraB");
    lIllllIlIIllII[lIllllIlIlIIlI[50]] = llllllIlllIlllI("Kv3NZPjDQiYAxqE8zpmw/AeL5sDXgbzvHjjuERfI4i74Nb+Koe6uJFKbtmpGUnfdaPTWWEQJnxCJN6JNPYTt/LzwL1BnKxb3+Hgy7Ze5tLDEvv6VhzYYK571EE1IIFx6EzwEnD2pkoMTPAScPamSgxXBtmfDIUo8PTPEMij0Wan9nSZWCQVxaA==", "VlOet");
    lIllllIlIIllII[lIllllIlIlIIlI[51]] = llllllIlllIlllI("KEGSW7ft3QWPlkkkXLxSuj0rnHFT2sNDFTLwAtqYPk9sgIoiYiEdLdSnx3vd8hBbdBqafh3ce/YzzojivYLvUZEEHRaceQiZSOdndeK01eHtenSk76UZBRl1gEXSQ/4N", "zZELv");
    lIllllIlIIllII[lIllllIlIlIIlI[52]] = llllllIlllIllll("FKbYKt/OM/OJVj27wvdDAb+N3QjcCDRJb7f07yvCKwa96hWRwiIQCw==", "QOnIi");
    lIllllIlIIllII[lIllllIlIlIIlI[53]] = llllllIlllIllll("AzoLKiHGcjd05Ysky6a8mC6FfU0Xi+NnKM5Dqw1gQ7o=", "EIicQ");
    lIllllIlIIllII[lIllllIlIlIIlI[54]] = llllllIlllIllll("yvb3aqDoAxDXPKmEmuFBgktgjaIObkbENyYk4wUlUC0SWIpEHJJVlJCOSkC6Wj91ASXoRX1YMJE=", "IbUvc");
    lIllllIlIIllII[lIllllIlIlIIlI[55]] = llllllIlllIllIl("AwpPJjkbHwghKQEITzclHkEAPHcCBhIhKAAKE298VE9BdW1O", "noaUM");
    lIllllIlIlIIII = null;
  }
  
  private static void llllllIlllllllI() {
    String str = (new Exception()).getStackTrace()[lIllllIlIlIIlI[0]].getFileName();
    lIllllIlIlIIII = str.substring(str.indexOf("ä") + lIllllIlIlIIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIlllIllll(String lllllllllllllllIlllIIlIlIIlIIIlI, String lllllllllllllllIlllIIlIlIIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIlIIlIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIlIIlIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIlIlIIlIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIlIlIIlIIlII.init(lIllllIlIlIIlI[2], lllllllllllllllIlllIIlIlIIlIIlIl);
      return new String(lllllllllllllllIlllIIlIlIIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIlIIlIIIll) {
      lllllllllllllllIlllIIlIlIIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlllIlllI(String lllllllllllllllIlllIIlIlIIIlllIl, String lllllllllllllllIlllIIlIlIIIlllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIlIlIIlIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIlIIIlllII.getBytes(StandardCharsets.UTF_8)), lIllllIlIlIIlI[8]), "DES");
      Cipher lllllllllllllllIlllIIlIlIIIlllll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIlIIIlllll.init(lIllllIlIlIIlI[2], lllllllllllllllIlllIIlIlIIlIIIII);
      return new String(lllllllllllllllIlllIIlIlIIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIlIlIIIllllI) {
      lllllllllllllllIlllIIlIlIIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlllIllIl(String lllllllllllllllIlllIIlIlIIIllIlI, String lllllllllllllllIlllIIlIlIIIllIIl) {
    lllllllllllllllIlllIIlIlIIIllIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlIlIIIllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlIlIIIllIII = new StringBuilder();
    char[] lllllllllllllllIlllIIlIlIIIlIlll = lllllllllllllllIlllIIlIlIIIllIIl.toCharArray();
    int lllllllllllllllIlllIIlIlIIIlIllI = lIllllIlIlIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIlIlIIIllIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIlIlIIlI[0];
    while (lllllllIIIIIlIl(j, i)) {
      char lllllllllllllllIlllIIlIlIIIllIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIlIlIIIlIllI++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIlIlIIIllIII);
  }
  
  private static void lllllllIIIIIIIl() {
    lIllllIlIlIIlI = new int[57];
    lIllllIlIlIIlI[0] = " ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ -" ".length());
    lIllllIlIlIIlI[1] = " ".length();
    lIllllIlIlIIlI[2] = " ".length() << " ".length();
    lIllllIlIlIIlI[3] = "   ".length();
    lIllllIlIlIIlI[4] = " ".length() << " ".length() << " ".length();
    lIllllIlIlIIlI[5] = 0x99 ^ 0x9C;
    lIllllIlIlIIlI[6] = "   ".length() << " ".length();
    lIllllIlIlIIlI[7] = (0x55 ^ 0x10) << " ".length() ^ 39 + 73 - 84 + 113;
    lIllllIlIlIIlI[8] = " ".length() << "   ".length();
    lIllllIlIlIIlI[9] = 0x55 ^ 0xA ^ (0x1A ^ 0x31) << " ".length();
    lIllllIlIlIIlI[10] = 146 + 83 - 76 + 36;
    lIllllIlIlIIlI[11] = 9 + 148 - -69 + 29;
    lIllllIlIlIIlI[12] = (0x16 ^ 0x13) << " ".length();
    lIllllIlIlIIlI[13] = (0x80 ^ 0xBF) << " ".length() ^ 0xF3 ^ 0x86;
    lIllllIlIlIIlI[14] = "   ".length() << " ".length() << " ".length();
    lIllllIlIlIIlI[15] = 0xBF ^ 0xBA ^ " ".length() << "   ".length();
    lIllllIlIlIIlI[16] = ((0x46 ^ 0x4F) << "   ".length() ^ 0x7F ^ 0x30) << " ".length();
    lIllllIlIlIIlI[17] = 0x15 ^ 0x1A;
    lIllllIlIlIIlI[18] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIlIlIIlI[19] = 0xD7 ^ 0xC6;
    lIllllIlIlIIlI[20] = (0x50 ^ 0x59) << " ".length() << " ".length();
    lIllllIlIlIIlI[21] = (0x60 ^ 0x2F ^ (0x34 ^ 0x17) << " ".length()) << " ".length();
    lIllllIlIlIIlI[22] = (0xCD ^ 0x86 ^ (0x86 ^ 0xAB) << " ".length()) << " ".length();
    lIllllIlIlIIlI[23] = (0x60 ^ 0x5B) << " ".length() ^ 0xD9 ^ 0xBC;
    lIllllIlIlIIlI[24] = 0x79 ^ 0x64;
    lIllllIlIlIIlI[25] = (68 + 55 - 64 + 114 ^ (0x2 ^ 0x17) << "   ".length()) << " ".length() << " ".length();
    lIllllIlIlIIlI[26] = 31 + 65 - -19 + 30 ^ (0x85 ^ 0xA4) << " ".length() << " ".length();
    lIllllIlIlIIlI[27] = (0x86 ^ 0x8B) << " ".length();
    lIllllIlIlIIlI[28] = (21 + 35 - -8 + 123 ^ (0x5 ^ 0xE) << " ".length() << " ".length() << " ".length()) << " ".length();
    lIllllIlIlIIlI[29] = 0x39 ^ 0x2E;
    lIllllIlIlIIlI[30] = "   ".length() << "   ".length();
    lIllllIlIlIIlI[31] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x81 ^ 0xA8;
    lIllllIlIlIIlI[32] = (0x6D ^ 0x68) << "   ".length() ^ 0x53 ^ 0x60;
    lIllllIlIlIIlI[33] = ((0x32 ^ 0x63) << " ".length() ^ 50 + 127 - 129 + 117) << " ".length() << " ".length();
    lIllllIlIlIIlI[34] = ((0x4E ^ 0x47) << " ".length() << " ".length() ^ 0x34 ^ 0x1F) << " ".length();
    lIllllIlIlIIlI[35] = 0x3A ^ 0x25;
    lIllllIlIlIIlI[36] = " ".length() << (0x6F ^ 0x6A);
    lIllllIlIlIIlI[37] = 124 + 133 - 239 + 153 ^ (0xF7 ^ 0xB2) << " ".length();
    lIllllIlIlIIlI[38] = 210 + 119 - 234 + 134 ^ (0xF6 ^ 0x95) << " ".length();
    lIllllIlIlIIlI[39] = (0xAA ^ 0xA1) << " ".length() << " ".length() << " ".length() ^ 60 + 73 - 85 + 101;
    lIllllIlIlIIlI[40] = (0 + 157 - 22 + 28 ^ (0xA9 ^ 0xA2) << " ".length() << " ".length() << " ".length()) << " ".length();
    lIllllIlIlIIlI[41] = "   ".length() << "   ".length() ^ 0xB6 ^ 0x89;
    lIllllIlIlIIlI[42] = (0x17 ^ 0x12) << "   ".length();
    lIllllIlIlIIlI[43] = 49 + 106 - 49 + 35 ^ (0x3C ^ 0x15) << " ".length() << " ".length();
    lIllllIlIlIIlI[44] = (0x71 ^ 0x64) << " ".length();
    lIllllIlIlIIlI[45] = 0x1B ^ 0x30;
    lIllllIlIlIIlI[46] = (78 + 119 - 21 + 15 ^ (0xAF ^ 0x82) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIllllIlIlIIlI[47] = (0x77 ^ 0x4A) << " ".length() ^ 0xED ^ 0xBA;
    lIllllIlIlIIlI[48] = (0xB0 ^ 0x8B ^ (0x94 ^ 0x9F) << " ".length() << " ".length()) << " ".length();
    lIllllIlIlIIlI[49] = 0xA8 ^ 0x87;
    lIllllIlIlIIlI[50] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIllllIlIlIIlI[51] = (0x47 ^ 0x58) << " ".length() ^ 0x8D ^ 0x82;
    lIllllIlIlIIlI[52] = (0x57 ^ 0x4E) << " ".length();
    lIllllIlIlIIlI[53] = 0x14 ^ 0x27;
    lIllllIlIlIIlI[54] = ((0x98 ^ 0x8B) << " ".length() ^ 0x2D ^ 0x6) << " ".length() << " ".length();
    lIllllIlIlIIlI[55] = 0xFB ^ 0x9C ^ (0x5F ^ 0x76) << " ".length();
    lIllllIlIlIIlI[56] = ((0x6 ^ 0x17) << " ".length() ^ 0x1B ^ 0x22) << " ".length();
  }
  
  private static boolean lllllllIIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllIIIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllIIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllIIIIIIlI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ai.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */