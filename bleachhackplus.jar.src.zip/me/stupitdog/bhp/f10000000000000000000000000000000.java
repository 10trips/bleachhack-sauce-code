package me.stupitdog.bhp;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.FocusableComponent;
import com.lukflug.panelstudio.settings.ColorComponent;
import com.lukflug.panelstudio.settings.ColorSetting;
import com.lukflug.panelstudio.settings.Toggleable;
import com.lukflug.panelstudio.theme.ColorScheme;
import com.lukflug.panelstudio.theme.Renderer;
import com.lukflug.panelstudio.theme.Theme;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.text.TextFormatting;

public class f10000000000000000000000000000000 extends ColorComponent {
  private static String[] lIllIllIIIIllI;
  
  private static Class[] lIllIllIIIIlll;
  
  private static final String[] lIllIllIIIllll;
  
  private static String[] lIllIllIIlIIII;
  
  private static final int[] lIllIllIIlIIIl;
  
  public f10000000000000000000000000000000(Theme lllllllllllllllIllllIIllllIlIlII, f100000000000000000000.ColorSetting lllllllllllllllIllllIIllllIlIIll, Toggleable lllllllllllllllIllllIIllllIlIIlI, Animation lllllllllllllllIllllIIllllIlIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: new java/lang/StringBuilder
    //   4: dup
    //   5: invokespecial <init> : ()V
    //   8: <illegal opcode> 0 : ()Lnet/minecraft/util/text/TextFormatting;
    //   13: <illegal opcode> 1 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   18: aload_2
    //   19: <illegal opcode> 2 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Ljava/lang/String;
    //   24: <illegal opcode> 3 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: <illegal opcode> 4 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   34: aconst_null
    //   35: aload_1
    //   36: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   41: aload #4
    //   43: aload_1
    //   44: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   49: aload_2
    //   50: getstatic me/stupitdog/bhp/f10000000000000000000000000000000.lIllIllIIlIIIl : [I
    //   53: iconst_0
    //   54: iaload
    //   55: getstatic me/stupitdog/bhp/f10000000000000000000000000000000.lIllIllIIlIIIl : [I
    //   58: iconst_1
    //   59: iaload
    //   60: aload_3
    //   61: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Animation;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/ColorSetting;ZZLcom/lukflug/panelstudio/settings/Toggleable;)V
    //   64: aload_2
    //   65: <illegal opcode> 7 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   70: invokestatic llllIlIIlllIlII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   73: ifeq -> 96
    //   76: aload_0
    //   77: new me/stupitdog/bhp/f10000000000000000000000000000000$SyncButton
    //   80: dup
    //   81: aload_0
    //   82: aload_1
    //   83: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   88: invokespecial <init> : (Lme/stupitdog/bhp/f10000000000000000000000000000000;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   91: <illegal opcode> 8 : (Lme/stupitdog/bhp/f10000000000000000000000000000000;Lcom/lukflug/panelstudio/Component;)V
    //   96: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	97	0	lllllllllllllllIllllIIllllIlIlIl	Lme/stupitdog/bhp/f10000000000000000000000000000000;
    //   0	97	1	lllllllllllllllIllllIIllllIlIlII	Lcom/lukflug/panelstudio/theme/Theme;
    //   0	97	2	lllllllllllllllIllllIIllllIlIIll	Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   0	97	3	lllllllllllllllIllllIIllllIlIIlI	Lcom/lukflug/panelstudio/settings/Toggleable;
    //   0	97	4	lllllllllllllllIllllIIllllIlIIIl	Lcom/lukflug/panelstudio/Animation;
  }
  
  static {
    llllIlIIlllIIll();
    llllIlIIlllIIlI();
    llllIlIIlllIIIl();
    llllIlIIllIlllI();
  }
  
  private static CallSite llllIlIIllIIIIl(MethodHandles.Lookup lllllllllllllllIllllIIllllIIIlIl, String lllllllllllllllIllllIIllllIIIlII, MethodType lllllllllllllllIllllIIllllIIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIllllIIlIll = lIllIllIIIIllI[Integer.parseInt(lllllllllllllllIllllIIllllIIIlII)].split(lIllIllIIIllll[lIllIllIIlIIIl[0]]);
      Class<?> lllllllllllllllIllllIIllllIIlIlI = Class.forName(lllllllllllllllIllllIIllllIIlIll[lIllIllIIlIIIl[0]]);
      String lllllllllllllllIllllIIllllIIlIIl = lllllllllllllllIllllIIllllIIlIll[lIllIllIIlIIIl[1]];
      MethodHandle lllllllllllllllIllllIIllllIIlIII = null;
      int lllllllllllllllIllllIIllllIIIlll = lllllllllllllllIllllIIllllIIlIll[lIllIllIIlIIIl[2]].length();
      if (llllIlIIlllIlIl(lllllllllllllllIllllIIllllIIIlll, lIllIllIIlIIIl[3])) {
        MethodType lllllllllllllllIllllIIllllIIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIllllIIlIll[lIllIllIIlIIIl[3]], f10000000000000000000000000000000.class.getClassLoader());
        if (llllIlIIlllIllI(lllllllllllllllIllllIIllllIIIlll, lIllIllIIlIIIl[3])) {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findVirtual(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllIl);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findStatic(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllIl);
        } 
        "".length();
        if (-" ".length() >= " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIllllIIllII = lIllIllIIIIlll[Integer.parseInt(lllllllllllllllIllllIIllllIIlIll[lIllIllIIlIIIl[3]])];
        if (llllIlIIlllIllI(lllllllllllllllIllllIIllllIIIlll, lIllIllIIlIIIl[2])) {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findGetter(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllII);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else if (llllIlIIlllIllI(lllllllllllllllIllllIIllllIIIlll, lIllIllIIlIIIl[4])) {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findStaticGetter(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllII);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else if (llllIlIIlllIllI(lllllllllllllllIllllIIllllIIIlll, lIllIllIIlIIIl[5])) {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findSetter(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllII);
          "".length();
          if (((0x7E ^ 0x77) << " ".length() << " ".length() & ((0x50 ^ 0x59) << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIllllIIlIII = lllllllllllllllIllllIIllllIIIlIl.findStaticSetter(lllllllllllllllIllllIIllllIIlIlI, lllllllllllllllIllllIIllllIIlIIl, lllllllllllllllIllllIIllllIIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIllllIIlIII);
    } catch (Exception lllllllllllllllIllllIIllllIIIllI) {
      lllllllllllllllIllllIIllllIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIllIlllI() {
    lIllIllIIIIllI = new String[lIllIllIIlIIIl[6]];
    lIllIllIIIIllI[lIllIllIIlIIIl[4]] = lIllIllIIIllll[lIllIllIIlIIIl[1]];
    lIllIllIIIIllI[lIllIllIIlIIIl[0]] = lIllIllIIIllll[lIllIllIIlIIIl[3]];
    lIllIllIIIIllI[lIllIllIIlIIIl[7]] = lIllIllIIIllll[lIllIllIIlIIIl[2]];
    lIllIllIIIIllI[lIllIllIIlIIIl[8]] = lIllIllIIIllll[lIllIllIIlIIIl[4]];
    lIllIllIIIIllI[lIllIllIIlIIIl[5]] = lIllIllIIIllll[lIllIllIIlIIIl[5]];
    lIllIllIIIIllI[lIllIllIIlIIIl[9]] = lIllIllIIIllll[lIllIllIIlIIIl[10]];
    lIllIllIIIIllI[lIllIllIIlIIIl[3]] = lIllIllIIIllll[lIllIllIIlIIIl[9]];
    lIllIllIIIIllI[lIllIllIIlIIIl[2]] = lIllIllIIIllll[lIllIllIIlIIIl[8]];
    lIllIllIIIIllI[lIllIllIIlIIIl[11]] = lIllIllIIIllll[lIllIllIIlIIIl[11]];
    lIllIllIIIIllI[lIllIllIIlIIIl[1]] = lIllIllIIIllll[lIllIllIIlIIIl[7]];
    lIllIllIIIIllI[lIllIllIIlIIIl[10]] = lIllIllIIIllll[lIllIllIIlIIIl[6]];
    lIllIllIIIIlll = new Class[lIllIllIIlIIIl[4]];
    lIllIllIIIIlll[lIllIllIIlIIIl[2]] = ColorSetting.class;
    lIllIllIIIIlll[lIllIllIIlIIIl[1]] = f100000000000000000000.ColorSetting.class;
    lIllIllIIIIlll[lIllIllIIlIIIl[3]] = ColorScheme.class;
    lIllIllIIIIlll[lIllIllIIlIIIl[0]] = TextFormatting.class;
  }
  
  private static void llllIlIIlllIIIl() {
    lIllIllIIIllll = new String[lIllIllIIlIIIl[12]];
    lIllIllIIIllll[lIllIllIIlIIIl[0]] = llllIlIIllIllll(lIllIllIIlIIII[lIllIllIIlIIIl[0]], lIllIllIIlIIII[lIllIllIIlIIIl[1]]);
    lIllIllIIIllll[lIllIllIIlIIIl[1]] = llllIlIIllIllll(lIllIllIIlIIII[lIllIllIIlIIIl[3]], lIllIllIIlIIII[lIllIllIIlIIIl[2]]);
    lIllIllIIIllll[lIllIllIIlIIIl[3]] = llllIlIIlllIIII(lIllIllIIlIIII[lIllIllIIlIIIl[4]], lIllIllIIlIIII[lIllIllIIlIIIl[5]]);
    lIllIllIIIllll[lIllIllIIlIIIl[2]] = llllIlIIllIllll(lIllIllIIlIIII[lIllIllIIlIIIl[10]], lIllIllIIlIIII[lIllIllIIlIIIl[9]]);
    lIllIllIIIllll[lIllIllIIlIIIl[4]] = llllIlIIllIllll(lIllIllIIlIIII[lIllIllIIlIIIl[8]], lIllIllIIlIIII[lIllIllIIlIIIl[11]]);
    lIllIllIIIllll[lIllIllIIlIIIl[5]] = llllIlIIlllIIII("9kFyzvKkeOdlrIHn+AW25jVo6/fIhKm2GRfuF7mr7r47U+sRIxxBAlisXgXycIckY5Atx+rwa1tgH0V4zqiKbSGgBVFMIt43gb7R6DSmBlXOgVIOG6eZHd210aKTLUkhRS1Yp5gl15A=", "AQYYp");
    lIllIllIIIllll[lIllIllIIlIIIl[10]] = llllIlIIllIllll("Vc4hf0WvL6BWaCsnKBb/99klNJ3aeB5xTSOZ2BA+XFHygnAuHo3gGA==", "WdFcv");
    lIllIllIIIllll[lIllIllIIlIIIl[9]] = llllIlIIllIllll("CpgjId75lZA9kxotXm3FNf8DTHyYzPtEpxtFyNp/nDeJwnZrMS/eUQDFApAZviibLhHWLzdJmxNpvYc1JQEsc6x1a0pvotlVjDTc5L+3JRKV1STLC3hPMg==", "UUgfu");
    lIllIllIIIllll[lIllIllIIlIIIl[8]] = llllIlIIlllIIII("vM0tTJwAEVCmU8DqdjMLj0HvUAmG92Flb2jCGMjrNA9qHv1eOirlHJKBzhUj2/AUmWYib8VrWm7yIZIoYSkRdG+UBEwpu2owEvdUB1iG4ms=", "eyYHC");
    lIllIllIIIllll[lIllIllIIlIIIl[11]] = llllIlIIlllIIII("sPF4Dnd5Zziei9hp50THcTjr0O8gGRpVaVAYQE51+tZpUBhATnX61mlQGEBOdfrWhyoUrFvP1Fy5hUJI9MVP8x5TFOr7KzRU", "HTBVE");
    lIllIllIIIllll[lIllIllIIlIIIl[7]] = llllIlIIlllIIII("edMSZyO4BL6LKxcwiJTA0R/cWctmFh9iKuoLuaS1FbIMOZx3Tcz184TPZ/i9Bdn1xsayFl0TTSEtX7mlD7xCBYqOSvZrZV6w+UaYOqO0Q6o=", "ElxdY");
    lIllIllIIIllll[lIllIllIIlIIIl[6]] = llllIlIIlllIIII("kUgWHFEWhIl8QilIO0blnXPkjj+XnJEjCu8aPdW9cyN1frbLxxLFO+13VVMMPODuAn0ZAShz04SiIkVq851TqyHejkdbvXR8KxEKGWDNcHrcAGW94m6DvprwyHjP1Q94xNacoV+1m64=", "yyiAy");
    lIllIllIIlIIII = null;
  }
  
  private static void llllIlIIlllIIlI() {
    String str = (new Exception()).getStackTrace()[lIllIllIIlIIIl[0]].getFileName();
    lIllIllIIlIIII = str.substring(str.indexOf("ä") + lIllIllIIlIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIIlllIIII(String lllllllllllllllIllllIIlllIllllll, String lllllllllllllllIllllIIlllIlllllI) {
    try {
      SecretKeySpec lllllllllllllllIllllIIllllIIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlllIlllllI.getBytes(StandardCharsets.UTF_8)), lIllIllIIlIIIl[8]), "DES");
      Cipher lllllllllllllllIllllIIllllIIIIIl = Cipher.getInstance("DES");
      lllllllllllllllIllllIIllllIIIIIl.init(lIllIllIIlIIIl[3], lllllllllllllllIllllIIllllIIIIlI);
      return new String(lllllllllllllllIllllIIllllIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlllIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIllllIIIIII) {
      lllllllllllllllIllllIIllllIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIIllIllll(String lllllllllllllllIllllIIlllIlllIlI, String lllllllllllllllIllllIIlllIlllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlllIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlllIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIlllIllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIlllIllllII.init(lIllIllIIlIIIl[3], lllllllllllllllIllllIIlllIllllIl);
      return new String(lllllllllllllllIllllIIlllIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlllIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlllIlllIll) {
      lllllllllllllllIllllIIlllIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIlllIIll() {
    lIllIllIIlIIIl = new int[13];
    lIllIllIIlIIIl[0] = (0x12 ^ 0x73) & (0xCC ^ 0xAD ^ 0xFFFFFFFF);
    lIllIllIIlIIIl[1] = " ".length();
    lIllIllIIlIIIl[2] = "   ".length();
    lIllIllIIlIIIl[3] = " ".length() << " ".length();
    lIllIllIIlIIIl[4] = " ".length() << " ".length() << " ".length();
    lIllIllIIlIIIl[5] = (0xB2 ^ 0x9F) << " ".length() << " ".length() ^ 96 + 42 - 43 + 82;
    lIllIllIIlIIIl[6] = (0xAA ^ 0xB9) << "   ".length() ^ 44 + 3 - -23 + 77;
    lIllIllIIlIIIl[7] = (0xB1 ^ 0x98 ^ (0x59 ^ 0x52) << " ".length() << " ".length()) << " ".length();
    lIllIllIIlIIIl[8] = " ".length() << "   ".length();
    lIllIllIIlIIIl[9] = 0x68 ^ 0x5B ^ (0x73 ^ 0x7E) << " ".length() << " ".length();
    lIllIllIIlIIIl[10] = "   ".length() << " ".length();
    lIllIllIIlIIIl[11] = 0x80 ^ 0x89;
    lIllIllIIlIIIl[12] = "   ".length() << " ".length() << " ".length();
  }
  
  private static boolean llllIlIIlllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIIlllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIIlllIlII(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private class SyncButton extends FocusableComponent {
    private static String[] lIllIlIIIIllll;
    
    private static Class[] lIllIlIIIlIIII;
    
    private static final String[] lIllIlIIlIlIII;
    
    private static String[] lIllIlIIlIlIIl;
    
    private static final int[] lIllIlIIlIlIlI;
    
    public SyncButton(Renderer lllllllllllllllIllllIllIllIlIllI) {
      super(lIllIlIIlIlIII[lIllIlIIlIlIlI[0]], null, lllllllllllllllIllllIllIllIlIllI);
    }
    
    public void render(Context lllllllllllllllIllllIllIllIlIlII) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
      //   5: aload_0
      //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   11: aload_0
      //   12: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lme/stupitdog/bhp/f10000000000000000000000000000000;
      //   17: <illegal opcode> 2 : (Lme/stupitdog/bhp/f10000000000000000000000000000000;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   22: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
      //   27: aload_0
      //   28: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   33: aload_1
      //   34: aload_0
      //   35: <illegal opcode> 4 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Ljava/lang/String;
      //   40: aload_0
      //   41: aload_1
      //   42: <illegal opcode> 5 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;Lcom/lukflug/panelstudio/Context;)Z
      //   47: getstatic me/stupitdog/bhp/f10000000000000000000000000000000$SyncButton.lIllIlIIlIlIlI : [I
      //   50: iconst_0
      //   51: iaload
      //   52: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
      //   57: aload_0
      //   58: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   63: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/theme/Renderer;)V
      //   68: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	69	0	lllllllllllllllIllllIllIllIlIlIl	Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;
      //   0	69	1	lllllllllllllllIllllIllIllIlIlII	Lcom/lukflug/panelstudio/Context;
    }
    
    public void handleButton(Context lllllllllllllllIllllIllIllIlIIlI, int lllllllllllllllIllllIllIllIlIIIl) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: iload_2
      //   3: invokespecial handleButton : (Lcom/lukflug/panelstudio/Context;I)V
      //   6: iload_2
      //   7: invokestatic llllIIlIllIlIll : (I)Z
      //   10: ifeq -> 77
      //   13: aload_1
      //   14: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/Context;)Z
      //   19: invokestatic llllIIlIllIllII : (I)Z
      //   22: ifeq -> 77
      //   25: aload_0
      //   26: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lme/stupitdog/bhp/f10000000000000000000000000000000;
      //   31: <illegal opcode> 9 : (Lme/stupitdog/bhp/f10000000000000000000000000000000;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   36: <illegal opcode> 10 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
      //   41: <illegal opcode> 11 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Lme/stupitdog/bhp/f01;
      //   46: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   51: aload_0
      //   52: <illegal opcode> 1 : (Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;)Lme/stupitdog/bhp/f10000000000000000000000000000000;
      //   57: <illegal opcode> 13 : (Lme/stupitdog/bhp/f10000000000000000000000000000000;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   62: <illegal opcode> 10 : ()Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
      //   67: <illegal opcode> 14 : (Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)Z
      //   72: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Z)V
      //   77: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	78	0	lllllllllllllllIllllIllIllIlIIll	Lme/stupitdog/bhp/f10000000000000000000000000000000$SyncButton;
      //   0	78	1	lllllllllllllllIllllIllIllIlIIlI	Lcom/lukflug/panelstudio/Context;
      //   0	78	2	lllllllllllllllIllllIllIllIlIIIl	I
    }
    
    static {
      llllIIlIllIlIlI();
      llllIIlIllIlIIl();
      llllIIlIllIlIII();
      llllIIlIllIIlII();
    }
    
    private static CallSite llllIIlIIlIllII(MethodHandles.Lookup lllllllllllllllIllllIllIllIIlIII, String lllllllllllllllIllllIllIllIIIlll, MethodType lllllllllllllllIllllIllIllIIIllI) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllllIllIllIIlllI = lIllIlIIIIllll[Integer.parseInt(lllllllllllllllIllllIllIllIIIlll)].split(lIllIlIIlIlIII[lIllIlIIlIlIlI[1]]);
        Class<?> lllllllllllllllIllllIllIllIIllIl = Class.forName(lllllllllllllllIllllIllIllIIlllI[lIllIlIIlIlIlI[0]]);
        String lllllllllllllllIllllIllIllIIllII = lllllllllllllllIllllIllIllIIlllI[lIllIlIIlIlIlI[1]];
        MethodHandle lllllllllllllllIllllIllIllIIlIll = null;
        int lllllllllllllllIllllIllIllIIlIlI = lllllllllllllllIllllIllIllIIlllI[lIllIlIIlIlIlI[2]].length();
        if (llllIIlIllIllIl(lllllllllllllllIllllIllIllIIlIlI, lIllIlIIlIlIlI[3])) {
          MethodType lllllllllllllllIllllIllIllIlIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIllIllIIlllI[lIllIlIIlIlIlI[3]], SyncButton.class.getClassLoader());
          if (llllIIlIllIlllI(lllllllllllllllIllllIllIllIIlIlI, lIllIlIIlIlIlI[3])) {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findVirtual(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIlIIII);
            "".length();
            if (" ".length() << " ".length() == 0)
              return null; 
          } else {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findStatic(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIlIIII);
          } 
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIllllIllIllIIllll = lIllIlIIIlIIII[Integer.parseInt(lllllllllllllllIllllIllIllIIlllI[lIllIlIIlIlIlI[3]])];
          if (llllIIlIllIlllI(lllllllllllllllIllllIllIllIIlIlI, lIllIlIIlIlIlI[2])) {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findGetter(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIIllll);
            "".length();
            if ("   ".length() == " ".length() << " ".length() << " ".length())
              return null; 
          } else if (llllIIlIllIlllI(lllllllllllllllIllllIllIllIIlIlI, lIllIlIIlIlIlI[4])) {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findStaticGetter(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIIllll);
            "".length();
            if (" ".length() << " ".length() << " ".length() == " ".length() << " ".length())
              return null; 
          } else if (llllIIlIllIlllI(lllllllllllllllIllllIllIllIIlIlI, lIllIlIIlIlIlI[5])) {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findSetter(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIIllll);
            "".length();
            if (" ".length() << " ".length() <= 0)
              return null; 
          } else {
            lllllllllllllllIllllIllIllIIlIll = lllllllllllllllIllllIllIllIIlIII.findStaticSetter(lllllllllllllllIllllIllIllIIllIl, lllllllllllllllIllllIllIllIIllII, lllllllllllllllIllllIllIllIIllll);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllllIllIllIIlIll);
      } catch (Exception lllllllllllllllIllllIllIllIIlIIl) {
        lllllllllllllllIllllIllIllIIlIIl.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIlIllIIlII() {
      lIllIlIIIIllll = new String[lIllIlIIlIlIlI[6]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[7]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[3]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[8]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[2]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[9]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[4]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[1]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[5]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[10]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[11]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[3]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[12]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[5]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[7]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[11]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[13]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[4]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[14]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[0]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[8]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[13]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[15]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[16]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[10]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[14]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[16]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[12]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[9]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[15]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[6]];
      lIllIlIIIIllll[lIllIlIIlIlIlI[2]] = lIllIlIIlIlIII[lIllIlIIlIlIlI[17]];
      lIllIlIIIlIIII = new Class[lIllIlIIlIlIlI[4]];
      lIllIlIIIlIIII[lIllIlIIlIlIlI[2]] = f100000000000000000000.ColorSetting.class;
      lIllIlIIIlIIII[lIllIlIIlIlIlI[1]] = Renderer.class;
      lIllIlIIIlIIII[lIllIlIIlIlIlI[0]] = f10000000000000000000000000000000.class;
      lIllIlIIIlIIII[lIllIlIIlIlIlI[3]] = String.class;
    }
    
    private static void llllIIlIllIlIII() {
      lIllIlIIlIlIII = new String[lIllIlIIlIlIlI[18]];
      lIllIlIIlIlIII[lIllIlIIlIlIlI[0]] = llllIIlIllIIlIl(lIllIlIIlIlIIl[lIllIlIIlIlIlI[0]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[1]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[1]] = llllIIlIllIIlIl(lIllIlIIlIlIIl[lIllIlIIlIlIlI[3]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[2]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[3]] = llllIIlIllIIllI(lIllIlIIlIlIIl[lIllIlIIlIlIlI[4]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[5]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[2]] = llllIIlIllIIlll(lIllIlIIlIlIIl[lIllIlIIlIlIlI[11]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[12]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[4]] = llllIIlIllIIllI(lIllIlIIlIlIIl[lIllIlIIlIlIlI[7]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[13]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[5]] = llllIIlIllIIlll(lIllIlIIlIlIIl[lIllIlIIlIlIlI[14]], lIllIlIIlIlIIl[lIllIlIIlIlIlI[8]]);
      lIllIlIIlIlIII[lIllIlIIlIlIlI[11]] = llllIIlIllIIlIl("eAIskxtz1Whc7KQTDXQhotdh51j5k9U/Q5cPRNal3VtDlw9E1qXdW0OXD0TWpd1bALjXOwq856mv/K+uf8ir3KahLTVsVRSafYgncO7p31ztnYx42aKfokOXD0TWpd1bQ5cPRNal3VtDlw9E1qXdW3pgJg4Qf0CdqkUGHryjm6PGGaLYpZJZHQANy6mI/5uSsJ6QWg46AkC18VvHuowP7WQy4XAoxGv0", "QDTIe");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[12]] = llllIIlIllIIlIl("cfytatJanF56eqhHODgqd6GeHLUOyCFFSrmsMLlw1D9KuawwuXDUP0q5rDC5cNQ/jY5Tk/XqbohCkLZ+4gTRbYY6jD6sIYg5aK82BiImv5HlfnNqKSXgTUq5rDC5cNQ/SrmsMLlw1D9KuawwuXDUP0/nkm4djSX0rpHvDinmAoIx1aB5KhGAbngkjzN69vyF0mXpyRv/iXJKnGj3/KQa8bEcuoUOK/66", "Jjwmz");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[7]] = llllIIlIllIIlIl("vThDevoXR09uVDmwP3tiAiDxEa48FIHAi46iQL0IsmCLjqJAvQiyYIuOokC9CLJgmF4WK64XvmPc0H5zhmUkEQr4v7mwFUH3BZSy0yMi41OlrMmAYp7JQ1yIsiIdqVrxzpqtYFP+Cvg6tOR83F2wYQ==", "nzGkP");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[13]] = llllIIlIllIIlll("CBcfSQ8eExQLFgxWAgYNDhQBExYPER1JFwMdHwJNOR0cAwYZHQBdEQ4WFgIRPxEGCwZRUD4EDAZXHhIIDRQHAEwbGRwCDxgMBwMKBFcxCA0fHQoTWCcSExECRBQTCQREKwYVCgUfST05Qi5IR0M=", "kxrgc");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[14]] = llllIIlIllIIlIl("ZcsyenJglHhYPPVjx2w22CuIQlK4Tcps3G0ZIFOhGbrcbRkgU6EZutxtGSBToRm6pr6sWxcjO5JRQncrHohXqnvmigO/GID3emhc1fuRLMQ=", "SnQpt");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[8]] = llllIIlIllIIllI("pfTW62RkgZIBhZ1em4JWEoKfQ1bpcOIVz90TQH+ukbbP3RNAf66Rts/dE0B/rpG2GnSCPUDWopvgE67WNJ+nQxcQnkL6qe1f7XmhYsJs1Sw=", "iphTZ");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[15]] = llllIIlIllIIlIl("RyYOkTvxiNgKS6GngYKoFQby/RLdGAlBTA+4wj0RX3JMD7jCPRFfckwPuMI9EV9ybWCVMqF2v0W/SKGzmx8wRl+x0/KGt44DIRwAa+luXSEAG+RU7YZrokwPuMI9EV9yTA+4wj0RX3JMD7jCPRFfcnxcYtNVZmWjq1AAx1bfPUalXaMsVhRiT7/Kz4z/fkcloV8VzvvATgPKhB+3eDc74CV+13LEwSy0", "lEprX");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[10]] = llllIIlIllIIlIl("Pk43n0oFX8LD5GOqQzIyvzUldT8j56X9yC7lHfrmfeWUN0hXot5pjdjK/Lddze9JfF2nTTcjieEjdV8HsV3n6vH0RPMgJvnM", "fHeJP");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[16]] = llllIIlIllIIlIl("rVTDLMj+7zSrx6emgbH494ZlwRKd5paiUucUXvCNmiaZNh1Q5N3MuA==", "lzJyu");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[9]] = llllIIlIllIIlIl("KmJdgeLsYBVzHzQ7vkih57DcO8sSKnS+8iVSmvedhLYyJfC/DbQyS9+gbSZfzShASRLi/xL37Kf2ippLcVZTpi/9t2k9AAfR", "ITNnJ");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[6]] = llllIIlIllIIllI("B77NJLWy/pmjasixGJ1HGJLO2d23otziEf+bhucU2A8oVDG8Kxm6nGA/AnWv1RrQa5h/ESO9LBYJ0ZPy/p2W9iqnes8W3Vv1vrn9LktKZVA=", "BzEJC");
      lIllIlIIlIlIII[lIllIlIIlIlIlI[17]] = llllIIlIllIIllI("zqPTunBA9SavTfgBixZyi2rSdhwPizvKVQ8sQfCqjtGQhYyLbjFmN4/LwI53oBbcPHaTo8M97VDzka2oIpFVyzUyuOo8Q142RoMD9Tc+hP0hdP/DszYXrYzqHtLZ6cNQAxHHOxi6+xozpN16LfXc/g==", "WZHgo");
      lIllIlIIlIlIIl = null;
    }
    
    private static void llllIIlIllIlIIl() {
      String str = (new Exception()).getStackTrace()[lIllIlIIlIlIlI[0]].getFileName();
      lIllIlIIlIlIIl = str.substring(str.indexOf("ä") + lIllIlIIlIlIlI[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String llllIIlIllIIlIl(String lllllllllllllllIllllIllIllIIIIlI, String lllllllllllllllIllllIllIllIIIIIl) {
      try {
        SecretKeySpec lllllllllllllllIllllIllIllIIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIllIIIIIl.getBytes(StandardCharsets.UTF_8)), lIllIlIIlIlIlI[7]), "DES");
        Cipher lllllllllllllllIllllIllIllIIIlII = Cipher.getInstance("DES");
        lllllllllllllllIllllIllIllIIIlII.init(lIllIlIIlIlIlI[3], lllllllllllllllIllllIllIllIIIlIl);
        return new String(lllllllllllllllIllllIllIllIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIllIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllllIllIllIIIIll) {
        lllllllllllllllIllllIllIllIIIIll.printStackTrace();
        return null;
      } 
    }
    
    private static String llllIIlIllIIlll(String lllllllllllllllIllllIllIlIllllll, String lllllllllllllllIllllIllIlIlllllI) {
      lllllllllllllllIllllIllIlIllllll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllllIllIlIllllIl = new StringBuilder();
      char[] lllllllllllllllIllllIllIlIllllII = lllllllllllllllIllllIllIlIlllllI.toCharArray();
      int lllllllllllllllIllllIllIlIlllIll = lIllIlIIlIlIlI[0];
      char[] arrayOfChar1 = lllllllllllllllIllllIllIlIllllll.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIllIlIIlIlIlI[0];
      while (llllIIlIllIllll(j, i)) {
        char lllllllllllllllIllllIllIllIIIIII = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllllIllIlIlllIll++;
        j++;
        "".length();
        if (((0x8C ^ 0xC5) & (0x49 ^ 0x0 ^ 0xFFFFFFFF)) < -" ".length())
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllllIllIlIllllIl);
    }
    
    private static String llllIIlIllIIllI(String lllllllllllllllIllllIllIlIllIlll, String lllllllllllllllIllllIllIlIllIllI) {
      try {
        SecretKeySpec lllllllllllllllIllllIllIlIlllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIlIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllllIllIlIlllIIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIllllIllIlIlllIIl.init(lIllIlIIlIlIlI[3], lllllllllllllllIllllIllIlIlllIlI);
        return new String(lllllllllllllllIllllIllIlIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllllIllIlIlllIII) {
        lllllllllllllllIllllIllIlIlllIII.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIlIllIlIlI() {
      lIllIlIIlIlIlI = new int[19];
      lIllIlIIlIlIlI[0] = ((0x69 ^ 0x62) << " ".length() << " ".length() ^ 0x9 ^ 0x34) << " ".length() << " ".length() & (((0x26 ^ 0x2B) << " ".length() ^ 0xBD ^ 0xB6) << " ".length() << " ".length() ^ -" ".length());
      lIllIlIIlIlIlI[1] = " ".length();
      lIllIlIIlIlIlI[2] = "   ".length();
      lIllIlIIlIlIlI[3] = " ".length() << " ".length();
      lIllIlIIlIlIlI[4] = " ".length() << " ".length() << " ".length();
      lIllIlIIlIlIlI[5] = 0x7E ^ 0x7B;
      lIllIlIIlIlIlI[6] = " ".length() << " ".length() << " ".length() << " ".length();
      lIllIlIIlIlIlI[7] = " ".length() << "   ".length();
      lIllIlIIlIlIlI[8] = 0x3F ^ 0x32 ^ "   ".length() << " ".length();
      lIllIlIIlIlIlI[9] = 0xA ^ 0x5;
      lIllIlIIlIlIlI[10] = (0x16 ^ 0x29) << " ".length() ^ 0xF4 ^ 0x87;
      lIllIlIIlIlIlI[11] = "   ".length() << " ".length();
      lIllIlIIlIlIlI[12] = 0x1 ^ 0x6;
      lIllIlIIlIlIlI[13] = 0x3 ^ 0xA;
      lIllIlIIlIlIlI[14] = ((0x29 ^ 0x16) << " ".length() ^ 0x55 ^ 0x2E) << " ".length();
      lIllIlIIlIlIlI[15] = "   ".length() << " ".length() << " ".length();
      lIllIlIIlIlIlI[16] = ((0x24 ^ 0x47) << " ".length() ^ 146 + 175 - 147 + 19) << " ".length();
      lIllIlIIlIlIlI[17] = 0x34 ^ 0x7F ^ (0x51 ^ 0x7C) << " ".length();
      lIllIlIIlIlIlI[18] = (0x86 ^ 0x8F) << " ".length();
    }
    
    private static boolean llllIIlIllIlllI(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean llllIIlIllIllll(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean llllIIlIllIllIl(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean llllIIlIllIllII(int param1Int) {
      return (param1Int != 0);
    }
    
    private static boolean llllIIlIllIlIll(int param1Int) {
      return (param1Int == 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */