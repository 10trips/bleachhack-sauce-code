package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.PlayerSPPushOutOfBlocksEvent;

public class f11 extends au {
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Boolean rotate;
  
  f100000000000000000000.Double offset;
  
  private BlockPos originalPos;
  
  private int oldSlot;
  
  private int stage;
  
  @EventHandler
  private final Listener<PlayerSPPushOutOfBlocksEvent> pushListener;
  
  private static String[] lIllIlIlllIIII;
  
  private static Class[] lIllIlIlllIIIl;
  
  private static final String[] lIlllIllIlIIIl;
  
  private static String[] lIlllIllIlIlII;
  
  private static final int[] lIlllIllIlIlIl;
  
  public f11() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   45: iconst_3
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f11;I)V
    //   52: aload_0
    //   53: new me/zero/alpine/listener/Listener
    //   56: dup
    //   57: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   62: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   65: iconst_0
    //   66: iaload
    //   67: anewarray java/util/function/Predicate
    //   70: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   73: putfield pushListener : Lme/zero/alpine/listener/Listener;
    //   76: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	77	0	lllllllllllllllIlllIlIIlIIlIIllI	Lme/stupitdog/bhp/f11;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   15: iconst_4
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   36: iconst_5
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_1
    //   51: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   54: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   57: bipush #6
    //   59: iaload
    //   60: aaload
    //   61: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   66: ldc ''
    //   68: invokevirtual length : ()I
    //   71: pop2
    //   72: aload_1
    //   73: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   76: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   79: bipush #7
    //   81: iaload
    //   82: aaload
    //   83: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   88: ldc ''
    //   90: invokevirtual length : ()I
    //   93: pop2
    //   94: aload_0
    //   95: aload_0
    //   96: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   99: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   102: bipush #8
    //   104: iaload
    //   105: aaload
    //   106: aload_1
    //   107: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   110: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   113: bipush #9
    //   115: iaload
    //   116: aaload
    //   117: <illegal opcode> 3 : (Lme/stupitdog/bhp/f11;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   122: <illegal opcode> 4 : (Lme/stupitdog/bhp/f11;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   127: aload_0
    //   128: aload_0
    //   129: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   132: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   135: bipush #10
    //   137: iaload
    //   138: aaload
    //   139: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   142: iconst_0
    //   143: iaload
    //   144: <illegal opcode> 5 : (Lme/stupitdog/bhp/f11;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   149: <illegal opcode> 6 : (Lme/stupitdog/bhp/f11;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   154: aload_0
    //   155: aload_0
    //   156: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   159: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   162: bipush #11
    //   164: iaload
    //   165: aaload
    //   166: ldc2_w 7.0
    //   169: ldc2_w -20.0
    //   172: ldc2_w 20.0
    //   175: <illegal opcode> 7 : (Lme/stupitdog/bhp/f11;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   180: <illegal opcode> 8 : (Lme/stupitdog/bhp/f11;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   185: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	186	0	lllllllllllllllIlllIlIIlIIlIIlIl	Lme/stupitdog/bhp/f11;
    //   8	178	1	lllllllllllllllIlllIlIIlIIlIIlII	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	178	1	lllllllllllllllIlllIlIIlIIlIIlII	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onEnable : ()V
    //   4: aload_0
    //   5: aload_0
    //   6: <illegal opcode> 9 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   11: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   16: <illegal opcode> 11 : (Lme/stupitdog/bhp/f11;Ljava/lang/String;)V
    //   21: aload_0
    //   22: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   25: iconst_0
    //   26: iaload
    //   27: <illegal opcode> 12 : (Lme/stupitdog/bhp/f11;I)V
    //   32: aload_0
    //   33: new net/minecraft/util/math/BlockPos
    //   36: dup
    //   37: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   42: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   47: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   52: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   57: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   62: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   67: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   72: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   77: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   82: invokespecial <init> : (DDD)V
    //   85: <illegal opcode> 18 : (Lme/stupitdog/bhp/f11;Lnet/minecraft/util/math/BlockPos;)V
    //   90: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   95: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   100: new net/minecraft/util/math/BlockPos
    //   103: dup
    //   104: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   109: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   114: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   119: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   124: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   129: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   134: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   139: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   144: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   149: invokespecial <init> : (DDD)V
    //   152: <illegal opcode> 20 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   157: <illegal opcode> 21 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   162: <illegal opcode> 22 : ()Lnet/minecraft/block/Block;
    //   167: <illegal opcode> 23 : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   172: invokestatic lllllIllIlIlIlI : (I)Z
    //   175: ifeq -> 194
    //   178: aload_0
    //   179: aload_0
    //   180: <illegal opcode> 24 : (Lme/stupitdog/bhp/f11;)Lnet/minecraft/util/math/BlockPos;
    //   185: invokespecial intersectsWithEntity : (Lnet/minecraft/util/math/BlockPos;)Z
    //   188: invokestatic lllllIllIlIlIll : (I)Z
    //   191: ifeq -> 201
    //   194: aload_0
    //   195: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   200: return
    //   201: aload_0
    //   202: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   207: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   212: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   217: <illegal opcode> 27 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   222: <illegal opcode> 1 : (Lme/stupitdog/bhp/f11;I)V
    //   227: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	228	0	lllllllllllllllIlllIlIIlIIlIIIll	Lme/stupitdog/bhp/f11;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 9 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   17: bipush #12
    //   19: iaload
    //   20: aaload
    //   21: <illegal opcode> 28 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   26: invokestatic lllllIllIlIlIll : (I)Z
    //   29: ifeq -> 634
    //   32: ldc net/minecraft/block/BlockObsidian
    //   34: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   39: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   42: iconst_3
    //   43: iaload
    //   44: invokestatic lllllIllIlIllIl : (II)Z
    //   47: ifeq -> 72
    //   50: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   53: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   56: bipush #13
    //   58: iaload
    //   59: aaload
    //   60: <illegal opcode> 30 : (Ljava/lang/String;)V
    //   65: aload_0
    //   66: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   71: return
    //   72: aload_0
    //   73: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   78: invokestatic lllllIllIlIlIlI : (I)Z
    //   81: ifeq -> 585
    //   84: ldc net/minecraft/block/BlockObsidian
    //   86: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   91: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   94: iconst_0
    //   95: iaload
    //   96: <illegal opcode> 32 : (IZ)V
    //   101: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   106: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   111: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   116: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   119: dup
    //   120: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   125: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   130: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   135: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   140: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   145: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   150: ldc2_w 0.41999998688698
    //   153: dadd
    //   154: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   159: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   164: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   169: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   172: iconst_1
    //   173: iaload
    //   174: invokespecial <init> : (DDDZ)V
    //   177: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   182: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   187: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   192: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   197: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   200: dup
    //   201: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   206: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   211: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   216: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   221: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   226: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   231: ldc2_w 0.7531999805211997
    //   234: dadd
    //   235: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   240: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   245: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   250: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   253: iconst_1
    //   254: iaload
    //   255: invokespecial <init> : (DDDZ)V
    //   258: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   263: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   268: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   273: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   278: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   281: dup
    //   282: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   287: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   292: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   297: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   302: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   307: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   312: ldc2_w 1.00133597911214
    //   315: dadd
    //   316: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   321: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   326: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   331: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   334: iconst_1
    //   335: iaload
    //   336: invokespecial <init> : (DDDZ)V
    //   339: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   344: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   349: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   354: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   359: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   362: dup
    //   363: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   368: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   373: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   378: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   383: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   388: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   393: ldc2_w 1.16610926093821
    //   396: dadd
    //   397: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   402: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   407: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   412: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   415: iconst_1
    //   416: iaload
    //   417: invokespecial <init> : (DDDZ)V
    //   420: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   425: aload_0
    //   426: <illegal opcode> 24 : (Lme/stupitdog/bhp/f11;)Lnet/minecraft/util/math/BlockPos;
    //   431: <illegal opcode> 35 : ()Lnet/minecraft/util/EnumHand;
    //   436: aload_0
    //   437: <illegal opcode> 36 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   442: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   447: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   450: iconst_1
    //   451: iaload
    //   452: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   455: iconst_0
    //   456: iaload
    //   457: <illegal opcode> 38 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;ZZZ)Z
    //   462: ldc ''
    //   464: invokevirtual length : ()I
    //   467: pop2
    //   468: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   473: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   478: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   483: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   486: dup
    //   487: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   492: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   497: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   502: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   507: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   512: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   517: aload_0
    //   518: <illegal opcode> 39 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   523: <illegal opcode> 40 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   528: dadd
    //   529: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   534: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   539: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   544: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   547: iconst_0
    //   548: iaload
    //   549: invokespecial <init> : (DDDZ)V
    //   552: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   557: aload_0
    //   558: <illegal opcode> 41 : (Lme/stupitdog/bhp/f11;)I
    //   563: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   566: iconst_0
    //   567: iaload
    //   568: <illegal opcode> 32 : (IZ)V
    //   573: aload_0
    //   574: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   577: iconst_1
    //   578: iaload
    //   579: <illegal opcode> 12 : (Lme/stupitdog/bhp/f11;I)V
    //   584: return
    //   585: aload_0
    //   586: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   591: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   594: iconst_1
    //   595: iaload
    //   596: invokestatic lllllIllIlIllIl : (II)Z
    //   599: ifeq -> 634
    //   602: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   607: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   612: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   617: dconst_0
    //   618: invokestatic lllllIllIlIllII : (DD)I
    //   621: invokestatic lllllIllIlIlllI : (I)Z
    //   624: ifeq -> 634
    //   627: aload_0
    //   628: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   633: return
    //   634: aload_0
    //   635: <illegal opcode> 9 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   640: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   645: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   648: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   651: bipush #14
    //   653: iaload
    //   654: aaload
    //   655: <illegal opcode> 28 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   660: invokestatic lllllIllIlIlIll : (I)Z
    //   663: ifeq -> 1270
    //   666: ldc_w net/minecraft/block/BlockEnderChest
    //   669: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   674: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   677: iconst_3
    //   678: iaload
    //   679: invokestatic lllllIllIlIllIl : (II)Z
    //   682: ifeq -> 707
    //   685: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   688: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   691: bipush #15
    //   693: iaload
    //   694: aaload
    //   695: <illegal opcode> 30 : (Ljava/lang/String;)V
    //   700: aload_0
    //   701: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   706: return
    //   707: aload_0
    //   708: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   713: invokestatic lllllIllIlIlIlI : (I)Z
    //   716: ifeq -> 1221
    //   719: ldc_w net/minecraft/block/BlockWeb
    //   722: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   727: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   730: iconst_0
    //   731: iaload
    //   732: <illegal opcode> 32 : (IZ)V
    //   737: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   742: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   747: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   752: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   755: dup
    //   756: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   761: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   766: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   771: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   776: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   781: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   786: ldc2_w 0.41999998688698
    //   789: dadd
    //   790: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   795: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   800: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   805: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   808: iconst_1
    //   809: iaload
    //   810: invokespecial <init> : (DDDZ)V
    //   813: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   818: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   823: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   828: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   833: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   836: dup
    //   837: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   842: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   847: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   852: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   857: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   862: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   867: ldc2_w 0.7531999805211997
    //   870: dadd
    //   871: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   876: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   881: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   886: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   889: iconst_1
    //   890: iaload
    //   891: invokespecial <init> : (DDDZ)V
    //   894: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   899: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   904: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   909: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   914: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   917: dup
    //   918: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   923: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   928: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   933: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   938: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   943: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   948: ldc2_w 1.00133597911214
    //   951: dadd
    //   952: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   957: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   962: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   967: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   970: iconst_1
    //   971: iaload
    //   972: invokespecial <init> : (DDDZ)V
    //   975: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   980: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   985: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   990: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   995: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   998: dup
    //   999: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1004: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1009: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1014: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1019: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1024: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1029: ldc2_w 1.16610926093821
    //   1032: dadd
    //   1033: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1038: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1043: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1048: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1051: iconst_1
    //   1052: iaload
    //   1053: invokespecial <init> : (DDDZ)V
    //   1056: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1061: aload_0
    //   1062: <illegal opcode> 24 : (Lme/stupitdog/bhp/f11;)Lnet/minecraft/util/math/BlockPos;
    //   1067: <illegal opcode> 35 : ()Lnet/minecraft/util/EnumHand;
    //   1072: aload_0
    //   1073: <illegal opcode> 36 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1078: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1083: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1086: iconst_1
    //   1087: iaload
    //   1088: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1091: iconst_0
    //   1092: iaload
    //   1093: <illegal opcode> 38 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;ZZZ)Z
    //   1098: ldc ''
    //   1100: invokevirtual length : ()I
    //   1103: pop2
    //   1104: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1109: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1114: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1119: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1122: dup
    //   1123: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1128: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1133: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1138: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1143: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1148: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1153: aload_0
    //   1154: <illegal opcode> 39 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   1159: <illegal opcode> 40 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   1164: dadd
    //   1165: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1170: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1175: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1180: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1183: iconst_0
    //   1184: iaload
    //   1185: invokespecial <init> : (DDDZ)V
    //   1188: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1193: aload_0
    //   1194: <illegal opcode> 41 : (Lme/stupitdog/bhp/f11;)I
    //   1199: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1202: iconst_0
    //   1203: iaload
    //   1204: <illegal opcode> 32 : (IZ)V
    //   1209: aload_0
    //   1210: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1213: iconst_1
    //   1214: iaload
    //   1215: <illegal opcode> 12 : (Lme/stupitdog/bhp/f11;I)V
    //   1220: return
    //   1221: aload_0
    //   1222: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   1227: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1230: iconst_1
    //   1231: iaload
    //   1232: invokestatic lllllIllIlIllIl : (II)Z
    //   1235: ifeq -> 1270
    //   1238: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1243: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1248: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1253: dconst_0
    //   1254: invokestatic lllllIllIlIllII : (DD)I
    //   1257: invokestatic lllllIllIlIlllI : (I)Z
    //   1260: ifeq -> 1270
    //   1263: aload_0
    //   1264: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   1269: return
    //   1270: aload_0
    //   1271: <illegal opcode> 9 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   1276: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   1281: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   1284: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1287: bipush #16
    //   1289: iaload
    //   1290: aaload
    //   1291: <illegal opcode> 28 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   1296: invokestatic lllllIllIlIlIll : (I)Z
    //   1299: ifeq -> 1906
    //   1302: ldc_w net/minecraft/block/BlockWeb
    //   1305: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   1310: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1313: iconst_3
    //   1314: iaload
    //   1315: invokestatic lllllIllIlIllIl : (II)Z
    //   1318: ifeq -> 1343
    //   1321: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   1324: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1327: bipush #17
    //   1329: iaload
    //   1330: aaload
    //   1331: <illegal opcode> 30 : (Ljava/lang/String;)V
    //   1336: aload_0
    //   1337: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   1342: return
    //   1343: aload_0
    //   1344: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   1349: invokestatic lllllIllIlIlIlI : (I)Z
    //   1352: ifeq -> 1857
    //   1355: ldc_w net/minecraft/block/BlockWeb
    //   1358: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   1363: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1366: iconst_0
    //   1367: iaload
    //   1368: <illegal opcode> 32 : (IZ)V
    //   1373: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1378: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1383: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1388: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1391: dup
    //   1392: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1397: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1402: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1407: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1412: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1417: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1422: ldc2_w 0.41999998688698
    //   1425: dadd
    //   1426: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1431: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1436: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1441: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1444: iconst_1
    //   1445: iaload
    //   1446: invokespecial <init> : (DDDZ)V
    //   1449: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1454: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1459: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1464: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1469: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1472: dup
    //   1473: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1478: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1483: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1488: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1493: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1498: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1503: ldc2_w 0.7531999805211997
    //   1506: dadd
    //   1507: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1512: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1517: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1522: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1525: iconst_1
    //   1526: iaload
    //   1527: invokespecial <init> : (DDDZ)V
    //   1530: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1535: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1540: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1545: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1550: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1553: dup
    //   1554: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1559: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1564: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1569: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1574: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1579: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1584: ldc2_w 1.00133597911214
    //   1587: dadd
    //   1588: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1593: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1598: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1603: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1606: iconst_1
    //   1607: iaload
    //   1608: invokespecial <init> : (DDDZ)V
    //   1611: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1616: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1621: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1626: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1631: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1634: dup
    //   1635: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1640: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1645: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1650: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1655: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1660: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1665: ldc2_w 1.16610926093821
    //   1668: dadd
    //   1669: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1674: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1679: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1684: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1687: iconst_1
    //   1688: iaload
    //   1689: invokespecial <init> : (DDDZ)V
    //   1692: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1697: aload_0
    //   1698: <illegal opcode> 24 : (Lme/stupitdog/bhp/f11;)Lnet/minecraft/util/math/BlockPos;
    //   1703: <illegal opcode> 35 : ()Lnet/minecraft/util/EnumHand;
    //   1708: aload_0
    //   1709: <illegal opcode> 36 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1714: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1719: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1722: iconst_1
    //   1723: iaload
    //   1724: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1727: iconst_0
    //   1728: iaload
    //   1729: <illegal opcode> 38 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;ZZZ)Z
    //   1734: ldc ''
    //   1736: invokevirtual length : ()I
    //   1739: pop2
    //   1740: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1745: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1750: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1755: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1758: dup
    //   1759: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1764: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1769: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1774: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1779: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1784: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1789: aload_0
    //   1790: <illegal opcode> 39 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   1795: <illegal opcode> 40 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   1800: dadd
    //   1801: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1806: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1811: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1816: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1819: iconst_0
    //   1820: iaload
    //   1821: invokespecial <init> : (DDDZ)V
    //   1824: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1829: aload_0
    //   1830: <illegal opcode> 41 : (Lme/stupitdog/bhp/f11;)I
    //   1835: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1838: iconst_0
    //   1839: iaload
    //   1840: <illegal opcode> 32 : (IZ)V
    //   1845: aload_0
    //   1846: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1849: iconst_1
    //   1850: iaload
    //   1851: <illegal opcode> 12 : (Lme/stupitdog/bhp/f11;I)V
    //   1856: return
    //   1857: aload_0
    //   1858: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   1863: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1866: iconst_1
    //   1867: iaload
    //   1868: invokestatic lllllIllIlIllIl : (II)Z
    //   1871: ifeq -> 1906
    //   1874: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1879: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1884: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1889: dconst_0
    //   1890: invokestatic lllllIllIlIllII : (DD)I
    //   1893: invokestatic lllllIllIlIlllI : (I)Z
    //   1896: ifeq -> 1906
    //   1899: aload_0
    //   1900: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   1905: return
    //   1906: aload_0
    //   1907: <illegal opcode> 9 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   1912: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   1917: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   1920: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1923: bipush #18
    //   1925: iaload
    //   1926: aaload
    //   1927: <illegal opcode> 28 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   1932: invokestatic lllllIllIlIlIll : (I)Z
    //   1935: ifeq -> 2542
    //   1938: ldc_w net/minecraft/block/BlockSkull
    //   1941: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   1946: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1949: iconst_3
    //   1950: iaload
    //   1951: invokestatic lllllIllIlIllIl : (II)Z
    //   1954: ifeq -> 1979
    //   1957: getstatic me/stupitdog/bhp/f11.lIlllIllIlIIIl : [Ljava/lang/String;
    //   1960: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   1963: bipush #19
    //   1965: iaload
    //   1966: aaload
    //   1967: <illegal opcode> 30 : (Ljava/lang/String;)V
    //   1972: aload_0
    //   1973: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   1978: return
    //   1979: aload_0
    //   1980: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   1985: invokestatic lllllIllIlIlIlI : (I)Z
    //   1988: ifeq -> 2493
    //   1991: ldc_w net/minecraft/block/BlockSkull
    //   1994: <illegal opcode> 29 : (Ljava/lang/Class;)I
    //   1999: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2002: iconst_0
    //   2003: iaload
    //   2004: <illegal opcode> 32 : (IZ)V
    //   2009: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2014: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2019: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2024: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2027: dup
    //   2028: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2033: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2038: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2043: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2048: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2053: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2058: ldc2_w 0.41999998688698
    //   2061: dadd
    //   2062: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2067: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2072: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2077: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2080: iconst_1
    //   2081: iaload
    //   2082: invokespecial <init> : (DDDZ)V
    //   2085: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2090: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2095: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2100: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2105: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2108: dup
    //   2109: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2114: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2119: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2124: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2129: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2134: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2139: ldc2_w 0.7531999805211997
    //   2142: dadd
    //   2143: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2148: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2153: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2158: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2161: iconst_1
    //   2162: iaload
    //   2163: invokespecial <init> : (DDDZ)V
    //   2166: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2171: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2176: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2181: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2186: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2189: dup
    //   2190: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2195: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2200: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2205: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2210: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2215: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2220: ldc2_w 1.00133597911214
    //   2223: dadd
    //   2224: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2229: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2234: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2239: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2242: iconst_1
    //   2243: iaload
    //   2244: invokespecial <init> : (DDDZ)V
    //   2247: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2252: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2257: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2262: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2267: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2270: dup
    //   2271: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2276: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2281: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2286: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2291: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2296: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2301: ldc2_w 1.16610926093821
    //   2304: dadd
    //   2305: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2310: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2315: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2320: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2323: iconst_1
    //   2324: iaload
    //   2325: invokespecial <init> : (DDDZ)V
    //   2328: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2333: aload_0
    //   2334: <illegal opcode> 24 : (Lme/stupitdog/bhp/f11;)Lnet/minecraft/util/math/BlockPos;
    //   2339: <illegal opcode> 35 : ()Lnet/minecraft/util/EnumHand;
    //   2344: aload_0
    //   2345: <illegal opcode> 36 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   2350: <illegal opcode> 37 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   2355: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2358: iconst_1
    //   2359: iaload
    //   2360: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2363: iconst_0
    //   2364: iaload
    //   2365: <illegal opcode> 38 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;ZZZ)Z
    //   2370: ldc ''
    //   2372: invokevirtual length : ()I
    //   2375: pop2
    //   2376: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2381: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2386: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2391: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2394: dup
    //   2395: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2400: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2405: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2410: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2415: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2420: <illegal opcode> 16 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2425: aload_0
    //   2426: <illegal opcode> 39 : (Lme/stupitdog/bhp/f11;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   2431: <illegal opcode> 40 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   2436: dadd
    //   2437: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2442: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2447: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2452: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2455: iconst_0
    //   2456: iaload
    //   2457: invokespecial <init> : (DDDZ)V
    //   2460: <illegal opcode> 34 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2465: aload_0
    //   2466: <illegal opcode> 41 : (Lme/stupitdog/bhp/f11;)I
    //   2471: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2474: iconst_0
    //   2475: iaload
    //   2476: <illegal opcode> 32 : (IZ)V
    //   2481: aload_0
    //   2482: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2485: iconst_1
    //   2486: iaload
    //   2487: <illegal opcode> 12 : (Lme/stupitdog/bhp/f11;I)V
    //   2492: return
    //   2493: aload_0
    //   2494: <illegal opcode> 31 : (Lme/stupitdog/bhp/f11;)I
    //   2499: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   2502: iconst_1
    //   2503: iaload
    //   2504: invokestatic lllllIllIlIllIl : (II)Z
    //   2507: ifeq -> 2542
    //   2510: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   2515: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2520: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2525: dconst_0
    //   2526: invokestatic lllllIllIlIllII : (DD)I
    //   2529: invokestatic lllllIllIlIlllI : (I)Z
    //   2532: ifeq -> 2542
    //   2535: aload_0
    //   2536: <illegal opcode> 25 : (Lme/stupitdog/bhp/f11;)V
    //   2541: return
    //   2542: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	2543	0	lllllllllllllllIlllIlIIlIIlIIIlI	Lme/stupitdog/bhp/f11;
  }
  
  private boolean intersectsWithEntity(BlockPos lllllllllllllllIlllIlIIlIIIlllll) {
    // Byte code:
    //   0: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 43 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 44 : (Ljava/util/List;)Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: <illegal opcode> 45 : (Ljava/util/Iterator;)Z
    //   27: invokestatic lllllIllIlIlIll : (I)Z
    //   30: ifeq -> 401
    //   33: aload_2
    //   34: <illegal opcode> 46 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast net/minecraft/entity/Entity
    //   42: astore_3
    //   43: aload_3
    //   44: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   49: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   54: <illegal opcode> 47 : (Lnet/minecraft/entity/Entity;Ljava/lang/Object;)Z
    //   59: invokestatic lllllIllIlIlIll : (I)Z
    //   62: ifeq -> 118
    //   65: ldc ''
    //   67: invokevirtual length : ()I
    //   70: pop
    //   71: ldc_w ' '
    //   74: invokevirtual length : ()I
    //   77: ineg
    //   78: ldc_w ' '
    //   81: invokevirtual length : ()I
    //   84: ineg
    //   85: if_icmpeq -> 21
    //   88: sipush #219
    //   91: sipush #196
    //   94: ixor
    //   95: ldc_w ' '
    //   98: invokevirtual length : ()I
    //   101: ishl
    //   102: bipush #97
    //   104: bipush #126
    //   106: ixor
    //   107: ldc_w ' '
    //   110: invokevirtual length : ()I
    //   113: ishl
    //   114: iconst_m1
    //   115: ixor
    //   116: iand
    //   117: ireturn
    //   118: aload_3
    //   119: instanceof net/minecraft/entity/item/EntityItem
    //   122: invokestatic lllllIllIlIlIll : (I)Z
    //   125: ifeq -> 286
    //   128: ldc ''
    //   130: invokevirtual length : ()I
    //   133: pop
    //   134: sipush #244
    //   137: sipush #147
    //   140: ixor
    //   141: bipush #103
    //   143: bipush #120
    //   145: ixor
    //   146: ldc_w ' '
    //   149: invokevirtual length : ()I
    //   152: ldc_w ' '
    //   155: invokevirtual length : ()I
    //   158: ishl
    //   159: ishl
    //   160: ixor
    //   161: ldc_w ' '
    //   164: invokevirtual length : ()I
    //   167: ishl
    //   168: bipush #86
    //   170: bipush #83
    //   172: ixor
    //   173: ldc_w ' '
    //   176: invokevirtual length : ()I
    //   179: ldc_w ' '
    //   182: invokevirtual length : ()I
    //   185: ldc_w ' '
    //   188: invokevirtual length : ()I
    //   191: ishl
    //   192: ishl
    //   193: ishl
    //   194: bipush #62
    //   196: bipush #117
    //   198: ixor
    //   199: ixor
    //   200: ldc_w ' '
    //   203: invokevirtual length : ()I
    //   206: ishl
    //   207: ldc_w ' '
    //   210: invokevirtual length : ()I
    //   213: ineg
    //   214: ixor
    //   215: iand
    //   216: ifeq -> 21
    //   219: bipush #85
    //   221: bipush #101
    //   223: iadd
    //   224: bipush #116
    //   226: isub
    //   227: bipush #65
    //   229: iadd
    //   230: sipush #173
    //   233: sipush #186
    //   236: ixor
    //   237: ldc_w '   '
    //   240: invokevirtual length : ()I
    //   243: ishl
    //   244: ixor
    //   245: bipush #71
    //   247: sipush #154
    //   250: iadd
    //   251: bipush #73
    //   253: isub
    //   254: iconst_3
    //   255: iadd
    //   256: bipush #122
    //   258: bipush #83
    //   260: ixor
    //   261: ldc_w ' '
    //   264: invokevirtual length : ()I
    //   267: ldc_w ' '
    //   270: invokevirtual length : ()I
    //   273: ishl
    //   274: ishl
    //   275: ixor
    //   276: ldc_w ' '
    //   279: invokevirtual length : ()I
    //   282: ineg
    //   283: ixor
    //   284: iand
    //   285: ireturn
    //   286: new net/minecraft/util/math/AxisAlignedBB
    //   289: dup
    //   290: aload_1
    //   291: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   294: aload_3
    //   295: <illegal opcode> 48 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   300: <illegal opcode> 49 : (Lnet/minecraft/util/math/AxisAlignedBB;Lnet/minecraft/util/math/AxisAlignedBB;)Z
    //   305: invokestatic lllllIllIlIlIll : (I)Z
    //   308: ifeq -> 317
    //   311: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   314: iconst_1
    //   315: iaload
    //   316: ireturn
    //   317: ldc ''
    //   319: invokevirtual length : ()I
    //   322: pop
    //   323: ldc_w ' '
    //   326: invokevirtual length : ()I
    //   329: ldc_w ' '
    //   332: invokevirtual length : ()I
    //   335: ldc_w ' '
    //   338: invokevirtual length : ()I
    //   341: ldc_w ' '
    //   344: invokevirtual length : ()I
    //   347: ishl
    //   348: ishl
    //   349: if_icmplt -> 21
    //   352: ldc_w '   '
    //   355: invokevirtual length : ()I
    //   358: bipush #116
    //   360: bipush #127
    //   362: ixor
    //   363: ldc_w '   '
    //   366: invokevirtual length : ()I
    //   369: ishl
    //   370: ixor
    //   371: bipush #113
    //   373: bipush #108
    //   375: ixor
    //   376: sipush #157
    //   379: sipush #190
    //   382: ixor
    //   383: ldc_w ' '
    //   386: invokevirtual length : ()I
    //   389: ishl
    //   390: ixor
    //   391: ldc_w ' '
    //   394: invokevirtual length : ()I
    //   397: ineg
    //   398: ixor
    //   399: iand
    //   400: ireturn
    //   401: getstatic me/stupitdog/bhp/f11.lIlllIllIlIlIl : [I
    //   404: iconst_0
    //   405: iaload
    //   406: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	274	3	lllllllllllllllIlllIlIIlIIlIIIIl	Lnet/minecraft/entity/Entity;
    //   0	407	0	lllllllllllllllIlllIlIIlIIlIIIII	Lme/stupitdog/bhp/f11;
    //   0	407	1	lllllllllllllllIlllIlIIlIIIlllll	Lnet/minecraft/util/math/BlockPos;
  }
  
  static {
    lllllIllIlIlIIl();
    lllllIllIlIIlll();
    lllllIllIlIIllI();
    lllllIllIlIIIIl();
  }
  
  private static CallSite llllIlIIIlIIIll(MethodHandles.Lookup lllllllllllllllIlllIlIIlIIIlIlIl, String lllllllllllllllIlllIlIIlIIIlIlII, MethodType lllllllllllllllIlllIlIIlIIIlIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIIlIIIllIll = lIllIlIlllIIII[Integer.parseInt(lllllllllllllllIlllIlIIlIIIlIlII)].split(lIlllIllIlIIIl[lIlllIllIlIlIl[20]]);
      Class<?> lllllllllllllllIlllIlIIlIIIllIlI = Class.forName(lllllllllllllllIlllIlIIlIIIllIll[lIlllIllIlIlIl[0]]);
      String lllllllllllllllIlllIlIIlIIIllIIl = lllllllllllllllIlllIlIIlIIIllIll[lIlllIllIlIlIl[1]];
      MethodHandle lllllllllllllllIlllIlIIlIIIllIII = null;
      int lllllllllllllllIlllIlIIlIIIlIlll = lllllllllllllllIlllIlIIlIIIllIll[lIlllIllIlIlIl[4]].length();
      if (lllllIllIlIllll(lllllllllllllllIlllIlIIlIIIlIlll, lIlllIllIlIlIl[2])) {
        MethodType lllllllllllllllIlllIlIIlIIIlllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIIlIIIllIll[lIlllIllIlIlIl[2]], f11.class.getClassLoader());
        if (lllllIllIlIllIl(lllllllllllllllIlllIlIIlIIIlIlll, lIlllIllIlIlIl[2])) {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findVirtual(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllIl);
          "".length();
          if (((0x33 ^ 0x64) & (0x61 ^ 0x36 ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findStatic(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllIl);
        } 
        "".length();
        if (((0x82 ^ 0xA5) & (0x3E ^ 0x19 ^ 0xFFFFFFFF)) < ((0x58 ^ 0x5F) << "   ".length() & ((0x6B ^ 0x6C) << "   ".length() ^ 0xFFFFFFFF)))
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIIlIIIlllII = lIllIlIlllIIIl[Integer.parseInt(lllllllllllllllIlllIlIIlIIIllIll[lIlllIllIlIlIl[2]])];
        if (lllllIllIlIllIl(lllllllllllllllIlllIlIIlIIIlIlll, lIlllIllIlIlIl[4])) {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findGetter(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllII);
          "".length();
          if (" ".length() << " ".length() <= ((0x7C ^ 0x29) & (0xE9 ^ 0xBC ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllIllIlIllIl(lllllllllllllllIlllIlIIlIIIlIlll, lIlllIllIlIlIl[5])) {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findStaticGetter(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllII);
          "".length();
          if (-((0x98 ^ 0x91) << " ".length() << " ".length() << " ".length() ^ 59 + 43 - 55 + 102) >= 0)
            return null; 
        } else if (lllllIllIlIllIl(lllllllllllllllIlllIlIIlIIIlIlll, lIlllIllIlIlIl[6])) {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findSetter(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllII);
          "".length();
          if (((0xB5 ^ 0xA2) << " ".length() << " ".length() & ((0x43 ^ 0x54) << " ".length() << " ".length() ^ 0xFFFFFFFF)) >= " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIIlIIIllIII = lllllllllllllllIlllIlIIlIIIlIlIl.findStaticSetter(lllllllllllllllIlllIlIIlIIIllIlI, lllllllllllllllIlllIlIIlIIIllIIl, lllllllllllllllIlllIlIIlIIIlllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIIlIIIllIII);
    } catch (Exception lllllllllllllllIlllIlIIlIIIlIllI) {
      lllllllllllllllIlllIlIIlIIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIllIlIIIIl() {
    lIllIlIlllIIII = new String[lIlllIllIlIlIl[21]];
    lIllIlIlllIIII[lIlllIllIlIlIl[16]] = lIlllIllIlIIIl[lIlllIllIlIlIl[22]];
    lIllIlIlllIIII[lIlllIllIlIlIl[23]] = lIlllIllIlIIIl[lIlllIllIlIlIl[24]];
    lIllIlIlllIIII[lIlllIllIlIlIl[25]] = lIlllIllIlIIIl[lIlllIllIlIlIl[26]];
    lIllIlIlllIIII[lIlllIllIlIlIl[27]] = lIlllIllIlIIIl[lIlllIllIlIlIl[27]];
    lIllIlIlllIIII[lIlllIllIlIlIl[28]] = lIlllIllIlIIIl[lIlllIllIlIlIl[29]];
    lIllIlIlllIIII[lIlllIllIlIlIl[30]] = lIlllIllIlIIIl[lIlllIllIlIlIl[31]];
    lIllIlIlllIIII[lIlllIllIlIlIl[31]] = lIlllIllIlIIIl[lIlllIllIlIlIl[32]];
    lIllIlIlllIIII[lIlllIllIlIlIl[14]] = lIlllIllIlIIIl[lIlllIllIlIlIl[28]];
    lIllIlIlllIIII[lIlllIllIlIlIl[33]] = lIlllIllIlIIIl[lIlllIllIlIlIl[34]];
    lIllIlIlllIIII[lIlllIllIlIlIl[35]] = lIlllIllIlIIIl[lIlllIllIlIlIl[36]];
    lIllIlIlllIIII[lIlllIllIlIlIl[10]] = lIlllIllIlIIIl[lIlllIllIlIlIl[37]];
    lIllIlIlllIIII[lIlllIllIlIlIl[38]] = lIlllIllIlIIIl[lIlllIllIlIlIl[35]];
    lIllIlIlllIIII[lIlllIllIlIlIl[9]] = lIlllIllIlIIIl[lIlllIllIlIlIl[38]];
    lIllIlIlllIIII[lIlllIllIlIlIl[15]] = lIlllIllIlIIIl[lIlllIllIlIlIl[39]];
    lIllIlIlllIIII[lIlllIllIlIlIl[39]] = lIlllIllIlIIIl[lIlllIllIlIlIl[40]];
    lIllIlIlllIIII[lIlllIllIlIlIl[12]] = lIlllIllIlIIIl[lIlllIllIlIlIl[30]];
    lIllIlIlllIIII[lIlllIllIlIlIl[24]] = lIlllIllIlIIIl[lIlllIllIlIlIl[41]];
    lIllIlIlllIIII[lIlllIllIlIlIl[29]] = lIlllIllIlIIIl[lIlllIllIlIlIl[42]];
    lIllIlIlllIIII[lIlllIllIlIlIl[7]] = lIlllIllIlIIIl[lIlllIllIlIlIl[43]];
    lIllIlIlllIIII[lIlllIllIlIlIl[5]] = lIlllIllIlIIIl[lIlllIllIlIlIl[25]];
    lIllIlIlllIIII[lIlllIllIlIlIl[4]] = lIlllIllIlIIIl[lIlllIllIlIlIl[44]];
    lIllIlIlllIIII[lIlllIllIlIlIl[37]] = lIlllIllIlIIIl[lIlllIllIlIlIl[45]];
    lIllIlIlllIIII[lIlllIllIlIlIl[19]] = lIlllIllIlIIIl[lIlllIllIlIlIl[46]];
    lIllIlIlllIIII[lIlllIllIlIlIl[8]] = lIlllIllIlIIIl[lIlllIllIlIlIl[23]];
    lIllIlIlllIIII[lIlllIllIlIlIl[36]] = lIlllIllIlIIIl[lIlllIllIlIlIl[47]];
    lIllIlIlllIIII[lIlllIllIlIlIl[48]] = lIlllIllIlIIIl[lIlllIllIlIlIl[49]];
    lIllIlIlllIIII[lIlllIllIlIlIl[41]] = lIlllIllIlIIIl[lIlllIllIlIlIl[50]];
    lIllIlIlllIIII[lIlllIllIlIlIl[1]] = lIlllIllIlIIIl[lIlllIllIlIlIl[33]];
    lIllIlIlllIIII[lIlllIllIlIlIl[2]] = lIlllIllIlIIIl[lIlllIllIlIlIl[48]];
    lIllIlIlllIIII[lIlllIllIlIlIl[6]] = lIlllIllIlIIIl[lIlllIllIlIlIl[51]];
    lIllIlIlllIIII[lIlllIllIlIlIl[32]] = lIlllIllIlIIIl[lIlllIllIlIlIl[52]];
    lIllIlIlllIIII[lIlllIllIlIlIl[18]] = lIlllIllIlIIIl[lIlllIllIlIlIl[21]];
    lIllIlIlllIIII[lIlllIllIlIlIl[0]] = lIlllIllIlIIIl[lIlllIllIlIlIl[53]];
    lIllIlIlllIIII[lIlllIllIlIlIl[45]] = lIlllIllIlIIIl[lIlllIllIlIlIl[54]];
    lIllIlIlllIIII[lIlllIllIlIlIl[34]] = lIlllIllIlIIIl[lIlllIllIlIlIl[55]];
    lIllIlIlllIIII[lIlllIllIlIlIl[11]] = lIlllIllIlIIIl[lIlllIllIlIlIl[56]];
    lIllIlIlllIIII[lIlllIllIlIlIl[51]] = lIlllIllIlIIIl[lIlllIllIlIlIl[57]];
    lIllIlIlllIIII[lIlllIllIlIlIl[47]] = lIlllIllIlIIIl[lIlllIllIlIlIl[58]];
    lIllIlIlllIIII[lIlllIllIlIlIl[20]] = lIlllIllIlIIIl[lIlllIllIlIlIl[59]];
    lIllIlIlllIIII[lIlllIllIlIlIl[17]] = lIlllIllIlIIIl[lIlllIllIlIlIl[60]];
    lIllIlIlllIIII[lIlllIllIlIlIl[49]] = lIlllIllIlIIIl[lIlllIllIlIlIl[61]];
    lIllIlIlllIIII[lIlllIllIlIlIl[13]] = lIlllIllIlIIIl[lIlllIllIlIlIl[62]];
    lIllIlIlllIIII[lIlllIllIlIlIl[26]] = lIlllIllIlIIIl[lIlllIllIlIlIl[63]];
    lIllIlIlllIIII[lIlllIllIlIlIl[44]] = lIlllIllIlIIIl[lIlllIllIlIlIl[64]];
    lIllIlIlllIIII[lIlllIllIlIlIl[42]] = lIlllIllIlIIIl[lIlllIllIlIlIl[65]];
    lIllIlIlllIIII[lIlllIllIlIlIl[46]] = lIlllIllIlIIIl[lIlllIllIlIlIl[66]];
    lIllIlIlllIIII[lIlllIllIlIlIl[52]] = lIlllIllIlIIIl[lIlllIllIlIlIl[67]];
    lIllIlIlllIIII[lIlllIllIlIlIl[22]] = lIlllIllIlIIIl[lIlllIllIlIlIl[68]];
    lIllIlIlllIIII[lIlllIllIlIlIl[50]] = lIlllIllIlIIIl[lIlllIllIlIlIl[69]];
    lIllIlIlllIIII[lIlllIllIlIlIl[43]] = lIlllIllIlIIIl[lIlllIllIlIlIl[70]];
    lIllIlIlllIIII[lIlllIllIlIlIl[40]] = lIlllIllIlIIIl[lIlllIllIlIlIl[71]];
    lIllIlIlllIIIl = new Class[lIlllIllIlIlIl[17]];
    lIllIlIlllIIIl[lIlllIllIlIlIl[11]] = WorldClient.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[1]] = int.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[0]] = f13.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[14]] = NetHandlerPlayClient.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[10]] = BlockPos.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[15]] = EnumHand.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[12]] = Block.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[6]] = f100000000000000000000.Double.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[5]] = f100000000000000000000.Boolean.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[2]] = Listener.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[4]] = f100000000000000000000.Mode.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[8]] = EntityPlayerSP.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[9]] = double.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[16]] = List.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[7]] = Minecraft.class;
    lIllIlIlllIIIl[lIlllIllIlIlIl[13]] = InventoryPlayer.class;
  }
  
  private static void lllllIllIlIIllI() {
    lIlllIllIlIIIl = new String[lIlllIllIlIlIl[72]];
    lIlllIllIlIIIl[lIlllIllIlIlIl[0]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[0]], lIlllIllIlIlII[lIlllIllIlIlIl[1]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[1]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[2]], lIlllIllIlIlII[lIlllIllIlIlIl[4]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[2]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[5]], lIlllIllIlIlII[lIlllIllIlIlIl[6]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[4]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[7]], lIlllIllIlIlII[lIlllIllIlIlIl[8]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[5]] = lllllIllIlIIlII(lIlllIllIlIlII[lIlllIllIlIlIl[9]], lIlllIllIlIlII[lIlllIllIlIlIl[10]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[6]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[11]], lIlllIllIlIlII[lIlllIllIlIlIl[12]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[7]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[13]], lIlllIllIlIlII[lIlllIllIlIlIl[14]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[8]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[15]], lIlllIllIlIlII[lIlllIllIlIlIl[16]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[9]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[17]], lIlllIllIlIlII[lIlllIllIlIlIl[18]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[10]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[19]], lIlllIllIlIlII[lIlllIllIlIlIl[20]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[11]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[22]], lIlllIllIlIlII[lIlllIllIlIlIl[24]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[12]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[26]], lIlllIllIlIlII[lIlllIllIlIlIl[27]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[13]] = lllllIllIlIIlII(lIlllIllIlIlII[lIlllIllIlIlIl[29]], lIlllIllIlIlII[lIlllIllIlIlIl[31]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[14]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[32]], lIlllIllIlIlII[lIlllIllIlIlIl[28]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[15]] = lllllIllIlIIIll(lIlllIllIlIlII[lIlllIllIlIlIl[34]], lIlllIllIlIlII[lIlllIllIlIlIl[36]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[16]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[37]], lIlllIllIlIlII[lIlllIllIlIlIl[35]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[17]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[38]], lIlllIllIlIlII[lIlllIllIlIlIl[39]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[18]] = lllllIllIlIIIlI(lIlllIllIlIlII[lIlllIllIlIlIl[40]], lIlllIllIlIlII[lIlllIllIlIlIl[30]]);
    lIlllIllIlIIIl[lIlllIllIlIlIl[19]] = lllllIllIlIIlII("DUwvqEg3YJaXC8hnssYbGdfRggH3sVpprDwsAMc4ChwqkTijIkq1RQ==", "jODFJ");
    lIlllIllIlIIIl[lIlllIllIlIlIl[20]] = lllllIllIlIIIlI("JsUCA5juil4=", "JWoQq");
    lIlllIllIlIIIl[lIlllIllIlIlIl[22]] = lllllIllIlIIIll("PxcsYhU4HD0vCjAULGIbPRs9Igx/FzY4ESULdgkWJRssNSg9EyEpCgIiYioRNB48E09hQ255JyVIYHZYcVI=", "QrXLx");
    lIlllIllIlIIIl[lIlllIllIlIlIl[24]] = lllllIllIlIIIll("CCs2dxUPICc6CgcoNncbCicnNwxIIzc1DA8+LjgBAzxsDhcUIiYaFA8rLC1CACcnNRw5eXBgQVARJGNJU3RieVg=", "fNBYx");
    lIlllIllIlIIIl[lIlllIllIlIlIl[26]] = lllllIllIlIIIlI("I2dge12rLrl/Rk4Hfi54eFWtbRSRugpLgGSCWNpe5t9ZlVMCbZP7Nw==", "ziFlm");
    lIlllIllIlIIIl[lIlllIllIlIlIl[27]] = lllllIllIlIIlII("CVg5nnZfTxmpcoOy4mRQpPeKMtz0fnchhBnKGtazf0P2sxBeOVMgj34AxIKY+/1WMYaTr5iZp1I=", "xDBDR");
    lIlllIllIlIIIl[lIlllIllIlIlIl[29]] = lllllIllIlIIIlI("JnvRe1qL93ZhNFaijzwwu83x48PlqE6Ey/5owea8kBEqXh4p9G5CAzvTgEtTlbvMCpC2kEamodOCZLQlQruykw==", "XWcJa");
    lIlllIllIlIIIl[lIlllIllIlIlIl[31]] = lllllIllIlIIIlI("JIdetRLp18C02RRdYfEDdzH3xeIhdFloATXJ2p6MHHgXr+iezmSBxaliiB0p/AtK", "GjbbG");
    lIlllIllIlIIIl[lIlllIllIlIlIl[32]] = lllllIllIlIIlII("Wc50h18QTKH7Q3gxLaXZusn6qxa8g8QFyWzI1P+IrDdTrFV+XbPR6Q==", "JHYiD");
    lIlllIllIlIIIl[lIlllIllIlIlIl[28]] = lllllIllIlIIIll("CwdvGxATEigcAAkFbwoMFkwnWVVcDyJSUlxCYUhE", "fbAhd");
    lIlllIllIlIIIl[lIlllIllIlIlIl[34]] = lllllIllIlIIlII("up6wI4StEJdqs9CrTtTdV/aW/lbKwSh+VTzxS6D+uvro4mgdI9Dzk8UAH7KG2VRXAgdICKmC3i/TcXZxLPtzaA==", "CyZxM");
    lIlllIllIlIIIl[lIlllIllIlIlIl[36]] = lllllIllIlIIIll("JyR4Kzg/MT8sKCUmeDokOm8waX1wMiI5Ky97Z2JsamE=", "JAVXL");
    lIlllIllIlIIIl[lIlllIllIlIlIl[37]] = lllllIllIlIIIll("Ch9cOiISChs9MggdXCs+F1QUeGddFx0tM11JSGl2Rw==", "gzrIV");
    lIlllIllIlIIIl[lIlllIllIlIlIl[35]] = lllllIllIlIIIlI("banCSm3jfyyci3PEMEMLWIiQ/XziYECSg8tT0C5BJjF+jWfO1J91/a/HeEXn3zmT", "jZoeP");
    lIlllIllIlIIIl[lIlllIllIlIlIl[38]] = lllllIllIlIIIll("IxJWFR07BxESDSEQVgQBPlkeV1h0GB4AGisDQlNTbldYRkk=", "Nwxfi");
    lIlllIllIlIIIl[lIlllIllIlIlIl[39]] = lllllIllIlIIIlI("AZzr2HH2Wu2cihawARpMSadD6tJA9/XZFns2x1w22Al0hzU0OOlKDDFaHvBUDRSSLfsTNyB6JWQ=", "oPhDO");
    lIlllIllIlIIIl[lIlllIllIlIlIl[40]] = lllllIllIlIIIlI("9/6dvfD8gP4RoAeULszzPH5v+EXcUk3rYTPjezwCPrnTpqYUL/X93GKcAOi13GQpnRt4IutNjKOCRY/7LZx22w==", "lCzGf");
    lIlllIllIlIIIl[lIlllIllIlIlIl[30]] = lllllIllIlIIIlI("b9RXyhGZOq2TaoNgJ7ykBivSzZ53+q8y159PDOfTbEyavY0kWC3zyq+gx/bvwsUQE0CGCmLnpgILXljeIDF6cw==", "DbHbU");
    lIlllIllIlIIIl[lIlllIllIlIlIl[41]] = lllllIllIlIIlII("rHyk6FLsAEwnvrFsc15xsrOPOpU3RxYa803PLIkcr0wA9z7QNHeoDwPh6GX1av6HW0BQ6m4QWciIZ+fwrJhd9bwPViPBNJx/ekf6akZYu1oQYl3TrV0XGw==", "wtTrs");
    lIlllIllIlIIIl[lIlllIllIlIlIl[42]] = lllllIllIlIIlII("ooRnnFrk9/1HQ698vTMnx74RMhZRLorr09+L1Hmph1Znpr50ZPJ2OA==", "zFQlX");
    lIlllIllIlIIIl[lIlllIllIlIlIl[43]] = lllllIllIlIIIll("JCxWFjA8ORERICYuVgcsOWceVHVzOxcRJT0sQlF+aWlYRWQ=", "IIxeD");
    lIlllIllIlIIIl[lIlllIllIlIlIl[25]] = lllllIllIlIIIll("IAxJOB04GQ4/DSIOSSkBPUcBelh3BAgvDHdaXWtJbUlH", "MigKi");
    lIlllIllIlIIIl[lIlllIllIlIlIl[44]] = lllllIllIlIIlII("0uO5WAlMOvG3M5tzCPQogA7VgFccHrHelYo8by4A+l5dnJUs4txfFibSkH7DnPSxqYP0+vCpjLCRMEUowzKXdbDf2YCPVHU3G6C5GbVOV2mfGlnV0kIxRmg72Xk3s8FudaeS2BrKleQ1HjN2pOFQSA/89YMfxImBD/z1gx/EiYFHZvLkppHuh9T5xJr9vhJb", "WhNMv");
    lIlllIllIlIIIl[lIlllIllIlIlIl[45]] = lllllIllIlIIIll("GBVNPiMAAAo5MxoXTS8/BV4COW0GFQ0pFB0RFwglBx8RADIGAwIqMk9YLyc2AxFMITYbF0weIwcZDSpsXCZZbQ==", "upcMW");
    lIlllIllIlIIIl[lIlllIllIlIlIl[46]] = lllllIllIlIIlII("spvIeO5blBzpv7zEvW6raTQKmhdq8/pxzcAZ7uOPhorTNIMZ+YJ+n9ORwmMsuke2", "WcAHn");
    lIlllIllIlIIIl[lIlllIllIlIlIl[23]] = lllllIllIlIIIll("AC9LMAcYOgw3FwItSyEbHWQDckJXOAAkGh4+ADE3Aj8HLxZXYikpEhsrSi8SAy1KEAcfIwskSCkOIWo/AC9KMAcYOgw3FwItSiEbHWUDckNdelVzQ116VXNDXXpVc0NdelVzVyklECEfCHFfY1M=", "mJeCs");
    lIlllIllIlIIIl[lIlllIllIlIlIl[47]] = lllllIllIlIIIlI("7qodnkKmc4H38T9UlRv4SRrGo70Rw0B7WhOhbW9jf4BSjfK29ZUA41dLn0U93gwrXruht80OjG7Rv83Ez5oFfQ==", "OwjfC");
    lIlllIllIlIIIl[lIlllIllIlIlIl[49]] = lllllIllIlIIlII("Z+XpMNGEDwZpvV+DJ3z9K+3F7qG+sYdeBbhRqfT5XMddlc+8UpFSKoUe9gh/dJot6j1JDGsppy3KY899H5dnHu3d9OuPW/LgeKnhM/WovxGcUMReSORijw==", "bgNTa");
    lIlllIllIlIIIl[lIlllIllIlIlIl[50]] = lllllIllIlIIIll("CxVDMQMTAAQ2EwkXQyAfFl4Lc0ZcAgI2FhIVV3ZNRlBN", "fpmBw");
    lIlllIllIlIIIl[lIlllIllIlIlIl[33]] = lllllIllIlIIlII("CVwlrVyn7NdjPwrPxOoQLRTAlZMTsIgqKf2m/ixIAX0IrVxK8Jnxbg==", "TSwnp");
    lIlllIllIlIIIl[lIlllIllIlIlIl[48]] = lllllIllIlIIlII("62pDxR7C0Fvm1L5lzLnS96v/GIVhJZzCAKIZ58rsUPCZHE7LIKGBaYbPKcROeaQfiJWYunetvlk=", "laamY");
    lIlllIllIlIIIl[lIlllIllIlIlIl[51]] = lllllIllIlIIlII("YOfe+Ewa9GAOkG+AgAaX5KsX1bHrYwTe9qz7gnV3yc8xmNz42GOQl1LMdHCzktCP1F3rOaKu1VByZKXsP3YXvZJELD6lG1LQhJv8E7uksyvKcPilNcavWcpw+KU1xq9ZMK0/HhbAKID5gqMAh3Xktw==", "avqaL");
    lIlllIllIlIIIl[lIlllIllIlIlIl[52]] = lllllIllIlIIlII("0RyINwrRC7cDoP17Mt+kB/2COtIAxxU9VJkJwxXLfPyOUMC+d/0Qrkb67Rp6WXBN1PT4duT2nFwafhbMiLHDkvueBpNMueWt", "cvXup");
    lIlllIllIlIIIl[lIlllIllIlIlIl[21]] = lllllIllIlIIIll("Og41RDo9BSQJJTUNNUQ0OAIkBCN6Di8ePiASby85IAI1Ewc4CjgPJQc7eww+MQclNWBkWndbCCJReVB3dEs=", "TkAjW");
    lIlllIllIlIIIl[lIlllIllIlIlIl[53]] = lllllIllIlIIIll("KTZnJzoxIyAgKis0ZzYmNH0vZX1+FhEEAgsaHQd0dGlpdG5k", "DSITN");
    lIlllIllIlIIIl[lIlllIllIlIlIl[54]] = lllllIllIlIIlII("9JrkKLtkZHPqyGMUFT6FWv6+sKkjh8AnHNCJUCCbSOP894/UWWAGpg==", "BGCPu");
    lIlllIllIlIIIl[lIlllIllIlIlIl[55]] = lllllIllIlIIIll("BgAsJ08AADQhTz8VKC8PC1s/NxQNDSkPBgIOKCMiDRI/fEkgCzswAEMNOygGQzIuNAgCBmFvO1ZBeg==", "laZFa");
    lIlllIllIlIIIl[lIlllIllIlIlIl[56]] = lllllIllIlIIlII("TRRq7/FGYDUYmYbcvkhLrANSMqwf7kgcQFXqE3KkoKMzL/ZOLDvHMgCGF9lBNjSMaT9MKqjJdSFzj08Ag+01La2g24EurTAZfKVVLdgl/wQ=", "mYgdu");
    lIlllIllIlIIIl[lIlllIllIlIlIl[57]] = lllllIllIlIIlII("dpgAuv8dFRj7M08KBIlss4ETMp8/Zj+MGWchL+WjKaXO+nl7w427/buFEl1mMcB396l2VqS+Xkkt5AJN/VX83IKHx9mHWJyz2i/qc8wvLajPu4lx7ivNRfNy45Aie23jJ8vPa7apNqE=", "IfUAS");
    lIlllIllIlIIIl[lIlllIllIlIlIl[58]] = lllllIllIlIIlII("viKmXxAEnVRYH3ZnQXKgFmnJYLvshtXlhXT4vzIkkkv7tic3slnpqcLdAT+aPpruaA6O1TPVwHQ=", "gYUPx");
    lIlllIllIlIIIl[lIlllIllIlIlIl[59]] = lllllIllIlIIIlI("+ND+FzuIt/GndWvzEROY0xShi4Q/eS74OIbGpB/pfqGSw5kPoCXfw9oHBIwZPsGifvAuLhW3EQM=", "BiwwY");
    lIlllIllIlIIIl[lIlllIllIlIlIl[60]] = lllllIllIlIIIll("NhQ+bAMxHy8hHDkXPmwNNBgvLBp2FCQ2BywIZAcALBg+Oz40EDMnHAshcCQHPR0uHVloQHxxMS1LcnhOeFE=", "XqJBn");
    lIlllIllIlIIIl[lIlllIllIlIlIl[61]] = lllllIllIlIIlII("kzaTsTo+zxzA9sGr5OXKGZZVi0FxraL44QUL35qFgM4VEtpOf71rFQ==", "ofDhx");
    lIlllIllIlIIIl[lIlllIllIlIlIl[62]] = lllllIllIlIIlII("PMwmNdDPokakVDd3ZlCZbM3wtuNsiYcdK26wfafDPSS4PJY0sx5JIA==", "BOUwH");
    lIlllIllIlIIIl[lIlllIllIlIlIl[63]] = lllllIllIlIIIll("AR8nZTcGFDYoKA4cJ2UzARMnZRgDFTAgKVUcOi42CyVifmpcTmAUAFVLYnF6T1pz", "ozSKZ");
    lIlllIllIlIIIl[lIlllIllIlIlIl[64]] = lllllIllIlIIIll("CRFjMDwRBCQ3LAsTYyEgFForcnhURH1zeFREfXN4VER9c3hURH1zbCAbOCEkAU4qJjwyFSE2LV5cZAdyRFQ=", "dtMCH");
    lIlllIllIlIIIl[lIlllIllIlIlIl[65]] = lllllIllIlIIlII("qc/IixB5TN2x5+UnH4vnnWbu5l4Y4agYIEuOZJdbU0Kli+KzcL42498fNFLM+AJQZ0FqXFvAbfWWkLK2EAEU3Q==", "rViXT");
    lIlllIllIlIIIl[lIlllIllIlIlIl[66]] = lllllIllIlIIIlI("G35+G7HrpUv4Z2Qesn4vfKeAX1Kfhos/0vXQCteqILVlGb7lYLzDg2EydMCf/2kAF+JA8qFhzCcjWARODUoOhw==", "cKxCz");
    lIlllIllIlIIIl[lIlllIllIlIlIl[67]] = lllllIllIlIIIlI("N3cMcUx9+h3YWlAJJQI2v8kxaRHtlb5khDKkOhnpNYTFzWMcCSoNgaEhgD91+RpQCWk/cOE95VF2xfrmanUC6My7mYEkcHTxnME+3zQT+QlLqe5I+reJug==", "SlvDh");
    lIlllIllIlIIIl[lIlllIllIlIlIl[68]] = lllllIllIlIIIlI("EoyRQJDTZPbFd5VKAOLuytU3f5YBvx3F5Nm37IsD+YTq7GhjrD1ZPRPoB6GtjDZLbwLtf6BvPpfgGYfIf3KZKXgdVTPQ+oGGrB5DpfrZsllO99Klg4Z31CrgV9Sof9GqDhqdwxi2TApmqnxYbvC6LF8Ez9j7gEkcs0askqYrG9U06/pvFnk2jEv+DUy5fXuB", "kryos");
    lIlllIllIlIIIl[lIlllIllIlIlIl[69]] = lllllIllIlIIIlI("ifaPFwjQvYNdCc1VAphcgYawtuHRMpelALcdfiznvNFWePnrqhaMYcuw/CCLabBA", "jSQEY");
    lIlllIllIlIIIl[lIlllIllIlIlIl[70]] = lllllIllIlIIIlI("WI6wj+CEXwCct8vwp62MMAFdSe3/lT0Ap935zMx7m7dRPgAUA0/LQWNhDejdVQ5m/W5aswN7j5hBsSU7MkCncwSKsYABxUBUwxG9lN0yuYYObQiv+sYiqGm2Q9g8zCbBh42cLasA8S8=", "nwYxC");
    lIlllIllIlIIIl[lIlllIllIlIlIl[71]] = lllllIllIlIIIll("Bz0iVjsANjMbJAg+IlY1BTEzFiJHNjMMIQYqPVYYDCweGTgNNDMKBgU5Lzs6AD04DGwPLTgbCVhsYUpvXgc3Qn4lNjMMeQQxOB01GzkwDHkHPSIPORszeSg3CjMzDG1ADmxYdg==", "iXVxV");
    lIlllIllIlIlII = null;
  }
  
  private static void lllllIllIlIIlll() {
    String str = (new Exception()).getStackTrace()[lIlllIllIlIlIl[0]].getFileName();
    lIlllIllIlIlII = str.substring(str.indexOf("ä") + lIlllIllIlIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIllIlIIlII(String lllllllllllllllIlllIlIIlIIIIllll, String lllllllllllllllIlllIlIIlIIIIlllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIlIIIlIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIlIIIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIIlIIIlIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIIlIIIlIIIl.init(lIlllIllIlIlIl[2], lllllllllllllllIlllIlIIlIIIlIIlI);
      return new String(lllllllllllllllIlllIlIIlIIIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIlIIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIlIIIlIIII) {
      lllllllllllllllIlllIlIIlIIIlIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIllIlIIIll(String lllllllllllllllIlllIlIIlIIIIllII, String lllllllllllllllIlllIlIIlIIIIlIll) {
    lllllllllllllllIlllIlIIlIIIIllII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIIlIIIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIIlIIIIlIlI = new StringBuilder();
    char[] lllllllllllllllIlllIlIIlIIIIlIIl = lllllllllllllllIlllIlIIlIIIIlIll.toCharArray();
    int lllllllllllllllIlllIlIIlIIIIlIII = lIlllIllIlIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIIlIIIIllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIllIlIlIl[0];
    while (lllllIllIllIIII(j, i)) {
      char lllllllllllllllIlllIlIIlIIIIllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIIlIIIIlIII++;
      j++;
      "".length();
      if ("   ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIIlIIIIlIlI);
  }
  
  private static String lllllIllIlIIIlI(String lllllllllllllllIlllIlIIlIIIIIlII, String lllllllllllllllIlllIlIIlIIIIIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIlIIIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIlIIIIIIll.getBytes(StandardCharsets.UTF_8)), lIlllIllIlIlIl[9]), "DES");
      Cipher lllllllllllllllIlllIlIIlIIIIIllI = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIIlIIIIIllI.init(lIlllIllIlIlIl[2], lllllllllllllllIlllIlIIlIIIIIlll);
      return new String(lllllllllllllllIlllIlIIlIIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIlIIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIlIIIIIlIl) {
      lllllllllllllllIlllIlIIlIIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIllIlIlIIl() {
    lIlllIllIlIlIl = new int[73];
    lIlllIllIlIlIl[0] = ((0x94 ^ 0xBD) << " ".length() ^ 0x4E ^ 0x9) << " ".length() & (((0x2 ^ 0x13) << "   ".length() ^ 129 + 137 - 109 + 0) << " ".length() ^ -" ".length());
    lIlllIllIlIlIl[1] = " ".length();
    lIlllIllIlIlIl[2] = " ".length() << " ".length();
    lIlllIllIlIlIl[3] = -" ".length();
    lIlllIllIlIlIl[4] = "   ".length();
    lIlllIllIlIlIl[5] = " ".length() << " ".length() << " ".length();
    lIlllIllIlIlIl[6] = 0x69 ^ 0x6C;
    lIlllIllIlIlIl[7] = "   ".length() << " ".length();
    lIlllIllIlIlIl[8] = 0x86 ^ 0x81;
    lIlllIllIlIlIl[9] = " ".length() << "   ".length();
    lIlllIllIlIlIl[10] = (0xAB ^ 0x8A) << " ".length() << " ".length() ^ 92 + 0 - -30 + 19;
    lIlllIllIlIlIl[11] = ((0x82 ^ 0x8D) << " ".length() << " ".length() ^ 0x40 ^ 0x79) << " ".length();
    lIlllIllIlIlIl[12] = 0x36 ^ 0x3D;
    lIlllIllIlIlIl[13] = "   ".length() << " ".length() << " ".length();
    lIlllIllIlIlIl[14] = 0x62 ^ 0x6F;
    lIlllIllIlIlIl[15] = ((0xBA ^ 0xBF) << "   ".length() ^ 0x27 ^ 0x8) << " ".length();
    lIlllIllIlIlIl[16] = 0x3 ^ 0xC;
    lIlllIllIlIlIl[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIllIlIlIl[18] = (0x4A ^ 0x4D) << " ".length() << " ".length() ^ 0x37 ^ 0x3A;
    lIlllIllIlIlIl[19] = (0x8A ^ 0x83) << " ".length();
    lIlllIllIlIlIl[20] = " ".length() << (0x21 ^ 0x24) ^ 0x78 ^ 0x4B;
    lIlllIllIlIlIl[21] = 0x2 ^ 0x31;
    lIlllIllIlIlIl[22] = ((0x7A ^ 0x53) << " ".length() ^ 0x4D ^ 0x1A) << " ".length() << " ".length();
    lIlllIllIlIlIl[23] = 0x4E ^ 0x65;
    lIlllIllIlIlIl[24] = 0xB3 ^ 0xA6;
    lIlllIllIlIlIl[25] = 0x55 ^ 0x72;
    lIlllIllIlIlIl[26] = ((0x3 ^ 0x20) << " ".length() << " ".length() ^ 87 + 68 - 34 + 14) << " ".length();
    lIlllIllIlIlIl[27] = 154 + 81 - 62 + 12 ^ (0x78 ^ 0x2F) << " ".length();
    lIlllIllIlIlIl[28] = 0xBB ^ 0xA0;
    lIlllIllIlIlIl[29] = "   ".length() << "   ".length();
    lIlllIllIlIlIl[30] = 0x2C ^ 0xF;
    lIlllIllIlIlIl[31] = 0x17 ^ 0x76 ^ (0x78 ^ 0x77) << "   ".length();
    lIlllIllIlIlIl[32] = (0x6A ^ 0x31 ^ (0x75 ^ 0x5E) << " ".length()) << " ".length();
    lIlllIllIlIlIl[33] = 0x93 ^ 0xBC;
    lIlllIllIlIlIl[34] = (0x5E ^ 0x59) << " ".length() << " ".length();
    lIlllIllIlIlIl[35] = 0x88 ^ 0x97;
    lIlllIllIlIlIl[36] = 0x4C ^ 0x2B ^ (0x19 ^ 0x24) << " ".length();
    lIlllIllIlIlIl[37] = ((0xDB ^ 0xC0) << " ".length() ^ 0xC ^ 0x35) << " ".length();
    lIlllIllIlIlIl[38] = " ".length() << (0x93 ^ 0x96);
    lIlllIllIlIlIl[39] = 0x24 ^ 0x5;
    lIlllIllIlIlIl[40] = ("   ".length() << "   ".length() ^ 0xA7 ^ 0xAE) << " ".length();
    lIlllIllIlIlIl[41] = (0xAD ^ 0x86 ^ (0x25 ^ 0x34) << " ".length()) << " ".length() << " ".length();
    lIlllIllIlIlIl[42] = (0x4B ^ 0x40) << " ".length() << " ".length() ^ 0x8 ^ 0x1;
    lIlllIllIlIlIl[43] = (0x86 ^ 0x81 ^ (0x93 ^ 0x96) << " ".length() << " ".length()) << " ".length();
    lIlllIllIlIlIl[44] = (57 + 57 - 33 + 78 ^ (0x67 ^ 0x2A) << " ".length()) << "   ".length();
    lIlllIllIlIlIl[45] = 0xEC ^ 0xC5;
    lIlllIllIlIlIl[46] = (0x8F ^ 0x9A) << " ".length();
    lIlllIllIlIlIl[47] = ((0x6A ^ 0x7D) << " ".length() ^ 0x48 ^ 0x6D) << " ".length() << " ".length();
    lIlllIllIlIlIl[48] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIllIlIlIl[49] = "   ".length() << (0xA3 ^ 0xA6) ^ 0x3F ^ 0x72;
    lIlllIllIlIlIl[50] = ((0x9E ^ 0x99) << " ".length() << " ".length() ^ 0x77 ^ 0x7C) << " ".length();
    lIlllIllIlIlIl[51] = 0xE ^ 0x51 ^ (0x78 ^ 0x4F) << " ".length();
    lIlllIllIlIlIl[52] = (0x12 ^ 0xB) << " ".length();
    lIlllIllIlIlIl[53] = (0x3 ^ 0x56 ^ (0xB2 ^ 0xB9) << "   ".length()) << " ".length() << " ".length();
    lIlllIllIlIlIl[54] = 0x5D ^ 0x68;
    lIlllIllIlIlIl[55] = (0x4A ^ 0x51) << " ".length();
    lIlllIllIlIlIl[56] = 0x8C ^ 0xB7 ^ "   ".length() << " ".length() << " ".length();
    lIlllIllIlIlIl[57] = (194 + 139 - 227 + 91 ^ (0x1C ^ 0x7D) << " ".length()) << "   ".length();
    lIlllIllIlIlIl[58] = (0x51 ^ 0x56) << " ".length() ^ 0x74 ^ 0x43;
    lIlllIllIlIlIl[59] = (0x9B ^ 0x86) << " ".length();
    lIlllIllIlIlIl[60] = 0xA3 ^ 0x98;
    lIlllIllIlIlIl[61] = (0x7D ^ 0x72) << " ".length() << " ".length();
    lIlllIllIlIlIl[62] = (0xC ^ 0x7) << " ".length() << " ".length() ^ 0x91 ^ 0x80;
    lIlllIllIlIlIl[63] = (0x5B ^ 0x8 ^ (0x61 ^ 0x72) << " ".length() << " ".length()) << " ".length();
    lIlllIllIlIlIl[64] = 0xEF ^ 0x9C ^ (0x79 ^ 0x6A) << " ".length() << " ".length();
    lIlllIllIlIlIl[65] = " ".length() << "   ".length() << " ".length();
    lIlllIllIlIlIl[66] = 17 + 127 - 132 + 123 ^ (0x2E ^ 0x4D) << " ".length();
    lIlllIllIlIlIl[67] = (0xA2 ^ 0x83) << " ".length();
    lIlllIllIlIlIl[68] = 0x76 ^ 0x35;
    lIlllIllIlIlIl[69] = (0xD5 ^ 0xC4) << " ".length() << " ".length();
    lIlllIllIlIlIl[70] = 0x32 ^ 0x77;
    lIlllIllIlIlIl[71] = (0xE1 ^ 0xBC ^ (0x68 ^ 0x57) << " ".length()) << " ".length();
    lIlllIllIlIlIl[72] = 29 + 39 - -34 + 103 ^ (0x45 ^ 0x0) << " ".length();
  }
  
  private static boolean lllllIllIlIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIllIllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIllIlIllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIllIlIlIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIllIlIlIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIllIlIlllI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllIllIlIllII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f11.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */