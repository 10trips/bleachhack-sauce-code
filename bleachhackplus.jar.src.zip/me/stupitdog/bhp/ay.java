package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ay extends au {
  private static String[] llIIlIIlIIIIll;
  
  private static Class[] llIIlIIlIIIlII;
  
  private static final String[] llIIlIIlIIIlIl;
  
  private static String[] llIIlIIlIIIllI;
  
  private static final int[] llIIlIIlIIIlll;
  
  public ay() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/ay.llIIlIIlIIIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIllIllIlllIll	Lme/stupitdog/bhp/ay;
  }
  
  static {
    lIIIIllIIlllllII();
    lIIIIllIIllllIll();
    lIIIIllIIllllIlI();
    lIIIIllIIlllIlll();
  }
  
  private static CallSite lIIIIllIIlllIllI(MethodHandles.Lookup lllllllllllllllIllIIllIllIllIIlI, String lllllllllllllllIllIIllIllIllIIIl, MethodType lllllllllllllllIllIIllIllIllIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIllIlllIII = llIIlIIlIIIIll[Integer.parseInt(lllllllllllllllIllIIllIllIllIIIl)].split(llIIlIIlIIIlIl[llIIlIIlIIIlll[3]]);
      Class<?> lllllllllllllllIllIIllIllIllIlll = Class.forName(lllllllllllllllIllIIllIllIlllIII[llIIlIIlIIIlll[0]]);
      String lllllllllllllllIllIIllIllIllIllI = lllllllllllllllIllIIllIllIlllIII[llIIlIIlIIIlll[1]];
      MethodHandle lllllllllllllllIllIIllIllIllIlIl = null;
      int lllllllllllllllIllIIllIllIllIlII = lllllllllllllllIllIIllIllIlllIII[llIIlIIlIIIlll[3]].length();
      if (lIIIIllIIlllllIl(lllllllllllllllIllIIllIllIllIlII, llIIlIIlIIIlll[2])) {
        MethodType lllllllllllllllIllIIllIllIlllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIllIlllIII[llIIlIIlIIIlll[2]], ay.class.getClassLoader());
        if (lIIIIllIIllllllI(lllllllllllllllIllIIllIllIllIlII, llIIlIIlIIIlll[2])) {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findVirtual(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIlI);
          "".length();
          if (-"   ".length() > 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findStatic(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIlI);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIllIlllIIl = llIIlIIlIIIlII[Integer.parseInt(lllllllllllllllIllIIllIllIlllIII[llIIlIIlIIIlll[2]])];
        if (lIIIIllIIllllllI(lllllllllllllllIllIIllIllIllIlII, llIIlIIlIIIlll[3])) {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findGetter(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else if (lIIIIllIIllllllI(lllllllllllllllIllIIllIllIllIlII, llIIlIIlIIIlll[4])) {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findStaticGetter(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIIl);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else if (lIIIIllIIllllllI(lllllllllllllllIllIIllIllIllIlII, llIIlIIlIIIlll[5])) {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findSetter(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIIl);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIllIllIlIl = lllllllllllllllIllIIllIllIllIIlI.findStaticSetter(lllllllllllllllIllIIllIllIllIlll, lllllllllllllllIllIIllIllIllIllI, lllllllllllllllIllIIllIllIlllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIllIllIlIl);
    } catch (Exception lllllllllllllllIllIIllIllIllIIll) {
      lllllllllllllllIllIIllIllIllIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIlllIlll() {
    llIIlIIlIIIIll = new String[llIIlIIlIIIlll[1]];
    llIIlIIlIIIIll[llIIlIIlIIIlll[0]] = llIIlIIlIIIlIl[llIIlIIlIIIlll[4]];
    llIIlIIlIIIlII = new Class[llIIlIIlIIIlll[1]];
    llIIlIIlIIIlII[llIIlIIlIIIlll[0]] = f13.class;
  }
  
  private static void lIIIIllIIllllIlI() {
    llIIlIIlIIIlIl = new String[llIIlIIlIIIlll[5]];
    llIIlIIlIIIlIl[llIIlIIlIIIlll[0]] = lIIIIllIIllllIII(llIIlIIlIIIllI[llIIlIIlIIIlll[0]], llIIlIIlIIIllI[llIIlIIlIIIlll[1]]);
    llIIlIIlIIIlIl[llIIlIIlIIIlll[1]] = lIIIIllIIllllIII(llIIlIIlIIIllI[llIIlIIlIIIlll[2]], llIIlIIlIIIllI[llIIlIIlIIIlll[3]]);
    llIIlIIlIIIlIl[llIIlIIlIIIlll[2]] = lIIIIllIIllllIII(llIIlIIlIIIllI[llIIlIIlIIIlll[4]], llIIlIIlIIIllI[llIIlIIlIIIlll[5]]);
    llIIlIIlIIIlIl[llIIlIIlIIIlll[3]] = lIIIIllIIllllIIl(llIIlIIlIIIllI[llIIlIIlIIIlll[6]], llIIlIIlIIIllI[llIIlIIlIIIlll[7]]);
    llIIlIIlIIIlIl[llIIlIIlIIIlll[4]] = lIIIIllIIllllIII(llIIlIIlIIIllI[llIIlIIlIIIlll[8]], llIIlIIlIIIllI[llIIlIIlIIIlll[9]]);
    llIIlIIlIIIllI = null;
  }
  
  private static void lIIIIllIIllllIll() {
    String str = (new Exception()).getStackTrace()[llIIlIIlIIIlll[0]].getFileName();
    llIIlIIlIIIllI = str.substring(str.indexOf("ä") + llIIlIIlIIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIIllllIII(String lllllllllllllllIllIIllIllIlIllII, String lllllllllllllllIllIIllIllIlIlIll) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIllIlIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIllIlIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIllIlIlllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIllIlIlllI.init(llIIlIIlIIIlll[2], lllllllllllllllIllIIllIllIlIllll);
      return new String(lllllllllllllllIllIIllIllIlIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIllIlIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIllIlIllIl) {
      lllllllllllllllIllIIllIllIlIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIIllllIIl(String lllllllllllllllIllIIllIllIlIIlll, String lllllllllllllllIllIIllIllIlIIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIllIlIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIllIlIIllI.getBytes(StandardCharsets.UTF_8)), llIIlIIlIIIlll[8]), "DES");
      Cipher lllllllllllllllIllIIllIllIlIlIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIllIlIlIIl.init(llIIlIIlIIIlll[2], lllllllllllllllIllIIllIllIlIlIlI);
      return new String(lllllllllllllllIllIIllIllIlIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIllIlIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIllIlIlIII) {
      lllllllllllllllIllIIllIllIlIlIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIlllllII() {
    llIIlIIlIIIlll = new int[10];
    llIIlIIlIIIlll[0] = (0xC ^ 0x5) << " ".length() & ((0x1C ^ 0x15) << " ".length() ^ 0xFFFFFFFF);
    llIIlIIlIIIlll[1] = " ".length();
    llIIlIIlIIIlll[2] = " ".length() << " ".length();
    llIIlIIlIIIlll[3] = "   ".length();
    llIIlIIlIIIlll[4] = " ".length() << " ".length() << " ".length();
    llIIlIIlIIIlll[5] = 0x35 ^ 0x60 ^ (0x73 ^ 0x76) << " ".length() << " ".length() << " ".length();
    llIIlIIlIIIlll[6] = "   ".length() << " ".length();
    llIIlIIlIIIlll[7] = 0x22 ^ 0x25;
    llIIlIIlIIIlll[8] = " ".length() << "   ".length();
    llIIlIIlIIIlll[9] = 0x6F ^ 0x66;
  }
  
  private static boolean lIIIIllIIllllllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIIlllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */