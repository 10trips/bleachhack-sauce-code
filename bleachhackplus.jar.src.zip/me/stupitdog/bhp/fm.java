package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class fm extends fs {
  private BlockPos blockPos;
  
  private EnumFacing enumFacing;
  
  private static String[] lIllIlIlIIlIIl;
  
  private static Class[] lIllIlIlIIlIlI;
  
  private static final String[] lIllIlIlIIlIll;
  
  private static String[] lIllIlIlIIllII;
  
  private static final int[] lIllIlIlIIllIl;
  
  public fm(BlockPos lllllllllllllllIllllIlIllllIIIll, EnumFacing lllllllllllllllIllllIlIllllIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/fm;Lnet/minecraft/util/math/BlockPos;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/fm;Lnet/minecraft/util/EnumFacing;)V
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIllllIlIllllIIlII	Lme/stupitdog/bhp/fm;
    //   0	19	1	lllllllllllllllIllllIlIllllIIIll	Lnet/minecraft/util/math/BlockPos;
    //   0	19	2	lllllllllllllllIllllIlIllllIIIlI	Lnet/minecraft/util/EnumFacing;
  }
  
  public BlockPos getBlockPos() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lme/stupitdog/bhp/fm;)Lnet/minecraft/util/math/BlockPos;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIlIllllIIIIl	Lme/stupitdog/bhp/fm;
  }
  
  public void setBlockPos(BlockPos lllllllllllllllIllllIlIlllIlllll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Lme/stupitdog/bhp/fm;Lnet/minecraft/util/math/BlockPos;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIlIllllIIIII	Lme/stupitdog/bhp/fm;
    //   0	8	1	lllllllllllllllIllllIlIlllIlllll	Lnet/minecraft/util/math/BlockPos;
  }
  
  public EnumFacing getEnumFacing() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lme/stupitdog/bhp/fm;)Lnet/minecraft/util/EnumFacing;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIlIlllIllllI	Lme/stupitdog/bhp/fm;
  }
  
  public void setEnumFacing(EnumFacing lllllllllllllllIllllIlIlllIlllII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 1 : (Lme/stupitdog/bhp/fm;Lnet/minecraft/util/EnumFacing;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIlIlllIlllIl	Lme/stupitdog/bhp/fm;
    //   0	8	1	lllllllllllllllIllllIlIlllIlllII	Lnet/minecraft/util/EnumFacing;
  }
  
  static {
    llllIIllIllllll();
    llllIIllIlllllI();
    llllIIllIllllIl();
    llllIIllIlllIll();
  }
  
  private static CallSite llllIIllIlllIlI(MethodHandles.Lookup lllllllllllllllIllllIlIlllIlIIll, String lllllllllllllllIllllIlIlllIlIIlI, MethodType lllllllllllllllIllllIlIlllIlIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIlIlllIllIIl = lIllIlIlIIlIIl[Integer.parseInt(lllllllllllllllIllllIlIlllIlIIlI)].split(lIllIlIlIIlIll[lIllIlIlIIllIl[0]]);
      Class<?> lllllllllllllllIllllIlIlllIllIII = Class.forName(lllllllllllllllIllllIlIlllIllIIl[lIllIlIlIIllIl[0]]);
      String lllllllllllllllIllllIlIlllIlIlll = lllllllllllllllIllllIlIlllIllIIl[lIllIlIlIIllIl[1]];
      MethodHandle lllllllllllllllIllllIlIlllIlIllI = null;
      int lllllllllllllllIllllIlIlllIlIlIl = lllllllllllllllIllllIlIlllIllIIl[lIllIlIlIIllIl[2]].length();
      if (llllIIlllIIIIII(lllllllllllllllIllllIlIlllIlIlIl, lIllIlIlIIllIl[3])) {
        MethodType lllllllllllllllIllllIlIlllIllIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlIlllIllIIl[lIllIlIlIIllIl[3]], fm.class.getClassLoader());
        if (llllIIlllIIIIIl(lllllllllllllllIllllIlIlllIlIlIl, lIllIlIlIIllIl[3])) {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findVirtual(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIll);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findStatic(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIll);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIlIlllIllIlI = lIllIlIlIIlIlI[Integer.parseInt(lllllllllllllllIllllIlIlllIllIIl[lIllIlIlIIllIl[3]])];
        if (llllIIlllIIIIIl(lllllllllllllllIllllIlIlllIlIlIl, lIllIlIlIIllIl[2])) {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findGetter(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIlI);
          "".length();
          if (((0xB1 ^ 0xC6 ^ " ".length() << "   ".length() << " ".length()) & (0x3 ^ 0x7E ^ (0x15 ^ 0x30) << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (llllIIlllIIIIIl(lllllllllllllllIllllIlIlllIlIlIl, lIllIlIlIIllIl[4])) {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findStaticGetter(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIlI);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (llllIIlllIIIIIl(lllllllllllllllIllllIlIlllIlIlIl, lIllIlIlIIllIl[5])) {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findSetter(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIlI);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else {
          lllllllllllllllIllllIlIlllIlIllI = lllllllllllllllIllllIlIlllIlIIll.findStaticSetter(lllllllllllllllIllllIlIlllIllIII, lllllllllllllllIllllIlIlllIlIlll, lllllllllllllllIllllIlIlllIllIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIlIlllIlIllI);
    } catch (Exception lllllllllllllllIllllIlIlllIlIlII) {
      lllllllllllllllIllllIlIlllIlIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIllIlllIll() {
    lIllIlIlIIlIIl = new String[lIllIlIlIIllIl[4]];
    lIllIlIlIIlIIl[lIllIlIlIIllIl[0]] = lIllIlIlIIlIll[lIllIlIlIIllIl[1]];
    lIllIlIlIIlIIl[lIllIlIlIIllIl[1]] = lIllIlIlIIlIll[lIllIlIlIIllIl[3]];
    lIllIlIlIIlIIl[lIllIlIlIIllIl[3]] = lIllIlIlIIlIll[lIllIlIlIIllIl[2]];
    lIllIlIlIIlIIl[lIllIlIlIIllIl[2]] = lIllIlIlIIlIll[lIllIlIlIIllIl[4]];
    lIllIlIlIIlIlI = new Class[lIllIlIlIIllIl[3]];
    lIllIlIlIIlIlI[lIllIlIlIIllIl[0]] = BlockPos.class;
    lIllIlIlIIlIlI[lIllIlIlIIllIl[1]] = EnumFacing.class;
  }
  
  private static void llllIIllIllllIl() {
    lIllIlIlIIlIll = new String[lIllIlIlIIllIl[5]];
    lIllIlIlIIlIll[lIllIlIlIIllIl[0]] = llllIIllIllllII(lIllIlIlIIllII[lIllIlIlIIllIl[0]], lIllIlIlIIllII[lIllIlIlIIllIl[1]]);
    lIllIlIlIIlIll[lIllIlIlIIllIl[1]] = llllIIllIllllII(lIllIlIlIIllII[lIllIlIlIIllIl[3]], lIllIlIlIIllII[lIllIlIlIIllIl[2]]);
    lIllIlIlIIlIll[lIllIlIlIIllIl[3]] = llllIIllIllllII(lIllIlIlIIllII[lIllIlIlIIllIl[4]], lIllIlIlIIllII[lIllIlIlIIllIl[5]]);
    lIllIlIlIIlIll[lIllIlIlIIllIl[2]] = llllIIllIllllII(lIllIlIlIIllII[lIllIlIlIIllIl[6]], lIllIlIlIIllII[lIllIlIlIIllIl[7]]);
    lIllIlIlIIlIll[lIllIlIlIIllIl[4]] = llllIIllIllllII(lIllIlIlIIllII[lIllIlIlIIllIl[8]], lIllIlIlIIllII[lIllIlIlIIllIl[9]]);
    lIllIlIlIIllII = null;
  }
  
  private static void llllIIllIlllllI() {
    String str = (new Exception()).getStackTrace()[lIllIlIlIIllIl[0]].getFileName();
    lIllIlIlIIllII = str.substring(str.indexOf("ä") + lIllIlIlIIllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIllIllllII(String lllllllllllllllIllllIlIlllIIllIl, String lllllllllllllllIllllIlIlllIIllII) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIlllIlIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIlllIIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIlIlllIIllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIlIlllIIllll.init(lIllIlIlIIllIl[3], lllllllllllllllIllllIlIlllIlIIII);
      return new String(lllllllllllllllIllllIlIlllIIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIlllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIlllIIlllI) {
      lllllllllllllllIllllIlIlllIIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIllIllllll() {
    lIllIlIlIIllIl = new int[10];
    lIllIlIlIIllIl[0] = ((0x13 ^ 0xC) << " ".length() ^ 0x27 ^ 0x1C) & (0xAC ^ 0xA1 ^ " ".length() << "   ".length() ^ -" ".length());
    lIllIlIlIIllIl[1] = " ".length();
    lIllIlIlIIllIl[2] = "   ".length();
    lIllIlIlIIllIl[3] = " ".length() << " ".length();
    lIllIlIlIIllIl[4] = " ".length() << " ".length() << " ".length();
    lIllIlIlIIllIl[5] = 0x8 ^ 0x5F ^ (0x10 ^ 0x39) << " ".length();
    lIllIlIlIIllIl[6] = "   ".length() << " ".length();
    lIllIlIlIIllIl[7] = 0x9C ^ 0x9B;
    lIllIlIlIIllIl[8] = " ".length() << "   ".length();
    lIllIlIlIIllIl[9] = 0x36 ^ 0x4F ^ (0x1A ^ 0x1D) << " ".length() << " ".length() << " ".length();
  }
  
  private static boolean llllIIlllIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIlllIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */