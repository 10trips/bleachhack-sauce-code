package me.stupitdog.bhp;

import com.google.gson.JsonObject;
import com.lukflug.panelstudio.ConfigList;
import com.lukflug.panelstudio.PanelConfig;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ad implements ConfigList {
  private final String fileLocation;
  
  private JsonObject panelObject;
  
  private static String[] llIIIIIIIIllll;
  
  private static Class[] llIIIIIIIlIIII;
  
  private static final String[] llIIIIIIIlIIIl;
  
  private static String[] llIIIIIIIlIIll;
  
  private static final int[] llIIIIIIIlIlII;
  
  public ad(String lllllllllllllllIllIllllIlIIlIllI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aconst_null
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad;Lcom/google/gson/JsonObject;)V
    //   11: aload_0
    //   12: aload_1
    //   13: putfield fileLocation : Ljava/lang/String;
    //   16: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIllIllllIlIIlIlll	Lme/stupitdog/bhp/ad;
    //   0	17	1	lllllllllllllllIllIllllIlIIlIllI	Ljava/lang/String;
  }
  
  public void begin(boolean lllllllllllllllIllIllllIlIIlIIIl) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic lIIIIIIIlllllIIl : (I)Z
    //   4: ifeq -> 289
    //   7: new java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: aload_0
    //   15: <illegal opcode> 1 : (Lme/stupitdog/bhp/ad;)Ljava/lang/String;
    //   20: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   28: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   31: iconst_0
    //   32: iaload
    //   33: aaload
    //   34: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   44: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   47: iconst_0
    //   48: iaload
    //   49: anewarray java/lang/String
    //   52: <illegal opcode> 4 : (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    //   57: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   60: iconst_0
    //   61: iaload
    //   62: anewarray java/nio/file/LinkOption
    //   65: <illegal opcode> 5 : (Ljava/nio/file/Path;[Ljava/nio/file/LinkOption;)Z
    //   70: invokestatic lIIIIIIIlllllIlI : (I)Z
    //   73: ifeq -> 77
    //   76: return
    //   77: new java/lang/StringBuilder
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: aload_0
    //   85: <illegal opcode> 1 : (Lme/stupitdog/bhp/ad;)Ljava/lang/String;
    //   90: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   98: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   101: iconst_1
    //   102: iaload
    //   103: aaload
    //   104: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   114: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   117: iconst_0
    //   118: iaload
    //   119: anewarray java/lang/String
    //   122: <illegal opcode> 4 : (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;
    //   127: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   130: iconst_0
    //   131: iaload
    //   132: anewarray java/nio/file/OpenOption
    //   135: <illegal opcode> 6 : (Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Ljava/io/InputStream;
    //   140: astore_2
    //   141: new com/google/gson/JsonParser
    //   144: dup
    //   145: invokespecial <init> : ()V
    //   148: new java/io/InputStreamReader
    //   151: dup
    //   152: aload_2
    //   153: invokespecial <init> : (Ljava/io/InputStream;)V
    //   156: <illegal opcode> 7 : (Lcom/google/gson/JsonParser;Ljava/io/Reader;)Lcom/google/gson/JsonElement;
    //   161: <illegal opcode> 8 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonObject;
    //   166: astore_3
    //   167: aload_3
    //   168: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   171: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   174: iconst_2
    //   175: iaload
    //   176: aaload
    //   177: <illegal opcode> 9 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   182: invokestatic lIIIIIIIlllllIll : (Ljava/lang/Object;)Z
    //   185: ifeq -> 189
    //   188: return
    //   189: aload_0
    //   190: aload_3
    //   191: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   194: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   197: iconst_3
    //   198: iaload
    //   199: aaload
    //   200: <illegal opcode> 9 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   205: <illegal opcode> 8 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonObject;
    //   210: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad;Lcom/google/gson/JsonObject;)V
    //   215: aload_2
    //   216: <illegal opcode> 10 : (Ljava/io/InputStream;)V
    //   221: ldc ''
    //   223: invokevirtual length : ()I
    //   226: pop
    //   227: bipush #124
    //   229: sipush #151
    //   232: iadd
    //   233: sipush #238
    //   236: isub
    //   237: bipush #122
    //   239: iadd
    //   240: bipush #19
    //   242: bipush #94
    //   244: ixor
    //   245: ldc ' '
    //   247: invokevirtual length : ()I
    //   250: ishl
    //   251: ixor
    //   252: ifgt -> 302
    //   255: return
    //   256: astore_2
    //   257: aload_2
    //   258: <illegal opcode> 11 : (Ljava/io/IOException;)V
    //   263: ldc ''
    //   265: invokevirtual length : ()I
    //   268: pop
    //   269: ldc ' '
    //   271: invokevirtual length : ()I
    //   274: ldc ' '
    //   276: invokevirtual length : ()I
    //   279: ishl
    //   280: ldc '   '
    //   282: invokevirtual length : ()I
    //   285: if_icmple -> 302
    //   288: return
    //   289: aload_0
    //   290: new com/google/gson/JsonObject
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad;Lcom/google/gson/JsonObject;)V
    //   302: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   141	80	2	lllllllllllllllIllIllllIlIIlIlIl	Ljava/io/InputStream;
    //   167	54	3	lllllllllllllllIllIllllIlIIlIlII	Lcom/google/gson/JsonObject;
    //   257	6	2	lllllllllllllllIllIllllIlIIlIIll	Ljava/io/IOException;
    //   0	303	0	lllllllllllllllIllIllllIlIIlIIlI	Lme/stupitdog/bhp/ad;
    //   0	303	1	lllllllllllllllIllIllllIlIIlIIIl	Z
    // Exception table:
    //   from	to	target	type
    //   77	188	256	java/io/IOException
    //   189	221	256	java/io/IOException
  }
  
  public void end(boolean lllllllllllllllIllIllllIlIIIlIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   6: invokestatic lIIIIIIIlllllIll : (Ljava/lang/Object;)Z
    //   9: ifeq -> 13
    //   12: return
    //   13: iload_1
    //   14: invokestatic lIIIIIIIlllllIlI : (I)Z
    //   17: ifeq -> 189
    //   20: new com/google/gson/GsonBuilder
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: <illegal opcode> 13 : (Lcom/google/gson/GsonBuilder;)Lcom/google/gson/GsonBuilder;
    //   32: <illegal opcode> 14 : (Lcom/google/gson/GsonBuilder;)Lcom/google/gson/Gson;
    //   37: astore_2
    //   38: new java/io/OutputStreamWriter
    //   41: dup
    //   42: new java/io/FileOutputStream
    //   45: dup
    //   46: new java/lang/StringBuilder
    //   49: dup
    //   50: invokespecial <init> : ()V
    //   53: aload_0
    //   54: <illegal opcode> 1 : (Lme/stupitdog/bhp/ad;)Ljava/lang/String;
    //   59: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   67: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   70: iconst_4
    //   71: iaload
    //   72: aaload
    //   73: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: <illegal opcode> 3 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   83: invokespecial <init> : (Ljava/lang/String;)V
    //   86: <illegal opcode> 15 : ()Ljava/nio/charset/Charset;
    //   91: invokespecial <init> : (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V
    //   94: astore_3
    //   95: new com/google/gson/JsonObject
    //   98: dup
    //   99: invokespecial <init> : ()V
    //   102: astore #4
    //   104: aload #4
    //   106: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIIIl : [Ljava/lang/String;
    //   109: getstatic me/stupitdog/bhp/ad.llIIIIIIIlIlII : [I
    //   112: iconst_5
    //   113: iaload
    //   114: aaload
    //   115: aload_0
    //   116: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   121: <illegal opcode> 16 : (Lcom/google/gson/JsonObject;Ljava/lang/String;Lcom/google/gson/JsonElement;)V
    //   126: aload_2
    //   127: new com/google/gson/JsonParser
    //   130: dup
    //   131: invokespecial <init> : ()V
    //   134: aload #4
    //   136: <illegal opcode> 17 : (Lcom/google/gson/JsonObject;)Ljava/lang/String;
    //   141: <illegal opcode> 18 : (Lcom/google/gson/JsonParser;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   146: <illegal opcode> 19 : (Lcom/google/gson/Gson;Lcom/google/gson/JsonElement;)Ljava/lang/String;
    //   151: astore #5
    //   153: aload_3
    //   154: aload #5
    //   156: <illegal opcode> 20 : (Ljava/io/OutputStreamWriter;Ljava/lang/String;)V
    //   161: aload_3
    //   162: <illegal opcode> 21 : (Ljava/io/OutputStreamWriter;)V
    //   167: ldc ''
    //   169: invokevirtual length : ()I
    //   172: pop
    //   173: ldc ' '
    //   175: invokevirtual length : ()I
    //   178: ifgt -> 189
    //   181: return
    //   182: astore_2
    //   183: aload_2
    //   184: <illegal opcode> 11 : (Ljava/io/IOException;)V
    //   189: aload_0
    //   190: aconst_null
    //   191: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad;Lcom/google/gson/JsonObject;)V
    //   196: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   38	129	2	lllllllllllllllIllIllllIlIIlIIII	Lcom/google/gson/Gson;
    //   95	72	3	lllllllllllllllIllIllllIlIIIllll	Ljava/io/OutputStreamWriter;
    //   104	63	4	lllllllllllllllIllIllllIlIIIlllI	Lcom/google/gson/JsonObject;
    //   153	14	5	lllllllllllllllIllIllllIlIIIllIl	Ljava/lang/String;
    //   183	6	2	lllllllllllllllIllIllllIlIIIllII	Ljava/io/IOException;
    //   0	197	0	lllllllllllllllIllIllllIlIIIlIll	Lme/stupitdog/bhp/ad;
    //   0	197	1	lllllllllllllllIllIllllIlIIIlIlI	Z
    // Exception table:
    //   from	to	target	type
    //   20	167	182	java/io/IOException
  }
  
  public PanelConfig addPanel(String lllllllllllllllIllIllllIlIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   6: invokestatic lIIIIIIIlllllIll : (Ljava/lang/Object;)Z
    //   9: ifeq -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: new com/google/gson/JsonObject
    //   17: dup
    //   18: invokespecial <init> : ()V
    //   21: astore_2
    //   22: aload_0
    //   23: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   28: aload_1
    //   29: aload_2
    //   30: <illegal opcode> 16 : (Lcom/google/gson/JsonObject;Ljava/lang/String;Lcom/google/gson/JsonElement;)V
    //   35: new me/stupitdog/bhp/ad$BhpPanelConfig
    //   38: dup
    //   39: aload_2
    //   40: invokespecial <init> : (Lcom/google/gson/JsonObject;)V
    //   43: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	44	0	lllllllllllllllIllIllllIlIIIlIIl	Lme/stupitdog/bhp/ad;
    //   0	44	1	lllllllllllllllIllIllllIlIIIlIII	Ljava/lang/String;
    //   22	22	2	lllllllllllllllIllIllllIlIIIIlll	Lcom/google/gson/JsonObject;
  }
  
  public PanelConfig getPanel(String lllllllllllllllIllIllllIlIIIIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   6: invokestatic lIIIIIIIlllllIll : (Ljava/lang/Object;)Z
    //   9: ifeq -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload_0
    //   15: <illegal opcode> 12 : (Lme/stupitdog/bhp/ad;)Lcom/google/gson/JsonObject;
    //   20: aload_1
    //   21: <illegal opcode> 9 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
    //   26: astore_2
    //   27: aload_2
    //   28: invokestatic lIIIIIIIllllllII : (Ljava/lang/Object;)Z
    //   31: ifeq -> 60
    //   34: aload_2
    //   35: <illegal opcode> 22 : (Lcom/google/gson/JsonElement;)Z
    //   40: invokestatic lIIIIIIIlllllIIl : (I)Z
    //   43: ifeq -> 60
    //   46: new me/stupitdog/bhp/ad$BhpPanelConfig
    //   49: dup
    //   50: aload_2
    //   51: <illegal opcode> 8 : (Lcom/google/gson/JsonElement;)Lcom/google/gson/JsonObject;
    //   56: invokespecial <init> : (Lcom/google/gson/JsonObject;)V
    //   59: areturn
    //   60: aconst_null
    //   61: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	62	0	lllllllllllllllIllIllllIlIIIIllI	Lme/stupitdog/bhp/ad;
    //   0	62	1	lllllllllllllllIllIllllIlIIIIlIl	Ljava/lang/String;
    //   27	35	2	lllllllllllllllIllIllllIlIIIIlII	Lcom/google/gson/JsonElement;
  }
  
  static {
    lIIIIIIIlllllIII();
    lIIIIIIIllllIlIl();
    lIIIIIIIllllIlII();
    lIIIIIIIlllIllII();
  }
  
  private static CallSite lIIIIIIIlllIlIll(MethodHandles.Lookup lllllllllllllllIllIllllIIllllIll, String lllllllllllllllIllIllllIIllllIlI, MethodType lllllllllllllllIllIllllIIllllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllllIlIIIIIIl = llIIIIIIIIllll[Integer.parseInt(lllllllllllllllIllIllllIIllllIlI)].split(llIIIIIIIlIIIl[llIIIIIIIlIlII[6]]);
      Class<?> lllllllllllllllIllIllllIlIIIIIII = Class.forName(lllllllllllllllIllIllllIlIIIIIIl[llIIIIIIIlIlII[0]]);
      String lllllllllllllllIllIllllIIlllllll = lllllllllllllllIllIllllIlIIIIIIl[llIIIIIIIlIlII[1]];
      MethodHandle lllllllllllllllIllIllllIIllllllI = null;
      int lllllllllllllllIllIllllIIlllllIl = lllllllllllllllIllIllllIlIIIIIIl[llIIIIIIIlIlII[3]].length();
      if (lIIIIIIIllllllIl(lllllllllllllllIllIllllIIlllllIl, llIIIIIIIlIlII[2])) {
        MethodType lllllllllllllllIllIllllIlIIIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllllIlIIIIIIl[llIIIIIIIlIlII[2]], ad.class.getClassLoader());
        if (lIIIIIIIlllllllI(lllllllllllllllIllIllllIIlllllIl, llIIIIIIIlIlII[2])) {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findVirtual(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIll);
          "".length();
          if (" ".length() > " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findStatic(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIll);
        } 
        "".length();
        if (" ".length() << " ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllllIlIIIIIlI = llIIIIIIIlIIII[Integer.parseInt(lllllllllllllllIllIllllIlIIIIIIl[llIIIIIIIlIlII[2]])];
        if (lIIIIIIIlllllllI(lllllllllllllllIllIllllIIlllllIl, llIIIIIIIlIlII[3])) {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findGetter(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIlI);
          "".length();
          if (("   ".length() << " ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() << " ".length() ^ -" ".length()) & (((0x56 ^ 0x51) << " ".length() ^ 0xB3 ^ 0x80) & (0x2 ^ 0x59 ^ (0x66 ^ 0x55) << " ".length() ^ -" ".length()) ^ -" ".length())) != 0)
            return null; 
        } else if (lIIIIIIIlllllllI(lllllllllllllllIllIllllIIlllllIl, llIIIIIIIlIlII[4])) {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findStaticGetter(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIIlllllllI(lllllllllllllllIllIllllIIlllllIl, llIIIIIIIlIlII[5])) {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findSetter(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIlI);
          "".length();
          if (((0xF ^ 0x6) << " ".length() << " ".length() & ((0x69 ^ 0x60) << " ".length() << " ".length() ^ 0xFFFFFFFF)) >= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllllIIllllllI = lllllllllllllllIllIllllIIllllIll.findStaticSetter(lllllllllllllllIllIllllIlIIIIIII, lllllllllllllllIllIllllIIlllllll, lllllllllllllllIllIllllIlIIIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllllIIllllllI);
    } catch (Exception lllllllllllllllIllIllllIIlllllII) {
      lllllllllllllllIllIllllIIlllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIlllIllII() {
    llIIIIIIIIllll = new String[llIIIIIIIlIlII[7]];
    llIIIIIIIIllll[llIIIIIIIlIlII[8]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[8]];
    llIIIIIIIIllll[llIIIIIIIlIlII[9]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[10]];
    llIIIIIIIIllll[llIIIIIIIlIlII[6]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[11]];
    llIIIIIIIIllll[llIIIIIIIlIlII[12]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[13]];
    llIIIIIIIIllll[llIIIIIIIlIlII[13]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[14]];
    llIIIIIIIIllll[llIIIIIIIlIlII[15]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[9]];
    llIIIIIIIIllll[llIIIIIIIlIlII[10]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[16]];
    llIIIIIIIIllll[llIIIIIIIlIlII[17]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[15]];
    llIIIIIIIIllll[llIIIIIIIlIlII[1]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[18]];
    llIIIIIIIIllll[llIIIIIIIlIlII[18]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[19]];
    llIIIIIIIIllll[llIIIIIIIlIlII[3]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[20]];
    llIIIIIIIIllll[llIIIIIIIlIlII[11]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[21]];
    llIIIIIIIIllll[llIIIIIIIlIlII[4]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[22]];
    llIIIIIIIIllll[llIIIIIIIlIlII[2]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[12]];
    llIIIIIIIIllll[llIIIIIIIlIlII[5]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[17]];
    llIIIIIIIIllll[llIIIIIIIlIlII[16]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[23]];
    llIIIIIIIIllll[llIIIIIIIlIlII[22]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[7]];
    llIIIIIIIIllll[llIIIIIIIlIlII[19]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[24]];
    llIIIIIIIIllll[llIIIIIIIlIlII[14]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[25]];
    llIIIIIIIIllll[llIIIIIIIlIlII[23]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[26]];
    llIIIIIIIIllll[llIIIIIIIlIlII[0]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[27]];
    llIIIIIIIIllll[llIIIIIIIlIlII[20]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[28]];
    llIIIIIIIIllll[llIIIIIIIlIlII[21]] = llIIIIIIIlIIIl[llIIIIIIIlIlII[29]];
    llIIIIIIIlIIII = new Class[llIIIIIIIlIlII[3]];
    llIIIIIIIlIIII[llIIIIIIIlIlII[2]] = Charset.class;
    llIIIIIIIlIIII[llIIIIIIIlIlII[0]] = JsonObject.class;
    llIIIIIIIlIIII[llIIIIIIIlIlII[1]] = String.class;
  }
  
  private static void lIIIIIIIllllIlII() {
    llIIIIIIIlIIIl = new String[llIIIIIIIlIlII[30]];
    llIIIIIIIlIIIl[llIIIIIIIlIlII[0]] = lIIIIIIIlllIllIl(llIIIIIIIlIIll[llIIIIIIIlIlII[0]], llIIIIIIIlIIll[llIIIIIIIlIlII[1]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[1]] = lIIIIIIIlllIlllI(llIIIIIIIlIIll[llIIIIIIIlIlII[2]], llIIIIIIIlIIll[llIIIIIIIlIlII[3]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[2]] = lIIIIIIIlllIllIl(llIIIIIIIlIIll[llIIIIIIIlIlII[4]], llIIIIIIIlIIll[llIIIIIIIlIlII[5]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[3]] = lIIIIIIIlllIllll(llIIIIIIIlIIll[llIIIIIIIlIlII[6]], llIIIIIIIlIIll[llIIIIIIIlIlII[8]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[4]] = lIIIIIIIlllIllll(llIIIIIIIlIIll[llIIIIIIIlIlII[10]], llIIIIIIIlIIll[llIIIIIIIlIlII[11]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[5]] = lIIIIIIIlllIlllI(llIIIIIIIlIIll[llIIIIIIIlIlII[13]], llIIIIIIIlIIll[llIIIIIIIlIlII[14]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[6]] = lIIIIIIIlllIlllI(llIIIIIIIlIIll[llIIIIIIIlIlII[9]], llIIIIIIIlIIll[llIIIIIIIlIlII[16]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[8]] = lIIIIIIIlllIlllI(llIIIIIIIlIIll[llIIIIIIIlIlII[15]], llIIIIIIIlIIll[llIIIIIIIlIlII[18]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[10]] = lIIIIIIIlllIlllI(llIIIIIIIlIIll[llIIIIIIIlIlII[19]], llIIIIIIIlIIll[llIIIIIIIlIlII[20]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[11]] = lIIIIIIIlllIllIl(llIIIIIIIlIIll[llIIIIIIIlIlII[21]], llIIIIIIIlIIll[llIIIIIIIlIlII[22]]);
    llIIIIIIIlIIIl[llIIIIIIIlIlII[13]] = lIIIIIIIlllIlllI("IQMQGWsiDUg3MD8SEwwWPxADGSgcEA8MIDlYEQosPwdcUAkhAxAZaicDCB9qGBYUESssWU8uf2tC", "KbfxE");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[14]] = lIIIIIIIlllIllIl("llKCmu622i7SASS9l4REcdHPOvZ6HtOHySfty2aLpdCac1U0BUyZtA==", "BINSr");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[9]] = lIIIIIIIlllIlllI("LSoKdA0hKgA2D2AiFDUEYAIUNQQMMA42Dis3XTkYKyQTP1BmbCs5BSNqADUFKSkCdQ09Kgl1LT0qCWFQbmU=", "NEgZj");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[16]] = lIIIIIIIlllIllll("0pzQxXG4rWfrSCHHfQPPhcotOaFLaGvItKdipfU9jRbYB9rmgSqcdcuicjVTR3De6W/lKrwlthlbvQALTCEsJS9y5zDRfUPnkkzVs6FT7Wo=", "sYHak");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[15]] = lIIIIIIIlllIllll("xwx6h20d9vqKIwEmmWE2xdmziyvjQ1GCDppQ7tsGXc9qffNTsqYwvg==", "xFVGN");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[18]] = lIIIIIIIlllIlllI("Kh9HKicyCgAtNygdRzs7N1QIPWkhEwU8HygZCC06KBRTaGlnWkk=", "GziYS");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[19]] = lIIIIIIIlllIllIl("3gP2vtnWJBWM6XKWkEAy4dewk+oSM+5o7hz8sbYdgFwgH1I/KT3R2vlZZdA1tJYU", "kyBpu");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[20]] = lIIIIIIIlllIllll("z9/78JM8Ui0Z3XYBO2gosctpCcCFKF/XSwRgti8XUrcdBtcas7PSWsSGaIAUQr7xVwpn19g4BYfym2l2V+D+Kg==", "uAjiL");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[21]] = lIIIIIIIlllIllIl("yJ9TLsQEwwq6x6dqokjcH9amErXUp6rq+D27b7UgXIml0Pgxpne4nLdtcpeT2QBtfLDuobxgbKlKMDb4h865E20ZMm+g/hB6ZSwsLtYs9bfN+QgVxskSUw==", "SNznY");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[22]] = lIIIIIIIlllIllIl("T0Cyx8yAaRg2lRJzNiKGF45sA/PKD3JskC53rpJICu3pA2ULL1WuKSf/ArhuUVP3m3LLYK04DvqP9jKhMvueEU2jD39IkpFvv8KKDgK2QnTqw2gC+0YC1g==", "esrvo");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[12]] = lIIIIIIIlllIllll("CfvVnMzPp92LZ3CAlaQS7oFmfxJ5zG/p6scxKuI6N8TjDvIOwiloKpKyQLOAd2Bptb3aEzyoPuHgt6am8ap8tHkdz5fJAODEJPoqGXfKPXc=", "eRzbs");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[17]] = lIIIIIIIlllIlllI("KCU8I0IsLSVsCisoL2wqKygvMVYnPCMxGDF+Yg4GIzIrbQIrK2UkBS4hZRINNixxGSAoJTwjQywtJW0KKygvbSArKiENHDYtJSxXax5wYg==", "BDJBl");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[23]] = lIIIIIIIlllIllIl("EXE88867GXzFTKpz3cDJjBY7CM/+nkhqLmj+3cywet4gInH4a+6TFHHAvy+5oJtNPKqO0f48eNfkbnSb/NUi945Xkumh3gsShaz1cc117qVZHze3LnbjnQ==", "KNBZG");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[7]] = lIIIIIIIlllIlllI("KQsDZx8lCwklHWQDHSYWZCMdJhZwEAEDCyUKVGE0KQsDZh8lCwklHWUDHSYWZS4dJhYPCAskHSQQVWA0IAUYKFcmBQAuVxkQHCAWLV9UaVg=", "JdnIx");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[24]] = lIIIIIIIlllIllll("TwmhFDN1EF8Dw6v0q1XFENP9ZrXlNc2UbmUiX++IUI36RF+CJ6IonwUi1o2IC83hB5cLwffxa4ZzJXu8WPHwexRQouqCno5X9lNcnTMOWCc3p+KAoKyjbg==", "hjqqZ");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[25]] = lIIIIIIIlllIllll("qUK70tIqDbJJkOI8v4ZCcuTFWp3SVT75gbkO5BIv2B4JCDWtWZWRyYkdX5KeDR3X", "kEGAF");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[26]] = lIIIIIIIlllIllIl("yjZ4VSDZW/YEA6mEkA1MIyCbWEyLm+Ikn9qdtyMjxtyd8D7yPTIizKY78FaYSKyB", "GYhfl");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[27]] = lIIIIIIIlllIllIl("SRVS9rp9W2gUgacCoPW/tCj4YWnOMlI97PSI2x/fEU2a7pq6CFBevA==", "pLMgm");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[28]] = lIIIIIIIlllIlllI("Kik+ZRImKTQnEGchICQbZwwgJBsGJDkuFj18JyQmPTQ6JRJzbnoHHygwMmQZKCg0ZCY9NDolEnJ8c2s=", "IFSKu");
    llIIIIIIIlIIIl[llIIIIIIIlIlII[29]] = lIIIIIIIlllIllll("aaQXRlvQtqs/wz3MWsRm7F3VQuUNQjjPczZkBZ3UFqBagkHAHHdj/z+hBBQ3MgNW+E8Pn4d7H0xGbtD2JwKsWpJdGuw0M0QGk0Z7kPyZ4tLNq0Pbh2jEQQ==", "xTLtg");
    llIIIIIIIlIIll = null;
  }
  
  private static void lIIIIIIIllllIlIl() {
    String str = (new Exception()).getStackTrace()[llIIIIIIIlIlII[0]].getFileName();
    llIIIIIIIlIIll = str.substring(str.indexOf("ä") + llIIIIIIIlIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIlllIlllI(String lllllllllllllllIllIllllIIlllIlll, String lllllllllllllllIllIllllIIlllIllI) {
    lllllllllllllllIllIllllIIlllIlll = new String(Base64.getDecoder().decode(lllllllllllllllIllIllllIIlllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllllIIlllIlIl = new StringBuilder();
    char[] lllllllllllllllIllIllllIIlllIlII = lllllllllllllllIllIllllIIlllIllI.toCharArray();
    int lllllllllllllllIllIllllIIlllIIll = llIIIIIIIlIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllllIIlllIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIIlIlII[0];
    while (lIIIIIIIllllllll(j, i)) {
      char lllllllllllllllIllIllllIIllllIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllllIIlllIIll++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllllIIlllIlIl);
  }
  
  private static String lIIIIIIIlllIllIl(String lllllllllllllllIllIllllIIllIllll, String lllllllllllllllIllIllllIIllIlllI) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIIlllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIIllIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllllIIlllIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllllIIlllIIIl.init(llIIIIIIIlIlII[2], lllllllllllllllIllIllllIIlllIIlI);
      return new String(lllllllllllllllIllIllllIIlllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIIllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIIlllIIII) {
      lllllllllllllllIllIllllIIlllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIlllIllll(String lllllllllllllllIllIllllIIllIlIlI, String lllllllllllllllIllIllllIIllIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIIllIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIIllIlIIl.getBytes(StandardCharsets.UTF_8)), llIIIIIIIlIlII[10]), "DES");
      Cipher lllllllllllllllIllIllllIIllIllII = Cipher.getInstance("DES");
      lllllllllllllllIllIllllIIllIllII.init(llIIIIIIIlIlII[2], lllllllllllllllIllIllllIIllIllIl);
      return new String(lllllllllllllllIllIllllIIllIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIIllIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIIllIlIll) {
      lllllllllllllllIllIllllIIllIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIlllllIII() {
    llIIIIIIIlIlII = new int[31];
    llIIIIIIIlIlII[0] = (0x74 ^ 0x1F ^ (0x51 ^ 0x6C) << " ".length()) << " ".length() & (("   ".length() << " ".length() << " ".length() ^ 0x7F ^ 0x62) << " ".length() ^ -" ".length());
    llIIIIIIIlIlII[1] = " ".length();
    llIIIIIIIlIlII[2] = " ".length() << " ".length();
    llIIIIIIIlIlII[3] = "   ".length();
    llIIIIIIIlIlII[4] = " ".length() << " ".length() << " ".length();
    llIIIIIIIlIlII[5] = 92 + 137 - 194 + 110 ^ (0x18 ^ 0x3D) << " ".length() << " ".length();
    llIIIIIIIlIlII[6] = "   ".length() << " ".length();
    llIIIIIIIlIlII[7] = (0x54 ^ 0x4B) << " ".length() << " ".length() ^ 0xE0 ^ 0x8B;
    llIIIIIIIlIlII[8] = 0x57 ^ 0x50;
    llIIIIIIIlIlII[9] = "   ".length() << " ".length() << " ".length();
    llIIIIIIIlIlII[10] = " ".length() << "   ".length();
    llIIIIIIIlIlII[11] = 0x63 ^ 0x6A;
    llIIIIIIIlIlII[12] = ((0x23 ^ 0x34) << " ".length() << " ".length() ^ 0x1A ^ 0x43) << " ".length() << " ".length();
    llIIIIIIIlIlII[13] = ((0xF ^ 0x4) << " ".length() ^ 0xB5 ^ 0xA6) << " ".length();
    llIIIIIIIlIlII[14] = 0x1E ^ 0x15;
    llIIIIIIIlIlII[15] = (0x5C ^ 0x5B) << " ".length();
    llIIIIIIIlIlII[16] = 0x3E ^ 0x33;
    llIIIIIIIlIlII[17] = 0xA4 ^ 0xB1;
    llIIIIIIIlIlII[18] = 62 + 179 - 108 + 68 ^ (0xC9 ^ 0xAA) << " ".length();
    llIIIIIIIlIlII[19] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIIlIlII[20] = 0xA3 ^ 0xB2;
    llIIIIIIIlIlII[21] = (0x57 ^ 0x5E) << " ".length();
    llIIIIIIIlIlII[22] = 106 + 77 - 101 + 55 ^ (0x5F ^ 0x12) << " ".length();
    llIIIIIIIlIlII[23] = (0x51 ^ 0x5A) << " ".length();
    llIIIIIIIlIlII[24] = "   ".length() << "   ".length();
    llIIIIIIIlIlII[25] = (0xA0 ^ 0xBF) << " ".length() ^ 0x3D ^ 0x1A;
    llIIIIIIIlIlII[26] = (0x18 ^ 0x15) << " ".length();
    llIIIIIIIlIlII[27] = 0x76 ^ 0x6D;
    llIIIIIIIlIlII[28] = (0x9F ^ 0x86 ^ (0x38 ^ 0x37) << " ".length()) << " ".length() << " ".length();
    llIIIIIIIlIlII[29] = (0xD ^ 0x12) << " ".length() ^ 0x4D ^ 0x6E;
    llIIIIIIIlIlII[30] = ((0x8E ^ 0xBD) << " ".length() << " ".length() ^ 73 + 153 - 182 + 151) << " ".length();
  }
  
  private static boolean lIIIIIIIlllllllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIllllllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIllllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIllllllII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIIlllllIll(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIIIlllllIIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIIlllllIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static class BhpPanelConfig implements PanelConfig {
    private final JsonObject configObject;
    
    private static String[] llIIIllIIllIIl;
    
    private static Class[] llIIIllIIllIlI;
    
    private static final String[] llIIIllIlIllII;
    
    private static String[] llIIIllIlIlllI;
    
    private static final int[] llIIIllIlIllll;
    
    public BhpPanelConfig(JsonObject lllllllllllllllIllIlIIlIIllIllll) {
      this.configObject = lllllllllllllllIllIlIIlIIllIllll;
    }
    
    public void savePositon(Point lllllllllllllllIllIlIIlIIllIllIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   6: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   9: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   12: iconst_0
      //   13: iaload
      //   14: aaload
      //   15: new com/google/gson/JsonPrimitive
      //   18: dup
      //   19: aload_1
      //   20: <illegal opcode> 1 : (Ljava/awt/Point;)I
      //   25: <illegal opcode> 2 : (I)Ljava/lang/Integer;
      //   30: invokespecial <init> : (Ljava/lang/Number;)V
      //   33: <illegal opcode> 3 : (Lcom/google/gson/JsonObject;Ljava/lang/String;Lcom/google/gson/JsonElement;)V
      //   38: aload_0
      //   39: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   44: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   47: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   50: iconst_1
      //   51: iaload
      //   52: aaload
      //   53: new com/google/gson/JsonPrimitive
      //   56: dup
      //   57: aload_1
      //   58: <illegal opcode> 4 : (Ljava/awt/Point;)I
      //   63: <illegal opcode> 2 : (I)Ljava/lang/Integer;
      //   68: invokespecial <init> : (Ljava/lang/Number;)V
      //   71: <illegal opcode> 3 : (Lcom/google/gson/JsonObject;Ljava/lang/String;Lcom/google/gson/JsonElement;)V
      //   76: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	77	0	lllllllllllllllIllIlIIlIIllIlllI	Lme/stupitdog/bhp/ad$BhpPanelConfig;
      //   0	77	1	lllllllllllllllIllIlIIlIIllIllIl	Ljava/awt/Point;
    }
    
    public Point loadPosition() {
      // Byte code:
      //   0: new java/awt/Point
      //   3: dup
      //   4: invokespecial <init> : ()V
      //   7: astore_1
      //   8: aload_0
      //   9: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   14: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   17: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   20: iconst_2
      //   21: iaload
      //   22: aaload
      //   23: <illegal opcode> 5 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
      //   28: astore_2
      //   29: aload_2
      //   30: invokestatic lIIIIlIlIIIllIll : (Ljava/lang/Object;)Z
      //   33: ifeq -> 91
      //   36: aload_2
      //   37: <illegal opcode> 6 : (Lcom/google/gson/JsonElement;)Z
      //   42: invokestatic lIIIIlIlIIIlllII : (I)Z
      //   45: ifeq -> 91
      //   48: aload_1
      //   49: aload_2
      //   50: <illegal opcode> 7 : (Lcom/google/gson/JsonElement;)I
      //   55: putfield x : I
      //   58: ldc ''
      //   60: invokevirtual length : ()I
      //   63: pop
      //   64: ldc ' '
      //   66: invokevirtual length : ()I
      //   69: ldc ' '
      //   71: invokevirtual length : ()I
      //   74: ldc ' '
      //   76: invokevirtual length : ()I
      //   79: ishl
      //   80: ishl
      //   81: ldc ' '
      //   83: invokevirtual length : ()I
      //   86: if_icmpne -> 93
      //   89: aconst_null
      //   90: areturn
      //   91: aconst_null
      //   92: areturn
      //   93: aload_0
      //   94: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   99: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   102: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   105: iconst_3
      //   106: iaload
      //   107: aaload
      //   108: <illegal opcode> 5 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
      //   113: astore_3
      //   114: aload_3
      //   115: invokestatic lIIIIlIlIIIllIll : (Ljava/lang/Object;)Z
      //   118: ifeq -> 162
      //   121: aload_3
      //   122: <illegal opcode> 6 : (Lcom/google/gson/JsonElement;)Z
      //   127: invokestatic lIIIIlIlIIIlllII : (I)Z
      //   130: ifeq -> 162
      //   133: aload_1
      //   134: aload_3
      //   135: <illegal opcode> 7 : (Lcom/google/gson/JsonElement;)I
      //   140: putfield y : I
      //   143: ldc ''
      //   145: invokevirtual length : ()I
      //   148: pop
      //   149: sipush #194
      //   152: sipush #198
      //   155: ixor
      //   156: ineg
      //   157: ifle -> 164
      //   160: aconst_null
      //   161: areturn
      //   162: aconst_null
      //   163: areturn
      //   164: aload_1
      //   165: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	166	0	lllllllllllllllIllIlIIlIIllIllII	Lme/stupitdog/bhp/ad$BhpPanelConfig;
      //   8	158	1	lllllllllllllllIllIlIIlIIllIlIll	Ljava/awt/Point;
      //   29	137	2	lllllllllllllllIllIlIIlIIllIlIlI	Lcom/google/gson/JsonElement;
      //   114	52	3	lllllllllllllllIllIlIIlIIllIlIIl	Lcom/google/gson/JsonElement;
    }
    
    public void saveState(boolean lllllllllllllllIllIlIIlIIllIIlll) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   6: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   9: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   12: iconst_4
      //   13: iaload
      //   14: aaload
      //   15: new com/google/gson/JsonPrimitive
      //   18: dup
      //   19: iload_1
      //   20: <illegal opcode> 8 : (Z)Ljava/lang/Boolean;
      //   25: invokespecial <init> : (Ljava/lang/Boolean;)V
      //   28: <illegal opcode> 3 : (Lcom/google/gson/JsonObject;Ljava/lang/String;Lcom/google/gson/JsonElement;)V
      //   33: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	34	0	lllllllllllllllIllIlIIlIIllIlIII	Lme/stupitdog/bhp/ad$BhpPanelConfig;
      //   0	34	1	lllllllllllllllIllIlIIlIIllIIlll	Z
    }
    
    public boolean loadState() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/ad$BhpPanelConfig;)Lcom/google/gson/JsonObject;
      //   6: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllII : [Ljava/lang/String;
      //   9: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   12: iconst_5
      //   13: iaload
      //   14: aaload
      //   15: <illegal opcode> 5 : (Lcom/google/gson/JsonObject;Ljava/lang/String;)Lcom/google/gson/JsonElement;
      //   20: astore_1
      //   21: aload_1
      //   22: invokestatic lIIIIlIlIIIllIll : (Ljava/lang/Object;)Z
      //   25: ifeq -> 47
      //   28: aload_1
      //   29: <illegal opcode> 6 : (Lcom/google/gson/JsonElement;)Z
      //   34: invokestatic lIIIIlIlIIIlllII : (I)Z
      //   37: ifeq -> 47
      //   40: aload_1
      //   41: <illegal opcode> 9 : (Lcom/google/gson/JsonElement;)Z
      //   46: ireturn
      //   47: getstatic me/stupitdog/bhp/ad$BhpPanelConfig.llIIIllIlIllll : [I
      //   50: iconst_0
      //   51: iaload
      //   52: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	53	0	lllllllllllllllIllIlIIlIIllIIllI	Lme/stupitdog/bhp/ad$BhpPanelConfig;
      //   21	32	1	lllllllllllllllIllIlIIlIIllIIlIl	Lcom/google/gson/JsonElement;
    }
    
    static {
      lIIIIlIlIIIllIlI();
      lIIIIlIlIIIllIII();
      lIIIIlIlIIIlIlll();
      lIIIIlIlIIIlIIlI();
    }
    
    private static CallSite lIIIIlIIllIllllI(MethodHandles.Lookup lllllllllllllllIllIlIIlIIlIlllII, String lllllllllllllllIllIlIIlIIlIllIll, MethodType lllllllllllllllIllIlIIlIIlIllIlI) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllIlIIlIIllIIIlI = llIIIllIIllIIl[Integer.parseInt(lllllllllllllllIllIlIIlIIlIllIll)].split(llIIIllIlIllII[llIIIllIlIllll[6]]);
        Class<?> lllllllllllllllIllIlIIlIIllIIIIl = Class.forName(lllllllllllllllIllIlIIlIIllIIIlI[llIIIllIlIllll[0]]);
        String lllllllllllllllIllIlIIlIIllIIIII = lllllllllllllllIllIlIIlIIllIIIlI[llIIIllIlIllll[1]];
        MethodHandle lllllllllllllllIllIlIIlIIlIlllll = null;
        int lllllllllllllllIllIlIIlIIlIllllI = lllllllllllllllIllIlIIlIIllIIIlI[llIIIllIlIllll[3]].length();
        if (lIIIIlIlIIIlllIl(lllllllllllllllIllIlIIlIIlIllllI, llIIIllIlIllll[2])) {
          MethodType lllllllllllllllIllIlIIlIIllIIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIlIIllIIIlI[llIIIllIlIllll[2]], BhpPanelConfig.class.getClassLoader());
          if (lIIIIlIlIIIllllI(lllllllllllllllIllIlIIlIIlIllllI, llIIIllIlIllll[2])) {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findVirtual(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIlII);
            "".length();
            if (" ".length() << " ".length() == 0)
              return null; 
          } else {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findStatic(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIlII);
          } 
          "".length();
          if (-" ".length() >= " ".length() << " ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIllIlIIlIIllIIIll = llIIIllIIllIlI[Integer.parseInt(lllllllllllllllIllIlIIlIIllIIIlI[llIIIllIlIllll[2]])];
          if (lIIIIlIlIIIllllI(lllllllllllllllIllIlIIlIIlIllllI, llIIIllIlIllll[3])) {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findGetter(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIIll);
            "".length();
            if (" ".length() << " ".length() < 0)
              return null; 
          } else if (lIIIIlIlIIIllllI(lllllllllllllllIllIlIIlIIlIllllI, llIIIllIlIllll[4])) {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findStaticGetter(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIIll);
            "".length();
            if (-"  ".length() > 0)
              return null; 
          } else if (lIIIIlIlIIIllllI(lllllllllllllllIllIlIIlIIlIllllI, llIIIllIlIllll[5])) {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findSetter(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIIll);
            "".length();
            if ((((0x8A ^ 0xC3) << " ".length() ^ 108 + 91 - 155 + 145) & ((0x8A ^ 0xBD) << " ".length() ^ 0x66 ^ 0x27 ^ -" ".length())) >= " ".length() << " ".length() << " ".length())
              return null; 
          } else {
            lllllllllllllllIllIlIIlIIlIlllll = lllllllllllllllIllIlIIlIIlIlllII.findStaticSetter(lllllllllllllllIllIlIIlIIllIIIIl, lllllllllllllllIllIlIIlIIllIIIII, lllllllllllllllIllIlIIlIIllIIIll);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllIlIIlIIlIlllll);
      } catch (Exception lllllllllllllllIllIlIIlIIlIlllIl) {
        lllllllllllllllIllIlIIlIIlIlllIl.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIlIlIIIlIIlI() {
      llIIIllIIllIIl = new String[llIIIllIlIllll[7]];
      llIIIllIIllIIl[llIIIllIlIllll[8]] = llIIIllIlIllII[llIIIllIlIllll[9]];
      llIIIllIIllIIl[llIIIllIlIllll[1]] = llIIIllIlIllII[llIIIllIlIllll[8]];
      llIIIllIIllIIl[llIIIllIlIllll[10]] = llIIIllIlIllII[llIIIllIlIllll[10]];
      llIIIllIIllIIl[llIIIllIlIllll[6]] = llIIIllIlIllII[llIIIllIlIllll[7]];
      llIIIllIIllIIl[llIIIllIlIllll[5]] = llIIIllIlIllII[llIIIllIlIllll[11]];
      llIIIllIIllIIl[llIIIllIlIllll[2]] = llIIIllIlIllII[llIIIllIlIllll[12]];
      llIIIllIIllIIl[llIIIllIlIllll[3]] = llIIIllIlIllII[llIIIllIlIllll[13]];
      llIIIllIIllIIl[llIIIllIlIllll[0]] = llIIIllIlIllII[llIIIllIlIllll[14]];
      llIIIllIIllIIl[llIIIllIlIllll[9]] = llIIIllIlIllII[llIIIllIlIllll[15]];
      llIIIllIIllIIl[llIIIllIlIllll[4]] = llIIIllIlIllII[llIIIllIlIllll[16]];
      llIIIllIIllIlI = new Class[llIIIllIlIllll[2]];
      llIIIllIIllIlI[llIIIllIlIllll[1]] = int.class;
      llIIIllIIllIlI[llIIIllIlIllll[0]] = JsonObject.class;
    }
    
    private static void lIIIIlIlIIIlIlll() {
      llIIIllIlIllII = new String[llIIIllIlIllll[17]];
      llIIIllIlIllII[llIIIllIlIllll[0]] = lIIIIlIlIIIlIIll(llIIIllIlIlllI[llIIIllIlIllll[0]], llIIIllIlIlllI[llIIIllIlIllll[1]]);
      llIIIllIlIllII[llIIIllIlIllll[1]] = lIIIIlIlIIIlIIll(llIIIllIlIlllI[llIIIllIlIllll[2]], llIIIllIlIlllI[llIIIllIlIllll[3]]);
      llIIIllIlIllII[llIIIllIlIllll[2]] = lIIIIlIlIIIlIlII(llIIIllIlIlllI[llIIIllIlIllll[4]], llIIIllIlIlllI[llIIIllIlIllll[5]]);
      llIIIllIlIllII[llIIIllIlIllll[3]] = lIIIIlIlIIIlIIll(llIIIllIlIlllI[llIIIllIlIllll[6]], llIIIllIlIlllI[llIIIllIlIllll[9]]);
      llIIIllIlIllII[llIIIllIlIllll[4]] = lIIIIlIlIIIlIlIl(llIIIllIlIlllI[llIIIllIlIllll[8]], llIIIllIlIlllI[llIIIllIlIllll[10]]);
      llIIIllIlIllII[llIIIllIlIllll[5]] = lIIIIlIlIIIlIlII(llIIIllIlIlllI[llIIIllIlIllll[7]], llIIIllIlIlllI[llIIIllIlIllll[11]]);
      llIIIllIlIllII[llIIIllIlIllll[6]] = lIIIIlIlIIIlIlII(llIIIllIlIlllI[llIIIllIlIllll[12]], llIIIllIlIlllI[llIIIllIlIllll[13]]);
      llIIIllIlIllII[llIIIllIlIllll[9]] = lIIIIlIlIIIlIlII(llIIIllIlIlllI[llIIIllIlIllll[14]], llIIIllIlIlllI[llIIIllIlIllll[15]]);
      llIIIllIlIllII[llIIIllIlIllll[8]] = lIIIIlIlIIIlIIll(llIIIllIlIlllI[llIIIllIlIllll[16]], llIIIllIlIlllI[llIIIllIlIllll[17]]);
      llIIIllIlIllII[llIIIllIlIllll[10]] = lIIIIlIlIIIlIlII(llIIIllIlIlllI[llIIIllIlIllll[18]], llIIIllIlIlllI[llIIIllIlIllll[19]]);
      llIIIllIlIllII[llIIIllIlIllll[7]] = lIIIIlIlIIIlIIll(llIIIllIlIlllI[llIIIllIlIllll[20]], llIIIllIlIlllI[llIIIllIlIllll[21]]);
      llIIIllIlIllII[llIIIllIlIllll[11]] = lIIIIlIlIIIlIlII("EiCZdGUxluoJH7tg4NSA8qsDZoMYb1CrAe0jAELbZuCeq6Iv3H636I7Poj/C4y04Fh0CJ8gNlhTXzNNNhytbJVS6Oh6kYNYmWLCdV+n77rVMNgh4OcsEzg==", "jjHfN");
      llIIIllIlIllII[llIIIllIlIllll[12]] = lIIIIlIlIIIlIlIl("KCA0EXkuICwXeQsvNhUwJzN4BjYuNCc/MXhpC1kbKCA0EXguICwXeAsvNhUwJzN5Snc=", "BABpW");
      llIIIllIlIllII[llIIIllIlIllll[13]] = lIIIIlIlIIIlIlIl("CSUmbTAFJSwvMkQtOCw5RAA4LDklKCEmNB5wKiczUGIHKTYcK2QvNgQtZBAjGCMlJGwmKSQueA0lJCQ7D2UsMDgEZQEwOAQPJyY6DyQ/eH48cGtj", "jJKCW");
      llIIIllIlIllII[llIIIllIlIllll[14]] = lIIIIlIlIIIlIlII("PtX0MNuq3M67PPchNZNYVIgSoYwINFiMivg/W6kctqlVCvVKjKojSu301UyfrbZeygswpEQaM7Q=", "TiXEB");
      llIIIllIlIllII[llIIIllIlIllll[15]] = lIIIIlIlIIIlIlIl("KToGWyslOgwZKWQyGBoiZB8YGiIPOQ4YKSQhURIpPhQYPCI+b0NcBXB1Sw==", "JUkuL");
      llIIIllIlIllII[llIIIllIlIllll[16]] = lIIIIlIlIIIlIlII("yznu9YvgtZ5Z0HPDbzqt4XFoHtOz21IQ", "NNhwd");
      llIIIllIlIlllI = null;
    }
    
    private static void lIIIIlIlIIIllIII() {
      String str = (new Exception()).getStackTrace()[llIIIllIlIllll[0]].getFileName();
      llIIIllIlIlllI = str.substring(str.indexOf("ä") + llIIIllIlIllll[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lIIIIlIlIIIlIlII(String lllllllllllllllIllIlIIlIIlIlIllI, String lllllllllllllllIllIlIIlIIlIlIlIl) {
      try {
        SecretKeySpec lllllllllllllllIllIlIIlIIlIllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIlIlIlIl.getBytes(StandardCharsets.UTF_8)), llIIIllIlIllll[8]), "DES");
        Cipher lllllllllllllllIllIlIIlIIlIllIII = Cipher.getInstance("DES");
        lllllllllllllllIllIlIIlIIlIllIII.init(llIIIllIlIllll[2], lllllllllllllllIllIlIIlIIlIllIIl);
        return new String(lllllllllllllllIllIlIIlIIlIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIIlIIlIlIlll) {
        lllllllllllllllIllIlIIlIIlIlIlll.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIlIlIIIlIIll(String lllllllllllllllIllIlIIlIIlIlIIIl, String lllllllllllllllIllIlIIlIIlIlIIII) {
      try {
        SecretKeySpec lllllllllllllllIllIlIIlIIlIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIlIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIlIIlIIlIlIIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIlIIlIIlIlIIll.init(llIIIllIlIllll[2], lllllllllllllllIllIlIIlIIlIlIlII);
        return new String(lllllllllllllllIllIlIIlIIlIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIIlIIlIlIIlI) {
        lllllllllllllllIllIlIIlIIlIlIIlI.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIlIlIIIlIlIl(String lllllllllllllllIllIlIIlIIlIIlllI, String lllllllllllllllIllIlIIlIIlIIllIl) {
      lllllllllllllllIllIlIIlIIlIIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIlIIlIIlIIllII = new StringBuilder();
      char[] lllllllllllllllIllIlIIlIIlIIlIll = lllllllllllllllIllIlIIlIIlIIllIl.toCharArray();
      int lllllllllllllllIllIlIIlIIlIIlIlI = llIIIllIlIllll[0];
      char[] arrayOfChar1 = lllllllllllllllIllIlIIlIIlIIlllI.toCharArray();
      int i = arrayOfChar1.length;
      int j = llIIIllIlIllll[0];
      while (lIIIIlIlIIIlllll(j, i)) {
        char lllllllllllllllIllIlIIlIIlIIllll = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllIlIIlIIlIIlIlI++;
        j++;
        "".length();
        if (null != null)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllIlIIlIIlIIllII);
    }
    
    private static void lIIIIlIlIIIllIlI() {
      llIIIllIlIllll = new int[22];
      llIIIllIlIllll[0] = (0x49 ^ 0x7C ^ (0x6E ^ 0x69) << "   ".length()) << " ".length() & (((0x35 ^ 0x14) << " ".length() << " ".length() ^ 82 + 4 - 85 + 136) << " ".length() ^ -" ".length());
      llIIIllIlIllll[1] = " ".length();
      llIIIllIlIllll[2] = " ".length() << " ".length();
      llIIIllIlIllll[3] = "   ".length();
      llIIIllIlIllll[4] = " ".length() << " ".length() << " ".length();
      llIIIllIlIllll[5] = (0x9A ^ 0xAF) << " ".length() ^ 0xF7 ^ 0x98;
      llIIIllIlIllll[6] = "   ".length() << " ".length();
      llIIIllIlIllll[7] = (0x9C ^ 0x99) << " ".length();
      llIIIllIlIllll[8] = " ".length() << "   ".length();
      llIIIllIlIllll[9] = 0x95 ^ 0x92;
      llIIIllIlIllll[10] = 0x75 ^ 0x7C;
      llIIIllIlIllll[11] = 0x37 ^ 0x3C;
      llIIIllIlIllll[12] = "   ".length() << " ".length() << " ".length();
      llIIIllIlIllll[13] = 0x55 ^ 0x58;
      llIIIllIlIllll[14] = (0x1E ^ 0x31 ^ (0x1B ^ 0x1E) << "   ".length()) << " ".length();
      llIIIllIlIllll[15] = 0xCA ^ 0xC5;
      llIIIllIlIllll[16] = " ".length() << " ".length() << " ".length() << " ".length();
      llIIIllIlIllll[17] = 0x23 ^ 0x32;
      llIIIllIlIllll[18] = (0x30 ^ 0x39) << " ".length();
      llIIIllIlIllll[19] = 0x7C ^ 0x6F;
      llIIIllIlIllll[20] = (0x32 ^ 0x37) << " ".length() << " ".length();
      llIIIllIlIllll[21] = 0x13 ^ 0x6;
    }
    
    private static boolean lIIIIlIlIIIllllI(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lIIIIlIlIIIlllll(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lIIIIlIlIIIlllIl(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean lIIIIlIlIIIllIll(Object param1Object) {
      return (param1Object != null);
    }
    
    private static boolean lIIIIlIlIIIlllII(int param1Int) {
      return (param1Int != 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\ad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */