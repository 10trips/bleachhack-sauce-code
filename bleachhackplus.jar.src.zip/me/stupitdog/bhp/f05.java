package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Queue;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayer;

public class f05 extends au {
  Queue<CPacketPlayer> packets;
  
  @EventHandler
  public Listener<f100000000000.Send> listener;
  
  private EntityOtherPlayerMP clonedPlayer;
  
  private static String[] llIIIIlIlIIIIl;
  
  private static Class[] llIIIIlIlIIIlI;
  
  private static final String[] llIIIIllIIIlIl;
  
  private static String[] llIIIIllIIllIl;
  
  private static final int[] llIIIIllIlIIIl;
  
  public f05() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f05.llIIIIllIIIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f05.llIIIIllIIIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f05.llIIIIllIIIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new java/util/LinkedList
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f05;Ljava/util/Queue;)V
    //   54: aload_0
    //   55: new me/zero/alpine/listener/Listener
    //   58: dup
    //   59: aload_0
    //   60: <illegal opcode> invoke : (Lme/stupitdog/bhp/f05;)Lme/zero/alpine/listener/EventHook;
    //   65: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   68: iconst_0
    //   69: iaload
    //   70: anewarray java/util/function/Predicate
    //   73: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   76: <illegal opcode> 2 : (Lme/stupitdog/bhp/f05;Lme/zero/alpine/listener/Listener;)V
    //   81: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	82	0	lllllllllllllllIllIllIIIllIlIlII	Lme/stupitdog/bhp/f05;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIllIIIIIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 125
    //   16: aload_0
    //   17: new net/minecraft/client/entity/EntityOtherPlayerMP
    //   20: dup
    //   21: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   26: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   31: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   36: <illegal opcode> 6 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Session;
    //   41: <illegal opcode> 7 : (Lnet/minecraft/util/Session;)Lcom/mojang/authlib/GameProfile;
    //   46: invokespecial <init> : (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
    //   49: <illegal opcode> 8 : (Lme/stupitdog/bhp/f05;Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   54: aload_0
    //   55: <illegal opcode> 9 : (Lme/stupitdog/bhp/f05;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   60: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   65: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   70: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityOtherPlayerMP;Lnet/minecraft/entity/Entity;)V
    //   75: aload_0
    //   76: <illegal opcode> 9 : (Lme/stupitdog/bhp/f05;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   81: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   86: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   91: <illegal opcode> 11 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   96: putfield field_70759_as : F
    //   99: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   104: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   109: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   112: iconst_3
    //   113: iaload
    //   114: aload_0
    //   115: <illegal opcode> 9 : (Lme/stupitdog/bhp/f05;)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
    //   120: <illegal opcode> 12 : (Lnet/minecraft/client/multiplayer/WorldClient;ILnet/minecraft/entity/Entity;)V
    //   125: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	126	0	lllllllllllllllIllIllIIIllIlIIll	Lme/stupitdog/bhp/f05;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 13 : (Lme/stupitdog/bhp/f05;)Ljava/util/Queue;
    //   6: <illegal opcode> 14 : (Ljava/util/Queue;)Z
    //   11: invokestatic lIIIIIllIIIIIIIl : (I)Z
    //   14: ifeq -> 62
    //   17: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   32: aload_0
    //   33: <illegal opcode> 13 : (Lme/stupitdog/bhp/f05;)Ljava/util/Queue;
    //   38: <illegal opcode> 16 : (Ljava/util/Queue;)Ljava/lang/Object;
    //   43: checkcast net/minecraft/network/Packet
    //   46: <illegal opcode> 17 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   51: ldc ''
    //   53: invokevirtual length : ()I
    //   56: pop
    //   57: aconst_null
    //   58: ifnull -> 0
    //   61: return
    //   62: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   67: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   72: astore_1
    //   73: aload_1
    //   74: invokestatic lIIIIIllIIIIIIII : (Ljava/lang/Object;)Z
    //   77: ifeq -> 113
    //   80: <illegal opcode> 3 : ()Lnet/minecraft/client/Minecraft;
    //   85: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   90: getstatic me/stupitdog/bhp/f05.llIIIIllIlIIIl : [I
    //   93: iconst_3
    //   94: iaload
    //   95: <illegal opcode> 18 : (Lnet/minecraft/client/multiplayer/WorldClient;I)Lnet/minecraft/entity/Entity;
    //   100: ldc ''
    //   102: invokevirtual length : ()I
    //   105: pop2
    //   106: aload_0
    //   107: aconst_null
    //   108: <illegal opcode> 8 : (Lme/stupitdog/bhp/f05;Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
    //   113: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	114	0	lllllllllllllllIllIllIIIllIlIIlI	Lme/stupitdog/bhp/f05;
    //   73	41	1	lllllllllllllllIllIllIIIllIlIIIl	Lnet/minecraft/entity/player/EntityPlayer;
  }
  
  static {
    lIIIIIlIllllllll();
    lIIIIIlIllllIlII();
    lIIIIIlIllllIIlI();
    lIIIIIlIlllIIIIl();
  }
  
  private static CallSite lIIIIIlIIllllIll(MethodHandles.Lookup lllllllllllllllIllIllIIIllIIIllI, String lllllllllllllllIllIllIIIllIIIlIl, MethodType lllllllllllllllIllIllIIIllIIIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIIllIIllII = llIIIIlIlIIIIl[Integer.parseInt(lllllllllllllllIllIllIIIllIIIlIl)].split(llIIIIllIIIlIl[llIIIIllIlIIIl[4]]);
      Class<?> lllllllllllllllIllIllIIIllIIlIll = Class.forName(lllllllllllllllIllIllIIIllIIllII[llIIIIllIlIIIl[0]]);
      String lllllllllllllllIllIllIIIllIIlIlI = lllllllllllllllIllIllIIIllIIllII[llIIIIllIlIIIl[1]];
      MethodHandle lllllllllllllllIllIllIIIllIIlIIl = null;
      int lllllllllllllllIllIllIIIllIIlIII = lllllllllllllllIllIllIIIllIIllII[llIIIIllIlIIIl[4]].length();
      if (lIIIIIllIIIIIIll(lllllllllllllllIllIllIIIllIIlIII, llIIIIllIlIIIl[2])) {
        MethodType lllllllllllllllIllIllIIIllIIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIIllIIllII[llIIIIllIlIIIl[2]], f05.class.getClassLoader());
        if (lIIIIIllIIIIIlII(lllllllllllllllIllIllIIIllIIlIII, llIIIIllIlIIIl[2])) {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findVirtual(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIlllI);
          "".length();
          if (-" ".length() < -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findStatic(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIlllI);
        } 
        "".length();
        if ("   ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIIllIIllIl = llIIIIlIlIIIlI[Integer.parseInt(lllllllllllllllIllIllIIIllIIllII[llIIIIllIlIIIl[2]])];
        if (lIIIIIllIIIIIlII(lllllllllllllllIllIllIIIllIIlIII, llIIIIllIlIIIl[4])) {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findGetter(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIllIl);
          "".length();
          if (" ".length() == ((0x1 ^ 0x42 ^ (0x8 ^ 0x39) << " ".length()) << " ".length() & (("   ".length() ^ (0x61 ^ 0x70) << " ".length()) << " ".length() ^ -" ".length())))
            return null; 
        } else if (lIIIIIllIIIIIlII(lllllllllllllllIllIllIIIllIIlIII, llIIIIllIlIIIl[5])) {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findStaticGetter(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIllIl);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else if (lIIIIIllIIIIIlII(lllllllllllllllIllIllIIIllIIlIII, llIIIIllIlIIIl[6])) {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findSetter(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIllIl);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIllIllIIIllIIlIIl = lllllllllllllllIllIllIIIllIIIllI.findStaticSetter(lllllllllllllllIllIllIIIllIIlIll, lllllllllllllllIllIllIIIllIIlIlI, lllllllllllllllIllIllIIIllIIllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIIllIIlIIl);
    } catch (Exception lllllllllllllllIllIllIIIllIIIlll) {
      lllllllllllllllIllIllIIIllIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlllIIIIl() {
    llIIIIlIlIIIIl = new String[llIIIIllIlIIIl[7]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[8]] = llIIIIllIIIlIl[llIIIIllIlIIIl[5]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[9]] = llIIIIllIIIlIl[llIIIIllIlIIIl[6]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[10]] = llIIIIllIIIlIl[llIIIIllIlIIIl[11]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[1]] = llIIIIllIIIlIl[llIIIIllIlIIIl[12]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[13]] = llIIIIllIIIlIl[llIIIIllIlIIIl[10]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[0]] = llIIIIllIIIlIl[llIIIIllIlIIIl[13]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[14]] = llIIIIllIIIlIl[llIIIIllIlIIIl[15]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[16]] = llIIIIllIIIlIl[llIIIIllIlIIIl[17]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[15]] = llIIIIllIIIlIl[llIIIIllIlIIIl[8]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[18]] = llIIIIllIIIlIl[llIIIIllIlIIIl[9]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[2]] = llIIIIllIIIlIl[llIIIIllIlIIIl[14]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[19]] = llIIIIllIIIlIl[llIIIIllIlIIIl[20]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[11]] = llIIIIllIIIlIl[llIIIIllIlIIIl[21]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[22]] = llIIIIllIIIlIl[llIIIIllIlIIIl[23]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[12]] = llIIIIllIIIlIl[llIIIIllIlIIIl[22]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[4]] = llIIIIllIIIlIl[llIIIIllIlIIIl[16]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[5]] = llIIIIllIIIlIl[llIIIIllIlIIIl[19]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[17]] = llIIIIllIIIlIl[llIIIIllIlIIIl[18]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[6]] = llIIIIllIIIlIl[llIIIIllIlIIIl[7]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[21]] = llIIIIllIIIlIl[llIIIIllIlIIIl[24]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[20]] = llIIIIllIIIlIl[llIIIIllIlIIIl[25]];
    llIIIIlIlIIIIl[llIIIIllIlIIIl[23]] = llIIIIllIIIlIl[llIIIIllIlIIIl[26]];
    llIIIIlIlIIIlI = new Class[llIIIIllIlIIIl[13]];
    llIIIIlIlIIIlI[llIIIIllIlIIIl[10]] = NetHandlerPlayClient.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[11]] = EntityOtherPlayerMP.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[0]] = f13.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[12]] = float.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[1]] = Queue.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[5]] = EntityPlayerSP.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[6]] = WorldClient.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[2]] = Listener.class;
    llIIIIlIlIIIlI[llIIIIllIlIIIl[4]] = Minecraft.class;
  }
  
  private static void lIIIIIlIllllIIlI() {
    llIIIIllIIIlIl = new String[llIIIIllIlIIIl[27]];
    llIIIIllIIIlIl[llIIIIllIlIIIl[0]] = lIIIIIlIlllIIIlI(llIIIIllIIllIl[llIIIIllIlIIIl[0]], llIIIIllIIllIl[llIIIIllIlIIIl[1]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[1]] = lIIIIIlIlllIIIll(llIIIIllIIllIl[llIIIIllIlIIIl[2]], llIIIIllIIllIl[llIIIIllIlIIIl[4]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[2]] = lIIIIIlIlllIIIlI(llIIIIllIIllIl[llIIIIllIlIIIl[5]], llIIIIllIIllIl[llIIIIllIlIIIl[6]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[4]] = lIIIIIlIlllIIlII(llIIIIllIIllIl[llIIIIllIlIIIl[11]], llIIIIllIIllIl[llIIIIllIlIIIl[12]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[5]] = lIIIIIlIlllIIlII(llIIIIllIIllIl[llIIIIllIlIIIl[10]], llIIIIllIIllIl[llIIIIllIlIIIl[13]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[6]] = lIIIIIlIlllIIIlI(llIIIIllIIllIl[llIIIIllIlIIIl[15]], llIIIIllIIllIl[llIIIIllIlIIIl[17]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[11]] = lIIIIIlIlllIIlII(llIIIIllIIllIl[llIIIIllIlIIIl[8]], llIIIIllIIllIl[llIIIIllIlIIIl[9]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[12]] = lIIIIIlIlllIIIlI(llIIIIllIIllIl[llIIIIllIlIIIl[14]], llIIIIllIIllIl[llIIIIllIlIIIl[20]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[10]] = lIIIIIlIlllIIIlI(llIIIIllIIllIl[llIIIIllIlIIIl[21]], llIIIIllIIllIl[llIIIIllIlIIIl[23]]);
    llIIIIllIIIlIl[llIIIIllIlIIIl[13]] = lIIIIIlIlllIIIlI("3wSgZb7vIa/DnWk8TYrRWhoSUGyM4l3ZAh+6YD18ELHcVpE8RJ81sg==", "qAlJh");
    llIIIIllIIIlIl[llIIIIllIlIIIl[15]] = lIIIIIlIlllIIlII("hTycyQKGc3uI6fqrCGNc21z/K+X8RTogedk3Q+zfJXk=", "ozZKC");
    llIIIIllIIIlIl[llIIIIllIlIIIl[17]] = lIIIIIlIlllIIlII("c8FjKYBX05P2xrGMIfGkiGJTbmH1Xm1x4VmSrKJxhI+yz9lbYl6UyMl/SHbKDFHW//jwGQBeF5LCeFWWtOd66bBlZnN4Wev3r5cHf1s9WcUCpknv+RA7WA==", "KLTdo");
    llIIIIllIIIlIl[llIIIIllIlIIIl[8]] = lIIIIIlIlllIIlII("+g22qRC/ENhYQ5vBtKE/3p02I23N1m5vc0PsdmRBHYth42+U8cdcWcOa0Q+g0S78PDS1p7SrQ6xPk0jrsTfSkz540T7rkpgjyxolQG33bQ2HWUGzDB9fTVtBZYwEkGro4sxeJD+NjyY=", "wFwYN");
    llIIIIllIIIlIl[llIIIIllIlIIIl[9]] = lIIIIIlIlllIIlII("4eSrK3Y3ckvwq9EmjbpecNhK9w4tsimju4rvKK7n1WdWwWrJn7liubPZeJm1IijA", "ghAsR");
    llIIIIllIIIlIl[llIIIIllIlIIIl[14]] = lIIIIIlIlllIIIll("OgBlNgMiFSIxEzgCZScfJ0stdUJtCSI2AzILLjdNZV9rZVd3RQ==", "WeKEw");
    llIIIIllIIIlIl[llIIIIllIlIIIl[20]] = lIIIIIlIlllIIIlI("b3CMxREs+vtjDHjXAUYMqTFJk/MmkN7I6ZbaTOtfm1aW5ZDwDpMSDAjMlbr7d3p0sseEHFLtujo=", "emrYK");
    llIIIIllIIIlIl[llIIIIllIlIIIl[21]] = lIIIIIlIlllIIlII("APp4Aj69Ipn1zqOptRaVr8YBjOLKKWO/pHTYvqlctOf6JnSKztuVOjll1SxKGKq/YuET3dIDmlTyfblL/aO9j3QptD+e5/c5+rCS30K54+0=", "RVeiQ");
    llIIIIllIIIlIl[llIIIIllIlIIIl[23]] = lIIIIIlIlllIIIll("Bgk5SQMBAigEHAkKOUkNBAUoCRpGATgLGgEcIQYXDR5jMAEaACkkAgEJIxNUDhkjBDFfX31VVjcOd08nQSAjAhpHASQJCwseLAEaRwkjEwccFWIiABwFOR5VUkxt", "hlMgn");
    llIIIIllIIIlIl[llIIIIllIlIIIl[22]] = lIIIIIlIlllIIlII("+g6hSTyzcg+fNtg4JVUXFRdoXzgsgWgacQYBp/88PWdnOTyxyTP5tqD1A8cWmnOQm2zpNjxInUALXZQv4hSIN612WzGndXRiNX0Eo1pbHEc=", "gDRPm");
    llIIIIllIIIlIl[llIIIIllIlIIIl[16]] = lIIIIIlIlllIIIlI("mY5AixAFCoVBLQ92ghRayfwcj18jxxoyS7KsdpHZODo=", "QNoPH");
    llIIIIllIIIlIl[llIIIIllIlIIIl[19]] = lIIIIIlIlllIIIll("DCYSZTkLLQMoJgMlEmU3DioDJSBMDg8lMQExBy0gWCUPLjgGHFF6YFF6OSxuVnlGa3Q=", "bCfKT");
    llIIIIllIIIlIl[llIIIIllIlIIIl[18]] = lIIIIIlIlllIIIll("NBYOZQYzHR8oGTsVDmUINhofJR90FhQ/Ai4KVA4FLhoOMjs2EgMuGQkjQC0CPx8eFFxqRE9yNDsAQHxRelNa", "ZszKk");
    llIIIIllIIIlIl[llIIIIllIlIIIl[7]] = lIIIIIlIlllIIlII("AD8FTHL0zwEI1iZc5BvsrfUNEoOKVzAX1agQms+76pioQHJad3RObFjbzKKjTasPpDq3fC73XEk=", "ISzKB");
    llIIIIllIIIlIl[llIIIIllIlIIIl[24]] = lIIIIIlIlllIIIll("AQ49BGQeGyIJZDoaLhAvUR8kCSZRR2IpIAoZKkomCgEsSgUJBS4GPlBVa0U=", "koKeJ");
    llIIIIllIIIlIl[llIIIIllIlIIIl[25]] = lIIIIIlIlllIIIlI("gS13ebfHgouq7m5lZc9TaX00zDpAOnP9goSeUjvhv4XZbN5z8Jm5QPxD9G2zfGdVxcG9ynYbCMQS9lWXAZJrVg==", "IfFWh");
    llIIIIllIIIlIl[llIIIIllIlIIIl[26]] = lIIIIIlIlllIIIlI("Rh4fFfICrZZnRaLg0o69pxjl9RP5S7DDbJbuc/hS6roqu6x5+C8tErgidmLoOUGO1EILdjwMgIhnR6eOk6es8SrIL4IfNBhiNVIRoj4hpPg0lfQ/WCq4NuFqhTzyxbEoJRgF8df/BUU=", "biGBt");
    llIIIIllIIllIl = null;
  }
  
  private static void lIIIIIlIllllIlII() {
    String str = (new Exception()).getStackTrace()[llIIIIllIlIIIl[0]].getFileName();
    llIIIIllIIllIl = str.substring(str.indexOf("ä") + llIIIIllIlIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIlllIIIll(String lllllllllllllllIllIllIIIllIIIIlI, String lllllllllllllllIllIllIIIllIIIIIl) {
    lllllllllllllllIllIllIIIllIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIllIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIIllIIIIII = new StringBuilder();
    char[] lllllllllllllllIllIllIIIlIllllll = lllllllllllllllIllIllIIIllIIIIIl.toCharArray();
    int lllllllllllllllIllIllIIIlIlllllI = llIIIIllIlIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIIllIIIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIllIlIIIl[0];
    while (lIIIIIllIIIIIlIl(j, i)) {
      char lllllllllllllllIllIllIIIllIIIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIIlIlllllI++;
      j++;
      "".length();
      if (((0xA8 ^ 0x99) << " ".length() & ((0xF3 ^ 0xC2) << " ".length() ^ 0xFFFFFFFF)) == " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIIllIIIIII);
  }
  
  private static String lIIIIIlIlllIIlII(String lllllllllllllllIllIllIIIlIlllIlI, String lllllllllllllllIllIllIIIlIlllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIlIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIlIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIIlIllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIIlIllllII.init(llIIIIllIlIIIl[2], lllllllllllllllIllIllIIIlIllllIl);
      return new String(lllllllllllllllIllIllIIIlIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIlIlllIll) {
      lllllllllllllllIllIllIIIlIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIlllIIIlI(String lllllllllllllllIllIllIIIlIllIlIl, String lllllllllllllllIllIllIIIlIllIlII) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIlIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIlIllIlII.getBytes(StandardCharsets.UTF_8)), llIIIIllIlIIIl[10]), "DES");
      Cipher lllllllllllllllIllIllIIIlIllIlll = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIIlIllIlll.init(llIIIIllIlIIIl[2], lllllllllllllllIllIllIIIlIlllIII);
      return new String(lllllllllllllllIllIllIIIlIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIlIllIllI) {
      lllllllllllllllIllIllIIIlIllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIllllllll() {
    llIIIIllIlIIIl = new int[28];
    llIIIIllIlIIIl[0] = (0x64 ^ 0x61) << " ".length() << " ".length() << " ".length() & ((0xB0 ^ 0xB5) << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF);
    llIIIIllIlIIIl[1] = " ".length();
    llIIIIllIlIIIl[2] = " ".length() << " ".length();
    llIIIIllIlIIIl[3] = -(0xFF ^ 0x9B);
    llIIIIllIlIIIl[4] = "   ".length();
    llIIIIllIlIIIl[5] = " ".length() << " ".length() << " ".length();
    llIIIIllIlIIIl[6] = (0x26 ^ 0x1) << " ".length() << " ".length() ^ 86 + 90 - 70 + 47;
    llIIIIllIlIIIl[7] = (0xBA ^ 0xB1) << " ".length();
    llIIIIllIlIIIl[8] = "   ".length() << " ".length() << " ".length();
    llIIIIllIlIIIl[9] = 0x9B ^ 0x88 ^ (0x29 ^ 0x26) << " ".length();
    llIIIIllIlIIIl[10] = " ".length() << "   ".length();
    llIIIIllIlIIIl[11] = "   ".length() << " ".length();
    llIIIIllIlIIIl[12] = (0x33 ^ 0x3C) << "   ".length() ^ 4 + 120 - 19 + 22;
    llIIIIllIlIIIl[13] = 0x17 ^ 0x1E;
    llIIIIllIlIIIl[14] = (0x43 ^ 0x44) << " ".length();
    llIIIIllIlIIIl[15] = ((0x6 ^ 0xD) << " ".length() << " ".length() << " ".length() ^ 131 + 46 - 144 + 148) << " ".length();
    llIIIIllIlIIIl[16] = 0xE9 ^ 0xBE ^ (0x3C ^ 0x2D) << " ".length() << " ".length();
    llIIIIllIlIIIl[17] = 0xC9 ^ 0x88 ^ (0x59 ^ 0x7C) << " ".length();
    llIIIIllIlIIIl[18] = (0x2 ^ 0x45) << " ".length() ^ 75 + 91 - 22 + 11;
    llIIIIllIlIIIl[19] = (0x69 ^ 0x6C) << " ".length() << " ".length();
    llIIIIllIlIIIl[20] = 38 + 92 - 69 + 72 ^ (0x64 ^ 0x21) << " ".length();
    llIIIIllIlIIIl[21] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIllIlIIIl[22] = (0x66 ^ 0x6F) << " ".length();
    llIIIIllIlIIIl[23] = 0x10 ^ 0x41 ^ " ".length() << "   ".length() << " ".length();
    llIIIIllIlIIIl[24] = 0x49 ^ 0x5E;
    llIIIIllIlIIIl[25] = "   ".length() << "   ".length();
    llIIIIllIlIIIl[26] = 0x52 ^ 0x4B;
    llIIIIllIlIIIl[27] = (0x4E ^ 0x7 ^ (0x27 ^ 0x36) << " ".length() << " ".length()) << " ".length();
  }
  
  private static boolean lIIIIIllIIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIllIIIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllIIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIllIIIIIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIllIIIIIIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIllIIIIIIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f05.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */