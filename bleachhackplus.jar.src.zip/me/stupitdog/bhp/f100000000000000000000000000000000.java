package me.stupitdog.bhp;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.text.TextFormatting;

public class f100000000000000000000000000000000 extends fh {
  private static String[] lIlllIlIIIlIII;
  
  private static Class[] lIlllIlIIIlIIl;
  
  private static final String[] lIlllIlIIIllll;
  
  private static String[] lIlllIlIIlIIII;
  
  private static final int[] lIlllIlIIlIIIl;
  
  public f100000000000000000000000000000000() {
    super(lIlllIlIIIllll[lIlllIlIIlIIIl[0]], lIlllIlIIIllll[lIlllIlIIlIIIl[1]], lIlllIlIIIllll[lIlllIlIIlIIIl[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIlllIlIllIllIlllI) {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   5: iconst_1
    //   6: iaload
    //   7: invokestatic lllllIIllllIIII : (II)Z
    //   10: ifeq -> 359
    //   13: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f9;
    //   18: <illegal opcode> 1 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   23: <illegal opcode> 2 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   28: <illegal opcode> 3 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   33: astore_2
    //   34: aload_2
    //   35: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   40: invokestatic lllllIIllllIIIl : (I)Z
    //   43: ifeq -> 301
    //   46: aload_2
    //   47: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   52: checkcast me/stupitdog/bhp/au
    //   55: astore_3
    //   56: aload_3
    //   57: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   62: aload_1
    //   63: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   66: iconst_1
    //   67: iaload
    //   68: aaload
    //   69: <illegal opcode> 7 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   74: invokestatic lllllIIllllIIIl : (I)Z
    //   77: ifeq -> 286
    //   80: aload_3
    //   81: <illegal opcode> 8 : (Lme/stupitdog/bhp/au;)V
    //   86: aload_3
    //   87: <illegal opcode> 9 : (Lme/stupitdog/bhp/au;)Z
    //   92: invokestatic lllllIIllllIIIl : (I)Z
    //   95: ifeq -> 199
    //   98: new java/lang/StringBuilder
    //   101: dup
    //   102: invokespecial <init> : ()V
    //   105: <illegal opcode> 10 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   110: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   115: aload_3
    //   116: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   121: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: <illegal opcode> 13 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   131: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   136: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIIllll : [Ljava/lang/String;
    //   139: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   142: iconst_3
    //   143: iaload
    //   144: aaload
    //   145: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: <illegal opcode> 14 : ()Lnet/minecraft/util/text/TextFormatting;
    //   155: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   160: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIIllll : [Ljava/lang/String;
    //   163: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   166: iconst_4
    //   167: iaload
    //   168: aaload
    //   169: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: <illegal opcode> 15 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   179: <illegal opcode> 16 : (Ljava/lang/String;)V
    //   184: ldc ''
    //   186: invokevirtual length : ()I
    //   189: pop
    //   190: ldc '   '
    //   192: invokevirtual length : ()I
    //   195: ifgt -> 286
    //   198: return
    //   199: new java/lang/StringBuilder
    //   202: dup
    //   203: invokespecial <init> : ()V
    //   206: <illegal opcode> 10 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   211: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   216: aload_3
    //   217: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   222: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: <illegal opcode> 13 : ()Lcom/mojang/realmsclient/gui/ChatFormatting;
    //   232: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   237: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIIllll : [Ljava/lang/String;
    //   240: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   243: iconst_5
    //   244: iaload
    //   245: aaload
    //   246: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: <illegal opcode> 17 : ()Lnet/minecraft/util/text/TextFormatting;
    //   256: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   261: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIIllll : [Ljava/lang/String;
    //   264: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   267: bipush #6
    //   269: iaload
    //   270: aaload
    //   271: <illegal opcode> 12 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   276: <illegal opcode> 15 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   281: <illegal opcode> 16 : (Ljava/lang/String;)V
    //   286: ldc ''
    //   288: invokevirtual length : ()I
    //   291: pop
    //   292: bipush #21
    //   294: bipush #16
    //   296: ixor
    //   297: ifne -> 34
    //   300: return
    //   301: ldc ''
    //   303: invokevirtual length : ()I
    //   306: pop
    //   307: sipush #152
    //   310: sipush #177
    //   313: ixor
    //   314: ldc ' '
    //   316: invokevirtual length : ()I
    //   319: ishl
    //   320: bipush #91
    //   322: bipush #114
    //   324: ixor
    //   325: ldc ' '
    //   327: invokevirtual length : ()I
    //   330: ishl
    //   331: iconst_m1
    //   332: ixor
    //   333: iand
    //   334: ifle -> 374
    //   337: return
    //   338: astore_2
    //   339: ldc ''
    //   341: invokevirtual length : ()I
    //   344: pop
    //   345: ldc '   '
    //   347: invokevirtual length : ()I
    //   350: ldc '   '
    //   352: invokevirtual length : ()I
    //   355: if_icmpeq -> 374
    //   358: return
    //   359: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIIllll : [Ljava/lang/String;
    //   362: getstatic me/stupitdog/bhp/f100000000000000000000000000000000.lIlllIlIIlIIIl : [I
    //   365: bipush #7
    //   367: iaload
    //   368: aaload
    //   369: <illegal opcode> 18 : (Ljava/lang/String;)V
    //   374: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   56	230	3	lllllllllllllllIlllIlIllIlllIIII	Lme/stupitdog/bhp/au;
    //   0	375	0	lllllllllllllllIlllIlIllIllIllll	Lme/stupitdog/bhp/f100000000000000000000000000000000;
    //   0	375	1	lllllllllllllllIlllIlIllIllIlllI	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   13	301	338	java/lang/Exception
  }
  
  static {
    lllllIIlllIllll();
    lllllIIlllIlllI();
    lllllIIlllIllIl();
    lllllIIlllIlIIl();
  }
  
  private static CallSite lllllIIllIlIIlI(MethodHandles.Lookup lllllllllllllllIlllIlIllIllIIlIl, String lllllllllllllllIlllIlIllIllIIlII, MethodType lllllllllllllllIlllIlIllIllIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIllIllIlIll = lIlllIlIIIlIII[Integer.parseInt(lllllllllllllllIlllIlIllIllIIlII)].split(lIlllIlIIIllll[lIlllIlIIlIIIl[8]]);
      Class<?> lllllllllllllllIlllIlIllIllIlIlI = Class.forName(lllllllllllllllIlllIlIllIllIlIll[lIlllIlIIlIIIl[0]]);
      String lllllllllllllllIlllIlIllIllIlIIl = lllllllllllllllIlllIlIllIllIlIll[lIlllIlIIlIIIl[1]];
      MethodHandle lllllllllllllllIlllIlIllIllIlIII = null;
      int lllllllllllllllIlllIlIllIllIIlll = lllllllllllllllIlllIlIllIllIlIll[lIlllIlIIlIIIl[3]].length();
      if (lllllIIllllIIlI(lllllllllllllllIlllIlIllIllIIlll, lIlllIlIIlIIIl[2])) {
        MethodType lllllllllllllllIlllIlIllIllIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIllIllIlIll[lIlllIlIIlIIIl[2]], f100000000000000000000000000000000.class.getClassLoader());
        if (lllllIIllllIIll(lllllllllllllllIlllIlIllIllIIlll, lIlllIlIIlIIIl[2])) {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findVirtual(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllIl);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findStatic(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllIl);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() == -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIllIllIllII = lIlllIlIIIlIIl[Integer.parseInt(lllllllllllllllIlllIlIllIllIlIll[lIlllIlIIlIIIl[2]])];
        if (lllllIIllllIIll(lllllllllllllllIlllIlIllIllIIlll, lIlllIlIIlIIIl[3])) {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findGetter(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllII);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else if (lllllIIllllIIll(lllllllllllllllIlllIlIllIllIIlll, lIlllIlIIlIIIl[4])) {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findStaticGetter(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllII);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIIllllIIll(lllllllllllllllIlllIlIllIllIIlll, lIlllIlIIlIIIl[5])) {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findSetter(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIlIllIllIlIII = lllllllllllllllIlllIlIllIllIIlIl.findStaticSetter(lllllllllllllllIlllIlIllIllIlIlI, lllllllllllllllIlllIlIllIllIlIIl, lllllllllllllllIlllIlIllIllIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIllIllIlIII);
    } catch (Exception lllllllllllllllIlllIlIllIllIIllI) {
      lllllllllllllllIlllIlIllIllIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlllIlIIl() {
    lIlllIlIIIlIII = new String[lIlllIlIIlIIIl[9]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[10]] = lIlllIlIIIllll[lIlllIlIIlIIIl[11]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[1]] = lIlllIlIIIllll[lIlllIlIIlIIIl[12]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[13]] = lIlllIlIIIllll[lIlllIlIIlIIIl[10]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[2]] = lIlllIlIIIllll[lIlllIlIIlIIIl[14]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[15]] = lIlllIlIIIllll[lIlllIlIIlIIIl[13]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[16]] = lIlllIlIIIllll[lIlllIlIIlIIIl[17]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[6]] = lIlllIlIIIllll[lIlllIlIIlIIIl[18]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[8]] = lIlllIlIIIllll[lIlllIlIIlIIIl[15]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[0]] = lIlllIlIIIllll[lIlllIlIIlIIIl[19]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[5]] = lIlllIlIIIllll[lIlllIlIIlIIIl[16]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[4]] = lIlllIlIIIllll[lIlllIlIIlIIIl[9]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[18]] = lIlllIlIIIllll[lIlllIlIIlIIIl[20]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[7]] = lIlllIlIIIllll[lIlllIlIIlIIIl[21]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[17]] = lIlllIlIIIllll[lIlllIlIIlIIIl[22]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[19]] = lIlllIlIIIllll[lIlllIlIIlIIIl[23]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[14]] = lIlllIlIIIllll[lIlllIlIIlIIIl[24]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[11]] = lIlllIlIIIllll[lIlllIlIIlIIIl[25]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[12]] = lIlllIlIIIllll[lIlllIlIIlIIIl[26]];
    lIlllIlIIIlIII[lIlllIlIIlIIIl[3]] = lIlllIlIIIllll[lIlllIlIIlIIIl[27]];
    lIlllIlIIIlIIl = new Class[lIlllIlIIlIIIl[5]];
    lIlllIlIIIlIIl[lIlllIlIIlIIIl[1]] = av.class;
    lIlllIlIIIlIIl[lIlllIlIIlIIIl[2]] = ArrayList.class;
    lIlllIlIIIlIIl[lIlllIlIIlIIIl[3]] = ChatFormatting.class;
    lIlllIlIIIlIIl[lIlllIlIIlIIIl[4]] = TextFormatting.class;
    lIlllIlIIIlIIl[lIlllIlIIlIIIl[0]] = f9.class;
  }
  
  private static void lllllIIlllIllIl() {
    lIlllIlIIIllll = new String[lIlllIlIIlIIIl[28]];
    lIlllIlIIIllll[lIlllIlIIlIIIl[0]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[0]], lIlllIlIIlIIII[lIlllIlIIlIIIl[1]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[1]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[2]], lIlllIlIIlIIII[lIlllIlIIlIIIl[3]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[2]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[4]], lIlllIlIIlIIII[lIlllIlIIlIIIl[5]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[3]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[6]], lIlllIlIIlIIII[lIlllIlIIlIIIl[7]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[4]] = lllllIIlllIlIll(lIlllIlIIlIIII[lIlllIlIIlIIIl[8]], lIlllIlIIlIIII[lIlllIlIIlIIIl[11]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[5]] = lllllIIlllIllII(lIlllIlIIlIIII[lIlllIlIIlIIIl[12]], lIlllIlIIlIIII[lIlllIlIIlIIIl[10]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[6]] = lllllIIlllIllII(lIlllIlIIlIIII[lIlllIlIIlIIIl[14]], lIlllIlIIlIIII[lIlllIlIIlIIIl[13]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[7]] = lllllIIlllIllII(lIlllIlIIlIIII[lIlllIlIIlIIIl[17]], lIlllIlIIlIIII[lIlllIlIIlIIIl[18]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[8]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[15]], lIlllIlIIlIIII[lIlllIlIIlIIIl[19]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[11]] = lllllIIlllIlIlI(lIlllIlIIlIIII[lIlllIlIIlIIIl[16]], lIlllIlIIlIIII[lIlllIlIIlIIIl[9]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[12]] = lllllIIlllIlIll(lIlllIlIIlIIII[lIlllIlIIlIIIl[20]], lIlllIlIIlIIII[lIlllIlIIlIIIl[21]]);
    lIlllIlIIIllll[lIlllIlIIlIIIl[10]] = lllllIIlllIlIll(lIlllIlIIlIIII[lIlllIlIIlIIIl[22]], "yFloX");
    lIlllIlIIIllll[lIlllIlIIlIIIl[14]] = lllllIIlllIllII("BChfIB0cPRgnDQYqXzEBGWMQJVMEIhUmBQw+S2FTSW1R", "iMqSi");
    lIlllIlIIIllll[lIlllIlIIlIIIl[13]] = lllllIIlllIllII("FzZdAhYPIxoFBhU0XRMKCn0SBVgJNh0VIRIyBzwHCSASFgdAez8bAwwyXB0DFDRcIhYIOh0WWVMFSVE=", "zSsqb");
    lIlllIlIIIllll[lIlllIlIIlIIIl[17]] = lllllIIlllIllII("KSpXFjAxPxARICsoVwcsNGEYEX43KhcBBywuDSA2NiALKCE3PBgCIX5nNQ8lMi5WCSUqKFY2MDYmFwJ/bRlDRQ==", "DOyeD");
    lIlllIlIIIllll[lIlllIlIIlIIIl[18]] = lllllIIlllIllII("CQB/EjURFTgVJQsCfwMpFEswFHsDACUvIAkAa0loKA8wFyBLCTAPJks2JRMoCgJqW2FE", "deQaA");
    lIlllIlIIIllll[lIlllIlIIlIIIl[15]] = lllllIIlllIlIll("yrkEI6/p++zjf/mgD0kOWyTOnOTURRigoccjAzQflE6y2FYLBmYgRg==", "ggmyV");
    lIlllIlIIIllll[lIlllIlIIlIIIl[19]] = lllllIIlllIlIll("dmRiBR0aPQVjIIuQSA3x8ocMUtcxBm+2tXvBTtO6ReE3GJ/clSTUmw==", "nEwGj");
    lIlllIlIIIllll[lIlllIlIIlIIIl[16]] = lllllIIlllIlIlI("f7m8dXQg1abNC7GOXWggbm2TC5Gj2gG5ID4fnYo18Mp5Wdjvw8FTHU4PsoAKej6f", "ZUdIJ");
    lIlllIlIIIllll[lIlllIlIIlIIIl[9]] = lllllIIlllIlIlI("WXERJUzC//BRoCvOhKFAXb46F1zx58H33HsvyIdbmXzzybCeHEJWug==", "QGAmK");
    lIlllIlIIIllll[lIlllIlIIlIIIl[20]] = lllllIIlllIlIll("5NkFiEBNtEPvaHGfloVCmUiHlCOm8wNcnbSzP8UnYf6J54SYtLYKkdzBIvMRoE1VaNtWPuy5X+1fBglGAFOwjg==", "wlfdU");
    lIlllIlIIIllll[lIlllIlIIlIIIl[21]] = lllllIIlllIlIlI("MgQ+1VUFH333mnZAGj2qC89O6F/dULhJvfrpfpyfh4Obe0b394NyQO+KysubOG0j0fmda95NoToFZBHAGgi55g==", "GIyov");
    lIlllIlIIIllll[lIlllIlIIlIIIl[22]] = lllllIIlllIlIlI("M9AT1F0BRmibjCkkbf5II7XvmZDfodVDayaowK3K2pwYDwRdc0Wa4qCbFv8aNG4XmCwmZUNRtBI=", "FsZVt");
    lIlllIlIIIllll[lIlllIlIIlIIIl[23]] = lllllIIlllIlIlI("lehiDhONTD4eEQ23p4IoVtdhOVpKxfVtsQJVP+Jz9+UE4eQSYNFkwnLn5Z4CxUV/HAxo8H71jC8=", "GjKEM");
    lIlllIlIIIllll[lIlllIlIIlIIIl[24]] = lllllIIlllIllII("LRk5FUMrGSETQxQMPR0DIDo6HQEjHT1ODDcIKhoJfVADHgwxGWAYDCkfYCcZNREhE1ZuNCUVGyZXIxUDIFccAB8uFig2GC4UKxEffEJvVA==", "GxOtm");
    lIlllIlIIIllll[lIlllIlIIlIIIl[25]] = lllllIIlllIlIlI("ClzKj58uhDZkFjfe02fxJOM+KE1RBlkKjYnenDLX2l9mvhPWt4hYNw==", "PZwte");
    lIlllIlIIIllll[lIlllIlIIlIIIl[26]] = lllllIIlllIllII("EQMAaiwdBgwqJlweCCUtHx8OKCgXAhlqJgcFQwcpExgrKzMfDRkwKBwLVxMJOzgofnJITE1kYQ==", "rlmDA");
    lIlllIlIIIllll[lIlllIlIIlIIIl[27]] = lllllIIlllIlIlI("mmvFsDrnxGTfBAr2dTsC4VKeDk/8OAOQmouUKYzLTX+jZLqJr3YyFtKYrpoeojAHpPmd2LIHkwc=", "cGAKR");
    lIlllIlIIlIIII = null;
  }
  
  private static void lllllIIlllIlllI() {
    String str = (new Exception()).getStackTrace()[lIlllIlIIlIIIl[0]].getFileName();
    lIlllIlIIlIIII = str.substring(str.indexOf("ä") + lIlllIlIIlIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIlllIllII(String lllllllllllllllIlllIlIllIllIIIIl, String lllllllllllllllIlllIlIllIllIIIII) {
    lllllllllllllllIlllIlIllIllIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIllIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIllIlIlllll = new StringBuilder();
    char[] lllllllllllllllIlllIlIllIlIllllI = lllllllllllllllIlllIlIllIllIIIII.toCharArray();
    int lllllllllllllllIlllIlIllIlIlllIl = lIlllIlIIlIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIllIllIIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIIlIIIl[0];
    while (lllllIIllllIlII(j, i)) {
      char lllllllllllllllIlllIlIllIllIIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIllIlIlllIl++;
      j++;
      "".length();
      if (-" ".length() > ((0x6 ^ 0x15) & (0x31 ^ 0x22 ^ 0xFFFFFFFF)))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIllIlIlllll);
  }
  
  private static String lllllIIlllIlIlI(String lllllllllllllllIlllIlIllIlIllIIl, String lllllllllllllllIlllIlIllIlIllIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIllIlIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIlIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIllIlIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIllIlIllIll.init(lIlllIlIIlIIIl[2], lllllllllllllllIlllIlIllIlIlllII);
      return new String(lllllllllllllllIlllIlIllIlIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIlIllIlI) {
      lllllllllllllllIlllIlIllIlIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIlllIlIll(String lllllllllllllllIlllIlIllIlIlIlII, String lllllllllllllllIlllIlIllIlIlIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIllIlIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIllIlIlIIll.getBytes(StandardCharsets.UTF_8)), lIlllIlIIlIIIl[8]), "DES");
      Cipher lllllllllllllllIlllIlIllIlIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIllIlIlIllI.init(lIlllIlIIlIIIl[2], lllllllllllllllIlllIlIllIlIlIlll);
      return new String(lllllllllllllllIlllIlIllIlIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIllIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIllIlIlIlIl) {
      lllllllllllllllIlllIlIllIlIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIlllIllll() {
    lIlllIlIIlIIIl = new int[29];
    lIlllIlIIlIIIl[0] = "   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ -" ".length());
    lIlllIlIIlIIIl[1] = " ".length();
    lIlllIlIIlIIIl[2] = " ".length() << " ".length();
    lIlllIlIIlIIIl[3] = "   ".length();
    lIlllIlIIlIIIl[4] = " ".length() << " ".length() << " ".length();
    lIlllIlIIlIIIl[5] = 0x98 ^ 0x8F ^ (0x3B ^ 0x32) << " ".length();
    lIlllIlIIlIIIl[6] = "   ".length() << " ".length();
    lIlllIlIIlIIIl[7] = (0x5E ^ 0x6F) << " ".length() << " ".length() ^ 3 + 4 - 5 + 193;
    lIlllIlIIlIIIl[8] = " ".length() << "   ".length();
    lIlllIlIIlIIIl[9] = 0x4E ^ 0x5D;
    lIlllIlIIlIIIl[10] = 0xF ^ 0x4;
    lIlllIlIIlIIIl[11] = (0x3F ^ 0x30) << " ".length() ^ 0x98 ^ 0x8F;
    lIlllIlIIlIIIl[12] = ((0x67 ^ 0x60) << " ".length() << " ".length() ^ 0x54 ^ 0x4D) << " ".length();
    lIlllIlIIlIIIl[13] = 143 + 3 - 72 + 103 ^ (0x2 ^ 0x2D) << " ".length() << " ".length();
    lIlllIlIIlIIIl[14] = "   ".length() << " ".length() << " ".length();
    lIlllIlIIlIIIl[15] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIlIIIl[16] = (48 + 135 - 35 + 7 ^ (0x51 ^ 0x18) << " ".length()) << " ".length();
    lIlllIlIIlIIIl[17] = (0x20 ^ 0x27) << " ".length();
    lIlllIlIIlIIIl[18] = 0x1E ^ 0x11;
    lIlllIlIIlIIIl[19] = 0xB8 ^ 0xA9;
    lIlllIlIIlIIIl[20] = ((0x55 ^ 0x42) << " ".length() ^ 0x5E ^ 0x75) << " ".length() << " ".length();
    lIlllIlIIlIIIl[21] = 0x26 ^ 0x33;
    lIlllIlIIlIIIl[22] = (0xB ^ 0x0) << " ".length();
    lIlllIlIIlIIIl[23] = 0xAE ^ 0xB9;
    lIlllIlIIlIIIl[24] = "   ".length() << "   ".length();
    lIlllIlIIlIIIl[25] = 0x3E ^ 0x27;
    lIlllIlIIlIIIl[26] = (122 + 183 - 205 + 107 ^ (0xFE ^ 0x9F) << " ".length()) << " ".length();
    lIlllIlIIlIIIl[27] = 0x1 ^ 0x1A;
    lIlllIlIIlIIIl[28] = (103 + 95 - 149 + 106 ^ (0x85 ^ 0xA2) << " ".length() << " ".length()) << " ".length() << " ".length();
  }
  
  private static boolean lllllIIllllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIllllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIllllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIllllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lllllIIllllIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */