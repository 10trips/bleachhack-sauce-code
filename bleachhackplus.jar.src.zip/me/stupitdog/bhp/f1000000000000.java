package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f1000000000000 extends au {
  private static String[] llIIlIIIIIlIlI;
  
  private static Class[] llIIlIIIIIlIll;
  
  private static final String[] llIIlIIIIIllII;
  
  private static String[] llIIlIIIIIllIl;
  
  private static final int[] llIIlIIIIIlllI;
  
  public f1000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIllII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIlllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIllII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIlllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIllII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIlllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000.llIIlIIIIIlllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIlllllIIllIll	Lme/stupitdog/bhp/f1000000000000;
  }
  
  static {
    lIIIIlIllllllIll();
    lIIIIlIllllllIIl();
    lIIIIlIllllllIII();
    lIIIIlIlllllIlII();
  }
  
  private static CallSite lIIIIlIlllllIIll(MethodHandles.Lookup lllllllllllllllIllIIlllllIIlIIlI, String lllllllllllllllIllIIlllllIIlIIIl, MethodType lllllllllllllllIllIIlllllIIlIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlllllIIllIII = llIIlIIIIIlIlI[Integer.parseInt(lllllllllllllllIllIIlllllIIlIIIl)].split(llIIlIIIIIllII[llIIlIIIIIlllI[3]]);
      Class<?> lllllllllllllllIllIIlllllIIlIlll = Class.forName(lllllllllllllllIllIIlllllIIllIII[llIIlIIIIIlllI[0]]);
      String lllllllllllllllIllIIlllllIIlIllI = lllllllllllllllIllIIlllllIIllIII[llIIlIIIIIlllI[1]];
      MethodHandle lllllllllllllllIllIIlllllIIlIlIl = null;
      int lllllllllllllllIllIIlllllIIlIlII = lllllllllllllllIllIIlllllIIllIII[llIIlIIIIIlllI[3]].length();
      if (lIIIIlIlllllllII(lllllllllllllllIllIIlllllIIlIlII, llIIlIIIIIlllI[2])) {
        MethodType lllllllllllllllIllIIlllllIIllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlllllIIllIII[llIIlIIIIIlllI[2]], f1000000000000.class.getClassLoader());
        if (lIIIIlIlllllllIl(lllllllllllllllIllIIlllllIIlIlII, llIIlIIIIIlllI[2])) {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findVirtual(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIlI);
          "".length();
          if (" ".length() <= (" ".length() << "   ".length() & (" ".length() << "   ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findStatic(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIlI);
        } 
        "".length();
        if (" ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlllllIIllIIl = llIIlIIIIIlIll[Integer.parseInt(lllllllllllllllIllIIlllllIIllIII[llIIlIIIIIlllI[2]])];
        if (lIIIIlIlllllllIl(lllllllllllllllIllIIlllllIIlIlII, llIIlIIIIIlllI[3])) {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findGetter(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIlllllllIl(lllllllllllllllIllIIlllllIIlIlII, llIIlIIIIIlllI[4])) {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findStaticGetter(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIIl);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (lIIIIlIlllllllIl(lllllllllllllllIllIIlllllIIlIlII, llIIlIIIIIlllI[5])) {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findSetter(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlllllIIlIlIl = lllllllllllllllIllIIlllllIIlIIlI.findStaticSetter(lllllllllllllllIllIIlllllIIlIlll, lllllllllllllllIllIIlllllIIlIllI, lllllllllllllllIllIIlllllIIllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlllllIIlIlIl);
    } catch (Exception lllllllllllllllIllIIlllllIIlIIll) {
      lllllllllllllllIllIIlllllIIlIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlllllIlII() {
    llIIlIIIIIlIlI = new String[llIIlIIIIIlllI[1]];
    llIIlIIIIIlIlI[llIIlIIIIIlllI[0]] = llIIlIIIIIllII[llIIlIIIIIlllI[4]];
    llIIlIIIIIlIll = new Class[llIIlIIIIIlllI[1]];
    llIIlIIIIIlIll[llIIlIIIIIlllI[0]] = f13.class;
  }
  
  private static void lIIIIlIllllllIII() {
    llIIlIIIIIllII = new String[llIIlIIIIIlllI[5]];
    llIIlIIIIIllII[llIIlIIIIIlllI[0]] = lIIIIlIlllllIlIl(llIIlIIIIIllIl[llIIlIIIIIlllI[0]], llIIlIIIIIllIl[llIIlIIIIIlllI[1]]);
    llIIlIIIIIllII[llIIlIIIIIlllI[1]] = lIIIIlIlllllIllI(llIIlIIIIIllIl[llIIlIIIIIlllI[2]], llIIlIIIIIllIl[llIIlIIIIIlllI[3]]);
    llIIlIIIIIllII[llIIlIIIIIlllI[2]] = lIIIIlIlllllIllI(llIIlIIIIIllIl[llIIlIIIIIlllI[4]], llIIlIIIIIllIl[llIIlIIIIIlllI[5]]);
    llIIlIIIIIllII[llIIlIIIIIlllI[3]] = lIIIIlIlllllIlll(llIIlIIIIIllIl[llIIlIIIIIlllI[6]], llIIlIIIIIllIl[llIIlIIIIIlllI[7]]);
    llIIlIIIIIllII[llIIlIIIIIlllI[4]] = lIIIIlIlllllIlll(llIIlIIIIIllIl[llIIlIIIIIlllI[8]], llIIlIIIIIllIl[llIIlIIIIIlllI[9]]);
    llIIlIIIIIllIl = null;
  }
  
  private static void lIIIIlIllllllIIl() {
    String str = (new Exception()).getStackTrace()[llIIlIIIIIlllI[0]].getFileName();
    llIIlIIIIIllIl = str.substring(str.indexOf("ä") + llIIlIIIIIlllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIlllllIllI(String lllllllllllllllIllIIlllllIIIlllI, String lllllllllllllllIllIIlllllIIIllIl) {
    lllllllllllllllIllIIlllllIIIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlllllIIIllII = new StringBuilder();
    char[] lllllllllllllllIllIIlllllIIIlIll = lllllllllllllllIllIIlllllIIIllIl.toCharArray();
    int lllllllllllllllIllIIlllllIIIlIlI = llIIlIIIIIlllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlllllIIIlllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIIIIlllI[0];
    while (lIIIIlIllllllllI(j, i)) {
      char lllllllllllllllIllIIlllllIIIllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlllllIIIlIlI++;
      j++;
      "".length();
      if ((((0x15 ^ 0x10) << "   ".length() ^ 0x17 ^ 0x1C) << " ".length() & ((71 + 39 - -18 + 11 ^ (0x1A ^ 0xF) << "   ".length()) << " ".length() ^ -" ".length())) != ("   ".length() & ("   ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlllllIIIllII);
  }
  
  private static String lIIIIlIlllllIlll(String lllllllllllllllIllIIlllllIIIIllI, String lllllllllllllllIllIIlllllIIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllllIIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlllllIIIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlllllIIIlIII.init(llIIlIIIIIlllI[2], lllllllllllllllIllIIlllllIIIlIIl);
      return new String(lllllllllllllllIllIIlllllIIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllllIIIIlll) {
      lllllllllllllllIllIIlllllIIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIlllllIlIl(String lllllllllllllllIllIIlllllIIIIIIl, String lllllllllllllllIllIIlllllIIIIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllllIIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIIIIIII.getBytes(StandardCharsets.UTF_8)), llIIlIIIIIlllI[8]), "DES");
      Cipher lllllllllllllllIllIIlllllIIIIIll = Cipher.getInstance("DES");
      lllllllllllllllIllIIlllllIIIIIll.init(llIIlIIIIIlllI[2], lllllllllllllllIllIIlllllIIIIlII);
      return new String(lllllllllllllllIllIIlllllIIIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllllIIIIIlI) {
      lllllllllllllllIllIIlllllIIIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllllllIll() {
    llIIlIIIIIlllI = new int[10];
    llIIlIIIIIlllI[0] = (0x8D ^ 0x94 ^ (0x80 ^ 0xAB) << " ".length()) & (64 + 56 - 78 + 99 ^ (0x4A ^ 0x2B) << " ".length() ^ -" ".length());
    llIIlIIIIIlllI[1] = " ".length();
    llIIlIIIIIlllI[2] = " ".length() << " ".length();
    llIIlIIIIIlllI[3] = "   ".length();
    llIIlIIIIIlllI[4] = " ".length() << " ".length() << " ".length();
    llIIlIIIIIlllI[5] = 0xF ^ 0xA;
    llIIlIIIIIlllI[6] = "   ".length() << " ".length();
    llIIlIIIIIlllI[7] = (0x75 ^ 0x26) << " ".length() ^ 14 + 15 - -68 + 64;
    llIIlIIIIIlllI[8] = " ".length() << "   ".length();
    llIIlIIIIIlllI[9] = 0x75 ^ 0x7C;
  }
  
  private static boolean lIIIIlIlllllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllllllllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIlllllllII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */