package me.stupitdog.bhp;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.Timer;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class am extends au {
  private Map<Potion, Color> potionColorMap;
  
  private static String[] lIlllIlllIllII;
  
  private static Class[] lIlllIlllIllIl;
  
  private static final String[] lIllllllIIlllI;
  
  private static String[] lIlllllllIIIlI;
  
  private static final int[] lIlllllllIIIll;
  
  public am() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new java/util/HashMap
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/am;Ljava/util/Map;)V
    //   54: aload_0
    //   55: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   60: <illegal opcode> 3 : ()Lnet/minecraft/potion/Potion;
    //   65: new java/awt/Color
    //   68: dup
    //   69: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   72: iconst_3
    //   73: iaload
    //   74: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   77: iconst_4
    //   78: iaload
    //   79: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   82: iconst_5
    //   83: iaload
    //   84: invokespecial <init> : (III)V
    //   87: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   92: ldc ''
    //   94: invokevirtual length : ()I
    //   97: pop2
    //   98: aload_0
    //   99: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   104: <illegal opcode> 5 : ()Lnet/minecraft/potion/Potion;
    //   109: new java/awt/Color
    //   112: dup
    //   113: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   116: bipush #6
    //   118: iaload
    //   119: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   122: bipush #7
    //   124: iaload
    //   125: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   128: bipush #8
    //   130: iaload
    //   131: invokespecial <init> : (III)V
    //   134: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   139: ldc ''
    //   141: invokevirtual length : ()I
    //   144: pop2
    //   145: aload_0
    //   146: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   151: <illegal opcode> 6 : ()Lnet/minecraft/potion/Potion;
    //   156: new java/awt/Color
    //   159: dup
    //   160: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   163: bipush #9
    //   165: iaload
    //   166: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   169: bipush #10
    //   171: iaload
    //   172: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   175: bipush #11
    //   177: iaload
    //   178: invokespecial <init> : (III)V
    //   181: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   186: ldc ''
    //   188: invokevirtual length : ()I
    //   191: pop2
    //   192: aload_0
    //   193: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   198: <illegal opcode> 7 : ()Lnet/minecraft/potion/Potion;
    //   203: new java/awt/Color
    //   206: dup
    //   207: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   210: bipush #12
    //   212: iaload
    //   213: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   216: bipush #13
    //   218: iaload
    //   219: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   222: bipush #14
    //   224: iaload
    //   225: invokespecial <init> : (III)V
    //   228: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   233: ldc ''
    //   235: invokevirtual length : ()I
    //   238: pop2
    //   239: aload_0
    //   240: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   245: <illegal opcode> 8 : ()Lnet/minecraft/potion/Potion;
    //   250: new java/awt/Color
    //   253: dup
    //   254: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   257: bipush #15
    //   259: iaload
    //   260: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   263: bipush #16
    //   265: iaload
    //   266: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   269: bipush #17
    //   271: iaload
    //   272: invokespecial <init> : (III)V
    //   275: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   280: ldc ''
    //   282: invokevirtual length : ()I
    //   285: pop2
    //   286: aload_0
    //   287: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   292: <illegal opcode> 9 : ()Lnet/minecraft/potion/Potion;
    //   297: new java/awt/Color
    //   300: dup
    //   301: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   304: bipush #11
    //   306: iaload
    //   307: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   310: bipush #18
    //   312: iaload
    //   313: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   316: bipush #19
    //   318: iaload
    //   319: invokespecial <init> : (III)V
    //   322: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   327: ldc ''
    //   329: invokevirtual length : ()I
    //   332: pop2
    //   333: aload_0
    //   334: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   339: <illegal opcode> 10 : ()Lnet/minecraft/potion/Potion;
    //   344: new java/awt/Color
    //   347: dup
    //   348: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   351: bipush #11
    //   353: iaload
    //   354: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   357: bipush #18
    //   359: iaload
    //   360: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   363: bipush #19
    //   365: iaload
    //   366: invokespecial <init> : (III)V
    //   369: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   374: ldc ''
    //   376: invokevirtual length : ()I
    //   379: pop2
    //   380: aload_0
    //   381: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   386: <illegal opcode> 11 : ()Lnet/minecraft/potion/Potion;
    //   391: new java/awt/Color
    //   394: dup
    //   395: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   398: bipush #20
    //   400: iaload
    //   401: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   404: bipush #21
    //   406: iaload
    //   407: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   410: bipush #22
    //   412: iaload
    //   413: invokespecial <init> : (III)V
    //   416: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   421: ldc ''
    //   423: invokevirtual length : ()I
    //   426: pop2
    //   427: aload_0
    //   428: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   433: <illegal opcode> 12 : ()Lnet/minecraft/potion/Potion;
    //   438: new java/awt/Color
    //   441: dup
    //   442: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   445: bipush #23
    //   447: iaload
    //   448: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   451: bipush #24
    //   453: iaload
    //   454: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   457: bipush #12
    //   459: iaload
    //   460: invokespecial <init> : (III)V
    //   463: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   468: ldc ''
    //   470: invokevirtual length : ()I
    //   473: pop2
    //   474: aload_0
    //   475: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   480: <illegal opcode> 13 : ()Lnet/minecraft/potion/Potion;
    //   485: new java/awt/Color
    //   488: dup
    //   489: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   492: bipush #25
    //   494: iaload
    //   495: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   498: bipush #26
    //   500: iaload
    //   501: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   504: bipush #27
    //   506: iaload
    //   507: invokespecial <init> : (III)V
    //   510: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   515: ldc ''
    //   517: invokevirtual length : ()I
    //   520: pop2
    //   521: aload_0
    //   522: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   527: <illegal opcode> 14 : ()Lnet/minecraft/potion/Potion;
    //   532: new java/awt/Color
    //   535: dup
    //   536: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   539: bipush #28
    //   541: iaload
    //   542: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   545: bipush #29
    //   547: iaload
    //   548: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   551: bipush #30
    //   553: iaload
    //   554: invokespecial <init> : (III)V
    //   557: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   562: ldc ''
    //   564: invokevirtual length : ()I
    //   567: pop2
    //   568: aload_0
    //   569: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   574: <illegal opcode> 15 : ()Lnet/minecraft/potion/Potion;
    //   579: new java/awt/Color
    //   582: dup
    //   583: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   586: bipush #31
    //   588: iaload
    //   589: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   592: bipush #32
    //   594: iaload
    //   595: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   598: bipush #30
    //   600: iaload
    //   601: invokespecial <init> : (III)V
    //   604: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   609: ldc ''
    //   611: invokevirtual length : ()I
    //   614: pop2
    //   615: aload_0
    //   616: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   621: <illegal opcode> 16 : ()Lnet/minecraft/potion/Potion;
    //   626: new java/awt/Color
    //   629: dup
    //   630: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   633: bipush #33
    //   635: iaload
    //   636: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   639: bipush #34
    //   641: iaload
    //   642: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   645: bipush #28
    //   647: iaload
    //   648: invokespecial <init> : (III)V
    //   651: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   656: ldc ''
    //   658: invokevirtual length : ()I
    //   661: pop2
    //   662: aload_0
    //   663: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   668: <illegal opcode> 17 : ()Lnet/minecraft/potion/Potion;
    //   673: new java/awt/Color
    //   676: dup
    //   677: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   680: bipush #35
    //   682: iaload
    //   683: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   686: bipush #36
    //   688: iaload
    //   689: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   692: bipush #37
    //   694: iaload
    //   695: invokespecial <init> : (III)V
    //   698: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   703: ldc ''
    //   705: invokevirtual length : ()I
    //   708: pop2
    //   709: aload_0
    //   710: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   715: <illegal opcode> 18 : ()Lnet/minecraft/potion/Potion;
    //   720: new java/awt/Color
    //   723: dup
    //   724: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   727: bipush #38
    //   729: iaload
    //   730: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   733: bipush #38
    //   735: iaload
    //   736: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   739: bipush #17
    //   741: iaload
    //   742: invokespecial <init> : (III)V
    //   745: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   750: ldc ''
    //   752: invokevirtual length : ()I
    //   755: pop2
    //   756: aload_0
    //   757: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   762: <illegal opcode> 19 : ()Lnet/minecraft/potion/Potion;
    //   767: new java/awt/Color
    //   770: dup
    //   771: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   774: bipush #38
    //   776: iaload
    //   777: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   780: bipush #38
    //   782: iaload
    //   783: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   786: bipush #39
    //   788: iaload
    //   789: invokespecial <init> : (III)V
    //   792: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   797: ldc ''
    //   799: invokevirtual length : ()I
    //   802: pop2
    //   803: aload_0
    //   804: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   809: <illegal opcode> 20 : ()Lnet/minecraft/potion/Potion;
    //   814: new java/awt/Color
    //   817: dup
    //   818: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   821: bipush #40
    //   823: iaload
    //   824: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   827: bipush #41
    //   829: iaload
    //   830: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   833: bipush #42
    //   835: iaload
    //   836: invokespecial <init> : (III)V
    //   839: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   844: ldc ''
    //   846: invokevirtual length : ()I
    //   849: pop2
    //   850: aload_0
    //   851: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   856: <illegal opcode> 21 : ()Lnet/minecraft/potion/Potion;
    //   861: new java/awt/Color
    //   864: dup
    //   865: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   868: bipush #43
    //   870: iaload
    //   871: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   874: bipush #44
    //   876: iaload
    //   877: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   880: bipush #43
    //   882: iaload
    //   883: invokespecial <init> : (III)V
    //   886: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   891: ldc ''
    //   893: invokevirtual length : ()I
    //   896: pop2
    //   897: aload_0
    //   898: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   903: <illegal opcode> 22 : ()Lnet/minecraft/potion/Potion;
    //   908: new java/awt/Color
    //   911: dup
    //   912: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   915: bipush #45
    //   917: iaload
    //   918: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   921: bipush #15
    //   923: iaload
    //   924: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   927: bipush #46
    //   929: iaload
    //   930: invokespecial <init> : (III)V
    //   933: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   938: ldc ''
    //   940: invokevirtual length : ()I
    //   943: pop2
    //   944: aload_0
    //   945: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   950: <illegal opcode> 23 : ()Lnet/minecraft/potion/Potion;
    //   955: new java/awt/Color
    //   958: dup
    //   959: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   962: bipush #47
    //   964: iaload
    //   965: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   968: bipush #48
    //   970: iaload
    //   971: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   974: bipush #49
    //   976: iaload
    //   977: invokespecial <init> : (III)V
    //   980: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   985: ldc ''
    //   987: invokevirtual length : ()I
    //   990: pop2
    //   991: aload_0
    //   992: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   997: <illegal opcode> 24 : ()Lnet/minecraft/potion/Potion;
    //   1002: new java/awt/Color
    //   1005: dup
    //   1006: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1009: bipush #50
    //   1011: iaload
    //   1012: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1015: bipush #51
    //   1017: iaload
    //   1018: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1021: bipush #17
    //   1023: iaload
    //   1024: invokespecial <init> : (III)V
    //   1027: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1032: ldc ''
    //   1034: invokevirtual length : ()I
    //   1037: pop2
    //   1038: aload_0
    //   1039: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1044: <illegal opcode> 25 : ()Lnet/minecraft/potion/Potion;
    //   1049: new java/awt/Color
    //   1052: dup
    //   1053: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1056: bipush #52
    //   1058: iaload
    //   1059: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1062: bipush #34
    //   1064: iaload
    //   1065: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1068: bipush #53
    //   1070: iaload
    //   1071: invokespecial <init> : (III)V
    //   1074: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1079: ldc ''
    //   1081: invokevirtual length : ()I
    //   1084: pop2
    //   1085: aload_0
    //   1086: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1091: <illegal opcode> 26 : ()Lnet/minecraft/potion/Potion;
    //   1096: new java/awt/Color
    //   1099: dup
    //   1100: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1103: bipush #50
    //   1105: iaload
    //   1106: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1109: bipush #16
    //   1111: iaload
    //   1112: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1115: bipush #17
    //   1117: iaload
    //   1118: invokespecial <init> : (III)V
    //   1121: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1126: ldc ''
    //   1128: invokevirtual length : ()I
    //   1131: pop2
    //   1132: aload_0
    //   1133: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1138: <illegal opcode> 27 : ()Lnet/minecraft/potion/Potion;
    //   1143: new java/awt/Color
    //   1146: dup
    //   1147: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1150: bipush #54
    //   1152: iaload
    //   1153: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1156: bipush #55
    //   1158: iaload
    //   1159: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1162: bipush #56
    //   1164: iaload
    //   1165: invokespecial <init> : (III)V
    //   1168: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1173: ldc ''
    //   1175: invokevirtual length : ()I
    //   1178: pop2
    //   1179: aload_0
    //   1180: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1185: <illegal opcode> 28 : ()Lnet/minecraft/potion/Potion;
    //   1190: new java/awt/Color
    //   1193: dup
    //   1194: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1197: bipush #57
    //   1199: iaload
    //   1200: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1203: bipush #21
    //   1205: iaload
    //   1206: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1209: bipush #21
    //   1211: iaload
    //   1212: invokespecial <init> : (III)V
    //   1215: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1220: ldc ''
    //   1222: invokevirtual length : ()I
    //   1225: pop2
    //   1226: aload_0
    //   1227: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1232: <illegal opcode> 29 : ()Lnet/minecraft/potion/Potion;
    //   1237: new java/awt/Color
    //   1240: dup
    //   1241: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1244: bipush #58
    //   1246: iaload
    //   1247: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1250: bipush #28
    //   1252: iaload
    //   1253: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1256: iconst_0
    //   1257: iaload
    //   1258: invokespecial <init> : (III)V
    //   1261: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1266: ldc ''
    //   1268: invokevirtual length : ()I
    //   1271: pop2
    //   1272: aload_0
    //   1273: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1278: <illegal opcode> 30 : ()Lnet/minecraft/potion/Potion;
    //   1283: new java/awt/Color
    //   1286: dup
    //   1287: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1290: bipush #10
    //   1292: iaload
    //   1293: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1296: bipush #59
    //   1298: iaload
    //   1299: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1302: bipush #44
    //   1304: iaload
    //   1305: invokespecial <init> : (III)V
    //   1308: <illegal opcode> 4 : (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1313: ldc ''
    //   1315: invokevirtual length : ()I
    //   1318: pop2
    //   1319: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1320	0	lllllllllllllllIllIlllllllIIIIIl	Lme/stupitdog/bhp/am;
  }
  
  @SubscribeEvent
  public void render(RenderGameOverlayEvent lllllllllllllllIllIllllllIlIlIll) {
    // Byte code:
    //   0: new net/minecraft/client/gui/ScaledResolution
    //   3: dup
    //   4: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   9: invokespecial <init> : (Lnet/minecraft/client/Minecraft;)V
    //   12: astore_2
    //   13: aload_1
    //   14: <illegal opcode> 32 : (Lnet/minecraftforge/client/event/RenderGameOverlayEvent;)Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   19: <illegal opcode> 33 : ()Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   24: invokestatic lIIIIIIIIlllllII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   27: ifeq -> 2249
    //   30: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   33: iconst_0
    //   34: iaload
    //   35: istore_3
    //   36: new java/util/ArrayList
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: <illegal opcode> 34 : ()Lme/stupitdog/bhp/f9;
    //   50: <illegal opcode> 35 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   55: <illegal opcode> 36 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   60: astore #4
    //   62: aload #4
    //   64: aload_0
    //   65: <illegal opcode> compare : (Lme/stupitdog/bhp/am;)Ljava/util/Comparator;
    //   70: <illegal opcode> 37 : (Ljava/util/ArrayList;Ljava/util/Comparator;)V
    //   75: <illegal opcode> 34 : ()Lme/stupitdog/bhp/f9;
    //   80: <illegal opcode> 38 : (Lme/stupitdog/bhp/f9;)Ljava/lang/String;
    //   85: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   88: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   91: bipush #60
    //   93: iaload
    //   94: aaload
    //   95: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   98: iconst_1
    //   99: iaload
    //   100: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   103: bipush #61
    //   105: iaload
    //   106: <illegal opcode> 39 : ()I
    //   111: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   116: iinc #3, 1
    //   119: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   122: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   125: bipush #62
    //   127: iaload
    //   128: aaload
    //   129: <illegal opcode> 41 : ()Lnet/minecraft/client/Minecraft;
    //   134: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   139: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Ljava/lang/String;
    //   144: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   147: iconst_1
    //   148: iaload
    //   149: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   152: bipush #61
    //   154: iaload
    //   155: iload_3
    //   156: <illegal opcode> 44 : ()I
    //   161: imul
    //   162: iadd
    //   163: <illegal opcode> 39 : ()I
    //   168: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   173: iinc #3, 1
    //   176: aload #4
    //   178: <illegal opcode> 45 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   183: astore #5
    //   185: aload #5
    //   187: <illegal opcode> 46 : (Ljava/util/Iterator;)Z
    //   192: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   195: ifeq -> 520
    //   198: aload #5
    //   200: <illegal opcode> 47 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   205: checkcast me/stupitdog/bhp/au
    //   208: astore #6
    //   210: aload #6
    //   212: <illegal opcode> 48 : (Lme/stupitdog/bhp/au;)Z
    //   217: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   220: ifeq -> 466
    //   223: aload #6
    //   225: <illegal opcode> 49 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   230: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   235: invokestatic lIIIIIIIIllllllI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   238: ifeq -> 466
    //   241: aload #6
    //   243: <illegal opcode> 50 : (Lme/stupitdog/bhp/au;)Z
    //   248: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   251: ifeq -> 466
    //   254: aload #6
    //   256: <illegal opcode> 51 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   261: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   264: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   267: bipush #63
    //   269: iaload
    //   270: aaload
    //   271: <illegal opcode> 52 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   276: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   279: ifeq -> 343
    //   282: aload #6
    //   284: <illegal opcode> 53 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   289: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   292: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   295: bipush #64
    //   297: iaload
    //   298: aaload
    //   299: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   302: iconst_1
    //   303: iaload
    //   304: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   307: bipush #61
    //   309: iaload
    //   310: iload_3
    //   311: <illegal opcode> 44 : ()I
    //   316: imul
    //   317: iadd
    //   318: <illegal opcode> 39 : ()I
    //   323: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   328: ldc ''
    //   330: invokevirtual length : ()I
    //   333: pop
    //   334: bipush #85
    //   336: bipush #80
    //   338: ixor
    //   339: ifne -> 463
    //   342: return
    //   343: aload #6
    //   345: <illegal opcode> 53 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   350: new java/lang/StringBuilder
    //   353: dup
    //   354: invokespecial <init> : ()V
    //   357: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   362: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   367: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   370: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   373: bipush #65
    //   375: iaload
    //   376: aaload
    //   377: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: <illegal opcode> 57 : ()Lnet/minecraft/util/text/TextFormatting;
    //   387: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   392: aload #6
    //   394: <illegal opcode> 51 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   399: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   409: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   414: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   417: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   420: bipush #66
    //   422: iaload
    //   423: aaload
    //   424: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   429: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   434: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   437: iconst_1
    //   438: iaload
    //   439: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   442: bipush #61
    //   444: iaload
    //   445: iload_3
    //   446: <illegal opcode> 44 : ()I
    //   451: imul
    //   452: iadd
    //   453: <illegal opcode> 39 : ()I
    //   458: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   463: iinc #3, 1
    //   466: ldc ''
    //   468: invokevirtual length : ()I
    //   471: pop
    //   472: bipush #120
    //   474: bipush #103
    //   476: ixor
    //   477: bipush #64
    //   479: bipush #95
    //   481: ixor
    //   482: iconst_m1
    //   483: ixor
    //   484: iand
    //   485: sipush #128
    //   488: sipush #133
    //   491: ixor
    //   492: ldc_w '   '
    //   495: invokevirtual length : ()I
    //   498: ishl
    //   499: sipush #143
    //   502: sipush #138
    //   505: ixor
    //   506: ldc_w '   '
    //   509: invokevirtual length : ()I
    //   512: ishl
    //   513: iconst_m1
    //   514: ixor
    //   515: iand
    //   516: if_icmpeq -> 185
    //   519: return
    //   520: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   523: iconst_1
    //   524: iaload
    //   525: istore_3
    //   526: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   531: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   536: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   541: d2i
    //   542: <illegal opcode> 60 : (I)Ljava/lang/String;
    //   547: astore #5
    //   549: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   554: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   559: <illegal opcode> 61 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   564: d2i
    //   565: <illegal opcode> 60 : (I)Ljava/lang/String;
    //   570: astore #6
    //   572: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   577: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   582: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   587: d2i
    //   588: <illegal opcode> 60 : (I)Ljava/lang/String;
    //   593: astore #7
    //   595: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   600: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   605: <illegal opcode> 63 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   610: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   613: bipush #67
    //   615: iaload
    //   616: invokestatic lIIIIIIIIlllllll : (II)Z
    //   619: ifeq -> 665
    //   622: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   627: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   632: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   637: ldc2_w 8.0
    //   640: ddiv
    //   641: ldc ''
    //   643: invokevirtual length : ()I
    //   646: pop
    //   647: ldc_w ' '
    //   650: invokevirtual length : ()I
    //   653: ineg
    //   654: ldc_w ' '
    //   657: invokevirtual length : ()I
    //   660: ineg
    //   661: if_icmpeq -> 684
    //   664: return
    //   665: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   670: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   675: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   680: ldc2_w 8.0
    //   683: dmul
    //   684: <illegal opcode> 64 : (D)J
    //   689: <illegal opcode> 65 : (J)Ljava/lang/String;
    //   694: astore #8
    //   696: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   701: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   706: <illegal opcode> 63 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   711: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   714: bipush #67
    //   716: iaload
    //   717: invokestatic lIIIIIIIIlllllll : (II)Z
    //   720: ifeq -> 766
    //   723: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   728: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   733: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   738: ldc2_w 8.0
    //   741: ddiv
    //   742: ldc ''
    //   744: invokevirtual length : ()I
    //   747: pop
    //   748: ldc_w ' '
    //   751: invokevirtual length : ()I
    //   754: ineg
    //   755: ldc_w ' '
    //   758: invokevirtual length : ()I
    //   761: ineg
    //   762: if_icmpeq -> 785
    //   765: return
    //   766: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   771: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   776: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   781: ldc2_w 8.0
    //   784: dmul
    //   785: <illegal opcode> 64 : (D)J
    //   790: <illegal opcode> 65 : (J)Ljava/lang/String;
    //   795: astore #9
    //   797: new java/lang/StringBuilder
    //   800: dup
    //   801: invokespecial <init> : ()V
    //   804: aload #5
    //   806: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   811: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   814: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   817: bipush #19
    //   819: iaload
    //   820: aaload
    //   821: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   826: aload #6
    //   828: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   833: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   836: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   839: bipush #18
    //   841: iaload
    //   842: aaload
    //   843: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   848: aload #7
    //   850: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   855: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   858: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   861: bipush #68
    //   863: iaload
    //   864: aaload
    //   865: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   870: aload #8
    //   872: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   877: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   880: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   883: bipush #69
    //   885: iaload
    //   886: aaload
    //   887: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   892: aload #9
    //   894: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   899: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   902: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   905: bipush #70
    //   907: iaload
    //   908: aaload
    //   909: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   914: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   919: astore #10
    //   921: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   924: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   927: bipush #71
    //   929: iaload
    //   930: aaload
    //   931: aload #10
    //   933: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   936: iconst_1
    //   937: iaload
    //   938: aload_2
    //   939: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   944: iload_3
    //   945: <illegal opcode> 44 : ()I
    //   950: imul
    //   951: isub
    //   952: <illegal opcode> 39 : ()I
    //   957: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   962: new java/util/ArrayList
    //   965: dup
    //   966: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   971: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   976: <illegal opcode> 67 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Ljava/util/Collection;
    //   981: invokespecial <init> : (Ljava/util/Collection;)V
    //   984: astore #11
    //   986: aload #11
    //   988: <illegal opcode> 68 : (Ljava/util/List;)Ljava/util/Iterator;
    //   993: astore #12
    //   995: aload #12
    //   997: <illegal opcode> 46 : (Ljava/util/Iterator;)Z
    //   1002: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   1005: ifeq -> 1198
    //   1008: aload #12
    //   1010: <illegal opcode> 47 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   1015: checkcast net/minecraft/potion/PotionEffect
    //   1018: astore #13
    //   1020: new java/lang/StringBuilder
    //   1023: dup
    //   1024: invokespecial <init> : ()V
    //   1027: aload_0
    //   1028: aload #13
    //   1030: <illegal opcode> 69 : (Lme/stupitdog/bhp/am;Lnet/minecraft/potion/PotionEffect;)Ljava/lang/String;
    //   1035: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1040: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1043: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1046: bipush #72
    //   1048: iaload
    //   1049: aaload
    //   1050: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1055: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1060: aload #13
    //   1062: fconst_1
    //   1063: <illegal opcode> 70 : (Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String;
    //   1068: aload_2
    //   1069: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1074: new java/lang/StringBuilder
    //   1077: dup
    //   1078: invokespecial <init> : ()V
    //   1081: aload_0
    //   1082: aload #13
    //   1084: <illegal opcode> 69 : (Lme/stupitdog/bhp/am;Lnet/minecraft/potion/PotionEffect;)Ljava/lang/String;
    //   1089: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1094: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1097: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1100: bipush #73
    //   1102: iaload
    //   1103: aaload
    //   1104: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1109: aload #13
    //   1111: fconst_1
    //   1112: <illegal opcode> 70 : (Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String;
    //   1117: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1122: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1127: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   1132: isub
    //   1133: aload_2
    //   1134: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1139: <illegal opcode> 44 : ()I
    //   1144: iload_3
    //   1145: imul
    //   1146: isub
    //   1147: aload_0
    //   1148: <illegal opcode> 2 : (Lme/stupitdog/bhp/am;)Ljava/util/Map;
    //   1153: aload #13
    //   1155: <illegal opcode> 73 : (Lnet/minecraft/potion/PotionEffect;)Lnet/minecraft/potion/Potion;
    //   1160: <illegal opcode> 74 : (Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;
    //   1165: checkcast java/awt/Color
    //   1168: <illegal opcode> 75 : (Ljava/awt/Color;)I
    //   1173: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   1178: iinc #3, 1
    //   1181: ldc ''
    //   1183: invokevirtual length : ()I
    //   1186: pop
    //   1187: ldc_w ' '
    //   1190: invokevirtual length : ()I
    //   1193: ineg
    //   1194: ifle -> 995
    //   1197: return
    //   1198: new java/lang/StringBuilder
    //   1201: dup
    //   1202: invokespecial <init> : ()V
    //   1205: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1208: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1211: bipush #74
    //   1213: iaload
    //   1214: aaload
    //   1215: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1220: aload_0
    //   1221: <illegal opcode> 76 : (Lme/stupitdog/bhp/am;)D
    //   1226: ldc2_w 10.0
    //   1229: ddiv
    //   1230: <illegal opcode> 77 : (D)D
    //   1235: <illegal opcode> 78 : (Ljava/lang/StringBuilder;D)Ljava/lang/StringBuilder;
    //   1240: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1245: astore #12
    //   1247: new java/lang/StringBuilder
    //   1250: dup
    //   1251: invokespecial <init> : ()V
    //   1254: <illegal opcode> 79 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1259: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1264: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1267: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1270: bipush #75
    //   1272: iaload
    //   1273: aaload
    //   1274: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1279: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1284: new java/lang/StringBuilder
    //   1287: dup
    //   1288: invokespecial <init> : ()V
    //   1291: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1296: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1301: aload #12
    //   1303: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1308: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1311: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1314: bipush #76
    //   1316: iaload
    //   1317: aaload
    //   1318: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1323: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1328: aload_2
    //   1329: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1334: new java/lang/StringBuilder
    //   1337: dup
    //   1338: invokespecial <init> : ()V
    //   1341: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1344: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1347: bipush #77
    //   1349: iaload
    //   1350: aaload
    //   1351: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1356: aload #12
    //   1358: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1363: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1366: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1369: bipush #78
    //   1371: iaload
    //   1372: aaload
    //   1373: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1378: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1383: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   1388: isub
    //   1389: aload_2
    //   1390: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1395: <illegal opcode> 44 : ()I
    //   1400: iload_3
    //   1401: imul
    //   1402: isub
    //   1403: <illegal opcode> 39 : ()I
    //   1408: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   1413: iinc #3, 1
    //   1416: <illegal opcode> 34 : ()Lme/stupitdog/bhp/f9;
    //   1421: <illegal opcode> 80 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/ft;
    //   1426: <illegal opcode> 81 : (Lme/stupitdog/bhp/ft;)F
    //   1431: <illegal opcode> 82 : (F)I
    //   1436: istore #13
    //   1438: new java/lang/StringBuilder
    //   1441: dup
    //   1442: invokespecial <init> : ()V
    //   1445: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1448: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1451: bipush #79
    //   1453: iaload
    //   1454: aaload
    //   1455: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1460: iload #13
    //   1462: <illegal opcode> 83 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   1467: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1472: astore #14
    //   1474: new java/lang/StringBuilder
    //   1477: dup
    //   1478: invokespecial <init> : ()V
    //   1481: <illegal opcode> 79 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1486: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1491: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1494: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1497: bipush #14
    //   1499: iaload
    //   1500: aaload
    //   1501: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1506: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1511: new java/lang/StringBuilder
    //   1514: dup
    //   1515: invokespecial <init> : ()V
    //   1518: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1523: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1528: aload #14
    //   1530: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1535: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1540: aload_2
    //   1541: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1546: new java/lang/StringBuilder
    //   1549: dup
    //   1550: invokespecial <init> : ()V
    //   1553: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1556: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1559: bipush #80
    //   1561: iaload
    //   1562: aaload
    //   1563: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1568: aload #14
    //   1570: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1575: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1578: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1581: bipush #81
    //   1583: iaload
    //   1584: aaload
    //   1585: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1590: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1595: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   1600: isub
    //   1601: aload_2
    //   1602: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1607: <illegal opcode> 44 : ()I
    //   1612: iload_3
    //   1613: imul
    //   1614: isub
    //   1615: <illegal opcode> 39 : ()I
    //   1620: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   1625: iinc #3, 1
    //   1628: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   1633: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1638: <illegal opcode> 84 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   1643: <illegal opcode> 85 : (Lnet/minecraft/item/ItemStack;)I
    //   1648: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   1653: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1658: <illegal opcode> 84 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   1663: <illegal opcode> 86 : (Lnet/minecraft/item/ItemStack;)I
    //   1668: isub
    //   1669: i2f
    //   1670: fstore #15
    //   1672: new java/lang/StringBuilder
    //   1675: dup
    //   1676: invokespecial <init> : ()V
    //   1679: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1682: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1685: bipush #82
    //   1687: iaload
    //   1688: aaload
    //   1689: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1694: fload #15
    //   1696: <illegal opcode> 87 : (Ljava/lang/StringBuilder;F)Ljava/lang/StringBuilder;
    //   1701: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1706: astore #16
    //   1708: new java/lang/StringBuilder
    //   1711: dup
    //   1712: invokespecial <init> : ()V
    //   1715: <illegal opcode> 79 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1720: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1725: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1728: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1731: bipush #83
    //   1733: iaload
    //   1734: aaload
    //   1735: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1740: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1745: new java/lang/StringBuilder
    //   1748: dup
    //   1749: invokespecial <init> : ()V
    //   1752: <illegal opcode> 88 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1757: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1762: aload #16
    //   1764: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1769: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1774: aload_2
    //   1775: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1780: new java/lang/StringBuilder
    //   1783: dup
    //   1784: invokespecial <init> : ()V
    //   1787: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1790: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1793: bipush #84
    //   1795: iaload
    //   1796: aaload
    //   1797: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1802: aload #16
    //   1804: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1809: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1812: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1815: bipush #24
    //   1817: iaload
    //   1818: aaload
    //   1819: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1824: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1829: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   1834: isub
    //   1835: aload_2
    //   1836: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1841: <illegal opcode> 44 : ()I
    //   1846: iload_3
    //   1847: imul
    //   1848: isub
    //   1849: <illegal opcode> 39 : ()I
    //   1854: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   1859: iinc #3, 1
    //   1862: new java/lang/StringBuilder
    //   1865: dup
    //   1866: invokespecial <init> : ()V
    //   1869: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1872: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1875: bipush #85
    //   1877: iaload
    //   1878: aaload
    //   1879: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1884: aload_0
    //   1885: <illegal opcode> 89 : (Lme/stupitdog/bhp/am;)I
    //   1890: <illegal opcode> 83 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   1895: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1900: astore #17
    //   1902: new java/lang/StringBuilder
    //   1905: dup
    //   1906: invokespecial <init> : ()V
    //   1909: <illegal opcode> 79 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1914: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1919: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1922: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1925: bipush #38
    //   1927: iaload
    //   1928: aaload
    //   1929: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1934: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1939: new java/lang/StringBuilder
    //   1942: dup
    //   1943: invokespecial <init> : ()V
    //   1946: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   1951: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1956: aload #17
    //   1958: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1963: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   1968: aload_2
    //   1969: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   1974: new java/lang/StringBuilder
    //   1977: dup
    //   1978: invokespecial <init> : ()V
    //   1981: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   1984: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   1987: bipush #86
    //   1989: iaload
    //   1990: aaload
    //   1991: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1996: aload #17
    //   1998: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2003: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   2006: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2009: bipush #87
    //   2011: iaload
    //   2012: aaload
    //   2013: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2018: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   2023: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   2028: isub
    //   2029: aload_2
    //   2030: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   2035: <illegal opcode> 44 : ()I
    //   2040: iload_3
    //   2041: imul
    //   2042: isub
    //   2043: <illegal opcode> 39 : ()I
    //   2048: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   2053: iinc #3, 1
    //   2056: new java/lang/StringBuilder
    //   2059: dup
    //   2060: invokespecial <init> : ()V
    //   2063: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   2066: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2069: bipush #20
    //   2071: iaload
    //   2072: aaload
    //   2073: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2078: <illegal opcode> 90 : ()I
    //   2083: <illegal opcode> 83 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   2088: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   2093: astore #18
    //   2095: new java/lang/StringBuilder
    //   2098: dup
    //   2099: invokespecial <init> : ()V
    //   2102: <illegal opcode> 79 : ()Lnet/minecraft/util/text/TextFormatting;
    //   2107: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2112: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   2115: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2118: bipush #17
    //   2120: iaload
    //   2121: aaload
    //   2122: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2127: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   2132: new java/lang/StringBuilder
    //   2135: dup
    //   2136: invokespecial <init> : ()V
    //   2139: <illegal opcode> 54 : ()Lnet/minecraft/util/text/TextFormatting;
    //   2144: <illegal opcode> 55 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2149: aload #18
    //   2151: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2156: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   2161: aload_2
    //   2162: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   2167: new java/lang/StringBuilder
    //   2170: dup
    //   2171: invokespecial <init> : ()V
    //   2174: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   2177: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2180: bipush #16
    //   2182: iaload
    //   2183: aaload
    //   2184: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2189: aload #18
    //   2191: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2196: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   2199: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2202: bipush #52
    //   2204: iaload
    //   2205: aaload
    //   2206: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2211: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   2216: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   2221: isub
    //   2222: aload_2
    //   2223: <illegal opcode> 66 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   2228: <illegal opcode> 44 : ()I
    //   2233: iload_3
    //   2234: imul
    //   2235: isub
    //   2236: <illegal opcode> 39 : ()I
    //   2241: <illegal opcode> 40 : (Ljava/lang/String;Ljava/lang/String;III)V
    //   2246: iinc #3, 1
    //   2249: aload_1
    //   2250: <illegal opcode> 32 : (Lnet/minecraftforge/client/event/RenderGameOverlayEvent;)Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   2255: <illegal opcode> 91 : ()Lnet/minecraftforge/client/event/RenderGameOverlayEvent$ElementType;
    //   2260: invokestatic lIIIIIIIIlllllII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   2263: ifeq -> 2394
    //   2266: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2271: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2276: <illegal opcode> 92 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   2281: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2286: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2291: <illegal opcode> 93 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   2296: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2301: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2306: <illegal opcode> 92 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   2311: fsub
    //   2312: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2317: <illegal opcode> 94 : (Lnet/minecraft/client/Minecraft;)F
    //   2322: fmul
    //   2323: fadd
    //   2324: <illegal opcode> 95 : (F)F
    //   2329: fstore_3
    //   2330: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2335: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2340: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   2345: ldc_w -1.0
    //   2348: fmul
    //   2349: fstore #4
    //   2351: aload_2
    //   2352: <illegal opcode> 71 : (Lnet/minecraft/client/gui/ScaledResolution;)I
    //   2357: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2360: bipush #77
    //   2362: iaload
    //   2363: isub
    //   2364: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2367: bipush #88
    //   2369: iaload
    //   2370: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   2373: bipush #85
    //   2375: iaload
    //   2376: fload_3
    //   2377: fload #4
    //   2379: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   2384: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2389: <illegal opcode> 97 : (IIIFFLnet/minecraft/entity/EntityLivingBase;)V
    //   2394: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   210	256	6	lllllllllllllllIllIlllllllIIIIII	Lme/stupitdog/bhp/au;
    //   1020	161	13	lllllllllllllllIllIllllllIllllll	Lnet/minecraft/potion/PotionEffect;
    //   36	2213	3	lllllllllllllllIllIllllllIlllllI	I
    //   45	2204	4	lllllllllllllllIllIllllllIllllIl	Ljava/util/ArrayList;
    //   549	1700	5	lllllllllllllllIllIllllllIllllII	Ljava/lang/String;
    //   572	1677	6	lllllllllllllllIllIllllllIlllIll	Ljava/lang/String;
    //   595	1654	7	lllllllllllllllIllIllllllIlllIlI	Ljava/lang/String;
    //   696	1553	8	lllllllllllllllIllIllllllIlllIIl	Ljava/lang/String;
    //   797	1452	9	lllllllllllllllIllIllllllIlllIII	Ljava/lang/String;
    //   921	1328	10	lllllllllllllllIllIllllllIllIlll	Ljava/lang/String;
    //   986	1263	11	lllllllllllllllIllIllllllIllIllI	Ljava/util/List;
    //   1247	1002	12	lllllllllllllllIllIllllllIllIlIl	Ljava/lang/String;
    //   1438	811	13	lllllllllllllllIllIllllllIllIlII	I
    //   1474	775	14	lllllllllllllllIllIllllllIllIIll	Ljava/lang/String;
    //   1672	577	15	lllllllllllllllIllIllllllIllIIlI	F
    //   1708	541	16	lllllllllllllllIllIllllllIllIIIl	Ljava/lang/String;
    //   1902	347	17	lllllllllllllllIllIllllllIllIIII	Ljava/lang/String;
    //   2095	154	18	lllllllllllllllIllIllllllIlIllll	Ljava/lang/String;
    //   2330	64	3	lllllllllllllllIllIllllllIlIlllI	F
    //   2351	43	4	lllllllllllllllIllIllllllIlIllIl	F
    //   0	2395	0	lllllllllllllllIllIllllllIlIllII	Lme/stupitdog/bhp/am;
    //   0	2395	1	lllllllllllllllIllIllllllIlIlIll	Lnet/minecraftforge/client/event/RenderGameOverlayEvent;
    //   13	2382	2	lllllllllllllllIllIllllllIlIlIlI	Lnet/minecraft/client/gui/ScaledResolution;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   45	2204	4	lllllllllllllllIllIllllllIllllIl	Ljava/util/ArrayList<Lme/stupitdog/bhp/au;>;
    //   986	1263	11	lllllllllllllllIllIllllllIllIllI	Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>;
  }
  
  public String getPotionString(PotionEffect lllllllllllllllIllIllllllIlIlIII) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 73 : (Lnet/minecraft/potion/PotionEffect;)Lnet/minecraft/potion/Potion;
    //   6: astore_2
    //   7: new java/lang/StringBuilder
    //   10: dup
    //   11: invokespecial <init> : ()V
    //   14: aload_2
    //   15: <illegal opcode> 98 : (Lnet/minecraft/potion/Potion;)Ljava/lang/String;
    //   20: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   23: iconst_0
    //   24: iaload
    //   25: anewarray java/lang/Object
    //   28: checkcast [Ljava/lang/Object;
    //   31: <illegal opcode> 99 : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   36: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   44: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   47: bipush #89
    //   49: iaload
    //   50: aaload
    //   51: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: aload_1
    //   57: <illegal opcode> 100 : (Lnet/minecraft/potion/PotionEffect;)I
    //   62: invokestatic lIIIIIIIlIIIIIII : (I)Z
    //   65: ifeq -> 96
    //   68: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   71: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   74: bipush #49
    //   76: iaload
    //   77: aaload
    //   78: ldc ''
    //   80: invokevirtual length : ()I
    //   83: pop
    //   84: ldc_w '   '
    //   87: invokevirtual length : ()I
    //   90: ineg
    //   91: ifle -> 140
    //   94: aconst_null
    //   95: areturn
    //   96: new java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial <init> : ()V
    //   103: aload_1
    //   104: <illegal opcode> 100 : (Lnet/minecraft/potion/PotionEffect;)I
    //   109: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   112: iconst_1
    //   113: iaload
    //   114: iadd
    //   115: <illegal opcode> 83 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   120: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   123: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   126: bipush #90
    //   128: iaload
    //   129: aaload
    //   130: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   140: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   150: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	151	0	lllllllllllllllIllIllllllIlIlIIl	Lme/stupitdog/bhp/am;
    //   0	151	1	lllllllllllllllIllIllllllIlIlIII	Lnet/minecraft/potion/PotionEffect;
    //   7	144	2	lllllllllllllllIllIllllllIlIIlll	Lnet/minecraft/potion/Potion;
  }
  
  public double turnIntoKpH(double lllllllllllllllIllIllllllIlIIlIl) {
    // Byte code:
    //   0: dload_1
    //   1: <illegal opcode> 101 : (D)F
    //   6: f2d
    //   7: ldc2_w 71.2729367892
    //   10: dmul
    //   11: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIllllllIlIIllI	Lme/stupitdog/bhp/am;
    //   0	12	1	lllllllllllllllIllIllllllIlIIlIl	D
  }
  
  public double getSpeedKpH() {
    // Byte code:
    //   0: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   15: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   20: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   25: <illegal opcode> 102 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   30: dsub
    //   31: dstore_1
    //   32: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   37: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   42: <illegal opcode> 62 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   47: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 103 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   62: dsub
    //   63: dstore_3
    //   64: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   69: <illegal opcode> 104 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/Timer;
    //   74: <illegal opcode> 105 : (Lnet/minecraft/util/Timer;)F
    //   79: ldc_w 1000.0
    //   82: fdiv
    //   83: fstore #5
    //   85: aload_0
    //   86: dload_1
    //   87: dload_1
    //   88: dmul
    //   89: dload_3
    //   90: dload_3
    //   91: dmul
    //   92: dadd
    //   93: <illegal opcode> 101 : (D)F
    //   98: fload #5
    //   100: fdiv
    //   101: f2d
    //   102: <illegal opcode> 106 : (Lme/stupitdog/bhp/am;D)D
    //   107: dstore #6
    //   109: ldc2_w 10.0
    //   112: dload #6
    //   114: dmul
    //   115: <illegal opcode> 64 : (D)J
    //   120: l2d
    //   121: ldc2_w 10.0
    //   124: ddiv
    //   125: dstore #6
    //   127: dload #6
    //   129: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	130	0	lllllllllllllllIllIllllllIlIIlII	Lme/stupitdog/bhp/am;
    //   32	98	1	lllllllllllllllIllIllllllIlIIIll	D
    //   64	66	3	lllllllllllllllIllIllllllIlIIIlI	D
    //   85	45	5	lllllllllllllllIllIllllllIlIIIIl	F
    //   109	21	6	lllllllllllllllIllIllllllIlIIIII	D
  }
  
  public int getPing() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   3: bipush #67
    //   5: iaload
    //   6: istore_1
    //   7: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   12: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   17: invokestatic lIIIIIIIlIIIIIIl : (Ljava/lang/Object;)Z
    //   20: ifeq -> 75
    //   23: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   28: <illegal opcode> 107 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   33: invokestatic lIIIIIIIlIIIIIIl : (Ljava/lang/Object;)Z
    //   36: ifeq -> 75
    //   39: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   44: <illegal opcode> 107 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   49: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   54: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   59: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Ljava/lang/String;
    //   64: <illegal opcode> 108 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Ljava/lang/String;)Lnet/minecraft/client/network/NetworkPlayerInfo;
    //   69: invokestatic lIIIIIIIlIIIIIlI : (Ljava/lang/Object;)Z
    //   72: ifeq -> 206
    //   75: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   78: bipush #67
    //   80: iaload
    //   81: istore_1
    //   82: ldc ''
    //   84: invokevirtual length : ()I
    //   87: pop
    //   88: ldc_w ' '
    //   91: invokevirtual length : ()I
    //   94: ldc_w ' '
    //   97: invokevirtual length : ()I
    //   100: ldc_w ' '
    //   103: invokevirtual length : ()I
    //   106: ldc_w ' '
    //   109: invokevirtual length : ()I
    //   112: ishl
    //   113: ishl
    //   114: ishl
    //   115: bipush #98
    //   117: bipush #103
    //   119: ixor
    //   120: ldc_w ' '
    //   123: invokevirtual length : ()I
    //   126: ldc_w ' '
    //   129: invokevirtual length : ()I
    //   132: ishl
    //   133: ishl
    //   134: ixor
    //   135: ineg
    //   136: iflt -> 242
    //   139: bipush #58
    //   141: bipush #15
    //   143: ixor
    //   144: ldc_w ' '
    //   147: invokevirtual length : ()I
    //   150: ldc_w ' '
    //   153: invokevirtual length : ()I
    //   156: ishl
    //   157: ishl
    //   158: bipush #104
    //   160: bipush #95
    //   162: iadd
    //   163: sipush #181
    //   166: isub
    //   167: sipush #135
    //   170: iadd
    //   171: ixor
    //   172: bipush #43
    //   174: bipush #50
    //   176: ixor
    //   177: ldc_w ' '
    //   180: invokevirtual length : ()I
    //   183: ishl
    //   184: bipush #93
    //   186: bipush #36
    //   188: iadd
    //   189: bipush #52
    //   191: isub
    //   192: bipush #50
    //   194: iadd
    //   195: ixor
    //   196: ldc_w ' '
    //   199: invokevirtual length : ()I
    //   202: ineg
    //   203: ixor
    //   204: iand
    //   205: ireturn
    //   206: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   211: <illegal opcode> 107 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   216: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   221: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   226: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Ljava/lang/String;
    //   231: <illegal opcode> 108 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Ljava/lang/String;)Lnet/minecraft/client/network/NetworkPlayerInfo;
    //   236: <illegal opcode> 109 : (Lnet/minecraft/client/network/NetworkPlayerInfo;)I
    //   241: istore_1
    //   242: iload_1
    //   243: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	244	0	lllllllllllllllIllIllllllIIlllll	Lme/stupitdog/bhp/am;
    //   7	237	1	lllllllllllllllIllIllllllIIllllI	I
  }
  
  public int getWidth(au lllllllllllllllIllIllllllIIlllII) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   3: bipush #67
    //   5: iaload
    //   6: istore_2
    //   7: aload_1
    //   8: <illegal opcode> 51 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   16: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   19: bipush #91
    //   21: iaload
    //   22: aaload
    //   23: <illegal opcode> 52 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   28: invokestatic lIIIIIIIIlllllIl : (I)Z
    //   31: ifeq -> 89
    //   34: aload_1
    //   35: <illegal opcode> 53 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   40: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   45: istore_2
    //   46: ldc ''
    //   48: invokevirtual length : ()I
    //   51: pop
    //   52: ldc_w ' '
    //   55: invokevirtual length : ()I
    //   58: ineg
    //   59: iflt -> 186
    //   62: bipush #11
    //   64: iconst_2
    //   65: ixor
    //   66: ldc_w ' '
    //   69: invokevirtual length : ()I
    //   72: ishl
    //   73: bipush #117
    //   75: bipush #124
    //   77: ixor
    //   78: ldc_w ' '
    //   81: invokevirtual length : ()I
    //   84: ishl
    //   85: iconst_m1
    //   86: ixor
    //   87: iand
    //   88: ireturn
    //   89: aload_1
    //   90: <illegal opcode> 51 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   95: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   98: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   101: bipush #48
    //   103: iaload
    //   104: aaload
    //   105: <illegal opcode> 52 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   110: invokestatic lIIIIIIIlIIIIIII : (I)Z
    //   113: ifeq -> 186
    //   116: new java/lang/StringBuilder
    //   119: dup
    //   120: invokespecial <init> : ()V
    //   123: aload_1
    //   124: <illegal opcode> 53 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   129: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   137: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   140: bipush #92
    //   142: iaload
    //   143: aaload
    //   144: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: aload_1
    //   150: <illegal opcode> 51 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   155: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   163: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   166: bipush #93
    //   168: iaload
    //   169: aaload
    //   170: <illegal opcode> 56 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: <illegal opcode> 58 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   180: <illegal opcode> 72 : (Ljava/lang/String;)I
    //   185: istore_2
    //   186: iload_2
    //   187: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	188	0	lllllllllllllllIllIllllllIIlllIl	Lme/stupitdog/bhp/am;
    //   0	188	1	lllllllllllllllIllIllllllIIlllII	Lme/stupitdog/bhp/au;
    //   7	181	2	lllllllllllllllIllIllllllIIllIll	I
  }
  
  public String getAxisDirection() {
    // Byte code:
    //   0: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 110 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   15: <illegal opcode> 111 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   20: <illegal opcode> 112 : (Lnet/minecraft/util/math/Vec3i;)I
    //   25: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   28: iconst_1
    //   29: iaload
    //   30: invokestatic lIIIIIIIlIIIIIll : (II)Z
    //   33: ifeq -> 47
    //   36: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   39: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   42: bipush #94
    //   44: iaload
    //   45: aaload
    //   46: areturn
    //   47: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 110 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   62: <illegal opcode> 111 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   67: <illegal opcode> 112 : (Lnet/minecraft/util/math/Vec3i;)I
    //   72: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   75: bipush #67
    //   77: iaload
    //   78: invokestatic lIIIIIIIlIIIIIll : (II)Z
    //   81: ifeq -> 95
    //   84: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   87: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   90: bipush #33
    //   92: iaload
    //   93: aaload
    //   94: areturn
    //   95: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   100: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   105: <illegal opcode> 110 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   110: <illegal opcode> 111 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   115: <illegal opcode> 113 : (Lnet/minecraft/util/math/Vec3i;)I
    //   120: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   123: iconst_1
    //   124: iaload
    //   125: invokestatic lIIIIIIIlIIIIIll : (II)Z
    //   128: ifeq -> 142
    //   131: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   134: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   137: bipush #95
    //   139: iaload
    //   140: aaload
    //   141: areturn
    //   142: <illegal opcode> 31 : ()Lnet/minecraft/client/Minecraft;
    //   147: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   152: <illegal opcode> 110 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   157: <illegal opcode> 111 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   162: <illegal opcode> 113 : (Lnet/minecraft/util/math/Vec3i;)I
    //   167: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   170: bipush #67
    //   172: iaload
    //   173: invokestatic lIIIIIIIlIIIIIll : (II)Z
    //   176: ifeq -> 190
    //   179: getstatic me/stupitdog/bhp/am.lIllllllIIlllI : [Ljava/lang/String;
    //   182: getstatic me/stupitdog/bhp/am.lIlllllllIIIll : [I
    //   185: bipush #96
    //   187: iaload
    //   188: aaload
    //   189: areturn
    //   190: aconst_null
    //   191: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	192	0	lllllllllllllllIllIllllllIIllIlI	Lme/stupitdog/bhp/am;
  }
  
  static {
    lIIIIIIIIllllIll();
    lIIIIIIIIllllIIl();
    lIIIIIIIIllllIII();
    lIIIIIIIIlIIIIlI();
  }
  
  private static CallSite lllllIllllIllIl(MethodHandles.Lookup lllllllllllllllIllIllllllIIIlllI, String lllllllllllllllIllIllllllIIIllIl, MethodType lllllllllllllllIllIllllllIIIllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllllllIIlIlII = lIlllIlllIllII[Integer.parseInt(lllllllllllllllIllIllllllIIIllIl)].split(lIllllllIIlllI[lIlllllllIIIll[46]]);
      Class<?> lllllllllllllllIllIllllllIIlIIll = Class.forName(lllllllllllllllIllIllllllIIlIlII[lIlllllllIIIll[0]]);
      String lllllllllllllllIllIllllllIIlIIlI = lllllllllllllllIllIllllllIIlIlII[lIlllllllIIIll[1]];
      MethodHandle lllllllllllllllIllIllllllIIlIIIl = null;
      int lllllllllllllllIllIllllllIIlIIII = lllllllllllllllIllIllllllIIlIlII[lIlllllllIIIll[60]].length();
      if (lIIIIIIIlIIIIlII(lllllllllllllllIllIllllllIIlIIII, lIlllllllIIIll[2])) {
        MethodType lllllllllllllllIllIllllllIIlIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllllllIIlIlII[lIlllllllIIIll[2]], am.class.getClassLoader());
        if (lIIIIIIIlIIIIIll(lllllllllllllllIllIllllllIIlIIII, lIlllllllIIIll[2])) {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findVirtual(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIllI);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findStatic(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIllI);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllllllIIlIlIl = lIlllIlllIllIl[Integer.parseInt(lllllllllllllllIllIllllllIIlIlII[lIlllllllIIIll[2]])];
        if (lIIIIIIIlIIIIIll(lllllllllllllllIllIllllllIIlIIII, lIlllllllIIIll[60])) {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findGetter(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIlIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIIlIIIIIll(lllllllllllllllIllIllllllIIlIIII, lIlllllllIIIll[62])) {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findStaticGetter(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIlIl);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else if (lIIIIIIIlIIIIIll(lllllllllllllllIllIllllllIIlIIII, lIlllllllIIIll[63])) {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findSetter(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIlIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIllllllIIlIIIl = lllllllllllllllIllIllllllIIIlllI.findStaticSetter(lllllllllllllllIllIllllllIIlIIll, lllllllllllllllIllIllllllIIlIIlI, lllllllllllllllIllIllllllIIlIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllllllIIlIIIl);
    } catch (Exception lllllllllllllllIllIllllllIIIllll) {
      lllllllllllllllIllIllllllIIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIlIIIIlI() {
    lIlllIlllIllII = new String[lIlllllllIIIll[97]];
    lIlllIlllIllII[lIlllllllIIIll[73]] = lIllllllIIlllI[lIlllllllIIIll[98]];
    lIlllIlllIllII[lIlllllllIIIll[69]] = lIllllllIIlllI[lIlllllllIIIll[58]];
    lIlllIlllIllII[lIlllllllIIIll[79]] = lIllllllIIlllI[lIlllllllIIIll[99]];
    lIlllIlllIllII[lIlllllllIIIll[100]] = lIllllllIIlllI[lIlllllllIIIll[47]];
    lIlllIlllIllII[lIlllllllIIIll[101]] = lIllllllIIlllI[lIlllllllIIIll[102]];
    lIlllIlllIllII[lIlllllllIIIll[84]] = lIllllllIIlllI[lIlllllllIIIll[103]];
    lIlllIlllIllII[lIlllllllIIIll[82]] = lIllllllIIlllI[lIlllllllIIIll[104]];
    lIlllIlllIllII[lIlllllllIIIll[105]] = lIllllllIIlllI[lIlllllllIIIll[106]];
    lIlllIlllIllII[lIlllllllIIIll[80]] = lIllllllIIlllI[lIlllllllIIIll[30]];
    lIlllIlllIllII[lIlllllllIIIll[66]] = lIllllllIIlllI[lIlllllllIIIll[107]];
    lIlllIlllIllII[lIlllllllIIIll[26]] = lIllllllIIlllI[lIlllllllIIIll[88]];
    lIlllIlllIllII[lIlllllllIIIll[45]] = lIllllllIIlllI[lIlllllllIIIll[108]];
    lIlllIlllIllII[lIlllllllIIIll[17]] = lIllllllIIlllI[lIlllllllIIIll[109]];
    lIlllIlllIllII[lIlllllllIIIll[99]] = lIllllllIIlllI[lIlllllllIIIll[110]];
    lIlllIlllIllII[lIlllllllIIIll[111]] = lIllllllIIlllI[lIlllllllIIIll[112]];
    lIlllIlllIllII[lIlllllllIIIll[103]] = lIllllllIIlllI[lIlllllllIIIll[113]];
    lIlllIlllIllII[lIlllllllIIIll[7]] = lIllllllIIlllI[lIlllllllIIIll[13]];
    lIlllIlllIllII[lIlllllllIIIll[93]] = lIllllllIIlllI[lIlllllllIIIll[11]];
    lIlllIlllIllII[lIlllllllIIIll[48]] = lIllllllIIlllI[lIlllllllIIIll[114]];
    lIlllIlllIllII[lIlllllllIIIll[115]] = lIllllllIIlllI[lIlllllllIIIll[29]];
    lIlllIlllIllII[lIlllllllIIIll[47]] = lIllllllIIlllI[lIlllllllIIIll[116]];
    lIlllIlllIllII[lIlllllllIIIll[61]] = lIllllllIIlllI[lIlllllllIIIll[117]];
    lIlllIlllIllII[lIlllllllIIIll[74]] = lIllllllIIlllI[lIlllllllIIIll[43]];
    lIlllIlllIllII[lIlllllllIIIll[2]] = lIllllllIIlllI[lIlllllllIIIll[118]];
    lIlllIlllIllII[lIlllllllIIIll[86]] = lIllllllIIlllI[lIlllllllIIIll[12]];
    lIlllIlllIllII[lIlllllllIIIll[119]] = lIllllllIIlllI[lIlllllllIIIll[100]];
    lIlllIlllIllII[lIlllllllIIIll[75]] = lIllllllIIlllI[lIlllllllIIIll[22]];
    lIlllIlllIllII[lIlllllllIIIll[112]] = lIllllllIIlllI[lIlllllllIIIll[44]];
    lIlllIlllIllII[lIlllllllIIIll[6]] = lIllllllIIlllI[lIlllllllIIIll[45]];
    lIlllIlllIllII[lIlllllllIIIll[38]] = lIllllllIIlllI[lIlllllllIIIll[120]];
    lIlllIlllIllII[lIlllllllIIIll[121]] = lIllllllIIlllI[lIlllllllIIIll[119]];
    lIlllIlllIllII[lIlllllllIIIll[95]] = lIllllllIIlllI[lIlllllllIIIll[122]];
    lIlllIlllIllII[lIlllllllIIIll[72]] = lIllllllIIlllI[lIlllllllIIIll[34]];
    lIlllIlllIllII[lIlllllllIIIll[110]] = lIllllllIIlllI[lIlllllllIIIll[42]];
    lIlllIlllIllII[lIlllllllIIIll[44]] = lIllllllIIlllI[lIlllllllIIIll[123]];
    lIlllIlllIllII[lIlllllllIIIll[42]] = lIllllllIIlllI[lIlllllllIIIll[23]];
    lIlllIlllIllII[lIlllllllIIIll[33]] = lIllllllIIlllI[lIlllllllIIIll[124]];
    lIlllIlllIllII[lIlllllllIIIll[49]] = lIllllllIIlllI[lIlllllllIIIll[125]];
    lIlllIlllIllII[lIlllllllIIIll[125]] = lIllllllIIlllI[lIlllllllIIIll[40]];
    lIlllIlllIllII[lIlllllllIIIll[126]] = lIllllllIIlllI[lIlllllllIIIll[105]];
    lIlllIlllIllII[lIlllllllIIIll[30]] = lIllllllIIlllI[lIlllllllIIIll[6]];
    lIlllIlllIllII[lIlllllllIIIll[127]] = lIllllllIIlllI[lIlllllllIIIll[101]];
    lIlllIlllIllII[lIlllllllIIIll[68]] = lIllllllIIlllI[lIlllllllIIIll[26]];
    lIlllIlllIllII[lIlllllllIIIll[104]] = lIllllllIIlllI[lIlllllllIIIll[128]];
    lIlllIlllIllII[lIlllllllIIIll[52]] = lIllllllIIlllI[lIlllllllIIIll[129]];
    lIlllIlllIllII[lIlllllllIIIll[20]] = lIllllllIIlllI[lIlllllllIIIll[130]];
    lIlllIlllIllII[lIlllllllIIIll[131]] = lIllllllIIlllI[lIlllllllIIIll[132]];
    lIlllIlllIllII[lIlllllllIIIll[22]] = lIllllllIIlllI[lIlllllllIIIll[56]];
    lIlllIlllIllII[lIlllllllIIIll[62]] = lIllllllIIlllI[lIlllllllIIIll[133]];
    lIlllIlllIllII[lIlllllllIIIll[114]] = lIllllllIIlllI[lIlllllllIIIll[131]];
    lIlllIlllIllII[lIlllllllIIIll[113]] = lIllllllIIlllI[lIlllllllIIIll[61]];
    lIlllIlllIllII[lIlllllllIIIll[129]] = lIllllllIIlllI[lIlllllllIIIll[115]];
    lIlllIlllIllII[lIlllllllIIIll[34]] = lIllllllIIlllI[lIlllllllIIIll[127]];
    lIlllIlllIllII[lIlllllllIIIll[58]] = lIllllllIIlllI[lIlllllllIIIll[134]];
    lIlllIlllIllII[lIlllllllIIIll[91]] = lIllllllIIlllI[lIlllllllIIIll[135]];
    lIlllIlllIllII[lIlllllllIIIll[40]] = lIllllllIIlllI[lIlllllllIIIll[111]];
    lIlllIlllIllII[lIlllllllIIIll[134]] = lIllllllIIlllI[lIlllllllIIIll[136]];
    lIlllIlllIllII[lIlllllllIIIll[70]] = lIllllllIIlllI[lIlllllllIIIll[126]];
    lIlllIlllIllII[lIlllllllIIIll[1]] = lIllllllIIlllI[lIlllllllIIIll[7]];
    lIlllIlllIllII[lIlllllllIIIll[63]] = lIllllllIIlllI[lIlllllllIIIll[137]];
    lIlllIlllIllII[lIlllllllIIIll[123]] = lIllllllIIlllI[lIlllllllIIIll[138]];
    lIlllIlllIllII[lIlllllllIIIll[108]] = lIllllllIIlllI[lIlllllllIIIll[139]];
    lIlllIlllIllII[lIlllllllIIIll[11]] = lIllllllIIlllI[lIlllllllIIIll[140]];
    lIlllIlllIllII[lIlllllllIIIll[19]] = lIllllllIIlllI[lIlllllllIIIll[121]];
    lIlllIlllIllII[lIlllllllIIIll[71]] = lIllllllIIlllI[lIlllllllIIIll[141]];
    lIlllIlllIllII[lIlllllllIIIll[12]] = lIllllllIIlllI[lIlllllllIIIll[142]];
    lIlllIlllIllII[lIlllllllIIIll[139]] = lIllllllIIlllI[lIlllllllIIIll[97]];
    lIlllIlllIllII[lIlllllllIIIll[137]] = lIllllllIIlllI[lIlllllllIIIll[143]];
    lIlllIlllIllII[lIlllllllIIIll[130]] = lIllllllIIlllI[lIlllllllIIIll[41]];
    lIlllIlllIllII[lIlllllllIIIll[14]] = lIllllllIIlllI[lIlllllllIIIll[144]];
    lIlllIlllIllII[lIlllllllIIIll[98]] = lIllllllIIlllI[lIlllllllIIIll[145]];
    lIlllIlllIllII[lIlllllllIIIll[76]] = lIllllllIIlllI[lIlllllllIIIll[146]];
    lIlllIlllIllII[lIlllllllIIIll[120]] = lIllllllIIlllI[lIlllllllIIIll[147]];
    lIlllIlllIllII[lIlllllllIIIll[117]] = lIllllllIIlllI[lIlllllllIIIll[148]];
    lIlllIlllIllII[lIlllllllIIIll[23]] = lIllllllIIlllI[lIlllllllIIIll[3]];
    lIlllIlllIllII[lIlllllllIIIll[13]] = lIllllllIIlllI[lIlllllllIIIll[51]];
    lIlllIlllIllII[lIlllllllIIIll[124]] = lIllllllIIlllI[lIlllllllIIIll[149]];
    lIlllIlllIllII[lIlllllllIIIll[109]] = lIllllllIIlllI[lIlllllllIIIll[35]];
    lIlllIlllIllII[lIlllllllIIIll[65]] = lIllllllIIlllI[lIlllllllIIIll[150]];
    lIlllIlllIllII[lIlllllllIIIll[0]] = lIllllllIIlllI[lIlllllllIIIll[8]];
    lIlllIlllIllII[lIlllllllIIIll[29]] = lIllllllIIlllI[lIlllllllIIIll[151]];
    lIlllIlllIllII[lIlllllllIIIll[135]] = lIllllllIIlllI[lIlllllllIIIll[36]];
    lIlllIlllIllII[lIlllllllIIIll[89]] = lIllllllIIlllI[lIlllllllIIIll[152]];
    lIlllIlllIllII[lIlllllllIIIll[88]] = lIllllllIIlllI[lIlllllllIIIll[153]];
    lIlllIlllIllII[lIlllllllIIIll[56]] = lIllllllIIlllI[lIlllllllIIIll[154]];
    lIlllIlllIllII[lIlllllllIIIll[46]] = lIllllllIIlllI[lIlllllllIIIll[155]];
    lIlllIlllIllII[lIlllllllIIIll[43]] = lIllllllIIlllI[lIlllllllIIIll[156]];
    lIlllIlllIllII[lIlllllllIIIll[64]] = lIllllllIIlllI[lIlllllllIIIll[157]];
    lIlllIlllIllII[lIlllllllIIIll[132]] = lIllllllIIlllI[lIlllllllIIIll[158]];
    lIlllIlllIllII[lIlllllllIIIll[107]] = lIllllllIIlllI[lIlllllllIIIll[159]];
    lIlllIlllIllII[lIlllllllIIIll[81]] = lIllllllIIlllI[lIlllllllIIIll[160]];
    lIlllIlllIllII[lIlllllllIIIll[92]] = lIllllllIIlllI[lIlllllllIIIll[161]];
    lIlllIlllIllII[lIlllllllIIIll[133]] = lIllllllIIlllI[lIlllllllIIIll[162]];
    lIlllIlllIllII[lIlllllllIIIll[85]] = lIllllllIIlllI[lIlllllllIIIll[163]];
    lIlllIlllIllII[lIlllllllIIIll[106]] = lIllllllIIlllI[lIlllllllIIIll[164]];
    lIlllIlllIllII[lIlllllllIIIll[83]] = lIllllllIIlllI[lIlllllllIIIll[165]];
    lIlllIlllIllII[lIlllllllIIIll[141]] = lIllllllIIlllI[lIlllllllIIIll[37]];
    lIlllIlllIllII[lIlllllllIIIll[78]] = lIllllllIIlllI[lIlllllllIIIll[15]];
    lIlllIlllIllII[lIlllllllIIIll[16]] = lIllllllIIlllI[lIlllllllIIIll[54]];
    lIlllIlllIllII[lIlllllllIIIll[94]] = lIllllllIIlllI[lIlllllllIIIll[166]];
    lIlllIlllIllII[lIlllllllIIIll[60]] = lIllllllIIlllI[lIlllllllIIIll[167]];
    lIlllIlllIllII[lIlllllllIIIll[142]] = lIllllllIIlllI[lIlllllllIIIll[168]];
    lIlllIlllIllII[lIlllllllIIIll[140]] = lIllllllIIlllI[lIlllllllIIIll[169]];
    lIlllIlllIllII[lIlllllllIIIll[122]] = lIllllllIIlllI[lIlllllllIIIll[28]];
    lIlllIlllIllII[lIlllllllIIIll[24]] = lIllllllIIlllI[lIlllllllIIIll[32]];
    lIlllIlllIllII[lIlllllllIIIll[77]] = lIllllllIIlllI[lIlllllllIIIll[170]];
    lIlllIlllIllII[lIlllllllIIIll[128]] = lIllllllIIlllI[lIlllllllIIIll[171]];
    lIlllIlllIllII[lIlllllllIIIll[18]] = lIllllllIIlllI[lIlllllllIIIll[172]];
    lIlllIlllIllII[lIlllllllIIIll[90]] = lIllllllIIlllI[lIlllllllIIIll[173]];
    lIlllIlllIllII[lIlllllllIIIll[96]] = lIllllllIIlllI[lIlllllllIIIll[174]];
    lIlllIlllIllII[lIlllllllIIIll[116]] = lIllllllIIlllI[lIlllllllIIIll[55]];
    lIlllIlllIllII[lIlllllllIIIll[102]] = lIllllllIIlllI[lIlllllllIIIll[39]];
    lIlllIlllIllII[lIlllllllIIIll[136]] = lIllllllIIlllI[lIlllllllIIIll[175]];
    lIlllIlllIllII[lIlllllllIIIll[87]] = lIllllllIIlllI[lIlllllllIIIll[176]];
    lIlllIlllIllII[lIlllllllIIIll[118]] = lIllllllIIlllI[lIlllllllIIIll[59]];
    lIlllIlllIllII[lIlllllllIIIll[138]] = lIllllllIIlllI[lIlllllllIIIll[53]];
    lIlllIlllIllIl = new Class[lIlllllllIIIll[73]];
    lIlllIlllIllIl[lIlllllllIIIll[69]] = int.class;
    lIlllIlllIllIl[lIlllllllIIIll[60]] = Minecraft.class;
    lIlllIlllIllIl[lIlllllllIIIll[72]] = Timer.class;
    lIlllIlllIllIl[lIlllllllIIIll[19]] = EntityPlayerSP.class;
    lIlllIlllIllIl[lIlllllllIIIll[62]] = RenderGameOverlayEvent.ElementType.class;
    lIlllIlllIllIl[lIlllllllIIIll[71]] = float.class;
    lIlllIlllIllIl[lIlllllllIIIll[68]] = double.class;
    lIlllIlllIllIl[lIlllllllIIIll[2]] = Potion.class;
    lIlllIlllIllIl[lIlllllllIIIll[65]] = ArrayList.class;
    lIlllIlllIllIl[lIlllllllIIIll[18]] = TextFormatting.class;
    lIlllIlllIllIl[lIlllllllIIIll[0]] = f13.class;
    lIlllIlllIllIl[lIlllllllIIIll[64]] = av.class;
    lIlllIlllIllIl[lIlllllllIIIll[70]] = ft.class;
    lIlllIlllIllIl[lIlllllllIIIll[66]] = String.class;
    lIlllIlllIllIl[lIlllllllIIIll[63]] = f9.class;
    lIlllIlllIllIl[lIlllllllIIIll[1]] = Map.class;
  }
  
  private static void lIIIIIIIIllllIII() {
    lIllllllIIlllI = new String[lIlllllllIIIll[177]];
    lIllllllIIlllI[lIlllllllIIIll[0]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[0]], lIlllllllIIIlI[lIlllllllIIIll[1]]);
    lIllllllIIlllI[lIlllllllIIIll[1]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[2]], lIlllllllIIIlI[lIlllllllIIIll[60]]);
    lIllllllIIlllI[lIlllllllIIIll[2]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[62]], lIlllllllIIIlI[lIlllllllIIIll[63]]);
    lIllllllIIlllI[lIlllllllIIIll[60]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[64]], lIlllllllIIIlI[lIlllllllIIIll[65]]);
    lIllllllIIlllI[lIlllllllIIIll[62]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[66]], lIlllllllIIIlI[lIlllllllIIIll[19]]);
    lIllllllIIlllI[lIlllllllIIIll[63]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[18]], lIlllllllIIIlI[lIlllllllIIIll[68]]);
    lIllllllIIlllI[lIlllllllIIIll[64]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[69]], lIlllllllIIIlI[lIlllllllIIIll[70]]);
    lIllllllIIlllI[lIlllllllIIIll[65]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[71]], lIlllllllIIIlI[lIlllllllIIIll[72]]);
    lIllllllIIlllI[lIlllllllIIIll[66]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[73]], lIlllllllIIIlI[lIlllllllIIIll[74]]);
    lIllllllIIlllI[lIlllllllIIIll[19]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[75]], lIlllllllIIIlI[lIlllllllIIIll[76]]);
    lIllllllIIlllI[lIlllllllIIIll[18]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[77]], lIlllllllIIIlI[lIlllllllIIIll[78]]);
    lIllllllIIlllI[lIlllllllIIIll[68]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[79]], lIlllllllIIIlI[lIlllllllIIIll[14]]);
    lIllllllIIlllI[lIlllllllIIIll[69]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[80]], lIlllllllIIIlI[lIlllllllIIIll[81]]);
    lIllllllIIlllI[lIlllllllIIIll[70]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[82]], lIlllllllIIIlI[lIlllllllIIIll[83]]);
    lIllllllIIlllI[lIlllllllIIIll[71]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[84]], lIlllllllIIIlI[lIlllllllIIIll[24]]);
    lIllllllIIlllI[lIlllllllIIIll[72]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[85]], lIlllllllIIIlI[lIlllllllIIIll[38]]);
    lIllllllIIlllI[lIlllllllIIIll[73]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[86]], lIlllllllIIIlI[lIlllllllIIIll[87]]);
    lIllllllIIlllI[lIlllllllIIIll[74]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[20]], lIlllllllIIIlI[lIlllllllIIIll[17]]);
    lIllllllIIlllI[lIlllllllIIIll[75]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[16]], lIlllllllIIIlI[lIlllllllIIIll[52]]);
    lIllllllIIlllI[lIlllllllIIIll[76]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[89]], lIlllllllIIIlI[lIlllllllIIIll[49]]);
    lIllllllIIlllI[lIlllllllIIIll[77]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[90]], lIlllllllIIIlI[lIlllllllIIIll[91]]);
    lIllllllIIlllI[lIlllllllIIIll[78]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[48]], lIlllllllIIIlI[lIlllllllIIIll[92]]);
    lIllllllIIlllI[lIlllllllIIIll[79]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[93]], lIlllllllIIIlI[lIlllllllIIIll[94]]);
    lIllllllIIlllI[lIlllllllIIIll[14]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[33]], lIlllllllIIIlI[lIlllllllIIIll[95]]);
    lIllllllIIlllI[lIlllllllIIIll[80]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[96]], lIlllllllIIIlI[lIlllllllIIIll[46]]);
    lIllllllIIlllI[lIlllllllIIIll[81]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[98]], lIlllllllIIIlI[lIlllllllIIIll[58]]);
    lIllllllIIlllI[lIlllllllIIIll[82]] = lIIIIIIIIlIIIlIl(lIlllllllIIIlI[lIlllllllIIIll[99]], lIlllllllIIIlI[lIlllllllIIIll[47]]);
    lIllllllIIlllI[lIlllllllIIIll[83]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[102]], lIlllllllIIIlI[lIlllllllIIIll[103]]);
    lIllllllIIlllI[lIlllllllIIIll[84]] = lIIIIIIIIlIIIIll(lIlllllllIIIlI[lIlllllllIIIll[104]], lIlllllllIIIlI[lIlllllllIIIll[106]]);
    lIllllllIIlllI[lIlllllllIIIll[24]] = lIIIIIIIIlIIIlII(lIlllllllIIIlI[lIlllllllIIIll[30]], lIlllllllIIIlI[lIlllllllIIIll[107]]);
    lIllllllIIlllI[lIlllllllIIIll[85]] = lIIIIIIIIlIIIlII("CbN6zAOdj5s=", "viWQq");
    lIllllllIIlllI[lIlllllllIIIll[38]] = lIIIIIIIIlIIIlIl("NgYePVU=", "fopZu");
    lIllllllIIlllI[lIlllllllIIIll[86]] = lIIIIIIIIlIIIlII("3quoNhkFKLM=", "vftpc");
    lIllllllIIlllI[lIlllllllIIIll[87]] = lIIIIIIIIlIIIlII("wWFgyfcJJgQ=", "DXzol");
    lIllllllIIlllI[lIlllllllIIIll[20]] = lIIIIIIIIlIIIIll("3IiPJx1L8wo=", "VkwHu");
    lIllllllIIlllI[lIlllllllIIIll[17]] = lIIIIIIIIlIIIlII("DQ6RmqQRwdc=", "ZchNE");
    lIllllllIIlllI[lIlllllllIIIll[16]] = lIIIIIIIIlIIIlIl("ND00aw==", "rmgKC");
    lIllllllIIlllI[lIlllllllIIIll[52]] = lIIIIIIIIlIIIlII("oUBdvrMQrNY=", "OWGyt");
    lIllllllIIlllI[lIlllllllIIIll[89]] = lIIIIIIIIlIIIIll("8Xag8S0N03s=", "Zsvrc");
    lIllllllIIlllI[lIlllllllIIIll[49]] = lIIIIIIIIlIIIlIl("", "AUmVH");
    lIllllllIIlllI[lIlllllllIIIll[90]] = lIIIIIIIIlIIIlII("TwrGkEiJM1Q=", "AirEd");
    lIllllllIIlllI[lIlllllllIIIll[91]] = lIIIIIIIIlIIIIll("KqKV52ZW39Q=", "omGih");
    lIllllllIIlllI[lIlllllllIIIll[48]] = lIIIIIIIIlIIIlIl("", "rumTu");
    lIllllllIIlllI[lIlllllllIIIll[92]] = lIIIIIIIIlIIIIll("vEJ+yCJIP0Y=", "xAXku");
    lIllllllIIlllI[lIlllllllIIIll[93]] = lIIIIIIIIlIIIlII("1chs9HW3I9E=", "qoMOy");
    lIllllllIIlllI[lIlllllllIIIll[94]] = lIIIIIIIIlIIIIll("m8tc1XrEN5Q=", "cPNnk");
    lIllllllIIlllI[lIlllllllIIIll[33]] = lIIIIIIIIlIIIlII("A33/TUDviJM=", "miYDc");
    lIllllllIIlllI[lIlllllllIIIll[95]] = lIIIIIIIIlIIIIll("AkXayYhrBwU=", "MNjUp");
    lIllllllIIlllI[lIlllllllIIIll[96]] = lIIIIIIIIlIIIlIl("az8=", "FeuMW");
    lIllllllIIlllI[lIlllllllIIIll[46]] = lIIIIIIIIlIIIIll("sBRcE05IIcc=", "NufZu");
    lIllllllIIlllI[lIlllllllIIIll[98]] = lIIIIIIIIlIIIlII("lEBc5PL5D/L+WiBGFx+KXHYnySMHKB6P2hy5ld6po1u0G0h+qxjM32m0ROdHqLQh2DZ2pslpCJE=", "tellB");
    lIllllllIIlllI[lIlllllllIIIll[58]] = lIIIIIIIIlIIIIll("oJ1sOCCHtlLHm1eNjZovyDDRlPf8a5rQcKtp9B+7aKQ/ZO89Ng+/GvSQS2eLoZDX7t3bhT2o8UU=", "CxReU");
    lIllllllIIlllI[lIlllllllIIIll[99]] = lIIIIIIIIlIIIlIl("IjAsTB0lOz0BAi0zLEwZIjwsTD0jNx0EFik2LBFKKjw9DhQTYm5WQ3oKLVhCdnV4QlA=", "LUXbp");
    lIllllllIIlllI[lIlllllllIIIll[47]] = lIIIIIIIIlIIIIll("M+V4yNDKtFBrM9kh2sjmUgWgwupSXNUUsB+gVH/ekIc=", "uxSav");
    lIllllllIIlllI[lIlllllllIIIll[102]] = lIIIIIIIIlIIIlIl("HyEjaQ8YKjIkEBAiIyENAyMyaQEdLTIpFl8hISIMBWoFIgwVISUAAxwhGDEHAyg2PicHITkzRjQoMioHHzADPhIUfhYLLktwbWdCUWQ=", "qDWGb");
    lIllllllIIlllI[lIlllllllIIIll[103]] = lIIIIIIIIlIIIlIl("KBEHZiYvGhYrOScSB2YiKB0HZgYpFjYuLSMXBztxIB0WJC8ZRUtwf3RALDFxdE5TaGtm", "FtsHK");
    lIllllllIIlllI[lIlllllllIIIll[104]] = lIIIIIIIIlIIIIll("tEoyRBy4+lSr5L2w72kkyF8jifLJuVW7Stoqren2aioZDJGj/d4924Bgfye/2fKY/BwYd7FFs1o=", "PXPLT");
    lIllllllIIlllI[lIlllllllIIIll[106]] = lIIIIIIIIlIIIIll("DUQU62ozDdN1M0YeQBOMx60W0/w+W6EyFgFIblzgq+X76a5jegqI1g==", "uFdHK");
    lIllllllIIlllI[lIlllllllIIIll[30]] = lIIIIIIIIlIIIlII("PdeBvWA+T/uMQBejrG+eO/UzIfnbZtx+bv+D34IdfZ/ZvhD/2fy20mR1XyBUmhic4w0Meybax2I=", "LbItu");
    lIllllllIIlllI[lIlllllllIIIll[107]] = lIIIIIIIIlIIIIll("0DYs0f3RFPioNl9tFUbQcLoy9nEVK/c5iqp0iEmtmSy/+RoifELTh5NKgJYxeAdz7dYqEATPS6g=", "eVxPk");
    lIllllllIIlllI[lIlllllllIIIll[88]] = lIIIIIIIIlIIIIll("TU+clhp6ftzeKD9Bnf5aZ28l8tdtjbukdoNRY8ZLcvu+TC124UAzVQmP+NaeoXTYFJQPos605icJRuP8ebt3jrxz4ufkYb9+", "GlMAt");
    lIllllllIIlllI[lIlllllllIIIll[108]] = lIIIIIIIIlIIIlIl("EDcVMnwWNw00fCkiETo8HRQWOj4eMxFpMwomBj02QH4neh4QNxUyfRY3DTR9KSIROjwdFBY6Ph4zEWhoWnY=", "zVcSR");
    lIllllllIIlllI[lIlllllllIIIll[109]] = lIIIIIIIIlIIIlIl("BAtIByIcHg8AMgYJSBY+GUAATWwEAQIBOgwjBxo3DgsUTmBTTkZU", "inftV");
    lIllllllIIlllI[lIlllllllIIIll[110]] = lIIIIIIIIlIIIIll("OpuBtijzDayaOH4ekRalD6cBqJf+hUbzBH465e4EEwoBkDebwYz0bTDgDC6EwLf+PDkoYAoTzOjfEIx8y9oZKA==", "qSlsu");
    lIllllllIIlllI[lIlllllllIIIll[112]] = lIIIIIIIIlIIIlIl("OjM5TAk9OCgBFjUwOUwRID8hTDA9OygQXjI/KA4AC2d0VlVgbxIHXmVid0JEdA==", "TVMbd");
    lIllllllIIlllI[lIlllllllIIIll[113]] = lIIIIIIIIlIIIIll("Bozs1KMRrkx18t0WzDnNtsNzlujq9ZAoGth1KlhpTcI1XZPeyvqFOzRVfCpONc8NetNkmhpHyV9REog963gYExeAgZTMlMWDEVoErOXyR+8=", "RScQp");
    lIllllllIIlllI[lIlllllllIIIll[13]] = lIIIIIIIIlIIIlII("9bs39QHFVM/1ppanc4AyRe1JarmeIvZR5CpoMlPjK37Ydmb4+gySRuNnAJOSjN7j5GORQobOqdtazRHJpvDig4shA0AToywiHl5A3aWXTdZW98bXSrt4UJKFi8gTTOVinGnQ8pcYrNlINn3mcvMbuq+TF7BEpPIELtgK+80UQ5YHtEh8c91MnQ==", "kOIQi");
    lIllllllIIlllI[lIlllllllIIIll[11]] = lIIIIIIIIlIIIIll("WyrpaIsX/oBw60SC940QTRQ7kLF4ojg/zM30lAFgzeyqiitLNWZC6w==", "oVWHb");
    lIllllllIIlllI[lIlllllllIIIll[114]] = lIIIIIIIIlIIIlIl("DDEtSz4LOjwGIQMyLUswDj08CydMGTALNgEmOAMnWDIwAD8GC25UZ1FtBgJpW255RXM=", "bTYeS");
    lIllllllIIlllI[lIlllllllIIIll[29]] = lIIIIIIIIlIIIlII("olh01d6UhREZbmsAY+dkITyesAyBBD9UxO4U6J5Q2H4/xLKCcawnscIWMcIqYn0ztlqztPqLIdU=", "BrKHe");
    lIllllllIIlllI[lIlllllllIIIll[116]] = lIIIIIIIIlIIIlII("yw4oymPHY+1iAUW2H2QVg3tnW1W2eSxGzqMIR2O2gTyImO1zgSVcPXAnpgdOBH57jsL00WD98kA=", "owxfd");
    lIllllllIIlllI[lIlllllllIIIll[117]] = lIIIIIIIIlIIIIll("6mve2uIjVCtHcLnQQwvxzXJaszdf+gIImte0bD1DakYgLtM9P0iexXXBUP0ouzKuYG0kMBRFssY=", "SrttT");
    lIllllllIIlllI[lIlllllllIIIll[43]] = lIIIIIIIIlIIIlIl("BCIbQgkDKQoPFgshG0INBC4bQikFJSoKAg8kGx9eDC4KAAA1cFlYUFsYH1ZWUGdPTEQ=", "jGold");
    lIllllllIIlllI[lIlllllllIIIll[118]] = lIIIIIIIIlIIIIll("oqrzh1ZcCv0QjmnAnPT6e8j2vYdzhv9ElMCZq0Xaurmw9Ld+l+jDSvol2DmEBJL7", "YdFud");
    lIllllllIIlllI[lIlllllllIIIll[12]] = lIIIIIIIIlIIIlIl("KCoXRAIvIQYJHScpFwwANCgGRAwqJgYEG2gqFQ8BMmExDwEiKhEtDisqLBwKNCMCEyowKg0eVSEqFz4WNipZQkYKIQYeQCsmDQ8MNC4FHgkpPQQPQCUjCg8BMmAGHAooO0w4CigrBhgoJyIGJRkjPQ8LFgM5BgQbYgoPDwIjIRc+FjYqWFBPZg==", "FOcjo");
    lIllllllIIlllI[lIlllllllIIIll[100]] = lIIIIIIIIlIIIlIl("Iy5vNAQ7OygzFCEsbyUYPmUnfkorPSQpBB45LiQVPTguNUp/eHtnUG4=", "NKAGp");
    lIllllllIIlllI[lIlllllllIIIll[22]] = lIIIIIIIIlIIIIll("LPCNikpaLeXG3nSCTVmR0A4MLFAXP3Ohr34moWmSLdm+EGr+7g1VHCeUT1XXEuFtZAFF6bnfZTY=", "FiEqr");
    lIllllllIIlllI[lIlllllllIIIll[44]] = lIIIIIIIIlIIIlII("00abJXXJfY99GNtWCrJRL4Q57vAVpxaNScMS4o2fsuM=", "EUVzl");
    lIllllllIIlllI[lIlllllllIIIll[45]] = lIIIIIIIIlIIIlII("jdG+LPt5sKA1EjFmmLGjwH+hduy1WzKmGZ9BHmfUtlBQeOcO5fKDNAzZTeEV7tOFxFYMqVWaz7E=", "fWeHn");
    lIllllllIIlllI[lIlllllllIIIll[120]] = lIIIIIIIIlIIIlIl("BDNkHgQcJiMZFAYxZA8YGXgrAEoENXBeSkl2ak0=", "iVJmp");
    lIllllllIIlllI[lIlllllllIIIll[119]] = lIIIIIIIIlIIIIll("pBzQY2Lc811yjs+l8d65H7epGC7LVLd/8G6dR5cNQT1u50NINKvqZABB8WeAK0ofl6+KPulLjEs=", "NOejI");
    lIllllllIIlllI[lIlllllllIIIll[122]] = lIIIIIIIIlIIIIll("4sDdhLlBeZ/B7RBMtu2CUCAQx2wZvEsb1rdpGjWcaJV+6WtMaHV9w42EthZeBMKy", "MevJI");
    lIllllllIIlllI[lIlllllllIIIll[34]] = lIIIIIIIIlIIIlII("B9YbRXNofPl3L5sMLHE0IcKQG6nk4O1K7kFeJwpTYDqdBJ3DIs8uG+he/FG9MeknvnLNwV9YILQ=", "BAkBG");
    lIllllllIIlllI[lIlllllllIIIll[42]] = lIIIIIIIIlIIIlIl("KyAmYCQsKzctOyQjJmAqKSw3ID1rIDw6IDE8fAsnMSwmNxkpJCsrOxYVaCggICk2EX50dWt9FicOaH97f2Vybg==", "EERNI");
    lIllllllIIlllI[lIlllllllIIIll[123]] = lIIIIIIIIlIIIIll("JMpiM8H5kX3eqVs2ZBo1QhBwPI5ECXW2Ru6k4Cjjg/o=", "xlWvi");
    lIllllllIIlllI[lIlllllllIIIll[23]] = lIIIIIIIIlIIIIll("YsGqekqGYx6Q98DDln6YGlgKYFDmx/1GOopeZCP9tMWyjY5n0Dji7U8L1T6ik7kOCiwpziceRqoKiJ9W4JfHJg==", "MgRMH");
    lIllllllIIlllI[lIlllllllIIIll[124]] = lIIIIIIIIlIIIlII("I5LvKUC04dFERPWn0zQStfuVHCx159exXV4tloQYo6+omvm8F/vaPg==", "Tutoz");
    lIllllllIIlllI[lIlllllllIIIll[125]] = lIIIIIIIIlIIIlII("e+5Bl6RR27aHXczpzcCKewoOZYKLf+epgujviqOc+O5nAsYgsbSUug==", "yxQOA");
    lIllllllIIlllI[lIlllllllIIIll[40]] = lIIIIIIIIlIIIlII("N7Ffnuw4iU52Pt3/ss3DTeCkMyJjTvC7M7h6uE7Kab06ompOTZbRCpM0zb8Gi+4Dj+hMCV/CBRCj1kYhN2JADw==", "jPZrk");
    lIllllllIIlllI[lIlllllllIIIll[105]] = lIIIIIIIIlIIIlIl("Gw4WdzccBQc6KBQNFnc5GQIHNy5bJgs3PxYZAz8uTw0XNzkqWlZua0RfPSxgXUIuNz8BRA8wNBAIEDg8AUQBNTMQBRZ2NBAfFTYoHkQsPC49Cgw9NhAZMjU7DCgOMD8bH1ljelU=", "ukbYZ");
    lIllllllIIlllI[lIlllllllIIIll[6]] = lIIIIIIIIlIIIlIl("IgISK0kkAgotSRsXFiMJLyERIwssBhZwEycwEDgOJgReYk4ECQU8BmcPBSQAZzAQOA4mBF9wR2g=", "HcdJg");
    lIllllllIIlllI[lIlllllllIIIll[101]] = lIIIIIIIIlIIIlIl("AhAFTRoFGxQABQ0TBU0UABwUDQNCEB8XHhgMXyYZGBwFGicAFAgGBT8lSwUeCRkVPEBcREdaKB1PQFJNTFVR", "luqcw");
    lIllllllIIlllI[lIlllllllIIIll[26]] = lIIIIIIIIlIIIlIl("LSM3TwMqKCYCHCIgN08HLS83TyMsJAYHCCYlNxJUJS8mDQoccXVVXXMZKVtceWZjQU4=", "CFCan");
    lIllllllIIlllI[lIlllllllIIIll[128]] = lIIIIIIIIlIIIlII("aflkfugEawfLzBmLRnSDYWDPuhCRKpyvTR4pxjuDSn92sRJvBIt/guM3cQmQAvWIgaosEswWMGTbWIqaO/N/fGcuLwG4PxuCyyyAaCNtzho=", "fcQeN");
    lIllllllIIlllI[lIlllllllIIIll[129]] = lIIIIIIIIlIIIlIl("GRcALGUGAh8hZTIEBCwyPx8FOXEAGQQ5cVs6HCw9ElkDOSIfWTUiJgMXBCw/HARNZB1JVlY=", "svvMK");
    lIllllllIIlllI[lIlllllllIIIll[130]] = lIIIIIIIIlIIIlII("b5X6dwxScSv93V4jOoe25pYMujeyFvoQNQMfiKzp2oK7jRHWD9bC8w==", "pwHhZ");
    lIllllllIIlllI[lIlllllllIIIll[132]] = lIIIIIIIIlIIIlIl("LD0tYjgrNjwvJyM+LWI2LjE8IiFsKjw/OjcqOikmbBFodDt4PiwiNh1panlld2oGLW9qFDMtIyN3NS07JXcKOCcrNj53Dg4yODo0bTQ4IjJtFzsmMCEsYmUZKDkvLXouOTcrehEsKyU7JWNjbA==", "BXYLU");
    lIllllllIIlllI[lIlllllllIIIll[56]] = lIIIIIIIIlIIIIll("kC2dP5kPEpQPOhQtRgsn8ZZRutyKeo7NyYZCymPBcsk0v7ggFArYKw==", "uSCAu");
    lIllllllIIlllI[lIlllllllIIIll[133]] = lIIIIIIIIlIIIIll("DB8psv5GqnSSimR1Hw/ngmMOQv+TD3IMrpqMOIkvJ/hcEEHMnyipA2pn/h+H/Mb0d0x4Z7HcarVjyRhJi2ZYUSNtPZnOwyBqG7e5R67gT1I=", "bFDAg");
    lIllllllIIlllI[lIlllllllIIIll[131]] = lIIIIIIIIlIIIlII("7MOTjZDqVpmWaTtM4A6ifVQZz0N8AV3rFd/95dqbtvh2tpBpQZhIlmVUcjIZpkSzvJIjLKl5rxc=", "KsomV");
    lIllllllIIlllI[lIlllllllIIIll[61]] = lIIIIIIIIlIIIlIl("Ey07MmYVLSM0ZjUjIzRyDSMeJzoQIippYDNlATkpDy1iPykXK2IAPAslIzRzQ2w=", "yLMSH");
    lIllllllIIlllI[lIlllllllIIIll[115]] = lIIIIIIIIlIIIlIl("ARQ9aBwGHywlAw4XPWgSAxgsKAVBPCAoFAwDKCAFVRc8KBIwQHB1SFdIFicaVVlgAEtPUQ==", "oqIFq");
    lIllllllIIlllI[lIlllllllIIIll[127]] = lIIIIIIIIlIIIlIl("Iw8cKmQlDwQsZAQPHiNwOwEfJS5zRixiA3NO", "InjKJ");
    lIllllllIIlllI[lIlllllllIIIll[134]] = lIIIIIIIIlIIIlII("ZpxEWB/tyv5R+OIG4r7xcwnwUPr8UaY6uu6Cx4dGjRHzpeFMJDhdGfSHfA4ZI1ofTy4oN9vUWgI=", "MXOxD");
    lIllllllIIlllI[lIlllllllIIIll[135]] = lIIIIIIIIlIIIlII("1kRVdNRELrrL9fJiH0cNXuN4aOU5RGdL8TS6Jk5nZSRABLfzPbOvgehKB9ED2UTmWHCn63ZG09Bz2dhF00TsGEGH7E1dMNld5qBGg0p5E94YA2fjuFTs2A==", "wAwtt");
    lIllllllIIlllI[lIlllllllIIIll[111]] = lIIIIIIIIlIIIlIl("Bg4YXwUBBQkSGgkNGF8dHAIAXxwNExhfPA0TGDcHGgYNBRwBBQtLLzouKT9SWVtWUUhISw==", "hklqh");
    lIllllllIIlllI[lIlllllllIIIll[136]] = lIIIIIIIIlIIIIll("HwOp5TkF65hW2v2+aCqHPQZMNtBeBYpvPX9iK9skon3t56MIJ7aNfp31M2nxDzZLY0SN+DLqvoP1OlomAw49Yg==", "bgwBv");
    lIllllllIIlllI[lIlllllllIIIll[126]] = lIIIIIIIIlIIIIll("J5T/g0/rgiWqzW/ZXHwglmNtzlkcYp7FTJzYnLlog25675+yZZeg7vaqo56e04/AkPi3/gEwMXI=", "HsFlO");
    lIllllllIIlllI[lIlllllllIIIll[7]] = lIIIIIIIIlIIIlII("CtJs3Wh905TCNZmepsDcsGpG3wN1lE+yuPq1PvTM4OINA9fEfqvb3iDezrRNTt7w", "HjXZG");
    lIllllllIIlllI[lIlllllllIIIll[137]] = lIIIIIIIIlIIIlIl("IBc1egEnHCQ3Hi8UNXoFIBs1eiEhEAQyCisRNSdWKBskOAgRRXdgXn8tJW5edFJhdEw=", "NrATl");
    lIllllllIIlllI[lIlllllllIIIll[138]] = lIIIIIIIIlIIIlII("HIETYb4EM4lpCO/0mJCur9RwZWPvWC8Cji4zS1IVl+AjNOolkaF95Vl7MflDEOdWLA41zZw7B91chCEOEpyPzkNwh4/kzeHweA4G21eXbkw1AZZMrXgsPf+T2ZM+u2yf", "vodkL");
    lIllllllIIlllI[lIlllllllIIIll[139]] = lIIIIIIIIlIIIlII("byj2CCpmyn8L/ndVGQhwXva21470gJR8e80UhlfaPjR+JIopi7tKNuj5CbLe4fjyfyBwwfpo3azCBItziKueFQ==", "wLHVL");
    lIllllllIIlllI[lIlllllllIIIll[140]] = lIIIIIIIIlIIIIll("HtV+hqW/gk8IVUXHVOmVI0u4hTyffq7Dz8dP9LiTbvfyxErFCF9lIcDLrHUFZYy+o01+jXiPWPxybPhyP6ZD3PoW+avBBn3gZw5HHfYDHxxW5anyIx80Hw==", "FHEsO");
    lIllllllIIlllI[lIlllllllIIIll[121]] = lIIIIIIIIlIIIlII("z/LFYrhoqYHN3U9P5H3oMZ98zSghTnJhrYSDw6B2D/lNLXuYnt8r2GmZeMrTOI2DRMuPz965+xA=", "Xgdgl");
    lIllllllIIlllI[lIlllllllIIIll[141]] = lIIIIIIIIlIIIlII("zJvJ8IljlYNk4XO5AutAQYjFcU9/KgpBwWgepCrpgjqRUHJnOOLsNoQIYO8oqbCsGkDhfTcD760=", "WdlxY");
    lIllllllIIlllI[lIlllllllIIIll[142]] = lIIIIIIIIlIIIlIl("OSI4BWYmNycIZh4iPl4vNjd0TAQ5IjgFZz8iIANnHCEkASsneGcoIjI1L0skMi0pSwcxKSsHPGh5bkQ=", "SCNdH");
    lIllllllIIlllI[lIlllllllIIIll[97]] = lIIIIIIIIlIIIlIl("ORQ1Yzc+HyQuKDYXNWMvIxgtYx85BCwLOzQYLypgMQQvLgVmRnd6aWcuLHdyfj0vKC54HCgjPzQDICsueAQ1JDZ4HCA5MngnJC5pPkp7bXo=", "WqAMZ");
    lIllllllIIlllI[lIlllllllIIIll[143]] = lIIIIIIIIlIIIlIl("IxQiWCgkHzMVNywXIlgmIRgzGDFjHzMCMiIDPVgLKAUhGTcmIToXPCgDHxgjIkswAysuLmdBfXVEZSkmd1l/P39tUQ==", "MqVvE");
    lIllllllIIlllI[lIlllllllIIIll[41]] = lIIIIIIIIlIIIlII("z2WODi8dooJsJqPIMzix2gGb7nniXf6rh7PS9CsSkbPryVv3KcU3nSIIRTOUUB4I1bFkHnPbyzU=", "HkHYm");
    lIllllllIIlllI[lIlllllllIIIll[144]] = lIIIIIIIIlIIIIll("vzgkkIQc7vdFemOyD6CNBBAp1TvRPh+H/diC/x7mkg1Tod/qIxBnWQnzOICR+lkdVDkldl06h8E=", "zvSLx");
    lIllllllIIlllI[lIlllllllIIIll[145]] = lIIIIIIIIlIIIlIl("LBFiOzA0BCU8IC4TYiosMVotPX4oBwg6JTZOZGEee1Rs", "AtLHD");
    lIllllllIIlllI[lIlllllllIIIll[146]] = lIIIIIIIIlIIIlII("tidR+z79eJ6iIDzJV59O9VZeYLIOxVuipOswCZB3FLPCeKengGyvsXJKWZ+UnjcsNL1NOCnBNrQ=", "sSUgx");
    lIllllllIIlllI[lIlllllllIIIll[147]] = lIIIIIIIIlIIIlIl("Dzw/bT4INy4gIQA/P20mFTAnbScEIT9tBwQhPwU8EzQqNycINyx5ASQKDhdpUGlxY3NBeQ==", "aYKCS");
    lIllllllIIlllI[lIlllllllIIIll[148]] = lIIIIIIIIlIIIlIl("DxcVaTkIHAQkJgAUFWk3DRsEKSBPFRQuejIRACsxBSAENDsNBxUuOw9IBzI6Ai1Wf2dTRD4mbklbKH10QQ==", "araGT");
    lIllllllIIlllI[lIlllllllIIIll[3]] = lIIIIIIIIlIIIlII("0ngOANToZJrdZS91YNapQ3ABDQ4HKLRwPDH7hzau/3As8Vs8GZO3lWCaJ/B4/aTJ3J9NtqCUtjc=", "ZTfex");
    lIllllllIIlllI[lIlllllllIIIll[51]] = lIIIIIIIIlIIIIll("MhVPoOROLdBlcmUFIzQ5+Sgj7aFABK+ChSAnMkjvZ0S15+ukWavO3qJ5gK5OvPfykbkrrumGvfKuEu1hoqALhQ==", "VhaMU");
    lIllllllIIlllI[lIlllllllIIIll[149]] = lIIIIIIIIlIIIIll("Ou16AuqShuF4W52Ls6ROX5fFbO7L3u/Mk5tdEjXavIO9CvBBvqWuiDzsCK9hNJUZ6I0AlC8rJuo=", "YbihU");
    lIllllllIIlllI[lIlllllllIIIll[35]] = lIIIIIIIIlIIIlII("CMMv/QuwMYIwgUP/0TNt8TDp3bJvaJvhDxaovfYxjZGraKwzmXb+cfowGA/M5I/Ig8dFmPZmevlMos8BgxgHJA==", "UQQgd");
    lIllllllIIlllI[lIlllllllIIIll[150]] = lIIIIIIIIlIIIlIl("PQoTYjo6AQIvJTIJE2I+PQYTYho8DSIqMTYMEz9tNQYCIDMMWFF4ZmowAXZlaU9HbHc=", "SogLW");
    lIllllllIIlllI[lIlllllllIIIll[8]] = lIIIIIIIIlIIIIll("1oJURkJF9IuaxaoPE1Mwjkt1K4lNpNaO7eSfSeDwPlZjOAVXIs6s9g==", "gHvkc");
    lIllllllIIlllI[lIlllllllIIIll[151]] = lIIIIIIIIlIIIlII("BJucL9RsIsm+YMnQWgCjXM7daiocxK/OsZAXKXV1AQnAZlbpIcArfZb8v3yj87VvFEGfOyLpXaHNOV10T6hZsLFSrU3wBg8TjRKwKFxNVfsTxIbmS5/XAxsbOBbw3oNi", "pwzFp");
    lIllllllIIlllI[lIlllllllIIIll[36]] = lIIIIIIIIlIIIIll("YXXDE8vbB30a6/jazy/He6wZ80BZdHmS3IAunDi1Gha1fDi3BPQDQUiCYg5OhN6vGhQZ10LzzgA=", "YxOvB");
    lIllllllIIlllI[lIlllllllIIIll[152]] = lIIIIIIIIlIIIIll("zxLYKNRh9srPmAhStDBAqVhXEt8wkjYXp1rSXr5vZT6sqopbE4Ah4Q==", "biZXk");
    lIllllllIIlllI[lIlllllllIIIll[153]] = lIIIIIIIIlIIIIll("CTmMYjJ1Ysd3y62fpwxAyCyY/sLx4846kdr+wVO+15P17B5upN4O9XW9nOJ1KJ5FggRZtWmLxRY=", "nfGBq");
    lIllllllIIlllI[lIlllllllIIIll[154]] = lIIIIIIIIlIIIlIl("CgAMTCMNCx0BPAUDDEwtCAwdDDpKAg0LYA0LDgcgEAoKG2AjEBErIBIAFhYhFhxCBDsKBidTelNVTFQRBV9QKwctIz4uIAERVw8nCgAbEC8CEVcHIBAMDBthIQsMCzodKREUJwoCOgM9AV5RNHRE", "dexbN");
    lIllllllIIlllI[lIlllllllIIIll[155]] = lIIIIIIIIlIIIlIl("HCFJPBkENA47CR4jSS0FAWoGOlcWIRMMDAUhACAfCH5PZiEcIUg8GQQ0DjsJHiNILQUBawF+Xkp+R28=", "qDgOm");
    lIllllllIIlllI[lIlllllllIIIll[156]] = lIIIIIIIIlIIIlIl("IyxKNBY7OQ0zBiEuSiUKPmcCMFgpLBAUFjwgCiA1Jy0QL1hmBQ4mFC9mCCYMKWY3MxAnJwN8SwdzRA==", "NIdGb");
    lIllllllIIlllI[lIlllllllIIIll[157]] = lIIIIIIIIlIIIlII("vWGa+RJdWyz4G7BmxjZdt6y+T0ciF2eLBYo/y71bVMAgskbJTtOR5X6AWV70z/z2MQGefaR6ww4=", "pyJqz");
    lIllllllIIlllI[lIlllllllIIIll[158]] = lIIIIIIIIlIIIIll("KjjNp/qTI8HUpM2Ju/DaU9Cf+ZKxCSbdpu/di+piHMYKHgSUy2PeBQf4j3rFse2gjabrHp1Cj4SgUc+f96ZhWg==", "PDedd");
    lIllllllIIlllI[lIlllllllIIIll[159]] = lIIIIIIIIlIIIIll("K9c9fFY98Vada1mDLFjRMnxVu10um+BBzJ50CScrI9fhshHY0Dy5FGX+6CG9co/07hZjodmsoyArVGtoXaU26g==", "hoaoD");
    lIllllllIIlllI[lIlllllllIIIll[160]] = lIIIIIIIIlIIIlIl("KA0FSR4vBhQEAScOBUkaKAEFST4pCjQBFSMLBRRJIAEUCxcZX0dTR3I3CV1BfEhRR1M=", "Fhqgs");
    lIllllllIIlllI[lIlllllllIIIll[161]] = lIIIIIIIIlIIIlII("MIeNNtyJBOrVjSIPt21myAr/PWl+61yIHlVg+FPzGQd+5DBNAOZB6Y6281UwtjIBYHVoLH+otvQM1QMAGYO9IOrfyM4rWQAD/a8BW7Rwi8yv47voiQ4RIw==", "agnBi");
    lIllllllIIlllI[lIlllllllIIIll[162]] = lIIIIIIIIlIIIIll("IwNXv4oQzojOvfP1/c1+iWRQ7WwIF4FzkIQ9jvV48w5my/w3nP8Eo6BjAnnxlxkXO0RjCc9ddYAZBkLMbMo/h2moi9PAvONq", "CKVrY");
    lIllllllIIlllI[lIlllllllIIIll[163]] = lIIIIIIIIlIIIIll("NRTKt69ZtYPWRcpONoMtUeWS+Lo4grjDiMO0X94QK+A0Guc80uEFPIXzOpdaSPcFRIdTqVJx9rk=", "buctc");
    lIllllllIIlllI[lIlllllllIIIll[164]] = lIIIIIIIIlIIIIll("/R8dXMvAtE/VSzI5SmBZS0QMJQERNL5n2qu7k0fPpeGMNI6WRqJ1cGRPefoL4pbCmkL8lHjPeJs=", "rHXjQ");
    lIllllllIIlllI[lIlllllllIIIll[165]] = lIIIIIIIIlIIIlIl("HBE8ZQwbGi0oExMSPGUIHB08ZSwdFg0tBxcXPDhbFB0tJwUtRXBzVUBHFzNbQE5oa0FS", "rtHKa");
    lIllllllIIlllI[lIlllllllIIIll[37]] = lIIIIIIIIlIIIIll("hSj38Qw3oHgJN+PUN+n4/hOjUcKlB04jlecNCXkfReUQvW0/6nGE4v3zolpYa1akaFWOEtyngH583BgFzsGvdg==", "zvGNg");
    lIllllllIIlllI[lIlllllllIIIll[15]] = lIIIIIIIIlIIIIll("CIA9LvBcwZw+fiZyIQ6Mvk9UAzdh6dyyIgCTrWFYDHPUUR4Vo1UplIH5fzOm5l0XVQFNFTZRS9M=", "ZtcTs");
    lIllllllIIlllI[lIlllllllIIIll[54]] = lIIIIIIIIlIIIIll("lV0GHBJbhAusvmyX1nz3EYBfuMMuZkLmHzVPA3AhWiQdI0UHKfnfyA==", "YGnvV");
    lIllllllIIlllI[lIlllllllIIIll[166]] = lIIIIIIIIlIIIlIl("CRcSDEcWAg0BRyIEFgwQLx8XGVMKAgEfCBcZFldBSjoODB8CWREZAA9ZLRkMERcQAhtYTERN", "cvdmi");
    lIllllllIIlllI[lIlllllllIIIll[167]] = lIIIIIIIIlIIIlII("2pe6Kpud853bDztHPbWobAeoBZTaTvB3E79xVUY2+pG7mloR8ycHBlNbPH9P60NSq5DnsdFk8ZA=", "vBRiN");
    lIllllllIIlllI[lIlllllllIIIll[168]] = lIIIIIIIIlIIIlIl("JREPDXwjERcLfAYeDQk1KgJDDz0iABgeN3VYMCV7BkpZ", "OpylR");
    lIllllllIIlllI[lIlllllllIIIll[169]] = lIIIIIIIIlIIIlII("mAtoDXmhXGr9kG4AAKACJ4xOt6eStsup0+3nD7krSpV/xYlVN7mpBmcJMiCdzvtTKud44vSOkyc=", "VagEb");
    lIllllllIIlllI[lIlllllllIIIll[28]] = lIIIIIIIIlIIIIll("CX2aCBiYUjNnMQYvSSVobDm3HLhxKt3h9DNDROOY01PmX7vahA7J1/sXQ6EYIa+E", "nfLlH");
    lIllllllIIlllI[lIlllllllIIIll[32]] = lIIIIIIIIlIIIlIl("CRA9byMOGywiPAYTPW8nCRw9bwMIFwwnKAIWPTJ0ARwsLSo4RHF5elVAFjt0VU9pYW5H", "guIAN");
    lIllllllIIlllI[lIlllllllIIIll[170]] = lIIIIIIIIlIIIIll("qwmO6eLv+QTMMApuHFJFh6TR7+ltzyOSQiG/X0UrZImF6dM9TfERxaaPfVPZ/LN9+D5fE0WAYzc=", "RUMKp");
    lIllllllIIlllI[lIlllllllIIIll[171]] = lIIIIIIIIlIIIlII("TAdFVXbsMuw1qY+aVZ36EP/GWWzuS/3wza6P5LM0Z00Qg8W8w5Ame2vg4iEBbOhOeX1nG1D2C/34KVB25o/shlkdbx3t0eLi", "RPTYD");
    lIllllllIIlllI[lIlllllllIIIll[172]] = lIIIIIIIIlIIIlII("aLRqrFTPbdoRpOgwcrob95iBA48XNkMFvhl85xbKodA2PcCAJEzMu9JSy6fIfWNopOvTdK3G3pA=", "ZbsCI");
    lIllllllIIlllI[lIlllllllIIIll[173]] = lIIIIIIIIlIIIIll("YgYwbNknN6n2GXqH2oKe31jYVhSmyPjumoXGsRLHxdLkyKfXhQRUXrvgCBoHImkWT0PKJdNbte/ERxRn3g+4C/9PBg8NtT7HxnJCdZJS4JoJwj3UElY6EA==", "LNury");
    lIllllllIIlllI[lIlllllllIIIll[174]] = lIIIIIIIIlIIIlII("pkbWbfdgHDNbrsb3/3I2F7ABPw+EJfLQPP9BjXPY5GzLN6cKYT5xLg==", "sEZJJ");
    lIllllllIIlllI[lIlllllllIIIll[55]] = lIIIIIIIIlIIIlII("aC4YMP+8vViDLmz65QCg/jiYb1tPiQtApQvKJKEA5dfwwQpVrtnMNABTQFEAb5Rk9cjZfZqqUSehGo7++AOdOMKAKccDBhzD7fibpID+kGtypeiUsA8MEnMOcHZR7qMdoNlkhU+EfRA=", "brQpp");
    lIllllllIIlllI[lIlllllllIIIll[39]] = lIIIIIIIIlIIIlII("LkOyPWuPfOcieXol08MNCQapoH64tp0Oki4sjCSLbqGbTNrfZijmWGQEP1lKj6pLoN+CRTBdSLM=", "ohJcq");
    lIllllllIIlllI[lIlllllllIIIll[175]] = lIIIIIIIIlIIIlIl("FSZ8GSINMzseMhckfAg+CG0zB2wMNiAEHxY3PSEmMHl6Ln88eXJK", "xCRjV");
    lIllllllIIlllI[lIlllllllIIIll[176]] = lIIIIIIIIlIIIlII("HH766tKKA+kH23/IU1wqBzFvAwFNV0PECtILwFElIhRFBqvIt7xFpOk3KdLY1jFABUv/z0Sj1wrpuo/pikT3f2hrda/VK94xNirTbHtuGSI=", "aiwqp");
    lIllllllIIlllI[lIlllllllIIIll[59]] = lIIIIIIIIlIIIlII("jcJ34PHspA0wsZIUYE2fl36HwMf1BuLWd7rw3w7K4Roa6kxxN0nAmhXli9gwW+25i2uLsSYU+5bIyWlhaby0WeyRQ6eCe9bW8z63cwgpLL9N5jWRCFebxw==", "ZLNtQ");
    lIllllllIIlllI[lIlllllllIIIll[53]] = lIIIIIIIIlIIIIll("Pv/LzNcKyrhw47yQDFfBtD4a6bDDhk9eRDOIbqxLcDQ6s9g39f4knERWL3ljcRE+oSFakzo92fHSKhorGw58pmAwPuPF36gObj7vCOkUGCj8vbgbdp0RaJQjs5Tlf+9S", "MzoSM");
    lIlllllllIIIlI = null;
  }
  
  private static void lIIIIIIIIllllIIl() {
    String str = (new Exception()).getStackTrace()[lIlllllllIIIll[0]].getFileName();
    lIlllllllIIIlI = str.substring(str.indexOf("ä") + lIlllllllIIIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIIlIIIlIl(String lllllllllllllllIllIllllllIIIlIlI, String lllllllllllllllIllIllllllIIIlIIl) {
    lllllllllllllllIllIllllllIIIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIllllllIIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllllllIIIlIII = new StringBuilder();
    char[] lllllllllllllllIllIllllllIIIIlll = lllllllllllllllIllIllllllIIIlIIl.toCharArray();
    int lllllllllllllllIllIllllllIIIIllI = lIlllllllIIIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllllllIIIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllllIIIll[0];
    while (lIIIIIIIlIIIIllI(j, i)) {
      char lllllllllllllllIllIllllllIIIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllllllIIIIllI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllllllIIIlIII);
  }
  
  private static String lIIIIIIIIlIIIlII(String lllllllllllllllIllIllllllIIIIIlI, String lllllllllllllllIllIllllllIIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllllllIIIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllllIIIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllllllIIIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllllllIIIIlII.init(lIlllllllIIIll[2], lllllllllllllllIllIllllllIIIIlIl);
      return new String(lllllllllllllllIllIllllllIIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllllIIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllllIIIIIll) {
      lllllllllllllllIllIllllllIIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIlIIIIll(String lllllllllllllllIllIlllllIlllllIl, String lllllllllllllllIllIlllllIlllllII) {
    try {
      SecretKeySpec lllllllllllllllIllIllllllIIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllllIlllllII.getBytes(StandardCharsets.UTF_8)), lIlllllllIIIll[66]), "DES");
      Cipher lllllllllllllllIllIlllllIlllllll = Cipher.getInstance("DES");
      lllllllllllllllIllIlllllIlllllll.init(lIlllllllIIIll[2], lllllllllllllllIllIllllllIIIIIII);
      return new String(lllllllllllllllIllIlllllIlllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllllIlllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllllIllllllI) {
      lllllllllllllllIllIlllllIllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIllllIll() {
    lIlllllllIIIll = new int[178];
    lIlllllllIIIll[0] = (0x26 ^ 0x37) << " ".length() << " ".length() & ((0xD4 ^ 0xC5) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIlllllllIIIll[1] = " ".length();
    lIlllllllIIIll[2] = " ".length() << " ".length();
    lIlllllllIIIll[3] = (0x36 ^ 0x29) << " ".length() << " ".length();
    lIlllllllIIIll[4] = 30 + 126 - 12 + 31;
    lIlllllllIIIll[5] = ((0x6 ^ 0x65) << " ".length() ^ 97 + 163 - 99 + 4) << " ".length();
    lIlllllllIIIll[6] = (151 + 135 - 190 + 77 ^ " ".length() << (0x22 ^ 0x25)) << " ".length();
    lIlllllllIIIll[7] = ((0xA ^ 0x29) << " ".length() ^ 0xCC ^ 0x91) << " ".length() << " ".length();
    lIlllllllIIIll[8] = 28 + 75 - 79 + 105;
    lIlllllllIIIll[9] = ((0x98 ^ 0xAD) << " ".length()) + ((0xD1 ^ 0xC2) << " ".length()) - 66 + 98 - 74 + 37 + ((0x95 ^ 0x8C) << "   ".length());
    lIlllllllIIIll[10] = "   ".length() << "   ".length() << " ".length();
    lIlllllllIIIll[11] = (0x84 ^ 0x8F) << " ".length() << " ".length() ^ 0x1B ^ 0x74;
    lIlllllllIIIll[12] = (0x5 ^ 0x20) << " ".length();
    lIlllllllIIIll[13] = (0x49 ^ 0x68) << " ".length();
    lIlllllllIIIll[14] = 0xB4 ^ 0xA3;
    lIlllllllIIIll[15] = (0x5E ^ 0x2B) + (" ".length() << "   ".length() << " ".length()) - (0x59 ^ 0x20) + (0xFD ^ 0xAA);
    lIlllllllIIIll[16] = (0x4F ^ 0x46) << " ".length() << " ".length();
    lIlllllllIIIll[17] = 80 + 1 - -17 + 29 ^ (0x0 ^ 0x17) << " ".length() << " ".length();
    lIlllllllIIIll[18] = (0x74 ^ 0x71) << " ".length();
    lIlllllllIIIll[19] = (0x5C ^ 0x5B) << " ".length() << " ".length() ^ 0x40 ^ 0x55;
    lIlllllllIIIll[20] = (0x11 ^ 0x0) << " ".length();
    lIlllllllIIIll[21] = ((0x8 ^ 0x3) << " ".length() << " ".length() << " ".length()) + ((0x1B ^ 0x3E) << " ".length() << " ".length()) - 97 + 186 - 150 + 148 + ((0xBB ^ 0x8E) << " ".length() << " ".length());
    lIlllllllIIIll[22] = ((0x2C ^ 0x3F) << " ".length() << " ".length() ^ 0x1B ^ 0x44) << " ".length() << " ".length();
    lIlllllllIIIll[23] = (0x8A ^ 0x9F) << " ".length() << " ".length() ^ " ".length();
    lIlllllllIIIll[24] = 0xA1 ^ 0xBC;
    lIlllllllIIIll[25] = 99 + 113 - 16 + 9;
    lIlllllllIIIll[26] = (0xEE ^ 0xAD ^ (0x8D ^ 0x98) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllllllIIIll[27] = 25 + 145 - 84 + 85;
    lIlllllllIIIll[28] = (0xB5 ^ 0x9A) + (0x38 ^ 0x7B) - (0xA ^ 0x61) + ((0x49 ^ 0x0) << " ".length());
    lIlllllllIIIll[29] = 0xB4 ^ 0x91 ^ "   ".length() << (0x23 ^ 0x26);
    lIlllllllIIIll[30] = (0x58 ^ 0x45) << " ".length();
    lIlllllllIIIll[31] = (0x94 ^ 0xAD) << " ".length() << " ".length();
    lIlllllllIIIll[32] = (0xD7 ^ 0x9A) << " ".length();
    lIlllllllIIIll[33] = ((0xCB ^ 0x98) << " ".length() ^ 90 + 121 - 188 + 154) << " ".length();
    lIlllllllIIIll[34] = (0x7B ^ 0x52) << " ".length();
    lIlllllllIIIll[35] = 60 + 68 - 119 + 118;
    lIlllllllIIIll[36] = ((0x6F ^ 0x7C) << " ".length() << " ".length()) + (0x49 ^ 0x78) - ((0x39 ^ 0x3E) << "   ".length()) + ((0xB1 ^ 0xAE) << " ".length());
    lIlllllllIIIll[37] = (0xEF ^ 0xA6) << " ".length();
    lIlllllllIIIll[38] = 0x2F ^ 0x30;
    lIlllllllIIIll[39] = 8 + 153 - 37 + 37;
    lIlllllllIIIll[40] = (0x28 ^ 0x23) << "   ".length();
    lIlllllllIIIll[41] = (0x23 ^ 0x18) << " ".length();
    lIlllllllIIIll[42] = (0x9E ^ 0x8B) << " ".length() ^ 0xF5 ^ 0x8C;
    lIlllllllIIIll[43] = (0x61 ^ 0x68) << "   ".length();
    lIlllllllIIIll[44] = 0x8 ^ 0x45;
    lIlllllllIIIll[45] = (0x41 ^ 0x66) << " ".length();
    lIlllllllIIIll[46] = 0x37 ^ 0x1A ^ (0xA9 ^ 0xAE) << " ".length() << " ".length();
    lIlllllllIIIll[47] = 0x79 ^ 0x4C;
    lIlllllllIIIll[48] = (0xD6 ^ 0xC3) << " ".length();
    lIlllllllIIIll[49] = 0xB8 ^ 0x9F;
    lIlllllllIIIll[50] = (0xA ^ 0x15) << "   ".length();
    lIlllllllIIIll[51] = 0xE3 ^ 0x9E;
    lIlllllllIIIll[52] = 0x27 ^ 0x2;
    lIlllllllIIIll[53] = 120 + 49 - 118 + 114;
    lIlllllllIIIll[54] = (114 + 97 - 152 + 96 ^ (0x2A ^ 0x75) << " ".length()) << " ".length() << " ".length();
    lIlllllllIIIll[55] = (125 + 4 - 120 + 122 ^ (0x53 ^ 0x10) << " ".length()) << (0xD4 ^ 0x91 ^ " ".length() << "   ".length() << " ".length());
    lIlllllllIIIll[56] = 0xF4 ^ 0x95;
    lIlllllllIIIll[57] = (0x6C ^ 0xB) << " ".length();
    lIlllllllIIIll[58] = (0x6E ^ 0x47) << " ".length() << " ".length() ^ 12 + 140 - 19 + 18;
    lIlllllllIIIll[59] = (0xFB ^ 0xAA ^ (0x53 ^ 0x5C) << "   ".length()) << " ".length() << " ".length();
    lIlllllllIIIll[60] = "   ".length();
    lIlllllllIIIll[61] = (0x57 ^ 0x4E) << " ".length() << " ".length();
    lIlllllllIIIll[62] = " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[63] = 0x8D ^ 0x88;
    lIlllllllIIIll[64] = "   ".length() << " ".length();
    lIlllllllIIIll[65] = 0x49 ^ 0x4E;
    lIlllllllIIIll[66] = " ".length() << "   ".length();
    lIlllllllIIIll[67] = -" ".length();
    lIlllllllIIIll[68] = 0xA3 ^ 0xA8;
    lIlllllllIIIll[69] = "   ".length() << " ".length() << " ".length();
    lIlllllllIIIll[70] = 0x29 ^ 0x24;
    lIlllllllIIIll[71] = ((0x66 ^ 0x73) << " ".length() << " ".length() ^ 0x37 ^ 0x64) << " ".length();
    lIlllllllIIIll[72] = 0x4F ^ 0x40;
    lIlllllllIIIll[73] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[74] = 0xD5 ^ 0xC4;
    lIlllllllIIIll[75] = ((0x43 ^ 0x50) << " ".length() << " ".length() ^ 0x2A ^ 0x6F) << " ".length();
    lIlllllllIIIll[76] = 0x17 ^ 0x4;
    lIlllllllIIIll[77] = (0x8C ^ 0x89) << " ".length() << " ".length();
    lIlllllllIIIll[78] = 0x5A ^ 0x4F;
    lIlllllllIIIll[79] = (0x51 ^ 0x5A) << " ".length();
    lIlllllllIIIll[80] = "   ".length() << "   ".length();
    lIlllllllIIIll[81] = (0x23 ^ 0x2E) << "   ".length() ^ 0x71 ^ 0x0;
    lIlllllllIIIll[82] = (0x2F ^ 0x22) << " ".length();
    lIlllllllIIIll[83] = (0x3C ^ 0x69) << " ".length() ^ 170 + 131 - 184 + 60;
    lIlllllllIIIll[84] = (0xB8 ^ 0xBF) << " ".length() << " ".length();
    lIlllllllIIIll[85] = (61 + 33 - 41 + 124 ^ (0x19 ^ 0x46) << " ".length()) << " ".length();
    lIlllllllIIIll[86] = " ".length() << ((0xAC ^ 0xB3) << " ".length() ^ 0x1 ^ 0x3A);
    lIlllllllIIIll[87] = 37 + 25 - 2 + 131 ^ (0xE5 ^ 0xAA) << " ".length();
    lIlllllllIIIll[88] = (0xBA ^ 0xB5) << " ".length() << " ".length();
    lIlllllllIIIll[89] = (0x47 ^ 0x54) << " ".length();
    lIlllllllIIIll[90] = ((0xA7 ^ 0xB8) << " ".length() << " ".length() ^ 0xCB ^ 0xB2) << "   ".length();
    lIlllllllIIIll[91] = 0x82 ^ 0xAD ^ "   ".length() << " ".length();
    lIlllllllIIIll[92] = 0x1 ^ 0x2A;
    lIlllllllIIIll[93] = (0xB5 ^ 0xBE) << " ".length() << " ".length();
    lIlllllllIIIll[94] = 0x5C ^ 0x71;
    lIlllllllIIIll[95] = 0x7C ^ 0x53;
    lIlllllllIIIll[96] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[97] = ((0x45 ^ 0x54) << " ".length() ^ 0x10 ^ 0x2F) << " ".length() << " ".length();
    lIlllllllIIIll[98] = (0x11 ^ 0x22 ^ (0x2B ^ 0x3E) << " ".length()) << " ".length();
    lIlllllllIIIll[99] = (0x21 ^ 0x2C) << " ".length() << " ".length();
    lIlllllllIIIll[100] = 0xD0 ^ 0x9B;
    lIlllllllIIIll[101] = (0x10 ^ 0x29) << " ".length() ^ 0x67 ^ 0x4E;
    lIlllllllIIIll[102] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0x5A ^ 0x51) << " ".length();
    lIlllllllIIIll[103] = 0xD ^ 0x3A;
    lIlllllllIIIll[104] = (0x7C ^ 0x7B) << "   ".length();
    lIlllllllIIIll[105] = 0x38 ^ 0x5F ^ (0x5 ^ 0x1A) << " ".length();
    lIlllllllIIIll[106] = (0xBA ^ 0xC7) << " ".length() ^ 59 + 63 - 34 + 107;
    lIlllllllIIIll[107] = " ".length() << " ".length() ^ 0x80 ^ 0xB9;
    lIlllllllIIIll[108] = 0x23 ^ 0x1E;
    lIlllllllIIIll[109] = (150 + 115 - 196 + 90 ^ " ".length() << (0xD ^ 0xA)) << " ".length();
    lIlllllllIIIll[110] = 0x66 ^ 0x59;
    lIlllllllIIIll[111] = 0xE2 ^ 0x8B;
    lIlllllllIIIll[112] = " ".length() << "   ".length() << " ".length();
    lIlllllllIIIll[113] = 0x61 ^ 0x20;
    lIlllllllIIIll[114] = ("   ".length() << "   ".length() ^ 0x54 ^ 0x5D) << " ".length() << " ".length();
    lIlllllllIIIll[115] = (0xA8 ^ 0xA5) << " ".length() << " ".length() << " ".length() ^ 67 + 157 - 107 + 64;
    lIlllllllIIIll[116] = (" ".length() ^ (0xD4 ^ 0xC5) << " ".length()) << " ".length();
    lIlllllllIIIll[117] = 0x54 ^ 0x43 ^ (0x35 ^ 0x30) << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[118] = 0x20 ^ 0x4F ^ (0x4D ^ 0x5E) << " ".length();
    lIlllllllIIIll[119] = (0x54 ^ 0x51) << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[120] = 0xDE ^ 0x91;
    lIlllllllIIIll[121] = 0x7E ^ 0xF;
    lIlllllllIIIll[122] = 0xD2 ^ 0x83;
    lIlllllllIIIll[123] = (0xA2 ^ 0xB7) << " ".length() << " ".length();
    lIlllllllIIIll[124] = (0x60 ^ 0x4B) << " ".length();
    lIlllllllIIIll[125] = 0x99 ^ 0xB0 ^ (0x72 ^ 0x4D) << " ".length();
    lIlllllllIIIll[126] = 0xEE ^ 0x85;
    lIlllllllIIIll[127] = (0xF ^ 0x3C) << " ".length();
    lIlllllllIIIll[128] = 0xE4 ^ 0xB9;
    lIlllllllIIIll[129] = (0x6C ^ 0x15 ^ (0x8D ^ 0xA6) << " ".length()) << " ".length();
    lIlllllllIIIll[130] = 27 + 88 - 2 + 90 ^ (0x18 ^ 0x3D) << " ".length() << " ".length();
    lIlllllllIIIll[131] = 0xC8 ^ 0xBB ^ " ".length() << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[132] = "   ".length() << (0x11 ^ 0x14);
    lIlllllllIIIll[133] = (0xA3 ^ 0x92) << " ".length();
    lIlllllllIIIll[134] = 25 + 138 - 126 + 126 ^ (0x2E ^ 0x1F) << " ".length() << " ".length();
    lIlllllllIIIll[135] = ((0xCD ^ 0x90) << " ".length() ^ 24 + 84 - 101 + 176) << "   ".length();
    lIlllllllIIIll[136] = (0xAA ^ 0x83 ^ (0x2F ^ 0x28) << " ".length() << " ".length()) << " ".length();
    lIlllllllIIIll[137] = 0xF3 ^ 0x9E;
    lIlllllllIIIll[138] = ((0xB1 ^ 0xA2) << "   ".length() ^ 2 + 109 - 54 + 118) << " ".length();
    lIlllllllIIIll[139] = (0x89 ^ 0x8E) << " ".length() << " ".length() << " ".length() ^ 0x7C ^ 0x63;
    lIlllllllIIIll[140] = ("   ".length() << "   ".length() ^ 0xB6 ^ 0xA9) << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[141] = ((0xAE ^ 0xA9) << "   ".length() ^ " ".length()) << " ".length();
    lIlllllllIIIll[142] = 0x22 ^ 0x51;
    lIlllllllIIIll[143] = 0x12 ^ 0x67;
    lIlllllllIIIll[144] = 0xC0 ^ 0xB7;
    lIlllllllIIIll[145] = (0x5B ^ 0x54) << "   ".length();
    lIlllllllIIIll[146] = 154 + 148 - 166 + 87 ^ (0x7 ^ 0x54) << " ".length();
    lIlllllllIIIll[147] = (146 + 37 - 36 + 2 ^ (0xA1 ^ 0xB4) << "   ".length()) << " ".length();
    lIlllllllIIIll[148] = 0xE7 ^ 0x9C;
    lIlllllllIIIll[149] = (0x17 ^ 0x28) << " ".length();
    lIlllllllIIIll[150] = " ".length() << (0x9 ^ 0xE);
    lIlllllllIIIll[151] = (0x79 ^ 0x0 ^ (0xC5 ^ 0xC2) << "   ".length()) << " ".length();
    lIlllllllIIIll[152] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xB0 ^ 0x81) << " ".length() << " ".length();
    lIlllllllIIIll[153] = 38 + 109 - 101 + 87;
    lIlllllllIIIll[154] = (0xCA ^ 0x89) << " ".length();
    lIlllllllIIIll[155] = 74 + 73 - 84 + 72;
    lIlllllllIIIll[156] = ((0x74 ^ 0x6D) << " ".length() << " ".length() ^ 0x41 ^ 0x34) << "   ".length();
    lIlllllllIIIll[157] = (0x27 ^ 0x1C) + ((0xE ^ 0x1F) << " ".length() << " ".length()) - ((0x15 ^ 0x30) << " ".length()) + ((0x72 ^ 0x67) << " ".length() << " ".length());
    lIlllllllIIIll[158] = (51 + 76 - 0 + 98 ^ (0xBE ^ 0x97) << " ".length() << " ".length()) << " ".length();
    lIlllllllIIIll[159] = 4 + 117 - 105 + 123;
    lIlllllllIIIll[160] = ((0xA1 ^ 0xB0) << " ".length() ^ " ".length()) << " ".length() << " ".length();
    lIlllllllIIIll[161] = ((0x51 ^ 0x56) << "   ".length()) + (0x55 ^ 0x74) - -(0x7F ^ 0x54) + (0x35 ^ 0x3C);
    lIlllllllIIIll[162] = ((0x3E ^ 0x39) << " ".length() << " ".length() << " ".length() ^ 0x61 ^ 0x56) << " ".length();
    lIlllllllIIIll[163] = 12 + 29 - -71 + 31;
    lIlllllllIIIll[164] = (0x22 ^ 0x6D ^ (0x6C ^ 0x4F) << " ".length()) << " ".length() << " ".length() << " ".length();
    lIlllllllIIIll[165] = 40 + 48 - -43 + 14;
    lIlllllllIIIll[166] = 11 + 42 - -61 + 35;
    lIlllllllIIIll[167] = (0x25 ^ 0x6E) << " ".length();
    lIlllllllIIIll[168] = 19 + 101 - 100 + 131;
    lIlllllllIIIll[169] = ((0x14 ^ 0x3B) << " ".length() ^ 0x79 ^ 0x34) << "   ".length();
    lIlllllllIIIll[170] = 119 + 145 - 175 + 66;
    lIlllllllIIIll[171] = (0x4D ^ 0x6A) << " ".length() << " ".length();
    lIlllllllIIIll[172] = 55 + 16 - 14 + 100;
    lIlllllllIIIll[173] = (0x74 ^ 0x3B) << " ".length();
    lIlllllllIIIll[174] = 120 + 36 - -1 + 2;
    lIlllllllIIIll[175] = ((0x21 ^ 0x16) << " ".length() ^ 0x57 ^ 0x68) << " ".length();
    lIlllllllIIIll[176] = 81 + 110 - 135 + 107;
    lIlllllllIIIll[177] = (0x6D ^ 0x3E) << " ".length();
  }
  
  private static boolean lIIIIIIIlIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIlIIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIlIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIIllllllI(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIIIIlllllII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIIIlIIIIIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIIlIIIIIlI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIIIIlllllIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIIlIIIIIII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIIIlllllll(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\am.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */