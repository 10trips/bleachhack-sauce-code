package me.stupitdog.bhp;

public class al extends fs {
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\al.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */