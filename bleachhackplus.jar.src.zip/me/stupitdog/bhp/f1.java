package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class f1 extends au {
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Boolean onTotem;
  
  public ArrayList<String> ggList;
  
  public ArrayList<String> ezList;
  
  public int index;
  
  @EventHandler
  public Listener<f10000000000000000000000000000000000> onTotemPop;
  
  private static String[] llIIIIIlIIIIlI;
  
  private static Class[] llIIIIIlIIIIll;
  
  private static final String[] llIIIIIllllIll;
  
  private static String[] llIIIIlIIIIIII;
  
  private static final int[] llIIIIlIIIIIlI;
  
  public f1() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   45: iconst_0
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1;I)V
    //   52: aload_0
    //   53: new me/zero/alpine/listener/Listener
    //   56: dup
    //   57: aload_0
    //   58: <illegal opcode> invoke : (Lme/stupitdog/bhp/f1;)Lme/zero/alpine/listener/EventHook;
    //   63: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   66: iconst_0
    //   67: iaload
    //   68: anewarray java/util/function/Predicate
    //   71: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   74: <illegal opcode> 2 : (Lme/stupitdog/bhp/f1;Lme/zero/alpine/listener/Listener;)V
    //   79: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	80	0	lllllllllllllllIllIllIlIllIlllII	Lme/stupitdog/bhp/f1;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_0
    //   9: new java/util/ArrayList
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: <illegal opcode> 3 : (Lme/stupitdog/bhp/f1;Ljava/util/ArrayList;)V
    //   21: aload_0
    //   22: new java/util/ArrayList
    //   25: dup
    //   26: invokespecial <init> : ()V
    //   29: <illegal opcode> 4 : (Lme/stupitdog/bhp/f1;Ljava/util/ArrayList;)V
    //   34: aload_1
    //   35: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   38: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   41: iconst_3
    //   42: iaload
    //   43: aaload
    //   44: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   49: ldc ''
    //   51: invokevirtual length : ()I
    //   54: pop2
    //   55: aload_1
    //   56: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   59: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   62: iconst_4
    //   63: iaload
    //   64: aaload
    //   65: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   70: ldc ''
    //   72: invokevirtual length : ()I
    //   75: pop2
    //   76: aload_0
    //   77: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   82: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   85: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   88: iconst_5
    //   89: iaload
    //   90: aaload
    //   91: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   96: ldc ''
    //   98: invokevirtual length : ()I
    //   101: pop2
    //   102: aload_0
    //   103: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   108: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   111: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   114: bipush #6
    //   116: iaload
    //   117: aaload
    //   118: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   123: ldc ''
    //   125: invokevirtual length : ()I
    //   128: pop2
    //   129: aload_0
    //   130: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   135: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   138: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   141: bipush #7
    //   143: iaload
    //   144: aaload
    //   145: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   150: ldc ''
    //   152: invokevirtual length : ()I
    //   155: pop2
    //   156: aload_0
    //   157: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   162: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   165: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   168: bipush #8
    //   170: iaload
    //   171: aaload
    //   172: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   177: ldc ''
    //   179: invokevirtual length : ()I
    //   182: pop2
    //   183: aload_0
    //   184: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   189: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   192: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   195: bipush #9
    //   197: iaload
    //   198: aaload
    //   199: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   204: ldc ''
    //   206: invokevirtual length : ()I
    //   209: pop2
    //   210: aload_0
    //   211: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   216: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   219: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   222: bipush #10
    //   224: iaload
    //   225: aaload
    //   226: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   231: ldc ''
    //   233: invokevirtual length : ()I
    //   236: pop2
    //   237: aload_0
    //   238: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   243: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   246: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   249: bipush #11
    //   251: iaload
    //   252: aaload
    //   253: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   258: ldc ''
    //   260: invokevirtual length : ()I
    //   263: pop2
    //   264: aload_0
    //   265: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   270: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   273: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   276: bipush #12
    //   278: iaload
    //   279: aaload
    //   280: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   285: ldc ''
    //   287: invokevirtual length : ()I
    //   290: pop2
    //   291: aload_0
    //   292: aload_0
    //   293: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   296: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   299: bipush #13
    //   301: iaload
    //   302: aaload
    //   303: aload_1
    //   304: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   307: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   310: bipush #14
    //   312: iaload
    //   313: aaload
    //   314: <illegal opcode> 8 : (Lme/stupitdog/bhp/f1;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   319: <illegal opcode> 9 : (Lme/stupitdog/bhp/f1;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   324: aload_0
    //   325: aload_0
    //   326: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   329: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   332: bipush #15
    //   334: iaload
    //   335: aaload
    //   336: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   339: iconst_1
    //   340: iaload
    //   341: <illegal opcode> 10 : (Lme/stupitdog/bhp/f1;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   346: <illegal opcode> 11 : (Lme/stupitdog/bhp/f1;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   351: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	352	0	lllllllllllllllIllIllIlIllIllIll	Lme/stupitdog/bhp/f1;
    //   8	344	1	lllllllllllllllIllIllIlIllIllIlI	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	344	1	lllllllllllllllIllIllIlIllIllIlI	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 12 : (Lme/stupitdog/bhp/f1;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   14: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   17: bipush #16
    //   19: iaload
    //   20: aaload
    //   21: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   26: invokestatic lIIIIIlIIIlllIII : (I)Z
    //   29: ifeq -> 75
    //   32: aload_0
    //   33: <illegal opcode> 15 : (Lme/stupitdog/bhp/f1;)Ljava/lang/String;
    //   38: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   41: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   44: bipush #17
    //   46: iaload
    //   47: aaload
    //   48: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   53: invokestatic lIIIIIlIIIlllIIl : (I)Z
    //   56: ifeq -> 75
    //   59: aload_0
    //   60: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   63: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   66: bipush #18
    //   68: iaload
    //   69: aaload
    //   70: <illegal opcode> 16 : (Lme/stupitdog/bhp/f1;Ljava/lang/String;)V
    //   75: aload_0
    //   76: <illegal opcode> 12 : (Lme/stupitdog/bhp/f1;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   81: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   86: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   89: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   92: bipush #19
    //   94: iaload
    //   95: aaload
    //   96: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   101: invokestatic lIIIIIlIIIlllIII : (I)Z
    //   104: ifeq -> 150
    //   107: aload_0
    //   108: <illegal opcode> 15 : (Lme/stupitdog/bhp/f1;)Ljava/lang/String;
    //   113: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   116: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   119: bipush #20
    //   121: iaload
    //   122: aaload
    //   123: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   128: invokestatic lIIIIIlIIIlllIIl : (I)Z
    //   131: ifeq -> 150
    //   134: aload_0
    //   135: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   138: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   141: bipush #21
    //   143: iaload
    //   144: aaload
    //   145: <illegal opcode> 16 : (Lme/stupitdog/bhp/f1;Ljava/lang/String;)V
    //   150: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	151	0	lllllllllllllllIllIllIlIllIllIIl	Lme/stupitdog/bhp/f1;
  }
  
  @SubscribeEvent
  public void onDeath(LivingDeathEvent lllllllllllllllIllIllIlIllIlIlll) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 17 : (Lnet/minecraftforge/event/entity/living/LivingDeathEvent;)Lnet/minecraft/entity/EntityLivingBase;
    //   6: instanceof net/minecraft/entity/player/EntityPlayer
    //   9: invokestatic lIIIIIlIIIlllIII : (I)Z
    //   12: ifeq -> 281
    //   15: aload_0
    //   16: <illegal opcode> 12 : (Lme/stupitdog/bhp/f1;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   21: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   26: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   29: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   32: bipush #22
    //   34: iaload
    //   35: aaload
    //   36: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   41: invokestatic lIIIIIlIIIlllIII : (I)Z
    //   44: ifeq -> 125
    //   47: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: aload_0
    //   58: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   63: aload_0
    //   64: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   69: <illegal opcode> 21 : (Ljava/util/ArrayList;I)Ljava/lang/Object;
    //   74: checkcast java/lang/String
    //   77: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;Ljava/lang/String;)V
    //   82: <illegal opcode> 23 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   87: new net/minecraftforge/client/event/ClientChatEvent
    //   90: dup
    //   91: aload_0
    //   92: <illegal opcode> 7 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   97: aload_0
    //   98: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   103: <illegal opcode> 21 : (Ljava/util/ArrayList;I)Ljava/lang/Object;
    //   108: checkcast java/lang/String
    //   111: invokespecial <init> : (Ljava/lang/String;)V
    //   114: <illegal opcode> 24 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Lnet/minecraftforge/fml/common/eventhandler/Event;)Z
    //   119: ldc ''
    //   121: invokevirtual length : ()I
    //   124: pop2
    //   125: aload_0
    //   126: <illegal opcode> 12 : (Lme/stupitdog/bhp/f1;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   131: <illegal opcode> 13 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   136: getstatic me/stupitdog/bhp/f1.llIIIIIllllIll : [Ljava/lang/String;
    //   139: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   142: bipush #23
    //   144: iaload
    //   145: aaload
    //   146: <illegal opcode> 14 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   151: invokestatic lIIIIIlIIIlllIII : (I)Z
    //   154: ifeq -> 235
    //   157: <illegal opcode> 18 : ()Lnet/minecraft/client/Minecraft;
    //   162: <illegal opcode> 19 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   167: aload_0
    //   168: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   173: aload_0
    //   174: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   179: <illegal opcode> 21 : (Ljava/util/ArrayList;I)Ljava/lang/Object;
    //   184: checkcast java/lang/String
    //   187: <illegal opcode> 22 : (Lnet/minecraft/client/entity/EntityPlayerSP;Ljava/lang/String;)V
    //   192: <illegal opcode> 23 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   197: new net/minecraftforge/client/event/ClientChatEvent
    //   200: dup
    //   201: aload_0
    //   202: <illegal opcode> 6 : (Lme/stupitdog/bhp/f1;)Ljava/util/ArrayList;
    //   207: aload_0
    //   208: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   213: <illegal opcode> 21 : (Ljava/util/ArrayList;I)Ljava/lang/Object;
    //   218: checkcast java/lang/String
    //   221: invokespecial <init> : (Ljava/lang/String;)V
    //   224: <illegal opcode> 24 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Lnet/minecraftforge/fml/common/eventhandler/Event;)Z
    //   229: ldc ''
    //   231: invokevirtual length : ()I
    //   234: pop2
    //   235: aload_0
    //   236: dup
    //   237: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   242: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   245: iconst_1
    //   246: iaload
    //   247: iadd
    //   248: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1;I)V
    //   253: aload_0
    //   254: <illegal opcode> 20 : (Lme/stupitdog/bhp/f1;)I
    //   259: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   262: iconst_3
    //   263: iaload
    //   264: invokestatic lIIIIIlIIIlllIlI : (II)Z
    //   267: ifeq -> 281
    //   270: aload_0
    //   271: getstatic me/stupitdog/bhp/f1.llIIIIlIIIIIlI : [I
    //   274: iconst_0
    //   275: iaload
    //   276: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1;I)V
    //   281: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	282	0	lllllllllllllllIllIllIlIllIllIII	Lme/stupitdog/bhp/f1;
    //   0	282	1	lllllllllllllllIllIllIlIllIlIlll	Lnet/minecraftforge/event/entity/living/LivingDeathEvent;
  }
  
  static {
    lIIIIIlIIIllIlll();
    lIIIIIlIIIlIllII();
    lIIIIIlIIIlIlIll();
    lIIIIIlIIIIlllIl();
  }
  
  private static CallSite lIIIIIIllIIIlIIl(MethodHandles.Lookup lllllllllllllllIllIllIlIllIIllII, String lllllllllllllllIllIllIlIllIIlIll, MethodType lllllllllllllllIllIllIlIllIIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIlIllIlIIlI = llIIIIIlIIIIlI[Integer.parseInt(lllllllllllllllIllIllIlIllIIlIll)].split(llIIIIIllllIll[llIIIIlIIIIIlI[26]]);
      Class<?> lllllllllllllllIllIllIlIllIlIIIl = Class.forName(lllllllllllllllIllIllIlIllIlIIlI[llIIIIlIIIIIlI[0]]);
      String lllllllllllllllIllIllIlIllIlIIII = lllllllllllllllIllIllIlIllIlIIlI[llIIIIlIIIIIlI[1]];
      MethodHandle lllllllllllllllIllIllIlIllIIllll = null;
      int lllllllllllllllIllIllIlIllIIlllI = lllllllllllllllIllIllIlIllIlIIlI[llIIIIlIIIIIlI[3]].length();
      if (lIIIIIlIIIlllIll(lllllllllllllllIllIllIlIllIIlllI, llIIIIlIIIIIlI[2])) {
        MethodType lllllllllllllllIllIllIlIllIlIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIlIllIlIIlI[llIIIIlIIIIIlI[2]], f1.class.getClassLoader());
        if (lIIIIIlIIIllllII(lllllllllllllllIllIllIlIllIIlllI, llIIIIlIIIIIlI[2])) {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findVirtual(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIlII);
          "".length();
          if (-(0xC5 ^ 0xC1) > 0)
            return null; 
        } else {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findStatic(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIlII);
        } 
        "".length();
        if (" ".length() << " ".length() != " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIlIllIlIIll = llIIIIIlIIIIll[Integer.parseInt(lllllllllllllllIllIllIlIllIlIIlI[llIIIIlIIIIIlI[2]])];
        if (lIIIIIlIIIllllII(lllllllllllllllIllIllIlIllIIlllI, llIIIIlIIIIIlI[3])) {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findGetter(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIIll);
          "".length();
          if (-" ".length() > -" ".length())
            return null; 
        } else if (lIIIIIlIIIllllII(lllllllllllllllIllIllIlIllIIlllI, llIIIIlIIIIIlI[4])) {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findStaticGetter(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIIll);
          "".length();
          if (((0x28 ^ 0xB ^ (0x26 ^ 0x3F) << " ".length()) & ((0x54 ^ 0x5F) << " ".length() << " ".length() << " ".length() ^ 160 + 115 - 200 + 86 ^ -" ".length())) > ((154 + 132 - 206 + 107 ^ (0x6B ^ 0x46) << " ".length() << " ".length()) & ((0x2C ^ 0x7B) << " ".length() ^ 86 + 35 - -22 + 18 ^ -" ".length())))
            return null; 
        } else if (lIIIIIlIIIllllII(lllllllllllllllIllIllIlIllIIlllI, llIIIIlIIIIIlI[5])) {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findSetter(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIIll);
          "".length();
          if (" ".length() > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIlIllIIllll = lllllllllllllllIllIllIlIllIIllII.findStaticSetter(lllllllllllllllIllIllIlIllIlIIIl, lllllllllllllllIllIllIlIllIlIIII, lllllllllllllllIllIllIlIllIlIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIlIllIIllll);
    } catch (Exception lllllllllllllllIllIllIlIllIIllIl) {
      lllllllllllllllIllIllIlIllIIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIIIIlllIl() {
    llIIIIIlIIIIlI = new String[llIIIIlIIIIIlI[25]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[6]] = llIIIIIllllIll[llIIIIlIIIIIlI[27]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[18]] = llIIIIIllllIll[llIIIIlIIIIIlI[28]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[23]] = llIIIIIllllIll[llIIIIlIIIIIlI[29]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[8]] = llIIIIIllllIll[llIIIIlIIIIIlI[30]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[4]] = llIIIIIllllIll[llIIIIlIIIIIlI[31]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[9]] = llIIIIIllllIll[llIIIIlIIIIIlI[32]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[10]] = llIIIIIllllIll[llIIIIlIIIIIlI[33]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[0]] = llIIIIIllllIll[llIIIIlIIIIIlI[34]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[22]] = llIIIIIllllIll[llIIIIlIIIIIlI[35]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[3]] = llIIIIIllllIll[llIIIIlIIIIIlI[36]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[2]] = llIIIIIllllIll[llIIIIlIIIIIlI[37]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[14]] = llIIIIIllllIll[llIIIIlIIIIIlI[38]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[19]] = llIIIIIllllIll[llIIIIlIIIIIlI[39]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[11]] = llIIIIIllllIll[llIIIIlIIIIIlI[40]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[15]] = llIIIIIllllIll[llIIIIlIIIIIlI[41]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[20]] = llIIIIIllllIll[llIIIIlIIIIIlI[42]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[13]] = llIIIIIllllIll[llIIIIlIIIIIlI[43]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[5]] = llIIIIIllllIll[llIIIIlIIIIIlI[44]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[12]] = llIIIIIllllIll[llIIIIlIIIIIlI[45]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[7]] = llIIIIIllllIll[llIIIIlIIIIIlI[46]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[24]] = llIIIIIllllIll[llIIIIlIIIIIlI[47]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[16]] = llIIIIIllllIll[llIIIIlIIIIIlI[48]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[17]] = llIIIIIllllIll[llIIIIlIIIIIlI[49]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[21]] = llIIIIIllllIll[llIIIIlIIIIIlI[50]];
    llIIIIIlIIIIlI[llIIIIlIIIIIlI[1]] = llIIIIIllllIll[llIIIIlIIIIIlI[51]];
    llIIIIIlIIIIll = new Class[llIIIIlIIIIIlI[9]];
    llIIIIIlIIIIll[llIIIIlIIIIIlI[2]] = Listener.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[4]] = f100000000000000000000.Mode.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[5]] = f100000000000000000000.Boolean.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[1]] = int.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[6]] = Minecraft.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[7]] = EntityPlayerSP.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[0]] = f13.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[3]] = ArrayList.class;
    llIIIIIlIIIIll[llIIIIlIIIIIlI[8]] = EventBus.class;
  }
  
  private static void lIIIIIlIIIlIlIll() {
    llIIIIIllllIll = new String[llIIIIlIIIIIlI[52]];
    llIIIIIllllIll[llIIIIlIIIIIlI[0]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[0]], llIIIIlIIIIIII[llIIIIlIIIIIlI[1]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[1]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[2]], llIIIIlIIIIIII[llIIIIlIIIIIlI[3]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[2]] = lIIIIIlIIIlIIIll(llIIIIlIIIIIII[llIIIIlIIIIIlI[4]], llIIIIlIIIIIII[llIIIIlIIIIIlI[5]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[3]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[6]], llIIIIlIIIIIII[llIIIIlIIIIIlI[7]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[4]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[8]], llIIIIlIIIIIII[llIIIIlIIIIIlI[9]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[5]] = lIIIIIlIIIlIIIll(llIIIIlIIIIIII[llIIIIlIIIIIlI[10]], llIIIIlIIIIIII[llIIIIlIIIIIlI[11]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[6]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[12]], llIIIIlIIIIIII[llIIIIlIIIIIlI[13]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[7]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[14]], llIIIIlIIIIIII[llIIIIlIIIIIlI[15]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[8]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[16]], llIIIIlIIIIIII[llIIIIlIIIIIlI[17]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[9]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[18]], llIIIIlIIIIIII[llIIIIlIIIIIlI[19]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[10]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[20]], llIIIIlIIIIIII[llIIIIlIIIIIlI[21]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[11]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[22]], llIIIIlIIIIIII[llIIIIlIIIIIlI[23]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[12]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[24]], llIIIIlIIIIIII[llIIIIlIIIIIlI[25]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[13]] = lIIIIIlIIIlIIIll(llIIIIlIIIIIII[llIIIIlIIIIIlI[26]], llIIIIlIIIIIII[llIIIIlIIIIIlI[27]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[14]] = lIIIIIlIIIlIIIII(llIIIIlIIIIIII[llIIIIlIIIIIlI[28]], llIIIIlIIIIIII[llIIIIlIIIIIlI[29]]);
    llIIIIIllllIll[llIIIIlIIIIIlI[15]] = lIIIIIlIIIlIIlII(llIIIIlIIIIIII[llIIIIlIIIIIlI[30]], "oYlOB");
    llIIIIIllllIll[llIIIIlIIIIIlI[16]] = lIIIIIlIIIlIIIll("2SsY9UQ6UAY=", "QTcIX");
    llIIIIIllllIll[llIIIIlIIIIIlI[17]] = lIIIIIlIIIlIIlII("IhwjDiQ5", "ciWaa");
    llIIIIIllllIll[llIIIIlIIIIIlI[18]] = lIIIIIlIIIlIIIll("duwowUp1Mfk=", "LQsAg");
    llIIIIIllllIll[llIIIIlIIIIIlI[19]] = lIIIIIlIIIlIIlII("KAM=", "oDhSm");
    llIIIIIllllIll[llIIIIlIIIIIlI[20]] = lIIIIIlIIIlIIIII("896Xh+/fnSY=", "WGjuu");
    llIIIIIllllIll[llIIIIlIIIIIlI[21]] = lIIIIIlIIIlIIIll("YrMIM1qFpcU=", "ccnDN");
    llIIIIIllllIll[llIIIIlIIIIIlI[22]] = lIIIIIlIIIlIIIII("MXJIjrIX3es=", "CIzgT");
    llIIIIIllllIll[llIIIIlIIIIIlI[23]] = lIIIIIlIIIlIIlII("Kj8=", "mxXty");
    llIIIIIllllIll[llIIIIlIIIIIlI[24]] = lIIIIIlIIIlIIIII("su6N/HIBxl8=", "AVrqW");
    llIIIIIllllIll[llIIIIlIIIIIlI[25]] = lIIIIIlIIIlIIIII("TE3BwZg6Ubk=", "aYJhs");
    llIIIIIllllIll[llIIIIlIIIIIlI[26]] = lIIIIIlIIIlIIlII("aQ==", "SeBLg");
    llIIIIIllllIll[llIIIIlIIIIIlI[27]] = lIIIIIlIIIlIIIII("+0HelEBWOvdr2edZD9MoMHSZ4oVag4yNafTAXmOY7MrjWCjYphJ6Zw==", "XaVZD");
    llIIIIIllllIll[llIIIIlIIIIIlI[28]] = lIIIIIlIIIlIIIll("hqWms/M+Wk7P5ZGZ4SbM8RYnQJ6n5sWhMBsK4K9FJaQ=", "teqho");
    llIIIIIllllIll[llIIIIlIIIIIlI[29]] = lIIIIIlIIIlIIlII("JQI8SDQiCS0FKyoBPAA2OQAtSDokCiUJN2UqIQg8KBUpAC0NCDoBPHEiHiMXHzgKMwpxX3JGeWtH", "KgHfY");
    llIIIIIllllIll[llIIIIlIIIIIlI[30]] = lIIIIIlIIIlIIIll("ig2JBCRwC5hT7SzgQnrO8UD5EgDrp7llLxG0MLVFMk3LQF2s8TNWWK3wCcvZABOcR10gpQ9AnVTlQhNM6kHdpFv7NGmHJuOhb2MHB1dk+to5npJ2YMAFIquu8b70KpB3Bz0NUFsA0YKd0GUw5pVbzIPzL5tg4Tzxg3QtV2K+JL49dBYd9CtmsNJWTJs0OiR9", "Lverr");
    llIIIIIllllIll[llIIIIlIIIIIlI[31]] = lIIIIIlIIIlIIIII("pZJ0xZCgdDN9oiQgwol89p7ssCmQ/tQr7GMYaLn+o/0L6N6eytZzzg==", "rfivW");
    llIIIIIllllIll[llIIIIlIIIIIlI[32]] = lIIIIIlIIIlIIIII("xq8dBhMZUmtwvKRGTo1w2Yu92JbSKcMOvEPb4frB5+62vpaeGO3LLw==", "Vlmfh");
    llIIIIIllllIll[llIIIIlIIIIIlI[33]] = lIIIIIlIIIlIIlII("IRFbCww5BBwMHCMTWxoQPFoTSUI+ERIRCzgRBzoXIxgQGRZ2XDkSGToVWhQZIhNaKww+HRsfQxZdORUdYwcBDQglABEXH2MWHQhXKkVFSEh8REVISHxERUhIfERFSEh8RFE6FyMYEBkWd05VWA==", "Ltuxx");
    llIIIIIllllIll[llIIIIlIIIIIlI[34]] = lIIIIIlIIIlIIIll("cnrLTXKEKK2zlrH70qll0DDXOAFz1xHg1On0Vhoh5nr9YczdQc6MWQ==", "ksCJB");
    llIIIIIllllIll[llIIIIlIIIIIlI[35]] = lIIIIIlIIIlIIIll("9F5h3LWIl+HkujFmpupzcAiwVLX3sU03VJjsfvHun2TnHcAjdNEnGpF0bjScg4E04sfWi3ydcT7gozTwGrCTJwu9MPzaclTMeuCQieSW3ApeKoiEpmGhng==", "hOsrr");
    llIIIIIllllIll[llIIIIlIIIIIlI[36]] = lIIIIIlIIIlIIIll("UpeBsQYYs4gKNs3N8b4fCz1MuVEKd5WmnD8vVihAHuTdOSuQoIQMxQ==", "sXSvp");
    llIIIIIllllIll[llIIIIlIIIIIlI[37]] = lIIIIIlIIIlIIIll("vm5DKdMbETL1jZrfDHENHBN0WuYg/rYEnJpHos4TutjTOucCYWjNHw==", "eiPgP");
    llIIIIIllllIll[llIIIIlIIIIIlI[38]] = lIIIIIlIIIlIIlII("Py8PNlY5LxcwVgY6Cz4WMnQcJg00IgoeHzshCzI7ND0cbVAZJBghGXoiGDkfeh0NJRE7KUJ+Im9uWQ==", "UNyWx");
    llIIIIIllllIll[llIIIIlIIIIIlI[39]] = lIIIIIlIIIlIIlII("GjENXj0dOhwTIhUyDV4zGD0cHiRaGRAeNRcmGBYkTjIQFTwQC05BZEdtJhdqQ25ZUHA=", "tTypP");
    llIIIIIllllIll[llIIIIlIIIIIlI[40]] = lIIIIIlIIIlIIlII("OBZGMRogAwE2CjoURiAGJV0Oc1Q6HTwtGjAeUndUdVNIYk4=", "UshBn");
    llIIIIIllllIll[llIIIIlIIIIIlI[41]] = lIIIIIlIIIlIIIII("lBLtBL+hOYw9PCD5a5LTLXCSD+ToD0sFTMlGntineJMp+9Xs04RZmu02RR+L3T433nw0msUrM90=", "aCHrC");
    llIIIIIllllIll[llIIIIlIIIIIlI[42]] = lIIIIIlIIIlIIIII("/GuVgg8oO3K1TdNJid8AcB1wW6f3Tf5Ba6w7rnvIYRI=", "ACFsJ");
    llIIIIIllllIll[llIIIIlIIIIIlI[43]] = lIIIIIlIIIlIIlII("Bx1PHQUfCAgaFQUfTwwZGlYHX0FaSFFeQVpIUV5BWkhRXkFaSFFeVScXBQtLDR0VOBAGDQRUWUM0Cw8HC1cNDx8NVzIaAwMWBlVLSlg=", "jxanq");
    llIIIIIllllIll[llIIIIlIIIIIlI[44]] = lIIIIIlIIIlIIIll("3MSImwKSouO6DknoMYaovIHtHCN05nQpPtqKrosNM2v/2bhXoZMJDuCzpyBy6zkcyw6uwjgop40=", "URlsx");
    llIIIIIllllIll[llIIIIlIIIIIlI[45]] = lIIIIIlIIIlIIlII("JApoNAI8Hy8zEiYIaCUeOUEgdkwkACIiTH1VZmdW", "IoFGv");
    llIIIIIllllIll[llIIIIlIIIIIlI[46]] = lIIIIIlIIIlIIIll("BKk+zU7T64oZAjiFYChZiGZJTWPvj5ljNHwqm3HXZyUQwgOZip6l1Q==", "pjtig");
    llIIIIIllllIll[llIIIIlIIIIIlI[47]] = lIIIIIlIIIlIIlII("CS8eficOJA8zOAYsHjYlFS0PfiwKJkQzJQonBT5kAjwPPj4PKwQ0JgI4RBU8AiQeEj8UcBo/ORNwQhwkAj5FPSMJLwkiKwE+DD84AC9FNicLZQk/JwolBH8vES8EJCIGJA48LxVlLyYvCT5ReRBdako=", "gJjPJ");
    llIIIIIllllIll[llIIIIlIIIIIlI[48]] = lIIIIIlIIIlIIlII("ByZjJycfMyQgNwUkYzY7Gm0rZWkZJjkaMgcmd3wfACI7NXwGIiMzfDk3Pz09DXhkAmlKYw==", "jCMTS");
    llIIIIIllllIll[llIIIIlIIIIIlI[49]] = lIIIIIlIIIlIIIll("cw7vtp3IHTWKXKpRlbKXANUB8VGZGKlqZDRODHWyd4mytp3+2sXMvO6S7riDNK1XbEmxSYFbj2nbMVv0TwHFh9RIDVFSzWPtVPzAuOcvMuE31VxDF5FnHOYG8YpCW3NLyTGC2/s8IwgjsLiQxDobBkoalbUKK6qP", "XCEkA");
    llIIIIIllllIll[llIIIIlIIIIIlI[50]] = lIIIIIlIIIlIIIII("y7B/zr6r2zXTV9IbPGlfBynI1MWNJZe3CWwTeZKbEEuTGfWGH4o965fkB6raFOyB4rjuNoGDMTE=", "YHBss");
    llIIIIIllllIll[llIIIIlIIIIIlI[51]] = lIIIIIlIIIlIIlII("Lh97Ozs2Cjw8KywdeyonM1QzeXUqFDEtN3lLb2hvY1p1", "CzUHO");
    llIIIIlIIIIIII = null;
  }
  
  private static void lIIIIIlIIIlIllII() {
    String str = (new Exception()).getStackTrace()[llIIIIlIIIIIlI[0]].getFileName();
    llIIIIlIIIIIII = str.substring(str.indexOf("ä") + llIIIIlIIIIIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIIIlIIIll(String lllllllllllllllIllIllIlIllIIIllI, String lllllllllllllllIllIllIlIllIIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIlIllIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlIllIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIlIllIIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIlIllIIlIII.init(llIIIIlIIIIIlI[2], lllllllllllllllIllIllIlIllIIlIIl);
      return new String(lllllllllllllllIllIllIlIllIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlIllIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIlIllIIIlll) {
      lllllllllllllllIllIllIlIllIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIIIlIIIII(String lllllllllllllllIllIllIlIllIIIIIl, String lllllllllllllllIllIllIlIllIIIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIllIlIllIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlIllIIIIII.getBytes(StandardCharsets.UTF_8)), llIIIIlIIIIIlI[8]), "DES");
      Cipher lllllllllllllllIllIllIlIllIIIIll = Cipher.getInstance("DES");
      lllllllllllllllIllIllIlIllIIIIll.init(llIIIIlIIIIIlI[2], lllllllllllllllIllIllIlIllIIIlII);
      return new String(lllllllllllllllIllIllIlIllIIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlIllIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIlIllIIIIlI) {
      lllllllllllllllIllIllIlIllIIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIIIlIIlII(String lllllllllllllllIllIllIlIlIlllllI, String lllllllllllllllIllIllIlIlIllllIl) {
    lllllllllllllllIllIllIlIlIlllllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIlIlIlllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIlIlIllllII = new StringBuilder();
    char[] lllllllllllllllIllIllIlIlIlllIll = lllllllllllllllIllIllIlIlIllllIl.toCharArray();
    int lllllllllllllllIllIllIlIlIlllIlI = llIIIIlIIIIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIlIlIlllllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIlIIIIIlI[0];
    while (lIIIIIlIIIllllIl(j, i)) {
      char lllllllllllllllIllIllIlIlIllllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIlIlIlllIlI++;
      j++;
      "".length();
      if (((0xD4 ^ 0xB7 ^ (0x50 ^ 0x79) << " ".length()) & (0x68 ^ 0x45 ^ (0x87 ^ 0x80) << " ".length() << " ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIlIlIllllII);
  }
  
  private static void lIIIIIlIIIllIlll() {
    llIIIIlIIIIIlI = new int[53];
    llIIIIlIIIIIlI[0] = (0x3A ^ 0x29) << " ".length() & ((0x20 ^ 0x33) << " ".length() ^ 0xFFFFFFFF);
    llIIIIlIIIIIlI[1] = " ".length();
    llIIIIlIIIIIlI[2] = " ".length() << " ".length();
    llIIIIlIIIIIlI[3] = "   ".length();
    llIIIIlIIIIIlI[4] = " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIlI[5] = 0x1E ^ 0x3 ^ "   ".length() << "   ".length();
    llIIIIlIIIIIlI[6] = "   ".length() << " ".length();
    llIIIIlIIIIIlI[7] = (0x58 ^ 0x1B) << " ".length() ^ 108 + 64 - 92 + 49;
    llIIIIlIIIIIlI[8] = " ".length() << "   ".length();
    llIIIIlIIIIIlI[9] = 88 + 83 - 94 + 62 ^ (0x4E ^ 0xF) << " ".length();
    llIIIIlIIIIIlI[10] = (0xC2 ^ 0xB5 ^ (0x5F ^ 0x66) << " ".length()) << " ".length();
    llIIIIlIIIIIlI[11] = 0x9C ^ 0x97 ^ (0xC5 ^ 0x88) & (0xC9 ^ 0x84 ^ 0xFFFFFFFF);
    llIIIIlIIIIIlI[12] = "   ".length() << " ".length() << " ".length();
    llIIIIlIIIIIlI[13] = 0x4B ^ 0x46;
    llIIIIlIIIIIlI[14] = (0x3E ^ 0x39) << " ".length();
    llIIIIlIIIIIlI[15] = (0x56 ^ 0x3) << " ".length() ^ 28 + 137 - 127 + 127;
    llIIIIlIIIIIlI[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIlI[17] = 0x13 ^ 0x2;
    llIIIIlIIIIIlI[18] = (" ".length() << " ".length() << " ".length() ^ 0x84 ^ 0x89) << " ".length();
    llIIIIlIIIIIlI[19] = 8 + 129 - 125 + 161 ^ (0x25 ^ 0x7A) << " ".length();
    llIIIIlIIIIIlI[20] = (0x3D ^ 0x38) << " ".length() << " ".length();
    llIIIIlIIIIIlI[21] = 140 + 53 - 169 + 145 ^ (0x8D ^ 0xA2) << " ".length() << " ".length();
    llIIIIlIIIIIlI[22] = (0xB4 ^ 0xBF) << " ".length();
    llIIIIlIIIIIlI[23] = 0xB7 ^ 0xA0;
    llIIIIlIIIIIlI[24] = "   ".length() << "   ".length();
    llIIIIlIIIIIlI[25] = 0x29 ^ 0x30;
    llIIIIlIIIIIlI[26] = (0x10 ^ 0x1D) << " ".length();
    llIIIIlIIIIIlI[27] = 122 + 150 - 250 + 159 ^ (0x64 ^ 0x33) << " ".length();
    llIIIIlIIIIIlI[28] = (0x43 ^ 0x44) << " ".length() << " ".length();
    llIIIIlIIIIIlI[29] = (0xA9 ^ 0xAC) << " ".length() << " ".length() ^ 0x71 ^ 0x78;
    llIIIIlIIIIIlI[30] = (106 + 81 - 184 + 154 ^ (0xCF ^ 0x86) << " ".length()) << " ".length();
    llIIIIlIIIIIlI[31] = 0x22 ^ 0x3D;
    llIIIIlIIIIIlI[32] = " ".length() << (73 + 74 - -25 + 17 ^ (0x79 ^ 0x6E) << "   ".length());
    llIIIIlIIIIIlI[33] = (0x31 ^ 0x40) << " ".length() ^ 142 + 131 - 107 + 29;
    llIIIIlIIIIIlI[34] = (0xA3 ^ 0xB2) << " ".length();
    llIIIIlIIIIIlI[35] = 0xCC ^ 0x99 ^ (0x92 ^ 0xA9) << " ".length();
    llIIIIlIIIIIlI[36] = (0xB ^ 0x5C ^ (0x7 ^ 0x28) << " ".length()) << " ".length() << " ".length();
    llIIIIlIIIIIlI[37] = (0x63 ^ 0x7C) << " ".length() ^ 0x8F ^ 0x94;
    llIIIIlIIIIIlI[38] = (0xB1 ^ 0xA2) << " ".length();
    llIIIIlIIIIIlI[39] = (0xFF ^ 0xAE) << " ".length() ^ 129 + 128 - 149 + 25;
    llIIIIlIIIIIlI[40] = (0x38 ^ 0x3 ^ (0x36 ^ 0x29) << " ".length()) << "   ".length();
    llIIIIlIIIIIlI[41] = 0xC ^ 0x2D ^ " ".length() << "   ".length();
    llIIIIlIIIIIlI[42] = (0x9A ^ 0x8F) << " ".length();
    llIIIIlIIIIIlI[43] = 0x38 ^ 0x13;
    llIIIIlIIIIIlI[44] = ((0xD0 ^ 0x8B) << " ".length() ^ 139 + 65 - 39 + 24) << " ".length() << " ".length();
    llIIIIlIIIIIlI[45] = (0x85 ^ 0x96) << "   ".length() ^ 156 + 75 - 52 + 2;
    llIIIIlIIIIIlI[46] = (0x26 ^ 0x31) << " ".length();
    llIIIIlIIIIIlI[47] = 0xE8 ^ 0xC7;
    llIIIIlIIIIIlI[48] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIIIIIlI[49] = 0x4A ^ 0x7B;
    llIIIIlIIIIIlI[50] = (0xAA ^ 0xB3) << " ".length();
    llIIIIlIIIIIlI[51] = (0x95 ^ 0xB8) << " ".length() << " ".length() ^ 106 + 58 - 106 + 77;
    llIIIIlIIIIIlI[52] = (0xA6 ^ 0x8B ^ " ".length() << (0x44 ^ 0x41)) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIIlIIIllllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIIIllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIIIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlIIIlllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lIIIIIlIIIlllIII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIlIIIlllIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */