package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public class f100000000000000000000000000000 extends au {
  f100000000000000000000.Mode mode;
  
  f100000000000000000000.Double height;
  
  f100000000000000000000.Boolean timer;
  
  private int ticks;
  
  private static String[] llIIIlllIIlllI;
  
  private static Class[] llIIIlllIIllll;
  
  private static final String[] llIIlIllllIIll;
  
  private static String[] llIIlIllllIlII;
  
  private static final int[] llIIlIllllIlIl;
  
  public f100000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   45: iconst_0
    //   46: iaload
    //   47: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   52: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	53	0	lllllllllllllllIllIIIlllIlIIlIII	Lme/stupitdog/bhp/f100000000000000000000000000000;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 2 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: aload_0
    //   52: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   58: iconst_5
    //   59: iaload
    //   60: aaload
    //   61: aload_1
    //   62: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   65: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   68: bipush #6
    //   70: iaload
    //   71: aaload
    //   72: <illegal opcode> 3 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   77: <illegal opcode> 4 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   82: aload_0
    //   83: aload_0
    //   84: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   87: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   90: bipush #7
    //   92: iaload
    //   93: aaload
    //   94: ldc2_w 2.5
    //   97: ldc2_w 0.5
    //   100: ldc2_w 2.5
    //   103: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   108: <illegal opcode> 6 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   113: aload_0
    //   114: aload_0
    //   115: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   118: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   121: bipush #8
    //   123: iaload
    //   124: aaload
    //   125: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   128: iconst_0
    //   129: iaload
    //   130: <illegal opcode> 7 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   135: <illegal opcode> 8 : (Lme/stupitdog/bhp/f100000000000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   140: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	141	0	lllllllllllllllIllIIIlllIlIIIlll	Lme/stupitdog/bhp/f100000000000000000000000000000;
    //   8	133	1	lllllllllllllllIllIIIlllIlIIIllI	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	133	1	lllllllllllllllIllIIIlllIlIIIllI	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: invokestatic lIIIlIIIIlllIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 32
    //   16: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: invokestatic lIIIlIIIIlllIIIl : (Ljava/lang/Object;)Z
    //   29: ifeq -> 33
    //   32: return
    //   33: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   38: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   43: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   48: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   51: ifeq -> 122
    //   54: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   59: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   64: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   69: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   72: ifeq -> 122
    //   75: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   80: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   85: <illegal opcode> 14 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   90: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   93: ifeq -> 122
    //   96: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   101: <illegal opcode> 15 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   106: <illegal opcode> 16 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   111: <illegal opcode> 17 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   116: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   119: ifeq -> 123
    //   122: return
    //   123: aload_0
    //   124: <illegal opcode> 18 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   129: <illegal opcode> 19 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   134: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   137: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   140: bipush #9
    //   142: iaload
    //   143: aaload
    //   144: <illegal opcode> 20 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   149: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   152: ifeq -> 2385
    //   155: aload_0
    //   156: <illegal opcode> 21 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   161: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   166: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   169: ifeq -> 218
    //   172: aload_0
    //   173: <illegal opcode> 23 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)I
    //   178: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   181: ifeq -> 200
    //   184: <illegal opcode> 24 : ()V
    //   189: ldc ''
    //   191: invokevirtual length : ()I
    //   194: pop
    //   195: aconst_null
    //   196: ifnull -> 218
    //   199: return
    //   200: aload_0
    //   201: dup
    //   202: <illegal opcode> 23 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)I
    //   207: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   210: iconst_1
    //   211: iaload
    //   212: isub
    //   213: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   218: ldc2_w 0.1
    //   221: <illegal opcode> 25 : (D)[D
    //   226: astore_1
    //   227: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   230: iconst_0
    //   231: iaload
    //   232: istore_2
    //   233: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   236: iconst_0
    //   237: iaload
    //   238: istore_3
    //   239: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   242: iconst_0
    //   243: iaload
    //   244: istore #4
    //   246: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   249: iconst_0
    //   250: iaload
    //   251: istore #5
    //   253: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   258: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   263: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   268: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   273: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   278: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   283: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   288: aload_1
    //   289: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   292: iconst_0
    //   293: iaload
    //   294: daload
    //   295: ldc2_w 2.6
    //   298: aload_1
    //   299: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   302: iconst_1
    //   303: iaload
    //   304: daload
    //   305: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   310: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   315: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   320: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   323: ifeq -> 405
    //   326: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   331: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   336: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   341: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   346: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   351: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   356: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   361: aload_1
    //   362: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   365: iconst_0
    //   366: iaload
    //   367: daload
    //   368: ldc2_w 2.4
    //   371: aload_1
    //   372: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   375: iconst_1
    //   376: iaload
    //   377: daload
    //   378: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   383: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   388: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   393: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   396: ifeq -> 405
    //   399: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   402: iconst_1
    //   403: iaload
    //   404: istore_2
    //   405: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   410: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   415: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   420: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   425: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   430: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   435: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   440: aload_1
    //   441: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   444: iconst_0
    //   445: iaload
    //   446: daload
    //   447: ldc2_w 2.1
    //   450: aload_1
    //   451: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   454: iconst_1
    //   455: iaload
    //   456: daload
    //   457: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   462: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   467: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   472: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   475: ifeq -> 557
    //   478: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   483: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   488: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   493: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   498: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   503: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   508: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   513: aload_1
    //   514: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   517: iconst_0
    //   518: iaload
    //   519: daload
    //   520: ldc2_w 1.9
    //   523: aload_1
    //   524: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   527: iconst_1
    //   528: iaload
    //   529: daload
    //   530: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   535: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   540: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   545: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   548: ifeq -> 557
    //   551: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   554: iconst_1
    //   555: iaload
    //   556: istore_3
    //   557: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   562: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   567: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   572: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   577: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   582: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   587: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   592: aload_1
    //   593: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   596: iconst_0
    //   597: iaload
    //   598: daload
    //   599: ldc2_w 1.6
    //   602: aload_1
    //   603: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   606: iconst_1
    //   607: iaload
    //   608: daload
    //   609: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   614: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   619: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   624: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   627: ifeq -> 710
    //   630: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   635: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   640: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   645: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   650: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   655: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   660: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   665: aload_1
    //   666: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   669: iconst_0
    //   670: iaload
    //   671: daload
    //   672: ldc2_w 1.4
    //   675: aload_1
    //   676: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   679: iconst_1
    //   680: iaload
    //   681: daload
    //   682: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   687: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   692: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   697: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   700: ifeq -> 710
    //   703: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   706: iconst_1
    //   707: iaload
    //   708: istore #4
    //   710: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   715: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   720: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   725: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   730: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   735: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   740: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   745: aload_1
    //   746: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   749: iconst_0
    //   750: iaload
    //   751: daload
    //   752: dconst_1
    //   753: aload_1
    //   754: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   757: iconst_1
    //   758: iaload
    //   759: daload
    //   760: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   765: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   770: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   775: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   778: ifeq -> 861
    //   781: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   786: <illegal opcode> 10 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   791: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   796: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   801: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   806: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   811: <illegal opcode> 26 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   816: aload_1
    //   817: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   820: iconst_0
    //   821: iaload
    //   822: daload
    //   823: ldc2_w 0.6
    //   826: aload_1
    //   827: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   830: iconst_1
    //   831: iaload
    //   832: daload
    //   833: <illegal opcode> 27 : (Lnet/minecraft/util/math/AxisAlignedBB;DDD)Lnet/minecraft/util/math/AxisAlignedBB;
    //   838: <illegal opcode> 28 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   843: <illegal opcode> 29 : (Ljava/util/List;)Z
    //   848: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   851: ifeq -> 861
    //   854: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   857: iconst_1
    //   858: iaload
    //   859: istore #5
    //   861: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   866: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   871: <illegal opcode> 30 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   876: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   879: ifeq -> 2385
    //   882: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   887: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   892: <illegal opcode> 31 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   897: fconst_0
    //   898: invokestatic lIIIlIIIIllIlllI : (FF)I
    //   901: invokestatic lIIIlIIIIlllIIlI : (I)Z
    //   904: ifeq -> 932
    //   907: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   912: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   917: <illegal opcode> 32 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   922: fconst_0
    //   923: invokestatic lIIIlIIIIllIlllI : (FF)I
    //   926: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   929: ifeq -> 2385
    //   932: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   937: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   942: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   947: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   950: ifeq -> 2385
    //   953: iload #5
    //   955: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   958: ifeq -> 1240
    //   961: aload_0
    //   962: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   967: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   972: dconst_1
    //   973: invokestatic lIIIlIIIIllIllll : (DD)I
    //   976: invokestatic lIIIlIIIIlllIlII : (I)Z
    //   979: ifeq -> 1240
    //   982: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   985: iconst_2
    //   986: iaload
    //   987: newarray double
    //   989: dup
    //   990: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   993: iconst_0
    //   994: iaload
    //   995: ldc2_w 0.42
    //   998: dastore
    //   999: dup
    //   1000: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1003: iconst_1
    //   1004: iaload
    //   1005: ldc2_w 0.753
    //   1008: dastore
    //   1009: astore #6
    //   1011: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1014: iconst_0
    //   1015: iaload
    //   1016: istore #7
    //   1018: iload #7
    //   1020: aload #6
    //   1022: arraylength
    //   1023: invokestatic lIIIlIIIIlllIlIl : (II)Z
    //   1026: ifeq -> 1142
    //   1029: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1034: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1039: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1044: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1047: dup
    //   1048: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1053: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1058: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1063: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1068: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1073: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1078: aload #6
    //   1080: iload #7
    //   1082: daload
    //   1083: dadd
    //   1084: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1089: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1094: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1099: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1104: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1109: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   1114: invokespecial <init> : (DDDZ)V
    //   1117: <illegal opcode> 40 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1122: iinc #7, 1
    //   1125: ldc ''
    //   1127: invokevirtual length : ()I
    //   1130: pop
    //   1131: ldc_w '  '
    //   1134: invokevirtual length : ()I
    //   1137: ineg
    //   1138: iflt -> 1018
    //   1141: return
    //   1142: aload_0
    //   1143: <illegal opcode> 21 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1148: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1153: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   1156: ifeq -> 1167
    //   1159: ldc_w 0.6
    //   1162: <illegal opcode> 41 : (F)V
    //   1167: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1172: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1177: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1182: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1187: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1192: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1197: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1202: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1207: dconst_1
    //   1208: dadd
    //   1209: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1214: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1219: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1224: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)V
    //   1229: aload_0
    //   1230: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1233: iconst_1
    //   1234: iaload
    //   1235: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   1240: iload #4
    //   1242: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   1245: ifeq -> 1589
    //   1248: aload_0
    //   1249: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   1254: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   1259: ldc2_w 1.5
    //   1262: invokestatic lIIIlIIIIllIllll : (DD)I
    //   1265: invokestatic lIIIlIIIIlllIlII : (I)Z
    //   1268: ifeq -> 1589
    //   1271: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1274: bipush #6
    //   1276: iaload
    //   1277: newarray double
    //   1279: dup
    //   1280: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1283: iconst_0
    //   1284: iaload
    //   1285: ldc2_w 0.42
    //   1288: dastore
    //   1289: dup
    //   1290: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1293: iconst_1
    //   1294: iaload
    //   1295: ldc2_w 0.75
    //   1298: dastore
    //   1299: dup
    //   1300: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1303: iconst_2
    //   1304: iaload
    //   1305: dconst_1
    //   1306: dastore
    //   1307: dup
    //   1308: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1311: iconst_3
    //   1312: iaload
    //   1313: ldc2_w 1.16
    //   1316: dastore
    //   1317: dup
    //   1318: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1321: iconst_4
    //   1322: iaload
    //   1323: ldc2_w 1.23
    //   1326: dastore
    //   1327: dup
    //   1328: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1331: iconst_5
    //   1332: iaload
    //   1333: ldc2_w 1.2
    //   1336: dastore
    //   1337: astore #6
    //   1339: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1342: iconst_0
    //   1343: iaload
    //   1344: istore #7
    //   1346: iload #7
    //   1348: aload #6
    //   1350: arraylength
    //   1351: invokestatic lIIIlIIIIlllIlIl : (II)Z
    //   1354: ifeq -> 1489
    //   1357: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1362: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1367: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1372: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1375: dup
    //   1376: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1381: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1386: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1391: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1396: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1401: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1406: aload #6
    //   1408: iload #7
    //   1410: daload
    //   1411: dadd
    //   1412: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1417: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1422: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1427: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1432: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1437: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   1442: invokespecial <init> : (DDDZ)V
    //   1445: <illegal opcode> 40 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1450: iinc #7, 1
    //   1453: ldc ''
    //   1455: invokevirtual length : ()I
    //   1458: pop
    //   1459: ldc_w ' '
    //   1462: invokevirtual length : ()I
    //   1465: ldc_w ' '
    //   1468: invokevirtual length : ()I
    //   1471: ldc_w ' '
    //   1474: invokevirtual length : ()I
    //   1477: ishl
    //   1478: ishl
    //   1479: ldc_w ' '
    //   1482: invokevirtual length : ()I
    //   1485: if_icmpge -> 1346
    //   1488: return
    //   1489: aload_0
    //   1490: <illegal opcode> 21 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1495: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1500: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   1503: ifeq -> 1514
    //   1506: ldc_w 0.35
    //   1509: <illegal opcode> 41 : (F)V
    //   1514: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1519: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1524: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1529: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1534: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1539: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1544: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1549: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1554: ldc2_w 1.5
    //   1557: dadd
    //   1558: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1563: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1568: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1573: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)V
    //   1578: aload_0
    //   1579: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1582: iconst_1
    //   1583: iaload
    //   1584: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   1589: iload_3
    //   1590: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   1593: ifeq -> 2011
    //   1596: aload_0
    //   1597: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   1602: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   1607: ldc2_w 2.0
    //   1610: invokestatic lIIIlIIIIllIllll : (DD)I
    //   1613: invokestatic lIIIlIIIIlllIlII : (I)Z
    //   1616: ifeq -> 2011
    //   1619: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1622: bipush #8
    //   1624: iaload
    //   1625: newarray double
    //   1627: dup
    //   1628: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1631: iconst_0
    //   1632: iaload
    //   1633: ldc2_w 0.42
    //   1636: dastore
    //   1637: dup
    //   1638: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1641: iconst_1
    //   1642: iaload
    //   1643: ldc2_w 0.78
    //   1646: dastore
    //   1647: dup
    //   1648: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1651: iconst_2
    //   1652: iaload
    //   1653: ldc2_w 0.63
    //   1656: dastore
    //   1657: dup
    //   1658: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1661: iconst_3
    //   1662: iaload
    //   1663: ldc2_w 0.51
    //   1666: dastore
    //   1667: dup
    //   1668: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1671: iconst_4
    //   1672: iaload
    //   1673: ldc2_w 0.9
    //   1676: dastore
    //   1677: dup
    //   1678: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1681: iconst_5
    //   1682: iaload
    //   1683: ldc2_w 1.21
    //   1686: dastore
    //   1687: dup
    //   1688: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1691: bipush #6
    //   1693: iaload
    //   1694: ldc2_w 1.45
    //   1697: dastore
    //   1698: dup
    //   1699: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1702: bipush #7
    //   1704: iaload
    //   1705: ldc2_w 1.43
    //   1708: dastore
    //   1709: astore #6
    //   1711: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   1714: iconst_0
    //   1715: iaload
    //   1716: istore #7
    //   1718: iload #7
    //   1720: aload #6
    //   1722: arraylength
    //   1723: invokestatic lIIIlIIIIlllIlIl : (II)Z
    //   1726: ifeq -> 1911
    //   1729: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1734: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1739: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1744: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   1747: dup
    //   1748: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1753: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1758: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1763: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1768: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1773: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1778: aload #6
    //   1780: iload #7
    //   1782: daload
    //   1783: dadd
    //   1784: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1789: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1794: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1799: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1804: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1809: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   1814: invokespecial <init> : (DDDZ)V
    //   1817: <illegal opcode> 40 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1822: iinc #7, 1
    //   1825: ldc ''
    //   1827: invokevirtual length : ()I
    //   1830: pop
    //   1831: bipush #47
    //   1833: bipush #58
    //   1835: ixor
    //   1836: ldc_w ' '
    //   1839: invokevirtual length : ()I
    //   1842: ishl
    //   1843: sipush #135
    //   1846: sipush #162
    //   1849: ixor
    //   1850: ixor
    //   1851: ldc_w ' '
    //   1854: invokevirtual length : ()I
    //   1857: ldc_w ' '
    //   1860: invokevirtual length : ()I
    //   1863: ishl
    //   1864: ishl
    //   1865: bipush #15
    //   1867: bipush #24
    //   1869: ixor
    //   1870: ldc_w '   '
    //   1873: invokevirtual length : ()I
    //   1876: ldc_w '   '
    //   1879: invokevirtual length : ()I
    //   1882: ishl
    //   1883: ixor
    //   1884: ldc_w ' '
    //   1887: invokevirtual length : ()I
    //   1890: ldc_w ' '
    //   1893: invokevirtual length : ()I
    //   1896: ishl
    //   1897: ishl
    //   1898: ldc_w ' '
    //   1901: invokevirtual length : ()I
    //   1904: ineg
    //   1905: ixor
    //   1906: iand
    //   1907: ifeq -> 1718
    //   1910: return
    //   1911: aload_0
    //   1912: <illegal opcode> 21 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1917: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1922: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   1925: ifeq -> 1936
    //   1928: ldc_w 0.25
    //   1931: <illegal opcode> 41 : (F)V
    //   1936: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1941: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1946: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1951: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1956: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1961: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1966: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1971: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1976: ldc2_w 2.0
    //   1979: dadd
    //   1980: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   1985: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1990: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1995: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)V
    //   2000: aload_0
    //   2001: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2004: iconst_2
    //   2005: iaload
    //   2006: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   2011: iload_2
    //   2012: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   2015: ifeq -> 2385
    //   2018: aload_0
    //   2019: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   2024: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   2029: ldc2_w 2.5
    //   2032: invokestatic lIIIlIIIIllIllll : (DD)I
    //   2035: invokestatic lIIIlIIIIlllIlII : (I)Z
    //   2038: ifeq -> 2385
    //   2041: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2044: bipush #10
    //   2046: iaload
    //   2047: newarray double
    //   2049: dup
    //   2050: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2053: iconst_0
    //   2054: iaload
    //   2055: ldc2_w 0.425
    //   2058: dastore
    //   2059: dup
    //   2060: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2063: iconst_1
    //   2064: iaload
    //   2065: ldc2_w 0.821
    //   2068: dastore
    //   2069: dup
    //   2070: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2073: iconst_2
    //   2074: iaload
    //   2075: ldc2_w 0.699
    //   2078: dastore
    //   2079: dup
    //   2080: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2083: iconst_3
    //   2084: iaload
    //   2085: ldc2_w 0.599
    //   2088: dastore
    //   2089: dup
    //   2090: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2093: iconst_4
    //   2094: iaload
    //   2095: ldc2_w 1.022
    //   2098: dastore
    //   2099: dup
    //   2100: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2103: iconst_5
    //   2104: iaload
    //   2105: ldc2_w 1.372
    //   2108: dastore
    //   2109: dup
    //   2110: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2113: bipush #6
    //   2115: iaload
    //   2116: ldc2_w 1.652
    //   2119: dastore
    //   2120: dup
    //   2121: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2124: bipush #7
    //   2126: iaload
    //   2127: ldc2_w 1.869
    //   2130: dastore
    //   2131: dup
    //   2132: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2135: bipush #8
    //   2137: iaload
    //   2138: ldc2_w 2.019
    //   2141: dastore
    //   2142: dup
    //   2143: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2146: bipush #9
    //   2148: iaload
    //   2149: ldc2_w 1.907
    //   2152: dastore
    //   2153: astore #6
    //   2155: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2158: iconst_0
    //   2159: iaload
    //   2160: istore #7
    //   2162: iload #7
    //   2164: aload #6
    //   2166: arraylength
    //   2167: invokestatic lIIIlIIIIlllIlIl : (II)Z
    //   2170: ifeq -> 2285
    //   2173: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2178: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2183: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   2188: new net/minecraft/network/play/client/CPacketPlayer$Position
    //   2191: dup
    //   2192: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2197: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2202: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2207: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2212: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2217: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2222: aload #6
    //   2224: iload #7
    //   2226: daload
    //   2227: dadd
    //   2228: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2233: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2238: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2243: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2248: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2253: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   2258: invokespecial <init> : (DDDZ)V
    //   2261: <illegal opcode> 40 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   2266: iinc #7, 1
    //   2269: ldc ''
    //   2271: invokevirtual length : ()I
    //   2274: pop
    //   2275: ldc_w '   '
    //   2278: invokevirtual length : ()I
    //   2281: ifne -> 2162
    //   2284: return
    //   2285: aload_0
    //   2286: <illegal opcode> 21 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   2291: <illegal opcode> 22 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   2296: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   2299: ifeq -> 2310
    //   2302: ldc_w 0.15
    //   2305: <illegal opcode> 41 : (F)V
    //   2310: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2315: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2320: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2325: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2330: <illegal opcode> 37 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2335: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2340: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2345: <illegal opcode> 38 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2350: ldc2_w 2.5
    //   2353: dadd
    //   2354: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2359: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2364: <illegal opcode> 39 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   2369: <illegal opcode> 42 : (Lnet/minecraft/client/entity/EntityPlayerSP;DDD)V
    //   2374: aload_0
    //   2375: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2378: iconst_2
    //   2379: iaload
    //   2380: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100000000000000000000000000000;I)V
    //   2385: aload_0
    //   2386: <illegal opcode> 18 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   2391: <illegal opcode> 19 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   2396: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   2399: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2402: bipush #10
    //   2404: iaload
    //   2405: aaload
    //   2406: <illegal opcode> 20 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   2411: invokestatic lIIIlIIIIlllIIll : (I)Z
    //   2414: ifeq -> 2470
    //   2417: new java/text/DecimalFormat
    //   2420: dup
    //   2421: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIIll : [Ljava/lang/String;
    //   2424: getstatic me/stupitdog/bhp/f100000000000000000000000000000.llIIlIllllIlIl : [I
    //   2427: bipush #11
    //   2429: iaload
    //   2430: aaload
    //   2431: invokespecial <init> : (Ljava/lang/String;)V
    //   2434: astore_1
    //   2435: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   2440: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   2445: aload_1
    //   2446: aload_0
    //   2447: <illegal opcode> 34 : (Lme/stupitdog/bhp/f100000000000000000000000000000;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   2452: <illegal opcode> 35 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   2457: <illegal opcode> 43 : (Ljava/text/DecimalFormat;D)Ljava/lang/String;
    //   2462: <illegal opcode> 44 : (Ljava/lang/String;)F
    //   2467: putfield field_70138_W : F
    //   2470: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   1018	124	7	lllllllllllllllIllIIIlllIlIIIlIl	I
    //   1011	229	6	lllllllllllllllIllIIIlllIlIIIlII	[D
    //   1346	143	7	lllllllllllllllIllIIIlllIlIIIIll	I
    //   1339	250	6	lllllllllllllllIllIIIlllIlIIIIlI	[D
    //   1718	193	7	lllllllllllllllIllIIIlllIlIIIIIl	I
    //   1711	300	6	lllllllllllllllIllIIIlllIlIIIIII	[D
    //   2162	123	7	lllllllllllllllIllIIIlllIIllllll	I
    //   2155	230	6	lllllllllllllllIllIIIlllIIlllllI	[D
    //   227	2158	1	lllllllllllllllIllIIIlllIIllllIl	[D
    //   233	2152	2	lllllllllllllllIllIIIlllIIllllII	Z
    //   239	2146	3	lllllllllllllllIllIIIlllIIlllIll	Z
    //   246	2139	4	lllllllllllllllIllIIIlllIIlllIlI	Z
    //   253	2132	5	lllllllllllllllIllIIIlllIIlllIIl	Z
    //   2435	35	1	lllllllllllllllIllIIIlllIIlllIII	Ljava/text/DecimalFormat;
    //   0	2471	0	lllllllllllllllIllIIIlllIIllIlll	Lme/stupitdog/bhp/f100000000000000000000000000000;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIlIIIIlllIIII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 32
    //   16: <illegal opcode> 9 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   26: ldc_w 0.5
    //   29: putfield field_70138_W : F
    //   32: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	33	0	lllllllllllllllIllIIIlllIIllIllI	Lme/stupitdog/bhp/f100000000000000000000000000000;
  }
  
  static {
    lIIIlIIIIllIllIl();
    lIIIlIIIIllIllII();
    lIIIlIIIIllIlIll();
    lIIIlIIIIllIIlll();
  }
  
  private static CallSite lIIIIlIlIllllIII(MethodHandles.Lookup lllllllllllllllIllIIIlllIIlIllIl, String lllllllllllllllIllIIIlllIIlIllII, MethodType lllllllllllllllIllIIIlllIIlIlIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIlllIIllIIll = llIIIlllIIlllI[Integer.parseInt(lllllllllllllllIllIIIlllIIlIllII)].split(llIIlIllllIIll[llIIlIllllIlIl[12]]);
      Class<?> lllllllllllllllIllIIIlllIIllIIlI = Class.forName(lllllllllllllllIllIIIlllIIllIIll[llIIlIllllIlIl[0]]);
      String lllllllllllllllIllIIIlllIIllIIIl = lllllllllllllllIllIIIlllIIllIIll[llIIlIllllIlIl[1]];
      MethodHandle lllllllllllllllIllIIIlllIIllIIII = null;
      int lllllllllllllllIllIIIlllIIlIllll = lllllllllllllllIllIIIlllIIllIIll[llIIlIllllIlIl[3]].length();
      if (lIIIlIIIIlllIllI(lllllllllllllllIllIIIlllIIlIllll, llIIlIllllIlIl[2])) {
        MethodType lllllllllllllllIllIIIlllIIllIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIlllIIllIIll[llIIlIllllIlIl[2]], f100000000000000000000000000000.class.getClassLoader());
        if (lIIIlIIIIlllIlll(lllllllllllllllIllIIIlllIIlIllll, llIIlIllllIlIl[2])) {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findVirtual(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlIl);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findStatic(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlIl);
        } 
        "".length();
        if (((0x2A ^ 0x3) << " ".length() & ((0x36 ^ 0x1F) << " ".length() ^ 0xFFFFFFFF)) >= " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIlllIIllIlII = llIIIlllIIllll[Integer.parseInt(lllllllllllllllIllIIIlllIIllIIll[llIIlIllllIlIl[2]])];
        if (lIIIlIIIIlllIlll(lllllllllllllllIllIIIlllIIlIllll, llIIlIllllIlIl[3])) {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findGetter(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (lIIIlIIIIlllIlll(lllllllllllllllIllIIIlllIIlIllll, llIIlIllllIlIl[4])) {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findStaticGetter(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (lIIIlIIIIlllIlll(lllllllllllllllIllIIIlllIIlIllll, llIIlIllllIlIl[5])) {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findSetter(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIIlllIIllIIII = lllllllllllllllIllIIIlllIIlIllIl.findStaticSetter(lllllllllllllllIllIIIlllIIllIIlI, lllllllllllllllIllIIIlllIIllIIIl, lllllllllllllllIllIIIlllIIllIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIlllIIllIIII);
    } catch (Exception lllllllllllllllIllIIIlllIIlIlllI) {
      lllllllllllllllIllIIIlllIIlIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIllIIlll() {
    llIIIlllIIlllI = new String[llIIlIllllIlIl[13]];
    llIIIlllIIlllI[llIIlIllllIlIl[14]] = llIIlIllllIIll[llIIlIllllIlIl[15]];
    llIIIlllIIlllI[llIIlIllllIlIl[16]] = llIIlIllllIIll[llIIlIllllIlIl[14]];
    llIIIlllIIlllI[llIIlIllllIlIl[17]] = llIIlIllllIIll[llIIlIllllIlIl[18]];
    llIIIlllIIlllI[llIIlIllllIlIl[19]] = llIIlIllllIIll[llIIlIllllIlIl[16]];
    llIIIlllIIlllI[llIIlIllllIlIl[20]] = llIIlIllllIIll[llIIlIllllIlIl[21]];
    llIIIlllIIlllI[llIIlIllllIlIl[22]] = llIIlIllllIIll[llIIlIllllIlIl[23]];
    llIIIlllIIlllI[llIIlIllllIlIl[2]] = llIIlIllllIIll[llIIlIllllIlIl[24]];
    llIIIlllIIlllI[llIIlIllllIlIl[25]] = llIIlIllllIIll[llIIlIllllIlIl[26]];
    llIIIlllIIlllI[llIIlIllllIlIl[27]] = llIIlIllllIIll[llIIlIllllIlIl[28]];
    llIIIlllIIlllI[llIIlIllllIlIl[18]] = llIIlIllllIIll[llIIlIllllIlIl[29]];
    llIIIlllIIlllI[llIIlIllllIlIl[28]] = llIIlIllllIIll[llIIlIllllIlIl[20]];
    llIIIlllIIlllI[llIIlIllllIlIl[26]] = llIIlIllllIIll[llIIlIllllIlIl[30]];
    llIIIlllIIlllI[llIIlIllllIlIl[31]] = llIIlIllllIIll[llIIlIllllIlIl[32]];
    llIIIlllIIlllI[llIIlIllllIlIl[7]] = llIIlIllllIIll[llIIlIllllIlIl[33]];
    llIIIlllIIlllI[llIIlIllllIlIl[1]] = llIIlIllllIIll[llIIlIllllIlIl[34]];
    llIIIlllIIlllI[llIIlIllllIlIl[34]] = llIIlIllllIIll[llIIlIllllIlIl[27]];
    llIIIlllIIlllI[llIIlIllllIlIl[33]] = llIIlIllllIIll[llIIlIllllIlIl[35]];
    llIIIlllIIlllI[llIIlIllllIlIl[35]] = llIIlIllllIIll[llIIlIllllIlIl[36]];
    llIIIlllIIlllI[llIIlIllllIlIl[30]] = llIIlIllllIIll[llIIlIllllIlIl[37]];
    llIIIlllIIlllI[llIIlIllllIlIl[4]] = llIIlIllllIIll[llIIlIllllIlIl[19]];
    llIIIlllIIlllI[llIIlIllllIlIl[37]] = llIIlIllllIIll[llIIlIllllIlIl[38]];
    llIIIlllIIlllI[llIIlIllllIlIl[6]] = llIIlIllllIIll[llIIlIllllIlIl[39]];
    llIIIlllIIlllI[llIIlIllllIlIl[8]] = llIIlIllllIIll[llIIlIllllIlIl[31]];
    llIIIlllIIlllI[llIIlIllllIlIl[21]] = llIIlIllllIIll[llIIlIllllIlIl[17]];
    llIIIlllIIlllI[llIIlIllllIlIl[40]] = llIIlIllllIIll[llIIlIllllIlIl[41]];
    llIIIlllIIlllI[llIIlIllllIlIl[10]] = llIIlIllllIIll[llIIlIllllIlIl[25]];
    llIIIlllIIlllI[llIIlIllllIlIl[5]] = llIIlIllllIIll[llIIlIllllIlIl[42]];
    llIIIlllIIlllI[llIIlIllllIlIl[0]] = llIIlIllllIIll[llIIlIllllIlIl[40]];
    llIIIlllIIlllI[llIIlIllllIlIl[38]] = llIIlIllllIIll[llIIlIllllIlIl[22]];
    llIIIlllIIlllI[llIIlIllllIlIl[11]] = llIIlIllllIIll[llIIlIllllIlIl[43]];
    llIIIlllIIlllI[llIIlIllllIlIl[24]] = llIIlIllllIIll[llIIlIllllIlIl[44]];
    llIIIlllIIlllI[llIIlIllllIlIl[12]] = llIIlIllllIIll[llIIlIllllIlIl[45]];
    llIIIlllIIlllI[llIIlIllllIlIl[39]] = llIIlIllllIIll[llIIlIllllIlIl[13]];
    llIIIlllIIlllI[llIIlIllllIlIl[41]] = llIIlIllllIIll[llIIlIllllIlIl[46]];
    llIIIlllIIlllI[llIIlIllllIlIl[43]] = llIIlIllllIIll[llIIlIllllIlIl[47]];
    llIIIlllIIlllI[llIIlIllllIlIl[42]] = llIIlIllllIIll[llIIlIllllIlIl[48]];
    llIIIlllIIlllI[llIIlIllllIlIl[32]] = llIIlIllllIIll[llIIlIllllIlIl[49]];
    llIIIlllIIlllI[llIIlIllllIlIl[29]] = llIIlIllllIIll[llIIlIllllIlIl[50]];
    llIIIlllIIlllI[llIIlIllllIlIl[3]] = llIIlIllllIIll[llIIlIllllIlIl[51]];
    llIIIlllIIlllI[llIIlIllllIlIl[9]] = llIIlIllllIIll[llIIlIllllIlIl[52]];
    llIIIlllIIlllI[llIIlIllllIlIl[23]] = llIIlIllllIIll[llIIlIllllIlIl[53]];
    llIIIlllIIlllI[llIIlIllllIlIl[15]] = llIIlIllllIIll[llIIlIllllIlIl[54]];
    llIIIlllIIlllI[llIIlIllllIlIl[45]] = llIIlIllllIIll[llIIlIllllIlIl[55]];
    llIIIlllIIlllI[llIIlIllllIlIl[36]] = llIIlIllllIIll[llIIlIllllIlIl[56]];
    llIIIlllIIlllI[llIIlIllllIlIl[44]] = llIIlIllllIIll[llIIlIllllIlIl[57]];
    llIIIlllIIllll = new Class[llIIlIllllIlIl[14]];
    llIIIlllIIllll[llIIlIllllIlIl[12]] = NetHandlerPlayClient.class;
    llIIIlllIIllll[llIIlIllllIlIl[7]] = EntityPlayerSP.class;
    llIIIlllIIllll[llIIlIllllIlIl[8]] = GameSettings.class;
    llIIIlllIIllll[llIIlIllllIlIl[11]] = float.class;
    llIIIlllIIllll[llIIlIllllIlIl[10]] = boolean.class;
    llIIIlllIIllll[llIIlIllllIlIl[6]] = WorldClient.class;
    llIIIlllIIllll[llIIlIllllIlIl[4]] = f100000000000000000000.Boolean.class;
    llIIIlllIIllll[llIIlIllllIlIl[0]] = f13.class;
    llIIIlllIIllll[llIIlIllllIlIl[1]] = int.class;
    llIIIlllIIllll[llIIlIllllIlIl[5]] = Minecraft.class;
    llIIIlllIIllll[llIIlIllllIlIl[15]] = double.class;
    llIIIlllIIllll[llIIlIllllIlIl[3]] = f100000000000000000000.Double.class;
    llIIIlllIIllll[llIIlIllllIlIl[9]] = KeyBinding.class;
    llIIIlllIIllll[llIIlIllllIlIl[2]] = f100000000000000000000.Mode.class;
  }
  
  private static void lIIIlIIIIllIlIll() {
    llIIlIllllIIll = new String[llIIlIllllIlIl[58]];
    llIIlIllllIIll[llIIlIllllIlIl[0]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[0]], llIIlIllllIlII[llIIlIllllIlIl[1]]);
    llIIlIllllIIll[llIIlIllllIlIl[1]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[2]], llIIlIllllIlII[llIIlIllllIlIl[3]]);
    llIIlIllllIIll[llIIlIllllIlIl[2]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[4]], llIIlIllllIlII[llIIlIllllIlIl[5]]);
    llIIlIllllIIll[llIIlIllllIlIl[3]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[6]], llIIlIllllIlII[llIIlIllllIlIl[7]]);
    llIIlIllllIIll[llIIlIllllIlIl[4]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[8]], llIIlIllllIlII[llIIlIllllIlIl[9]]);
    llIIlIllllIIll[llIIlIllllIlIl[5]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[10]], llIIlIllllIlII[llIIlIllllIlIl[11]]);
    llIIlIllllIIll[llIIlIllllIlIl[6]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[12]], llIIlIllllIlII[llIIlIllllIlIl[15]]);
    llIIlIllllIIll[llIIlIllllIlIl[7]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[14]], llIIlIllllIlII[llIIlIllllIlIl[18]]);
    llIIlIllllIIll[llIIlIllllIlIl[8]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[16]], llIIlIllllIlII[llIIlIllllIlIl[21]]);
    llIIlIllllIIll[llIIlIllllIlIl[9]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[23]], llIIlIllllIlII[llIIlIllllIlIl[24]]);
    llIIlIllllIIll[llIIlIllllIlIl[10]] = lIIIlIIIIllIlIlI(llIIlIllllIlII[llIIlIllllIlIl[26]], llIIlIllllIlII[llIIlIllllIlIl[28]]);
    llIIlIllllIIll[llIIlIllllIlIl[11]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[29]], llIIlIllllIlII[llIIlIllllIlIl[20]]);
    llIIlIllllIIll[llIIlIllllIlIl[12]] = lIIIlIIIIllIlIIl(llIIlIllllIlII[llIIlIllllIlIl[30]], llIIlIllllIlII[llIIlIllllIlIl[32]]);
    llIIlIllllIIll[llIIlIllllIlIl[15]] = lIIIlIIIIllIlIlI(llIIlIllllIlII[llIIlIllllIlIl[33]], llIIlIllllIlII[llIIlIllllIlIl[34]]);
    llIIlIllllIIll[llIIlIllllIlIl[14]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[27]], llIIlIllllIlII[llIIlIllllIlIl[35]]);
    llIIlIllllIIll[llIIlIllllIlIl[18]] = lIIIlIIIIllIlIII(llIIlIllllIlII[llIIlIllllIlIl[36]], llIIlIllllIlII[llIIlIllllIlIl[37]]);
    llIIlIllllIIll[llIIlIllllIlIl[16]] = lIIIlIIIIllIlIII("PgQ1XCs5DyQRNDEHNVwlPAgkHDJ+BC8GLyQYbzcoJAg1CxY8ADgXNAMxexQvNQ0lLXFgVnFAGTITe0N3akFhUg==", "PaArF");
    llIIlIllllIIll[llIIlIllllIlIl[21]] = lIIIlIIIIllIlIIl("+D6RWxNNZUVhwk8CZVmn2YiCEE2vH+yySs5daLSui/lKzl1otK6L+UrOXWi0rov5sPYa8LRGxpGuu41HCRl0sw==", "GYfcQ");
    llIIlIllllIIll[llIIlIllllIlIl[23]] = lIIIlIIIIllIlIII("HAN9KTMEFjouIx4BfTgvAUg1K30CAycOLhwDIWBvN08FYGc=", "qfSZG");
    llIIlIllllIIll[llIIlIllllIlIl[24]] = lIIIlIIIIllIlIlI("EeRE4cV7C/eR4t5p5iRHwzNnrN476DNRQt7VoBZiHwwM6heVmiV+FXAzqDNJOguU5bA5r39D9j0=", "SoIaY");
    llIIlIllllIIll[llIIlIllllIlIl[26]] = lIIIlIIIIllIlIlI("cTsGWWyyBqwZRpl5nFNjNHKNjFWQ/wfH/tdAMBxos8FbnYYmuMSbSzA3oNr7chSFHAALGRHNu/jsMg16sfnc8g==", "PBrfV");
    llIIlIllllIIll[llIIlIllllIlIl[28]] = lIIIlIIIIllIlIlI("WzzbP9m8KoGyEo4/75kH+fwP3XFnXXbpFO/WgQ6/wBbWlgYAwsbt7a1plXdsLG+CaErXdYcGbUcbd2fdZk7o2SR6kW0nGIpXzjb5dH73QH5MQW+WYU2OzyPyBXTz/pWALmGjdLVLkAa9Vdh/+0iJWZpBazHmjaYHyLV+wn5eRH/AOpznfMAKqDTLPGcF107PQe90ZS+gvtA=", "XHiED");
    llIIlIllllIIll[llIIlIllllIlIl[29]] = lIIIlIIIIllIlIII("CCIwYjcPKSEvKAchMGI5Ci4hIi5ICi0iPwU1JSouXCEtKTYCGHN9blFzGzVgXn1kbHo=", "fGDLZ");
    llIIlIllllIIll[llIIlIllllIlIl[20]] = lIIIlIIIIllIlIII("IQp2Ehg5HzEVCCMIdgMEPEE+UFx8X2hRXHxfaFFcfF9oUVx8X2hRXHxfaFFcfF9oWxglAj0TVnhVeEFM", "LoXal");
    llIIlIllllIIll[llIIlIllllIlIl[30]] = lIIIlIIIIllIlIII("HDU8FGcaNSQSZyUgOBwnEW4vBDwXODk8Lhg7OBAKFycvT2E6PisDKFk4KxsuWQc+ByAYM3FcE0x0ag==", "vTJuI");
    llIIlIllllIIll[llIIlIllllIlIl[32]] = lIIIlIIIIllIlIII("KyhGPjwzPQE5LCkqRi8gNmMOfHh2fVh9eHZ9WH14dn1YfXh2fVh9bAIiHS8kI3cPKDwQLAQ4LXxlQQlyZm0=", "FMhMH");
    llIIlIllllIIll[llIIlIllllIlIl[33]] = lIIIlIIIIllIlIII("CS1GMAEROAE3EQsvRiEdFGYOckVUeFhzRVR4WHNFVHhYc0VUeFhzRVR4WHNFVHhYeQcBLwEwAQE6KiwaCC0JLU9MBAIiAwVnBCIbA2c7NwcNJg94L00EBSZaFzwdMxwQLAckWgYgGGwTVXhYc0VUeFhzRVR4WHNFVHhYc0VUbCosGggtCS1OXmhI", "dHhCu");
    llIIlIllllIIll[llIIlIllllIlIl[34]] = lIIIlIIIIllIlIlI("4lsElCBMLQ5GqgYVHgkJAwkXkIllbPpTw7uqDpfMX/PDu6oOl8xf88O7qg6XzF/z3ZkuItlpxuh/lIxKZoIQkg==", "ZJmNq");
    llIIlIllllIIll[llIIlIllllIlIl[27]] = lIIIlIIIIllIlIIl("QJMuIFN7RD5R3AyA+uX8sCWHI1NZW0tSJ5sNT7iq/5whWcCyRzRQNcN2qWaqcgNWfKTMi+TXVaLO3h084yFAuM0I2phro/snMP8ATbg33PhPSvDZc80ZEPJBNuIBN5q/o7L6jSt6gLo=", "urqIg");
    llIIlIllllIIll[llIIlIllllIlIl[35]] = lIIIlIIIIllIlIIl("wsCD6QnpeVYhzvWfS4zqxEgco2pJw/9bYGEUlbZkpXStvic7DE90i7tXNzK5WHukLXEnNaW6wu9LYMoDGj5lrden8cjKqchAxdeB555C+IPbTpIpSXf2JSLZxFBKmDoUgSUWZ6INpOI=", "oeDoe");
    llIIlIllllIIll[llIIlIllllIlIl[36]] = lIIIlIIIIllIlIII("Gy8/IF8EOiAtXz0nOjVLGD0MLAEFN3NpWCt0aWE=", "qNIAq");
    llIIlIllllIIll[llIIlIllllIlIl[37]] = lIIIlIIIIllIlIIl("e4ICJMJ1n3A+Mlvi7Cf17TN2jFJuYnsE0PbM8J33/ClM/ASiDWAOeQ==", "IImcy");
    llIIlIllllIIll[llIIlIllllIlIl[19]] = lIIIlIIIIllIlIlI("lPcHk9JN/0cgDfuGz7N2hsfBlkJ+8FcbTkENgZhhgxxOQQ2BmGGDHE5BDYGYYYMc8IN1uFqduuLygE9NUPlFag==", "fwuYY");
    llIIlIllllIIll[llIIlIllllIlIl[38]] = lIIIlIIIIllIlIIl("AKyswzlsXrdG5dUsntSmBjDcxH8FgxNwnwr7zKwIgzN6wAt5sTmBtzXl2X6w/CpUkn4RbZdJh5uWJ+NIGeHmAnl3mta65Aec", "JTHYF");
    llIIlIllllIIll[llIIlIllllIlIl[39]] = lIIIlIIIIllIlIlI("UnLAqnKEQXqCpjd1Q1sPsw3zxr17FuSSq1uUXp3hUPWrW5ReneFQ9atblF6d4VD15BsbRdxCULdOdKk/NvlmhQ==", "ufdpk");
    llIIlIllllIIll[llIIlIllllIlIl[31]] = lIIIlIIIIllIlIlI("y+j8jUyv7EwckgL13KiHD/6PqqJOgNB6Op4DuBbov+M6ngO4Fui/4zqeA7gW6L/jIVzPct8pGT++ZdoZ8kdE4A==", "lqOMp");
    llIIlIllllIIll[llIIlIllllIlIl[17]] = lIIIlIIIIllIlIII("OSMjQjk+KDIPJjYgI0I3Oy8yAiB5NTIYID4oMB96HCMuLj05Ij4CM20gIgI3CHdiXWBgdggIbn9vDVZ0dw==", "WFWlT");
    llIIlIllllIIll[llIIlIllllIlIl[41]] = lIIIlIIIIllIlIIl("5iBl0nPxS91wQ1tJDe7qQxMlp1BB6J9aG791FX0UWmXzjGfCilOPryV2W0iFJrCvMuXXjREDNze1euBj5DyHirHpG0CKKtoA0VAqUUSwXOyHlpKkJtHmv2NVre3ZoqKoa844e4jio04=", "JJebu");
    llIIlIllllIIll[llIIlIllllIlIl[25]] = lIIIlIIIIllIlIlI("5htlDpDO2SELMfQWGZgtHyn2LGnjpgoHx6MrX/Y+bTdwSWAC+O+DLr9M04DFWdWUm5VA6goaZJI=", "uJRHl");
    llIIlIllllIIll[llIIlIllllIlIl[42]] = lIIIlIIIIllIlIlI("axPl6k5rubHevsDvs8VUdxs5r68SaFC5kCxNKcXjyD6QLE0pxePIPpAsTSnF48g+Udf9nfIFXMotmpFm3r8AN+CogUzqQM1NlK47lE1Ktq3I8mReJQXlDjeZ1JQMqdSfMPRR4bsnbcBBG/lD2+KIVpAsTSnF48g+Ay0Y3t4bXgfz4jQMMpvH7XdbsJ+9aacO", "NiRDb");
    llIIlIllllIIll[llIIlIllllIlIl[40]] = lIIIlIIIIllIlIlI("68sQGAPDzaIpMKpvjCuG4IIuqtU4qDONBF5xjbkdLhcCP4Fq75nj0w==", "obbeJ");
    llIIlIllllIIll[llIIlIllllIlIl[22]] = lIIIlIIIIllIlIII("Hi4OViwZJR8bMxEtDlYiHCIfFjVeLhQMKAQyVD0vBCIOAREcKgMdMyMbQB4oFSceJ3ZAekhKHjVxS0h7UGta", "pKzxA");
    llIIlIllllIIll[llIIlIllllIlIl[43]] = lIIIlIIIIllIlIIl("aiUB+5MCAhdGU9jepFyb5NwHAp6fNCiApiiTySqpf9/MLT8er7/b7AGLjkmthA+wEMS9qbtiq/8=", "eGRTy");
    llIIlIllllIIll[llIIlIllllIlIl[44]] = lIIIlIIIIllIlIlI("N0o5yOQoPRPgMMKgnInaoYvdU0ssOFsc9sbAcGEdVkLFfdUDO6umomWhjTnPdhaognWkwnxqLNzfDhVE/ekNCnVyHVk/CAS2ORONVUzle4Y=", "TARUz");
    llIIlIllllIIll[llIIlIllllIlIl[45]] = lIIIlIIIIllIlIIl("JCTtWt0+1S/nmyMDf5xZcXRcD3KcuwRraIhEjdIpsNANTrnZPvDknyWxV/v21Qyj1WpPbD3luLtwMLKQdQnyGg==", "UXSOW");
    llIIlIllllIIll[llIIlIllllIlIl[13]] = lIIIlIIIIllIlIlI("3ibXYvEmixzTZKRl9+H5fzH+U58R7RraitHqyxm7zcyK0erLGbvNzIrR6ssZu83MuRrlQeceChitLtgBJmxy8w==", "tjqbB");
    llIIlIllllIIll[llIIlIllllIlIl[46]] = lIIIlIIIIllIlIII("ICk8Wi4nIi0XMS8qPFogIiUtGjdgKSYAKjo1ZjEtOiU8DRMiLTERMR0cchIqKyAsK3R+fX5BHDp2eUd5bmxo", "NLHtC");
    llIIlIllllIIll[llIIlIllllIlIl[47]] = lIIIlIIIIllIlIII("DCsOWQILIB8UHQMoDlkMDicfGRtMKxQDBhY3VDIBFicODj8OLwMSHTEeQBEaDC0lQF9Tfk0oDVhmPjMrSxhAV08=", "bNzwo");
    llIIlIllllIIll[llIIlIllllIlIl[48]] = lIIIlIIIIllIlIIl("I2OSeC5IkH7raOtQbejO2TbafaljMAaSO8Dln7vggN/qnEqwF9dGdDxP4ES5rWqEZqjaspqXGtz2w9mjc17+8A==", "xmAJy");
    llIIlIllllIIll[llIIlIllllIlIl[49]] = lIIIlIIIIllIlIII("DzBPKzMXJQgsIw0yTzovEnsAL30EOhMvJhAxW3ADSw4lYmc=", "bUaXG");
    llIIlIllllIIll[llIIlIllllIlIl[50]] = lIIIlIIIIllIlIIl("A6LiKz+OYQVPaDB/Uaj/P0Zvp2okzlLg9Xo12QVjrxWTB7maluaOm7DAhghTfM46EpYlaCXjvO3Ke4NYzWp2yw==", "Nggbf");
    llIIlIllllIIll[llIIlIllllIlIl[51]] = lIIIlIIIIllIlIIl("/p9ie9w6C9dIOqtHQuaYKGUZ1FqTlTVGjh61n7Ci5eyOHrWfsKLl7I4etZ+wouXsLOMgzDVmAdVeHeKZjoH5QHnJymCLNmF1ekYf8eJD+Uq43l9ALNyH/2ex4hJd1ZQvnvdq1stAE+PH/ASw6728pflVE3ljuNY/owIzKkQRSqMengdvaCvriI4etZ+wouXsjh61n7Ci5eyJ0VkbpE1kItLuMVLcUG3r", "FedGE");
    llIIlIllllIIll[llIIlIllllIlIl[52]] = lIIIlIIIIllIlIlI("fwszgxqKVUbhRAGVSQzSX2HuYB6Cask43taCH4qd/8He1oIfip3/wd7Wgh+Knf/BT712g6ctdHqQF0PdaDfiYQ==", "pPfyT");
    llIIlIllllIIll[llIIlIllllIlIl[53]] = lIIIlIIIIllIlIlI("sNCwqoPVxyAM9QaB+pVFW+De5fVuTA8Soy9fv5dJVPCjL1+/l0lU8KMvX7+XSVTwL310rWwXP0GXagdOdugpNA==", "CGiBn");
    llIIlIllllIIll[llIIlIllllIlIl[54]] = lIIIlIIIIllIlIlI("68fsOLWBE3pebifRmceseuooQeW9HedXjm0b5kl7bQ+Kc7Sa67YUtVV+WVEUFM1bfDEL60so0MkD9RlP5CfdWcXSxbcUGPG8", "mqqZf");
    llIIlIllllIIll[llIIlIllllIlIl[55]] = lIIIlIIIIllIlIlI("6DI1UoT+pTAPIBt8g/2o+34YoAbKTbQIT2WFya+QYTipUETRaUXnBKu1+4e9DpYZNZuxrZPJCUk=", "rUGOS");
    llIIlIllllIIll[llIIlIllllIlIl[56]] = lIIIlIIIIllIlIlI("L7dJyDlG4yKwgWtXRY+yfMSGr7wDFQsx2EOW9lMeGj4SRkYf57ZNB7TsFDnLFAW9hxyQHl5uUV1+AwpIZrKwCw==", "kYMpS");
    llIIlIllllIIll[llIIlIllllIlIl[57]] = lIIIlIIIIllIlIlI("PFqZOXu17dGGmsnUZdNOI1O4ntC0t0Z2ErokRVo11Nw0tGmyNZWvGRQ9W6wPAqJaaQdLLTWqXE4=", "HiTNk");
    llIIlIllllIlII = null;
  }
  
  private static void lIIIlIIIIllIllII() {
    String str = (new Exception()).getStackTrace()[llIIlIllllIlIl[0]].getFileName();
    llIIlIllllIlII = str.substring(str.indexOf("ä") + llIIlIllllIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIIllIlIIl(String lllllllllllllllIllIIIlllIIlIIlll, String lllllllllllllllIllIIIlllIIlIIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIIlIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIIlIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIlllIIlIlIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIlllIIlIlIIl.init(llIIlIllllIlIl[2], lllllllllllllllIllIIIlllIIlIlIlI);
      return new String(lllllllllllllllIllIIIlllIIlIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIIlIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIIlIlIII) {
      lllllllllllllllIllIIIlllIIlIlIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIllIlIlI(String lllllllllllllllIllIIIlllIIlIIIlI, String lllllllllllllllIllIIIlllIIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIIlIIIIl.getBytes(StandardCharsets.UTF_8)), llIIlIllllIlIl[8]), "DES");
      Cipher lllllllllllllllIllIIIlllIIlIIlII = Cipher.getInstance("DES");
      lllllllllllllllIllIIIlllIIlIIlII.init(llIIlIllllIlIl[2], lllllllllllllllIllIIIlllIIlIIlIl);
      return new String(lllllllllllllllIllIIIlllIIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIIlIIIll) {
      lllllllllllllllIllIIIlllIIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIllIlIII(String lllllllllllllllIllIIIlllIIIlllll, String lllllllllllllllIllIIIlllIIIllllI) {
    lllllllllllllllIllIIIlllIIIlllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIIIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIlllIIIlllIl = new StringBuilder();
    char[] lllllllllllllllIllIIIlllIIIlllII = lllllllllllllllIllIIIlllIIIllllI.toCharArray();
    int lllllllllllllllIllIIIlllIIIllIll = llIIlIllllIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIlllIIIlllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIllllIlIl[0];
    while (lIIIlIIIIlllIlIl(j, i)) {
      char lllllllllllllllIllIIIlllIIlIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIlllIIIllIll++;
      j++;
      "".length();
      if (-" ".length() > " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIlllIIIlllIl);
  }
  
  private static void lIIIlIIIIllIllIl() {
    llIIlIllllIlIl = new int[59];
    llIIlIllllIlIl[0] = (0xE0 ^ 0xB5) & (0xFE ^ 0xAB ^ 0xFFFFFFFF);
    llIIlIllllIlIl[1] = " ".length();
    llIIlIllllIlIl[2] = " ".length() << " ".length();
    llIIlIllllIlIl[3] = "   ".length();
    llIIlIllllIlIl[4] = " ".length() << " ".length() << " ".length();
    llIIlIllllIlIl[5] = 0x36 ^ 0x33;
    llIIlIllllIlIl[6] = "   ".length() << " ".length();
    llIIlIllllIlIl[7] = (0x9 ^ 0x5C) << " ".length() ^ 11 + 50 - -61 + 51;
    llIIlIllllIlIl[8] = " ".length() << "   ".length();
    llIIlIllllIlIl[9] = (0x1F ^ 0x22) << " ".length() ^ 0xDE ^ 0xAD;
    llIIlIllllIlIl[10] = (0xA9 ^ 0xAC) << " ".length();
    llIIlIllllIlIl[11] = 0x0 ^ 0x35 ^ (0x41 ^ 0x5E) << " ".length();
    llIIlIllllIlIl[12] = "   ".length() << " ".length() << " ".length();
    llIIlIllllIlIl[13] = 0xAD ^ 0x80;
    llIIlIllllIlIl[14] = ((0xFE ^ 0xB3) << " ".length() ^ 92 + 38 - 121 + 148) << " ".length();
    llIIlIllllIlIl[15] = (0x38 ^ 0x27) << " ".length() << " ".length() ^ 0x74 ^ 0x5;
    llIIlIllllIlIl[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIllllIlIl[17] = (0x5F ^ 0x56) << " ".length() << " ".length();
    llIIlIllllIlIl[18] = 0xBA ^ 0xB5;
    llIIlIllllIlIl[19] = " ".length() << ((0x43 ^ 0x0) << " ".length() ^ 64 + 78 - 97 + 86);
    llIIlIllllIlIl[20] = (0x1E ^ 0x59) << " ".length() ^ 5 + 131 - 60 + 77;
    llIIlIllllIlIl[21] = 0xBD ^ 0xAC;
    llIIlIllllIlIl[22] = 0x33 ^ 0x1A;
    llIIlIllllIlIl[23] = (0x36 ^ 0x5 ^ (0x1C ^ 0x1) << " ".length()) << " ".length();
    llIIlIllllIlIl[24] = 0x9E ^ 0x8D;
    llIIlIllllIlIl[25] = (93 + 99 - 109 + 68 ^ (0xC ^ 0x2D) << " ".length() << " ".length()) << " ".length();
    llIIlIllllIlIl[26] = (0x7C ^ 0x79) << " ".length() << " ".length();
    llIIlIllllIlIl[27] = (0x26 ^ 0x21) << " ".length() << " ".length();
    llIIlIllllIlIl[28] = 0x34 ^ 0x21;
    llIIlIllllIlIl[29] = (0x84 ^ 0x8F) << " ".length();
    llIIlIllllIlIl[30] = "   ".length() << "   ".length();
    llIIlIllllIlIl[31] = 0x8 ^ 0x2B;
    llIIlIllllIlIl[32] = 0x2D ^ 0x34;
    llIIlIllllIlIl[33] = ((0x5A ^ 0x73) << " ".length() ^ 0x39 ^ 0x66) << " ".length();
    llIIlIllllIlIl[34] = 0xA3 ^ 0xB8;
    llIIlIllllIlIl[35] = 0x40 ^ 0x5D;
    llIIlIllllIlIl[36] = (0x69 ^ 0x66) << " ".length();
    llIIlIllllIlIl[37] = 0x50 ^ 0x4F;
    llIIlIllllIlIl[38] = 0x4C ^ 0xB ^ (0x58 ^ 0x6B) << " ".length();
    llIIlIllllIlIl[39] = (0x37 ^ 0x40 ^ (0x51 ^ 0x62) << " ".length()) << " ".length();
    llIIlIllllIlIl[40] = ((0x67 ^ 0x5A) << " ".length() ^ 74 + 82 - 63 + 34) << "   ".length();
    llIIlIllllIlIl[41] = 0x90 ^ 0xB5;
    llIIlIllllIlIl[42] = 0x74 ^ 0x53;
    llIIlIllllIlIl[43] = (0x38 ^ 0x2D) << " ".length();
    llIIlIllllIlIl[44] = 0xD ^ 0x26;
    llIIlIllllIlIl[45] = (74 + 153 - 186 + 130 ^ (0x73 ^ 0x76) << (0x17 ^ 0x12)) << " ".length() << " ".length();
    llIIlIllllIlIl[46] = (0x22 ^ 0x73 ^ (0xE6 ^ 0xC5) << " ".length()) << " ".length();
    llIIlIllllIlIl[47] = (0x92 ^ 0x9B) << " ".length() << " ".length() ^ 0x9 ^ 0x2;
    llIIlIllllIlIl[48] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIlIllllIlIl[49] = 0x93 ^ 0xA2;
    llIIlIllllIlIl[50] = (133 + 26 - 32 + 58 ^ (0xA0 ^ 0xA5) << (0x83 ^ 0x86)) << " ".length();
    llIIlIllllIlIl[51] = (0xBA ^ 0x95) << " ".length() << " ".length() ^ 26 + 62 - 75 + 130;
    llIIlIllllIlIl[52] = (" ".length() << (0x4C ^ 0x4B) ^ 25 + 26 - 19 + 109) << " ".length() << " ".length();
    llIIlIllllIlIl[53] = (0x29 ^ 0x16) << " ".length() ^ 0x2D ^ 0x66;
    llIIlIllllIlIl[54] = ((0x5C ^ 0x67) << " ".length() ^ 0xD2 ^ 0xBF) << " ".length();
    llIIlIllllIlIl[55] = (0x17 ^ 0x1A) << " ".length() << " ".length() ^ "   ".length();
    llIIlIllllIlIl[56] = ((0x1 ^ 0x50) << " ".length() ^ 129 + 82 - 60 + 14) << "   ".length();
    llIIlIllllIlIl[57] = 0xE5 ^ 0x82 ^ (0x68 ^ 0x47) << " ".length();
    llIIlIllllIlIl[58] = ((0x85 ^ 0x82) << " ".length() << " ".length() << " ".length() ^ 0x4C ^ 0x21) << " ".length();
  }
  
  private static boolean lIIIlIIIIlllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIIlllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIIlllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIIIlllIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIlIIIIlllIIIl(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIlIIIIlllIIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIlIIIIlllIIlI(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIlIIIIlllIlII(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static int lIIIlIIIIllIlllI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIlIIIIllIllll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */