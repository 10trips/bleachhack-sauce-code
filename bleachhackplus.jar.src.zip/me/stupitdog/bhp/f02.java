package me.stupitdog.bhp;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.settings.KeybindComponent;
import com.lukflug.panelstudio.settings.KeybindSetting;
import com.lukflug.panelstudio.theme.Renderer;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class f02 extends KeybindComponent {
  private static String[] lIlllllIllllII;
  
  private static Class[] lIlllllIllllIl;
  
  private static final String[] lIllllllIIIlII;
  
  private static String[] lIllllllIIIlIl;
  
  private static final int[] lIllllllIIIllI;
  
  public f02(Renderer lllllllllllllllIlllIIIIIlIIIlIII, KeybindSetting lllllllllllllllIlllIIIIIlIIIIlll) {
    super(lllllllllllllllIlllIIIIIlIIIlIII, lllllllllllllllIlllIIIIIlIIIIlll);
  }
  
  public void handleKey(Context lllllllllllllllIlllIIIIIlIIIIlIl, int lllllllllllllllIlllIIIIIlIIIIlII) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: <illegal opcode> 0 : (Lme/stupitdog/bhp/f02;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   7: getstatic me/stupitdog/bhp/f02.lIllllllIIIllI : [I
    //   10: iconst_0
    //   11: iaload
    //   12: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   17: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;I)V
    //   22: aload_0
    //   23: aload_1
    //   24: <illegal opcode> 3 : (Lme/stupitdog/bhp/f02;Lcom/lukflug/panelstudio/Context;)Z
    //   29: invokestatic lIIIIIIIIIlIllll : (I)Z
    //   32: ifeq -> 82
    //   35: iload_2
    //   36: getstatic me/stupitdog/bhp/f02.lIllllllIIIllI : [I
    //   39: iconst_1
    //   40: iaload
    //   41: invokestatic lIIIIIIIIIllIIII : (II)Z
    //   44: ifeq -> 59
    //   47: iload_2
    //   48: getstatic me/stupitdog/bhp/f02.lIllllllIIIllI : [I
    //   51: iconst_2
    //   52: iaload
    //   53: invokestatic lIIIIIIIIIllIIIl : (II)Z
    //   56: ifeq -> 82
    //   59: aload_0
    //   60: <illegal opcode> 4 : (Lme/stupitdog/bhp/f02;)Lcom/lukflug/panelstudio/settings/KeybindSetting;
    //   65: getstatic me/stupitdog/bhp/f02.lIllllllIIIllI : [I
    //   68: iconst_0
    //   69: iaload
    //   70: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/KeybindSetting;I)V
    //   75: aload_0
    //   76: <illegal opcode> 6 : (Lme/stupitdog/bhp/f02;)V
    //   81: return
    //   82: aload_0
    //   83: aload_1
    //   84: iload_2
    //   85: invokespecial handleKey : (Lcom/lukflug/panelstudio/Context;I)V
    //   88: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	89	0	lllllllllllllllIlllIIIIIlIIIIllI	Lme/stupitdog/bhp/f02;
    //   0	89	1	lllllllllllllllIlllIIIIIlIIIIlIl	Lcom/lukflug/panelstudio/Context;
    //   0	89	2	lllllllllllllllIlllIIIIIlIIIIlII	I
  }
  
  static {
    lIIIIIIIIIlIllIl();
    lIIIIIIIIIlIlIll();
    lIIIIIIIIIlIlIlI();
    lIIIIIIIIIlIIlIl();
  }
  
  private static CallSite lIIIIIIIIIIlIllI(MethodHandles.Lookup lllllllllllllllIlllIIIIIIllllIll, String lllllllllllllllIlllIIIIIIllllIlI, MethodType lllllllllllllllIlllIIIIIIllllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIIIlIIIIIIl = lIlllllIllllII[Integer.parseInt(lllllllllllllllIlllIIIIIIllllIlI)].split(lIllllllIIIlII[lIllllllIIIllI[0]]);
      Class<?> lllllllllllllllIlllIIIIIlIIIIIII = Class.forName(lllllllllllllllIlllIIIIIlIIIIIIl[lIllllllIIIllI[0]]);
      String lllllllllllllllIlllIIIIIIlllllll = lllllllllllllllIlllIIIIIlIIIIIIl[lIllllllIIIllI[3]];
      MethodHandle lllllllllllllllIlllIIIIIIllllllI = null;
      int lllllllllllllllIlllIIIIIIlllllIl = lllllllllllllllIlllIIIIIlIIIIIIl[lIllllllIIIllI[4]].length();
      if (lIIIIIIIIIllIIlI(lllllllllllllllIlllIIIIIIlllllIl, lIllllllIIIllI[5])) {
        MethodType lllllllllllllllIlllIIIIIlIIIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIIIlIIIIIIl[lIllllllIIIllI[5]], f02.class.getClassLoader());
        if (lIIIIIIIIIllIIIl(lllllllllllllllIlllIIIIIIlllllIl, lIllllllIIIllI[5])) {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findVirtual(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIll);
          "".length();
          if (" ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findStatic(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIll);
        } 
        "".length();
        if (" ".length() == "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIIIlIIIIIlI = lIlllllIllllIl[Integer.parseInt(lllllllllllllllIlllIIIIIlIIIIIIl[lIllllllIIIllI[5]])];
        if (lIIIIIIIIIllIIIl(lllllllllllllllIlllIIIIIIlllllIl, lIllllllIIIllI[4])) {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findGetter(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIlI);
          "".length();
          if ("   ".length() >= " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIIIIllIIIl(lllllllllllllllIlllIIIIIIlllllIl, lIllllllIIIllI[6])) {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findStaticGetter(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIIIIllIIIl(lllllllllllllllIlllIIIIIIlllllIl, lIllllllIIIllI[7])) {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findSetter(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIlI);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIllllllI = lllllllllllllllIlllIIIIIIllllIll.findStaticSetter(lllllllllllllllIlllIIIIIlIIIIIII, lllllllllllllllIlllIIIIIIlllllll, lllllllllllllllIlllIIIIIlIIIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIIIIllllllI);
    } catch (Exception lllllllllllllllIlllIIIIIIlllllII) {
      lllllllllllllllIlllIIIIIIlllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIIlIIlIl() {
    lIlllllIllllII = new String[lIllllllIIIllI[8]];
    lIlllllIllllII[lIllllllIIIllI[3]] = lIllllllIIIlII[lIllllllIIIllI[3]];
    lIlllllIllllII[lIllllllIIIllI[6]] = lIllllllIIIlII[lIllllllIIIllI[5]];
    lIlllllIllllII[lIllllllIIIllI[5]] = lIllllllIIIlII[lIllllllIIIllI[4]];
    lIlllllIllllII[lIllllllIIIllI[9]] = lIllllllIIIlII[lIllllllIIIllI[6]];
    lIlllllIllllII[lIllllllIIIllI[7]] = lIllllllIIIlII[lIllllllIIIllI[7]];
    lIlllllIllllII[lIllllllIIIllI[4]] = lIllllllIIIlII[lIllllllIIIllI[9]];
    lIlllllIllllII[lIllllllIIIllI[0]] = lIllllllIIIlII[lIllllllIIIllI[8]];
    lIlllllIllllIl = new Class[lIllllllIIIllI[5]];
    lIlllllIllllIl[lIllllllIIIllI[3]] = KeybindSetting.class;
    lIlllllIllllIl[lIllllllIIIllI[0]] = Renderer.class;
  }
  
  private static void lIIIIIIIIIlIlIlI() {
    lIllllllIIIlII = new String[lIllllllIIIllI[10]];
    lIllllllIIIlII[lIllllllIIIllI[0]] = lIIIIIIIIIlIIllI(lIllllllIIIlIl[lIllllllIIIllI[0]], lIllllllIIIlIl[lIllllllIIIllI[3]]);
    lIllllllIIIlII[lIllllllIIIllI[3]] = lIIIIIIIIIlIlIII(lIllllllIIIlIl[lIllllllIIIllI[5]], lIllllllIIIlIl[lIllllllIIIllI[4]]);
    lIllllllIIIlII[lIllllllIIIllI[5]] = lIIIIIIIIIlIlIIl(lIllllllIIIlIl[lIllllllIIIllI[6]], lIllllllIIIlIl[lIllllllIIIllI[7]]);
    lIllllllIIIlII[lIllllllIIIllI[4]] = lIIIIIIIIIlIIllI(lIllllllIIIlIl[lIllllllIIIllI[9]], lIllllllIIIlIl[lIllllllIIIllI[8]]);
    lIllllllIIIlII[lIllllllIIIllI[6]] = lIIIIIIIIIlIlIIl(lIllllllIIIlIl[lIllllllIIIllI[10]], lIllllllIIIlIl[lIllllllIIIllI[11]]);
    lIllllllIIIlII[lIllllllIIIllI[7]] = lIIIIIIIIIlIIllI(lIllllllIIIlIl[lIllllllIIIllI[12]], lIllllllIIIlIl[lIllllllIIIllI[13]]);
    lIllllllIIIlII[lIllllllIIIllI[9]] = lIIIIIIIIIlIIllI("83Bn4ZQlTAa2AOW5WE8CES6TftdmHJHksgsX6Q6xm4gtNM8bLQNlvUxSm4Dxf8AtNkIsC+1CPnN1LYJUeud6Pi3Da/RvQn1R", "IClXo");
    lIllllllIIIlII[lIllllllIIIllI[8]] = lIIIIIIIIIlIlIII("JiJcGDc+NxsfJyQgXAkrO2kUW3FxNRcFJy41Fxl5e31SS2M=", "KGrkC");
    lIllllllIIIlIl = null;
  }
  
  private static void lIIIIIIIIIlIlIll() {
    String str = (new Exception()).getStackTrace()[lIllllllIIIllI[0]].getFileName();
    lIllllllIIIlIl = str.substring(str.indexOf("ä") + lIllllllIIIllI[3], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIIIlIIllI(String lllllllllllllllIlllIIIIIIlllIlIl, String lllllllllllllllIlllIIIIIIlllIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIllllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIlllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIIIIlllIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIIIIlllIlll.init(lIllllllIIIllI[5], lllllllllllllllIlllIIIIIIllllIII);
      return new String(lllllllllllllllIlllIIIIIIlllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIlllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIlllIllI) {
      lllllllllllllllIlllIIIIIIlllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIIlIlIII(String lllllllllllllllIlllIIIIIIlllIIlI, String lllllllllllllllIlllIIIIIIlllIIIl) {
    lllllllllllllllIlllIIIIIIlllIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIlllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIIIIlllIIII = new StringBuilder();
    char[] lllllllllllllllIlllIIIIIIllIllll = lllllllllllllllIlllIIIIIIlllIIIl.toCharArray();
    int lllllllllllllllIlllIIIIIIllIlllI = lIllllllIIIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIIIIlllIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllllIIIllI[0];
    while (lIIIIIIIIIllIIll(j, i)) {
      char lllllllllllllllIlllIIIIIIlllIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIIIIllIlllI++;
      j++;
      "".length();
      if ((((0x78 ^ 0x7D) << (0xAE ^ 0xAB) ^ 63 + 48 - 7 + 47) & ((0x77 ^ 0x72) << (0x85 ^ 0x80) ^ 14 + 122 - 74 + 89 ^ -" ".length())) > ("   ".length() & ("   ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIIIIlllIIII);
  }
  
  private static String lIIIIIIIIIlIlIIl(String lllllllllllllllIlllIIIIIIllIlIlI, String lllllllllllllllIlllIIIIIIllIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIllIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIllIlIIl.getBytes(StandardCharsets.UTF_8)), lIllllllIIIllI[10]), "DES");
      Cipher lllllllllllllllIlllIIIIIIllIllII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIIIIllIllII.init(lIllllllIIIllI[5], lllllllllllllllIlllIIIIIIllIllIl);
      return new String(lllllllllllllllIlllIIIIIIllIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIllIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIllIlIll) {
      lllllllllllllllIlllIIIIIIllIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIIlIllIl() {
    lIllllllIIIllI = new int[14];
    lIllllllIIIllI[0] = (0x32 ^ 0x25) & (0x18 ^ 0xF ^ 0xFFFFFFFF);
    lIllllllIIIllI[1] = 105 + 15 - -48 + 43;
    lIllllllIIIllI[2] = ((0xA0 ^ 0x8B) << " ".length() << " ".length() ^ 90 + 155 - 74 + 0) << " ".length();
    lIllllllIIIllI[3] = " ".length();
    lIllllllIIIllI[4] = "   ".length();
    lIllllllIIIllI[5] = " ".length() << " ".length();
    lIllllllIIIllI[6] = " ".length() << " ".length() << " ".length();
    lIllllllIIIllI[7] = 0x7C ^ 0x79;
    lIllllllIIIllI[8] = 0xAF ^ 0xA8;
    lIllllllIIIllI[9] = "   ".length() << " ".length();
    lIllllllIIIllI[10] = " ".length() << "   ".length();
    lIllllllIIIllI[11] = 0x41 ^ 0x52 ^ (0x90 ^ 0x9D) << " ".length();
    lIllllllIIIllI[12] = (0x94 ^ 0x91) << " ".length();
    lIllllllIIIllI[13] = 0x51 ^ 0x5A;
  }
  
  private static boolean lIIIIIIIIIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIIIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIIIlIllll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIIIIllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f02.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */