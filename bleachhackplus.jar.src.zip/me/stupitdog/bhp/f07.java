package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumHand;

public class f07 extends au {
  f100000000000000000000.Double speed;
  
  f100000000000000000000.Double ySpeed;
  
  public static f100000000000000000000.Mode mode;
  
  public static f100000000000000000000.Mode yawMode;
  
  f100000000000000000000.Boolean rubberband;
  
  f100000000000000000000.Integer offset;
  
  @EventHandler
  private Listener<f100000000000000> onTravel;
  
  @EventHandler
  private Listener<f100> onClientPacket;
  
  @EventHandler
  private Listener<f100> onServerPacket;
  
  private static String[] lIllIllIlIIIIl;
  
  private static Class[] lIllIllIlIIIlI;
  
  private static final String[] lIlllIIIIllllI;
  
  private static String[] lIlllIIIlIIIlI;
  
  private static final int[] lIlllIIIlIIIll;
  
  public f07() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: aload_0
    //   47: <illegal opcode> invoke : (Lme/stupitdog/bhp/f07;)Lme/zero/alpine/listener/EventHook;
    //   52: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   55: iconst_0
    //   56: iaload
    //   57: anewarray java/util/function/Predicate
    //   60: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   63: <illegal opcode> 1 : (Lme/stupitdog/bhp/f07;Lme/zero/alpine/listener/Listener;)V
    //   68: aload_0
    //   69: new me/zero/alpine/listener/Listener
    //   72: dup
    //   73: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   78: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   81: iconst_0
    //   82: iaload
    //   83: anewarray java/util/function/Predicate
    //   86: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   89: <illegal opcode> 2 : (Lme/stupitdog/bhp/f07;Lme/zero/alpine/listener/Listener;)V
    //   94: aload_0
    //   95: new me/zero/alpine/listener/Listener
    //   98: dup
    //   99: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   104: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   107: iconst_0
    //   108: iaload
    //   109: anewarray java/util/function/Predicate
    //   112: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   115: <illegal opcode> 3 : (Lme/stupitdog/bhp/f07;Lme/zero/alpine/listener/Listener;)V
    //   120: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	121	0	lllllllllllllllIlllIllllllIlIlll	Lme/stupitdog/bhp/f07;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_1
    //   51: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   54: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   57: iconst_5
    //   58: iaload
    //   59: aaload
    //   60: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   65: ldc ''
    //   67: invokevirtual length : ()I
    //   70: pop2
    //   71: new java/util/ArrayList
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore_2
    //   79: aload_2
    //   80: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   83: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   86: bipush #6
    //   88: iaload
    //   89: aaload
    //   90: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   95: ldc ''
    //   97: invokevirtual length : ()I
    //   100: pop2
    //   101: aload_2
    //   102: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   105: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   108: bipush #7
    //   110: iaload
    //   111: aaload
    //   112: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   117: ldc ''
    //   119: invokevirtual length : ()I
    //   122: pop2
    //   123: aload_2
    //   124: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   127: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   130: bipush #8
    //   132: iaload
    //   133: aaload
    //   134: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   139: ldc ''
    //   141: invokevirtual length : ()I
    //   144: pop2
    //   145: aload_2
    //   146: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   149: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   152: bipush #9
    //   154: iaload
    //   155: aaload
    //   156: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   161: ldc ''
    //   163: invokevirtual length : ()I
    //   166: pop2
    //   167: aload_0
    //   168: aload_0
    //   169: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   172: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   175: bipush #10
    //   177: iaload
    //   178: aaload
    //   179: ldc2_w 2.0
    //   182: dconst_0
    //   183: ldc2_w 5.0
    //   186: <illegal opcode> 5 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   191: <illegal opcode> 6 : (Lme/stupitdog/bhp/f07;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   196: aload_0
    //   197: aload_0
    //   198: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   201: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   204: bipush #11
    //   206: iaload
    //   207: aaload
    //   208: ldc2_w 0.5
    //   211: dconst_0
    //   212: ldc2_w 5.0
    //   215: <illegal opcode> 5 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   220: <illegal opcode> 7 : (Lme/stupitdog/bhp/f07;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   225: aload_0
    //   226: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   229: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   232: bipush #12
    //   234: iaload
    //   235: aaload
    //   236: aload_1
    //   237: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   240: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   243: bipush #13
    //   245: iaload
    //   246: aaload
    //   247: <illegal opcode> 8 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   252: <illegal opcode> 9 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   257: aload_0
    //   258: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   261: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   264: bipush #14
    //   266: iaload
    //   267: aaload
    //   268: aload_2
    //   269: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   272: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   275: bipush #15
    //   277: iaload
    //   278: aaload
    //   279: <illegal opcode> 8 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   284: <illegal opcode> 10 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   289: aload_0
    //   290: aload_0
    //   291: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   294: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   297: bipush #16
    //   299: iaload
    //   300: aaload
    //   301: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   304: iconst_1
    //   305: iaload
    //   306: <illegal opcode> 11 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   311: <illegal opcode> 12 : (Lme/stupitdog/bhp/f07;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   316: aload_0
    //   317: aload_0
    //   318: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   321: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   324: bipush #17
    //   326: iaload
    //   327: aaload
    //   328: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   331: bipush #15
    //   333: iaload
    //   334: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   337: iconst_1
    //   338: iaload
    //   339: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   342: bipush #18
    //   344: iaload
    //   345: <illegal opcode> 13 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   350: <illegal opcode> 14 : (Lme/stupitdog/bhp/f07;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   355: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	356	0	lllllllllllllllIlllIllllllIlIllI	Lme/stupitdog/bhp/f07;
    //   8	348	1	lllllllllllllllIlllIllllllIlIlIl	Ljava/util/ArrayList;
    //   79	277	2	lllllllllllllllIlllIllllllIlIlII	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	348	1	lllllllllllllllIlllIllllllIlIlIl	Ljava/util/ArrayList<Ljava/lang/String;>;
    //   79	277	2	lllllllllllllllIlllIllllllIlIlII	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onDisable : ()V
    //   4: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   19: invokestatic llllIllllIlIIll : (Ljava/lang/Object;)Z
    //   22: ifeq -> 50
    //   25: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   30: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   35: <illegal opcode> 17 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   40: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   43: iconst_0
    //   44: iaload
    //   45: <illegal opcode> 18 : (Lnet/minecraft/entity/Entity;Z)V
    //   50: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	51	0	lllllllllllllllIlllIllllllIlIIll	Lme/stupitdog/bhp/f07;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 19 : ()Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   6: <illegal opcode> 20 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   11: <illegal opcode> 21 : (Lme/stupitdog/bhp/f07;Ljava/lang/String;)V
    //   16: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIlllIllllllIlIIlI	Lme/stupitdog/bhp/f07;
  }
  
  private void steerBoat(Entity lllllllllllllllIlllIllllllIlIIII) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore_2
    //   6: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   11: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   16: <illegal opcode> 23 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   21: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   26: istore_3
    //   27: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   32: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   37: <illegal opcode> 25 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   42: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   47: istore #4
    //   49: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   54: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   59: <illegal opcode> 26 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   64: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   69: istore #5
    //   71: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   76: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   81: <illegal opcode> 27 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   86: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   91: istore #6
    //   93: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   96: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   99: bipush #19
    //   101: iaload
    //   102: aaload
    //   103: <illegal opcode> 28 : (Ljava/lang/String;)Z
    //   108: invokestatic llllIllllIlIlII : (I)Z
    //   111: ifeq -> 135
    //   114: getstatic me/stupitdog/bhp/f07.lIlllIIIIllllI : [Ljava/lang/String;
    //   117: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   120: bipush #20
    //   122: iaload
    //   123: aaload
    //   124: <illegal opcode> 28 : (Ljava/lang/String;)Z
    //   129: invokestatic llllIllllIlIlIl : (I)Z
    //   132: ifeq -> 154
    //   135: aload_1
    //   136: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   141: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   146: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   151: putfield field_70177_z : F
    //   154: aload_1
    //   155: <illegal opcode> 30 : (Lnet/minecraft/entity/Entity;)Z
    //   160: invokestatic llllIllllIlIlII : (I)Z
    //   163: ifeq -> 297
    //   166: aload_1
    //   167: <illegal opcode> 31 : (Lnet/minecraft/entity/Entity;)Z
    //   172: invokestatic llllIllllIlIlII : (I)Z
    //   175: ifeq -> 189
    //   178: aload_1
    //   179: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   182: iconst_1
    //   183: iaload
    //   184: <illegal opcode> 18 : (Lnet/minecraft/entity/Entity;Z)V
    //   189: aload_1
    //   190: dconst_0
    //   191: putfield field_70181_x : D
    //   194: aload_1
    //   195: dup
    //   196: <illegal opcode> 32 : (Lnet/minecraft/entity/Entity;)D
    //   201: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   206: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   211: <illegal opcode> 33 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   216: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   219: iconst_2
    //   220: iaload
    //   221: irem
    //   222: invokestatic llllIllllIlIlII : (I)Z
    //   225: ifeq -> 290
    //   228: ldc2_w 0.1
    //   231: ldc ''
    //   233: invokevirtual length : ()I
    //   236: pop
    //   237: bipush #46
    //   239: bipush #57
    //   241: ixor
    //   242: ldc_w ' '
    //   245: invokevirtual length : ()I
    //   248: ishl
    //   249: bipush #41
    //   251: bipush #36
    //   253: ixor
    //   254: ixor
    //   255: sipush #146
    //   258: sipush #143
    //   261: ixor
    //   262: ldc_w ' '
    //   265: invokevirtual length : ()I
    //   268: ishl
    //   269: sipush #149
    //   272: sipush #140
    //   275: ixor
    //   276: ixor
    //   277: ldc_w ' '
    //   280: invokevirtual length : ()I
    //   283: ineg
    //   284: ixor
    //   285: iand
    //   286: ifeq -> 293
    //   289: return
    //   290: ldc2_w -0.1
    //   293: dadd
    //   294: putfield field_70181_x : D
    //   297: iload_3
    //   298: invokestatic llllIllllIlIlIl : (I)Z
    //   301: ifeq -> 312
    //   304: iload #6
    //   306: invokestatic llllIllllIlIlII : (I)Z
    //   309: ifeq -> 322
    //   312: aload_1
    //   313: dconst_0
    //   314: putfield field_70159_w : D
    //   317: aload_1
    //   318: dconst_0
    //   319: putfield field_70179_y : D
    //   322: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   327: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   332: <illegal opcode> 34 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   337: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   342: invokestatic llllIllllIlIlIl : (I)Z
    //   345: ifeq -> 370
    //   348: aload_1
    //   349: dup
    //   350: <illegal opcode> 32 : (Lnet/minecraft/entity/Entity;)D
    //   355: aload_0
    //   356: <illegal opcode> 35 : (Lme/stupitdog/bhp/f07;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   361: <illegal opcode> 36 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   366: dadd
    //   367: putfield field_70181_x : D
    //   370: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   375: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   380: <illegal opcode> 37 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   385: <illegal opcode> 24 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   390: invokestatic llllIllllIlIlIl : (I)Z
    //   393: ifeq -> 418
    //   396: aload_1
    //   397: dup
    //   398: <illegal opcode> 32 : (Lnet/minecraft/entity/Entity;)D
    //   403: aload_0
    //   404: <illegal opcode> 35 : (Lme/stupitdog/bhp/f07;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   409: <illegal opcode> 36 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   414: dsub
    //   415: putfield field_70181_x : D
    //   418: iload_3
    //   419: invokestatic llllIllllIlIlII : (I)Z
    //   422: ifeq -> 450
    //   425: iload #4
    //   427: invokestatic llllIllllIlIlII : (I)Z
    //   430: ifeq -> 450
    //   433: iload #5
    //   435: invokestatic llllIllllIlIlII : (I)Z
    //   438: ifeq -> 450
    //   441: iload #6
    //   443: invokestatic llllIllllIlIlII : (I)Z
    //   446: ifeq -> 450
    //   449: return
    //   450: iload #4
    //   452: invokestatic llllIllllIlIlIl : (I)Z
    //   455: ifeq -> 517
    //   458: iload #5
    //   460: invokestatic llllIllllIlIlIl : (I)Z
    //   463: ifeq -> 517
    //   466: iload #6
    //   468: invokestatic llllIllllIlIlIl : (I)Z
    //   471: ifeq -> 760
    //   474: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   477: bipush #21
    //   479: iaload
    //   480: istore_2
    //   481: ldc ''
    //   483: invokevirtual length : ()I
    //   486: pop
    //   487: ldc_w ' '
    //   490: invokevirtual length : ()I
    //   493: ldc_w ' '
    //   496: invokevirtual length : ()I
    //   499: ldc_w ' '
    //   502: invokevirtual length : ()I
    //   505: ldc_w ' '
    //   508: invokevirtual length : ()I
    //   511: ishl
    //   512: ishl
    //   513: if_icmpne -> 760
    //   516: return
    //   517: iload_3
    //   518: invokestatic llllIllllIlIlIl : (I)Z
    //   521: ifeq -> 665
    //   524: iload #6
    //   526: invokestatic llllIllllIlIlIl : (I)Z
    //   529: ifeq -> 665
    //   532: iload #4
    //   534: invokestatic llllIllllIlIlIl : (I)Z
    //   537: ifeq -> 583
    //   540: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   543: bipush #22
    //   545: iaload
    //   546: istore_2
    //   547: ldc ''
    //   549: invokevirtual length : ()I
    //   552: pop
    //   553: ldc_w ' '
    //   556: invokevirtual length : ()I
    //   559: ldc_w ' '
    //   562: invokevirtual length : ()I
    //   565: ldc_w ' '
    //   568: invokevirtual length : ()I
    //   571: ishl
    //   572: ishl
    //   573: ldc_w '   '
    //   576: invokevirtual length : ()I
    //   579: if_icmpge -> 760
    //   582: return
    //   583: iload #5
    //   585: invokestatic llllIllllIlIlIl : (I)Z
    //   588: ifeq -> 628
    //   591: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   594: bipush #23
    //   596: iaload
    //   597: istore_2
    //   598: ldc ''
    //   600: invokevirtual length : ()I
    //   603: pop
    //   604: ldc_w ' '
    //   607: invokevirtual length : ()I
    //   610: ldc_w ' '
    //   613: invokevirtual length : ()I
    //   616: ishl
    //   617: ldc_w ' '
    //   620: invokevirtual length : ()I
    //   623: ineg
    //   624: if_icmpge -> 760
    //   627: return
    //   628: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   631: bipush #24
    //   633: iaload
    //   634: istore_2
    //   635: ldc ''
    //   637: invokevirtual length : ()I
    //   640: pop
    //   641: ldc_w ' '
    //   644: invokevirtual length : ()I
    //   647: ldc_w ' '
    //   650: invokevirtual length : ()I
    //   653: ishl
    //   654: ldc_w ' '
    //   657: invokevirtual length : ()I
    //   660: ineg
    //   661: if_icmpne -> 760
    //   664: return
    //   665: iload #4
    //   667: invokestatic llllIllllIlIlIl : (I)Z
    //   670: ifeq -> 716
    //   673: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   676: bipush #22
    //   678: iaload
    //   679: istore_2
    //   680: ldc ''
    //   682: invokevirtual length : ()I
    //   685: pop
    //   686: ldc_w ' '
    //   689: invokevirtual length : ()I
    //   692: ldc_w ' '
    //   695: invokevirtual length : ()I
    //   698: ishl
    //   699: ldc_w ' '
    //   702: invokevirtual length : ()I
    //   705: ldc_w ' '
    //   708: invokevirtual length : ()I
    //   711: ishl
    //   712: if_icmpeq -> 760
    //   715: return
    //   716: iload #5
    //   718: invokestatic llllIllllIlIlIl : (I)Z
    //   721: ifeq -> 754
    //   724: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   727: bipush #23
    //   729: iaload
    //   730: istore_2
    //   731: ldc ''
    //   733: invokevirtual length : ()I
    //   736: pop
    //   737: ldc_w ' '
    //   740: invokevirtual length : ()I
    //   743: ineg
    //   744: ldc_w ' '
    //   747: invokevirtual length : ()I
    //   750: if_icmple -> 760
    //   753: return
    //   754: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   757: iconst_0
    //   758: iaload
    //   759: istore_2
    //   760: iload_3
    //   761: invokestatic llllIllllIlIlIl : (I)Z
    //   764: ifeq -> 825
    //   767: iload_2
    //   768: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   771: iconst_2
    //   772: iaload
    //   773: idiv
    //   774: istore_2
    //   775: ldc ''
    //   777: invokevirtual length : ()I
    //   780: pop
    //   781: ldc_w ' '
    //   784: invokevirtual length : ()I
    //   787: ldc_w ' '
    //   790: invokevirtual length : ()I
    //   793: ldc_w ' '
    //   796: invokevirtual length : ()I
    //   799: ishl
    //   800: ishl
    //   801: ldc_w ' '
    //   804: invokevirtual length : ()I
    //   807: ldc_w ' '
    //   810: invokevirtual length : ()I
    //   813: ldc_w ' '
    //   816: invokevirtual length : ()I
    //   819: ishl
    //   820: ishl
    //   821: if_icmpeq -> 848
    //   824: return
    //   825: iload #6
    //   827: invokestatic llllIllllIlIlIl : (I)Z
    //   830: ifeq -> 848
    //   833: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   836: bipush #21
    //   838: iaload
    //   839: iload_2
    //   840: getstatic me/stupitdog/bhp/f07.lIlllIIIlIIIll : [I
    //   843: iconst_2
    //   844: iaload
    //   845: idiv
    //   846: isub
    //   847: istore_2
    //   848: <illegal opcode> 15 : ()Lnet/minecraft/client/Minecraft;
    //   853: <illegal opcode> 16 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   858: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   863: iload_2
    //   864: i2f
    //   865: fadd
    //   866: fstore #7
    //   868: aload_1
    //   869: fload #7
    //   871: fneg
    //   872: f2d
    //   873: <illegal opcode> 38 : (D)D
    //   878: <illegal opcode> 39 : (D)D
    //   883: aload_0
    //   884: <illegal opcode> 40 : (Lme/stupitdog/bhp/f07;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   889: <illegal opcode> 36 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   894: d2f
    //   895: f2d
    //   896: dmul
    //   897: putfield field_70159_w : D
    //   900: aload_1
    //   901: fload #7
    //   903: f2d
    //   904: <illegal opcode> 38 : (D)D
    //   909: <illegal opcode> 41 : (D)D
    //   914: aload_0
    //   915: <illegal opcode> 40 : (Lme/stupitdog/bhp/f07;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   920: <illegal opcode> 36 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   925: d2f
    //   926: f2d
    //   927: dmul
    //   928: putfield field_70179_y : D
    //   931: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	932	0	lllllllllllllllIlllIllllllIlIIIl	Lme/stupitdog/bhp/f07;
    //   0	932	1	lllllllllllllllIlllIllllllIlIIII	Lnet/minecraft/entity/Entity;
    //   6	926	2	lllllllllllllllIlllIllllllIIllll	I
    //   27	905	3	lllllllllllllllIlllIllllllIIlllI	Z
    //   49	883	4	lllllllllllllllIlllIllllllIIllIl	Z
    //   71	861	5	lllllllllllllllIlllIllllllIIllII	Z
    //   93	839	6	lllllllllllllllIlllIllllllIIlIll	Z
    //   868	64	7	lllllllllllllllIlllIllllllIIlIlI	F
  }
  
  public static boolean isMode(String lllllllllllllllIlllIllllllIIlIIl) {
    // Byte code:
    //   0: <illegal opcode> 19 : ()Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   5: <illegal opcode> 20 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   10: aload_0
    //   11: <illegal opcode> 42 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   16: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIlllIllllllIIlIIl	Ljava/lang/String;
  }
  
  public static boolean isYawMode(String lllllllllllllllIlllIllllllIIlIII) {
    // Byte code:
    //   0: <illegal opcode> 43 : ()Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   5: <illegal opcode> 20 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   10: aload_0
    //   11: <illegal opcode> 42 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   16: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIlllIllllllIIlIII	Ljava/lang/String;
  }
  
  static {
    llllIllllIlIIlI();
    llllIllllIlIIIl();
    llllIllllIlIIII();
    llllIllllIIIIlI();
  }
  
  private static CallSite llllIlIlIllIIII(MethodHandles.Lookup lllllllllllllllIlllIlllllIlllIll, String lllllllllllllllIlllIlllllIlllIlI, MethodType lllllllllllllllIlllIlllllIlllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIllllllIIIIIl = lIllIllIlIIIIl[Integer.parseInt(lllllllllllllllIlllIlllllIlllIlI)].split(lIlllIIIIllllI[lIlllIIIlIIIll[29]]);
      Class<?> lllllllllllllllIlllIllllllIIIIII = Class.forName(lllllllllllllllIlllIllllllIIIIIl[lIlllIIIlIIIll[0]]);
      String lllllllllllllllIlllIlllllIllllll = lllllllllllllllIlllIllllllIIIIIl[lIlllIIIlIIIll[1]];
      MethodHandle lllllllllllllllIlllIlllllIlllllI = null;
      int lllllllllllllllIlllIlllllIllllIl = lllllllllllllllIlllIllllllIIIIIl[lIlllIIIlIIIll[3]].length();
      if (llllIllllIlIllI(lllllllllllllllIlllIlllllIllllIl, lIlllIIIlIIIll[2])) {
        MethodType lllllllllllllllIlllIllllllIIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIllllllIIIIIl[lIlllIIIlIIIll[2]], f07.class.getClassLoader());
        if (llllIllllIlIlll(lllllllllllllllIlllIlllllIllllIl, lIlllIIIlIIIll[2])) {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findVirtual(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIll);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findStatic(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIll);
        } 
        "".length();
        if (-" ".length() != -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIllllllIIIIlI = lIllIllIlIIIlI[Integer.parseInt(lllllllllllllllIlllIllllllIIIIIl[lIlllIIIlIIIll[2]])];
        if (llllIllllIlIlll(lllllllllllllllIlllIlllllIllllIl, lIlllIIIlIIIll[3])) {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findGetter(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (llllIllllIlIlll(lllllllllllllllIlllIlllllIllllIl, lIlllIIIlIIIll[4])) {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findStaticGetter(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIlI);
          "".length();
          if (-" ".length() < -" ".length())
            return null; 
        } else if (llllIllllIlIlll(lllllllllllllllIlllIlllllIllllIl, lIlllIIIlIIIll[5])) {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findSetter(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIlI);
          "".length();
          if (-" ".length() >= (" ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIlllIlllllIlllllI = lllllllllllllllIlllIlllllIlllIll.findStaticSetter(lllllllllllllllIlllIllllllIIIIII, lllllllllllllllIlllIlllllIllllll, lllllllllllllllIlllIllllllIIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlllllIlllllI);
    } catch (Exception lllllllllllllllIlllIlllllIllllII) {
      lllllllllllllllIlllIlllllIllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllllIIIIlI() {
    lIllIllIlIIIIl = new String[lIlllIIIlIIIll[30]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[18]] = lIlllIIIIllllI[lIlllIIIlIIIll[31]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[32]] = lIlllIIIIllllI[lIlllIIIlIIIll[33]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[34]] = lIlllIIIIllllI[lIlllIIIlIIIll[35]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[36]] = lIlllIIIIllllI[lIlllIIIlIIIll[34]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[25]] = lIlllIIIIllllI[lIlllIIIlIIIll[37]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[38]] = lIlllIIIIllllI[lIlllIIIlIIIll[39]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[3]] = lIlllIIIIllllI[lIlllIIIlIIIll[40]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[11]] = lIlllIIIIllllI[lIlllIIIlIIIll[38]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[20]] = lIlllIIIIllllI[lIlllIIIlIIIll[41]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[26]] = lIlllIIIIllllI[lIlllIIIlIIIll[42]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[41]] = lIlllIIIIllllI[lIlllIIIlIIIll[43]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[44]] = lIlllIIIIllllI[lIlllIIIlIIIll[45]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[9]] = lIlllIIIIllllI[lIlllIIIlIIIll[36]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[10]] = lIlllIIIIllllI[lIlllIIIlIIIll[46]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[33]] = lIlllIIIIllllI[lIlllIIIlIIIll[44]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[47]] = lIlllIIIIllllI[lIlllIIIlIIIll[18]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[37]] = lIlllIIIIllllI[lIlllIIIlIIIll[47]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[48]] = lIlllIIIIllllI[lIlllIIIlIIIll[49]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[14]] = lIlllIIIIllllI[lIlllIIIlIIIll[48]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[0]] = lIlllIIIIllllI[lIlllIIIlIIIll[50]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[39]] = lIlllIIIIllllI[lIlllIIIlIIIll[51]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[28]] = lIlllIIIIllllI[lIlllIIIlIIIll[52]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[6]] = lIlllIIIIllllI[lIlllIIIlIIIll[53]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[17]] = lIlllIIIIllllI[lIlllIIIlIIIll[54]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[45]] = lIlllIIIIllllI[lIlllIIIlIIIll[55]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[29]] = lIlllIIIIllllI[lIlllIIIlIIIll[32]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[51]] = lIlllIIIIllllI[lIlllIIIlIIIll[56]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[42]] = lIlllIIIIllllI[lIlllIIIlIIIll[57]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[43]] = lIlllIIIIllllI[lIlllIIIlIIIll[30]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[40]] = lIlllIIIIllllI[lIlllIIIlIIIll[58]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[35]] = lIlllIIIIllllI[lIlllIIIlIIIll[59]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[13]] = lIlllIIIIllllI[lIlllIIIlIIIll[60]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[27]] = lIlllIIIIllllI[lIlllIIIlIIIll[61]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[7]] = lIlllIIIIllllI[lIlllIIIlIIIll[62]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[52]] = lIlllIIIIllllI[lIlllIIIlIIIll[63]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[19]] = lIlllIIIIllllI[lIlllIIIlIIIll[64]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[54]] = lIlllIIIIllllI[lIlllIIIlIIIll[65]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[2]] = lIlllIIIIllllI[lIlllIIIlIIIll[66]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[49]] = lIlllIIIIllllI[lIlllIIIlIIIll[67]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[57]] = lIlllIIIIllllI[lIlllIIIlIIIll[68]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[15]] = lIlllIIIIllllI[lIlllIIIlIIIll[69]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[5]] = lIlllIIIIllllI[lIlllIIIlIIIll[70]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[31]] = lIlllIIIIllllI[lIlllIIIlIIIll[71]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[55]] = lIlllIIIIllllI[lIlllIIIlIIIll[72]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[46]] = lIlllIIIIllllI[lIlllIIIlIIIll[73]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[4]] = lIlllIIIIllllI[lIlllIIIlIIIll[74]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[8]] = lIlllIIIIllllI[lIlllIIIlIIIll[75]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[12]] = lIlllIIIIllllI[lIlllIIIlIIIll[76]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[53]] = lIlllIIIIllllI[lIlllIIIlIIIll[77]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[16]] = lIlllIIIIllllI[lIlllIIIlIIIll[78]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[50]] = lIlllIIIIllllI[lIlllIIIlIIIll[79]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[56]] = lIlllIIIIllllI[lIlllIIIlIIIll[80]];
    lIllIllIlIIIIl[lIlllIIIlIIIll[1]] = lIlllIIIIllllI[lIlllIIIlIIIll[81]];
    lIllIllIlIIIlI = new Class[lIlllIIIlIIIll[17]];
    lIllIllIlIIIlI[lIlllIIIlIIIll[2]] = f100000000000000000000.Double.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[13]] = int.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[16]] = WorldClient.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[7]] = EntityPlayerSP.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[11]] = boolean.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[9]] = KeyBinding.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[5]] = f100000000000000000000.Integer.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[14]] = PlayerControllerMP.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[15]] = EnumHand.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[12]] = double.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[10]] = float.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[1]] = Listener.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[3]] = f100000000000000000000.Mode.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[0]] = f13.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[4]] = f100000000000000000000.Boolean.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[6]] = Minecraft.class;
    lIllIllIlIIIlI[lIlllIIIlIIIll[8]] = GameSettings.class;
  }
  
  private static void llllIllllIlIIII() {
    lIlllIIIIllllI = new String[lIlllIIIlIIIll[82]];
    lIlllIIIIllllI[lIlllIIIlIIIll[0]] = llllIllllIIIIll(lIlllIIIlIIIlI[lIlllIIIlIIIll[0]], lIlllIIIlIIIlI[lIlllIIIlIIIll[1]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[1]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[2]], lIlllIIIlIIIlI[lIlllIIIlIIIll[3]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[2]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[4]], lIlllIIIlIIIlI[lIlllIIIlIIIll[5]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[3]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[6]], lIlllIIIlIIIlI[lIlllIIIlIIIll[7]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[4]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[8]], lIlllIIIlIIIlI[lIlllIIIlIIIll[9]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[5]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[10]], lIlllIIIlIIIlI[lIlllIIIlIIIll[11]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[6]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[12]], lIlllIIIlIIIlI[lIlllIIIlIIIll[13]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[7]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[14]], lIlllIIIlIIIlI[lIlllIIIlIIIll[15]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[8]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[16]], lIlllIIIlIIIlI[lIlllIIIlIIIll[17]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[9]] = llllIllllIIIIll(lIlllIIIlIIIlI[lIlllIIIlIIIll[19]], lIlllIIIlIIIlI[lIlllIIIlIIIll[20]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[10]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[25]], lIlllIIIlIIIlI[lIlllIIIlIIIll[26]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[11]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[27]], lIlllIIIlIIIlI[lIlllIIIlIIIll[28]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[12]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[29]], lIlllIIIlIIIlI[lIlllIIIlIIIll[31]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[13]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[33]], lIlllIIIlIIIlI[lIlllIIIlIIIll[35]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[14]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[34]], lIlllIIIlIIIlI[lIlllIIIlIIIll[37]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[15]] = llllIllllIIIIll(lIlllIIIlIIIlI[lIlllIIIlIIIll[39]], lIlllIIIlIIIlI[lIlllIIIlIIIll[40]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[16]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[38]], lIlllIIIlIIIlI[lIlllIIIlIIIll[41]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[17]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[42]], lIlllIIIlIIIlI[lIlllIIIlIIIll[43]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[19]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[45]], lIlllIIIlIIIlI[lIlllIIIlIIIll[36]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[20]] = llllIllllIIIIll(lIlllIIIlIIIlI[lIlllIIIlIIIll[46]], lIlllIIIlIIIlI[lIlllIIIlIIIll[44]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[25]] = llllIllllIIIIll(lIlllIIIlIIIlI[lIlllIIIlIIIll[18]], lIlllIIIlIIIlI[lIlllIIIlIIIll[47]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[26]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[49]], lIlllIIIlIIIlI[lIlllIIIlIIIll[48]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[27]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[50]], lIlllIIIlIIIlI[lIlllIIIlIIIll[51]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[28]] = llllIllllIIIlII(lIlllIIIlIIIlI[lIlllIIIlIIIll[52]], lIlllIIIlIIIlI[lIlllIIIlIIIll[53]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[29]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[54]], lIlllIIIlIIIlI[lIlllIIIlIIIll[55]]);
    lIlllIIIIllllI[lIlllIIIlIIIll[31]] = llllIllllIIIlIl(lIlllIIIlIIIlI[lIlllIIIlIIIll[32]], "tNuCJ");
    lIlllIIIIllllI[lIlllIIIlIIIll[33]] = llllIllllIIIlIl("e6Hx0re6kaM2AB+1L9ncuUKQ9tjSrNN6STfJv3YqdXIWatLw66l7nmupLPP1LAadK4VAvpg63SkHGSBrVWQudUlVN//qSsIAuOLth4kGoT7qzixxRRXBx4hbwgdzWg0G", "SyXBP");
    lIlllIIIIllllI[lIlllIIIlIIIll[35]] = llllIllllIIIlII("AwZBFBUbEwYTBQEEQQUJHk0JV1ZUChw+ABkuAAMEVEsjDQAYAkALAAAEQDQVHAoBAFpHOVVH", "ncoga");
    lIlllIIIIllllI[lIlllIIIlIIIll[34]] = llllIllllIIIIll("nXdVatQsEWh+wt/71jhj7w+SlNq039cY8y7+AvDPJSIntizV56xn5Xre9HbZJj1V2uuFfB8gFXJtZzEOMuPsow==", "CaMmZ");
    lIlllIIIIllllI[lIlllIIIlIIIll[37]] = llllIllllIIIlII("ISBIMR05NQ82DSMiSCABPGsAc1l8dVZyWXx1VnJZfHVWcll8dVZyTQEqAidTKyASFAggMAN4QWUJDCMfLWoKIwcrajU2GyUrAXlTbGU=", "LEfBi");
    lIlllIIIIllllI[lIlllIIIlIIIll[39]] = llllIllllIIIlIl("Rsaxb6CNkpX0FD/ZpYZSUSUuBcjXD1+zyJkWNmfutrxi23z1xq+u9AC8/g3r4e+tjU4UrlwpUlw=", "cGvHI");
    lIlllIIIIllllI[lIlllIIIlIIIll[40]] = llllIllllIIIlII("JQR7NzM9ETwwIycGeyYvOE8zdHByDjsXIjoXMDYXKQI+ITNyUG9kZ2hBdQ==", "HaUDG");
    lIlllIIIIllllI[lIlllIIIlIIIll[38]] = llllIllllIIIlII("AQBvJzYZFSggJgMCbzYqHEsnZHVWFyQzKx8RJCYAAwotMSMCX2kYKA0TIHsuDQsmexEYFyg6JVc/aBgvCUoyIDccDDUwLQtKIzwyQwNwZHJcVXFkclxVcWRyXFVxZHJcVXFwAAMKLTEjAl57dGI=", "leATB");
    lIlllIIIIllllI[lIlllIIIlIIIll[41]] = llllIllllIIIlIl("8m8KohCtvmwuQsM/0eEcpsP5wnsttYQouEyIyH1RvfKnzh3g/DAZXQ==", "OFVdm");
    lIlllIIIIllllI[lIlllIIIlIIIll[42]] = llllIllllIIIIll("Wm8r6MoABsSvtTkDeMDSyXrMS4lZH2EQVfQKJ+tMnyJx2cNMz5kVmVFJtvEGgzNMsqOFRx8FJXafzA10yu8kEg==", "lTyvH");
    lIlllIIIIllllI[lIlllIIIlIIIll[43]] = llllIllllIIIlII("JjYBbD0hPRAhIik1AWwzJDoQLCRmNhs2OTwqWwc+PDoBOwAkMgwnIhsDTyQ5LT8RHWd4YkJxDykyT3NjcnNVYg==", "HSuBP");
    lIlllIIIIllllI[lIlllIIIlIIIll[45]] = llllIllllIIIlIl("JmpFl6cXyiDlVL7Yo+zD7HET9lNeE/KvDsxJxBNv7L0=", "BsrgS");
    lIlllIIIIllllI[lIlllIIIlIIIll[36]] = llllIllllIIIlIl("nmLHnfQ+sCwSOpSvzIIdllyIzq/OOxRrtXxa8hsQnRNBAS+mX624iA==", "JsRwJ");
    lIlllIIIIllllI[lIlllIIIlIIIll[46]] = llllIllllIIIIll("Nup490yTegca8ndKYY8A+GgDkev6L7u1MfhCiTF1iRY+SjoYuGM9Cw==", "UdQig");
    lIlllIIIIllllI[lIlllIIIlIIIll[44]] = llllIllllIIIlIl("6U4JkRj2p36yacdHSLvNPqVE5L9L/k1ePziT2/OA3bS1KEHIJw9MgEjPkAVXY0nRggblBF6m8PC0x+alsmMfTQ==", "DEOTk");
    lIlllIIIIllllI[lIlllIIIlIIIll[18]] = llllIllllIIIlII("ORA1F2o/EC0Rah4QNx5+MB4wTGwXWAdMZA==", "SqCvD");
    lIlllIIIIllllI[lIlllIIIlIIIll[47]] = llllIllllIIIIll("d1Ef/ttcqsypViCJW11j7lkGuDWophNPzTUXEywwOP0ZfhrfsFnruujOLBOZoQNQuAGh4y6XZI9qcThhRRQWfQ==", "fKhYd");
    lIlllIIIIllllI[lIlllIIIlIIIll[49]] = llllIllllIIIlIl("0bKf5yqkO7vc6WyGcab+qQN8rQkGvEwS1KgcFZTXTZqjuYPnxtNFfQ==", "vKLKI");
    lIlllIIIIllllI[lIlllIIIlIIIll[48]] = llllIllllIIIlII("NBd5FRosAj4SCjYVeQQGKVwxVlljHTEAHTwGbVNUeVJ3Rk4=", "YrWfn");
    lIlllIIIIllllI[lIlllIIIlIIIll[50]] = llllIllllIIIlIl("rVSI/tFTE7Hs+gSVW+fBNvwI7Um6/Gu8ek5n3eDXaMpo6aNmJugEHw==", "tmDHv");
    lIlllIIIIllllI[lIlllIIIlIIIll[51]] = llllIllllIIIlIl("p4QC3sAfzj8r7VcDNe9HuUTXSpALijJx25OQsG0X+yt7lPL6ylnZiRxw/bIkuRX2gwcbMGslTJY=", "lkPLT");
    lIlllIIIIllllI[lIlllIIIlIIIll[52]] = llllIllllIIIIll("bLGQYrKTjvUpTVFnyJhx3FCFjuqiC9C0MMougylIg+98DWXuPfgbu2MvOZXWmz9Wg6igkmih39GbNRBh90dr3g==", "xXFdj");
    lIlllIIIIllllI[lIlllIIIlIIIll[53]] = llllIllllIIIIll("UXpvZ0RfhMqQFwOGnh3d0t9qPQIibbL+5eB03MVzuj2imEbBJdpYWA==", "ZyOCM");
    lIlllIIIIllllI[lIlllIIIlIIIll[54]] = llllIllllIIIIll("I0tR3aCbIQ6/sOTglTajV6TKa2iQSUvHfIFnwEVyOPttEUf/egV+BX52svGSYSVpxnrDDXD94IOCZ9BxYTu6OiFB6zZhGj8tgjAwqLSrFvQJynyPeO8ShjaPWJow6W8h", "Neuxs");
    lIlllIIIIllllI[lIlllIIIlIIIll[55]] = llllIllllIIIlIl("T4r10YG/6HWlg5UzY8wvBrMuAnKzLZkiHOvd8Mux6R9ZBzbw86YbIXGlXBBj2DYxtVDE/YZRXWpf7ESMBpzqzQ==", "IcvAB");
    lIlllIIIIllllI[lIlllIIIlIIIll[32]] = llllIllllIIIlIl("ouk5YJ3EwFpcX69naR7sdIzhaHIjD+qF4Iok6qv0gsZbK8vYkcZjtyt1/yagDSMUMTjRQOO8rR+mNc1gSpeQsA==", "kyCgZ");
    lIlllIIIIllllI[lIlllIIIlIIIll[56]] = llllIllllIIIIll("cEh/w4L0zcYwC9tYP41GWHVo2LcgOw+UsA5cN5p6LpboNIdoqIwkdwJevP9p7M0SUC/CU7PDNfnK+7uYHPNgAV87hylXOvo6", "lCggS");
    lIlllIIIIllllI[lIlllIIIlIIIll[57]] = llllIllllIIIlIl("SgKVYgUysZMJLh55qPuYDHaxkw8yCuvMUicT79Am8eI8T6xEr9MN6gdPZ0ml9v+2p0EeCol4qUbU6ilywX8gJA==", "qnmOk");
    lIlllIIIIllllI[lIlllIIIlIIIll[30]] = llllIllllIIIIll("8objewnXLzhIB7ev5ayov7Rz/pYUJwRsKa752juhcWzNcdqIxdRdgw==", "RFGKs");
    lIlllIIIIllllI[lIlllIIIlIIIll[58]] = llllIllllIIIlII("OiwwTS49JyEAMTUvME0mOj0tFzp6DCoXKiAwfgU2OiobUnttf3FRHDUsfktqDnNkQw==", "TIDcC");
    lIlllIIIIllllI[lIlllIIIlIIIll[59]] = llllIllllIIIlIl("IPFmyW3gwAZYOHML55CL572KfJhUMNSfU6/QaVne7hiOVH/247JcyDcXgz/AL6QQFE/YNkKwZhILsJucEowtQw==", "UjCgs");
    lIlllIIIIllllI[lIlllIIIlIIIll[60]] = llllIllllIIIIll("7Mj8haqTzfQ868Sr4+oYI27lG6yJ486w7d7o9OaPdLWNlFurG6FhzSDiPKNeTBwp0lfhB31+2+VoMNL2ASLikIu9PjmntMu1LqCBkSXJQatuSS4oFTpXk25JLigVOleTojScH+bENKTcPNKyR95nVWA+xtocu6tR", "vPLGv");
    lIlllIIIIllllI[lIlllIIIlIIIll[61]] = llllIllllIIIIll("wL+7S2C6sfC2TjZwHdPRp88XtFHrr+f359kJ12DjGnPSmPSOKxBtnZRaqAw5JABBYlbHoFcmz10=", "HCtZf");
    lIlllIIIIllllI[lIlllIIIlIIIll[62]] = llllIllllIIIlIl("k9nWgZdRgtM8ke/m0LD56eBm2gpnoQ7hJjPvEq75dUk7V1BRh+YESQ==", "SmWQL");
    lIlllIIIIllllI[lIlllIIIlIIIll[63]] = llllIllllIIIIll("Edgt/oFPq3IcxK08mszjxBGmKrbeDhShL9sTfGDZy7+cAiFtZjCVmA==", "mlaDx");
    lIlllIIIIllllI[lIlllIIIlIIIll[64]] = llllIllllIIIlIl("AkVkNx3dYVl18pdfd41icLwWRYe8ZqDkmXPHvvmxHrkTTyL5N5j1oum5jsi6tFtUD52WzUXOmRA=", "cdtOI");
    lIlllIIIIllllI[lIlllIIIlIIIll[65]] = llllIllllIIIlIl("RX+6UEBVpva0qeAGc68q5wHFnT179LSKttSjO/xzblD7e7/evRp/VBLI38u/Oube", "IgeBE");
    lIlllIIIIllllI[lIlllIIIlIIIll[66]] = llllIllllIIIIll("I+iM6DIN4DSCOmmXzSArHOrbpVo9ln+g6b0BBLAtRfnNtzwe5538lOzyLZU1CHTd", "DrGfR");
    lIlllIIIIllllI[lIlllIIIlIIIll[67]] = llllIllllIIIlII("JTkxEHgjOSkWeBwsNRg4KGIiACMuNDQ4MSE3NRQVLisiS34DMiYHN2A0Jh8xYAszAz8hP3xYDHV4Zw==", "OXGqV");
    lIlllIIIIllllI[lIlllIIIlIIIll[68]] = llllIllllIIIlII("Kz89RD0sNCwJIiQ8PUQzKTMsBCRrFyAENSYoKAwkfzwgDzwhBX5bZHFrFg9qdGxzSnBl", "EZIjP");
    lIlllIIIIllllI[lIlllIIIlIIIll[69]] = llllIllllIIIlIl("YHg8Q94hDWDbNNhXrZr+Jyz/f3vrrdBrq2QJDa9mp2Y=", "HEBva");
    lIlllIIIIllllI[lIlllIIIlIIIll[70]] = llllIllllIIIIll("mpEmVSO38JU+HEzSZ8uL3zR7eb3fKvNYbfNxOi0oTYod9DSd9PC3dC5sBDsYfLgoSYRH9x6nGtJWljZ2hfl4PbHdKULg59oj+QWTeF5iw72u/lwazzmMv67+XBrPOYy/pyZ9EHy+vlGkUf9YwOMkew==", "pELNo");
    lIlllIIIIllllI[lIlllIIIlIIIll[71]] = llllIllllIIIlII("LBAmWCQrGzcVOyMTJlgqLhw3GD1sBjcCPSsbNQVnBRQ/ExonASYfJyUGaBAgJxk2KX52RmVGFjpPa0xpYlU=", "BuRvI");
    lIlllIIIIllllI[lIlllIIIlIIIll[72]] = llllIllllIIIlII("IBUWRSQnHgcIOy8WFkUqIhkHBT1gHRcHPScADgowKwJMOyUvCQcZCiEeFhkmIhwHGQQeSgQeJy0vU1N+fklVNCh0WC4FLDpfDwInKxMQCi86XwcFPScEG0Q5IhEbDjthNQwfIDoJMgcoNxUQUAUgFRZEJCceBwg7LxYWRCwgBAsfMGE1DB8gOglZJycrBE0GICAVARkoKARNHj0nHE0uJzsdKgonKktLJycrBE0GICAVARkoKARNHj0nHE0uJzsdIwg9Jx8MOSw9BQ4fcnRQQg==", "NpbkI");
    lIlllIIIIllllI[lIlllIIIlIIIll[73]] = llllIllllIIIlII("HzcADEQZNxgKRDg3AgVQATkkDA4cNxgeUF0SXylQVQ==", "uVvmj");
    lIlllIIIIllllI[lIlllIIIlIIIll[74]] = llllIllllIIIlIl("CdWSZjaOEfqAJxPD4hAtUyR3GJbPdi5/0oClc++LuRj+lsw9BkXjteRLxrws/Pk5prKNACiGYUw=", "MsLqd");
    lIlllIIIIllllI[lIlllIIIlIIIll[75]] = llllIllllIIIlII("ByR3ISYfMTAmNgUmdzA6Gm8/YmVQMzw1Oxk1PCAfBSU8aHomKzgkM0UtODw1RRItIDsEJmIeOAs3OH0nHig1fR4DMi1pHgAgLzN9BiA3NX05NSs7PA16cB4/D24qJicaKC02PQ1uOzoiRSdoYmJacWliYlpxaWJiWnFpYmJacWl2HwUlPGloSmE=", "jAYRR");
    lIlllIIIIllllI[lIlllIIIlIIIll[76]] = llllIllllIIIIll("628MmtLAD9Gqgrkvi7QG9Le59vFBE2PooBTmKhzlSpKKAG7mu96eCw==", "qIEEQ");
    lIlllIIIIllllI[lIlllIIIlIIIll[77]] = llllIllllIIIlII("DT0HXDkKNhYRJgI+B1w3DzEWHCBNFRocMQAqEhQgWT4aFzgHB0RDYFdqLBBuUmxJUnRD", "cXsrT");
    lIlllIIIIllllI[lIlllIIIlIIIll[78]] = llllIllllIIIIll("uVO50op6Ib2eD0XiRww7p927dXR6KdjFmxAePXYye6veQ/9Ig2XBBD5T++Nd2xqaZxWwdNP05aM=", "DiobS");
    lIlllIIIIllllI[lIlllIIIlIIIll[79]] = llllIllllIIIlII("Czd+FRgTIjkSCAk1fgQEFnw2VltcOyMrAwI3ak4gDDMmB0MKMz4BQzUmIg8CAWl5PFZG", "fRPfl");
    lIlllIIIIllllI[lIlllIIIlIIIll[80]] = llllIllllIIIlIl("4yN2nKBUnSTTVQgh3PFyVa5IDcdOewcByIU4FiikwRDKZvydNs7vjDAOnNkvvapTQRO+ppeWHPXaaKg7vGMr6lyAaDHbhHiAPlWIHuCP24E=", "yBthS");
    lIlllIIIIllllI[lIlllIIIlIIIll[81]] = llllIllllIIIlII("GwB/BhIDFTgBAhkCfxcOBks3RVFMCj8hFBcTNBlcR19xVUZWRQ==", "veQuf");
    lIlllIIIlIIIlI = null;
  }
  
  private static void llllIllllIlIIIl() {
    String str = (new Exception()).getStackTrace()[lIlllIIIlIIIll[0]].getFileName();
    lIlllIIIlIIIlI = str.substring(str.indexOf("ä") + lIlllIIIlIIIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllllIIIlII(String lllllllllllllllIlllIlllllIllIlll, String lllllllllllllllIlllIlllllIllIllI) {
    lllllllllllllllIlllIlllllIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlllllIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlllllIllIlIl = new StringBuilder();
    char[] lllllllllllllllIlllIlllllIllIlII = lllllllllllllllIlllIlllllIllIllI.toCharArray();
    int lllllllllllllllIlllIlllllIllIIll = lIlllIIIlIIIll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlllllIllIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIIlIIIll[0];
    while (llllIllllIllIII(j, i)) {
      char lllllllllllllllIlllIlllllIlllIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlllllIllIIll++;
      j++;
      "".length();
      if ((((0x29 ^ 0x3A) << " ".length() ^ 0x1A ^ 0x7F) & ((0x1B ^ 0x7E) << " ".length() ^ 24 + 57 - -55 + 1 ^ -" ".length())) != ((0x1F ^ 0x48 ^ "   ".length() << " ".length()) & (0x5D ^ 0x74 ^ (0x51 ^ 0x5E) << "   ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlllllIllIlIl);
  }
  
  private static String llllIllllIIIIll(String lllllllllllllllIlllIlllllIlIllll, String lllllllllllllllIlllIlllllIlIlllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllllIllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllllIlIlllI.getBytes(StandardCharsets.UTF_8)), lIlllIIIlIIIll[8]), "DES");
      Cipher lllllllllllllllIlllIlllllIllIIIl = Cipher.getInstance("DES");
      lllllllllllllllIlllIlllllIllIIIl.init(lIlllIIIlIIIll[2], lllllllllllllllIlllIlllllIllIIlI);
      return new String(lllllllllllllllIlllIlllllIllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllllIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllllIllIIII) {
      lllllllllllllllIlllIlllllIllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllllIIIlIl(String lllllllllllllllIlllIlllllIlIlIlI, String lllllllllllllllIlllIlllllIlIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllllIlIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllllIlIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllllIlIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllllIlIllII.init(lIlllIIIlIIIll[2], lllllllllllllllIlllIlllllIlIllIl);
      return new String(lllllllllllllllIlllIlllllIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllllIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllllIlIlIll) {
      lllllllllllllllIlllIlllllIlIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllllIlIIlI() {
    lIlllIIIlIIIll = new int[83];
    lIlllIIIlIIIll[0] = (101 + 201 - 251 + 180 ^ (0xE7 ^ 0xB6) << " ".length()) & ((0x2E ^ 0x49) << " ".length() ^ 56 + 84 - 83 + 82 ^ -" ".length());
    lIlllIIIlIIIll[1] = " ".length();
    lIlllIIIlIIIll[2] = " ".length() << " ".length();
    lIlllIIIlIIIll[3] = "   ".length();
    lIlllIIIlIIIll[4] = " ".length() << " ".length() << " ".length();
    lIlllIIIlIIIll[5] = (0xF7 ^ 0xC6) << " ".length() << " ".length() ^ 12 + 1 - -174 + 6;
    lIlllIIIlIIIll[6] = "   ".length() << " ".length();
    lIlllIIIlIIIll[7] = 0x1A ^ 0x1D;
    lIlllIIIlIIIll[8] = " ".length() << "   ".length();
    lIlllIIIlIIIll[9] = 0x77 ^ 0x7E;
    lIlllIIIlIIIll[10] = (0x62 ^ 0x3F ^ (0xBA ^ 0xB1) << "   ".length()) << " ".length();
    lIlllIIIlIIIll[11] = (0xD6 ^ 0x9B) << " ".length() ^ 138 + 8 - 111 + 110;
    lIlllIIIlIIIll[12] = "   ".length() << " ".length() << " ".length();
    lIlllIIIlIIIll[13] = "   ".length() << " ".length() << " ".length() ^ " ".length();
    lIlllIIIlIIIll[14] = ((0x99 ^ 0x86) << " ".length() << " ".length() ^ 0xBE ^ 0xC5) << " ".length();
    lIlllIIIlIIIll[15] = 48 + 93 - 114 + 118 ^ (0xF6 ^ 0xB9) << " ".length();
    lIlllIIIlIIIll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIIlIIIll[17] = 0x42 ^ 0x1F ^ (0x21 ^ 0x32) << " ".length() << " ".length();
    lIlllIIIlIIIll[18] = (0xE2 ^ 0xC7 ^ " ".length() << (0x2B ^ 0x2E)) << "   ".length();
    lIlllIIIlIIIll[19] = ((0x20 ^ 0x75) << " ".length() ^ 155 + 61 - 54 + 1) << " ".length();
    lIlllIIIlIIIll[20] = 0x5B ^ 0x48;
    lIlllIIIlIIIll[21] = (0xB4 ^ 0x99) << " ".length() << " ".length();
    lIlllIIIlIIIll[22] = -(0x23 ^ 0x38 ^ 0x74 ^ 0x35);
    lIlllIIIlIIIll[23] = (35 + 16 - 38 + 158 ^ (0x73 ^ 0x30) << " ".length()) << " ".length();
    lIlllIIIlIIIll[24] = -" ".length();
    lIlllIIIlIIIll[25] = ("   ".length() << " ".length() << " ".length() ^ 0x49 ^ 0x40) << " ".length() << " ".length();
    lIlllIIIlIIIll[26] = (0x98 ^ 0xC5) << " ".length() ^ 142 + 164 - 271 + 140;
    lIlllIIIlIIIll[27] = (0x24 ^ 0x2F) << " ".length();
    lIlllIIIlIIIll[28] = 0x12 ^ 0x5;
    lIlllIIIlIIIll[29] = "   ".length() << "   ".length();
    lIlllIIIlIIIll[30] = (0x1A ^ 0x7) << " ".length() << " ".length() ^ 0xE ^ 0x4F;
    lIlllIIIlIIIll[31] = 0xBC ^ 0xA5;
    lIlllIIIlIIIll[32] = (0x9C ^ 0x85) << " ".length();
    lIlllIIIlIIIll[33] = (0x5F ^ 0x52) << " ".length();
    lIlllIIIlIIIll[34] = (0x43 ^ 0x44) << " ".length() << " ".length();
    lIlllIIIlIIIll[35] = 0x18 ^ 0x3;
    lIlllIIIlIIIll[36] = (0x6B ^ 0x32) << " ".length() ^ 143 + 66 - 136 + 78;
    lIlllIIIlIIIll[37] = 0x32 ^ 0x2F;
    lIlllIIIlIIIll[38] = " ".length() << (0x47 ^ 0x42);
    lIlllIIIlIIIll[39] = (0xCC ^ 0xC3) << " ".length();
    lIlllIIIlIIIll[40] = 0xF ^ 0x10;
    lIlllIIIlIIIll[41] = 0x32 ^ 0x13;
    lIlllIIIlIIIll[42] = (0x9D ^ 0x8C) << " ".length();
    lIlllIIIlIIIll[43] = 0x75 ^ 0x56;
    lIlllIIIlIIIll[44] = (0xA ^ 0x27) << " ".length() << " ".length() ^ 90 + 61 - 38 + 34;
    lIlllIIIlIIIll[45] = (0xB2 ^ 0xBB) << " ".length() << " ".length();
    lIlllIIIlIIIll[46] = ((0x43 ^ 0x64) << " ".length() ^ 0x9E ^ 0xC3) << " ".length();
    lIlllIIIlIIIll[47] = (0x40 ^ 0x47) << " ".length() << " ".length() ^ 0xF0 ^ 0xC5;
    lIlllIIIlIIIll[48] = 159 + 148 - 174 + 104 ^ (0x2A ^ 0x49) << " ".length();
    lIlllIIIlIIIll[49] = (0xB5 ^ 0xA0) << " ".length();
    lIlllIIIlIIIll[50] = ((0xB2 ^ 0x95) << " ".length() ^ 0x77 ^ 0x32) << " ".length() << " ".length();
    lIlllIIIlIIIll[51] = (0x16 ^ 0x1B) << "   ".length() ^ 0xF4 ^ 0xB1;
    lIlllIIIlIIIll[52] = (0xA ^ 0x1D) << " ".length();
    lIlllIIIlIIIll[53] = 0xEB ^ 0xA6 ^ (0x58 ^ 0x69) << " ".length();
    lIlllIIIlIIIll[54] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIIlIIIll[55] = 0x1A ^ 0x2B;
    lIlllIIIlIIIll[56] = 176 + 138 - 249 + 112 ^ (0xCC ^ 0x8D) << " ".length();
    lIlllIIIlIIIll[57] = (0x13 ^ 0x1E) << " ".length() << " ".length();
    lIlllIIIlIIIll[58] = (0xBE ^ 0xA5) << " ".length();
    lIlllIIIlIIIll[59] = 0xF6 ^ 0xC1;
    lIlllIIIlIIIll[60] = (0x59 ^ 0x5E) << "   ".length();
    lIlllIIIlIIIll[61] = 0xB ^ 0x32;
    lIlllIIIlIIIll[62] = (0x9F ^ 0x82) << " ".length();
    lIlllIIIlIIIll[63] = 0x1 ^ 0x3A;
    lIlllIIIlIIIll[64] = (0x21 ^ 0x2E) << " ".length() << " ".length();
    lIlllIIIlIIIll[65] = 0x1D ^ 0x20;
    lIlllIIIlIIIll[66] = (0x9 ^ 0x16) << " ".length();
    lIlllIIIlIIIll[67] = 0x53 ^ 0x6C;
    lIlllIIIlIIIll[68] = " ".length() << "   ".length() << " ".length();
    lIlllIIIlIIIll[69] = 0x6D ^ 0x2C;
    lIlllIIIlIIIll[70] = ((0x64 ^ 0x4F) << " ".length() ^ 0xD8 ^ 0xAF) << " ".length();
    lIlllIIIlIIIll[71] = (0xA5 ^ 0x86) << " ".length() ^ 0x29 ^ 0x2C;
    lIlllIIIlIIIll[72] = (0xB5 ^ 0xA4) << " ".length() << " ".length();
    lIlllIIIlIIIll[73] = (0xB ^ 0x4A) << " ".length() ^ 81 + 100 - 151 + 169;
    lIlllIIIlIIIll[74] = (0xA8 ^ 0x8B) << " ".length();
    lIlllIIIlIIIll[75] = (0xB6 ^ 0xA7) << " ".length() ^ 0x7D ^ 0x18;
    lIlllIIIlIIIll[76] = (0xA0 ^ 0xA9) << "   ".length();
    lIlllIIIlIIIll[77] = 0x74 ^ 0x3D;
    lIlllIIIlIIIll[78] = (0x16 ^ 0x21 ^ (0x70 ^ 0x79) << " ".length()) << " ".length();
    lIlllIIIlIIIll[79] = 172 + 59 - 84 + 54 ^ (0x3A ^ 0x7B) << " ".length();
    lIlllIIIlIIIll[80] = (0x45 ^ 0x56) << " ".length() << " ".length();
    lIlllIIIlIIIll[81] = 0xFB ^ 0xB4 ^ " ".length() << " ".length();
    lIlllIIIlIIIll[82] = (0x5F ^ 0x78) << " ".length();
  }
  
  private static boolean llllIllllIlIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIllllIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIllllIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIllllIlIIll(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllIllllIlIlIl(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllIllllIlIlII(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f07.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */