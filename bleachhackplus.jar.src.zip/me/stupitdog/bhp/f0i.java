package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHopper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

public class f0i extends au {
  public static final List<Block> shulkerList;
  
  private int stage;
  
  private BlockPos placeTarget;
  
  private int obiSlot;
  
  private int dispenserSlot;
  
  private int shulkerSlot;
  
  private int redstoneSlot;
  
  private int hopperSlot;
  
  private boolean isSneaking;
  
  private ao timer;
  
  private static String[] lIllllIlIIIlll;
  
  private static Class[] lIllllIlIIlIII;
  
  private static final String[] llIIIIIlIlIIII;
  
  private static String[] llIIIIIlIlIllI;
  
  private static final int[] llIIIIIlIllIll;
  
  public f0i() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/stupitdog/bhp/ao
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f0i;Lme/stupitdog/bhp/ao;)V
    //   54: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	55	0	lllllllllllllllIllIllIlllllIllll	Lme/stupitdog/bhp/f0i;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0i;I)V
    //   11: aload_0
    //   12: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   15: iconst_3
    //   16: iaload
    //   17: <illegal opcode> 3 : (Lme/stupitdog/bhp/f0i;I)V
    //   22: aload_0
    //   23: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   26: iconst_3
    //   27: iaload
    //   28: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0i;I)V
    //   33: aload_0
    //   34: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   37: iconst_3
    //   38: iaload
    //   39: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0i;I)V
    //   44: aload_0
    //   45: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   48: iconst_3
    //   49: iaload
    //   50: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0i;I)V
    //   55: aload_0
    //   56: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   59: iconst_0
    //   60: iaload
    //   61: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0i;I)V
    //   66: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   69: iconst_0
    //   70: iaload
    //   71: istore_1
    //   72: iload_1
    //   73: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   76: iconst_4
    //   77: iaload
    //   78: invokestatic lIIIIIIlllIllllI : (II)Z
    //   81: ifeq -> 567
    //   84: aload_0
    //   85: <illegal opcode> 8 : (Lme/stupitdog/bhp/f0i;)I
    //   90: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   93: iconst_3
    //   94: iaload
    //   95: invokestatic lIIIIIIlllIlllll : (II)Z
    //   98: ifeq -> 201
    //   101: aload_0
    //   102: <illegal opcode> 9 : (Lme/stupitdog/bhp/f0i;)I
    //   107: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   110: iconst_3
    //   111: iaload
    //   112: invokestatic lIIIIIIlllIlllll : (II)Z
    //   115: ifeq -> 201
    //   118: aload_0
    //   119: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0i;)I
    //   124: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   127: iconst_3
    //   128: iaload
    //   129: invokestatic lIIIIIIlllIlllll : (II)Z
    //   132: ifeq -> 201
    //   135: aload_0
    //   136: <illegal opcode> 11 : (Lme/stupitdog/bhp/f0i;)I
    //   141: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   144: iconst_3
    //   145: iaload
    //   146: invokestatic lIIIIIIlllIlllll : (II)Z
    //   149: ifeq -> 201
    //   152: aload_0
    //   153: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0i;)I
    //   158: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   161: iconst_3
    //   162: iaload
    //   163: invokestatic lIIIIIIlllIlllll : (II)Z
    //   166: ifeq -> 201
    //   169: ldc ''
    //   171: invokevirtual length : ()I
    //   174: pop
    //   175: ldc ' '
    //   177: invokevirtual length : ()I
    //   180: ldc ' '
    //   182: invokevirtual length : ()I
    //   185: ldc ' '
    //   187: invokevirtual length : ()I
    //   190: ishl
    //   191: ishl
    //   192: ldc '   '
    //   194: invokevirtual length : ()I
    //   197: if_icmpgt -> 567
    //   200: return
    //   201: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   206: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   211: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   216: iload_1
    //   217: <illegal opcode> 16 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   222: astore_2
    //   223: aload_2
    //   224: <illegal opcode> 17 : ()Lnet/minecraft/item/ItemStack;
    //   229: invokestatic lIIIIIIllllIIIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   232: ifeq -> 544
    //   235: aload_2
    //   236: <illegal opcode> 18 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   241: instanceof net/minecraft/item/ItemBlock
    //   244: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   247: ifeq -> 288
    //   250: ldc ''
    //   252: invokevirtual length : ()I
    //   255: pop
    //   256: ldc ' '
    //   258: invokevirtual length : ()I
    //   261: ldc ' '
    //   263: invokevirtual length : ()I
    //   266: ldc ' '
    //   268: invokevirtual length : ()I
    //   271: ishl
    //   272: ishl
    //   273: ldc ' '
    //   275: invokevirtual length : ()I
    //   278: ldc ' '
    //   280: invokevirtual length : ()I
    //   283: ishl
    //   284: if_icmpgt -> 544
    //   287: return
    //   288: aload_2
    //   289: <illegal opcode> 18 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   294: checkcast net/minecraft/item/ItemBlock
    //   297: <illegal opcode> 19 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   302: astore_3
    //   303: aload_3
    //   304: <illegal opcode> 20 : ()Lnet/minecraft/block/BlockHopper;
    //   309: invokestatic lIIIIIIllllIIIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   312: ifeq -> 396
    //   315: aload_0
    //   316: iload_1
    //   317: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0i;I)V
    //   322: ldc ''
    //   324: invokevirtual length : ()I
    //   327: pop
    //   328: ldc ' '
    //   330: invokevirtual length : ()I
    //   333: ineg
    //   334: bipush #26
    //   336: bipush #51
    //   338: ixor
    //   339: sipush #187
    //   342: sipush #180
    //   345: ixor
    //   346: ldc ' '
    //   348: invokevirtual length : ()I
    //   351: ldc ' '
    //   353: invokevirtual length : ()I
    //   356: ishl
    //   357: ishl
    //   358: ixor
    //   359: sipush #166
    //   362: sipush #189
    //   365: ixor
    //   366: ldc ' '
    //   368: invokevirtual length : ()I
    //   371: ldc ' '
    //   373: invokevirtual length : ()I
    //   376: ishl
    //   377: ishl
    //   378: bipush #73
    //   380: bipush #48
    //   382: ixor
    //   383: ixor
    //   384: ldc ' '
    //   386: invokevirtual length : ()I
    //   389: ineg
    //   390: ixor
    //   391: iand
    //   392: if_icmpne -> 544
    //   395: return
    //   396: <illegal opcode> 21 : ()Ljava/util/List;
    //   401: aload_3
    //   402: <illegal opcode> 22 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   407: invokestatic lIIIIIIllllIIIll : (I)Z
    //   410: ifeq -> 431
    //   413: aload_0
    //   414: iload_1
    //   415: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0i;I)V
    //   420: ldc ''
    //   422: invokevirtual length : ()I
    //   425: pop
    //   426: aconst_null
    //   427: ifnull -> 544
    //   430: return
    //   431: aload_3
    //   432: <illegal opcode> 23 : ()Lnet/minecraft/block/Block;
    //   437: invokestatic lIIIIIIllllIIIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   440: ifeq -> 471
    //   443: aload_0
    //   444: iload_1
    //   445: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0i;I)V
    //   450: ldc ''
    //   452: invokevirtual length : ()I
    //   455: pop
    //   456: ldc ' '
    //   458: invokevirtual length : ()I
    //   461: ineg
    //   462: ldc '   '
    //   464: invokevirtual length : ()I
    //   467: if_icmplt -> 544
    //   470: return
    //   471: aload_3
    //   472: <illegal opcode> 24 : ()Lnet/minecraft/block/Block;
    //   477: invokestatic lIIIIIIllllIIIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   480: ifeq -> 525
    //   483: aload_0
    //   484: iload_1
    //   485: <illegal opcode> 3 : (Lme/stupitdog/bhp/f0i;I)V
    //   490: ldc ''
    //   492: invokevirtual length : ()I
    //   495: pop
    //   496: bipush #22
    //   498: bipush #27
    //   500: ixor
    //   501: ldc ' '
    //   503: invokevirtual length : ()I
    //   506: ishl
    //   507: bipush #95
    //   509: bipush #82
    //   511: ixor
    //   512: ldc ' '
    //   514: invokevirtual length : ()I
    //   517: ishl
    //   518: iconst_m1
    //   519: ixor
    //   520: iand
    //   521: ifeq -> 544
    //   524: return
    //   525: aload_3
    //   526: <illegal opcode> 25 : ()Lnet/minecraft/block/Block;
    //   531: invokestatic lIIIIIIllllIIIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   534: ifeq -> 544
    //   537: aload_0
    //   538: iload_1
    //   539: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0i;I)V
    //   544: iinc #1, 1
    //   547: ldc ''
    //   549: invokevirtual length : ()I
    //   552: pop
    //   553: ldc ' '
    //   555: invokevirtual length : ()I
    //   558: ldc '   '
    //   560: invokevirtual length : ()I
    //   563: if_icmplt -> 72
    //   566: return
    //   567: aload_0
    //   568: <illegal opcode> 8 : (Lme/stupitdog/bhp/f0i;)I
    //   573: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   576: iconst_3
    //   577: iaload
    //   578: invokestatic lIIIIIIllllIIlII : (II)Z
    //   581: ifeq -> 605
    //   584: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   587: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   590: iconst_5
    //   591: iaload
    //   592: aaload
    //   593: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   598: aload_0
    //   599: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   604: return
    //   605: aload_0
    //   606: <illegal opcode> 9 : (Lme/stupitdog/bhp/f0i;)I
    //   611: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   614: iconst_3
    //   615: iaload
    //   616: invokestatic lIIIIIIllllIIlII : (II)Z
    //   619: ifeq -> 644
    //   622: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   625: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   628: bipush #6
    //   630: iaload
    //   631: aaload
    //   632: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   637: aload_0
    //   638: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   643: return
    //   644: aload_0
    //   645: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0i;)I
    //   650: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   653: iconst_3
    //   654: iaload
    //   655: invokestatic lIIIIIIllllIIlII : (II)Z
    //   658: ifeq -> 683
    //   661: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   664: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   667: bipush #7
    //   669: iaload
    //   670: aaload
    //   671: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   676: aload_0
    //   677: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   682: return
    //   683: aload_0
    //   684: <illegal opcode> 11 : (Lme/stupitdog/bhp/f0i;)I
    //   689: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   692: iconst_3
    //   693: iaload
    //   694: invokestatic lIIIIIIllllIIlII : (II)Z
    //   697: ifeq -> 722
    //   700: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   703: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   706: bipush #8
    //   708: iaload
    //   709: aaload
    //   710: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   715: aload_0
    //   716: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   721: return
    //   722: aload_0
    //   723: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0i;)I
    //   728: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   731: iconst_3
    //   732: iaload
    //   733: invokestatic lIIIIIIllllIIlII : (II)Z
    //   736: ifeq -> 761
    //   739: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   742: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   745: bipush #9
    //   747: iaload
    //   748: aaload
    //   749: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   754: aload_0
    //   755: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   760: return
    //   761: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   766: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   771: invokestatic lIIIIIIllllIIlIl : (Ljava/lang/Object;)Z
    //   774: ifeq -> 824
    //   777: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   782: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   787: <illegal opcode> 29 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   792: invokestatic lIIIIIIllllIIlIl : (Ljava/lang/Object;)Z
    //   795: ifeq -> 824
    //   798: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   803: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   808: <illegal opcode> 29 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   813: <illegal opcode> 30 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   818: invokestatic lIIIIIIllllIIllI : (Ljava/lang/Object;)Z
    //   821: ifeq -> 846
    //   824: getstatic me/stupitdog/bhp/f0i.llIIIIIlIlIIII : [Ljava/lang/String;
    //   827: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   830: bipush #10
    //   832: iaload
    //   833: aaload
    //   834: <illegal opcode> 26 : (Ljava/lang/String;)V
    //   839: aload_0
    //   840: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0i;)V
    //   845: return
    //   846: aload_0
    //   847: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   852: <illegal opcode> 28 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/util/math/RayTraceResult;
    //   857: <illegal opcode> 29 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/math/BlockPos;
    //   862: <illegal opcode> 30 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   867: <illegal opcode> 31 : (Lme/stupitdog/bhp/f0i;Lnet/minecraft/util/math/BlockPos;)V
    //   872: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   223	321	2	lllllllllllllllIllIllIlllllIlllI	Lnet/minecraft/item/ItemStack;
    //   303	241	3	lllllllllllllllIllIllIlllllIllIl	Lnet/minecraft/block/Block;
    //   72	495	1	lllllllllllllllIllIllIlllllIllII	I
    //   0	873	0	lllllllllllllllIllIllIlllllIlIll	Lme/stupitdog/bhp/f0i;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 32 : (Lme/stupitdog/bhp/f0i;)I
    //   6: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   9: ifeq -> 255
    //   12: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   17: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   22: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   27: aload_0
    //   28: <illegal opcode> 8 : (Lme/stupitdog/bhp/f0i;)I
    //   33: putfield field_70461_c : I
    //   36: aload_0
    //   37: new net/minecraft/util/math/BlockPos
    //   40: dup
    //   41: aload_0
    //   42: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   47: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   50: <illegal opcode> 34 : ()Lnet/minecraft/util/EnumFacing;
    //   55: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   58: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   63: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   68: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   73: aload_0
    //   74: <illegal opcode> 9 : (Lme/stupitdog/bhp/f0i;)I
    //   79: putfield field_70461_c : I
    //   82: aload_0
    //   83: new net/minecraft/util/math/BlockPos
    //   86: dup
    //   87: aload_0
    //   88: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   93: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   96: iconst_0
    //   97: iaload
    //   98: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   101: iconst_1
    //   102: iaload
    //   103: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   106: iconst_0
    //   107: iaload
    //   108: <illegal opcode> 35 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   113: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   116: <illegal opcode> 34 : ()Lnet/minecraft/util/EnumFacing;
    //   121: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   124: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   129: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   134: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   139: new net/minecraft/network/play/client/CPacketEntityAction
    //   142: dup
    //   143: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   148: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   153: <illegal opcode> 37 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   158: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   161: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   166: aload_0
    //   167: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   170: iconst_0
    //   171: iaload
    //   172: <illegal opcode> 39 : (Lme/stupitdog/bhp/f0i;Z)V
    //   177: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   182: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   187: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   192: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   195: dup
    //   196: aload_0
    //   197: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   202: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   205: iconst_0
    //   206: iaload
    //   207: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   210: iconst_1
    //   211: iaload
    //   212: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   215: iconst_0
    //   216: iaload
    //   217: <illegal opcode> 35 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   222: <illegal opcode> 34 : ()Lnet/minecraft/util/EnumFacing;
    //   227: <illegal opcode> 40 : ()Lnet/minecraft/util/EnumHand;
    //   232: fconst_0
    //   233: fconst_0
    //   234: fconst_0
    //   235: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   238: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   243: aload_0
    //   244: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   247: iconst_1
    //   248: iaload
    //   249: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0i;I)V
    //   254: return
    //   255: aload_0
    //   256: <illegal opcode> 32 : (Lme/stupitdog/bhp/f0i;)I
    //   261: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   264: iconst_1
    //   265: iaload
    //   266: invokestatic lIIIIIIllllIIlII : (II)Z
    //   269: ifeq -> 452
    //   272: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   277: <illegal opcode> 41 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   282: instanceof net/minecraft/client/gui/inventory/GuiContainer
    //   285: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   288: ifeq -> 292
    //   291: return
    //   292: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   297: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   302: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   307: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   312: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   317: <illegal opcode> 44 : (Lnet/minecraft/inventory/Container;)I
    //   322: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   325: iconst_1
    //   326: iaload
    //   327: aload_0
    //   328: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0i;)I
    //   333: <illegal opcode> 45 : ()Lnet/minecraft/inventory/ClickType;
    //   338: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   343: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   348: <illegal opcode> 46 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   353: ldc ''
    //   355: invokevirtual length : ()I
    //   358: pop2
    //   359: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   364: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   369: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   374: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   379: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   384: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   389: aload_0
    //   390: <illegal opcode> 11 : (Lme/stupitdog/bhp/f0i;)I
    //   395: putfield field_70461_c : I
    //   398: aload_0
    //   399: new net/minecraft/util/math/BlockPos
    //   402: dup
    //   403: aload_0
    //   404: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   409: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   412: iconst_0
    //   413: iaload
    //   414: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   417: iconst_2
    //   418: iaload
    //   419: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   422: iconst_0
    //   423: iaload
    //   424: <illegal opcode> 35 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   429: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   432: <illegal opcode> 34 : ()Lnet/minecraft/util/EnumFacing;
    //   437: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   440: aload_0
    //   441: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   444: iconst_2
    //   445: iaload
    //   446: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0i;I)V
    //   451: return
    //   452: aload_0
    //   453: <illegal opcode> 32 : (Lme/stupitdog/bhp/f0i;)I
    //   458: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   461: iconst_2
    //   462: iaload
    //   463: invokestatic lIIIIIIllllIIlII : (II)Z
    //   466: ifeq -> 788
    //   469: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   474: <illegal opcode> 48 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   479: aload_0
    //   480: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   485: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   490: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   495: <illegal opcode> 49 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   500: <illegal opcode> 50 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   505: <illegal opcode> 51 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   510: <illegal opcode> 30 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   515: <illegal opcode> 52 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   520: <illegal opcode> 53 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   525: astore_1
    //   526: aload_1
    //   527: instanceof net/minecraft/block/BlockAir
    //   530: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   533: ifeq -> 546
    //   536: aload_1
    //   537: instanceof net/minecraft/block/BlockLiquid
    //   540: invokestatic lIIIIIIllllIIIll : (I)Z
    //   543: ifeq -> 547
    //   546: return
    //   547: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   552: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   557: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   562: aload_0
    //   563: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0i;)I
    //   568: putfield field_70461_c : I
    //   571: aload_0
    //   572: new net/minecraft/util/math/BlockPos
    //   575: dup
    //   576: aload_0
    //   577: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   582: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   587: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   592: <illegal opcode> 49 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   597: <illegal opcode> 50 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   602: <illegal opcode> 51 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   607: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   610: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   615: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   620: <illegal opcode> 49 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   625: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   628: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   633: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   638: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   643: new net/minecraft/network/play/client/CPacketEntityAction
    //   646: dup
    //   647: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   652: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   657: <illegal opcode> 37 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   662: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   665: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   670: aload_0
    //   671: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   674: iconst_0
    //   675: iaload
    //   676: <illegal opcode> 39 : (Lme/stupitdog/bhp/f0i;Z)V
    //   681: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   686: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   691: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   696: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   699: dup
    //   700: aload_0
    //   701: <illegal opcode> 33 : (Lme/stupitdog/bhp/f0i;)Lnet/minecraft/util/math/BlockPos;
    //   706: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   711: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   716: <illegal opcode> 49 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   721: <illegal opcode> 50 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   726: <illegal opcode> 51 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   731: <illegal opcode> 34 : ()Lnet/minecraft/util/EnumFacing;
    //   736: <illegal opcode> 40 : ()Lnet/minecraft/util/EnumHand;
    //   741: fconst_0
    //   742: fconst_0
    //   743: fconst_0
    //   744: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   747: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   752: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   757: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   762: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   767: aload_0
    //   768: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0i;)I
    //   773: putfield field_70461_c : I
    //   776: aload_0
    //   777: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   780: iconst_5
    //   781: iaload
    //   782: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0i;I)V
    //   787: return
    //   788: aload_0
    //   789: <illegal opcode> 32 : (Lme/stupitdog/bhp/f0i;)I
    //   794: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   797: iconst_5
    //   798: iaload
    //   799: invokestatic lIIIIIIllllIIlII : (II)Z
    //   802: ifeq -> 1114
    //   805: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   810: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   815: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   820: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   825: <illegal opcode> 43 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   830: <illegal opcode> 44 : (Lnet/minecraft/inventory/Container;)I
    //   835: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   838: iconst_0
    //   839: iaload
    //   840: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   845: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   850: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   855: <illegal opcode> 54 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   860: <illegal opcode> 45 : ()Lnet/minecraft/inventory/ClickType;
    //   865: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   870: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   875: <illegal opcode> 46 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   880: ldc ''
    //   882: invokevirtual length : ()I
    //   885: pop2
    //   886: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   891: <illegal opcode> 48 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   896: <illegal opcode> 55 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   901: <illegal opcode> 56 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   906: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   911: <illegal opcode> 57 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   916: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   921: <illegal opcode> 57 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   926: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   931: <illegal opcode> 57 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   936: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   941: <illegal opcode> 58 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   946: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   951: <illegal opcode> 59 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   956: <illegal opcode> 60 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   961: aconst_null
    //   962: <illegal opcode> 61 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   967: checkcast net/minecraft/entity/Entity
    //   970: astore_1
    //   971: aload_1
    //   972: invokestatic lIIIIIIllllIIlIl : (Ljava/lang/Object;)Z
    //   975: ifeq -> 1114
    //   978: aload_1
    //   979: instanceof net/minecraft/entity/player/EntityPlayer
    //   982: invokestatic lIIIIIIllllIIIll : (I)Z
    //   985: ifeq -> 1114
    //   988: <illegal opcode> 62 : ()Lme/stupitdog/bhp/f9;
    //   993: <illegal opcode> 63 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   998: aload_1
    //   999: <illegal opcode> 64 : (Lnet/minecraft/entity/Entity;)Ljava/util/UUID;
    //   1004: <illegal opcode> 65 : (Ljava/util/UUID;)Ljava/lang/String;
    //   1009: <illegal opcode> 66 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)Z
    //   1014: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   1017: ifeq -> 1114
    //   1020: aload_0
    //   1021: <illegal opcode> 67 : (Lme/stupitdog/bhp/f0i;)Lme/stupitdog/bhp/ao;
    //   1026: ldc2_w 20
    //   1029: <illegal opcode> 68 : (Lme/stupitdog/bhp/ao;J)Z
    //   1034: invokestatic lIIIIIIllllIIIll : (I)Z
    //   1037: ifeq -> 1114
    //   1040: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1045: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1050: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1055: new net/minecraft/network/play/client/CPacketUseEntity
    //   1058: dup
    //   1059: aload_1
    //   1060: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   1063: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1068: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1073: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1078: <illegal opcode> 40 : ()Lnet/minecraft/util/EnumHand;
    //   1083: <illegal opcode> 69 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   1088: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   1093: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1098: <illegal opcode> 70 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   1103: aload_0
    //   1104: <illegal opcode> 67 : (Lme/stupitdog/bhp/f0i;)Lme/stupitdog/bhp/ao;
    //   1109: <illegal opcode> 71 : (Lme/stupitdog/bhp/ao;)V
    //   1114: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   526	262	1	lllllllllllllllIllIllIlllllIlIlI	Lnet/minecraft/block/Block;
    //   971	143	1	lllllllllllllllIllIllIlllllIlIIl	Lnet/minecraft/entity/Entity;
    //   0	1115	0	lllllllllllllllIllIllIlllllIlIII	Lme/stupitdog/bhp/f0i;
  }
  
  private void placeBlock(BlockPos lllllllllllllllIllIllIlllllIIllI, EnumFacing lllllllllllllllIllIllIlllllIIlIl) {
    // Byte code:
    //   0: aload_1
    //   1: aload_2
    //   2: <illegal opcode> 51 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   7: astore_3
    //   8: aload_2
    //   9: <illegal opcode> 50 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   14: astore #4
    //   16: aload_0
    //   17: <illegal opcode> 72 : (Lme/stupitdog/bhp/f0i;)Z
    //   22: invokestatic lIIIIIIllllIIIIl : (I)Z
    //   25: ifeq -> 81
    //   28: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   33: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   38: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   43: new net/minecraft/network/play/client/CPacketEntityAction
    //   46: dup
    //   47: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 73 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   62: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   65: <illegal opcode> 38 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   70: aload_0
    //   71: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   74: iconst_1
    //   75: iaload
    //   76: <illegal opcode> 39 : (Lme/stupitdog/bhp/f0i;Z)V
    //   81: new net/minecraft/util/math/Vec3d
    //   84: dup
    //   85: aload_3
    //   86: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   89: ldc2_w 0.5
    //   92: ldc2_w 0.5
    //   95: ldc2_w 0.5
    //   98: <illegal opcode> 74 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   103: new net/minecraft/util/math/Vec3d
    //   106: dup
    //   107: aload #4
    //   109: <illegal opcode> 75 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   114: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   117: ldc2_w 0.5
    //   120: <illegal opcode> 76 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   125: <illegal opcode> 77 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   130: astore #5
    //   132: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   137: <illegal opcode> 42 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   142: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   147: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   152: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   157: <illegal opcode> 48 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   162: aload_3
    //   163: aload #4
    //   165: aload #5
    //   167: <illegal opcode> 40 : ()Lnet/minecraft/util/EnumHand;
    //   172: <illegal opcode> 78 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   177: ldc ''
    //   179: invokevirtual length : ()I
    //   182: pop2
    //   183: <illegal opcode> 13 : ()Lnet/minecraft/client/Minecraft;
    //   188: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   193: <illegal opcode> 40 : ()Lnet/minecraft/util/EnumHand;
    //   198: <illegal opcode> 69 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   203: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	204	0	lllllllllllllllIllIllIlllllIIlll	Lme/stupitdog/bhp/f0i;
    //   0	204	1	lllllllllllllllIllIllIlllllIIllI	Lnet/minecraft/util/math/BlockPos;
    //   0	204	2	lllllllllllllllIllIllIlllllIIlIl	Lnet/minecraft/util/EnumFacing;
    //   8	196	3	lllllllllllllllIllIllIlllllIIlII	Lnet/minecraft/util/math/BlockPos;
    //   16	188	4	lllllllllllllllIllIllIlllllIIIll	Lnet/minecraft/util/EnumFacing;
    //   132	72	5	lllllllllllllllIllIllIlllllIIIlI	Lnet/minecraft/util/math/Vec3d;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIIIlllIlllIl : ()V
    //   3: invokestatic lIIIIIIlllIIlIlI : ()V
    //   6: invokestatic lIIIIIIlllIIlIIl : ()V
    //   9: invokestatic lIIIIIIllIlllIll : ()V
    //   12: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   15: bipush #11
    //   17: iaload
    //   18: anewarray net/minecraft/block/Block
    //   21: dup
    //   22: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   25: iconst_0
    //   26: iaload
    //   27: <illegal opcode> 82 : ()Lnet/minecraft/block/Block;
    //   32: aastore
    //   33: dup
    //   34: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   37: iconst_1
    //   38: iaload
    //   39: <illegal opcode> 83 : ()Lnet/minecraft/block/Block;
    //   44: aastore
    //   45: dup
    //   46: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   49: iconst_2
    //   50: iaload
    //   51: <illegal opcode> 84 : ()Lnet/minecraft/block/Block;
    //   56: aastore
    //   57: dup
    //   58: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   61: iconst_5
    //   62: iaload
    //   63: <illegal opcode> 85 : ()Lnet/minecraft/block/Block;
    //   68: aastore
    //   69: dup
    //   70: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   73: bipush #6
    //   75: iaload
    //   76: <illegal opcode> 86 : ()Lnet/minecraft/block/Block;
    //   81: aastore
    //   82: dup
    //   83: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   86: bipush #7
    //   88: iaload
    //   89: <illegal opcode> 87 : ()Lnet/minecraft/block/Block;
    //   94: aastore
    //   95: dup
    //   96: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   99: bipush #8
    //   101: iaload
    //   102: <illegal opcode> 88 : ()Lnet/minecraft/block/Block;
    //   107: aastore
    //   108: dup
    //   109: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   112: bipush #9
    //   114: iaload
    //   115: <illegal opcode> 89 : ()Lnet/minecraft/block/Block;
    //   120: aastore
    //   121: dup
    //   122: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   125: bipush #10
    //   127: iaload
    //   128: <illegal opcode> 90 : ()Lnet/minecraft/block/Block;
    //   133: aastore
    //   134: dup
    //   135: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   138: iconst_4
    //   139: iaload
    //   140: <illegal opcode> 91 : ()Lnet/minecraft/block/Block;
    //   145: aastore
    //   146: dup
    //   147: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   150: bipush #12
    //   152: iaload
    //   153: <illegal opcode> 92 : ()Lnet/minecraft/block/Block;
    //   158: aastore
    //   159: dup
    //   160: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   163: bipush #13
    //   165: iaload
    //   166: <illegal opcode> 93 : ()Lnet/minecraft/block/Block;
    //   171: aastore
    //   172: dup
    //   173: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   176: bipush #14
    //   178: iaload
    //   179: <illegal opcode> 94 : ()Lnet/minecraft/block/Block;
    //   184: aastore
    //   185: dup
    //   186: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   189: bipush #15
    //   191: iaload
    //   192: <illegal opcode> 95 : ()Lnet/minecraft/block/Block;
    //   197: aastore
    //   198: dup
    //   199: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   202: bipush #16
    //   204: iaload
    //   205: <illegal opcode> 96 : ()Lnet/minecraft/block/Block;
    //   210: aastore
    //   211: dup
    //   212: getstatic me/stupitdog/bhp/f0i.llIIIIIlIllIll : [I
    //   215: bipush #17
    //   217: iaload
    //   218: <illegal opcode> 97 : ()Lnet/minecraft/block/Block;
    //   223: aastore
    //   224: <illegal opcode> 98 : ([Ljava/lang/Object;)Ljava/util/List;
    //   229: putstatic me/stupitdog/bhp/f0i.shulkerList : Ljava/util/List;
    //   232: return
  }
  
  private static CallSite llllllIlllIIllI(MethodHandles.Lookup lllllllllllllllIllIllIllllIlIlII, String lllllllllllllllIllIllIllllIlIIll, MethodType lllllllllllllllIllIllIllllIlIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIllllIllIlI = lIllllIlIIIlll[Integer.parseInt(lllllllllllllllIllIllIllllIlIIll)].split(llIIIIIlIlIIII[llIIIIIlIllIll[4]]);
      Class<?> lllllllllllllllIllIllIllllIllIIl = Class.forName(lllllllllllllllIllIllIllllIllIlI[llIIIIIlIllIll[0]]);
      String lllllllllllllllIllIllIllllIllIII = lllllllllllllllIllIllIllllIllIlI[llIIIIIlIllIll[1]];
      MethodHandle lllllllllllllllIllIllIllllIlIlll = null;
      int lllllllllllllllIllIllIllllIlIllI = lllllllllllllllIllIllIllllIllIlI[llIIIIIlIllIll[5]].length();
      if (lIIIIIIllllIlIIl(lllllllllllllllIllIllIllllIlIllI, llIIIIIlIllIll[2])) {
        MethodType lllllllllllllllIllIllIllllIlllII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIllllIllIlI[llIIIIIlIllIll[2]], f0i.class.getClassLoader());
        if (lIIIIIIllllIIlII(lllllllllllllllIllIllIllllIlIllI, llIIIIIlIllIll[2])) {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findVirtual(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIlllII);
          "".length();
          if ((((0x80 ^ 0xA5) << " ".length() ^ 0x72 ^ 0x23) << " ".length() & ((0x4F ^ 0x36 ^ (0x64 ^ 0x55) << " ".length()) << " ".length() ^ -" ".length())) > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findStatic(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIlllII);
        } 
        "".length();
        if (-(0x48 ^ 0x4C) > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIllllIllIll = lIllllIlIIlIII[Integer.parseInt(lllllllllllllllIllIllIllllIllIlI[llIIIIIlIllIll[2]])];
        if (lIIIIIIllllIIlII(lllllllllllllllIllIllIllllIlIllI, llIIIIIlIllIll[5])) {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findGetter(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIllIll);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else if (lIIIIIIllllIIlII(lllllllllllllllIllIllIllllIlIllI, llIIIIIlIllIll[6])) {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findStaticGetter(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIllIll);
          "".length();
          if (((0x33 ^ 0x3A) & (0x47 ^ 0x4E ^ 0xFFFFFFFF)) > 0)
            return null; 
        } else if (lIIIIIIllllIIlII(lllllllllllllllIllIllIllllIlIllI, llIIIIIlIllIll[7])) {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findSetter(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIllIll);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIllllIlIlll = lllllllllllllllIllIllIllllIlIlII.findStaticSetter(lllllllllllllllIllIllIllllIllIIl, lllllllllllllllIllIllIllllIllIII, lllllllllllllllIllIllIllllIllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIllllIlIlll);
    } catch (Exception lllllllllllllllIllIllIllllIlIlIl) {
      lllllllllllllllIllIllIllllIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIllIlllIll() {
    lIllllIlIIIlll = new String[llIIIIIlIllIll[18]];
    lIllllIlIIIlll[llIIIIIlIllIll[11]] = llIIIIIlIlIIII[llIIIIIlIllIll[12]];
    lIllllIlIIIlll[llIIIIIlIllIll[14]] = llIIIIIlIlIIII[llIIIIIlIllIll[13]];
    lIllllIlIIIlll[llIIIIIlIllIll[5]] = llIIIIIlIlIIII[llIIIIIlIllIll[14]];
    lIllllIlIIIlll[llIIIIIlIllIll[19]] = llIIIIIlIlIIII[llIIIIIlIllIll[15]];
    lIllllIlIIIlll[llIIIIIlIllIll[10]] = llIIIIIlIlIIII[llIIIIIlIllIll[16]];
    lIllllIlIIIlll[llIIIIIlIllIll[20]] = llIIIIIlIlIIII[llIIIIIlIllIll[17]];
    lIllllIlIIIlll[llIIIIIlIllIll[21]] = llIIIIIlIlIIII[llIIIIIlIllIll[11]];
    lIllllIlIIIlll[llIIIIIlIllIll[22]] = llIIIIIlIlIIII[llIIIIIlIllIll[23]];
    lIllllIlIIIlll[llIIIIIlIllIll[24]] = llIIIIIlIlIIII[llIIIIIlIllIll[25]];
    lIllllIlIIIlll[llIIIIIlIllIll[4]] = llIIIIIlIlIIII[llIIIIIlIllIll[26]];
    lIllllIlIIIlll[llIIIIIlIllIll[15]] = llIIIIIlIlIIII[llIIIIIlIllIll[19]];
    lIllllIlIIIlll[llIIIIIlIllIll[17]] = llIIIIIlIlIIII[llIIIIIlIllIll[27]];
    lIllllIlIIIlll[llIIIIIlIllIll[28]] = llIIIIIlIlIIII[llIIIIIlIllIll[29]];
    lIllllIlIIIlll[llIIIIIlIllIll[30]] = llIIIIIlIlIIII[llIIIIIlIllIll[31]];
    lIllllIlIIIlll[llIIIIIlIllIll[32]] = llIIIIIlIlIIII[llIIIIIlIllIll[33]];
    lIllllIlIIIlll[llIIIIIlIllIll[34]] = llIIIIIlIlIIII[llIIIIIlIllIll[35]];
    lIllllIlIIIlll[llIIIIIlIllIll[36]] = llIIIIIlIlIIII[llIIIIIlIllIll[37]];
    lIllllIlIIIlll[llIIIIIlIllIll[38]] = llIIIIIlIlIIII[llIIIIIlIllIll[39]];
    lIllllIlIIIlll[llIIIIIlIllIll[40]] = llIIIIIlIlIIII[llIIIIIlIllIll[41]];
    lIllllIlIIIlll[llIIIIIlIllIll[8]] = llIIIIIlIlIIII[llIIIIIlIllIll[42]];
    lIllllIlIIIlll[llIIIIIlIllIll[43]] = llIIIIIlIlIIII[llIIIIIlIllIll[40]];
    lIllllIlIIIlll[llIIIIIlIllIll[44]] = llIIIIIlIlIIII[llIIIIIlIllIll[45]];
    lIllllIlIIIlll[llIIIIIlIllIll[45]] = llIIIIIlIlIIII[llIIIIIlIllIll[46]];
    lIllllIlIIIlll[llIIIIIlIllIll[47]] = llIIIIIlIlIIII[llIIIIIlIllIll[48]];
    lIllllIlIIIlll[llIIIIIlIllIll[0]] = llIIIIIlIlIIII[llIIIIIlIllIll[49]];
    lIllllIlIIIlll[llIIIIIlIllIll[50]] = llIIIIIlIlIIII[llIIIIIlIllIll[51]];
    lIllllIlIIIlll[llIIIIIlIllIll[52]] = llIIIIIlIlIIII[llIIIIIlIllIll[53]];
    lIllllIlIIIlll[llIIIIIlIllIll[54]] = llIIIIIlIlIIII[llIIIIIlIllIll[30]];
    lIllllIlIIIlll[llIIIIIlIllIll[55]] = llIIIIIlIlIIII[llIIIIIlIllIll[56]];
    lIllllIlIIIlll[llIIIIIlIllIll[57]] = llIIIIIlIlIIII[llIIIIIlIllIll[58]];
    lIllllIlIIIlll[llIIIIIlIllIll[59]] = llIIIIIlIlIIII[llIIIIIlIllIll[60]];
    lIllllIlIIIlll[llIIIIIlIllIll[61]] = llIIIIIlIlIIII[llIIIIIlIllIll[62]];
    lIllllIlIIIlll[llIIIIIlIllIll[29]] = llIIIIIlIlIIII[llIIIIIlIllIll[63]];
    lIllllIlIIIlll[llIIIIIlIllIll[64]] = llIIIIIlIlIIII[llIIIIIlIllIll[65]];
    lIllllIlIIIlll[llIIIIIlIllIll[66]] = llIIIIIlIlIIII[llIIIIIlIllIll[67]];
    lIllllIlIIIlll[llIIIIIlIllIll[1]] = llIIIIIlIlIIII[llIIIIIlIllIll[47]];
    lIllllIlIIIlll[llIIIIIlIllIll[41]] = llIIIIIlIlIIII[llIIIIIlIllIll[28]];
    lIllllIlIIIlll[llIIIIIlIllIll[68]] = llIIIIIlIlIIII[llIIIIIlIllIll[69]];
    lIllllIlIIIlll[llIIIIIlIllIll[13]] = llIIIIIlIlIIII[llIIIIIlIllIll[70]];
    lIllllIlIIIlll[llIIIIIlIllIll[71]] = llIIIIIlIlIIII[llIIIIIlIllIll[72]];
    lIllllIlIIIlll[llIIIIIlIllIll[53]] = llIIIIIlIlIIII[llIIIIIlIllIll[73]];
    lIllllIlIIIlll[llIIIIIlIllIll[69]] = llIIIIIlIlIIII[llIIIIIlIllIll[64]];
    lIllllIlIIIlll[llIIIIIlIllIll[46]] = llIIIIIlIlIIII[llIIIIIlIllIll[74]];
    lIllllIlIIIlll[llIIIIIlIllIll[56]] = llIIIIIlIlIIII[llIIIIIlIllIll[66]];
    lIllllIlIIIlll[llIIIIIlIllIll[75]] = llIIIIIlIlIIII[llIIIIIlIllIll[52]];
    lIllllIlIIIlll[llIIIIIlIllIll[12]] = llIIIIIlIlIIII[llIIIIIlIllIll[55]];
    lIllllIlIIIlll[llIIIIIlIllIll[49]] = llIIIIIlIlIIII[llIIIIIlIllIll[76]];
    lIllllIlIIIlll[llIIIIIlIllIll[77]] = llIIIIIlIlIIII[llIIIIIlIllIll[77]];
    lIllllIlIIIlll[llIIIIIlIllIll[33]] = llIIIIIlIlIIII[llIIIIIlIllIll[78]];
    lIllllIlIIIlll[llIIIIIlIllIll[79]] = llIIIIIlIlIIII[llIIIIIlIllIll[80]];
    lIllllIlIIIlll[llIIIIIlIllIll[72]] = llIIIIIlIlIIII[llIIIIIlIllIll[57]];
    lIllllIlIIIlll[llIIIIIlIllIll[81]] = llIIIIIlIlIIII[llIIIIIlIllIll[82]];
    lIllllIlIIIlll[llIIIIIlIllIll[65]] = llIIIIIlIlIIII[llIIIIIlIllIll[83]];
    lIllllIlIIIlll[llIIIIIlIllIll[84]] = llIIIIIlIlIIII[llIIIIIlIllIll[85]];
    lIllllIlIIIlll[llIIIIIlIllIll[26]] = llIIIIIlIlIIII[llIIIIIlIllIll[86]];
    lIllllIlIIIlll[llIIIIIlIllIll[58]] = llIIIIIlIlIIII[llIIIIIlIllIll[32]];
    lIllllIlIIIlll[llIIIIIlIllIll[67]] = llIIIIIlIlIIII[llIIIIIlIllIll[75]];
    lIllllIlIIIlll[llIIIIIlIllIll[87]] = llIIIIIlIlIIII[llIIIIIlIllIll[68]];
    lIllllIlIIIlll[llIIIIIlIllIll[83]] = llIIIIIlIlIIII[llIIIIIlIllIll[88]];
    lIllllIlIIIlll[llIIIIIlIllIll[6]] = llIIIIIlIlIIII[llIIIIIlIllIll[34]];
    lIllllIlIIIlll[llIIIIIlIllIll[89]] = llIIIIIlIlIIII[llIIIIIlIllIll[44]];
    lIllllIlIIIlll[llIIIIIlIllIll[23]] = llIIIIIlIlIIII[llIIIIIlIllIll[90]];
    lIllllIlIIIlll[llIIIIIlIllIll[91]] = llIIIIIlIlIIII[llIIIIIlIllIll[50]];
    lIllllIlIIIlll[llIIIIIlIllIll[82]] = llIIIIIlIlIIII[llIIIIIlIllIll[92]];
    lIllllIlIIIlll[llIIIIIlIllIll[27]] = llIIIIIlIlIIII[llIIIIIlIllIll[93]];
    lIllllIlIIIlll[llIIIIIlIllIll[94]] = llIIIIIlIlIIII[llIIIIIlIllIll[24]];
    lIllllIlIIIlll[llIIIIIlIllIll[60]] = llIIIIIlIlIIII[llIIIIIlIllIll[87]];
    lIllllIlIIIlll[llIIIIIlIllIll[63]] = llIIIIIlIlIIII[llIIIIIlIllIll[95]];
    lIllllIlIIIlll[llIIIIIlIllIll[25]] = llIIIIIlIlIIII[llIIIIIlIllIll[43]];
    lIllllIlIIIlll[llIIIIIlIllIll[31]] = llIIIIIlIlIIII[llIIIIIlIllIll[96]];
    lIllllIlIIIlll[llIIIIIlIllIll[86]] = llIIIIIlIlIIII[llIIIIIlIllIll[81]];
    lIllllIlIIIlll[llIIIIIlIllIll[97]] = llIIIIIlIlIIII[llIIIIIlIllIll[79]];
    lIllllIlIIIlll[llIIIIIlIllIll[98]] = llIIIIIlIlIIII[llIIIIIlIllIll[20]];
    lIllllIlIIIlll[llIIIIIlIllIll[51]] = llIIIIIlIlIIII[llIIIIIlIllIll[21]];
    lIllllIlIIIlll[llIIIIIlIllIll[85]] = llIIIIIlIlIIII[llIIIIIlIllIll[61]];
    lIllllIlIIIlll[llIIIIIlIllIll[35]] = llIIIIIlIlIIII[llIIIIIlIllIll[22]];
    lIllllIlIIIlll[llIIIIIlIllIll[70]] = llIIIIIlIlIIII[llIIIIIlIllIll[59]];
    lIllllIlIIIlll[llIIIIIlIllIll[96]] = llIIIIIlIlIIII[llIIIIIlIllIll[98]];
    lIllllIlIIIlll[llIIIIIlIllIll[62]] = llIIIIIlIlIIII[llIIIIIlIllIll[38]];
    lIllllIlIIIlll[llIIIIIlIllIll[16]] = llIIIIIlIlIIII[llIIIIIlIllIll[99]];
    lIllllIlIIIlll[llIIIIIlIllIll[93]] = llIIIIIlIlIIII[llIIIIIlIllIll[100]];
    lIllllIlIIIlll[llIIIIIlIllIll[42]] = llIIIIIlIlIIII[llIIIIIlIllIll[89]];
    lIllllIlIIIlll[llIIIIIlIllIll[37]] = llIIIIIlIlIIII[llIIIIIlIllIll[36]];
    lIllllIlIIIlll[llIIIIIlIllIll[74]] = llIIIIIlIlIIII[llIIIIIlIllIll[94]];
    lIllllIlIIIlll[llIIIIIlIllIll[2]] = llIIIIIlIlIIII[llIIIIIlIllIll[84]];
    lIllllIlIIIlll[llIIIIIlIllIll[78]] = llIIIIIlIlIIII[llIIIIIlIllIll[97]];
    lIllllIlIIIlll[llIIIIIlIllIll[99]] = llIIIIIlIlIIII[llIIIIIlIllIll[54]];
    lIllllIlIIIlll[llIIIIIlIllIll[39]] = llIIIIIlIlIIII[llIIIIIlIllIll[91]];
    lIllllIlIIIlll[llIIIIIlIllIll[80]] = llIIIIIlIlIIII[llIIIIIlIllIll[71]];
    lIllllIlIIIlll[llIIIIIlIllIll[88]] = llIIIIIlIlIIII[llIIIIIlIllIll[18]];
    lIllllIlIIIlll[llIIIIIlIllIll[95]] = llIIIIIlIlIIII[llIIIIIlIllIll[101]];
    lIllllIlIIIlll[llIIIIIlIllIll[7]] = llIIIIIlIlIIII[llIIIIIlIllIll[102]];
    lIllllIlIIIlll[llIIIIIlIllIll[76]] = llIIIIIlIlIIII[llIIIIIlIllIll[103]];
    lIllllIlIIIlll[llIIIIIlIllIll[73]] = llIIIIIlIlIIII[llIIIIIlIllIll[104]];
    lIllllIlIIIlll[llIIIIIlIllIll[100]] = llIIIIIlIlIIII[llIIIIIlIllIll[105]];
    lIllllIlIIIlll[llIIIIIlIllIll[90]] = llIIIIIlIlIIII[llIIIIIlIllIll[106]];
    lIllllIlIIIlll[llIIIIIlIllIll[92]] = llIIIIIlIlIIII[llIIIIIlIllIll[107]];
    lIllllIlIIIlll[llIIIIIlIllIll[48]] = llIIIIIlIlIIII[llIIIIIlIllIll[108]];
    lIllllIlIIIlll[llIIIIIlIllIll[9]] = llIIIIIlIlIIII[llIIIIIlIllIll[109]];
    lIllllIlIIlIII = new Class[llIIIIIlIllIll[33]];
    lIllllIlIIlIII[llIIIIIlIllIll[17]] = boolean.class;
    lIllllIlIIlIII[llIIIIIlIllIll[19]] = ClickType.class;
    lIllllIlIIlIII[llIIIIIlIllIll[10]] = List.class;
    lIllllIlIIlIII[llIIIIIlIllIll[11]] = EnumHand.class;
    lIllllIlIIlIII[llIIIIIlIllIll[26]] = Container.class;
    lIllllIlIIlIII[llIIIIIlIllIll[4]] = Block.class;
    lIllllIlIIlIII[llIIIIIlIllIll[6]] = EntityPlayerSP.class;
    lIllllIlIIlIII[llIIIIIlIllIll[31]] = a.class;
    lIllllIlIIlIII[llIIIIIlIllIll[8]] = ItemStack.class;
    lIllllIlIIlIII[llIIIIIlIllIll[1]] = ao.class;
    lIllllIlIIlIII[llIIIIIlIllIll[12]] = RayTraceResult.class;
    lIllllIlIIlIII[llIIIIIlIllIll[27]] = WorldClient.class;
    lIllllIlIIlIII[llIIIIIlIllIll[14]] = EnumFacing.class;
    lIllllIlIIlIII[llIIIIIlIllIll[23]] = GuiScreen.class;
    lIllllIlIIlIII[llIIIIIlIllIll[16]] = CPacketEntityAction.Action.class;
    lIllllIlIIlIII[llIIIIIlIllIll[5]] = Minecraft.class;
    lIllllIlIIlIII[llIIIIIlIllIll[29]] = f9.class;
    lIllllIlIIlIII[llIIIIIlIllIll[9]] = BlockHopper.class;
    lIllllIlIIlIII[llIIIIIlIllIll[0]] = f13.class;
    lIllllIlIIlIII[llIIIIIlIllIll[15]] = NetHandlerPlayClient.class;
    lIllllIlIIlIII[llIIIIIlIllIll[7]] = InventoryPlayer.class;
    lIllllIlIIlIII[llIIIIIlIllIll[25]] = PlayerControllerMP.class;
    lIllllIlIIlIII[llIIIIIlIllIll[13]] = BlockPos.class;
    lIllllIlIIlIII[llIIIIIlIllIll[2]] = int.class;
  }
  
  private static void lIIIIIIlllIIlIIl() {
    llIIIIIlIlIIII = new String[llIIIIIlIllIll[110]];
    llIIIIIlIlIIII[llIIIIIlIllIll[0]] = lIIIIIIllIllllII(llIIIIIlIlIllI[llIIIIIlIllIll[0]], llIIIIIlIlIllI[llIIIIIlIllIll[1]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[1]] = lIIIIIIllIllllIl(llIIIIIlIlIllI[llIIIIIlIllIll[2]], llIIIIIlIlIllI[llIIIIIlIllIll[5]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[2]] = lIIIIIIllIllllIl(llIIIIIlIlIllI[llIIIIIlIllIll[6]], llIIIIIlIlIllI[llIIIIIlIllIll[7]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[5]] = lIIIIIIllIllllIl(llIIIIIlIlIllI[llIIIIIlIllIll[8]], llIIIIIlIlIllI[llIIIIIlIllIll[9]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[6]] = lIIIIIIllIllllII(llIIIIIlIlIllI[llIIIIIlIllIll[10]], llIIIIIlIlIllI[llIIIIIlIllIll[4]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[7]] = lIIIIIIllIlllllI(llIIIIIlIlIllI[llIIIIIlIllIll[12]], llIIIIIlIlIllI[llIIIIIlIllIll[13]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[8]] = lIIIIIIllIllllII(llIIIIIlIlIllI[llIIIIIlIllIll[14]], llIIIIIlIlIllI[llIIIIIlIllIll[15]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[9]] = lIIIIIIllIllllII(llIIIIIlIlIllI[llIIIIIlIllIll[16]], llIIIIIlIlIllI[llIIIIIlIllIll[17]]);
    llIIIIIlIlIIII[llIIIIIlIllIll[10]] = lIIIIIIllIllllII("HCYgBT4DDiYBNCkUMANidQwIUT8oE3UdPigMPB82ZwYhUScmCzwVcTMGJxY0M0Z1FTg0BjcdOCkAe19/", "GgUqQ");
    llIIIIIlIlIIII[llIIIIIlIllIll[4]] = lIIIIIIllIllllIl("Mg681uu2tlU=", "eepGA");
    llIIIIIlIlIIII[llIIIIIlIllIll[12]] = lIIIIIIllIlllllI("Vzs8Cvd9VPwMenWcH3obhJygRASkUEfrTItmQg0LnBDnDfLcoUDw3X6OqA1UwUC9MpKplXAviKqjpF+7gkMrpykS0dd1y5rCkVlXuwq2+oVmrdP/9UcBI2lNQ+kc2mit", "Bxyal");
    llIIIIIlIlIIII[llIIIIIlIllIll[13]] = lIIIIIIllIllllIl("BJQmEq3/Q1iPB/M4XFbmdtQy9YSKRx+FnB4P/IZyJkVC5FftqO8ZIw==", "OtHpa");
    llIIIIIlIlIIII[llIIIIIlIllIll[14]] = lIIIIIIllIlllllI("sPS8kGQNWfnI1c4TWHq6SF/XopGtm9Tus671fUlKbB1CqFOASXUdT4tWNdm9Spjy", "bGxVU");
    llIIIIIlIlIIII[llIIIIIlIllIll[15]] = lIIIIIIllIlllllI("qCxkuWOd2KIEb3h6tmk+B6k3GUUELoNv0Swjk1cmwQFn2UIP57LBvkWE4RFrGkpPKKRbkUWvTNo=", "EsHBx");
    llIIIIIlIlIIII[llIIIIIlIllIll[16]] = lIIIIIIllIllllIl("1xdP1PohmMbEjlrqFc8RTttS49K8fHKM3SfYlDctkXCiWYRUH3k6GQ==", "dylzG");
    llIIIIIlIlIIII[llIIIIIlIllIll[17]] = lIIIIIIllIllllIl("DWUgaicL9J6wMqFxH8Q8HGxpjuR7sb6l3o3PvaiaR2jvZqM83opoB9+5LingIqzijt4TZkIBUMg=", "KZIQA");
    llIIIIIlIlIIII[llIIIIIlIllIll[11]] = lIIIIIIllIlllllI("tIOEYgwV0OAx21yyMb1GV1ikUysIe+4tvPSN/2dxzz/1vhMw+/9YO/L0zZdRjybKCSl+17mCpmc=", "SJGjS");
    llIIIIIlIlIIII[llIIIIIlIllIll[23]] = lIIIIIIllIllllII("FiwNfxkRJxwyBhkvDX8dFiANfzYUJho6B0IvEDQYHBZIaERBcUkOEBdzQGtUWGlZ", "xIyQt");
    llIIIIIlIlIIII[llIIIIIlIllIll[25]] = lIIIIIIllIllllII("PC4NdzQ7JRw6KzMtDXcsJiIVdxw8PhQfODEiFz5jND4XOgZjfE9uamIUFGNxewcXPC19JhA3PDE5GD8tfT4NMDV9JhgtMX0dHDpqO3BDeXk=", "RKyYY");
    llIIIIIlIlIIII[llIIIIIlIllIll[26]] = lIIIIIIllIlllllI("qhiYBVBhkLfleNG5ohh1a8MnhUfKNMPYebw4p5smJh9mMjgojwjDA35iC1UP4CaA", "IYWUs");
    llIIIIIlIlIIII[llIIIIIlIllIll[19]] = lIIIIIIllIllllIl("fEKOpotaZLRcCij6lBPNvhRTEvyAvDu/O0Pk4WsJL6k=", "mtjMX");
    llIIIIIlIlIIII[llIIIIIlIllIll[27]] = lIIIIIIllIllllIl("Rnhh0LKnuSr4P0Djf++fXEcV1IXbicd9XJ9ZUQ3lVrzBQGcEQTkv0WqRcxq3W71cAJhViKYy64SfZKO/bl2bWQ==", "FZFxH");
    llIIIIIlIlIIII[llIIIIIlIllIll[29]] = lIIIIIIllIllllII("AykSfAAEIgMxHwwqEnwOASUDPBlDIRM+GQQ8CjMUCD5IAgEMNQMgLgIiEiACASADICA9dgAnAw4TV2paXXVeDQxXZC8bJCEiAyZCACUINw4fLQAmQgQiEDcDGSMUK0IuIA8xBjk1FjdWISIDJkIAJQg3Dh8tACZCCCISOxkUYxY+DBQpFH0oAzgPJhQ9IAcrCB93Tx4DCDhJPwQDKQUgDAs4STsZCCFJGxkIITUmDA4nXWhNTQ==", "mLfRm");
    llIIIIIlIlIIII[llIIIIIlIllIll[31]] = lIIIIIIllIllllII("OwQfYTw8Dw4sIzQHH2E/MBUcICM+TxsjMCxPCCM4MA8fYRIFAAgkNCEkBTs4IRgqLCU8DgVrEDYVAiA/bzI/AAEKMiUKEB4oJQhrZFVRb3F1QQ==", "UakOQ");
    llIIIIIlIlIIII[llIIIIIlIllIll[33]] = lIIIIIIllIlllllI("ccDo8aNcI09S/23JHcZ1NACZ2deNziMbELaCndDozqOX1PmySkYqf4V/LgF6gBT5", "vWHnx");
    llIIIIIlIlIIII[llIIIIIlIllIll[35]] = lIIIIIIllIllllII("HBM1fh4bGCQzARMQNX4QHh8kPgdcEy8kGgYPbxUdBh81KSMeFzg1ASEmezYGHBUeYUtGQHFpLBNMaRwdFwJuPRocEyIiEhQCbiUHGxpuFR0HGwkxHRZNaAZJUlY=", "rvAPs");
    llIIIIIlIlIIII[llIIIIIlIllIll[37]] = lIIIIIIllIllllII("PxAnQS84GzYMMDATJ0ErPxwnQQA9GjAEMWsTOgouNSpiVnJoTWQwJidPalVicVVz", "QuSoB");
    llIIIIIlIlIIII[llIIIIIlIllIll[39]] = lIIIIIIllIllllII("DwIHTRUICRYACgABB00RDw4HTToNCBAIC1sBGgYUBThCWkhYX0A8HBNdSllYQUdT", "agscx");
    llIIIIIlIlIIII[llIIIIIlIllIll[41]] = lIIIIIIllIllllII("GwENQygcChwONxQCDUMwAQ0VQygUEBFDBxkLGgYVGhdDCzAbByZcckJdQVkaFF5RRAkbAQ1CKBwKHA43FAINQjABDRVCKBQQEUIHGQsaBhUaF0JXZVU=", "udymE");
    llIIIIIlIlIIII[llIIIIIlIllIll[42]] = lIIIIIIllIllllII("NRxZBiYtCR4BNjceWRc6KFcRRTtiERgFIj0LJBk9LENFT3J4WVdV", "XywuR");
    llIIIIIlIlIIII[llIIIIIlIllIll[40]] = lIIIIIIllIlllllI("NJvzC5nBFFWX9wRaZik46+XR1GrHBkRgjfbjk6iOEoFCX3rS5E5+1/FyIDTM3GUowH00UETOuKPI4TZY4h8jIbZpNeNuCLiHWhA6ivibDKcwzwcCD5qmek97Lli6QlLbnX+IoCOrbhdhVGeZyT39lXkAetMz6Oq13OngI0lDiOdAcopbqH8dq43245OojhKBXAnngz5z3kbYWS2A4TjdIU6Ku0JCgGHqVjX4GSby0ukIVfij9UA9KvqyjIsig1JZeQB60zPo6rW44N4Osoc8Bi7jssjFmwLTHsGBQnRS1AaW6EvtY6aljDra1Tnwm+EVVNNCcWH9gjc8D7aXFNtki06Ku0JCgGHqVjX4GSby0unQQusyoGqEofQ3e9zXcWfZWhA6ivibDKf9VQTZYyerxtUgSCdsWrPf4Y8nmAxbl/Yh8+7KOc8ulQ==", "xSckY");
    llIIIIIlIlIIII[llIIIIIlIllIll[45]] = lIIIIIIllIllllII("DCwSeDgLJwM1JwMvEng2DiADOCFMLAgiPBYwSBM7FiASLwUOKB8zJzEZXDAgDCo5Z21WcVRnCgEQXH58NHNGdg==", "bIfVU");
    llIIIIIlIlIIII[llIIIIIlIllIll[46]] = lIIIIIIllIllllII("KRd+JTExAjkiISsVfjQtNFw2Zix+Ajw3JiEmMSQiIQZqZ3R+UnB2ZWQ=", "DrPVE");
    llIIIIIlIlIIII[llIIIIIlIllIll[48]] = lIIIIIIllIllllII("BD03XAMDNiYRHAs+N1wHBC4mHBoFKjpcLQYxIBk6EygmSD09GRNIXFpiY1JOSg==", "jXCrn");
    llIIIIIlIlIIII[llIIIIIlIllIll[49]] = lIIIIIIllIllllII("BAFNCxIcFAoMAgYDTRoOGUoFSVVTJyw1JCgwWUhcSURDWA==", "idcxf");
    llIIIIIlIlIIII[llIIIIIlIllIll[51]] = lIIIIIIllIlllllI("jxH9ePxlngA++LrE7TaIRGgOSH/WZU7QusZb0XJ0ZXso0Yr0/m69iA==", "cibqG");
    llIIIIIlIlIIII[llIIIIIlIllIll[53]] = lIIIIIIllIllllIl("xcBk/j/A3YAqWPiXj41QBkRlul+v+1ddWra+tUwLr1GF3/zvII2weIC/YTuvAKp6QQjfv3+lwQWVurv6vUW3yw==", "IGRhn");
    llIIIIIlIlIIII[llIIIIIlIllIll[30]] = lIIIIIIllIllllII("IhwzRAIlFyIJHS0fM0QGIhAzRC0gFiQBHHYfLg8DKCZ2U191QHY1CzZDflBPbFln", "LyGjo");
    llIIIIIlIlIIII[llIIIIIlIllIll[56]] = lIIIIIIllIllllIl("8+L/vXFdmfJ6/c4PU5YCeFBAdmtIR+h7/Tb4f5MGgPCaKPeRcMC/IboCYegtheI7lDAREnoYQB92sVjcaIWVS3tT5XOedRLp", "Mdllx");
    llIIIIIlIlIIII[llIIIIIlIllIll[58]] = lIIIIIIllIllllIl("vcY5EvUGZfSibs96tC+WUTK5FRWCacwTZbXbWXcVZPNOQU3I4xFZCHzrW1oy0VXxSiwPAcIgRNP1+SICJ9iBs/Qzh06Acg1E9KWhOYHO/do=", "UchtT");
    llIIIIIlIlIIII[llIIIIIlIllIll[60]] = lIIIIIIllIllllII("LzEETwQoOhUCGyAyBE8ALz0ETystOxMKGnsyGQQFJQtBWFl4bEE+DTFuSVtJYXRQ", "ATpai");
    llIIIIIlIlIIII[llIIIIIlIllIll[62]] = lIIIIIIllIlllllI("NGEiwTWgEc7CJPxwzTGcQ5w8GHfagBiE2by5MiMjWbYblJuJCHaOMFAOkQddq0Jic4PAPwJyGlo=", "PPVvY");
    llIIIIIlIlIIII[llIIIIIlIllIll[63]] = lIIIIIIllIllllIl("QILJzzODoL7mS9bYJhbrknEFhycGFbKZeWynSBqD3pDccN4YQcyFh3ZLjcOVEFUVGrRfIL68gLE=", "NVpfr");
    llIIIIIlIlIIII[llIIIIIlIllIll[65]] = lIIIIIIllIlllllI("JEEDQZDgBBNDV8pfyPSifpHUV+6nLnI+WHiyrjc1sCeTPHqU/syKySZb3VdCx/LTPprHCoXh/5VJyspZIBKqgYT4/qeh7HicHDe0qnw5S1s+mscKheH/lUnKylkgEqqB+/EHGFbEa4T5MNPH5L5FaylvVyneFaWV", "JXChC");
    llIIIIIlIlIIII[llIIIIIlIllIll[67]] = lIIIIIIllIllllII("GgoWXjodAQcTJRUJFl41GAABG3kHGwMEMlomIBw4FwQxBDYAClgWIhoMPUFgQ11RQAgXVUpZGxoKFl86HQEHEyUVCRZfNRgAARt4NgMNEzxPVUJQ", "tobpW");
    llIIIIIlIlIIII[llIIIIIlIllIll[47]] = lIIIIIIllIlllllI("BhOXiSFvOOh3aRMl0wRiRqWMEvskV6pZMWksP32kBqqhV1ofgFl5sQ==", "SOTYE");
    llIIIIIlIlIIII[llIIIIIlIllIll[28]] = lIIIIIIllIlllllI("evQ68SUfWJy3WiIxQdAcU4seaniUsn/0+LFde9Fdy4lWGFK5X8JQAJJ5GRt1lPruIiHUMtJWNwg=", "rvyVf");
    llIIIIIlIlIIII[llIIIIIlIllIll[69]] = lIIIIIIllIllllIl("Pemc2R98UX6pE/4xHy/mZO/Qo/N3cWPH4LXKaonFZPyugctSIhnTig==", "tiGev");
    llIIIIIlIlIIII[llIIIIIlIllIll[70]] = lIIIIIIllIllllII("IAFGEDE4FAEXISIDRgEtPUoOUyx3Fg0HNjkLBgYWIQscWXd3REhD", "MdhcE");
    llIIIIIlIlIIII[llIIIIIlIllIll[72]] = lIIIIIIllIllllIl("9MaGStov9KoH4n38fB6ZPLKg4o1MKOOawQWoI+L+qlbE5ghssjwGKkR/wDb4k9Mjk9l4vbO2WGxpwHOZt4yNxg==", "bwTwt");
    llIIIIIlIlIIII[llIIIIIlIllIll[73]] = lIIIIIIllIlllllI("d532uho3kd/wZVbCiv/iSdQ9oo7TH540iGx7fOcvjC0mj6JuxaAZKzzzWfi+zx1NLDoEi0PCriKv/pRbCFWjqg==", "kyaQL");
    llIIIIIlIlIIII[llIIIIIlIllIll[64]] = lIIIIIIllIllllII("BCY+SyUDLS8GOgslPksrBiovCzxEJiQRIR46ZCAmHio+HBgGIjMAOjkTcAM9BCAVUnladnk6IlBrYzNySmM=", "jCJeH");
    llIIIIIlIlIIII[llIIIIIlIllIll[74]] = lIIIIIIllIlllllI("eUa6P0zJAcuZ/RiELroR8unkwYk88In8ufvzYRZrA6Z1ygvm6h36SQ==", "bGgxY");
    llIIIIIlIlIIII[llIIIIIlIllIll[66]] = lIIIIIIllIllllII("OQkgWjw+AjEXIzYKIFoyOwUxGiV5AjEAJjgeP1ofMhgcFT8zADEGATsNLTc9Pgk6AGsxGToXDmZYY0ZoYDM1TnkbAjEAfjoFOhEyJQ0yAH45CSADPiUHeyQwNAcxAGp+Om5UcQ==", "WlTtQ");
    llIIIIIlIlIIII[llIIIIIlIllIll[52]] = lIIIIIIllIllllIl("p/k0prWQeE6QgwWQMIgfewHa1FPUL2/5o/CJkr34uxT6bzqr4+NlHGED6f4f7i2Dp5NhMaKduN8=", "EJQnj");
    llIIIIIlIlIIII[llIIIIIlIllIll[55]] = lIIIIIIllIlllllI("IbgfnfMGs6qHgQYpTCGca2he4AQt1CtFQ1BWCKqudDEXkmEH8lHX/A==", "MDQWN");
    llIIIIIlIlIIII[llIIIIIlIllIll[76]] = lIIIIIIllIllllIl("3CddAlxbDj2FD4+WxjQL9KuVpkQ6drdjp4OW5LdSjxVIcPKrsmluZOcN8YDtUgXQ", "EuDGl");
    llIIIIIlIlIIII[llIIIIIlIllIll[77]] = lIIIIIIllIllllII("ITsbL2U+LgQiZTguHysqJnQ+OjkuOwB0LSI2GSs5cXIhJCo9O0I7PyI2Qig+JTkZJyQldT08Li8zDi8/LmFEAiEqLAxhPj8zAWE4PygILyZkCRk8Lio3VnRraw==", "KZmNK");
    llIIIIIlIlIIII[llIIIIIlIllIll[78]] = lIIIIIIllIlllllI("ST8AazXkrFf2kVL0y3SDezT5JbP2rl/3D8/wASxuk7wVQafF/HkTJbnB++g22zj9", "yuwij");
    llIIIIIlIlIIII[llIIIIIlIllIll[80]] = lIIIIIIllIlllllI("/uAJgtvaPt1+xV0aFX24KHE85n7WW69gDWxoa4G3g3hVO8VGFOZLU3/jPbG3PbAPPrZNRFS0mNqCmOIjjV/A9Uar9DrSMa1xh04WwuPu7wGjdI1fUCLdalCljiyTwOhx", "hWvAg");
    llIIIIIlIlIIII[llIIIIIlIllIll[57]] = lIIIIIIllIllllII("CTIZTB0OOQgBAgYxGUwTCz4IDARJMgMWGRMuQyceEz4ZGyALNhQHAjQHVwQFCTQyU0dTb1xTLwYYV0pZKzkIFl8KPgMHExU2CxZfEiMEDl8iORgPNgY0BAwXXG1NQg==", "gWmbp");
    llIIIIIlIlIIII[llIIIIIlIllIll[82]] = lIIIIIIllIlllllI("xT1spW9qMryH8lKJ2qbyGfWHjWX/gQNzlhBWo++mZgjZ4QR6UFe3nPbDtF3ym4ho", "FvnOy");
    llIIIIIlIlIIII[llIIIIIlIllIll[83]] = lIIIIIIllIllllII("IiQZazQlLwgmKy0nGWs6ICgIKy1iJAMxMDg4QwA3OCgZPAkgIBQgKx8RVyMwKS0JGm59cVp1Bi4AV3RgdmFNZQ==", "LAmEY");
    llIIIIIlIlIIII[llIIIIIlIllIll[85]] = lIIIIIIllIllllII("JyAYexsgKwk2BCgjGHsfJywYezQlKg8+BXMjBTAaLRpdbEZwfVUKEjF/VW9WaWVM", "IElUv");
    llIIIIIlIlIIII[llIIIIIlIllIll[86]] = lIIIIIIllIlllllI("4xudxxW92eMWv+Kayh2LGIGuaJu0UzAYCq9601XsyhpyRMVYMGtKhNjs7GPRhl4VoE9mMDnk1wWUz2qQlM4GaBvmr86znCedp8iTzYLsRAQ=", "caeKC");
    llIIIIIlIlIIII[llIIIIIlIllIll[32]] = lIIIIIIllIlllllI("h1u579Q0Czx4lZGAGjpZzIwxUBYEfk8QkWEGsBnrMoXcm9JAIHXBIAjSvX02olBK", "iJHOf");
    llIIIIIlIlIIII[llIIIIIlIllIll[75]] = lIIIIIIllIlllllI("2+8PhP4eWGL/gr1MXLpZNH7zAruqGHzBYvLGKXXTvjuhIfx+rX3LgXULL7kDxgKbm1MySyBfcVs=", "VjJon");
    llIIIIIlIlIIII[llIIIIIlIllIll[68]] = lIIIIIIllIllllIl("fBFVCWWKCT3/LDcWnIF+I/ZSc7wL8ppmAyQ3Xhb2/dxKU4YsKlP7yShKQxDBz22y8mshj+2mXGbo2WrSGUHFWHcr0k6uZ1MZ3yFv1DZqDHUcfsFzw2RNmw==", "DPAEF");
    llIIIIIlIlIIII[llIIIIIlIllIll[88]] = lIIIIIIllIllllIl("uYHjI0acZ0nx3MT50omNtpnjhXf1JMa+btt6Ydfh0kXzzsjTA8navg==", "qtqzX");
    llIIIIIlIlIIII[llIIIIIlIllIll[34]] = lIIIIIIllIlllllI("MJyPa/qIM3rT8JZis+TxSXawbxtCvIONJTJ4dH61tkOatg6nziutd4scN6f9jrd+", "roCNH");
    llIIIIIlIlIIII[llIIIIIlIllIll[44]] = lIIIIIIllIllllII("Owo4fC48ASkxMTQJOHwqOwY4fAE5AC85MG8JJTcvMTB9a3NsV3oNJyBVdWhjdU9s", "UoLRC");
    llIIIIIlIlIIII[llIIIIIlIllIll[90]] = lIIIIIIllIlllllI("d6QB988TDpLJRs7E79ep3JSisbMkYbDzRjvD1kOKEklu1ImK1J7FcRNPeW9MuBdjO/lZ+avXkKk=", "wLZxs");
    llIIIIIlIlIIII[llIIIIIlIllIll[50]] = lIIIIIIllIllllII("HwcVfDoYDAQxJRAEFXw+HwsVfBUdDQI5JEsECDc7FT1Qa2dIVVQNMzBYWGh3UUJB", "qbaRW");
    llIIIIIlIlIIII[llIIIIIlIllIll[92]] = lIIIIIIllIllllII("CBYyA1kXAy0OWS0HMAsYDBYoWBgQMigRElhfCAgWFBZrDhYMEGstFQgSJxZMSzsuAwEDWCgDGQVYCwAdBxQwWU1CVw==", "bwDbw");
    llIIIIIlIlIIII[llIIIIIlIllIll[93]] = lIIIIIIllIllllII("DhZPMR8WAwg2DwwUTyADE10HcgJZAAk3BwgWEw4CEAdbelFDU0Fi", "csaBk");
    llIIIIIlIlIIII[llIIIIIlIllIll[24]] = lIIIIIIllIllllIl("X9QB8enbx8PKt9vVwCOXIyKorLq5wq7CyeRIFQ+2GIiV19xWJu6U2vB1RXzveeKmf3IrVbcZc5Q=", "izMsp");
    llIIIIIlIlIIII[llIIIIIlIllIll[87]] = lIIIIIIllIllllIl("s/1CF0GRCqJhWZM8AldJPY+HR+mSQZhqWpeUu4kzeXwDUq++YvNHVPMv8w0+U8uN", "znOvS");
    llIIIIIlIlIIII[llIIIIIlIllIll[95]] = lIIIIIIllIllllIl("cWwwqeCyPiTup+9S4LXWi7JIKkxy+QD+4u7Vi0goisM5PcFk6A1SP5WfuDjvtzbSMv0k9Y/NMps=", "Wuojz");
    llIIIIIlIlIIII[llIIIIIlIllIll[43]] = lIIIIIIllIllllIl("/TeV1iU/XnidUxDCKP38guOrZlwYXu65NIcZjfr6liSgijWiZGtsiN0U1UYwO1rLHFUfY43f8qTibqg4nROo83CxdhgCsNAVqZrGHc1nOY0=", "PbWbg");
    llIIIIIlIlIIII[llIIIIIlIllIll[96]] = lIIIIIIllIllllIl("RDOa4v/lYqE2lIOLyaF//ZTPT1HBQrHSIt72zdXvdBxNd9ZnqpbN6U/Uz5jpE7uE", "eCtsu");
    llIIIIIlIlIIII[llIIIIIlIllIll[81]] = lIIIIIIllIllllIl("NR9/aq7sH7vYLc4EgHHXAVDDXxFbWa5M41flwSExIdfluhLrJzQwLkyQypvYrlh5LWgSqApuXq7+EzTQ8XxbftS2i/2noV9a", "FfBGd");
    llIIIIIlIlIIII[llIIIIIlIllIll[79]] = lIIIIIIllIllllIl("DL55dJREa/SX818UOu8ZG5m2KlctsHEXOMoMdKJscs5XVqQJhsV2EbvqB5vnic5CaiEiYx8gRN4=", "yLKav");
    llIIIIIlIlIIII[llIIIIIlIllIll[20]] = lIIIIIIllIlllllI("s0x9PAMG3vsfqZJcottvqU2irQgVhkVto0nR/RZ/evRFJ7egeDS/GmStV4Y8kQoFADw9bFoNv2E=", "qlOtR");
    llIIIIIlIlIIII[llIIIIIlIllIll[21]] = lIIIIIIllIllllII("JiguZSIhIz8oPSkrLmU6PCQ2ZSIpOTJlDSQiOSAfJz5gLTomLgV6eH90YnkQKXdyAgYBZBYlKjxiNyIhLS4oKik8Yi8/JiRiNyo7IGIYJyArJgokPHN3ems=", "HMZKO");
    llIIIIIlIlIIII[llIIIIIlIllIll[61]] = lIIIIIIllIllllIl("aa8Qgaxct9CUipCdiEsfUNEZJg6nuDR7xhqbO0DhGAaVst951Ba54cMX2gh97LPz", "UswcQ");
    llIIIIIlIlIIII[llIIIIIlIllIll[22]] = lIIIIIIllIllllII("NAc7eB8zDCo1ADsEO3gbNAs7eDA2DSw9AWAEJjMePj1+Y0JuV34JEAJYdmxSekJv", "ZbOVr");
    llIIIIIlIlIIII[llIIIIIlIllIll[59]] = lIIIIIIllIllllIl("K4MzPxl7bT8/Hk3kKzbhzFJJe3XQYhlVAim4/F16dUix8fbOIuTfRM0wcj4qbV+ql3TIeCMJ4QA=", "EoFcN");
    llIIIIIlIlIIII[llIIIIIlIllIll[98]] = lIIIIIIllIlllllI("DjTpERp31Qwu/EQBEpE6/8FXPISEU1kL9xnSBqx9xMxSOP3RCrGiGZqtJHp6lEeh6g7yzBleLpgZ9+BeHMaa9kOjGJqMV+wCkthENPfyVAbqLbPoNSjX+PuKBq0S5gf9", "cRMPp");
    llIIIIIlIlIIII[llIIIIIlIllIll[38]] = lIIIIIIllIllllIl("Fi50F/5iOsMFL5RV/LivBQvbuRJryXkWhtqEiIYZNwcFZBhnqXXCeJ3WS9Z4o9PMRoskaUHR5sc=", "HLSWO");
    llIIIIIlIlIIII[llIIIIIlIllIll[99]] = lIIIIIIllIlllllI("v2iRpr/SctpjlCgnw3zK/+wlI3K0euZ2K9fCkN8bj/RUcsY2K+ZmDGF+vzHwj9V5QKvyJ5ktJCw=", "NylOH");
    llIIIIIlIlIIII[llIIIIIlIllIll[100]] = lIIIIIIllIlllllI("PH3wW4m53LNj8cZSj6WOVKLbRs5jP13oUhWISzSt/Ymmh+ZGPK0qNvSFaNC6z0yiE5l0JmFOxk2ANjuM/Ng8JGh1uBLiI6FMIBxllkazhOwqVAK76D+y1A==", "ytIQT");
    llIIIIIlIlIIII[llIIIIIlIllIll[89]] = lIIIIIIllIllllII("KiIffgItKQ4zHSUhH34aMC4HfgIlMwN+PSU+PyIOJyI5NRwxKx9qCTEpCA9ec39caF0bJlF4RggpDiRAKS4FNQw2Jg0kQDEzAjxAKSYfOEAGKwQzBBQoGGtVZGc=", "DGkPo");
    llIIIIIlIlIIII[llIIIIIlIllIll[36]] = lIIIIIIllIllllIl("daYfD5ioBwJa+PY64j0QJHgaXgelU/FcHdP5pZjzAV14YwdnEWgrhj75nPFFLJ3OJQ1/eq+CDaasacm3vIZnkw==", "nWPum");
    llIIIIIlIlIIII[llIIIIIlIllIll[94]] = lIIIIIIllIllllIl("4OtiDrjf6XW2FX/SovoXaDfLbOuiiEQARnFOEuHR21vNB7jgL57eLVjBqGuh5Z8ekz3IXllqiPoJReae5He+V/sN3jjxLHuCKg+hhaBKyONNRYRp4ekj6Uc69T9qTsNwNke1o77Hn5yzeowKOIC5JMbdcwWjPSStlzuk57bGG5qkmU6vug52gBaxPPORh4gw", "leapn");
    llIIIIIlIlIIII[llIIIIIlIllIll[84]] = lIIIIIIllIlllllI("0XZ0OYA9oDxbPpypUkKLcK5+PRokMk8Bkfq6cy+kfcYZ/+s+tlTLrw==", "HpTZq");
    llIIIIIlIlIIII[llIIIIIlIllIll[97]] = lIIIIIIllIllllII("OhsEJG8lDhspbyMOACAgPVQhMTM1Gx9/LDEKSG0NOhsEJG4lDhspbjYPHCY1ORUcagclFBExKD8USWwNOhsEJG4lDhspbiMOACAgPVUhMTM1Gx9+e3Ba", "PzrEA");
    llIIIIIlIlIIII[llIIIIIlIllIll[54]] = lIIIIIIllIllllII("ASwZWAkGJwgVFg4vGVgNASAZWCYDJg4dF1UvBBMICxZcT1RWcVkpABxzVExET2lN", "oImvd");
    llIIIIIlIlIIII[llIIIIIlIllIll[91]] = lIIIIIIllIllllIl("4c1oQLtlXyhuDzAEnyI9dt7hdwLjc0G72UDyawy8A7+c5oZ4YGkFRQ==", "zJZMC");
    llIIIIIlIlIIII[llIIIIIlIllIll[71]] = lIIIIIIllIlllllI("QMLYHUFdAs+XmQI0ADgGFeG82iwXAiREqZCH2aN0fl01sE4cTtLOAYuAeU/Ecry7DHi/oUtM49YhmgM+nqEYFcjSDxRXBy0M/vv7LFCfyjePETzT3XLvng==", "gOEYp");
    llIIIIIlIlIIII[llIIIIIlIllIll[18]] = lIIIIIIllIllllII("Gy9HMR8DOgA2DxktRyADBmQILVEeKxoQDhcpAScPTGIjazFMakk=", "vJiBk");
    llIIIIIlIlIIII[llIIIIIlIllIll[101]] = lIIIIIIllIllllII("PQ8weSM6BCE0PDIMMHk7JwMoeSMyHix5GDYJdzN0NR8qNBFiXXxgdmQ1IW1mHwQhI2E+AyoyLSELIiNhJh4tO2E+CzA/YQUPJ2QqaEMIOSsnRSk+IDYJNjYoJ0UxIyc/RSk2OjtFEjItYA5/bW5z", "SjDWN");
    llIIIIIlIlIIII[llIIIIIlIllIll[102]] = lIIIIIIllIlllllI("7ZIDOOYGFjcvyDmAT3N5Rw4INUEsC9ETWfo+qolhDODvMGdJ9izG15t+Y9ShR26v", "YBFRm");
    llIIIIIlIlIIII[llIIIIIlIllIll[103]] = lIIIIIIllIlllllI("Zf03nEDddaCuqEZ3cHPBmpFvYX0ZiZXcU7B7hAiQrLzxsrEscT9mQ8pV1OxYvzkRSWO0Ztn+3Jk=", "swNDp");
    llIIIIIlIlIIII[llIIIIIlIllIll[104]] = lIIIIIIllIllllII("CzcufD8MPD8xIAQ0LnwnETs2fBcLJzcUMwY7NDVoAyc0MQ1UZWxlYVENPmh6TB40NyZKPzM8NwYgOzQmSicuOz5KFzQnPyMzOTs8AmlgcnI=", "eRZRR");
    llIIIIIlIlIIII[llIIIIIlIllIll[105]] = lIIIIIIllIllllII("PgMmRwk5CDcKFjEAJkcNPg8mRyY8CTECF2oAOwwINDljUFRpXmc2ACRca1NEcEZy", "PfRid");
    llIIIIIlIlIIII[llIIIIIlIllIll[106]] = lIIIIIIllIlllllI("URPkvSHqY1fRAdUstS8pQAlylHyhSUm5vRxSIEiFUucif7UbuAoisQ==", "qLPCY");
    llIIIIIlIlIIII[llIIIIIlIllIll[107]] = lIIIIIIllIllllIl("CM2u7ooOjp/cm4RDbTGcE4I5T0ynpeU/+DrQN7RP1RkpqOv4NdWgen3OnU3DNSr96maM4EcVAZUGqnhYzFoxxWQyFgfWmO7fNQYDPp8Ql6XtX7QOWVyGwQ==", "aZScs");
    llIIIIIlIlIIII[llIIIIIlIllIll[108]] = lIIIIIIllIlllllI("v9KjGMa6ITc+2MNSAcdehk04jgqPPLRsNr/bzHpXHt/+8RxnpK2zlg==", "qSNvg");
    llIIIIIlIlIIII[llIIIIIlIllIll[109]] = lIIIIIIllIllllII("IzBCJTM7JQUiIyEyQjQvPnsKZi50Jhg3ICtvXmxnbnVMdg==", "NUlVG");
    llIIIIIlIlIllI = null;
  }
  
  private static void lIIIIIIlllIIlIlI() {
    String str = (new Exception()).getStackTrace()[llIIIIIlIllIll[0]].getFileName();
    llIIIIIlIlIllI = str.substring(str.indexOf("ä") + llIIIIIlIllIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIllIllllII(String lllllllllllllllIllIllIllllIlIIII, String lllllllllllllllIllIllIllllIIllll) {
    lllllllllllllllIllIllIllllIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIllllIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIllllIIlllI = new StringBuilder();
    char[] lllllllllllllllIllIllIllllIIllIl = lllllllllllllllIllIllIllllIIllll.toCharArray();
    int lllllllllllllllIllIllIllllIIllII = llIIIIIlIllIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIllllIlIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIlIllIll[0];
    while (lIIIIIIlllIllllI(j, i)) {
      char lllllllllllllllIllIllIllllIlIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIllllIIllII++;
      j++;
      "".length();
      if (-" ".length() == "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIllllIIlllI);
  }
  
  private static String lIIIIIIllIllllIl(String lllllllllllllllIllIllIllllIIlIII, String lllllllllllllllIllIllIllllIIIlll) {
    try {
      SecretKeySpec lllllllllllllllIllIllIllllIIlIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIllllIIIlll.getBytes(StandardCharsets.UTF_8)), llIIIIIlIllIll[10]), "DES");
      Cipher lllllllllllllllIllIllIllllIIlIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIllIllllIIlIlI.init(llIIIIIlIllIll[2], lllllllllllllllIllIllIllllIIlIll);
      return new String(lllllllllllllllIllIllIllllIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIllllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIllllIIlIIl) {
      lllllllllllllllIllIllIllllIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIllIlllllI(String lllllllllllllllIllIllIllllIIIIll, String lllllllllllllllIllIllIllllIIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIllllIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIllllIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIllllIIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIllllIIIlIl.init(llIIIIIlIllIll[2], lllllllllllllllIllIllIllllIIIllI);
      return new String(lllllllllllllllIllIllIllllIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIllllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIllllIIIlII) {
      lllllllllllllllIllIllIllllIIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlllIlllIl() {
    llIIIIIlIllIll = new int[111];
    llIIIIIlIllIll[0] = (55 + 44 - 67 + 155 ^ (0x71 ^ 0x3C) << " ".length()) << " ".length() & ((111 + 126 - 168 + 104 ^ (0x4F ^ 0x6C) << " ".length() << " ".length()) << " ".length() ^ -" ".length());
    llIIIIIlIllIll[1] = " ".length();
    llIIIIIlIllIll[2] = " ".length() << " ".length();
    llIIIIIlIllIll[3] = -" ".length();
    llIIIIIlIllIll[4] = 0x3A ^ 0x33;
    llIIIIIlIllIll[5] = "   ".length();
    llIIIIIlIllIll[6] = " ".length() << " ".length() << " ".length();
    llIIIIIlIllIll[7] = 68 + 133 - 41 + 35 ^ (0xD2 ^ 0xB1) << " ".length();
    llIIIIIlIllIll[8] = "   ".length() << " ".length();
    llIIIIIlIllIll[9] = " ".length() << (0xA8 ^ 0xAD) ^ 0x4E ^ 0x69;
    llIIIIIlIllIll[10] = " ".length() << "   ".length();
    llIIIIIlIllIll[11] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIllIll[12] = (0x75 ^ 0x70) << " ".length();
    llIIIIIlIllIll[13] = 0x86 ^ 0x8D;
    llIIIIIlIllIll[14] = "   ".length() << " ".length() << " ".length();
    llIIIIIlIllIll[15] = 0xD ^ 0x0;
    llIIIIIlIllIll[16] = (0x2E ^ 0x29) << " ".length();
    llIIIIIlIllIll[17] = 0xCE ^ 0xC1;
    llIIIIIlIllIll[18] = 0x53 ^ 0x78 ^ (0xB2 ^ 0xBB) << "   ".length();
    llIIIIIlIllIll[19] = (0x4A ^ 0x4F) << " ".length() << " ".length();
    llIIIIIlIllIll[20] = ((0x2 ^ 0x1B) << " ".length() << " ".length() ^ 0x8C ^ 0xC1) << " ".length();
    llIIIIIlIllIll[21] = 0x67 ^ 0x34;
    llIIIIIlIllIll[22] = (0x8C ^ 0xAB) << " ".length() ^ 0x13 ^ 0x8;
    llIIIIIlIllIll[23] = 70 + 118 - 123 + 78 ^ (0x19 ^ 0x56) << " ".length();
    llIIIIIlIllIll[24] = 0x72 ^ 0x39;
    llIIIIIlIllIll[25] = ((0xD8 ^ 0x93) << " ".length() ^ 37 + 99 - 133 + 156) << " ".length();
    llIIIIIlIllIll[26] = 0x7C ^ 0x6F;
    llIIIIIlIllIll[27] = (0xB1 ^ 0x90) << " ".length() ^ 0xEF ^ 0xB8;
    llIIIIIlIllIll[28] = (0x1B ^ 0xC) << " ".length();
    llIIIIIlIllIll[29] = (0x60 ^ 0x6B) << " ".length();
    llIIIIIlIllIll[30] = 0x55 ^ 0x6A ^ (0x5 ^ 0x8) << " ".length();
    llIIIIIlIllIll[31] = 0xB7 ^ 0xA0;
    llIIIIIlIllIll[32] = (0xB3 ^ 0xAA) << "   ".length() ^ 95 + 110 - 110 + 42;
    llIIIIIlIllIll[33] = "   ".length() << "   ".length();
    llIIIIIlIllIll[34] = 0x1D ^ 0x58;
    llIIIIIlIllIll[35] = 63 + 169 - 176 + 133 ^ (0x40 ^ 0x69) << " ".length() << " ".length();
    llIIIIIlIllIll[36] = (165 + 20 - 35 + 37 ^ (0x9F ^ 0xB4) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIIIIlIllIll[37] = ((0x28 ^ 0x1F) << " ".length() ^ 0x2A ^ 0x49) << " ".length();
    llIIIIIlIllIll[38] = ((0xB ^ 0x1E) << "   ".length() ^ 15 + 24 - -41 + 83) << "   ".length();
    llIIIIIlIllIll[39] = 0x15 ^ 0xE;
    llIIIIIlIllIll[40] = (91 + 57 - 52 + 49 ^ (0x7C ^ 0x33) << " ".length()) << " ".length();
    llIIIIIlIllIll[41] = (0xBD ^ 0x9C ^ (0xA8 ^ 0xBB) << " ".length()) << " ".length() << " ".length();
    llIIIIIlIllIll[42] = 0x5C ^ 0x41;
    llIIIIIlIllIll[43] = (0xA9 ^ 0x8E) << " ".length();
    llIIIIIlIllIll[44] = (0x97 ^ 0xB0 ^ " ".length() << " ".length() << " ".length()) << " ".length();
    llIIIIIlIllIll[45] = 0x41 ^ 0x5E;
    llIIIIIlIllIll[46] = " ".length() << (0xAA ^ 0xAF);
    llIIIIIlIllIll[47] = 0xDF ^ 0xA6 ^ (0x1D ^ 0x8) << " ".length() << " ".length();
    llIIIIIlIllIll[48] = 0xF9 ^ 0xB8 ^ "   ".length() << (0xC1 ^ 0xC4);
    llIIIIIlIllIll[49] = ((0xB2 ^ 0xB5) << " ".length() << " ".length() << " ".length() ^ 0x14 ^ 0x75) << " ".length();
    llIIIIIlIllIll[50] = (0x7A ^ 0x73) << "   ".length();
    llIIIIIlIllIll[51] = (0x99 ^ 0xB6) << " ".length() ^ 0x70 ^ 0xD;
    llIIIIIlIllIll[52] = (0xA4 ^ 0xBF) << " ".length();
    llIIIIIlIllIll[53] = (0x5E ^ 0x57) << " ".length() << " ".length();
    llIIIIIlIllIll[54] = "   ".length() << (0x57 ^ 0x52);
    llIIIIIlIllIll[55] = 88 + 147 - 185 + 125 ^ (0x8D ^ 0x9E) << "   ".length();
    llIIIIIlIllIll[56] = (0x58 ^ 0x4B) << " ".length();
    llIIIIIlIllIll[57] = (0xA8 ^ 0xA7) << " ".length() << " ".length();
    llIIIIIlIllIll[58] = (0x2B ^ 0x2E) << " ".length() << " ".length() << " ".length() ^ 0x7B ^ 0xC;
    llIIIIIlIllIll[59] = ((0x27 ^ 0x28) << "   ".length() ^ 0xED ^ 0xBE) << " ".length();
    llIIIIIlIllIll[60] = (53 + 64 - 22 + 40 ^ (0x3F ^ 0x7E) << " ".length()) << "   ".length();
    llIIIIIlIllIll[61] = (0x99 ^ 0x8C) << " ".length() << " ".length();
    llIIIIIlIllIll[62] = (0x84 ^ 0x81) << " ".length() ^ 0x2A ^ 0x9;
    llIIIIIlIllIll[63] = (2 + 38 - -113 + 14 ^ (0x73 ^ 0x2A) << " ".length()) << " ".length();
    llIIIIIlIllIll[64] = 0x49 ^ 0x7A;
    llIIIIIlIllIll[65] = 0x59 ^ 0x18 ^ (0x31 ^ 0x4) << " ".length();
    llIIIIIlIllIll[66] = (0x76 ^ 0x79) << " ".length() << " ".length() ^ 0x1E ^ 0x17;
    llIIIIIlIllIll[67] = ((0x6 ^ 0x1D) << " ".length() ^ 0x4B ^ 0x76) << " ".length() << " ".length();
    llIIIIIlIllIll[68] = 0xE9 ^ 0xAA;
    llIIIIIlIllIll[69] = 0xB2 ^ 0x9D;
    llIIIIIlIllIll[70] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIlIllIll[71] = (0x57 ^ 0x66) << " ".length();
    llIIIIIlIllIll[72] = 0x57 ^ 0x14 ^ (0x41 ^ 0x78) << " ".length();
    llIIIIIlIllIll[73] = (0x4B ^ 0x58 ^ (0xBB ^ 0xBE) << " ".length()) << " ".length();
    llIIIIIlIllIll[74] = (0x79 ^ 0x74) << " ".length() << " ".length();
    llIIIIIlIllIll[75] = ((0x51 ^ 0x68) << " ".length() ^ 0xCC ^ 0x9F) << " ".length();
    llIIIIIlIllIll[76] = (0x8E ^ 0x89) << "   ".length();
    llIIIIIlIllIll[77] = 0x44 ^ 0x7D;
    llIIIIIlIllIll[78] = (0x3F ^ 0x22) << " ".length();
    llIIIIIlIllIll[79] = 0xD ^ 0x5C;
    llIIIIIlIllIll[80] = 38 + 22 - -99 + 28 ^ " ".length() << (0x76 ^ 0x71);
    llIIIIIlIllIll[81] = (0xA3 ^ 0x98 ^ (0x1C ^ 0x3) << " ".length()) << " ".length() << " ".length() << " ".length();
    llIIIIIlIllIll[82] = (0xA3 ^ 0x86) << " ".length() << " ".length() ^ 84 + 118 - 37 + 4;
    llIIIIIlIllIll[83] = (144 + 66 - 112 + 87 ^ (0xD5 ^ 0x86) << " ".length()) << " ".length();
    llIIIIIlIllIll[84] = ((0x5D ^ 0x4E) << " ".length() ^ 0x67 ^ 0x6E) << " ".length();
    llIIIIIlIllIll[85] = 0x2C ^ 0x13;
    llIIIIIlIllIll[86] = " ".length() << "   ".length() << " ".length();
    llIIIIIlIllIll[87] = (0x4 ^ 0x17) << " ".length() << " ".length();
    llIIIIIlIllIll[88] = ((0x3A ^ 0x23) << " ".length() << " ".length() ^ 0x48 ^ 0x3D) << " ".length() << " ".length();
    llIIIIIlIllIll[89] = 0x4C ^ 0x17;
    llIIIIIlIllIll[90] = 0x57 ^ 0x4C ^ (0x44 ^ 0x53) << " ".length() << " ".length();
    llIIIIIlIllIll[91] = 0xF9 ^ 0x98;
    llIIIIIlIllIll[92] = 94 + 0 - -110 + 43 ^ (0xE3 ^ 0xBC) << " ".length();
    llIIIIIlIllIll[93] = (0x41 ^ 0x64) << " ".length();
    llIIIIIlIllIll[94] = 0x77 ^ 0xA ^ " ".length() << (0xA5 ^ 0xA0);
    llIIIIIlIllIll[95] = 0x29 ^ 0x64;
    llIIIIIlIllIll[96] = 129 + 86 - 93 + 89 ^ (0xE3 ^ 0xC4) << " ".length() << " ".length();
    llIIIIIlIllIll[97] = 0xED ^ 0xB2;
    llIIIIIlIllIll[98] = (0xD9 ^ 0xA4) << " ".length() ^ 11 + 120 - 100 + 142;
    llIIIIIlIllIll[99] = 0xDC ^ 0x85;
    llIIIIIlIllIll[100] = (0x2B ^ 0x6) << " ".length();
    llIIIIIlIllIll[101] = (0xAE ^ 0xB9 ^ (0x77 ^ 0x70) << " ".length()) << " ".length() << " ".length();
    llIIIIIlIllIll[102] = 0xFE ^ 0x9B;
    llIIIIIlIllIll[103] = (0x22 ^ 0x11) << " ".length();
    llIIIIIlIllIll[104] = 0x60 ^ 0x7;
    llIIIIIlIllIll[105] = (0x17 ^ 0x1A) << "   ".length();
    llIIIIIlIllIll[106] = 0x79 ^ 0xC ^ (0x87 ^ 0x80) << " ".length() << " ".length();
    llIIIIIlIllIll[107] = (0x7D ^ 0x48) << " ".length();
    llIIIIIlIllIll[108] = "   ".length() ^ (0x54 ^ 0x59) << "   ".length();
    llIIIIIlIllIll[109] = (0x57 ^ 0x4C) << " ".length() << " ".length();
    llIIIIIlIllIll[110] = 0xAF ^ 0xC2;
  }
  
  private static boolean lIIIIIIllllIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlllIllllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIllllIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIllllIIIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIIllllIIIlI(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIIllllIIlIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIllllIIllI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIIllllIIIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIllllIIIIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIllllIlIII(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lIIIIIIlllIlllll(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIIIllllIIlll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */