package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public class aa extends au {
  private static String[] lIlllIlIlIIIlI;
  
  private static Class[] lIlllIlIlIIIll;
  
  private static final String[] lIlllIlIlIIlII;
  
  private static String[] lIlllIlIlIIlIl;
  
  private static final int[] lIlllIlIlIIllI;
  
  public aa() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIlII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIlII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/aa.lIlllIlIlIIllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIlIlIlIlIlIll	Lme/stupitdog/bhp/aa;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   10: ldc 100.0
    //   12: putfield field_74333_Y : F
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIlIlIlIlIlIlI	Lme/stupitdog/bhp/aa;
  }
  
  static {
    lllllIlIIllIIIl();
    lllllIlIIllIIII();
    lllllIlIIlIllll();
    lllllIlIIlIlIll();
  }
  
  private static CallSite lllllIlIIlIlIlI(MethodHandles.Lookup lllllllllllllllIlllIlIlIlIlIIIIl, String lllllllllllllllIlllIlIlIlIlIIIII, MethodType lllllllllllllllIlllIlIlIlIIlllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIlIlIlIIlll = lIlllIlIlIIIlI[Integer.parseInt(lllllllllllllllIlllIlIlIlIlIIIII)].split(lIlllIlIlIIlII[lIlllIlIlIIllI[3]]);
      Class<?> lllllllllllllllIlllIlIlIlIlIIllI = Class.forName(lllllllllllllllIlllIlIlIlIlIIlll[lIlllIlIlIIllI[0]]);
      String lllllllllllllllIlllIlIlIlIlIIlIl = lllllllllllllllIlllIlIlIlIlIIlll[lIlllIlIlIIllI[1]];
      MethodHandle lllllllllllllllIlllIlIlIlIlIIlII = null;
      int lllllllllllllllIlllIlIlIlIlIIIll = lllllllllllllllIlllIlIlIlIlIIlll[lIlllIlIlIIllI[3]].length();
      if (lllllIlIIllIIlI(lllllllllllllllIlllIlIlIlIlIIIll, lIlllIlIlIIllI[2])) {
        MethodType lllllllllllllllIlllIlIlIlIlIlIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIlIlIlIIlll[lIlllIlIlIIllI[2]], aa.class.getClassLoader());
        if (lllllIlIIllIIll(lllllllllllllllIlllIlIlIlIlIIIll, lIlllIlIlIIllI[2])) {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findVirtual(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIIl);
          "".length();
          if (-((0x5 ^ 0x5A) << " ".length() ^ 23 + 53 - -105 + 6) >= 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findStatic(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIIl);
        } 
        "".length();
        if (((0x62 ^ 0x67) & (0x3B ^ 0x3E ^ 0xFFFFFFFF)) == -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIlIlIlIlIII = lIlllIlIlIIIll[Integer.parseInt(lllllllllllllllIlllIlIlIlIlIIlll[lIlllIlIlIIllI[2]])];
        if (lllllIlIIllIIll(lllllllllllllllIlllIlIlIlIlIIIll, lIlllIlIlIIllI[3])) {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findGetter(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIII);
          "".length();
          if (((0x1E ^ 0x37) & (0xE9 ^ 0xC0 ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (lllllIlIIllIIll(lllllllllllllllIlllIlIlIlIlIIIll, lIlllIlIlIIllI[4])) {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findStaticGetter(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIlIIllIIll(lllllllllllllllIlllIlIlIlIlIIIll, lIlllIlIlIIllI[5])) {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findSetter(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIII);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIlIlIlIIlII = lllllllllllllllIlllIlIlIlIlIIIIl.findStaticSetter(lllllllllllllllIlllIlIlIlIlIIllI, lllllllllllllllIlllIlIlIlIlIIlIl, lllllllllllllllIlllIlIlIlIlIlIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIlIlIlIIlII);
    } catch (Exception lllllllllllllllIlllIlIlIlIlIIIlI) {
      lllllllllllllllIlllIlIlIlIlIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlIIlIlIll() {
    lIlllIlIlIIIlI = new String[lIlllIlIlIIllI[3]];
    lIlllIlIlIIIlI[lIlllIlIlIIllI[2]] = lIlllIlIlIIlII[lIlllIlIlIIllI[4]];
    lIlllIlIlIIIlI[lIlllIlIlIIllI[0]] = lIlllIlIlIIlII[lIlllIlIlIIllI[5]];
    lIlllIlIlIIIlI[lIlllIlIlIIllI[1]] = lIlllIlIlIIlII[lIlllIlIlIIllI[6]];
    lIlllIlIlIIIll = new Class[lIlllIlIlIIllI[4]];
    lIlllIlIlIIIll[lIlllIlIlIIllI[2]] = GameSettings.class;
    lIlllIlIlIIIll[lIlllIlIlIIllI[3]] = float.class;
    lIlllIlIlIIIll[lIlllIlIlIIllI[1]] = Minecraft.class;
    lIlllIlIlIIIll[lIlllIlIlIIllI[0]] = f13.class;
  }
  
  private static void lllllIlIIlIllll() {
    lIlllIlIlIIlII = new String[lIlllIlIlIIllI[7]];
    lIlllIlIlIIlII[lIlllIlIlIIllI[0]] = lllllIlIIlIllII(lIlllIlIlIIlIl[lIlllIlIlIIllI[0]], lIlllIlIlIIlIl[lIlllIlIlIIllI[1]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[1]] = lllllIlIIlIllIl(lIlllIlIlIIlIl[lIlllIlIlIIllI[2]], lIlllIlIlIIlIl[lIlllIlIlIIllI[3]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[2]] = lllllIlIIlIllII(lIlllIlIlIIlIl[lIlllIlIlIIllI[4]], lIlllIlIlIIlIl[lIlllIlIlIIllI[5]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[3]] = lllllIlIIlIlllI(lIlllIlIlIIlIl[lIlllIlIlIIllI[6]], lIlllIlIlIIlIl[lIlllIlIlIIllI[7]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[4]] = lllllIlIIlIlllI(lIlllIlIlIIlIl[lIlllIlIlIIllI[8]], lIlllIlIlIIlIl[lIlllIlIlIIllI[9]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[5]] = lllllIlIIlIlllI(lIlllIlIlIIlIl[lIlllIlIlIIllI[10]], lIlllIlIlIIlIl[lIlllIlIlIIllI[11]]);
    lIlllIlIlIIlII[lIlllIlIlIIllI[6]] = lllllIlIIlIllII(lIlllIlIlIIlIl[lIlllIlIlIIllI[12]], lIlllIlIlIIlIl[lIlllIlIlIIllI[13]]);
    lIlllIlIlIIlIl = null;
  }
  
  private static void lllllIlIIllIIII() {
    String str = (new Exception()).getStackTrace()[lIlllIlIlIIllI[0]].getFileName();
    lIlllIlIlIIlIl = str.substring(str.indexOf("ä") + lIlllIlIlIIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIlIIlIllII(String lllllllllllllllIlllIlIlIlIIlllIl, String lllllllllllllllIlllIlIlIlIIlllII) {
    lllllllllllllllIlllIlIlIlIIlllIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIlIIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIlIlIIllIll = new StringBuilder();
    char[] lllllllllllllllIlllIlIlIlIIllIlI = lllllllllllllllIlllIlIlIlIIlllII.toCharArray();
    int lllllllllllllllIlllIlIlIlIIllIIl = lIlllIlIlIIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIlIlIIlllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIlIIllI[0];
    while (lllllIlIIllIlII(j, i)) {
      char lllllllllllllllIlllIlIlIlIIllllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIlIlIIllIIl++;
      j++;
      "".length();
      if ("   ".length() != "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIlIlIIllIll);
  }
  
  private static String lllllIlIIlIllIl(String lllllllllllllllIlllIlIlIlIIlIlIl, String lllllllllllllllIlllIlIlIlIIlIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlIlIIllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIlIIlIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIlIlIIlIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIlIlIIlIlll.init(lIlllIlIlIIllI[2], lllllllllllllllIlllIlIlIlIIllIII);
      return new String(lllllllllllllllIlllIlIlIlIIlIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIlIIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlIlIIlIllI) {
      lllllllllllllllIlllIlIlIlIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlIIlIlllI(String lllllllllllllllIlllIlIlIlIIlIIII, String lllllllllllllllIlllIlIlIlIIIllll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlIlIIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIlIIIllll.getBytes(StandardCharsets.UTF_8)), lIlllIlIlIIllI[8]), "DES");
      Cipher lllllllllllllllIlllIlIlIlIIlIIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIlIlIIlIIlI.init(lIlllIlIlIIllI[2], lllllllllllllllIlllIlIlIlIIlIIll);
      return new String(lllllllllllllllIlllIlIlIlIIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIlIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlIlIIlIIIl) {
      lllllllllllllllIlllIlIlIlIIlIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlIIllIIIl() {
    lIlllIlIlIIllI = new int[14];
    lIlllIlIlIIllI[0] = ((0xFD ^ 0x9A) << " ".length() ^ 83 + 30 - -2 + 82) << " ".length() & (((0x77 ^ 0x72) << "   ".length() ^ 0x2E ^ 0xD) << " ".length() ^ -" ".length());
    lIlllIlIlIIllI[1] = " ".length();
    lIlllIlIlIIllI[2] = " ".length() << " ".length();
    lIlllIlIlIIllI[3] = "   ".length();
    lIlllIlIlIIllI[4] = " ".length() << " ".length() << " ".length();
    lIlllIlIlIIllI[5] = 0xE ^ 0x51 ^ (0x83 ^ 0xAE) << " ".length();
    lIlllIlIlIIllI[6] = "   ".length() << " ".length();
    lIlllIlIlIIllI[7] = (0xA7 ^ 0x8C) << " ".length() ^ 0x2E ^ 0x7F;
    lIlllIlIlIIllI[8] = " ".length() << "   ".length();
    lIlllIlIlIIllI[9] = (0xC8 ^ 0xC7) << " ".length() << " ".length() ^ 0xF6 ^ 0xC3;
    lIlllIlIlIIllI[10] = (0x57 ^ 0x8 ^ (0x1A ^ 0x37) << " ".length()) << " ".length();
    lIlllIlIlIIllI[11] = 0x7A ^ 0x71;
    lIlllIlIlIIllI[12] = "   ".length() << " ".length() << " ".length();
    lIlllIlIlIIllI[13] = (0xBE ^ 0x81) << " ".length() ^ 0x59 ^ 0x2A;
  }
  
  private static boolean lllllIlIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIlIIllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIlIIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\aa.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */