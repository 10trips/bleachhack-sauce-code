package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.math.BlockPos;

public class f10 extends au {
  private static String[] llIIlIIlIIlIll;
  
  private static Class[] llIIlIIlIIllII;
  
  private static final String[] llIIlIIlIllIIl;
  
  private static String[] llIIlIIlIllIlI;
  
  private static final int[] llIIlIIlIllIll;
  
  public f10() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIIllIlIIlIlIIl	Lme/stupitdog/bhp/f10;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/item/ItemStack;
    //   15: <illegal opcode> 4 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   20: instanceof net/minecraft/item/ItemBow
    //   23: invokestatic lIIIIllIlIllIlIl : (I)Z
    //   26: ifeq -> 185
    //   29: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   34: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   39: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   44: invokestatic lIIIIllIlIllIlIl : (I)Z
    //   47: ifeq -> 185
    //   50: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   55: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   60: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   65: getstatic me/stupitdog/bhp/f10.llIIlIIlIllIll : [I
    //   68: iconst_3
    //   69: iaload
    //   70: invokestatic lIIIIllIlIllIllI : (II)Z
    //   73: ifeq -> 185
    //   76: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   81: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   86: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   91: new net/minecraft/network/play/client/CPacketPlayerDigging
    //   94: dup
    //   95: <illegal opcode> 8 : ()Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;
    //   100: <illegal opcode> 9 : ()Lnet/minecraft/util/math/BlockPos;
    //   105: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   110: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   115: <illegal opcode> 10 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumFacing;
    //   120: invokespecial <init> : (Lnet/minecraft/network/play/client/CPacketPlayerDigging$Action;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   123: <illegal opcode> 11 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   128: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   133: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   138: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   143: new net/minecraft/network/play/client/CPacketPlayerTryUseItem
    //   146: dup
    //   147: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   152: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   157: <illegal opcode> 12 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/EnumHand;
    //   162: invokespecial <init> : (Lnet/minecraft/util/EnumHand;)V
    //   165: <illegal opcode> 11 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   170: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   175: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   180: <illegal opcode> 13 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   185: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	186	0	lllllllllllllllIllIIllIlIIlIlIII	Lme/stupitdog/bhp/f10;
  }
  
  static {
    lIIIIllIlIllIlII();
    lIIIIllIlIllIIll();
    lIIIIllIlIllIIlI();
    lIIIIllIlIlIlllI();
  }
  
  private static CallSite lIIIIllIlIIIlllI(MethodHandles.Lookup lllllllllllllllIllIIllIlIIIlllll, String lllllllllllllllIllIIllIlIIIllllI, MethodType lllllllllllllllIllIIllIlIIIlllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIlIIlIIlIl = llIIlIIlIIlIll[Integer.parseInt(lllllllllllllllIllIIllIlIIIllllI)].split(llIIlIIlIllIIl[llIIlIIlIllIll[3]]);
      Class<?> lllllllllllllllIllIIllIlIIlIIlII = Class.forName(lllllllllllllllIllIIllIlIIlIIlIl[llIIlIIlIllIll[0]]);
      String lllllllllllllllIllIIllIlIIlIIIll = lllllllllllllllIllIIllIlIIlIIlIl[llIIlIIlIllIll[1]];
      MethodHandle lllllllllllllllIllIIllIlIIlIIIlI = null;
      int lllllllllllllllIllIIllIlIIlIIIIl = lllllllllllllllIllIIllIlIIlIIlIl[llIIlIIlIllIll[3]].length();
      if (lIIIIllIlIllIlll(lllllllllllllllIllIIllIlIIlIIIIl, llIIlIIlIllIll[2])) {
        MethodType lllllllllllllllIllIIllIlIIlIIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIlIIlIIlIl[llIIlIIlIllIll[2]], f10.class.getClassLoader());
        if (lIIIIllIlIlllIII(lllllllllllllllIllIIllIlIIlIIIIl, llIIlIIlIllIll[2])) {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findVirtual(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIlll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findStatic(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIlll);
        } 
        "".length();
        if ("   ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIlIIlIIllI = llIIlIIlIIllII[Integer.parseInt(lllllllllllllllIllIIllIlIIlIIlIl[llIIlIIlIllIll[2]])];
        if (lIIIIllIlIlllIII(lllllllllllllllIllIIllIlIIlIIIIl, llIIlIIlIllIll[3])) {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findGetter(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIllI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length())
            return null; 
        } else if (lIIIIllIlIlllIII(lllllllllllllllIllIIllIlIIlIIIIl, llIIlIIlIllIll[4])) {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findStaticGetter(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIllI);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIllIlIlllIII(lllllllllllllllIllIIllIlIIlIIIIl, llIIlIIlIllIll[5])) {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findSetter(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIllI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIlIIlIIIlI = lllllllllllllllIllIIllIlIIIlllll.findStaticSetter(lllllllllllllllIllIIllIlIIlIIlII, lllllllllllllllIllIIllIlIIlIIIll, lllllllllllllllIllIIllIlIIlIIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIlIIlIIIlI);
    } catch (Exception lllllllllllllllIllIIllIlIIlIIIII) {
      lllllllllllllllIllIIllIlIIlIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIlIlIlllI() {
    llIIlIIlIIlIll = new String[llIIlIIlIllIll[6]];
    llIIlIIlIIlIll[llIIlIIlIllIll[7]] = llIIlIIlIllIIl[llIIlIIlIllIll[4]];
    llIIlIIlIIlIll[llIIlIIlIllIll[4]] = llIIlIIlIllIIl[llIIlIIlIllIll[5]];
    llIIlIIlIIlIll[llIIlIIlIllIll[8]] = llIIlIIlIllIIl[llIIlIIlIllIll[7]];
    llIIlIIlIIlIll[llIIlIIlIllIll[2]] = llIIlIIlIllIIl[llIIlIIlIllIll[9]];
    llIIlIIlIIlIll[llIIlIIlIllIll[10]] = llIIlIIlIllIIl[llIIlIIlIllIll[10]];
    llIIlIIlIIlIll[llIIlIIlIllIll[11]] = llIIlIIlIllIIl[llIIlIIlIllIll[12]];
    llIIlIIlIIlIll[llIIlIIlIllIll[9]] = llIIlIIlIllIIl[llIIlIIlIllIll[13]];
    llIIlIIlIIlIll[llIIlIIlIllIll[0]] = llIIlIIlIllIIl[llIIlIIlIllIll[8]];
    llIIlIIlIIlIll[llIIlIIlIllIll[14]] = llIIlIIlIllIIl[llIIlIIlIllIll[14]];
    llIIlIIlIIlIll[llIIlIIlIllIll[12]] = llIIlIIlIllIIl[llIIlIIlIllIll[11]];
    llIIlIIlIIlIll[llIIlIIlIllIll[5]] = llIIlIIlIllIIl[llIIlIIlIllIll[6]];
    llIIlIIlIIlIll[llIIlIIlIllIll[13]] = llIIlIIlIllIIl[llIIlIIlIllIll[15]];
    llIIlIIlIIlIll[llIIlIIlIllIll[3]] = llIIlIIlIllIIl[llIIlIIlIllIll[16]];
    llIIlIIlIIlIll[llIIlIIlIllIll[1]] = llIIlIIlIllIIl[llIIlIIlIllIll[17]];
    llIIlIIlIIllII = new Class[llIIlIIlIllIll[7]];
    llIIlIIlIIllII[llIIlIIlIllIll[0]] = f13.class;
    llIIlIIlIIllII[llIIlIIlIllIll[2]] = EntityPlayerSP.class;
    llIIlIIlIIllII[llIIlIIlIllIll[5]] = BlockPos.class;
    llIIlIIlIIllII[llIIlIIlIllIll[1]] = Minecraft.class;
    llIIlIIlIIllII[llIIlIIlIllIll[4]] = CPacketPlayerDigging.Action.class;
    llIIlIIlIIllII[llIIlIIlIllIll[3]] = NetHandlerPlayClient.class;
  }
  
  private static void lIIIIllIlIllIIlI() {
    llIIlIIlIllIIl = new String[llIIlIIlIllIll[18]];
    llIIlIIlIllIIl[llIIlIIlIllIll[0]] = lIIIIllIlIlIllll(llIIlIIlIllIlI[llIIlIIlIllIll[0]], llIIlIIlIllIlI[llIIlIIlIllIll[1]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[1]] = lIIIIllIlIllIIII(llIIlIIlIllIlI[llIIlIIlIllIll[2]], llIIlIIlIllIlI[llIIlIIlIllIll[3]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[2]] = lIIIIllIlIllIIIl(llIIlIIlIllIlI[llIIlIIlIllIll[4]], llIIlIIlIllIlI[llIIlIIlIllIll[5]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[3]] = lIIIIllIlIlIllll(llIIlIIlIllIlI[llIIlIIlIllIll[7]], llIIlIIlIllIlI[llIIlIIlIllIll[9]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[4]] = lIIIIllIlIlIllll(llIIlIIlIllIlI[llIIlIIlIllIll[10]], llIIlIIlIllIlI[llIIlIIlIllIll[12]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[5]] = lIIIIllIlIllIIII(llIIlIIlIllIlI[llIIlIIlIllIll[13]], llIIlIIlIllIlI[llIIlIIlIllIll[8]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[7]] = lIIIIllIlIllIIII(llIIlIIlIllIlI[llIIlIIlIllIll[14]], llIIlIIlIllIlI[llIIlIIlIllIll[11]]);
    llIIlIIlIllIIl[llIIlIIlIllIll[9]] = lIIIIllIlIllIIII("lNAI82xt2uh/67PSLy/GPUoTUIkQiSokYOs47DVqOpORWBIQDhQSAfLqTgWCtHxDrZb4r8XHFL4=", "YOpCQ");
    llIIlIIlIllIIl[llIIlIIlIllIll[10]] = lIIIIllIlIllIIIl("RLsrKV9XjFarosZUGv3B0YmrRaZMCuZnpqd76fmStgkYLLmI99WtctbBmXy6FMJgzr3JqbyxFR6N5PnoTO8HzfBMii/DF8or8F3LWfCNwtexdnfbmVDTYQ==", "OdWdQ");
    llIIlIIlIllIIl[llIIlIIlIllIll[12]] = lIIIIllIlIlIllll("KBwnfwkvFzYyFicfJ38HKhA2PxBoHD0lDTIAfRQKMhAnKDQqGCo0FhUpaTcRKBoMYFxyTGpmOyUBaXlNEENzcQ==", "FySQd");
    llIIlIIlIllIIl[llIIlIIlIllIll[13]] = lIIIIllIlIllIIII("RIZ6cPXeHiFGtzrVng+mjO1TZ7ctKR21/yVEkuIWY3xJUkArzFo929bodowQ3gJKUD8EuifCS4z5hlsmvm/3GA==", "ugbNo");
    llIIlIIlIllIIl[llIIlIIlIllIll[8]] = lIIIIllIlIllIIIl("ZHdY9T1dz48jUHUlrpBzKpbG519Wl+sG1PiXNro6n1mI7F54IaqqzQ==", "Vbgae");
    llIIlIIlIllIIl[llIIlIIlIllIll[14]] = lIIIIllIlIlIllll("OQ8iZSQ+BDMoOzYMImUqOwMzJT15Dzg/ICMTeA4nIwMiMhk7Cy8uOwQ6bC08OQkJenFjXGZ7FjQZbGNgGwQzP2Y6AzguKiULMD9mIh4/J2YSBCMmATYEMnBzd0o=", "WjVKI");
    llIIlIIlIllIIl[llIIlIIlIllIll[11]] = lIIIIllIlIllIIIl("gE6+EBw1J/d/gMDnK4TVR5pGBFk4haEt5TLouYWSFnvBGld/l7eHKArp4s2iilTHg01qdvNHxt4=", "ptBsq");
    llIIlIIlIllIIl[llIIlIIlIllIll[6]] = lIIIIllIlIllIIIl("bFSReH2jJxUiRXQcXHoGb6ZY7oskeDlFnkgUWzj6jjL6w7dQ6ULXVqgtHFGeCy8LZVBDkJcPleWmMFFdn3e/fya1MyCzpTN+", "SljsF");
    llIIlIIlIllIIl[llIIlIIlIllIll[15]] = lIIIIllIlIllIIII("OEDJusgiTBjqUatSFvehQkorpJOqqZCeYmgSfHxUGyot6HgSy6E1ik8GSy8YKDXPe9Or4BxzSJJbyhO3MtBdgfR47MD7VdWN48nRjfqkRYKefFJqxrGugZ61E6z4T4b7", "onIlg");
    llIIlIIlIllIIl[llIIlIIlIllIll[16]] = lIIIIllIlIllIIII("BCKxdX8TlUXo1L3dQjm/3NBBVckdxi5+ez03Rmhr1iZWT7JNe56m6CQmGQZAkZLC3HtyCvgWbffoi/xLZKSP4PyW4fSK9sQ46dLnBAzPIQXaGYWU4XOcTadm3tcjFEAG", "fqBiX");
    llIIlIIlIllIIl[llIIlIIlIllIll[17]] = lIIIIllIlIllIIIl("RC+CqtEjoC1P9Mkqy0UaB2yu4qhdSj8oneUDEj1/FxU=", "bTEEk");
    llIIlIIlIllIlI = null;
  }
  
  private static void lIIIIllIlIllIIll() {
    String str = (new Exception()).getStackTrace()[llIIlIIlIllIll[0]].getFileName();
    llIIlIIlIllIlI = str.substring(str.indexOf("ä") + llIIlIIlIllIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIlIlIllll(String lllllllllllllllIllIIllIlIIIllIll, String lllllllllllllllIllIIllIlIIIllIlI) {
    lllllllllllllllIllIIllIlIIIllIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIIIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllIlIIIllIIl = new StringBuilder();
    char[] lllllllllllllllIllIIllIlIIIllIII = lllllllllllllllIllIIllIlIIIllIlI.toCharArray();
    int lllllllllllllllIllIIllIlIIIlIlll = llIIlIIlIllIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIllIlIIIllIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIlIllIll[0];
    while (lIIIIllIlIlllIIl(j, i)) {
      char lllllllllllllllIllIIllIlIIIlllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllIlIIIlIlll++;
      j++;
      "".length();
      if (((0xA5 ^ 0xC6) & (0x49 ^ 0x2A ^ 0xFFFFFFFF) & ((0x45 ^ 0x16) & (0x39 ^ 0x6A ^ 0xFFFFFFFF) ^ 0xFFFFFFFF)) >= " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllIlIIIllIIl);
  }
  
  private static String lIIIIllIlIllIIII(String lllllllllllllllIllIIllIlIIIlIIll, String lllllllllllllllIllIIllIlIIIlIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlIIIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlIIIlIIlI.getBytes(StandardCharsets.UTF_8)), llIIlIIlIllIll[10]), "DES");
      Cipher lllllllllllllllIllIIllIlIIIlIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIlIIIlIlIl.init(llIIlIIlIllIll[2], lllllllllllllllIllIIllIlIIIlIllI);
      return new String(lllllllllllllllIllIIllIlIIIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIlIIIlIlII) {
      lllllllllllllllIllIIllIlIIIlIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIlIllIIIl(String lllllllllllllllIllIIllIlIIIIlllI, String lllllllllllllllIllIIllIlIIIIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlIIIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlIIIIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIlIIIlIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIlIIIlIIII.init(llIIlIIlIllIll[2], lllllllllllllllIllIIllIlIIIlIIIl);
      return new String(lllllllllllllllIllIIllIlIIIlIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIIIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIlIIIIllll) {
      lllllllllllllllIllIIllIlIIIIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIlIllIlII() {
    llIIlIIlIllIll = new int[19];
    llIIlIIlIllIll[0] = (0x1E ^ 0x1 ^ (0x6 ^ 0x3) << " ".length() << " ".length() << " ".length()) & (114 + 57 - 96 + 68 ^ "   ".length() << "   ".length() << " ".length() ^ -" ".length());
    llIIlIIlIllIll[1] = " ".length();
    llIIlIIlIllIll[2] = " ".length() << " ".length();
    llIIlIIlIllIll[3] = "   ".length();
    llIIlIIlIllIll[4] = " ".length() << " ".length() << " ".length();
    llIIlIIlIllIll[5] = 0x1C ^ 0x19;
    llIIlIIlIllIll[6] = (0x84 ^ 0x83) << " ".length();
    llIIlIIlIllIll[7] = "   ".length() << " ".length();
    llIIlIIlIllIll[8] = 0x11 ^ 0x1A;
    llIIlIIlIllIll[9] = 0x56 ^ 0x51;
    llIIlIIlIllIll[10] = " ".length() << "   ".length();
    llIIlIIlIllIll[11] = 0x21 ^ 0x2C;
    llIIlIIlIllIll[12] = (0x4 ^ 0x2D) << " ".length() << " ".length() ^ 77 + 130 - 125 + 91;
    llIIlIIlIllIll[13] = ((0x5F ^ 0x4A) << " ".length() << " ".length() ^ 0xCB ^ 0x9A) << " ".length();
    llIIlIIlIllIll[14] = "   ".length() << " ".length() << " ".length();
    llIIlIIlIllIll[15] = 0x3A ^ 0x35;
    llIIlIIlIllIll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIlIllIll[17] = 0xAE ^ 0xBF;
    llIIlIIlIllIll[18] = ((0x1C ^ 0x2F) << " ".length() ^ 0xDD ^ 0xB2) << " ".length();
  }
  
  private static boolean lIIIIllIlIlllIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIlIllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 >= paramInt2);
  }
  
  private static boolean lIIIIllIlIlllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIlIllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIlIllIlIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */