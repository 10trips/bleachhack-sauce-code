package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fb extends au {
  private static String[] lIlllIllIllIll;
  
  private static Class[] lIlllIllIlllII;
  
  private static final String[] lIlllIllIlllIl;
  
  private static String[] lIlllIllIllllI;
  
  private static final int[] lIlllIllIlllll;
  
  public fb() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fb.lIlllIllIlllIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fb.lIlllIllIlllll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fb.lIlllIllIlllIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fb.lIlllIllIlllll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fb.lIlllIllIlllIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fb.lIlllIllIlllll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fb.lIlllIllIlllll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIlIIIllIIIlll	Lme/stupitdog/bhp/fb;
  }
  
  static {
    lllllIlllIIIlll();
    lllllIlllIIIllI();
    lllllIlllIIIlIl();
    lllllIlllIIIIIl();
  }
  
  private static CallSite lllllIlllIIIIII(MethodHandles.Lookup lllllllllllllllIlllIlIIIlIlllllI, String lllllllllllllllIlllIlIIIlIllllIl, MethodType lllllllllllllllIlllIlIIIlIllllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIIIllIIIlII = lIlllIllIllIll[Integer.parseInt(lllllllllllllllIlllIlIIIlIllllIl)].split(lIlllIllIlllIl[lIlllIllIlllll[3]]);
      Class<?> lllllllllllllllIlllIlIIIllIIIIll = Class.forName(lllllllllllllllIlllIlIIIllIIIlII[lIlllIllIlllll[0]]);
      String lllllllllllllllIlllIlIIIllIIIIlI = lllllllllllllllIlllIlIIIllIIIlII[lIlllIllIlllll[1]];
      MethodHandle lllllllllllllllIlllIlIIIllIIIIIl = null;
      int lllllllllllllllIlllIlIIIllIIIIII = lllllllllllllllIlllIlIIIllIIIlII[lIlllIllIlllll[3]].length();
      if (lllllIlllIIlIII(lllllllllllllllIlllIlIIIllIIIIII, lIlllIllIlllll[2])) {
        MethodType lllllllllllllllIlllIlIIIllIIIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIIIllIIIlII[lIlllIllIlllll[2]], fb.class.getClassLoader());
        if (lllllIlllIIlIIl(lllllllllllllllIlllIlIIIllIIIIII, lIlllIllIlllll[2])) {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findVirtual(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findStatic(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIllI);
        } 
        "".length();
        if ("   ".length() < " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIIIllIIIlIl = lIlllIllIlllII[Integer.parseInt(lllllllllllllllIlllIlIIIllIIIlII[lIlllIllIlllll[2]])];
        if (lllllIlllIIlIIl(lllllllllllllllIlllIlIIIllIIIIII, lIlllIllIlllll[3])) {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findGetter(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIlIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lllllIlllIIlIIl(lllllllllllllllIlllIlIIIllIIIIII, lIlllIllIlllll[4])) {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findStaticGetter(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIlIl);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else if (lllllIlllIIlIIl(lllllllllllllllIlllIlIIIllIIIIII, lIlllIllIlllll[5])) {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findSetter(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIlIl);
          "".length();
          if (((0x6D ^ 0x68 ^ "   ".length() << " ".length() << " ".length()) & ((0x37 ^ 0x3E) << "   ".length() ^ 0x13 ^ 0x52 ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIIIllIIIIIl = lllllllllllllllIlllIlIIIlIlllllI.findStaticSetter(lllllllllllllllIlllIlIIIllIIIIll, lllllllllllllllIlllIlIIIllIIIIlI, lllllllllllllllIlllIlIIIllIIIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIIIllIIIIIl);
    } catch (Exception lllllllllllllllIlllIlIIIlIllllll) {
      lllllllllllllllIlllIlIIIlIllllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlllIIIIIl() {
    lIlllIllIllIll = new String[lIlllIllIlllll[1]];
    lIlllIllIllIll[lIlllIllIlllll[0]] = lIlllIllIlllIl[lIlllIllIlllll[4]];
    lIlllIllIlllII = new Class[lIlllIllIlllll[1]];
    lIlllIllIlllII[lIlllIllIlllll[0]] = f13.class;
  }
  
  private static void lllllIlllIIIlIl() {
    lIlllIllIlllIl = new String[lIlllIllIlllll[5]];
    lIlllIllIlllIl[lIlllIllIlllll[0]] = lllllIlllIIIIlI(lIlllIllIllllI[lIlllIllIlllll[0]], lIlllIllIllllI[lIlllIllIlllll[1]]);
    lIlllIllIlllIl[lIlllIllIlllll[1]] = lllllIlllIIIIll(lIlllIllIllllI[lIlllIllIlllll[2]], lIlllIllIllllI[lIlllIllIlllll[3]]);
    lIlllIllIlllIl[lIlllIllIlllll[2]] = lllllIlllIIIIll(lIlllIllIllllI[lIlllIllIlllll[4]], lIlllIllIllllI[lIlllIllIlllll[5]]);
    lIlllIllIlllIl[lIlllIllIlllll[3]] = lllllIlllIIIIll(lIlllIllIllllI[lIlllIllIlllll[6]], lIlllIllIllllI[lIlllIllIlllll[7]]);
    lIlllIllIlllIl[lIlllIllIlllll[4]] = lllllIlllIIIlII(lIlllIllIllllI[lIlllIllIlllll[8]], lIlllIllIllllI[lIlllIllIlllll[9]]);
    lIlllIllIllllI = null;
  }
  
  private static void lllllIlllIIIllI() {
    String str = (new Exception()).getStackTrace()[lIlllIllIlllll[0]].getFileName();
    lIlllIllIllllI = str.substring(str.indexOf("ä") + lIlllIllIlllll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIlllIIIlII(String lllllllllllllllIlllIlIIIlIlllIII, String lllllllllllllllIlllIlIIIlIllIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIlIlllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIlIllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIIIlIlllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIIIlIlllIlI.init(lIlllIllIlllll[2], lllllllllllllllIlllIlIIIlIlllIll);
      return new String(lllllllllllllllIlllIlIIIlIlllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIlIlllIIl) {
      lllllllllllllllIlllIlIIIlIlllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlllIIIIll(String lllllllllllllllIlllIlIIIlIllIIll, String lllllllllllllllIlllIlIIIlIllIIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIlIllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIlIllIIlI.getBytes(StandardCharsets.UTF_8)), lIlllIllIlllll[8]), "DES");
      Cipher lllllllllllllllIlllIlIIIlIllIlIl = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIIIlIllIlIl.init(lIlllIllIlllll[2], lllllllllllllllIlllIlIIIlIllIllI);
      return new String(lllllllllllllllIlllIlIIIlIllIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIlIllIlII) {
      lllllllllllllllIlllIlIIIlIllIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlllIIIIlI(String lllllllllllllllIlllIlIIIlIllIIII, String lllllllllllllllIlllIlIIIlIlIllll) {
    lllllllllllllllIlllIlIIIlIllIIII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIlIllIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIIIlIlIlllI = new StringBuilder();
    char[] lllllllllllllllIlllIlIIIlIlIllIl = lllllllllllllllIlllIlIIIlIlIllll.toCharArray();
    int lllllllllllllllIlllIlIIIlIlIllII = lIlllIllIlllll[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIIIlIllIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIllIlllll[0];
    while (lllllIlllIIlIlI(j, i)) {
      char lllllllllllllllIlllIlIIIlIllIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIIIlIlIllII++;
      j++;
      "".length();
      if (-" ".length() > (" ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIIIlIlIlllI);
  }
  
  private static void lllllIlllIIIlll() {
    lIlllIllIlllll = new int[10];
    lIlllIllIlllll[0] = ((0x61 ^ 0x70) << " ".length() ^ 0x37 ^ 0x56) & (" ".length() << (0xB0 ^ 0xB5) ^ 0x24 ^ 0x47 ^ -" ".length());
    lIlllIllIlllll[1] = " ".length();
    lIlllIllIlllll[2] = " ".length() << " ".length();
    lIlllIllIlllll[3] = "   ".length();
    lIlllIllIlllll[4] = " ".length() << " ".length() << " ".length();
    lIlllIllIlllll[5] = (0x49 ^ 0x5E) << " ".length() << " ".length() ^ 0x57 ^ 0xE;
    lIlllIllIlllll[6] = "   ".length() << " ".length();
    lIlllIllIlllll[7] = 45 + 93 - -8 + 21 ^ (0x3F ^ 0x3A) << (0x32 ^ 0x37);
    lIlllIllIlllll[8] = " ".length() << "   ".length();
    lIlllIllIlllll[9] = 0x2F ^ 0x26;
  }
  
  private static boolean lllllIlllIIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIlllIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIlllIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */