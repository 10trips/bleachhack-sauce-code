package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class a {
  public List<fz> friends;
  
  private static String[] llIIIllIllIIIl;
  
  private static Class[] llIIIllIllIIlI;
  
  private static final String[] llIIIllIllIIll;
  
  private static String[] llIIIllIllIllI;
  
  private static final int[] llIIIllIllIlll;
  
  public a() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new java/util/ArrayList
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: <illegal opcode> 0 : (Lme/stupitdog/bhp/a;Ljava/util/List;)V
    //   17: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	18	0	lllllllllllllllIllIlIIlIIIIIIIll	Lme/stupitdog/bhp/a;
  }
  
  public List<fz> getFriends() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/stupitdog/bhp/a;)Ljava/util/List;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIlIIIIIIIlI	Lme/stupitdog/bhp/a;
  }
  
  public boolean isFriend(String lllllllllllllllIllIlIIIlllllllll) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/a.llIIIllIllIlll : [I
    //   3: iconst_0
    //   4: iaload
    //   5: istore_2
    //   6: aload_0
    //   7: <illegal opcode> 2 : (Lme/stupitdog/bhp/a;)Ljava/util/List;
    //   12: <illegal opcode> 3 : (Ljava/util/List;)Ljava/util/Iterator;
    //   17: astore_3
    //   18: aload_3
    //   19: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   24: invokestatic lIIIIlIlIIllIIIl : (I)Z
    //   27: ifeq -> 136
    //   30: aload_3
    //   31: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   36: checkcast me/stupitdog/bhp/fz
    //   39: astore #4
    //   41: aload #4
    //   43: <illegal opcode> 6 : (Lme/stupitdog/bhp/fz;)Ljava/lang/String;
    //   48: aload_1
    //   49: <illegal opcode> 7 : (Ljava/lang/String;Ljava/lang/Object;)Z
    //   54: invokestatic lIIIIlIlIIllIIIl : (I)Z
    //   57: ifeq -> 66
    //   60: getstatic me/stupitdog/bhp/a.llIIIllIllIlll : [I
    //   63: iconst_1
    //   64: iaload
    //   65: istore_2
    //   66: ldc ''
    //   68: invokevirtual length : ()I
    //   71: pop
    //   72: ldc ' '
    //   74: invokevirtual length : ()I
    //   77: ineg
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: if_icmplt -> 18
    //   86: bipush #110
    //   88: bipush #71
    //   90: ixor
    //   91: sipush #191
    //   94: sipush #154
    //   97: ixor
    //   98: ldc ' '
    //   100: invokevirtual length : ()I
    //   103: ishl
    //   104: ixor
    //   105: bipush #45
    //   107: bipush #18
    //   109: ixor
    //   110: iconst_1
    //   111: bipush #22
    //   113: ixor
    //   114: ldc ' '
    //   116: invokevirtual length : ()I
    //   119: ldc ' '
    //   121: invokevirtual length : ()I
    //   124: ishl
    //   125: ishl
    //   126: ixor
    //   127: ldc ' '
    //   129: invokevirtual length : ()I
    //   132: ineg
    //   133: ixor
    //   134: iand
    //   135: ireturn
    //   136: iload_2
    //   137: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   41	25	4	lllllllllllllllIllIlIIlIIIIIIIIl	Lme/stupitdog/bhp/fz;
    //   0	138	0	lllllllllllllllIllIlIIlIIIIIIIII	Lme/stupitdog/bhp/a;
    //   0	138	1	lllllllllllllllIllIlIIIlllllllll	Ljava/lang/String;
    //   6	132	2	lllllllllllllllIllIlIIIllllllllI	Z
  }
  
  public fz getFriendByName(String lllllllllllllllIllIlIIIllllllIll) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: <illegal opcode> 2 : (Lme/stupitdog/bhp/a;)Ljava/util/List;
    //   8: <illegal opcode> 3 : (Ljava/util/List;)Ljava/util/Iterator;
    //   13: astore_3
    //   14: aload_3
    //   15: <illegal opcode> 4 : (Ljava/util/Iterator;)Z
    //   20: invokestatic lIIIIlIlIIllIIIl : (I)Z
    //   23: ifeq -> 107
    //   26: aload_3
    //   27: <illegal opcode> 5 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   32: checkcast me/stupitdog/bhp/fz
    //   35: astore #4
    //   37: aload #4
    //   39: <illegal opcode> 8 : (Lme/stupitdog/bhp/fz;)Ljava/lang/String;
    //   44: aload_1
    //   45: <illegal opcode> 9 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   50: invokestatic lIIIIlIlIIllIIIl : (I)Z
    //   53: ifeq -> 59
    //   56: aload #4
    //   58: astore_2
    //   59: ldc ''
    //   61: invokevirtual length : ()I
    //   64: pop
    //   65: ldc '   '
    //   67: invokevirtual length : ()I
    //   70: ldc ' '
    //   72: invokevirtual length : ()I
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ishl
    //   81: ishl
    //   82: ldc '   '
    //   84: invokevirtual length : ()I
    //   87: ldc ' '
    //   89: invokevirtual length : ()I
    //   92: ldc ' '
    //   94: invokevirtual length : ()I
    //   97: ishl
    //   98: ishl
    //   99: iconst_m1
    //   100: ixor
    //   101: iand
    //   102: ifeq -> 14
    //   105: aconst_null
    //   106: areturn
    //   107: aload_2
    //   108: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   37	22	4	lllllllllllllllIllIlIIIlllllllIl	Lme/stupitdog/bhp/fz;
    //   0	109	0	lllllllllllllllIllIlIIIlllllllII	Lme/stupitdog/bhp/a;
    //   0	109	1	lllllllllllllllIllIlIIIllllllIll	Ljava/lang/String;
    //   2	107	2	lllllllllllllllIllIlIIIllllllIlI	Lme/stupitdog/bhp/fz;
  }
  
  public void addFriend(String lllllllllllllllIllIlIIIllllllIII, String lllllllllllllllIllIlIIIlllllIlll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/stupitdog/bhp/a;)Ljava/util/List;
    //   6: new me/stupitdog/bhp/fz
    //   9: dup
    //   10: aload_2
    //   11: aload_1
    //   12: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   15: <illegal opcode> 10 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   20: ldc ''
    //   22: invokevirtual length : ()I
    //   25: pop2
    //   26: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	27	0	lllllllllllllllIllIlIIIllllllIIl	Lme/stupitdog/bhp/a;
    //   0	27	1	lllllllllllllllIllIlIIIllllllIII	Ljava/lang/String;
    //   0	27	2	lllllllllllllllIllIlIIIlllllIlll	Ljava/lang/String;
  }
  
  public void delFriend(String lllllllllllllllIllIlIIIlllllIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/stupitdog/bhp/a;)Ljava/util/List;
    //   6: aload_0
    //   7: aload_1
    //   8: <illegal opcode> 11 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)Lme/stupitdog/bhp/fz;
    //   13: <illegal opcode> 12 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop2
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	0	lllllllllllllllIllIlIIIlllllIllI	Lme/stupitdog/bhp/a;
    //   0	25	1	lllllllllllllllIllIlIIIlllllIlIl	Ljava/lang/String;
  }
  
  static {
    lIIIIlIlIIllIIII();
    lIIIIlIlIIlIllll();
    lIIIIlIlIIlIlllI();
    lIIIIlIlIIlIIIIl();
  }
  
  private static CallSite lIIIIlIlIIlIIIII(MethodHandles.Lookup lllllllllllllllIllIlIIIllllIllII, String lllllllllllllllIllIlIIIllllIlIll, MethodType lllllllllllllllIllIlIIIllllIlIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIIlllllIIlI = llIIIllIllIIIl[Integer.parseInt(lllllllllllllllIllIlIIIllllIlIll)].split(llIIIllIllIIll[llIIIllIllIlll[0]]);
      Class<?> lllllllllllllllIllIlIIIlllllIIIl = Class.forName(lllllllllllllllIllIlIIIlllllIIlI[llIIIllIllIlll[0]]);
      String lllllllllllllllIllIlIIIlllllIIII = lllllllllllllllIllIlIIIlllllIIlI[llIIIllIllIlll[1]];
      MethodHandle lllllllllllllllIllIlIIIllllIllll = null;
      int lllllllllllllllIllIlIIIllllIlllI = lllllllllllllllIllIlIIIlllllIIlI[llIIIllIllIlll[2]].length();
      if (lIIIIlIlIIllIIlI(lllllllllllllllIllIlIIIllllIlllI, llIIIllIllIlll[3])) {
        MethodType lllllllllllllllIllIlIIIlllllIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIIlllllIIlI[llIIIllIllIlll[3]], a.class.getClassLoader());
        if (lIIIIlIlIIllIIll(lllllllllllllllIllIlIIIllllIlllI, llIIIllIllIlll[3])) {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findVirtual(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIlII);
          "".length();
          if (((0x26 ^ 0x77) & (0x11 ^ 0x40 ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findStatic(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIlII);
        } 
        "".length();
        if (((0xDC ^ 0xC3) << " ".length() & ((0x7 ^ 0x18) << " ".length() ^ 0xFFFFFFFF)) < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIIlllllIIll = llIIIllIllIIlI[Integer.parseInt(lllllllllllllllIllIlIIIlllllIIlI[llIIIllIllIlll[3]])];
        if (lIIIIlIlIIllIIll(lllllllllllllllIllIlIIIllllIlllI, llIIIllIllIlll[2])) {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findGetter(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIIll);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (lIIIIlIlIIllIIll(lllllllllllllllIllIlIIIllllIlllI, llIIIllIllIlll[4])) {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findStaticGetter(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIIll);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIlIIllIIll(lllllllllllllllIllIlIIIllllIlllI, llIIIllIllIlll[5])) {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findSetter(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIIll);
          "".length();
          if ((((0x8E ^ 0xA3) << " ".length() << " ".length() ^ 111 + 63 - 20 + 25) << " ".length() & (((0x3D ^ 0x3A) << " ".length() << " ".length() << " ".length() ^ 0xCC ^ 0xBB) << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIllllIllll = lllllllllllllllIllIlIIIllllIllII.findStaticSetter(lllllllllllllllIllIlIIIlllllIIIl, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIIlllllIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIIllllIllll);
    } catch (Exception lllllllllllllllIllIlIIIllllIllIl) {
      lllllllllllllllIllIlIIIllllIllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlIIlIIIIl() {
    llIIIllIllIIIl = new String[llIIIllIllIlll[6]];
    llIIIllIllIIIl[llIIIllIllIlll[3]] = llIIIllIllIIll[llIIIllIllIlll[1]];
    llIIIllIllIIIl[llIIIllIllIlll[7]] = llIIIllIllIIll[llIIIllIllIlll[3]];
    llIIIllIllIIIl[llIIIllIllIlll[4]] = llIIIllIllIIll[llIIIllIllIlll[2]];
    llIIIllIllIIIl[llIIIllIllIlll[8]] = llIIIllIllIIll[llIIIllIllIlll[4]];
    llIIIllIllIIIl[llIIIllIllIlll[1]] = llIIIllIllIIll[llIIIllIllIlll[5]];
    llIIIllIllIIIl[llIIIllIllIlll[5]] = llIIIllIllIIll[llIIIllIllIlll[9]];
    llIIIllIllIIIl[llIIIllIllIlll[0]] = llIIIllIllIIll[llIIIllIllIlll[10]];
    llIIIllIllIIIl[llIIIllIllIlll[11]] = llIIIllIllIIll[llIIIllIllIlll[8]];
    llIIIllIllIIIl[llIIIllIllIlll[12]] = llIIIllIllIIll[llIIIllIllIlll[13]];
    llIIIllIllIIIl[llIIIllIllIlll[2]] = llIIIllIllIIll[llIIIllIllIlll[7]];
    llIIIllIllIIIl[llIIIllIllIlll[10]] = llIIIllIllIIll[llIIIllIllIlll[11]];
    llIIIllIllIIIl[llIIIllIllIlll[13]] = llIIIllIllIIll[llIIIllIllIlll[12]];
    llIIIllIllIIIl[llIIIllIllIlll[9]] = llIIIllIllIIll[llIIIllIllIlll[6]];
    llIIIllIllIIlI = new Class[llIIIllIllIlll[1]];
    llIIIllIllIIlI[llIIIllIllIlll[0]] = List.class;
  }
  
  private static void lIIIIlIlIIlIlllI() {
    llIIIllIllIIll = new String[llIIIllIllIlll[14]];
    llIIIllIllIIll[llIIIllIllIlll[0]] = lIIIIlIlIIlIIIlI(llIIIllIllIllI[llIIIllIllIlll[0]], llIIIllIllIllI[llIIIllIllIlll[1]]);
    llIIIllIllIIll[llIIIllIllIlll[1]] = lIIIIlIlIIlIIIll(llIIIllIllIllI[llIIIllIllIlll[3]], llIIIllIllIllI[llIIIllIllIlll[2]]);
    llIIIllIllIIll[llIIIllIllIlll[3]] = lIIIIlIlIIlIIIll(llIIIllIllIllI[llIIIllIllIlll[4]], llIIIllIllIllI[llIIIllIllIlll[5]]);
    llIIIllIllIIll[llIIIllIllIlll[2]] = lIIIIlIlIIlIIIlI(llIIIllIllIllI[llIIIllIllIlll[9]], llIIIllIllIllI[llIIIllIllIlll[10]]);
    llIIIllIllIIll[llIIIllIllIlll[4]] = lIIIIlIlIIlIlIll(llIIIllIllIllI[llIIIllIllIlll[8]], llIIIllIllIllI[llIIIllIllIlll[13]]);
    llIIIllIllIIll[llIIIllIllIlll[5]] = lIIIIlIlIIlIIIll(llIIIllIllIllI[llIIIllIllIlll[7]], llIIIllIllIllI[llIIIllIllIlll[11]]);
    llIIIllIllIIll[llIIIllIllIlll[9]] = lIIIIlIlIIlIIIll(llIIIllIllIllI[llIIIllIllIlll[12]], llIIIllIllIllI[llIIIllIllIlll[6]]);
    llIIIllIllIIll[llIIIllIllIlll[10]] = lIIIIlIlIIlIIIll("17675vmS218XdPZSWxTxkMhVZDMsypcXmZza8L/n4Dky7mx8pGDFTw==", "MrSTt");
    llIIIllIllIIll[llIIIllIllIlll[8]] = lIIIIlIlIIlIIIlI("X3Eg33GfP0foR7nUAVHEaq+1I5U8q1DUJ4MdNbeq7+qqGD2Mp1BFFUALb1FXD5fiYFc7+CQeo3SwUGr8r41c5A6PBAMNQkNg/66PV/4nIvg=", "IiDZH");
    llIIIllIllIIll[llIIIllIllIlll[13]] = lIIIIlIlIIlIIIll("Cqbt6golqgS+N9tOlANqthJBMbr0N4/b/0jDiDuRV+SB02HTuwfw+Ziz8y8bxLZT", "EsAIZ");
    llIIIllIllIIll[llIIIllIllIlll[7]] = lIIIIlIlIIlIlIll("HSo6BkACPyULQDsiPxNUHj8pFQ8DJD5dRl4HJgYYFmQ5EwcbZAUTCwUqOAgcTHFsRw==", "wKLgn");
    llIIIllIllIIll[llIIIllIllIlll[11]] = lIIIIlIlIIlIIIll("khd9NuH06Mdos1sRoCFkUGx1OrBKJl7UbF8Dc4lTE31jWW5OLIRXb3bIFnYGiCujmtVcjsudnu4=", "PoDaU");
    llIIIllIllIIll[llIIIllIllIlll[12]] = lIIIIlIlIIlIlIll("CBMdKUYOEwUvRjEGGSEGBUgOOR0DHhgBDwwdGS0rAwEOckAuGAo+CU0eCiYPTSEfOgEMFVBhMlhSSw==", "brkHh");
    llIIIllIllIIll[llIIIllIllIlll[6]] = lIIIIlIlIIlIlIll("LBxGNS00CQEyPS4eRiQxMVcOPGMmHBwPPXtRQQozIA8JaTUgFw9pCjULASg+ekNIZg==", "AyhFY");
    llIIIllIllIllI = null;
  }
  
  private static void lIIIIlIlIIlIllll() {
    String str = (new Exception()).getStackTrace()[llIIIllIllIlll[0]].getFileName();
    llIIIllIllIllI = str.substring(str.indexOf("ä") + llIIIllIllIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIlIIlIIIll(String lllllllllllllllIllIlIIIllllIIllI, String lllllllllllllllIllIlIIIllllIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIllllIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIllllIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIllllIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIllllIlIII.init(llIIIllIllIlll[3], lllllllllllllllIllIlIIIllllIlIIl);
      return new String(lllllllllllllllIllIlIIIllllIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIllllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIllllIIlll) {
      lllllllllllllllIllIlIIIllllIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIlIIlIlIll(String lllllllllllllllIllIlIIIllllIIIll, String lllllllllllllllIllIlIIIllllIIIlI) {
    lllllllllllllllIllIlIIIllllIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIIllllIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIIllllIIIIl = new StringBuilder();
    char[] lllllllllllllllIllIlIIIllllIIIII = lllllllllllllllIllIlIIIllllIIIlI.toCharArray();
    int lllllllllllllllIllIlIIIlllIlllll = llIIIllIllIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIIllllIIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIllIllIlll[0];
    while (lIIIIlIlIIllIlII(j, i)) {
      char lllllllllllllllIllIlIIIllllIIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIIlllIlllll++;
      j++;
      "".length();
      if (-"  ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIIllllIIIIl);
  }
  
  private static String lIIIIlIlIIlIIIlI(String lllllllllllllllIllIlIIIlllIllIll, String lllllllllllllllIllIlIIIlllIllIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIlllIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIlllIllIlI.getBytes(StandardCharsets.UTF_8)), llIIIllIllIlll[8]), "DES");
      Cipher lllllllllllllllIllIlIIIlllIlllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIlllIlllIl.init(llIIIllIllIlll[3], lllllllllllllllIllIlIIIlllIllllI);
      return new String(lllllllllllllllIllIlIIIlllIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIlllIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIlllIlllII) {
      lllllllllllllllIllIlIIIlllIlllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlIIllIIII() {
    llIIIllIllIlll = new int[15];
    llIIIllIllIlll[0] = (114 + 62 - 127 + 82 ^ (0x2E ^ 0xF) << " ".length() << " ".length()) & ((0x5A ^ 0x7B) << " ".length() << " ".length() ^ 69 + 57 - 0 + 5 ^ -" ".length());
    llIIIllIllIlll[1] = " ".length();
    llIIIllIllIlll[2] = "   ".length();
    llIIIllIllIlll[3] = " ".length() << " ".length();
    llIIIllIllIlll[4] = " ".length() << " ".length() << " ".length();
    llIIIllIllIlll[5] = 0xAA ^ 0xAF;
    llIIIllIllIlll[6] = 0x20 ^ 0x69 ^ (0x4D ^ 0x5C) << " ".length() << " ".length();
    llIIIllIllIlll[7] = ("   ".length() << "   ".length() ^ 0x49 ^ 0x54) << " ".length();
    llIIIllIllIlll[8] = " ".length() << "   ".length();
    llIIIllIllIlll[9] = "   ".length() << " ".length();
    llIIIllIllIlll[10] = 0x9 ^ 0xE;
    llIIIllIllIlll[11] = 0xCF ^ 0xC4;
    llIIIllIllIlll[12] = "   ".length() << " ".length() << " ".length();
    llIIIllIllIlll[13] = 0x8E ^ 0x87;
    llIIIllIllIlll[14] = ((0x4F ^ 0x70) << " ".length() ^ 0x65 ^ 0x1C) << " ".length();
  }
  
  private static boolean lIIIIlIlIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIlIIllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIlIIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIlIIllIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */