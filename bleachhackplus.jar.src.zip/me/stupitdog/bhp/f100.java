package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.network.Packet;

public class f100 extends fs {
  public Packet m_Packet;
  
  private static String[] lIlllIlllIIIll;
  
  private static Class[] lIlllIlllIIlII;
  
  private static final String[] lIlllIlllIIlIl;
  
  private static String[] lIlllIlllIIllI;
  
  private static final int[] lIlllIlllIIlll;
  
  public f100(Packet lllllllllllllllIlllIlIIIlIIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/f100;Lnet/minecraft/network/Packet;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIlIIIlIIIIIlI	Lme/stupitdog/bhp/f100;
    //   0	12	1	lllllllllllllllIlllIlIIIlIIIIIIl	Lnet/minecraft/network/Packet;
  }
  
  public Packet GetPacket() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100;)Lnet/minecraft/network/Packet;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIlIIIlIIIIIII	Lme/stupitdog/bhp/f100;
  }
  
  public Packet getPacket() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lme/stupitdog/bhp/f100;)Lnet/minecraft/network/Packet;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIlIIIIlllllll	Lme/stupitdog/bhp/f100;
  }
  
  static {
    lllllIllllIIIIl();
    lllllIllllIIIII();
    lllllIlllIlllll();
    lllllIlllIlllII();
  }
  
  private static CallSite lllllIlllIllIll(MethodHandles.Lookup lllllllllllllllIlllIlIIIIlllIllI, String lllllllllllllllIlllIlIIIIlllIlIl, MethodType lllllllllllllllIlllIlIIIIlllIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIIIIlllllII = lIlllIlllIIIll[Integer.parseInt(lllllllllllllllIlllIlIIIIlllIlIl)].split(lIlllIlllIIlIl[lIlllIlllIIlll[0]]);
      Class<?> lllllllllllllllIlllIlIIIIllllIll = Class.forName(lllllllllllllllIlllIlIIIIlllllII[lIlllIlllIIlll[0]]);
      String lllllllllllllllIlllIlIIIIllllIlI = lllllllllllllllIlllIlIIIIlllllII[lIlllIlllIIlll[1]];
      MethodHandle lllllllllllllllIlllIlIIIIllllIIl = null;
      int lllllllllllllllIlllIlIIIIllllIII = lllllllllllllllIlllIlIIIIlllllII[lIlllIlllIIlll[2]].length();
      if (lllllIllllIIIlI(lllllllllllllllIlllIlIIIIllllIII, lIlllIlllIIlll[3])) {
        MethodType lllllllllllllllIlllIlIIIIllllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIIIIlllllII[lIlllIlllIIlll[3]], f100.class.getClassLoader());
        if (lllllIllllIIIll(lllllllllllllllIlllIlIIIIllllIII, lIlllIlllIIlll[3])) {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findVirtual(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIllllllI);
          "".length();
          if (((0xF ^ 0x0) << " ".length() & ((0x6C ^ 0x63) << " ".length() ^ 0xFFFFFFFF)) <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findStatic(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIllllllI);
        } 
        "".length();
        if (((0x10 ^ 0x15) << " ".length() << " ".length() << " ".length() & ((0xAE ^ 0xAB) << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIIIIlllllIl = lIlllIlllIIlII[Integer.parseInt(lllllllllllllllIlllIlIIIIlllllII[lIlllIlllIIlll[3]])];
        if (lllllIllllIIIll(lllllllllllllllIlllIlIIIIllllIII, lIlllIlllIIlll[2])) {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findGetter(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIlllllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lllllIllllIIIll(lllllllllllllllIlllIlIIIIllllIII, lIlllIlllIIlll[4])) {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findStaticGetter(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIlllllIl);
          "".length();
          if ((((0x2D ^ 0x28) << (0x8F ^ 0x8A) ^ 114 + 82 - 149 + 108) & (0x3A ^ 0x1B ^ (0x7E ^ 0x73) << " ".length() ^ -" ".length())) >= " ".length() << " ".length())
            return null; 
        } else if (lllllIllllIIIll(lllllllllllllllIlllIlIIIIllllIII, lIlllIlllIIlll[5])) {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findSetter(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIlllllIl);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIIIIllllIIl = lllllllllllllllIlllIlIIIIlllIllI.findStaticSetter(lllllllllllllllIlllIlIIIIllllIll, lllllllllllllllIlllIlIIIIllllIlI, lllllllllllllllIlllIlIIIIlllllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIIIIllllIIl);
    } catch (Exception lllllllllllllllIlllIlIIIIlllIlll) {
      lllllllllllllllIlllIlIIIIlllIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIlllIlllII() {
    lIlllIlllIIIll = new String[lIlllIlllIIlll[3]];
    lIlllIlllIIIll[lIlllIlllIIlll[0]] = lIlllIlllIIlIl[lIlllIlllIIlll[1]];
    lIlllIlllIIIll[lIlllIlllIIlll[1]] = lIlllIlllIIlIl[lIlllIlllIIlll[3]];
    lIlllIlllIIlII = new Class[lIlllIlllIIlll[1]];
    lIlllIlllIIlII[lIlllIlllIIlll[0]] = Packet.class;
  }
  
  private static void lllllIlllIlllll() {
    lIlllIlllIIlIl = new String[lIlllIlllIIlll[2]];
    lIlllIlllIIlIl[lIlllIlllIIlll[0]] = lllllIlllIlllIl(lIlllIlllIIllI[lIlllIlllIIlll[0]], lIlllIlllIIllI[lIlllIlllIIlll[1]]);
    lIlllIlllIIlIl[lIlllIlllIIlll[1]] = lllllIlllIlllIl(lIlllIlllIIllI[lIlllIlllIIlll[3]], lIlllIlllIIllI[lIlllIlllIIlll[2]]);
    lIlllIlllIIlIl[lIlllIlllIIlll[3]] = lllllIlllIllllI(lIlllIlllIIllI[lIlllIlllIIlll[4]], lIlllIlllIIllI[lIlllIlllIIlll[5]]);
    lIlllIlllIIllI = null;
  }
  
  private static void lllllIllllIIIII() {
    String str = (new Exception()).getStackTrace()[lIlllIlllIIlll[0]].getFileName();
    lIlllIlllIIllI = str.substring(str.indexOf("ä") + lIlllIlllIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIlllIlllIl(String lllllllllllllllIlllIlIIIIlllIIII, String lllllllllllllllIlllIlIIIIllIllll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIIlllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIIllIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIIIIlllIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIIIIlllIIlI.init(lIlllIlllIIlll[3], lllllllllllllllIlllIlIIIIlllIIll);
      return new String(lllllllllllllllIlllIlIIIIlllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIIlllIIIl) {
      lllllllllllllllIlllIlIIIIlllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIlllIllllI(String lllllllllllllllIlllIlIIIIllIlIll, String lllllllllllllllIlllIlIIIIllIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIIIIllIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIIllIlIlI.getBytes(StandardCharsets.UTF_8)), lIlllIlllIIlll[6]), "DES");
      Cipher lllllllllllllllIlllIlIIIIllIllIl = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIIIIllIllIl.init(lIlllIlllIIlll[3], lllllllllllllllIlllIlIIIIllIlllI);
      return new String(lllllllllllllllIlllIlIIIIllIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIIllIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIIIIllIllII) {
      lllllllllllllllIlllIlIIIIllIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIllllIIIIl() {
    lIlllIlllIIlll = new int[7];
    lIlllIlllIIlll[0] = " ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ 0xFFFFFFFF);
    lIlllIlllIIlll[1] = " ".length();
    lIlllIlllIIlll[2] = "   ".length();
    lIlllIlllIIlll[3] = " ".length() << " ".length();
    lIlllIlllIIlll[4] = " ".length() << " ".length() << " ".length();
    lIlllIlllIIlll[5] = 0xBF ^ 0xBA;
    lIlllIlllIIlll[6] = " ".length() << "   ".length();
  }
  
  private static boolean lllllIllllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIllllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */