package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.text.TextFormatting;

public class f100000000000000000000000000000000000 extends fh {
  private static String[] llIIIIIIlllIlI;
  
  private static Class[] llIIIIIIlllIll;
  
  private static final String[] llIIIIIllIIlll;
  
  private static String[] llIIIIIllIlIII;
  
  private static final int[] llIIIIIllIlIIl;
  
  public f100000000000000000000000000000000000() {
    super(llIIIIIllIIlll[llIIIIIllIlIIl[0]], llIIIIIllIIlll[llIIIIIllIlIIl[1]], llIIIIIllIIlll[llIIIIIllIlIIl[2]]);
  }
  
  public void runCommand(String[] lllllllllllllllIllIllIlllIIIIIII) {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIlIIl : [I
    //   5: iconst_1
    //   6: iaload
    //   7: invokestatic lIIIIIlIIIIIIIII : (II)Z
    //   10: ifeq -> 288
    //   13: aload_1
    //   14: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIlIIl : [I
    //   17: iconst_1
    //   18: iaload
    //   19: aaload
    //   20: <illegal opcode> 0 : (Ljava/lang/String;)I
    //   25: istore_2
    //   26: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   31: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   36: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   41: invokestatic lIIIIIlIIIIIIIIl : (I)Z
    //   44: ifeq -> 106
    //   47: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   52: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   57: <illegal opcode> 4 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/Entity;
    //   62: ldc ''
    //   64: invokevirtual length : ()I
    //   67: pop
    //   68: ldc ' '
    //   70: invokevirtual length : ()I
    //   73: ldc ' '
    //   75: invokevirtual length : ()I
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ishl
    //   84: ishl
    //   85: ldc ' '
    //   87: invokevirtual length : ()I
    //   90: ldc ' '
    //   92: invokevirtual length : ()I
    //   95: ldc ' '
    //   97: invokevirtual length : ()I
    //   100: ishl
    //   101: ishl
    //   102: if_icmpeq -> 116
    //   105: return
    //   106: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   111: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   116: astore_3
    //   117: aload_3
    //   118: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   123: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   128: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   133: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   138: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   143: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   148: iload_2
    //   149: i2d
    //   150: dadd
    //   151: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   156: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   161: <illegal opcode> 7 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   166: <illegal opcode> 8 : (Lnet/minecraft/entity/Entity;DDD)V
    //   171: new java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIIlll : [Ljava/lang/String;
    //   181: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIlIIl : [I
    //   184: iconst_3
    //   185: iaload
    //   186: aaload
    //   187: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: <illegal opcode> 10 : ()Lnet/minecraft/util/text/TextFormatting;
    //   197: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   202: iload_2
    //   203: <illegal opcode> 12 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   208: <illegal opcode> 13 : ()Lnet/minecraft/util/text/TextFormatting;
    //   213: <illegal opcode> 11 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   218: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIIlll : [Ljava/lang/String;
    //   221: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIlIIl : [I
    //   224: iconst_4
    //   225: iaload
    //   226: aaload
    //   227: <illegal opcode> 9 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: <illegal opcode> 14 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   237: <illegal opcode> 15 : (Ljava/lang/String;)V
    //   242: ldc ''
    //   244: invokevirtual length : ()I
    //   247: pop
    //   248: ldc '   '
    //   250: invokevirtual length : ()I
    //   253: ldc '   '
    //   255: invokevirtual length : ()I
    //   258: iconst_m1
    //   259: ixor
    //   260: iand
    //   261: ldc ' '
    //   263: invokevirtual length : ()I
    //   266: ineg
    //   267: if_icmpgt -> 302
    //   270: return
    //   271: astore_2
    //   272: ldc ''
    //   274: invokevirtual length : ()I
    //   277: pop
    //   278: ldc '   '
    //   280: invokevirtual length : ()I
    //   283: ineg
    //   284: ifle -> 302
    //   287: return
    //   288: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIIlll : [Ljava/lang/String;
    //   291: getstatic me/stupitdog/bhp/f100000000000000000000000000000000000.llIIIIIllIlIIl : [I
    //   294: iconst_5
    //   295: iaload
    //   296: aaload
    //   297: <illegal opcode> 16 : (Ljava/lang/String;)V
    //   302: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   26	216	2	lllllllllllllllIllIllIlllIIIIIll	I
    //   117	125	3	lllllllllllllllIllIllIlllIIIIIlI	Lnet/minecraft/entity/Entity;
    //   0	303	0	lllllllllllllllIllIllIlllIIIIIIl	Lme/stupitdog/bhp/f100000000000000000000000000000000000;
    //   0	303	1	lllllllllllllllIllIllIlllIIIIIII	[Ljava/lang/String;
    // Exception table:
    //   from	to	target	type
    //   13	242	271	java/lang/Exception
  }
  
  static {
    lIIIIIIlllllllll();
    lIIIIIIllllllllI();
    lIIIIIIlllllllIl();
    lIIIIIIllllllIIl();
  }
  
  private static CallSite lIIIIIIlIllllIlI(MethodHandles.Lookup lllllllllllllllIllIllIllIlllIlll, String lllllllllllllllIllIllIllIlllIllI, MethodType lllllllllllllllIllIllIllIlllIlIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIllIlllllIl = llIIIIIIlllIlI[Integer.parseInt(lllllllllllllllIllIllIllIlllIllI)].split(llIIIIIllIIlll[llIIIIIllIlIIl[6]]);
      Class<?> lllllllllllllllIllIllIllIlllllII = Class.forName(lllllllllllllllIllIllIllIlllllIl[llIIIIIllIlIIl[0]]);
      String lllllllllllllllIllIllIllIllllIll = lllllllllllllllIllIllIllIlllllIl[llIIIIIllIlIIl[1]];
      MethodHandle lllllllllllllllIllIllIllIllllIlI = null;
      int lllllllllllllllIllIllIllIllllIIl = lllllllllllllllIllIllIllIlllllIl[llIIIIIllIlIIl[3]].length();
      if (lIIIIIlIIIIIIIlI(lllllllllllllllIllIllIllIllllIIl, llIIIIIllIlIIl[2])) {
        MethodType lllllllllllllllIllIllIllIlllllll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIllIlllllIl[llIIIIIllIlIIl[2]], f100000000000000000000000000000000000.class.getClassLoader());
        if (lIIIIIlIIIIIIIll(lllllllllllllllIllIllIllIllllIIl, llIIIIIllIlIIl[2])) {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findVirtual(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIlllllll);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findStatic(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIlllllll);
        } 
        "".length();
        if (((0xC6 ^ 0x83 ^ (0x70 ^ 0x43) << " ".length()) & (0x72 ^ 0x3 ^ (0x1C ^ 0x35) << " ".length() ^ -" ".length())) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIllIllllllI = llIIIIIIlllIll[Integer.parseInt(lllllllllllllllIllIllIllIlllllIl[llIIIIIllIlIIl[2]])];
        if (lIIIIIlIIIIIIIll(lllllllllllllllIllIllIllIllllIIl, llIIIIIllIlIIl[3])) {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findGetter(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIllllllI);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (lIIIIIlIIIIIIIll(lllllllllllllllIllIllIllIllllIIl, llIIIIIllIlIIl[4])) {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findStaticGetter(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIllllllI);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else if (lIIIIIlIIIIIIIll(lllllllllllllllIllIllIllIllllIIl, llIIIIIllIlIIl[5])) {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findSetter(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIllllllI);
          "".length();
          if ((0x86 ^ 0x83) <= 0)
            return null; 
        } else {
          lllllllllllllllIllIllIllIllllIlI = lllllllllllllllIllIllIllIlllIlll.findStaticSetter(lllllllllllllllIllIllIllIlllllII, lllllllllllllllIllIllIllIllllIll, lllllllllllllllIllIllIllIllllllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIllIllllIlI);
    } catch (Exception lllllllllllllllIllIllIllIllllIII) {
      lllllllllllllllIllIllIllIllllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIllllllIIl() {
    llIIIIIIlllIlI = new String[llIIIIIllIlIIl[7]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[8]] = llIIIIIllIIlll[llIIIIIllIlIIl[9]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[10]] = llIIIIIllIIlll[llIIIIIllIlIIl[11]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[5]] = llIIIIIllIIlll[llIIIIIllIlIIl[10]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[4]] = llIIIIIllIIlll[llIIIIIllIlIIl[12]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[2]] = llIIIIIllIIlll[llIIIIIllIlIIl[13]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[9]] = llIIIIIllIIlll[llIIIIIllIlIIl[14]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[0]] = llIIIIIllIIlll[llIIIIIllIlIIl[15]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[14]] = llIIIIIllIIlll[llIIIIIllIlIIl[8]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[11]] = llIIIIIllIIlll[llIIIIIllIlIIl[16]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[3]] = llIIIIIllIIlll[llIIIIIllIlIIl[17]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[15]] = llIIIIIllIIlll[llIIIIIllIlIIl[7]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[13]] = llIIIIIllIIlll[llIIIIIllIlIIl[18]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[16]] = llIIIIIllIIlll[llIIIIIllIlIIl[19]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[1]] = llIIIIIllIIlll[llIIIIIllIlIIl[20]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[6]] = llIIIIIllIIlll[llIIIIIllIlIIl[21]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[12]] = llIIIIIllIIlll[llIIIIIllIlIIl[22]];
    llIIIIIIlllIlI[llIIIIIllIlIIl[17]] = llIIIIIllIIlll[llIIIIIllIlIIl[23]];
    llIIIIIIlllIll = new Class[llIIIIIllIlIIl[3]];
    llIIIIIIlllIll[llIIIIIllIlIIl[0]] = EntityPlayerSP.class;
    llIIIIIIlllIll[llIIIIIllIlIIl[2]] = TextFormatting.class;
    llIIIIIIlllIll[llIIIIIllIlIIl[1]] = double.class;
  }
  
  private static void lIIIIIIlllllllIl() {
    llIIIIIllIIlll = new String[llIIIIIllIlIIl[24]];
    llIIIIIllIIlll[llIIIIIllIlIIl[0]] = lIIIIIIllllllIlI(llIIIIIllIlIII[llIIIIIllIlIIl[0]], llIIIIIllIlIII[llIIIIIllIlIIl[1]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[1]] = lIIIIIIllllllIll(llIIIIIllIlIII[llIIIIIllIlIIl[2]], llIIIIIllIlIII[llIIIIIllIlIIl[3]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[2]] = lIIIIIIllllllIll(llIIIIIllIlIII[llIIIIIllIlIIl[4]], llIIIIIllIlIII[llIIIIIllIlIIl[5]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[3]] = lIIIIIIlllllllII(llIIIIIllIlIII[llIIIIIllIlIIl[6]], llIIIIIllIlIII[llIIIIIllIlIIl[9]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[4]] = lIIIIIIllllllIll(llIIIIIllIlIII[llIIIIIllIlIIl[11]], llIIIIIllIlIII[llIIIIIllIlIIl[10]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[5]] = lIIIIIIllllllIlI(llIIIIIllIlIII[llIIIIIllIlIIl[12]], llIIIIIllIlIII[llIIIIIllIlIIl[13]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[6]] = lIIIIIIllllllIll(llIIIIIllIlIII[llIIIIIllIlIIl[14]], llIIIIIllIlIII[llIIIIIllIlIIl[15]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[9]] = lIIIIIIllllllIlI(llIIIIIllIlIII[llIIIIIllIlIIl[8]], llIIIIIllIlIII[llIIIIIllIlIIl[16]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[11]] = lIIIIIIlllllllII(llIIIIIllIlIII[llIIIIIllIlIIl[17]], llIIIIIllIlIII[llIIIIIllIlIIl[7]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[10]] = lIIIIIIllllllIll(llIIIIIllIlIII[llIIIIIllIlIIl[18]], llIIIIIllIlIII[llIIIIIllIlIIl[19]]);
    llIIIIIllIIlll[llIIIIIllIlIIl[12]] = lIIIIIIllllllIlI("09Jhm4coSJRKZLwSEGFOBrA8ORr10xq5UVYSyjrI6SDOr3L2d5jo6Cg1NJoe094Erk3ayO4a79guQQa5Kek6GVlX2utM6/cyH3pMTU5cMM9vNYPaw6/45PQ/1MxaFoY7", "efHrX");
    llIIIIIllIIlll[llIIIIIllIlIIl[13]] = lIIIIIIllllllIll("NwkFYj8wAhQvIDgKBWIxNQUUIiZ3IRgiNzoeEComYwoYKT49M0Z9ZmpVLitoaVZRbHI=", "YlqLR");
    llIIIIIllIIlll[llIIIIIllIlIIl[14]] = lIIIIIIllllllIlI("lK9j+A678+IlRGJpD7R5g4LKlqckvjdQgo3mr/lxJKo8k907zmwHWDmGAwRycIpV3jIjNyZRWnK0CR7umjtxWA==", "YVpNN");
    llIIIIIllIIlll[llIIIIIllIlIIl[15]] = lIIIIIIllllllIll("OiMgFGY8IzgSZhksIhAvNTBsBSkiMTM8JiR4fjkiMTQ3WiQxLDFaGyQwPxsva2sfT2g=", "PBVuH");
    llIIIIIllIIlll[llIIIIIllIlIIl[8]] = lIIIIIIlllllllII("pb/pXQo595qUp2R34o3VCmevfDJV07uqMgp8Jtfmc/cKsaEBLjyYN9kBKVlvLEcMlu2vS6y+shSNEb4ezcje4w==", "ZKOpx");
    llIIIIIllIIlll[llIIIIIllIlIIl[16]] = lIIIIIIllllllIlI("mabIWJAEN29p5/EbFJqpKVgnshtFHJVgjefCjYVJIvktIIczFFKtnEFfXEyRH+G+1MB+PwKbFqI=", "wbExA");
    llIIIIIllIIlll[llIIIIIllIlIIl[17]] = lIIIIIIllllllIlI("j3RBEhzldxje9V6CTiix6XoZchRMbvdQ/v4MOxBhXMUC6XGGv+WwPH7JoyBfjF1D/k38WYgbaIDIqMzCebvkpM3YzhLePxSr", "gBsgV");
    llIIIIIllIIlll[llIIIIIllIlIIl[7]] = lIIIIIIllllllIlI("a75gr5FePRsPxUOZlc85SuSR5McQ0/yqJdXZd5sAEmn2hYsc/FgFMsGHdUW3FpZLZMsaK/BlpFU=", "OiPfA");
    llIIIIIllIIlll[llIIIIIllIlIIl[18]] = lIIIIIIllllllIll("OwYSKF09BgouXQITFiAdNiURIB81AhZzEiEXAScXa08oIxInBkslEj8ASwYROwIHPUh4Kw4oBTBICCgdNkg3PQE4CQMLBjgLACwBal1EaQ==", "QgdIs");
    llIIIIIllIIlll[llIIIIIllIlIIl[19]] = lIIIIIIllllllIlI("OhhsZmrfqQWT59TqmEYzmANq3pYslDGZHQ4Q9lsdqUve1AI9L9cf3mMjCHX1R3WTC/gofvZJICkpMdNSd0WcPg==", "UBoxJ");
    llIIIIIllIIlll[llIIIIIllIlIIl[20]] = lIIIIIIllllllIlI("R77W2301MeG+xZ5QnE//Puber7ATgYXDqUIYHV7CJdfjvO6hF1nXeJJTqIDQkL2I85DcYCehIxNCkUMcJnrJoTqhoM1JYA+Mqd+S0zYUahCTsZ47ADIxIw==", "Azggk");
    llIIIIIllIIlll[llIIIIIllIlIIl[21]] = lIIIIIIllllllIll("JSQTQjkiLwIPJionE0I3JygCAiBlJAkYPT84SSk6PygTFQQnIB4JJhgRXQo9Li0DM2N7cFFfCz57VlZ0a2E=", "KAglT");
    llIIIIIllIIlll[llIIIIIllIlIIl[22]] = lIIIIIIllllllIlI("kIksfh3bZnxeMVbln7ewT4ur02IciZ9EJaGMGhrqFTM2tGR+AFoL/BTBAHT+a5iMvs8siLIhJJA=", "tFwQH");
    llIIIIIllIIlll[llIIIIIllIlIIl[23]] = lIIIIIIllllllIll("DjNjFTcWJiQSJwwxYwQrE3gsEnkQMyMCAAs3OSMxETk/KyYQJSwBJll+AQwiFTdiCiINMWI1NxE/IwF4SgB3Rg==", "cVMfC");
    llIIIIIllIlIII = null;
  }
  
  private static void lIIIIIIllllllllI() {
    String str = (new Exception()).getStackTrace()[llIIIIIllIlIIl[0]].getFileName();
    llIIIIIllIlIII = str.substring(str.indexOf("ä") + llIIIIIllIlIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIllllllIll(String lllllllllllllllIllIllIllIlllIIll, String lllllllllllllllIllIllIllIlllIIlI) {
    lllllllllllllllIllIllIllIlllIIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIllIlllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIllIlllIIIl = new StringBuilder();
    char[] lllllllllllllllIllIllIllIlllIIII = lllllllllllllllIllIllIllIlllIIlI.toCharArray();
    int lllllllllllllllIllIllIllIllIllll = llIIIIIllIlIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIllIlllIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIllIlIIl[0];
    while (lIIIIIlIIIIIIlII(j, i)) {
      char lllllllllllllllIllIllIllIlllIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIllIllIllll++;
      j++;
      "".length();
      if ((((0x43 ^ 0x4A) << " ".length() << " ".length() ^ 0xFF ^ 0x9A) & ((0x34 ^ 0x29) << "   ".length() ^ 48 + 84 - 59 + 96 ^ -" ".length())) > " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIllIlllIIIl);
  }
  
  private static String lIIIIIIllllllIlI(String lllllllllllllllIllIllIllIllIlIll, String lllllllllllllllIllIllIllIllIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIllIllIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIllIllIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIllIllIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIllIllIllIl.init(llIIIIIllIlIIl[2], lllllllllllllllIllIllIllIllIlllI);
      return new String(lllllllllllllllIllIllIllIllIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIllIllIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIllIllIllII) {
      lllllllllllllllIllIllIllIllIllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlllllllII(String lllllllllllllllIllIllIllIllIIllI, String lllllllllllllllIllIllIllIllIIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIllIllIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIllIllIIlIl.getBytes(StandardCharsets.UTF_8)), llIIIIIllIlIIl[11]), "DES");
      Cipher lllllllllllllllIllIllIllIllIlIII = Cipher.getInstance("DES");
      lllllllllllllllIllIllIllIllIlIII.init(llIIIIIllIlIIl[2], lllllllllllllllIllIllIllIllIlIIl);
      return new String(lllllllllllllllIllIllIllIllIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIllIllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIllIllIIlll) {
      lllllllllllllllIllIllIllIllIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlllllllll() {
    llIIIIIllIlIIl = new int[25];
    llIIIIIllIlIIl[0] = (0x8A ^ 0x85) << " ".length() & ((0x4A ^ 0x45) << " ".length() ^ 0xFFFFFFFF);
    llIIIIIllIlIIl[1] = " ".length();
    llIIIIIllIlIIl[2] = " ".length() << " ".length();
    llIIIIIllIlIIl[3] = "   ".length();
    llIIIIIllIlIIl[4] = " ".length() << " ".length() << " ".length();
    llIIIIIllIlIIl[5] = 0xF2 ^ 0x89 ^ (0xA2 ^ 0x9D) << " ".length();
    llIIIIIllIlIIl[6] = "   ".length() << " ".length();
    llIIIIIllIlIIl[7] = 0x5E ^ 0x4F;
    llIIIIIllIlIIl[8] = (0x2C ^ 0x2B) << " ".length();
    llIIIIIllIlIIl[9] = 0x8F ^ 0x88;
    llIIIIIllIlIIl[10] = 0xB7 ^ 0xBE;
    llIIIIIllIlIIl[11] = " ".length() << "   ".length();
    llIIIIIllIlIIl[12] = ((0x63 ^ 0x68) << " ".length() << " ".length() << " ".length() ^ 108 + 119 - 58 + 12) << " ".length();
    llIIIIIllIlIIl[13] = 0x8A ^ 0x99 ^ "   ".length() << "   ".length();
    llIIIIIllIlIIl[14] = "   ".length() << " ".length() << " ".length();
    llIIIIIllIlIIl[15] = 0xB7 ^ 0xBA;
    llIIIIIllIlIIl[16] = 0x82 ^ 0x8D;
    llIIIIIllIlIIl[17] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIllIlIIl[18] = (0xA ^ 0x3) << " ".length();
    llIIIIIllIlIIl[19] = 0x33 ^ 0x20;
    llIIIIIllIlIIl[20] = ((0xD ^ 0x5E) << " ".length() ^ 107 + 78 - 85 + 63) << " ".length() << " ".length();
    llIIIIIllIlIIl[21] = 0x90 ^ 0x85;
    llIIIIIllIlIIl[22] = (0x91 ^ 0x9A) << " ".length();
    llIIIIIllIlIIl[23] = 0x7E ^ 0x69;
    llIIIIIllIlIIl[24] = "   ".length() << "   ".length();
  }
  
  private static boolean lIIIIIlIIIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIIIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIIIIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlIIIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lIIIIIlIIIIIIIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f100000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */