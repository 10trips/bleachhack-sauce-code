package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class f0h extends au {
  f100000000000000000000.Boolean place;
  
  f100000000000000000000.Boolean explode;
  
  f100000000000000000000.Boolean rotate;
  
  f100000000000000000000.Boolean rayTrace;
  
  f100000000000000000000.Boolean onedot13;
  
  f100000000000000000000.Double placeRange;
  
  f100000000000000000000.Double placeDelay;
  
  f100000000000000000000.Mode breakMode;
  
  f100000000000000000000.Double breakRange;
  
  f100000000000000000000.Double breakDelay;
  
  f100000000000000000000.Boolean cancelCrystal;
  
  f100000000000000000000.Double minDmg;
  
  f100000000000000000000.Double maxSelfDmg;
  
  f100000000000000000000.Double facePlaceDmg;
  
  f100000000000000000000.Boolean doSwitch;
  
  f100000000000000000000.Mode switchMode;
  
  f100000000000000000000.Boolean render;
  
  f100000000000000000000.ColorSetting color;
  
  f100000000000000000000.Boolean rDamage;
  
  public ao breakTimer;
  
  public ao placeTimer;
  
  private Entity renderEnt;
  
  private ArrayList<BlockPos> PlacedCrystals;
  
  private BlockPos renderBlock;
  
  private EnumFacing enumFacing;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private static boolean isSpoofingAngles;
  
  private static double yaw;
  
  private static double pitch;
  
  private static String[] lIllIlIlIIIlll;
  
  private static Class[] lIllIlIlIIlIII;
  
  private static final String[] lIlllIIIllIlII;
  
  private static String[] lIlllIIIllllll;
  
  private static final int[] lIlllIIlIIIIII;
  
  public f0h() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/stupitdog/bhp/ao
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/ao;)V
    //   54: aload_0
    //   55: new me/stupitdog/bhp/ao
    //   58: dup
    //   59: invokespecial <init> : ()V
    //   62: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/ao;)V
    //   67: aload_0
    //   68: new java/util/ArrayList
    //   71: dup
    //   72: invokespecial <init> : ()V
    //   75: <illegal opcode> 3 : (Lme/stupitdog/bhp/f0h;Ljava/util/ArrayList;)V
    //   80: aload_0
    //   81: new me/zero/alpine/listener/Listener
    //   84: dup
    //   85: aload_0
    //   86: <illegal opcode> invoke : (Lme/stupitdog/bhp/f0h;)Lme/zero/alpine/listener/EventHook;
    //   91: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   94: iconst_0
    //   95: iaload
    //   96: anewarray java/util/function/Predicate
    //   99: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   102: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0h;Lme/zero/alpine/listener/Listener;)V
    //   107: new java/util/ArrayList
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: astore_1
    //   115: aload_1
    //   116: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   119: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   122: iconst_3
    //   123: iaload
    //   124: aaload
    //   125: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   130: ldc ''
    //   132: invokevirtual length : ()I
    //   135: pop2
    //   136: aload_1
    //   137: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   140: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   143: iconst_4
    //   144: iaload
    //   145: aaload
    //   146: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   151: ldc ''
    //   153: invokevirtual length : ()I
    //   156: pop2
    //   157: aload_1
    //   158: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   161: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   164: iconst_5
    //   165: iaload
    //   166: aaload
    //   167: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   172: ldc ''
    //   174: invokevirtual length : ()I
    //   177: pop2
    //   178: new java/util/ArrayList
    //   181: dup
    //   182: invokespecial <init> : ()V
    //   185: astore_2
    //   186: aload_2
    //   187: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   190: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   193: bipush #6
    //   195: iaload
    //   196: aaload
    //   197: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   202: ldc ''
    //   204: invokevirtual length : ()I
    //   207: pop2
    //   208: aload_2
    //   209: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   212: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   215: bipush #7
    //   217: iaload
    //   218: aaload
    //   219: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   224: ldc ''
    //   226: invokevirtual length : ()I
    //   229: pop2
    //   230: aload_0
    //   231: aload_0
    //   232: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   235: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   238: bipush #8
    //   240: iaload
    //   241: aaload
    //   242: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   245: iconst_1
    //   246: iaload
    //   247: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   252: <illegal opcode> 7 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   257: aload_0
    //   258: aload_0
    //   259: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   262: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   265: bipush #9
    //   267: iaload
    //   268: aaload
    //   269: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   272: iconst_1
    //   273: iaload
    //   274: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   279: <illegal opcode> 8 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   284: aload_0
    //   285: aload_0
    //   286: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   289: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   292: bipush #10
    //   294: iaload
    //   295: aaload
    //   296: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   299: iconst_1
    //   300: iaload
    //   301: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   306: <illegal opcode> 9 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   311: aload_0
    //   312: aload_0
    //   313: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   316: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   319: bipush #11
    //   321: iaload
    //   322: aaload
    //   323: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   326: iconst_1
    //   327: iaload
    //   328: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   333: <illegal opcode> 10 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   338: aload_0
    //   339: aload_0
    //   340: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   343: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   346: bipush #12
    //   348: iaload
    //   349: aaload
    //   350: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   353: iconst_0
    //   354: iaload
    //   355: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   360: <illegal opcode> 11 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   365: aload_0
    //   366: aload_0
    //   367: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   370: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   373: bipush #13
    //   375: iaload
    //   376: aaload
    //   377: ldc2_w 4.4
    //   380: dconst_0
    //   381: ldc2_w 10.0
    //   384: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   389: <illegal opcode> 13 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   394: aload_0
    //   395: aload_0
    //   396: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   399: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   402: bipush #14
    //   404: iaload
    //   405: aaload
    //   406: ldc2_w 20.0
    //   409: dconst_1
    //   410: ldc2_w 20.0
    //   413: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   418: <illegal opcode> 14 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   423: aload_0
    //   424: aload_0
    //   425: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   428: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   431: bipush #15
    //   433: iaload
    //   434: aaload
    //   435: aload_1
    //   436: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   439: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   442: bipush #16
    //   444: iaload
    //   445: aaload
    //   446: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   451: <illegal opcode> 16 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   456: aload_0
    //   457: aload_0
    //   458: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   461: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   464: bipush #17
    //   466: iaload
    //   467: aaload
    //   468: ldc2_w 4.4
    //   471: dconst_0
    //   472: ldc2_w 10.0
    //   475: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   480: <illegal opcode> 17 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   485: aload_0
    //   486: aload_0
    //   487: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   490: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   493: bipush #18
    //   495: iaload
    //   496: aaload
    //   497: ldc2_w 20.0
    //   500: dconst_1
    //   501: ldc2_w 20.0
    //   504: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   509: <illegal opcode> 18 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   514: aload_0
    //   515: aload_0
    //   516: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   519: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   522: bipush #19
    //   524: iaload
    //   525: aaload
    //   526: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   529: iconst_1
    //   530: iaload
    //   531: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   536: <illegal opcode> 19 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   541: aload_0
    //   542: aload_0
    //   543: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   546: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   549: bipush #20
    //   551: iaload
    //   552: aaload
    //   553: ldc2_w 8.0
    //   556: dconst_0
    //   557: ldc2_w 36.0
    //   560: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   565: <illegal opcode> 20 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   570: aload_0
    //   571: aload_0
    //   572: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   575: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   578: bipush #21
    //   580: iaload
    //   581: aaload
    //   582: ldc2_w 8.0
    //   585: dconst_0
    //   586: ldc2_w 36.0
    //   589: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   594: <illegal opcode> 21 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   599: aload_0
    //   600: aload_0
    //   601: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   604: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   607: bipush #22
    //   609: iaload
    //   610: aaload
    //   611: ldc2_w 8.0
    //   614: dconst_0
    //   615: ldc2_w 36.0
    //   618: <illegal opcode> 12 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   623: <illegal opcode> 22 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   628: aload_0
    //   629: aload_0
    //   630: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   633: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   636: bipush #23
    //   638: iaload
    //   639: aaload
    //   640: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   643: iconst_1
    //   644: iaload
    //   645: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   650: <illegal opcode> 23 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   655: aload_0
    //   656: aload_0
    //   657: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   660: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   663: bipush #24
    //   665: iaload
    //   666: aaload
    //   667: aload_2
    //   668: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   671: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   674: bipush #25
    //   676: iaload
    //   677: aaload
    //   678: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   683: <illegal opcode> 24 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   688: aload_0
    //   689: aload_0
    //   690: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   693: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   696: bipush #26
    //   698: iaload
    //   699: aaload
    //   700: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   703: iconst_1
    //   704: iaload
    //   705: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   710: <illegal opcode> 25 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   715: aload_0
    //   716: aload_0
    //   717: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   720: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   723: bipush #27
    //   725: iaload
    //   726: aaload
    //   727: new me/stupitdog/bhp/f01
    //   730: dup
    //   731: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   734: bipush #28
    //   736: iaload
    //   737: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   740: bipush #28
    //   742: iaload
    //   743: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   746: bipush #28
    //   748: iaload
    //   749: invokespecial <init> : (III)V
    //   752: <illegal opcode> 26 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   757: <illegal opcode> 27 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   762: aload_0
    //   763: aload_0
    //   764: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   767: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   770: bipush #29
    //   772: iaload
    //   773: aaload
    //   774: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   777: iconst_1
    //   778: iaload
    //   779: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   784: <illegal opcode> 28 : (Lme/stupitdog/bhp/f0h;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   789: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	790	0	lllllllllllllllIlllIlllIllIIIllI	Lme/stupitdog/bhp/f0h;
    //   115	675	1	lllllllllllllllIlllIlllIllIIIlIl	Ljava/util/ArrayList;
    //   186	604	2	lllllllllllllllIlllIlllIllIIIlII	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   115	675	1	lllllllllllllllIlllIlllIllIIIlIl	Ljava/util/ArrayList<Ljava/lang/String;>;
    //   186	604	2	lllllllllllllllIlllIlllIllIIIlII	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void update() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 29 : (Lme/stupitdog/bhp/f0h;)V
    //   6: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIlllIllIIIIll	Lme/stupitdog/bhp/f0h;
  }
  
  public void implLogic() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0h;)V
    //   6: aload_0
    //   7: <illegal opcode> 31 : (Lme/stupitdog/bhp/f0h;)V
    //   12: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIlllIlllIllIIIIlI	Lme/stupitdog/bhp/f0h;
  }
  
  public void placeLogic() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 32 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: invokestatic lllllIIIIlIlIII : (I)Z
    //   14: ifeq -> 1793
    //   17: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   32: <illegal opcode> 37 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   37: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   40: iconst_0
    //   41: iaload
    //   42: <illegal opcode> 38 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   47: checkcast net/minecraft/item/ItemStack
    //   50: <illegal opcode> 39 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   55: <illegal opcode> 40 : ()Lnet/minecraft/item/Item;
    //   60: invokestatic lllllIIIIlIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   63: ifeq -> 94
    //   66: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   69: iconst_1
    //   70: iaload
    //   71: istore_1
    //   72: ldc ''
    //   74: invokevirtual length : ()I
    //   77: pop
    //   78: ldc_w ' '
    //   81: invokevirtual length : ()I
    //   84: ldc_w '   '
    //   87: invokevirtual length : ()I
    //   90: if_icmplt -> 100
    //   93: return
    //   94: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   97: iconst_0
    //   98: iaload
    //   99: istore_1
    //   100: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   105: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   110: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   115: <illegal opcode> 41 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   120: istore_2
    //   121: aload_0
    //   122: <illegal opcode> 42 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   127: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   132: invokestatic lllllIIIIlIlIII : (I)Z
    //   135: ifeq -> 231
    //   138: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   141: iconst_0
    //   142: iaload
    //   143: istore_3
    //   144: iload_3
    //   145: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   148: bipush #9
    //   150: iaload
    //   151: invokestatic lllllIIIIlIlIlI : (II)Z
    //   154: ifeq -> 231
    //   157: <illegal opcode> 43 : ()Lnet/minecraft/client/Minecraft;
    //   162: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   167: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   172: iload_3
    //   173: <illegal opcode> 44 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   178: <illegal opcode> 39 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   183: astore #4
    //   185: aload #4
    //   187: <illegal opcode> 40 : ()Lnet/minecraft/item/Item;
    //   192: invokestatic lllllIIIIlIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   195: ifeq -> 217
    //   198: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   203: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   208: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   213: iload_3
    //   214: putfield field_70461_c : I
    //   217: iinc #3, 1
    //   220: ldc ''
    //   222: invokevirtual length : ()I
    //   225: pop
    //   226: aconst_null
    //   227: ifnull -> 144
    //   230: return
    //   231: aload_0
    //   232: invokespecial findCrystalBlocks : ()Ljava/util/List;
    //   235: astore_3
    //   236: new java/util/ArrayList
    //   239: dup
    //   240: invokespecial <init> : ()V
    //   243: astore #4
    //   245: aload #4
    //   247: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   252: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   257: <illegal opcode> 46 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   262: <illegal opcode> 47 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   267: <illegal opcode> 48 : ()Ljava/util/stream/Collector;
    //   272: <illegal opcode> 49 : (Ljava/util/stream/Stream;Ljava/util/stream/Collector;)Ljava/lang/Object;
    //   277: checkcast java/util/Collection
    //   280: <illegal opcode> 50 : (Ljava/util/List;Ljava/util/Collection;)Z
    //   285: ldc ''
    //   287: invokevirtual length : ()I
    //   290: pop2
    //   291: aconst_null
    //   292: astore #5
    //   294: ldc2_w 0.5
    //   297: dstore #6
    //   299: aload_0
    //   300: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   303: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   306: bipush #30
    //   308: iaload
    //   309: aaload
    //   310: <illegal opcode> 51 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;)V
    //   315: aload #4
    //   317: <illegal opcode> 52 : (Ljava/util/List;)Ljava/util/Iterator;
    //   322: astore #8
    //   324: aload #8
    //   326: <illegal opcode> 53 : (Ljava/util/Iterator;)Z
    //   331: invokestatic lllllIIIIlIlIII : (I)Z
    //   334: ifeq -> 1028
    //   337: aload #8
    //   339: <illegal opcode> 54 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   344: checkcast net/minecraft/entity/Entity
    //   347: astore #9
    //   349: aload #9
    //   351: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   356: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   361: invokestatic lllllIIIIlIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   364: ifeq -> 324
    //   367: aload #9
    //   369: checkcast net/minecraft/entity/EntityLivingBase
    //   372: <illegal opcode> 55 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   377: fconst_0
    //   378: invokestatic lllllIIIIlIIlIl : (FF)I
    //   381: invokestatic lllllIIIIlIllII : (I)Z
    //   384: ifeq -> 324
    //   387: <illegal opcode> 56 : ()Lme/stupitdog/bhp/f9;
    //   392: <illegal opcode> 57 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   397: aload #9
    //   399: <illegal opcode> 58 : (Lnet/minecraft/entity/Entity;)Ljava/util/UUID;
    //   404: <illegal opcode> 59 : (Ljava/util/UUID;)Ljava/lang/String;
    //   409: <illegal opcode> 60 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)Z
    //   414: invokestatic lllllIIIIlIlIII : (I)Z
    //   417: ifeq -> 442
    //   420: ldc ''
    //   422: invokevirtual length : ()I
    //   425: pop
    //   426: ldc_w ' '
    //   429: invokevirtual length : ()I
    //   432: ldc_w '   '
    //   435: invokevirtual length : ()I
    //   438: if_icmplt -> 324
    //   441: return
    //   442: aload_3
    //   443: <illegal opcode> 52 : (Ljava/util/List;)Ljava/util/Iterator;
    //   448: astore #10
    //   450: aload #10
    //   452: <illegal opcode> 53 : (Ljava/util/Iterator;)Z
    //   457: invokestatic lllllIIIIlIlIII : (I)Z
    //   460: ifeq -> 1004
    //   463: aload #10
    //   465: <illegal opcode> 54 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   470: checkcast net/minecraft/util/math/BlockPos
    //   473: astore #11
    //   475: aload #9
    //   477: aload #11
    //   479: <illegal opcode> 61 : (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/BlockPos;)D
    //   484: dstore #12
    //   486: dload #12
    //   488: aload_0
    //   489: <illegal opcode> 62 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   494: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   499: ldc2_w 2.0
    //   502: <illegal opcode> 64 : (DD)D
    //   507: invokestatic lllllIIIIlIIllI : (DD)I
    //   510: invokestatic lllllIIIIlIlllI : (I)Z
    //   513: ifeq -> 532
    //   516: ldc ''
    //   518: invokevirtual length : ()I
    //   521: pop
    //   522: ldc_w ' '
    //   525: invokevirtual length : ()I
    //   528: ifgt -> 450
    //   531: return
    //   532: aload #11
    //   534: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   539: i2d
    //   540: ldc2_w 0.5
    //   543: dadd
    //   544: aload #11
    //   546: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   551: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   554: iconst_1
    //   555: iaload
    //   556: iadd
    //   557: i2d
    //   558: aload #11
    //   560: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   565: i2d
    //   566: ldc2_w 0.5
    //   569: dadd
    //   570: aload #9
    //   572: <illegal opcode> 68 : (DDDLnet/minecraft/entity/Entity;)F
    //   577: f2d
    //   578: dstore #14
    //   580: dload #14
    //   582: aload_0
    //   583: <illegal opcode> 69 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   588: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   593: invokestatic lllllIIIIlIIlll : (DD)I
    //   596: invokestatic lllllIIIIlIllll : (I)Z
    //   599: ifeq -> 667
    //   602: aload #9
    //   604: checkcast net/minecraft/entity/EntityLivingBase
    //   607: <illegal opcode> 55 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   612: aload #9
    //   614: checkcast net/minecraft/entity/EntityLivingBase
    //   617: <illegal opcode> 70 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   622: fadd
    //   623: f2d
    //   624: aload_0
    //   625: <illegal opcode> 71 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   630: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   635: invokestatic lllllIIIIlIIllI : (DD)I
    //   638: invokestatic lllllIIIIlIllII : (I)Z
    //   641: ifeq -> 667
    //   644: ldc ''
    //   646: invokevirtual length : ()I
    //   649: pop
    //   650: ldc_w ' '
    //   653: invokevirtual length : ()I
    //   656: ldc_w ' '
    //   659: invokevirtual length : ()I
    //   662: ishl
    //   663: ifgt -> 450
    //   666: return
    //   667: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   672: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   677: aload #11
    //   679: <illegal opcode> 72 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   684: <illegal opcode> 72 : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/BlockPos;
    //   689: <illegal opcode> 73 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   694: <illegal opcode> 74 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   699: <illegal opcode> 75 : ()Lnet/minecraft/block/Block;
    //   704: invokestatic lllllIIIIlIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   707: ifeq -> 755
    //   710: aload_0
    //   711: <illegal opcode> 76 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   716: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   721: invokestatic lllllIIIIllIIII : (I)Z
    //   724: ifeq -> 755
    //   727: ldc ''
    //   729: invokevirtual length : ()I
    //   732: pop
    //   733: bipush #98
    //   735: bipush #15
    //   737: ixor
    //   738: bipush #25
    //   740: bipush #20
    //   742: ixor
    //   743: ldc_w '   '
    //   746: invokevirtual length : ()I
    //   749: ishl
    //   750: ixor
    //   751: ifgt -> 450
    //   754: return
    //   755: dload #14
    //   757: dload #6
    //   759: invokestatic lllllIIIIlIIllI : (DD)I
    //   762: invokestatic lllllIIIIlIllII : (I)Z
    //   765: ifeq -> 988
    //   768: aload #11
    //   770: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   775: i2d
    //   776: ldc2_w 0.5
    //   779: dadd
    //   780: aload #11
    //   782: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   787: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   790: iconst_1
    //   791: iaload
    //   792: iadd
    //   793: i2d
    //   794: aload #11
    //   796: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   801: i2d
    //   802: ldc2_w 0.5
    //   805: dadd
    //   806: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   811: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   816: <illegal opcode> 68 : (DDDLnet/minecraft/entity/Entity;)F
    //   821: f2d
    //   822: dstore #16
    //   824: dload #16
    //   826: dload #14
    //   828: invokestatic lllllIIIIlIIllI : (DD)I
    //   831: invokestatic lllllIIIIlIllII : (I)Z
    //   834: ifeq -> 859
    //   837: dload #14
    //   839: aload #9
    //   841: checkcast net/minecraft/entity/EntityLivingBase
    //   844: <illegal opcode> 55 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   849: f2d
    //   850: invokestatic lllllIIIIlIIlll : (DD)I
    //   853: invokestatic lllllIIIIlIllll : (I)Z
    //   856: ifeq -> 450
    //   859: dload #16
    //   861: ldc2_w 0.5
    //   864: dsub
    //   865: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   870: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   875: <illegal opcode> 77 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   880: f2d
    //   881: invokestatic lllllIIIIlIIllI : (DD)I
    //   884: invokestatic lllllIIIIlIllII : (I)Z
    //   887: ifeq -> 901
    //   890: ldc ''
    //   892: invokevirtual length : ()I
    //   895: pop
    //   896: aconst_null
    //   897: ifnull -> 450
    //   900: return
    //   901: dload #16
    //   903: aload_0
    //   904: <illegal opcode> 78 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   909: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   914: invokestatic lllllIIIIlIIllI : (DD)I
    //   917: invokestatic lllllIIIIlIllII : (I)Z
    //   920: ifeq -> 959
    //   923: ldc ''
    //   925: invokevirtual length : ()I
    //   928: pop
    //   929: ldc_w '   '
    //   932: invokevirtual length : ()I
    //   935: ldc_w ' '
    //   938: invokevirtual length : ()I
    //   941: ldc_w ' '
    //   944: invokevirtual length : ()I
    //   947: ldc_w ' '
    //   950: invokevirtual length : ()I
    //   953: ishl
    //   954: ishl
    //   955: if_icmplt -> 450
    //   958: return
    //   959: dload #14
    //   961: dstore #6
    //   963: aload #11
    //   965: astore #5
    //   967: aload_0
    //   968: aload #9
    //   970: <illegal opcode> 79 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/entity/Entity;)V
    //   975: aload_0
    //   976: aload #9
    //   978: <illegal opcode> 80 : (Lnet/minecraft/entity/Entity;)Ljava/lang/String;
    //   983: <illegal opcode> 51 : (Lme/stupitdog/bhp/f0h;Ljava/lang/String;)V
    //   988: ldc ''
    //   990: invokevirtual length : ()I
    //   993: pop
    //   994: ldc_w '   '
    //   997: invokevirtual length : ()I
    //   1000: ifge -> 450
    //   1003: return
    //   1004: ldc ''
    //   1006: invokevirtual length : ()I
    //   1009: pop
    //   1010: ldc_w ' '
    //   1013: invokevirtual length : ()I
    //   1016: ineg
    //   1017: ldc_w ' '
    //   1020: invokevirtual length : ()I
    //   1023: ineg
    //   1024: if_icmpeq -> 324
    //   1027: return
    //   1028: dload #6
    //   1030: ldc2_w 0.5
    //   1033: invokestatic lllllIIIIlIIllI : (DD)I
    //   1036: invokestatic lllllIIIIllIIII : (I)Z
    //   1039: ifeq -> 1062
    //   1042: aload_0
    //   1043: aconst_null
    //   1044: <illegal opcode> 81 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/math/BlockPos;)V
    //   1049: aload_0
    //   1050: aconst_null
    //   1051: <illegal opcode> 79 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/entity/Entity;)V
    //   1056: <illegal opcode> 82 : ()V
    //   1061: return
    //   1062: aload_0
    //   1063: aload #5
    //   1065: <illegal opcode> 81 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/math/BlockPos;)V
    //   1070: aload_0
    //   1071: <illegal opcode> 83 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/ao;
    //   1076: aload_0
    //   1077: <illegal opcode> 84 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   1082: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   1087: ldc2_w 4.0
    //   1090: dmul
    //   1091: d2l
    //   1092: <illegal opcode> 85 : (Lme/stupitdog/bhp/ao;J)Z
    //   1097: invokestatic lllllIIIIlIlIII : (I)Z
    //   1100: ifeq -> 1793
    //   1103: aload_0
    //   1104: <illegal opcode> 86 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1109: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1114: invokestatic lllllIIIIlIlIII : (I)Z
    //   1117: ifeq -> 1170
    //   1120: aload_0
    //   1121: aload #5
    //   1123: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1128: i2d
    //   1129: ldc2_w 0.5
    //   1132: dadd
    //   1133: aload #5
    //   1135: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1140: i2d
    //   1141: ldc2_w 0.5
    //   1144: dsub
    //   1145: aload #5
    //   1147: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1152: i2d
    //   1153: ldc2_w 0.5
    //   1156: dadd
    //   1157: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1162: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1167: invokespecial lookAtPacket : (DDDLnet/minecraft/entity/player/EntityPlayer;)V
    //   1170: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1175: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   1180: new net/minecraft/util/math/Vec3d
    //   1183: dup
    //   1184: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1189: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1194: <illegal opcode> 87 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1199: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1204: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1209: <illegal opcode> 88 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1214: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1219: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1224: <illegal opcode> 89 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   1229: f2d
    //   1230: dadd
    //   1231: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1236: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1241: <illegal opcode> 90 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   1246: invokespecial <init> : (DDD)V
    //   1249: new net/minecraft/util/math/Vec3d
    //   1252: dup
    //   1253: aload #5
    //   1255: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1260: i2d
    //   1261: ldc2_w 0.5
    //   1264: dadd
    //   1265: aload #5
    //   1267: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1272: i2d
    //   1273: ldc2_w 0.5
    //   1276: dsub
    //   1277: aload #5
    //   1279: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1284: i2d
    //   1285: ldc2_w 0.5
    //   1288: dadd
    //   1289: invokespecial <init> : (DDD)V
    //   1292: <illegal opcode> 91 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult;
    //   1297: astore #8
    //   1299: aload_0
    //   1300: <illegal opcode> 92 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1305: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1310: invokestatic lllllIIIIlIlIII : (I)Z
    //   1313: ifeq -> 1370
    //   1316: aload #8
    //   1318: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   1321: ifeq -> 1337
    //   1324: aload #8
    //   1326: <illegal opcode> 93 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/EnumFacing;
    //   1331: invokestatic lllllIIIIllIIlI : (Ljava/lang/Object;)Z
    //   1334: ifeq -> 1357
    //   1337: aload_0
    //   1338: aconst_null
    //   1339: <illegal opcode> 94 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/EnumFacing;)V
    //   1344: aload_0
    //   1345: aconst_null
    //   1346: <illegal opcode> 81 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/math/BlockPos;)V
    //   1351: <illegal opcode> 82 : ()V
    //   1356: return
    //   1357: aload_0
    //   1358: aload #8
    //   1360: <illegal opcode> 93 : (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/util/EnumFacing;
    //   1365: <illegal opcode> 94 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/EnumFacing;)V
    //   1370: aload #5
    //   1372: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   1375: ifeq -> 1782
    //   1378: aload_0
    //   1379: <illegal opcode> 92 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1384: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1389: invokestatic lllllIIIIlIlIII : (I)Z
    //   1392: ifeq -> 1509
    //   1395: aload_0
    //   1396: <illegal opcode> 95 : (Lme/stupitdog/bhp/f0h;)Lnet/minecraft/util/EnumFacing;
    //   1401: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   1404: ifeq -> 1509
    //   1407: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1412: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1417: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1422: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   1425: dup
    //   1426: aload #5
    //   1428: aload_0
    //   1429: <illegal opcode> 95 : (Lme/stupitdog/bhp/f0h;)Lnet/minecraft/util/EnumFacing;
    //   1434: iload_1
    //   1435: invokestatic lllllIIIIlIlIII : (I)Z
    //   1438: ifeq -> 1470
    //   1441: <illegal opcode> 97 : ()Lnet/minecraft/util/EnumHand;
    //   1446: ldc ''
    //   1448: invokevirtual length : ()I
    //   1451: pop
    //   1452: ldc_w ' '
    //   1455: invokevirtual length : ()I
    //   1458: ineg
    //   1459: ldc_w ' '
    //   1462: invokevirtual length : ()I
    //   1465: ineg
    //   1466: if_icmpge -> 1475
    //   1469: return
    //   1470: <illegal opcode> 98 : ()Lnet/minecraft/util/EnumHand;
    //   1475: fconst_0
    //   1476: fconst_0
    //   1477: fconst_0
    //   1478: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   1481: <illegal opcode> 99 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1486: ldc ''
    //   1488: invokevirtual length : ()I
    //   1491: pop
    //   1492: ldc_w ' '
    //   1495: invokevirtual length : ()I
    //   1498: ldc_w ' '
    //   1501: invokevirtual length : ()I
    //   1504: ishl
    //   1505: ifne -> 1704
    //   1508: return
    //   1509: aload #5
    //   1511: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   1516: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   1519: bipush #28
    //   1521: iaload
    //   1522: invokestatic lllllIIIIllIIll : (II)Z
    //   1525: ifeq -> 1627
    //   1528: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1533: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1538: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1543: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   1546: dup
    //   1547: aload #5
    //   1549: <illegal opcode> 100 : ()Lnet/minecraft/util/EnumFacing;
    //   1554: iload_1
    //   1555: invokestatic lllllIIIIlIlIII : (I)Z
    //   1558: ifeq -> 1582
    //   1561: <illegal opcode> 97 : ()Lnet/minecraft/util/EnumHand;
    //   1566: ldc ''
    //   1568: invokevirtual length : ()I
    //   1571: pop
    //   1572: ldc_w '   '
    //   1575: invokevirtual length : ()I
    //   1578: ifne -> 1587
    //   1581: return
    //   1582: <illegal opcode> 98 : ()Lnet/minecraft/util/EnumHand;
    //   1587: fconst_0
    //   1588: fconst_0
    //   1589: fconst_0
    //   1590: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   1593: <illegal opcode> 99 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1598: ldc ''
    //   1600: invokevirtual length : ()I
    //   1603: pop
    //   1604: ldc_w ' '
    //   1607: invokevirtual length : ()I
    //   1610: ldc_w ' '
    //   1613: invokevirtual length : ()I
    //   1616: ishl
    //   1617: ldc_w ' '
    //   1620: invokevirtual length : ()I
    //   1623: if_icmpge -> 1704
    //   1626: return
    //   1627: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1632: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1637: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1642: new net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock
    //   1645: dup
    //   1646: aload #5
    //   1648: <illegal opcode> 101 : ()Lnet/minecraft/util/EnumFacing;
    //   1653: iload_1
    //   1654: invokestatic lllllIIIIlIlIII : (I)Z
    //   1657: ifeq -> 1688
    //   1660: <illegal opcode> 97 : ()Lnet/minecraft/util/EnumHand;
    //   1665: ldc ''
    //   1667: invokevirtual length : ()I
    //   1670: pop
    //   1671: ldc_w '   '
    //   1674: invokevirtual length : ()I
    //   1677: ldc_w ' '
    //   1680: invokevirtual length : ()I
    //   1683: ineg
    //   1684: if_icmpge -> 1693
    //   1687: return
    //   1688: <illegal opcode> 98 : ()Lnet/minecraft/util/EnumHand;
    //   1693: fconst_0
    //   1694: fconst_0
    //   1695: fconst_0
    //   1696: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
    //   1699: <illegal opcode> 99 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1704: aload_0
    //   1705: aload #5
    //   1707: <illegal opcode> 81 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/math/BlockPos;)V
    //   1712: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1717: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1722: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   1727: new net/minecraft/network/play/client/CPacketAnimation
    //   1730: dup
    //   1731: <illegal opcode> 98 : ()Lnet/minecraft/util/EnumHand;
    //   1736: invokespecial <init> : (Lnet/minecraft/util/EnumHand;)V
    //   1739: <illegal opcode> 99 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   1744: aload_0
    //   1745: <illegal opcode> 102 : (Lme/stupitdog/bhp/f0h;)Ljava/util/ArrayList;
    //   1750: aload #5
    //   1752: <illegal opcode> 5 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1757: ldc ''
    //   1759: invokevirtual length : ()I
    //   1762: pop2
    //   1763: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   1768: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1773: <illegal opcode> 36 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   1778: iload_2
    //   1779: putfield field_70461_c : I
    //   1782: aload_0
    //   1783: <illegal opcode> 83 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/ao;
    //   1788: <illegal opcode> 103 : (Lme/stupitdog/bhp/ao;)V
    //   1793: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   72	22	1	lllllllllllllllIlllIlllIllIIIIIl	Z
    //   185	32	4	lllllllllllllllIlllIlllIllIIIIII	Lnet/minecraft/item/Item;
    //   144	87	3	lllllllllllllllIlllIlllIlIllllll	I
    //   824	164	16	lllllllllllllllIlllIlllIlIlllllI	D
    //   486	502	12	lllllllllllllllIlllIlllIlIllllIl	D
    //   580	408	14	lllllllllllllllIlllIlllIlIllllII	D
    //   475	513	11	lllllllllllllllIlllIlllIlIlllIll	Lnet/minecraft/util/math/BlockPos;
    //   349	655	9	lllllllllllllllIlllIlllIlIlllIlI	Lnet/minecraft/entity/Entity;
    //   1299	494	8	lllllllllllllllIlllIlllIlIlllIIl	Lnet/minecraft/util/math/RayTraceResult;
    //   100	1693	1	lllllllllllllllIlllIlllIlIlllIII	Z
    //   121	1672	2	lllllllllllllllIlllIlllIlIllIlll	I
    //   236	1557	3	lllllllllllllllIlllIlllIlIllIllI	Ljava/util/List;
    //   245	1548	4	lllllllllllllllIlllIlllIlIllIlIl	Ljava/util/List;
    //   294	1499	5	lllllllllllllllIlllIlllIlIllIlII	Lnet/minecraft/util/math/BlockPos;
    //   299	1494	6	lllllllllllllllIlllIlllIlIllIIll	D
    //   0	1794	0	lllllllllllllllIlllIlllIlIllIIlI	Lme/stupitdog/bhp/f0h;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   236	1557	3	lllllllllllllllIlllIlllIlIllIllI	Ljava/util/List<Lnet/minecraft/util/math/BlockPos;>;
    //   245	1548	4	lllllllllllllllIlllIlllIlIllIlIl	Ljava/util/List<Lnet/minecraft/entity/Entity;>;
  }
  
  public void breakLogic() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 104 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: invokestatic lllllIIIIlIlIII : (I)Z
    //   14: ifeq -> 311
    //   17: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   27: <illegal opcode> 105 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   32: <illegal opcode> 47 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   37: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   42: <illegal opcode> 106 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   47: aload_0
    //   48: <illegal opcode> test : (Lme/stupitdog/bhp/f0h;)Ljava/util/function/Predicate;
    //   53: <illegal opcode> 106 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   58: aload_0
    //   59: <illegal opcode> test : (Lme/stupitdog/bhp/f0h;)Ljava/util/function/Predicate;
    //   64: <illegal opcode> 106 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   69: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   74: <illegal opcode> 107 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   79: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   84: <illegal opcode> 108 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   89: <illegal opcode> 109 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   94: aconst_null
    //   95: <illegal opcode> 110 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   100: checkcast net/minecraft/entity/item/EntityEnderCrystal
    //   103: astore_1
    //   104: aload_0
    //   105: <illegal opcode> 111 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/ao;
    //   110: aload_0
    //   111: <illegal opcode> 112 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   116: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   121: ldc2_w 4.0
    //   124: dmul
    //   125: d2l
    //   126: <illegal opcode> 85 : (Lme/stupitdog/bhp/ao;J)Z
    //   131: invokestatic lllllIIIIlIlIII : (I)Z
    //   134: ifeq -> 311
    //   137: aload_1
    //   138: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   141: ifeq -> 311
    //   144: aload_0
    //   145: <illegal opcode> 86 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   150: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   155: invokestatic lllllIIIIlIlIII : (I)Z
    //   158: ifeq -> 193
    //   161: aload_0
    //   162: aload_1
    //   163: <illegal opcode> 113 : (Lnet/minecraft/entity/item/EntityEnderCrystal;)D
    //   168: aload_1
    //   169: <illegal opcode> 114 : (Lnet/minecraft/entity/item/EntityEnderCrystal;)D
    //   174: aload_1
    //   175: <illegal opcode> 115 : (Lnet/minecraft/entity/item/EntityEnderCrystal;)D
    //   180: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   185: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   190: invokespecial lookAtPacket : (DDDLnet/minecraft/entity/player/EntityPlayer;)V
    //   193: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   198: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   203: <illegal opcode> 96 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   208: new net/minecraft/network/play/client/CPacketUseEntity
    //   211: dup
    //   212: aload_1
    //   213: invokespecial <init> : (Lnet/minecraft/entity/Entity;)V
    //   216: <illegal opcode> 99 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   221: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   226: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   231: <illegal opcode> 98 : ()Lnet/minecraft/util/EnumHand;
    //   236: <illegal opcode> 116 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/util/EnumHand;)V
    //   241: aload_0
    //   242: <illegal opcode> 117 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   247: <illegal opcode> 33 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   252: invokestatic lllllIIIIlIlIII : (I)Z
    //   255: ifeq -> 300
    //   258: aload_1
    //   259: <illegal opcode> 118 : (Lnet/minecraft/entity/item/EntityEnderCrystal;)V
    //   264: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   269: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   274: <illegal opcode> 119 : (Lnet/minecraft/client/multiplayer/WorldClient;)V
    //   279: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   284: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   289: <illegal opcode> 120 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   294: ldc ''
    //   296: invokevirtual length : ()I
    //   299: pop2
    //   300: aload_0
    //   301: <illegal opcode> 111 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/ao;
    //   306: <illegal opcode> 103 : (Lme/stupitdog/bhp/ao;)V
    //   311: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   104	207	1	lllllllllllllllIlllIlllIlIllIIIl	Lnet/minecraft/entity/item/EntityEnderCrystal;
    //   0	312	0	lllllllllllllllIlllIlllIlIllIIII	Lme/stupitdog/bhp/f0h;
  }
  
  private boolean crystalCheck(Entity lllllllllllllllIlllIlllIlIlIlIll) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof net/minecraft/entity/item/EntityEnderCrystal
    //   4: invokestatic lllllIIIIllIIII : (I)Z
    //   7: ifeq -> 16
    //   10: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   13: iconst_0
    //   14: iaload
    //   15: ireturn
    //   16: aload_0
    //   17: <illegal opcode> 121 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   22: <illegal opcode> 122 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   27: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   30: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   33: bipush #31
    //   35: iaload
    //   36: aaload
    //   37: <illegal opcode> 123 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   42: invokestatic lllllIIIIlIlIII : (I)Z
    //   45: ifeq -> 54
    //   48: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   51: iconst_1
    //   52: iaload
    //   53: ireturn
    //   54: aload_0
    //   55: <illegal opcode> 121 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   60: <illegal opcode> 122 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   65: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   68: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   71: bipush #32
    //   73: iaload
    //   74: aaload
    //   75: <illegal opcode> 123 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   80: invokestatic lllllIIIIlIlIII : (I)Z
    //   83: ifeq -> 322
    //   86: new java/util/ArrayList
    //   89: dup
    //   90: aload_0
    //   91: <illegal opcode> 102 : (Lme/stupitdog/bhp/f0h;)Ljava/util/ArrayList;
    //   96: invokespecial <init> : (Ljava/util/Collection;)V
    //   99: <illegal opcode> 124 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   104: astore_2
    //   105: aload_2
    //   106: <illegal opcode> 53 : (Ljava/util/Iterator;)Z
    //   111: invokestatic lllllIIIIlIlIII : (I)Z
    //   114: ifeq -> 237
    //   117: aload_2
    //   118: <illegal opcode> 54 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   123: checkcast net/minecraft/util/math/BlockPos
    //   126: astore_3
    //   127: aload_3
    //   128: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   131: ifeq -> 179
    //   134: aload_3
    //   135: aload_1
    //   136: <illegal opcode> 125 : (Lnet/minecraft/entity/Entity;)D
    //   141: d2i
    //   142: aload_1
    //   143: <illegal opcode> 126 : (Lnet/minecraft/entity/Entity;)D
    //   148: d2i
    //   149: aload_1
    //   150: <illegal opcode> 127 : (Lnet/minecraft/entity/Entity;)D
    //   155: d2i
    //   156: <illegal opcode> 128 : (Lnet/minecraft/util/math/BlockPos;III)D
    //   161: ldc2_w 3.0
    //   164: invokestatic lllllIIIIllIlII : (DD)I
    //   167: invokestatic lllllIIIIllIllI : (I)Z
    //   170: ifeq -> 179
    //   173: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   176: iconst_1
    //   177: iaload
    //   178: ireturn
    //   179: ldc ''
    //   181: invokevirtual length : ()I
    //   184: pop
    //   185: ldc_w ' '
    //   188: invokevirtual length : ()I
    //   191: ldc_w ' '
    //   194: invokevirtual length : ()I
    //   197: ldc_w ' '
    //   200: invokevirtual length : ()I
    //   203: ishl
    //   204: ishl
    //   205: ldc_w ' '
    //   208: invokevirtual length : ()I
    //   211: ldc_w ' '
    //   214: invokevirtual length : ()I
    //   217: ishl
    //   218: if_icmpgt -> 105
    //   221: bipush #121
    //   223: bipush #110
    //   225: ixor
    //   226: sipush #154
    //   229: sipush #141
    //   232: ixor
    //   233: iconst_m1
    //   234: ixor
    //   235: iand
    //   236: ireturn
    //   237: ldc ''
    //   239: invokevirtual length : ()I
    //   242: pop
    //   243: ldc_w ' '
    //   246: invokevirtual length : ()I
    //   249: ineg
    //   250: ldc_w ' '
    //   253: invokevirtual length : ()I
    //   256: ldc_w ' '
    //   259: invokevirtual length : ()I
    //   262: ishl
    //   263: if_icmple -> 619
    //   266: sipush #167
    //   269: sipush #162
    //   272: ixor
    //   273: ldc_w ' '
    //   276: invokevirtual length : ()I
    //   279: ldc_w ' '
    //   282: invokevirtual length : ()I
    //   285: ldc_w ' '
    //   288: invokevirtual length : ()I
    //   291: ishl
    //   292: ishl
    //   293: ishl
    //   294: iconst_4
    //   295: iconst_1
    //   296: ixor
    //   297: ldc_w ' '
    //   300: invokevirtual length : ()I
    //   303: ldc_w ' '
    //   306: invokevirtual length : ()I
    //   309: ldc_w ' '
    //   312: invokevirtual length : ()I
    //   315: ishl
    //   316: ishl
    //   317: ishl
    //   318: iconst_m1
    //   319: ixor
    //   320: iand
    //   321: ireturn
    //   322: aload_0
    //   323: <illegal opcode> 121 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   328: <illegal opcode> 122 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)Ljava/lang/String;
    //   333: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   336: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   339: bipush #33
    //   341: iaload
    //   342: aaload
    //   343: <illegal opcode> 123 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   348: invokestatic lllllIIIIlIlIII : (I)Z
    //   351: ifeq -> 619
    //   354: aload_0
    //   355: <illegal opcode> 129 : (Lme/stupitdog/bhp/f0h;)Lnet/minecraft/entity/Entity;
    //   360: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   363: ifeq -> 442
    //   366: aload_0
    //   367: <illegal opcode> 129 : (Lme/stupitdog/bhp/f0h;)Lnet/minecraft/entity/Entity;
    //   372: checkcast net/minecraft/entity/EntityLivingBase
    //   375: ldc ''
    //   377: invokevirtual length : ()I
    //   380: pop
    //   381: ldc_w ' '
    //   384: invokevirtual length : ()I
    //   387: ldc_w ' '
    //   390: invokevirtual length : ()I
    //   393: ldc_w ' '
    //   396: invokevirtual length : ()I
    //   399: ishl
    //   400: ishl
    //   401: ldc_w ' '
    //   404: invokevirtual length : ()I
    //   407: if_icmpgt -> 447
    //   410: sipush #161
    //   413: sipush #170
    //   416: ixor
    //   417: ldc_w '   '
    //   420: invokevirtual length : ()I
    //   423: ishl
    //   424: sipush #169
    //   427: sipush #162
    //   430: ixor
    //   431: ldc_w '   '
    //   434: invokevirtual length : ()I
    //   437: ishl
    //   438: iconst_m1
    //   439: ixor
    //   440: iand
    //   441: ireturn
    //   442: aload_0
    //   443: aload_1
    //   444: invokespecial GetNearTarget : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/entity/EntityLivingBase;
    //   447: astore_2
    //   448: aload_2
    //   449: invokestatic lllllIIIIllIIIl : (Ljava/lang/Object;)Z
    //   452: ifeq -> 472
    //   455: aload_2
    //   456: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   461: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   466: invokestatic lllllIIIIlIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   469: ifeq -> 478
    //   472: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   475: iconst_0
    //   476: iaload
    //   477: ireturn
    //   478: aload_1
    //   479: <illegal opcode> 125 : (Lnet/minecraft/entity/Entity;)D
    //   484: ldc2_w 0.5
    //   487: dadd
    //   488: aload_1
    //   489: <illegal opcode> 126 : (Lnet/minecraft/entity/Entity;)D
    //   494: dconst_1
    //   495: dadd
    //   496: aload_1
    //   497: <illegal opcode> 127 : (Lnet/minecraft/entity/Entity;)D
    //   502: ldc2_w 0.5
    //   505: dadd
    //   506: aload_2
    //   507: <illegal opcode> 68 : (DDDLnet/minecraft/entity/Entity;)F
    //   512: fstore_3
    //   513: fload_3
    //   514: f2d
    //   515: aload_0
    //   516: <illegal opcode> 69 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   521: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   526: invokestatic lllllIIIIllIlIl : (DD)I
    //   529: invokestatic lllllIIIIlIllll : (I)Z
    //   532: ifeq -> 584
    //   535: fload_3
    //   536: f2d
    //   537: aload_0
    //   538: <illegal opcode> 69 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   543: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   548: invokestatic lllllIIIIllIlIl : (DD)I
    //   551: invokestatic lllllIIIIlIllII : (I)Z
    //   554: ifeq -> 613
    //   557: aload_2
    //   558: <illegal opcode> 55 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   563: f2d
    //   564: aload_0
    //   565: <illegal opcode> 71 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   570: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   575: invokestatic lllllIIIIllIlIl : (DD)I
    //   578: invokestatic lllllIIIIlIllII : (I)Z
    //   581: ifeq -> 613
    //   584: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   587: iconst_1
    //   588: iaload
    //   589: ldc ''
    //   591: invokevirtual length : ()I
    //   594: pop
    //   595: aconst_null
    //   596: ifnull -> 618
    //   599: bipush #27
    //   601: bipush #56
    //   603: ixor
    //   604: bipush #116
    //   606: bipush #87
    //   608: ixor
    //   609: iconst_m1
    //   610: ixor
    //   611: iand
    //   612: ireturn
    //   613: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   616: iconst_0
    //   617: iaload
    //   618: ireturn
    //   619: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   622: iconst_0
    //   623: iaload
    //   624: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   127	52	3	lllllllllllllllIlllIlllIlIlIllll	Lnet/minecraft/util/math/BlockPos;
    //   448	171	2	lllllllllllllllIlllIlllIlIlIlllI	Lnet/minecraft/entity/EntityLivingBase;
    //   513	106	3	lllllllllllllllIlllIlllIlIlIllIl	F
    //   0	625	0	lllllllllllllllIlllIlllIlIlIllII	Lme/stupitdog/bhp/f0h;
    //   0	625	1	lllllllllllllllIlllIlllIlIlIlIll	Lnet/minecraft/entity/Entity;
  }
  
  private void renderNameTag(BlockPos lllllllllllllllIlllIlllIlIlIlIIl, double lllllllllllllllIlllIlllIlIlIlIII, float lllllllllllllllIlllIlllIlIlIIlll) {
    // Byte code:
    //   0: <illegal opcode> 130 : ()V
    //   5: aload_1
    //   6: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   11: i2f
    //   12: ldc_w 0.5
    //   15: fadd
    //   16: aload_1
    //   17: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   22: i2f
    //   23: ldc_w 0.5
    //   26: fadd
    //   27: aload_1
    //   28: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   33: i2f
    //   34: ldc_w 0.5
    //   37: fadd
    //   38: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   43: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   48: fconst_1
    //   49: <illegal opcode> 131 : (FFFLnet/minecraft/entity/player/EntityPlayer;F)V
    //   54: <illegal opcode> 132 : ()V
    //   59: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   64: <illegal opcode> 133 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   69: new java/lang/StringBuilder
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: dload_2
    //   77: <illegal opcode> 134 : (Ljava/lang/StringBuilder;D)Ljava/lang/StringBuilder;
    //   82: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   85: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   88: bipush #34
    //   90: iaload
    //   91: aaload
    //   92: <illegal opcode> 135 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: <illegal opcode> 136 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   102: <illegal opcode> 137 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;)I
    //   107: i2d
    //   108: ldc2_w 2.0
    //   111: ddiv
    //   112: dneg
    //   113: dconst_0
    //   114: dconst_0
    //   115: <illegal opcode> 138 : (DDD)V
    //   120: new java/lang/StringBuilder
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: dload_2
    //   128: <illegal opcode> 134 : (Ljava/lang/StringBuilder;D)Ljava/lang/StringBuilder;
    //   133: getstatic me/stupitdog/bhp/f0h.lIlllIIIllIlII : [Ljava/lang/String;
    //   136: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   139: bipush #35
    //   141: iaload
    //   142: aaload
    //   143: <illegal opcode> 135 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: <illegal opcode> 136 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   153: fconst_0
    //   154: fconst_0
    //   155: new me/stupitdog/bhp/f01
    //   158: dup
    //   159: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   162: bipush #36
    //   164: iaload
    //   165: invokespecial <init> : (I)V
    //   168: <illegal opcode> 139 : (Ljava/lang/String;FFLme/stupitdog/bhp/f01;)F
    //   173: ldc ''
    //   175: invokevirtual length : ()I
    //   178: pop2
    //   179: <illegal opcode> 140 : ()V
    //   184: <illegal opcode> 141 : ()V
    //   189: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	190	0	lllllllllllllllIlllIlllIlIlIlIlI	Lme/stupitdog/bhp/f0h;
    //   0	190	1	lllllllllllllllIlllIlllIlIlIlIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	190	2	lllllllllllllllIlllIlllIlIlIlIII	D
    //   0	190	4	lllllllllllllllIlllIlllIlIlIIlll	F
  }
  
  public static void glBillboard(float lllllllllllllllIlllIlllIlIlIIllI, float lllllllllllllllIlllIlllIlIlIIlIl, float lllllllllllllllIlllIlllIlIlIIlII) {
    // Byte code:
    //   0: ldc_w 0.02666667
    //   3: fstore_3
    //   4: fload_0
    //   5: f2d
    //   6: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   11: <illegal opcode> 142 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   16: <illegal opcode> 143 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   21: dsub
    //   22: fload_1
    //   23: f2d
    //   24: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   29: <illegal opcode> 142 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   34: <illegal opcode> 144 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   39: dsub
    //   40: fload_2
    //   41: f2d
    //   42: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   47: <illegal opcode> 142 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   52: <illegal opcode> 145 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   57: dsub
    //   58: <illegal opcode> 138 : (DDD)V
    //   63: fconst_0
    //   64: fconst_1
    //   65: fconst_0
    //   66: <illegal opcode> 146 : (FFF)V
    //   71: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   76: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   81: <illegal opcode> 147 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   86: fneg
    //   87: fconst_0
    //   88: fconst_1
    //   89: fconst_0
    //   90: <illegal opcode> 148 : (FFFF)V
    //   95: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   100: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   105: <illegal opcode> 149 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   110: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   115: <illegal opcode> 150 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   120: <illegal opcode> 151 : (Lnet/minecraft/client/settings/GameSettings;)I
    //   125: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   128: iconst_2
    //   129: iaload
    //   130: invokestatic lllllIIIIllIIll : (II)Z
    //   133: ifeq -> 168
    //   136: ldc_w -1.0
    //   139: ldc ''
    //   141: invokevirtual length : ()I
    //   144: pop
    //   145: ldc_w '   '
    //   148: invokevirtual length : ()I
    //   151: ldc_w ' '
    //   154: invokevirtual length : ()I
    //   157: ldc_w ' '
    //   160: invokevirtual length : ()I
    //   163: ishl
    //   164: if_icmpgt -> 169
    //   167: return
    //   168: fconst_1
    //   169: fconst_0
    //   170: fconst_0
    //   171: <illegal opcode> 148 : (FFFF)V
    //   176: ldc_w -0.02666667
    //   179: ldc_w -0.02666667
    //   182: ldc_w 0.02666667
    //   185: <illegal opcode> 152 : (FFF)V
    //   190: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	191	0	lllllllllllllllIlllIlllIlIlIIllI	F
    //   0	191	1	lllllllllllllllIlllIlllIlIlIIlIl	F
    //   0	191	2	lllllllllllllllIlllIlllIlIlIIlII	F
    //   4	187	3	lllllllllllllllIlllIlllIlIlIIIll	F
  }
  
  public static void glBillboardDistanceScaled(float lllllllllllllllIlllIlllIlIlIIIlI, float lllllllllllllllIlllIlllIlIlIIIIl, float lllllllllllllllIlllIlllIlIlIIIII, EntityPlayer lllllllllllllllIlllIlllIlIIlllll, float lllllllllllllllIlllIlllIlIIllllI) {
    // Byte code:
    //   0: fload_0
    //   1: fload_1
    //   2: fload_2
    //   3: <illegal opcode> 153 : (FFF)V
    //   8: aload_3
    //   9: fload_0
    //   10: f2d
    //   11: fload_1
    //   12: f2d
    //   13: fload_2
    //   14: f2d
    //   15: <illegal opcode> 154 : (Lnet/minecraft/entity/player/EntityPlayer;DDD)D
    //   20: d2i
    //   21: istore #5
    //   23: iload #5
    //   25: i2f
    //   26: fconst_2
    //   27: fdiv
    //   28: fconst_2
    //   29: fconst_2
    //   30: fload #4
    //   32: fsub
    //   33: fadd
    //   34: fdiv
    //   35: fstore #6
    //   37: fload #6
    //   39: fconst_1
    //   40: invokestatic lllllIIIIllIlll : (FF)I
    //   43: invokestatic lllllIIIIlIllll : (I)Z
    //   46: ifeq -> 52
    //   49: fconst_1
    //   50: fstore #6
    //   52: fload #6
    //   54: fload #6
    //   56: fload #6
    //   58: <illegal opcode> 152 : (FFF)V
    //   63: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	64	0	lllllllllllllllIlllIlllIlIlIIIlI	F
    //   0	64	1	lllllllllllllllIlllIlllIlIlIIIIl	F
    //   0	64	2	lllllllllllllllIlllIlllIlIlIIIII	F
    //   0	64	3	lllllllllllllllIlllIlllIlIIlllll	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	64	4	lllllllllllllllIlllIlllIlIIllllI	F
    //   23	41	5	lllllllllllllllIlllIlllIlIIlllIl	I
    //   37	27	6	lllllllllllllllIlllIlllIlIIlllII	F
  }
  
  private boolean validTarget(Entity lllllllllllllllIlllIlllIlIIllIlI) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic lllllIIIIllIIlI : (Ljava/lang/Object;)Z
    //   4: ifeq -> 13
    //   7: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   10: iconst_0
    //   11: iaload
    //   12: ireturn
    //   13: aload_1
    //   14: instanceof net/minecraft/entity/EntityLivingBase
    //   17: invokestatic lllllIIIIllIIII : (I)Z
    //   20: ifeq -> 29
    //   23: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   26: iconst_0
    //   27: iaload
    //   28: ireturn
    //   29: aload_1
    //   30: <illegal opcode> 155 : (Lnet/minecraft/entity/Entity;)Z
    //   35: invokestatic lllllIIIIllIIII : (I)Z
    //   38: ifeq -> 60
    //   41: aload_1
    //   42: checkcast net/minecraft/entity/EntityLivingBase
    //   45: <illegal opcode> 55 : (Lnet/minecraft/entity/EntityLivingBase;)F
    //   50: fconst_0
    //   51: invokestatic lllllIIIIlllIII : (FF)I
    //   54: invokestatic lllllIIIIllIllI : (I)Z
    //   57: ifeq -> 66
    //   60: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   63: iconst_0
    //   64: iaload
    //   65: ireturn
    //   66: aload_1
    //   67: instanceof net/minecraft/entity/player/EntityPlayer
    //   70: invokestatic lllllIIIIlIlIII : (I)Z
    //   73: ifeq -> 192
    //   76: aload_1
    //   77: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   82: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   87: invokestatic lllllIIIIlIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   90: ifeq -> 186
    //   93: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   96: iconst_1
    //   97: iaload
    //   98: ldc ''
    //   100: invokevirtual length : ()I
    //   103: pop
    //   104: ldc_w ' '
    //   107: invokevirtual length : ()I
    //   110: ifge -> 191
    //   113: ldc_w '   '
    //   116: invokevirtual length : ()I
    //   119: sipush #132
    //   122: sipush #171
    //   125: ixor
    //   126: sipush #140
    //   129: sipush #153
    //   132: ixor
    //   133: ldc_w ' '
    //   136: invokevirtual length : ()I
    //   139: ishl
    //   140: ixor
    //   141: ishl
    //   142: ldc_w '   '
    //   145: invokevirtual length : ()I
    //   148: sipush #200
    //   151: sipush #177
    //   154: ixor
    //   155: bipush #99
    //   157: bipush #124
    //   159: ixor
    //   160: ldc_w ' '
    //   163: invokevirtual length : ()I
    //   166: ldc_w ' '
    //   169: invokevirtual length : ()I
    //   172: ishl
    //   173: ishl
    //   174: ixor
    //   175: ishl
    //   176: ldc_w ' '
    //   179: invokevirtual length : ()I
    //   182: ineg
    //   183: ixor
    //   184: iand
    //   185: ireturn
    //   186: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   189: iconst_0
    //   190: iaload
    //   191: ireturn
    //   192: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   195: iconst_0
    //   196: iaload
    //   197: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	198	0	lllllllllllllllIlllIlllIlIIllIll	Lme/stupitdog/bhp/f0h;
    //   0	198	1	lllllllllllllllIlllIlllIlIIllIlI	Lnet/minecraft/entity/Entity;
  }
  
  private EntityLivingBase GetNearTarget(Entity lllllllllllllllIlllIlllIlIIllIII) {
    // Byte code:
    //   0: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 105 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: <illegal opcode> 47 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   20: aload_0
    //   21: <illegal opcode> test : (Lme/stupitdog/bhp/f0h;)Ljava/util/function/Predicate;
    //   26: <illegal opcode> 106 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   31: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   36: <illegal opcode> 107 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   41: aload_1
    //   42: <illegal opcode> apply : (Lnet/minecraft/entity/Entity;)Ljava/util/function/Function;
    //   47: <illegal opcode> 108 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   52: <illegal opcode> 109 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   57: aconst_null
    //   58: <illegal opcode> 110 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   63: checkcast net/minecraft/entity/EntityLivingBase
    //   66: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	67	0	lllllllllllllllIlllIlllIlIIllIIl	Lme/stupitdog/bhp/f0h;
    //   0	67	1	lllllllllllllllIlllIlllIlIIllIII	Lnet/minecraft/entity/Entity;
  }
  
  private static float getDamageMultiplied(float lllllllllllllllIlllIlllIlIIlIlll) {
    // Byte code:
    //   0: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 156 : (Lnet/minecraft/client/multiplayer/WorldClient;)Lnet/minecraft/world/EnumDifficulty;
    //   15: <illegal opcode> 157 : (Lnet/minecraft/world/EnumDifficulty;)I
    //   20: istore_1
    //   21: fload_0
    //   22: iload_1
    //   23: invokestatic lllllIIIIllIIII : (I)Z
    //   26: ifeq -> 65
    //   29: fconst_0
    //   30: ldc ''
    //   32: invokevirtual length : ()I
    //   35: pop
    //   36: bipush #122
    //   38: bipush #55
    //   40: ixor
    //   41: ldc_w ' '
    //   44: invokevirtual length : ()I
    //   47: ishl
    //   48: bipush #83
    //   50: bipush #6
    //   52: iadd
    //   53: bipush #-50
    //   55: isub
    //   56: bipush #20
    //   58: iadd
    //   59: ixor
    //   60: ifgt -> 126
    //   63: fconst_0
    //   64: freturn
    //   65: iload_1
    //   66: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   69: iconst_2
    //   70: iaload
    //   71: invokestatic lllllIIIIllIIll : (II)Z
    //   74: ifeq -> 96
    //   77: fconst_1
    //   78: ldc ''
    //   80: invokevirtual length : ()I
    //   83: pop
    //   84: ldc_w ' '
    //   87: invokevirtual length : ()I
    //   90: ineg
    //   91: ifle -> 126
    //   94: fconst_0
    //   95: freturn
    //   96: iload_1
    //   97: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   100: iconst_1
    //   101: iaload
    //   102: invokestatic lllllIIIIllIIll : (II)Z
    //   105: ifeq -> 123
    //   108: ldc_w 0.5
    //   111: ldc ''
    //   113: invokevirtual length : ()I
    //   116: pop
    //   117: aconst_null
    //   118: ifnull -> 126
    //   121: fconst_0
    //   122: freturn
    //   123: ldc_w 1.5
    //   126: fmul
    //   127: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	128	0	lllllllllllllllIlllIlllIlIIlIlll	F
    //   21	107	1	lllllllllllllllIlllIlllIlIIlIllI	I
  }
  
  public static float calculateDamage(double lllllllllllllllIlllIlllIlIIlIlIl, double lllllllllllllllIlllIlllIlIIlIlII, double lllllllllllllllIlllIlllIlIIlIIll, Entity lllllllllllllllIlllIlllIlIIlIIlI) {
    // Byte code:
    //   0: ldc_w 12.0
    //   3: fstore #7
    //   5: aload #6
    //   7: dload_0
    //   8: dload_2
    //   9: dload #4
    //   11: <illegal opcode> 158 : (Lnet/minecraft/entity/Entity;DDD)D
    //   16: fload #7
    //   18: f2d
    //   19: ddiv
    //   20: dstore #8
    //   22: new net/minecraft/util/math/Vec3d
    //   25: dup
    //   26: dload_0
    //   27: dload_2
    //   28: dload #4
    //   30: invokespecial <init> : (DDD)V
    //   33: astore #10
    //   35: aload #6
    //   37: <illegal opcode> 159 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/world/World;
    //   42: aload #10
    //   44: aload #6
    //   46: <illegal opcode> 160 : (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB;
    //   51: <illegal opcode> 161 : (Lnet/minecraft/world/World;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/AxisAlignedBB;)F
    //   56: f2d
    //   57: dstore #11
    //   59: dconst_1
    //   60: dload #8
    //   62: dsub
    //   63: dload #11
    //   65: dmul
    //   66: dstore #13
    //   68: dload #13
    //   70: dload #13
    //   72: dmul
    //   73: dload #13
    //   75: dadd
    //   76: ldc2_w 2.0
    //   79: ddiv
    //   80: ldc2_w 7.0
    //   83: dmul
    //   84: fload #7
    //   86: f2d
    //   87: dmul
    //   88: dconst_1
    //   89: dadd
    //   90: d2i
    //   91: i2f
    //   92: fstore #15
    //   94: dconst_1
    //   95: dstore #16
    //   97: aload #6
    //   99: instanceof net/minecraft/entity/EntityLivingBase
    //   102: invokestatic lllllIIIIlIlIII : (I)Z
    //   105: ifeq -> 163
    //   108: aload #6
    //   110: checkcast net/minecraft/entity/EntityLivingBase
    //   113: fload #15
    //   115: <illegal opcode> 162 : (F)F
    //   120: new net/minecraft/world/Explosion
    //   123: dup
    //   124: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   129: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   134: aconst_null
    //   135: dload_0
    //   136: dload_2
    //   137: dload #4
    //   139: ldc_w 6.0
    //   142: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   145: iconst_0
    //   146: iaload
    //   147: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   150: iconst_1
    //   151: iaload
    //   152: invokespecial <init> : (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;DDDFZZ)V
    //   155: <illegal opcode> 163 : (Lnet/minecraft/entity/EntityLivingBase;FLnet/minecraft/world/Explosion;)F
    //   160: f2d
    //   161: dstore #16
    //   163: dload #16
    //   165: d2f
    //   166: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	167	0	lllllllllllllllIlllIlllIlIIlIlIl	D
    //   0	167	2	lllllllllllllllIlllIlllIlIIlIlII	D
    //   0	167	4	lllllllllllllllIlllIlllIlIIlIIll	D
    //   0	167	6	lllllllllllllllIlllIlllIlIIlIIlI	Lnet/minecraft/entity/Entity;
    //   5	162	7	lllllllllllllllIlllIlllIlIIlIIIl	F
    //   22	145	8	lllllllllllllllIlllIlllIlIIlIIII	D
    //   35	132	10	lllllllllllllllIlllIlllIlIIIllll	Lnet/minecraft/util/math/Vec3d;
    //   59	108	11	lllllllllllllllIlllIlllIlIIIlllI	D
    //   68	99	13	lllllllllllllllIlllIlllIlIIIllIl	D
    //   94	73	15	lllllllllllllllIlllIlllIlIIIllII	F
    //   97	70	16	lllllllllllllllIlllIlllIlIIIlIll	D
  }
  
  public static float getBlastReduction(EntityLivingBase lllllllllllllllIlllIlllIlIIIIllI, float lllllllllllllllIlllIlllIlIIIIlIl, Explosion lllllllllllllllIlllIlllIlIIIIlII) {
    // Byte code:
    //   0: aload_0
    //   1: instanceof net/minecraft/entity/player/EntityPlayer
    //   4: invokestatic lllllIIIIlIlIII : (I)Z
    //   7: ifeq -> 135
    //   10: aload_0
    //   11: checkcast net/minecraft/entity/player/EntityPlayer
    //   14: astore_3
    //   15: aload_2
    //   16: <illegal opcode> 164 : (Lnet/minecraft/world/Explosion;)Lnet/minecraft/util/DamageSource;
    //   21: astore #4
    //   23: fload_1
    //   24: aload_3
    //   25: <illegal opcode> 165 : (Lnet/minecraft/entity/player/EntityPlayer;)I
    //   30: i2f
    //   31: aload_3
    //   32: <illegal opcode> 166 : ()Lnet/minecraft/entity/ai/attributes/IAttribute;
    //   37: <illegal opcode> 167 : (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance;
    //   42: <illegal opcode> 168 : (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)D
    //   47: d2f
    //   48: <illegal opcode> 169 : (FFF)F
    //   53: fstore_1
    //   54: aload_3
    //   55: <illegal opcode> 170 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/Iterable;
    //   60: aload #4
    //   62: <illegal opcode> 171 : (Ljava/lang/Iterable;Lnet/minecraft/util/DamageSource;)I
    //   67: istore #5
    //   69: iload #5
    //   71: i2f
    //   72: fconst_0
    //   73: ldc_w 20.0
    //   76: <illegal opcode> 172 : (FFF)F
    //   81: fstore #6
    //   83: fload_1
    //   84: fconst_1
    //   85: fload #6
    //   87: ldc_w 25.0
    //   90: fdiv
    //   91: fsub
    //   92: fmul
    //   93: fstore_1
    //   94: aload_0
    //   95: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   98: bipush #11
    //   100: iaload
    //   101: <illegal opcode> 173 : (I)Lnet/minecraft/potion/Potion;
    //   106: <illegal opcode> 174 : (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/potion/Potion;)Z
    //   111: invokestatic lllllIIIIlIlIII : (I)Z
    //   114: ifeq -> 125
    //   117: fload_1
    //   118: fload_1
    //   119: ldc_w 4.0
    //   122: fdiv
    //   123: fsub
    //   124: fstore_1
    //   125: fload_1
    //   126: fconst_0
    //   127: <illegal opcode> 175 : (FF)F
    //   132: fstore_1
    //   133: fload_1
    //   134: freturn
    //   135: fload_1
    //   136: aload_0
    //   137: <illegal opcode> 176 : (Lnet/minecraft/entity/EntityLivingBase;)I
    //   142: i2f
    //   143: aload_0
    //   144: <illegal opcode> 166 : ()Lnet/minecraft/entity/ai/attributes/IAttribute;
    //   149: <illegal opcode> 177 : (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance;
    //   154: <illegal opcode> 168 : (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)D
    //   159: d2f
    //   160: <illegal opcode> 169 : (FFF)F
    //   165: fstore_1
    //   166: fload_1
    //   167: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   15	120	3	lllllllllllllllIlllIlllIlIIIlIlI	Lnet/minecraft/entity/player/EntityPlayer;
    //   23	112	4	lllllllllllllllIlllIlllIlIIIlIIl	Lnet/minecraft/util/DamageSource;
    //   69	66	5	lllllllllllllllIlllIlllIlIIIlIII	I
    //   83	52	6	lllllllllllllllIlllIlllIlIIIIlll	F
    //   0	168	0	lllllllllllllllIlllIlllIlIIIIllI	Lnet/minecraft/entity/EntityLivingBase;
    //   0	168	1	lllllllllllllllIlllIlllIlIIIIlIl	F
    //   0	168	2	lllllllllllllllIlllIlllIlIIIIlII	Lnet/minecraft/world/Explosion;
  }
  
  public boolean canPlaceCrystal(BlockPos lllllllllllllllIlllIlllIlIIIIIlI) {
    // Byte code:
    //   0: aload_1
    //   1: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   4: iconst_0
    //   5: iaload
    //   6: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   9: iconst_1
    //   10: iaload
    //   11: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   14: iconst_0
    //   15: iaload
    //   16: <illegal opcode> 178 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   21: astore_2
    //   22: aload_1
    //   23: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   26: iconst_0
    //   27: iaload
    //   28: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   31: iconst_2
    //   32: iaload
    //   33: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: <illegal opcode> 178 : (Lnet/minecraft/util/math/BlockPos;III)Lnet/minecraft/util/math/BlockPos;
    //   43: astore_3
    //   44: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   49: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   54: aload_1
    //   55: <illegal opcode> 73 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   60: <illegal opcode> 74 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   65: <illegal opcode> 179 : ()Lnet/minecraft/block/Block;
    //   70: invokestatic lllllIIIIlIlIll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   73: ifeq -> 108
    //   76: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   81: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   86: aload_1
    //   87: <illegal opcode> 73 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   92: <illegal opcode> 74 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   97: <illegal opcode> 180 : ()Lnet/minecraft/block/Block;
    //   102: invokestatic lllllIIIIlIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   105: ifeq -> 244
    //   108: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   113: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   118: ldc_w net/minecraft/entity/Entity
    //   121: new net/minecraft/util/math/AxisAlignedBB
    //   124: dup
    //   125: aload_2
    //   126: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   129: <illegal opcode> 181 : (Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   134: <illegal opcode> 182 : (Ljava/util/List;)Z
    //   139: invokestatic lllllIIIIlIlIII : (I)Z
    //   142: ifeq -> 244
    //   145: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   150: <illegal opcode> 45 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   155: ldc_w net/minecraft/entity/Entity
    //   158: new net/minecraft/util/math/AxisAlignedBB
    //   161: dup
    //   162: aload_3
    //   163: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   166: <illegal opcode> 181 : (Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   171: <illegal opcode> 182 : (Ljava/util/List;)Z
    //   176: invokestatic lllllIIIIlIlIII : (I)Z
    //   179: ifeq -> 244
    //   182: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   185: iconst_1
    //   186: iaload
    //   187: ldc ''
    //   189: invokevirtual length : ()I
    //   192: pop
    //   193: ldc_w ' '
    //   196: invokevirtual length : ()I
    //   199: ifgt -> 249
    //   202: bipush #12
    //   204: bipush #11
    //   206: ixor
    //   207: ldc_w ' '
    //   210: invokevirtual length : ()I
    //   213: ldc_w ' '
    //   216: invokevirtual length : ()I
    //   219: ishl
    //   220: ishl
    //   221: bipush #14
    //   223: bipush #9
    //   225: ixor
    //   226: ldc_w ' '
    //   229: invokevirtual length : ()I
    //   232: ldc_w ' '
    //   235: invokevirtual length : ()I
    //   238: ishl
    //   239: ishl
    //   240: iconst_m1
    //   241: ixor
    //   242: iand
    //   243: ireturn
    //   244: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   247: iconst_0
    //   248: iaload
    //   249: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	250	0	lllllllllllllllIlllIlllIlIIIIIll	Lme/stupitdog/bhp/f0h;
    //   0	250	1	lllllllllllllllIlllIlllIlIIIIIlI	Lnet/minecraft/util/math/BlockPos;
    //   22	228	2	lllllllllllllllIlllIlllIlIIIIIIl	Lnet/minecraft/util/math/BlockPos;
    //   44	206	3	lllllllllllllllIlllIlllIlIIIIIII	Lnet/minecraft/util/math/BlockPos;
  }
  
  public List<BlockPos> getSphere(BlockPos lllllllllllllllIlllIlllIIllllIIl, float lllllllllllllllIlllIlllIIllllIII, int lllllllllllllllIlllIlllIIlllIlll, boolean lllllllllllllllIlllIlllIIlllIllI, boolean lllllllllllllllIlllIlllIIlllIlIl, int lllllllllllllllIlllIlllIIlllIlII) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: aload_1
    //   10: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;)I
    //   15: istore #8
    //   17: aload_1
    //   18: <illegal opcode> 66 : (Lnet/minecraft/util/math/BlockPos;)I
    //   23: istore #9
    //   25: aload_1
    //   26: <illegal opcode> 67 : (Lnet/minecraft/util/math/BlockPos;)I
    //   31: istore #10
    //   33: iload #8
    //   35: fload_2
    //   36: f2i
    //   37: isub
    //   38: istore #11
    //   40: iload #11
    //   42: i2f
    //   43: iload #8
    //   45: i2f
    //   46: fload_2
    //   47: fadd
    //   48: invokestatic lllllIIIIlllIll : (FF)I
    //   51: invokestatic lllllIIIIllIllI : (I)Z
    //   54: ifeq -> 485
    //   57: iload #10
    //   59: fload_2
    //   60: f2i
    //   61: isub
    //   62: istore #12
    //   64: iload #12
    //   66: i2f
    //   67: iload #10
    //   69: i2f
    //   70: fload_2
    //   71: fadd
    //   72: invokestatic lllllIIIIlllIll : (FF)I
    //   75: invokestatic lllllIIIIllIllI : (I)Z
    //   78: ifeq -> 415
    //   81: iload #5
    //   83: invokestatic lllllIIIIlIlIII : (I)Z
    //   86: ifeq -> 106
    //   89: iload #9
    //   91: fload_2
    //   92: f2i
    //   93: isub
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop
    //   100: aconst_null
    //   101: ifnull -> 108
    //   104: aconst_null
    //   105: areturn
    //   106: iload #9
    //   108: istore #13
    //   110: iload #13
    //   112: i2f
    //   113: iload #5
    //   115: invokestatic lllllIIIIlIlIII : (I)Z
    //   118: ifeq -> 180
    //   121: iload #9
    //   123: i2f
    //   124: fload_2
    //   125: fadd
    //   126: ldc ''
    //   128: invokevirtual length : ()I
    //   131: pop
    //   132: ldc_w ' '
    //   135: invokevirtual length : ()I
    //   138: ldc_w '   '
    //   141: invokevirtual length : ()I
    //   144: ldc_w ' '
    //   147: invokevirtual length : ()I
    //   150: ishl
    //   151: ishl
    //   152: ldc_w ' '
    //   155: invokevirtual length : ()I
    //   158: ldc_w '   '
    //   161: invokevirtual length : ()I
    //   164: ldc_w ' '
    //   167: invokevirtual length : ()I
    //   170: ishl
    //   171: ishl
    //   172: iconst_m1
    //   173: ixor
    //   174: iand
    //   175: ifeq -> 185
    //   178: aconst_null
    //   179: areturn
    //   180: iload #9
    //   182: iload_3
    //   183: iadd
    //   184: i2f
    //   185: invokestatic lllllIIIIlllIll : (FF)I
    //   188: invokestatic lllllIIIIlIllll : (I)Z
    //   191: ifeq -> 366
    //   194: iload #8
    //   196: iload #11
    //   198: isub
    //   199: iload #8
    //   201: iload #11
    //   203: isub
    //   204: imul
    //   205: iload #10
    //   207: iload #12
    //   209: isub
    //   210: iload #10
    //   212: iload #12
    //   214: isub
    //   215: imul
    //   216: iadd
    //   217: iload #5
    //   219: invokestatic lllllIIIIlIlIII : (I)Z
    //   222: ifeq -> 260
    //   225: iload #9
    //   227: iload #13
    //   229: isub
    //   230: iload #9
    //   232: iload #13
    //   234: isub
    //   235: imul
    //   236: ldc ''
    //   238: invokevirtual length : ()I
    //   241: pop
    //   242: ldc_w ' '
    //   245: invokevirtual length : ()I
    //   248: ineg
    //   249: ldc_w '   '
    //   252: invokevirtual length : ()I
    //   255: if_icmplt -> 265
    //   258: aconst_null
    //   259: areturn
    //   260: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   263: iconst_0
    //   264: iaload
    //   265: iadd
    //   266: i2d
    //   267: dstore #14
    //   269: dload #14
    //   271: fload_2
    //   272: fload_2
    //   273: fmul
    //   274: f2d
    //   275: invokestatic lllllIIIIllllII : (DD)I
    //   278: invokestatic lllllIIIIlIllll : (I)Z
    //   281: ifeq -> 344
    //   284: iload #4
    //   286: invokestatic lllllIIIIlIlIII : (I)Z
    //   289: ifeq -> 311
    //   292: dload #14
    //   294: fload_2
    //   295: fconst_1
    //   296: fsub
    //   297: fload_2
    //   298: fconst_1
    //   299: fsub
    //   300: fmul
    //   301: f2d
    //   302: invokestatic lllllIIIIllllII : (DD)I
    //   305: invokestatic lllllIIIIlIlllI : (I)Z
    //   308: ifeq -> 344
    //   311: new net/minecraft/util/math/BlockPos
    //   314: dup
    //   315: iload #11
    //   317: iload #13
    //   319: iload #6
    //   321: iadd
    //   322: iload #12
    //   324: invokespecial <init> : (III)V
    //   327: astore #16
    //   329: aload #7
    //   331: aload #16
    //   333: <illegal opcode> 183 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   338: ldc ''
    //   340: invokevirtual length : ()I
    //   343: pop2
    //   344: iinc #13, 1
    //   347: ldc ''
    //   349: invokevirtual length : ()I
    //   352: pop
    //   353: sipush #139
    //   356: sipush #143
    //   359: ixor
    //   360: ineg
    //   361: iflt -> 110
    //   364: aconst_null
    //   365: areturn
    //   366: iinc #12, 1
    //   369: ldc ''
    //   371: invokevirtual length : ()I
    //   374: pop
    //   375: bipush #90
    //   377: bipush #93
    //   379: ixor
    //   380: ldc_w ' '
    //   383: invokevirtual length : ()I
    //   386: ishl
    //   387: sipush #172
    //   390: sipush #171
    //   393: ixor
    //   394: ldc_w ' '
    //   397: invokevirtual length : ()I
    //   400: ishl
    //   401: iconst_m1
    //   402: ixor
    //   403: iand
    //   404: ldc_w '   '
    //   407: invokevirtual length : ()I
    //   410: if_icmple -> 64
    //   413: aconst_null
    //   414: areturn
    //   415: iinc #11, 1
    //   418: ldc ''
    //   420: invokevirtual length : ()I
    //   423: pop
    //   424: bipush #15
    //   426: bipush #68
    //   428: ixor
    //   429: iconst_5
    //   430: bipush #58
    //   432: ixor
    //   433: ldc_w ' '
    //   436: invokevirtual length : ()I
    //   439: ishl
    //   440: ixor
    //   441: bipush #56
    //   443: bipush #98
    //   445: iadd
    //   446: bipush #79
    //   448: isub
    //   449: bipush #100
    //   451: iadd
    //   452: bipush #59
    //   454: bipush #118
    //   456: ixor
    //   457: ldc_w ' '
    //   460: invokevirtual length : ()I
    //   463: ishl
    //   464: ixor
    //   465: ldc_w ' '
    //   468: invokevirtual length : ()I
    //   471: ineg
    //   472: ixor
    //   473: iand
    //   474: ldc_w ' '
    //   477: invokevirtual length : ()I
    //   480: if_icmpne -> 40
    //   483: aconst_null
    //   484: areturn
    //   485: aload #7
    //   487: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   329	15	16	lllllllllllllllIlllIlllIIlllllll	Lnet/minecraft/util/math/BlockPos;
    //   269	75	14	lllllllllllllllIlllIlllIIllllllI	D
    //   110	256	13	lllllllllllllllIlllIlllIIlllllIl	I
    //   64	351	12	lllllllllllllllIlllIlllIIlllllII	I
    //   40	445	11	lllllllllllllllIlllIlllIIllllIll	I
    //   0	488	0	lllllllllllllllIlllIlllIIllllIlI	Lme/stupitdog/bhp/f0h;
    //   0	488	1	lllllllllllllllIlllIlllIIllllIIl	Lnet/minecraft/util/math/BlockPos;
    //   0	488	2	lllllllllllllllIlllIlllIIllllIII	F
    //   0	488	3	lllllllllllllllIlllIlllIIlllIlll	I
    //   0	488	4	lllllllllllllllIlllIlllIIlllIllI	Z
    //   0	488	5	lllllllllllllllIlllIlllIIlllIlIl	Z
    //   0	488	6	lllllllllllllllIlllIlllIIlllIlII	I
    //   9	479	7	lllllllllllllllIlllIlllIIlllIIll	Ljava/util/List;
    //   17	471	8	lllllllllllllllIlllIlllIIlllIIlI	I
    //   25	463	9	lllllllllllllllIlllIlllIIlllIIIl	I
    //   33	455	10	lllllllllllllllIlllIlllIIlllIIII	I
    // Local variable type table:
    //   start	length	slot	name	signature
    //   9	479	7	lllllllllllllllIlllIlllIIlllIIll	Ljava/util/List<Lnet/minecraft/util/math/BlockPos;>;
  }
  
  public static BlockPos getPlayerPos() {
    // Byte code:
    //   0: new net/minecraft/util/math/BlockPos
    //   3: dup
    //   4: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   9: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   14: <illegal opcode> 87 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   19: <illegal opcode> 184 : (D)D
    //   24: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   29: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   34: <illegal opcode> 88 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   39: <illegal opcode> 184 : (D)D
    //   44: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   49: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   54: <illegal opcode> 90 : (Lnet/minecraft/client/entity/EntityPlayerSP;)D
    //   59: <illegal opcode> 184 : (D)D
    //   64: invokespecial <init> : (DDD)V
    //   67: areturn
  }
  
  private List<BlockPos> findCrystalBlocks() {
    // Byte code:
    //   0: <illegal opcode> 185 : ()Lnet/minecraft/util/NonNullList;
    //   5: astore_1
    //   6: aload_1
    //   7: aload_0
    //   8: <illegal opcode> 186 : ()Lnet/minecraft/util/math/BlockPos;
    //   13: aload_0
    //   14: <illegal opcode> 62 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   19: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   24: d2f
    //   25: aload_0
    //   26: <illegal opcode> 62 : (Lme/stupitdog/bhp/f0h;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   31: <illegal opcode> 63 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   36: d2i
    //   37: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   40: iconst_0
    //   41: iaload
    //   42: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   45: iconst_1
    //   46: iaload
    //   47: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   50: iconst_0
    //   51: iaload
    //   52: <illegal opcode> 187 : (Lme/stupitdog/bhp/f0h;Lnet/minecraft/util/math/BlockPos;FIZZI)Ljava/util/List;
    //   57: <illegal opcode> 47 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   62: aload_0
    //   63: <illegal opcode> test : (Lme/stupitdog/bhp/f0h;)Ljava/util/function/Predicate;
    //   68: <illegal opcode> 106 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   73: <illegal opcode> 48 : ()Ljava/util/stream/Collector;
    //   78: <illegal opcode> 49 : (Ljava/util/stream/Stream;Ljava/util/stream/Collector;)Ljava/lang/Object;
    //   83: checkcast java/util/Collection
    //   86: <illegal opcode> 188 : (Lnet/minecraft/util/NonNullList;Ljava/util/Collection;)Z
    //   91: ldc ''
    //   93: invokevirtual length : ()I
    //   96: pop2
    //   97: aload_1
    //   98: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	99	0	lllllllllllllllIlllIlllIIllIllll	Lme/stupitdog/bhp/f0h;
    //   6	93	1	lllllllllllllllIlllIlllIIllIlllI	Lnet/minecraft/util/NonNullList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   6	93	1	lllllllllllllllIlllIlllIIllIlllI	Lnet/minecraft/util/NonNullList<Lnet/minecraft/util/math/BlockPos;>;
  }
  
  private static void resetRotation() {
    // Byte code:
    //   0: <illegal opcode> 189 : ()Z
    //   5: invokestatic lllllIIIIlIlIII : (I)Z
    //   8: ifeq -> 63
    //   11: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   16: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   21: <illegal opcode> 147 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   26: f2d
    //   27: <illegal opcode> 190 : (D)V
    //   32: <illegal opcode> 34 : ()Lnet/minecraft/client/Minecraft;
    //   37: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   42: <illegal opcode> 149 : (Lnet/minecraft/client/entity/EntityPlayerSP;)F
    //   47: f2d
    //   48: <illegal opcode> 191 : (D)V
    //   53: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   56: iconst_0
    //   57: iaload
    //   58: <illegal opcode> 192 : (Z)V
    //   63: return
  }
  
  public static double[] calculateLookAt(double lllllllllllllllIlllIlllIIllIllIl, double lllllllllllllllIlllIlllIIllIllII, double lllllllllllllllIlllIlllIIllIlIll, EntityPlayer lllllllllllllllIlllIlllIIllIlIlI) {
    // Byte code:
    //   0: aload #6
    //   2: <illegal opcode> 193 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   7: dload_0
    //   8: dsub
    //   9: dstore #7
    //   11: aload #6
    //   13: <illegal opcode> 194 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   18: dload_2
    //   19: dsub
    //   20: dstore #9
    //   22: aload #6
    //   24: <illegal opcode> 195 : (Lnet/minecraft/entity/player/EntityPlayer;)D
    //   29: dload #4
    //   31: dsub
    //   32: dstore #11
    //   34: dload #7
    //   36: dload #7
    //   38: dmul
    //   39: dload #9
    //   41: dload #9
    //   43: dmul
    //   44: dadd
    //   45: dload #11
    //   47: dload #11
    //   49: dmul
    //   50: dadd
    //   51: <illegal opcode> 196 : (D)D
    //   56: dstore #13
    //   58: dload #7
    //   60: dload #13
    //   62: ddiv
    //   63: dstore #7
    //   65: dload #9
    //   67: dload #13
    //   69: ddiv
    //   70: dstore #9
    //   72: dload #11
    //   74: dload #13
    //   76: ddiv
    //   77: dstore #11
    //   79: dload #9
    //   81: <illegal opcode> 197 : (D)D
    //   86: dstore #15
    //   88: dload #11
    //   90: dload #7
    //   92: <illegal opcode> 198 : (DD)D
    //   97: dstore #17
    //   99: dload #15
    //   101: ldc2_w 180.0
    //   104: dmul
    //   105: ldc2_w 3.141592653589793
    //   108: ddiv
    //   109: dstore #15
    //   111: dload #17
    //   113: ldc2_w 180.0
    //   116: dmul
    //   117: ldc2_w 3.141592653589793
    //   120: ddiv
    //   121: dstore #17
    //   123: dload #17
    //   125: ldc2_w 90.0
    //   128: dadd
    //   129: dstore #17
    //   131: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   134: iconst_2
    //   135: iaload
    //   136: newarray double
    //   138: dup
    //   139: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   142: iconst_0
    //   143: iaload
    //   144: dload #17
    //   146: dastore
    //   147: dup
    //   148: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   151: iconst_1
    //   152: iaload
    //   153: dload #15
    //   155: dastore
    //   156: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	157	0	lllllllllllllllIlllIlllIIllIllIl	D
    //   0	157	2	lllllllllllllllIlllIlllIIllIllII	D
    //   0	157	4	lllllllllllllllIlllIlllIIllIlIll	D
    //   0	157	6	lllllllllllllllIlllIlllIIllIlIlI	Lnet/minecraft/entity/player/EntityPlayer;
    //   11	146	7	lllllllllllllllIlllIlllIIllIlIIl	D
    //   22	135	9	lllllllllllllllIlllIlllIIllIlIII	D
    //   34	123	11	lllllllllllllllIlllIlllIIllIIlll	D
    //   58	99	13	lllllllllllllllIlllIlllIIllIIllI	D
    //   88	69	15	lllllllllllllllIlllIlllIIllIIlIl	D
    //   99	58	17	lllllllllllllllIlllIlllIIllIIlII	D
  }
  
  private static void setYawAndPitch(float lllllllllllllllIlllIlllIIllIIIll, float lllllllllllllllIlllIlllIIllIIIlI) {
    // Byte code:
    //   0: fload_0
    //   1: f2d
    //   2: <illegal opcode> 190 : (D)V
    //   7: fload_1
    //   8: f2d
    //   9: <illegal opcode> 191 : (D)V
    //   14: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   17: iconst_1
    //   18: iaload
    //   19: <illegal opcode> 192 : (Z)V
    //   24: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	25	0	lllllllllllllllIlllIlllIIllIIIll	F
    //   0	25	1	lllllllllllllllIlllIlllIIllIIIlI	F
  }
  
  private void lookAtPacket(double lllllllllllllllIlllIlllIIllIIIII, double lllllllllllllllIlllIlllIIlIlllll, double lllllllllllllllIlllIlllIIlIllllI, EntityPlayer lllllllllllllllIlllIlllIIlIlllIl) {
    // Byte code:
    //   0: dload_1
    //   1: dload_3
    //   2: dload #5
    //   4: aload #7
    //   6: <illegal opcode> 199 : (DDDLnet/minecraft/entity/player/EntityPlayer;)[D
    //   11: astore #8
    //   13: aload #8
    //   15: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   18: iconst_0
    //   19: iaload
    //   20: daload
    //   21: d2f
    //   22: aload #8
    //   24: getstatic me/stupitdog/bhp/f0h.lIlllIIlIIIIII : [I
    //   27: iconst_1
    //   28: iaload
    //   29: daload
    //   30: d2f
    //   31: <illegal opcode> 200 : (FF)V
    //   36: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	37	0	lllllllllllllllIlllIlllIIllIIIIl	Lme/stupitdog/bhp/f0h;
    //   0	37	1	lllllllllllllllIlllIlllIIllIIIII	D
    //   0	37	3	lllllllllllllllIlllIlllIIlIlllll	D
    //   0	37	5	lllllllllllllllIlllIlllIIlIllllI	D
    //   0	37	7	lllllllllllllllIlllIlllIIlIlllIl	Lnet/minecraft/entity/player/EntityPlayer;
    //   13	24	8	lllllllllllllllIlllIlllIIlIlllII	[D
  }
  
  private double interpolate(double lllllllllllllllIlllIlllIIlIllIlI, double lllllllllllllllIlllIlllIIlIllIIl, float lllllllllllllllIlllIlllIIlIllIII) {
    return lllllllllllllllIlllIlllIIlIllIlI + (lllllllllllllllIlllIlllIIlIllIIl - lllllllllllllllIlllIlllIIlIllIlI) * lllllllllllllllIlllIlllIIlIllIII;
  }
  
  static {
    lllllIIIIlIIlII();
    lllllIIIIIllllI();
    lllllIIIIIlllIl();
    llllIlllllllIlI();
  }
  
  private static CallSite llllIIllIlllIIl(MethodHandles.Lookup lllllllllllllllIlllIlllIIlIIIIlI, String lllllllllllllllIlllIlllIIlIIIIIl, MethodType lllllllllllllllIlllIlllIIlIIIIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlllIIlIIlIII = lIllIlIlIIIlll[Integer.parseInt(lllllllllllllllIlllIlllIIlIIIIIl)].split(lIlllIIIllIlII[lIlllIIlIIIIII[37]]);
      Class<?> lllllllllllllllIlllIlllIIlIIIlll = Class.forName(lllllllllllllllIlllIlllIIlIIlIII[lIlllIIlIIIIII[0]]);
      String lllllllllllllllIlllIlllIIlIIIllI = lllllllllllllllIlllIlllIIlIIlIII[lIlllIIlIIIIII[1]];
      MethodHandle lllllllllllllllIlllIlllIIlIIIlIl = null;
      int lllllllllllllllIlllIlllIIlIIIlII = lllllllllllllllIlllIlllIIlIIlIII[lIlllIIlIIIIII[3]].length();
      if (lllllIIIIlllllI(lllllllllllllllIlllIlllIIlIIIlII, lIlllIIlIIIIII[2])) {
        MethodType lllllllllllllllIlllIlllIIlIIlIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlllIIlIIlIII[lIlllIIlIIIIII[2]], f0h.class.getClassLoader());
        if (lllllIIIIllIIll(lllllllllllllllIlllIlllIIlIIIlII, lIlllIIlIIIIII[2])) {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findVirtual(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findStatic(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIlI);
        } 
        "".length();
        if (-" ".length() != -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlllIIlIIlIIl = lIllIlIlIIlIII[Integer.parseInt(lllllllllllllllIlllIlllIIlIIlIII[lIlllIIlIIIIII[2]])];
        if (lllllIIIIllIIll(lllllllllllllllIlllIlllIIlIIIlII, lIlllIIlIIIIII[3])) {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findGetter(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIIl);
          "".length();
          if (((0x4A ^ 0x29) & (0x17 ^ 0x74 ^ 0xFFFFFFFF)) >= " ".length())
            return null; 
        } else if (lllllIIIIllIIll(lllllllllllllllIlllIlllIIlIIIlII, lIlllIIlIIIIII[4])) {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findStaticGetter(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else if (lllllIIIIllIIll(lllllllllllllllIlllIlllIIlIIIlII, lIlllIIlIIIIII[5])) {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findSetter(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIIl);
          "".length();
          if (" ".length() << " ".length() < " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIlllIIlIIIlIl = lllllllllllllllIlllIlllIIlIIIIlI.findStaticSetter(lllllllllllllllIlllIlllIIlIIIlll, lllllllllllllllIlllIlllIIlIIIllI, lllllllllllllllIlllIlllIIlIIlIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlllIIlIIIlIl);
    } catch (Exception lllllllllllllllIlllIlllIIlIIIIll) {
      lllllllllllllllIlllIlllIIlIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlllllllIlI() {
    lIllIlIlIIIlll = new String[lIlllIIlIIIIII[38]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[39]] = lIlllIIIllIlII[lIlllIIlIIIIII[40]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[9]] = lIlllIIIllIlII[lIlllIIlIIIIII[41]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[42]] = lIlllIIIllIlII[lIlllIIlIIIIII[43]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[6]] = lIlllIIIllIlII[lIlllIIlIIIIII[44]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[45]] = lIlllIIIllIlII[lIlllIIlIIIIII[46]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[47]] = lIlllIIIllIlII[lIlllIIlIIIIII[48]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[49]] = lIlllIIIllIlII[lIlllIIlIIIIII[50]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[51]] = lIlllIIIllIlII[lIlllIIlIIIIII[52]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[53]] = lIlllIIIllIlII[lIlllIIlIIIIII[54]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[55]] = lIlllIIIllIlII[lIlllIIlIIIIII[56]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[57]] = lIlllIIIllIlII[lIlllIIlIIIIII[58]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[59]] = lIlllIIIllIlII[lIlllIIlIIIIII[60]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[23]] = lIlllIIIllIlII[lIlllIIlIIIIII[61]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[62]] = lIlllIIIllIlII[lIlllIIlIIIIII[63]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[64]] = lIlllIIIllIlII[lIlllIIlIIIIII[65]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[66]] = lIlllIIIllIlII[lIlllIIlIIIIII[67]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[68]] = lIlllIIIllIlII[lIlllIIlIIIIII[69]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[7]] = lIlllIIIllIlII[lIlllIIlIIIIII[70]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[71]] = lIlllIIIllIlII[lIlllIIlIIIIII[72]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[73]] = lIlllIIIllIlII[lIlllIIlIIIIII[74]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[65]] = lIlllIIIllIlII[lIlllIIlIIIIII[75]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[76]] = lIlllIIIllIlII[lIlllIIlIIIIII[77]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[78]] = lIlllIIIllIlII[lIlllIIlIIIIII[79]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[35]] = lIlllIIIllIlII[lIlllIIlIIIIII[80]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[81]] = lIlllIIIllIlII[lIlllIIlIIIIII[82]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[83]] = lIlllIIIllIlII[lIlllIIlIIIIII[84]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[15]] = lIlllIIIllIlII[lIlllIIlIIIIII[85]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[86]] = lIlllIIIllIlII[lIlllIIlIIIIII[87]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[88]] = lIlllIIIllIlII[lIlllIIlIIIIII[62]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[89]] = lIlllIIIllIlII[lIlllIIlIIIIII[90]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[91]] = lIlllIIIllIlII[lIlllIIlIIIIII[92]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[74]] = lIlllIIIllIlII[lIlllIIlIIIIII[93]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[94]] = lIlllIIIllIlII[lIlllIIlIIIIII[95]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[96]] = lIlllIIIllIlII[lIlllIIlIIIIII[97]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[98]] = lIlllIIIllIlII[lIlllIIlIIIIII[99]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[63]] = lIlllIIIllIlII[lIlllIIlIIIIII[100]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[61]] = lIlllIIIllIlII[lIlllIIlIIIIII[101]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[46]] = lIlllIIIllIlII[lIlllIIlIIIIII[102]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[20]] = lIlllIIIllIlII[lIlllIIlIIIIII[103]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[11]] = lIlllIIIllIlII[lIlllIIlIIIIII[104]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[105]] = lIlllIIIllIlII[lIlllIIlIIIIII[106]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[26]] = lIlllIIIllIlII[lIlllIIlIIIIII[107]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[29]] = lIlllIIIllIlII[lIlllIIlIIIIII[78]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[99]] = lIlllIIIllIlII[lIlllIIlIIIIII[108]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[109]] = lIlllIIIllIlII[lIlllIIlIIIIII[105]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[19]] = lIlllIIIllIlII[lIlllIIlIIIIII[55]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[17]] = lIlllIIIllIlII[lIlllIIlIIIIII[110]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[14]] = lIlllIIIllIlII[lIlllIIlIIIIII[111]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[103]] = lIlllIIIllIlII[lIlllIIlIIIIII[112]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[113]] = lIlllIIIllIlII[lIlllIIlIIIIII[114]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[22]] = lIlllIIIllIlII[lIlllIIlIIIIII[115]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[116]] = lIlllIIIllIlII[lIlllIIlIIIIII[117]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[118]] = lIlllIIIllIlII[lIlllIIlIIIIII[91]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[67]] = lIlllIIIllIlII[lIlllIIlIIIIII[119]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[24]] = lIlllIIIllIlII[lIlllIIlIIIIII[120]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[2]] = lIlllIIIllIlII[lIlllIIlIIIIII[96]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[121]] = lIlllIIIllIlII[lIlllIIlIIIIII[113]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[122]] = lIlllIIIllIlII[lIlllIIlIIIIII[123]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[124]] = lIlllIIIllIlII[lIlllIIlIIIIII[125]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[126]] = lIlllIIIllIlII[lIlllIIlIIIIII[127]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[128]] = lIlllIIIllIlII[lIlllIIlIIIIII[129]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[130]] = lIlllIIIllIlII[lIlllIIlIIIIII[59]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[131]] = lIlllIIIllIlII[lIlllIIlIIIIII[132]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[133]] = lIlllIIIllIlII[lIlllIIlIIIIII[83]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[41]] = lIlllIIIllIlII[lIlllIIlIIIIII[134]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[135]] = lIlllIIIllIlII[lIlllIIlIIIIII[136]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[50]] = lIlllIIIllIlII[lIlllIIlIIIIII[137]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[82]] = lIlllIIIllIlII[lIlllIIlIIIIII[138]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[52]] = lIlllIIIllIlII[lIlllIIlIIIIII[139]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[77]] = lIlllIIIllIlII[lIlllIIlIIIIII[122]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[140]] = lIlllIIIllIlII[lIlllIIlIIIIII[141]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[142]] = lIlllIIIllIlII[lIlllIIlIIIIII[143]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[104]] = lIlllIIIllIlII[lIlllIIlIIIIII[144]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[75]] = lIlllIIIllIlII[lIlllIIlIIIIII[145]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[146]] = lIlllIIIllIlII[lIlllIIlIIIIII[147]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[40]] = lIlllIIIllIlII[lIlllIIlIIIIII[109]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[148]] = lIlllIIIllIlII[lIlllIIlIIIIII[149]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[150]] = lIlllIIIllIlII[lIlllIIlIIIIII[47]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[4]] = lIlllIIIllIlII[lIlllIIlIIIIII[151]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[152]] = lIlllIIIllIlII[lIlllIIlIIIIII[118]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[153]] = lIlllIIIllIlII[lIlllIIlIIIIII[94]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[129]] = lIlllIIIllIlII[lIlllIIlIIIIII[51]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[154]] = lIlllIIIllIlII[lIlllIIlIIIIII[155]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[115]] = lIlllIIIllIlII[lIlllIIlIIIIII[156]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[157]] = lIlllIIIllIlII[lIlllIIlIIIIII[148]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[127]] = lIlllIIIllIlII[lIlllIIlIIIIII[71]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[117]] = lIlllIIIllIlII[lIlllIIlIIIIII[157]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[80]] = lIlllIIIllIlII[lIlllIIlIIIIII[126]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[110]] = lIlllIIIllIlII[lIlllIIlIIIIII[158]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[159]] = lIlllIIIllIlII[lIlllIIlIIIIII[152]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[85]] = lIlllIIIllIlII[lIlllIIlIIIIII[86]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[27]] = lIlllIIIllIlII[lIlllIIlIIIIII[160]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[161]] = lIlllIIIllIlII[lIlllIIlIIIIII[162]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[143]] = lIlllIIIllIlII[lIlllIIlIIIIII[76]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[163]] = lIlllIIIllIlII[lIlllIIlIIIIII[164]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[1]] = lIlllIIIllIlII[lIlllIIlIIIIII[163]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[151]] = lIlllIIIllIlII[lIlllIIlIIIIII[165]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[32]] = lIlllIIIllIlII[lIlllIIlIIIIII[166]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[165]] = lIlllIIIllIlII[lIlllIIlIIIIII[167]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[44]] = lIlllIIIllIlII[lIlllIIlIIIIII[64]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[111]] = lIlllIIIllIlII[lIlllIIlIIIIII[168]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[56]] = lIlllIIIllIlII[lIlllIIlIIIIII[169]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[114]] = lIlllIIIllIlII[lIlllIIlIIIIII[170]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[141]] = lIlllIIIllIlII[lIlllIIlIIIIII[171]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[155]] = lIlllIIIllIlII[lIlllIIlIIIIII[172]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[173]] = lIlllIIIllIlII[lIlllIIlIIIIII[174]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[175]] = lIlllIIIllIlII[lIlllIIlIIIIII[176]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[34]] = lIlllIIIllIlII[lIlllIIlIIIIII[177]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[33]] = lIlllIIIllIlII[lIlllIIlIIIIII[150]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[108]] = lIlllIIIllIlII[lIlllIIlIIIIII[178]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[120]] = lIlllIIIllIlII[lIlllIIlIIIIII[89]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[179]] = lIlllIIIllIlII[lIlllIIlIIIIII[180]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[100]] = lIlllIIIllIlII[lIlllIIlIIIIII[181]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[90]] = lIlllIIIllIlII[lIlllIIlIIIIII[161]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[5]] = lIlllIIIllIlII[lIlllIIlIIIIII[182]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[183]] = lIlllIIIllIlII[lIlllIIlIIIIII[184]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[185]] = lIlllIIIllIlII[lIlllIIlIIIIII[159]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[182]] = lIlllIIIllIlII[lIlllIIlIIIIII[49]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[186]] = lIlllIIIllIlII[lIlllIIlIIIIII[154]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[187]] = lIlllIIIllIlII[lIlllIIlIIIIII[42]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[54]] = lIlllIIIllIlII[lIlllIIlIIIIII[88]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[188]] = lIlllIIIllIlII[lIlllIIlIIIIII[186]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[25]] = lIlllIIIllIlII[lIlllIIlIIIIII[128]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[158]] = lIlllIIIllIlII[lIlllIIlIIIIII[121]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[189]] = lIlllIIIllIlII[lIlllIIlIIIIII[142]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[171]] = lIlllIIIllIlII[lIlllIIlIIIIII[133]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[112]] = lIlllIIIllIlII[lIlllIIlIIIIII[173]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[12]] = lIlllIIIllIlII[lIlllIIlIIIIII[190]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[106]] = lIlllIIIllIlII[lIlllIIlIIIIII[191]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[192]] = lIlllIIIllIlII[lIlllIIlIIIIII[124]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[139]] = lIlllIIIllIlII[lIlllIIlIIIIII[116]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[174]] = lIlllIIIllIlII[lIlllIIlIIIIII[192]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[92]] = lIlllIIIllIlII[lIlllIIlIIIIII[185]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[125]] = lIlllIIIllIlII[lIlllIIlIIIIII[188]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[193]] = lIlllIIIllIlII[lIlllIIlIIIIII[194]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[138]] = lIlllIIIllIlII[lIlllIIlIIIIII[195]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[37]] = lIlllIIIllIlII[lIlllIIlIIIIII[183]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[196]] = lIlllIIIllIlII[lIlllIIlIIIIII[73]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[191]] = lIlllIIIllIlII[lIlllIIlIIIIII[130]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[197]] = lIlllIIIllIlII[lIlllIIlIIIIII[57]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[198]] = lIlllIIIllIlII[lIlllIIlIIIIII[199]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[200]] = lIlllIIIllIlII[lIlllIIlIIIIII[201]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[95]] = lIlllIIIllIlII[lIlllIIlIIIIII[202]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[170]] = lIlllIIIllIlII[lIlllIIlIIIIII[203]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[194]] = lIlllIIIllIlII[lIlllIIlIIIIII[204]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[204]] = lIlllIIIllIlII[lIlllIIlIIIIII[205]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[160]] = lIlllIIIllIlII[lIlllIIlIIIIII[39]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[21]] = lIlllIIIllIlII[lIlllIIlIIIIII[81]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[107]] = lIlllIIIllIlII[lIlllIIlIIIIII[45]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[16]] = lIlllIIIllIlII[lIlllIIlIIIIII[140]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[69]] = lIlllIIIllIlII[lIlllIIlIIIIII[206]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[172]] = lIlllIIIllIlII[lIlllIIlIIIIII[179]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[137]] = lIlllIIIllIlII[lIlllIIlIIIIII[207]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[207]] = lIlllIIIllIlII[lIlllIIlIIIIII[208]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[136]] = lIlllIIIllIlII[lIlllIIlIIIIII[198]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[162]] = lIlllIIIllIlII[lIlllIIlIIIIII[66]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[70]] = lIlllIIIllIlII[lIlllIIlIIIIII[209]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[166]] = lIlllIIIllIlII[lIlllIIlIIIIII[210]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[72]] = lIlllIIIllIlII[lIlllIIlIIIIII[197]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[156]] = lIlllIIIllIlII[lIlllIIlIIIIII[175]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[134]] = lIlllIIIllIlII[lIlllIIlIIIIII[53]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[145]] = lIlllIIIllIlII[lIlllIIlIIIIII[211]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[18]] = lIlllIIIllIlII[lIlllIIlIIIIII[212]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[201]] = lIlllIIIllIlII[lIlllIIlIIIIII[213]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[84]] = lIlllIIIllIlII[lIlllIIlIIIIII[135]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[211]] = lIlllIIIllIlII[lIlllIIlIIIIII[214]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[147]] = lIlllIIIllIlII[lIlllIIlIIIIII[68]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[215]] = lIlllIIIllIlII[lIlllIIlIIIIII[215]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[195]] = lIlllIIIllIlII[lIlllIIlIIIIII[189]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[209]] = lIlllIIIllIlII[lIlllIIlIIIIII[153]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[101]] = lIlllIIIllIlII[lIlllIIlIIIIII[200]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[181]] = lIlllIIIllIlII[lIlllIIlIIIIII[98]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[177]] = lIlllIIIllIlII[lIlllIIlIIIIII[216]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[216]] = lIlllIIIllIlII[lIlllIIlIIIIII[217]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[31]] = lIlllIIIllIlII[lIlllIIlIIIIII[218]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[97]] = lIlllIIIllIlII[lIlllIIlIIIIII[146]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[167]] = lIlllIIIllIlII[lIlllIIlIIIIII[193]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[60]] = lIlllIIIllIlII[lIlllIIlIIIIII[187]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[203]] = lIlllIIIllIlII[lIlllIIlIIIIII[131]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[3]] = lIlllIIIllIlII[lIlllIIlIIIIII[196]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[178]] = lIlllIIIllIlII[lIlllIIlIIIIII[219]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[210]] = lIlllIIIllIlII[lIlllIIlIIIIII[38]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[119]] = lIlllIIIllIlII[lIlllIIlIIIIII[220]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[208]] = lIlllIIIllIlII[lIlllIIlIIIIII[221]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[219]] = lIlllIIIllIlII[lIlllIIlIIIIII[222]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[87]] = lIlllIIIllIlII[lIlllIIlIIIIII[223]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[79]] = lIlllIIIllIlII[lIlllIIlIIIIII[224]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[0]] = lIlllIIIllIlII[lIlllIIlIIIIII[225]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[48]] = lIlllIIIllIlII[lIlllIIlIIIIII[226]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[123]] = lIlllIIIllIlII[lIlllIIlIIIIII[227]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[8]] = lIlllIIIllIlII[lIlllIIlIIIIII[228]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[168]] = lIlllIIIllIlII[lIlllIIlIIIIII[229]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[184]] = lIlllIIIllIlII[lIlllIIlIIIIII[230]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[218]] = lIlllIIIllIlII[lIlllIIlIIIIII[231]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[213]] = lIlllIIIllIlII[lIlllIIlIIIIII[232]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[180]] = lIlllIIIllIlII[lIlllIIlIIIIII[233]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[144]] = lIlllIIIllIlII[lIlllIIlIIIIII[234]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[212]] = lIlllIIIllIlII[lIlllIIlIIIIII[235]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[58]] = lIlllIIIllIlII[lIlllIIlIIIIII[236]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[169]] = lIlllIIIllIlII[lIlllIIlIIIIII[237]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[149]] = lIlllIIIllIlII[lIlllIIlIIIIII[238]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[190]] = lIlllIIIllIlII[lIlllIIlIIIIII[239]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[205]] = lIlllIIIllIlII[lIlllIIlIIIIII[240]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[202]] = lIlllIIIllIlII[lIlllIIlIIIIII[241]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[176]] = lIlllIIIllIlII[lIlllIIlIIIIII[242]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[10]] = lIlllIIIllIlII[lIlllIIlIIIIII[243]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[102]] = lIlllIIIllIlII[lIlllIIlIIIIII[244]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[43]] = lIlllIIIllIlII[lIlllIIlIIIIII[245]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[164]] = lIlllIIIllIlII[lIlllIIlIIIIII[246]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[199]] = lIlllIIIllIlII[lIlllIIlIIIIII[247]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[132]] = lIlllIIIllIlII[lIlllIIlIIIIII[248]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[217]] = lIlllIIIllIlII[lIlllIIlIIIIII[249]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[206]] = lIlllIIIllIlII[lIlllIIlIIIIII[250]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[93]] = lIlllIIIllIlII[lIlllIIlIIIIII[251]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[13]] = lIlllIIIllIlII[lIlllIIlIIIIII[252]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[30]] = lIlllIIIllIlII[lIlllIIlIIIIII[253]];
    lIllIlIlIIIlll[lIlllIIlIIIIII[214]] = lIlllIIIllIlII[lIlllIIlIIIIII[254]];
    lIllIlIlIIlIII = new Class[lIlllIIlIIIIII[32]];
    lIllIlIlIIlIII[lIlllIIlIIIIII[13]] = int.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[6]] = f100000000000000000000.Mode.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[30]] = World.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[24]] = EnumHand.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[23]] = NetHandlerPlayClient.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[26]] = float.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[19]] = Entity.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[15]] = List.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[11]] = NonNullList.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[16]] = f9.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[12]] = Item.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[7]] = f100000000000000000000.ColorSetting.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[2]] = ArrayList.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[0]] = f13.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[31]] = IAttribute.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[18]] = Block.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[5]] = f100000000000000000000.Double.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[20]] = BlockPos.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[21]] = double.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[14]] = WorldClient.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[25]] = FontRenderer.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[10]] = InventoryPlayer.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[9]] = EntityPlayerSP.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[27]] = GameSettings.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[29]] = boolean.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[22]] = EnumFacing.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[4]] = f100000000000000000000.Boolean.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[8]] = Minecraft.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[17]] = a.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[3]] = Listener.class;
    lIllIlIlIIlIII[lIlllIIlIIIIII[1]] = ao.class;
  }
  
  private static void lllllIIIIIlllIl() {
    lIlllIIIllIlII = new String[lIlllIIlIIIIII[255]];
    lIlllIIIllIlII[lIlllIIlIIIIII[0]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[0]], lIlllIIIllllll[lIlllIIlIIIIII[1]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[1]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[2]], lIlllIIIllllll[lIlllIIlIIIIII[3]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[2]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[4]], lIlllIIIllllll[lIlllIIlIIIIII[5]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[3]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[6]], lIlllIIIllllll[lIlllIIlIIIIII[7]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[4]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[8]], lIlllIIIllllll[lIlllIIlIIIIII[9]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[5]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[10]], lIlllIIIllllll[lIlllIIlIIIIII[11]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[6]] = lllllIIIIIIIIll(lIlllIIIllllll[lIlllIIlIIIIII[12]], lIlllIIIllllll[lIlllIIlIIIIII[13]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[7]] = lllllIIIIIIIIll(lIlllIIIllllll[lIlllIIlIIIIII[14]], lIlllIIIllllll[lIlllIIlIIIIII[15]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[8]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[16]], lIlllIIIllllll[lIlllIIlIIIIII[17]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[9]] = lllllIIIIIIIIll(lIlllIIIllllll[lIlllIIlIIIIII[18]], lIlllIIIllllll[lIlllIIlIIIIII[19]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[10]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[20]], lIlllIIIllllll[lIlllIIlIIIIII[21]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[11]] = lllllIIIIIIIIll(lIlllIIIllllll[lIlllIIlIIIIII[22]], lIlllIIIllllll[lIlllIIlIIIIII[23]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[12]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[24]], lIlllIIIllllll[lIlllIIlIIIIII[25]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[13]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[26]], lIlllIIIllllll[lIlllIIlIIIIII[27]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[14]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[29]], lIlllIIIllllll[lIlllIIlIIIIII[30]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[15]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[31]], lIlllIIIllllll[lIlllIIlIIIIII[32]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[16]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[33]], lIlllIIIllllll[lIlllIIlIIIIII[34]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[17]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[35]], lIlllIIIllllll[lIlllIIlIIIIII[37]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[18]] = lllllIIIIIIIIll(lIlllIIIllllll[lIlllIIlIIIIII[40]], lIlllIIIllllll[lIlllIIlIIIIII[41]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[19]] = llllIlllllllIll(lIlllIIIllllll[lIlllIIlIIIIII[43]], lIlllIIIllllll[lIlllIIlIIIIII[44]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[20]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[46]], lIlllIIIllllll[lIlllIIlIIIIII[48]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[21]] = llllIllllllllII(lIlllIIIllllll[lIlllIIlIIIIII[50]], lIlllIIIllllll[lIlllIIlIIIIII[52]]);
    lIlllIIIllIlII[lIlllIIlIIIIII[22]] = lllllIIIIIIIIll("LjA2AR8EMDYBCwU2", "hQUdO");
    lIlllIIIllIlII[lIlllIIlIIIIII[23]] = llllIlllllllIll("8zrWhZrUgZ8=", "efGpy");
    lIlllIIIllIlII[lIlllIIlIIIIII[24]] = llllIllllllllII("naVjOI92VDqw6Ster5ImNQ==", "IEwNC");
    lIlllIIIllIlII[lIlllIIlIIIIII[25]] = llllIllllllllII("1BXz9RWBjP4=", "TXEUr");
    lIlllIIIllIlII[lIlllIIlIIIIII[26]] = lllllIIIIIIIIll("BikqCQ8m", "TLDmj");
    lIlllIIIllIlII[lIlllIIlIIIIII[27]] = llllIllllllllII("xVAOE11SGfw=", "qDrTm");
    lIlllIIIllIlII[lIlllIIlIIIIII[29]] = llllIllllllllII("9UIfwGcWZSRSv3hxnTfcug==", "LiaVJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[30]] = lllllIIIIIIIIll("", "TwFgt");
    lIlllIIIllIlII[lIlllIIlIIIIII[31]] = llllIllllllllII("Dc6t/sKNktc=", "wIRIJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[32]] = llllIlllllllIll("g/vQFUstH/E=", "GZajn");
    lIlllIIIllIlII[lIlllIIlIIIIII[33]] = lllllIIIIIIIIll("Fg4nETg=", "EcFcL");
    lIlllIIIllIlII[lIlllIIlIIIIII[34]] = llllIlllllllIll("Uop52aXqDLw=", "RFkUJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[35]] = llllIlllllllIll("DzWkF8j5E1Q=", "AEUwa");
    lIlllIIIllIlII[lIlllIIlIIIIII[37]] = llllIllllllllII("uDiOwrWxKCg=", "MzVho");
    lIlllIIIllIlII[lIlllIIlIIIIII[40]] = llllIlllllllIll("Xq/BYDCZgyrm+WrFYpzPKobyYtymNRO31C34XHsf2hg=", "Ipmgr");
    lIlllIIIllIlII[lIlllIIlIIIIII[41]] = lllllIIIIIIIIll("CTNgHjIRJicZIgsxYA8uFHgoXS5eJCEZJxAzdFl8RHZuTWY=", "dVNmF");
    lIlllIIIllIlII[lIlllIIlIIIIII[43]] = llllIlllllllIll("WyOj5Bp/yJcbWHnTSalEeuDgxXCbmAJjhPKMEI8zSJia5lZ0yFqMJ+mw50nFbT8B9mGrrGd3E1s=", "LaUzz");
    lIlllIIIllIlII[lIlllIIlIIIIII[44]] = lllllIIIIIIIIll("BB93CyQcCjAMNAYddxo4GVQ/SDhTCDwfORoOPAoSBhU1HTEHQHE0OggMOFc8CBQ+VwMdCDAWN1IgcDQ9DFUqDCUZEy0cPw5VOxAgRhxoSGBZSmlIYFlKaUhgWUppSGBZSmlcEgYVNR0xB0FjWHA=", "izYxP");
    lIlllIIIllIlII[lIlllIIlIIIIII[46]] = llllIllllllllII("brSuUIshokWYVc2BgOAoSITTMCqaubaFI0PYM0P8Hlc=", "GSRkG");
    lIlllIIIllIlII[lIlllIIlIIIIII[48]] = lllllIIIIIIIIll("GTUxeRwePiA0AxY2MXkUGSQsIwhZOTEyHFkVKyMYAykAORUSIgYlCAQkJDtLETkgOxUoZ3VmR0IPMW1DRmpld1E=", "wPEWq");
    lIlllIIIllIlII[lIlllIIlIIIIII[50]] = llllIllllllllII("04Dek/l+uc5wMZ/X8/gm4jPygfB4jidO/uG7AHX66BquXAMyvoD5hNtV7OX2Un38", "FoxQc");
    lIlllIIIllIlII[lIlllIIlIIIIII[52]] = lllllIIIIIIIIll("GwJiJTkDFyUiKRkAYjQlBkkqZiVMBC04LhMLDyQ0BRMtOndCXWx2bQ==", "vgLVM");
    lIlllIIIllIlII[lIlllIIlIIIIII[54]] = llllIllllllllII("FwA12yt3lZFFALoXWwopoBQkqb1bVITzW8+gxvqYal8=", "yzrtX");
    lIlllIIIllIlII[lIlllIIlIIIIII[56]] = llllIllllllllII("1OZ6xe0QFV39HYj0g195YXn8AiB5VtSkIUVkJxZTd1FnoL8kdKKPJrp8H98ExqaY", "IFDWE");
    lIlllIIIllIlII[lIlllIIlIIIIII[58]] = llllIlllllllIll("LXudlpHscTW5+zVIdWFW7CApZF/JU7v4uh5xldUuYYY=", "hfbBE");
    lIlllIIIllIlII[lIlllIIlIIIIII[60]] = lllllIIIIIIIIll("HTMtQwAaODwOHxIwLUMYBz81QygdIzQlDB0yYyIrNQkRLCM3bGtZV1N2eU0=", "sVYmm");
    lIlllIIIllIlII[lIlllIIlIIIIII[61]] = lllllIIIIIIIIll("JhN6EQY+Bj0WFiQRegAaO1gyUhpxEjsxBSICNwpIf0x0QlJrVg==", "KvTbr");
    lIlllIIIllIlII[lIlllIIlIIIIII[63]] = lllllIIIIIIIIll("HzQ7G1YZNCMdVjg0ORJCBTo6QFAxEWQ+QlU=", "uUMzx");
    lIlllIIIllIlII[lIlllIIlIIIIII[65]] = llllIlllllllIll("db5BcUzKLkAfANjAAbFfaX/y4wRUKmj7jzDICsTl+Smifn8ZGbLTWETHVJMNTFYsxXCHYuZSAyIIsbnyc3TDyIyF0oXcEucdV5/MKGkiqv8=", "oNRLf");
    lIlllIIIllIlII[lIlllIIlIIIIII[67]] = lllllIIIIIIIIll("IgB5IgE6FT4lESACeTMdP0sxYR11FT4lFidfZWBPb0V3cVVv", "OeWQu");
    lIlllIIIllIlII[lIlllIIlIIIIII[69]] = llllIllllllllII("fnuHYo60Z6MtsO1X9rnIpePQ5rN6rPmPAGA8JUAHkGQlxmSuxwy7EtN3xXsDu6eG", "NkDmh");
    lIlllIIIllIlII[lIlllIIlIIIIII[70]] = lllllIIIIIIIIll("HxVLHx0HAAwYDR0XSw4BAl4DXAFIAAkNChdKUVZJUlBFTA==", "rpeli");
    lIlllIIIllIlII[lIlllIIlIIIIII[72]] = llllIlllllllIll("90yQGqXJQ7U937rKfjZbtK97tRFUlg4bddoqP5Qq3cik1j0h5N07KQ==", "QZzsg");
    lIlllIIIllIlII[lIlllIIlIIIIII[74]] = llllIllllllllII("3BPhqeX2dDzfTiPijluVrwSyEw/3O2ftjAL2RyaQZSKKf+ic1cCsXajQnQLZupN/1vWn/gVqloL3vjd4GXeNT9sJXP6l8X/fNvOx+e08nrA=", "iwxQI");
    lIlllIIIllIlII[lIlllIIlIIIIII[75]] = lllllIIIIIIIIll("GhsEGGUFDhsVZTwTAQ1xER4WOCccQFo1IREME1Y+BBMeVggfFh4cKAQTHRdwWSBIWWs=", "pzryK");
    lIlllIIIllIlII[lIlllIIlIIIIII[77]] = llllIlllllllIll("7+ymJNvdpI/+KYSCTtrGoXS/7rf7cBJ4XzRxIiRdb271YuwYCLy8uQ==", "jLsvm");
    lIlllIIIllIlII[lIlllIIlIIIIII[79]] = llllIllllllllII("F/cJoKXkGwu1GhMhXnt6AO+M/EMZXN65EMOpyeV5LPYyNzz63UEMJw==", "nqIol");
    lIlllIIIllIlII[lIlllIIlIIIIII[80]] = lllllIIIIIIIIll("Bz1ZBTwfKB4CLAU/WRQgGnYRRiBQNRRMcFB4V1Zo", "jXwvH");
    lIlllIIIllIlII[lIlllIIlIIIIII[82]] = llllIllllllllII("YXS/RoVw3iNTB8/Hz957v3imsGS5XqYEP1CQuMuJRA4AvnFg+G6co6HXQSuDQHvJ", "yFDNe");
    lIlllIIIllIlII[lIlllIIlIIIIII[84]] = llllIllllllllII("UmxjtqeQZLGwwG+qRKZOPhriQVeJsQ09yGuKLxHfqbPfLH87lmHFQUhG+BSrh62AshG4fN2nnaFIB/Rko8n1vLasHniAH0Msm3V2cIsBA8eqPp8Dbz/lqGl0C3v9bLJ6sLqUEP109GQ=", "EbdWy");
    lIlllIIIllIlII[lIlllIIlIIIIII[85]] = llllIllllllllII("rwt7PoUePgRXdwRHwaVudjl0txIT2wShGNfzFGhIxSjkZdR4MQEiRT8zRAOtv+JQEo8p82y0x0eOEfPPJjf7Y4Cq14eHRAORUrAlMWHrfyPnaXRI9PZioa/8qvZtUAM6ag4J1efJVCjnL/yDp7xPBTrfwd812LJmOt/B3zXYsmb1Ij+XHW9JtyPoONV2ShQd", "fGNPm");
    lIlllIIIllIlII[lIlllIIlIIIIII[87]] = llllIlllllllIll("4h/S46dw4//ewVDCt3jhFYbL2Jto95Fz6EZUcdGKub8jhNr7Vlu8SgV7Al9FPoMqjPznAkRutl8=", "MLvzA");
    lIlllIIIllIlII[lIlllIIlIIIIII[62]] = llllIllllllllII("nNN3Pl/1z4bcqTCpm+uGbIkGx0Myd/Z8pP4tiyVUuWaf5I8aFZs0zgtECaRyLhzMwBZB1W7hrTMLG05bza/zJA6YoqlO1f6fUm8T4buPKCLP3PXFxWN6/gOgryHm3W+xn+WVodtD+hw=", "skrdT");
    lIlllIIIllIlII[lIlllIIlIIIIII[90]] = llllIllllllllII("AoevV45E3RvasmLDwqSQaV0NSAYKJ265x3/OzzXx0WAUwGLjS6nOqA2KJsD21lKz60cVTiiOdblHvbtVKDG334sFXiriltkQ", "whnyv");
    lIlllIIIllIlII[lIlllIIlIIIIII[92]] = llllIlllllllIll("to8Q6f6xbITG7m9crjWOhDmNh1YPTf1eDluomZTBdl/WfW3YS7ayoA+uAGM18ljzSekim4x3lhPva0Rh60tOgA==", "PTTuh");
    lIlllIIIllIlII[lIlllIIlIIIIII[93]] = llllIlllllllIll("9dhJDcz8H0sImzLWECb1YkDpuaG4/3WO+eYAxhaJCqBvmfqwmNmmVVXO5jhtJF7B0qQPk7JtLJFvVpAEMkSjRA==", "bqEFM");
    lIlllIIIllIlII[lIlllIIlIIIIII[95]] = llllIllllllllII("3f9lH/qfD8rmJWGzsEFKhL6tRojT7xB16w3Yn5X11TDLbCW+94aYKZqe/aZlALqmnB5ecCbAS1C62YOTSYKgqSO6ai078zY3znCnYkoLQudgI5EcJYhX3wcAgPuVHFWd", "GKsyD");
    lIlllIIIllIlII[lIlllIIlIIIIII[97]] = llllIlllllllIll("UcnBGwoq0jkB2NJiNOu8qfSLdu30RTJ3lqRhFFvmPSEYBw+dgDYoQrZpmZx4vjzco9YVtRBc4SmF3HbrYEsB2otNZXNcPn+8/bQd9INTT1Rwg3oK9PDzZlAR/qsbOOAqoVUxjauqH9W4jZ/UqOrzoFBk7DZS29By+evkrRWDMYGhVTGNq6of1biNn9So6vOgzymxvKiGjFJjhPAJXk8wht/59ZZPKi+2", "TUXWR");
    lIlllIIIllIlII[lIlllIIlIIIIII[99]] = llllIlllllllIll("KLamgNYKBfEL9FhAbCkVbfnap2qCbIm9UZa5z3+GJsAN+Lw95ey3e+EDMIbMAwE99oaVlOAJVEzrgz+vSe+6lRI0d/X5VGHcq/02JjmDWMl855QgzIC+lUp0/ztSXtdd", "TwxfM");
    lIlllIIIllIlII[lIlllIIlIIIIII[100]] = llllIlllllllIll("KGkFFyCor8q8EXZN5mEioBCJSjExnrmMAakStgj9WkTZcZL1Q5eifTDZA4iOsYkJ2ZBeYKKGEViCBeRqcxnpgI6vUquggv7qG29ZD89BOGkC/4XaiZSt4Q==", "NREhU");
    lIlllIIIllIlII[lIlllIIlIIIIII[101]] = lllllIIIIIIIIll("JysVJlY4PgorVj4+ESIZIGQgKBQhLwAzFz85WTMXASMQM0JlYy8tGTsrTDIMJCZMNAw/LwIqVw4lDysdLj4MNUN3ag==", "MJcGx");
    lIlllIIIllIlII[lIlllIIlIIIIII[102]] = llllIllllllllII("JHIUJ51gdJ2YWPgbdtDGeyjPoSpRki24Xi8MoQUR7vS3awK1q1mACbXjQg0OUQvMhJT/qIOKVUc=", "vcqoE");
    lIlllIIIllIlII[lIlllIIlIIIIII[103]] = llllIlllllllIll("35kvhJBp/vjCzptrH8TAz2uXPPpHXNI9PjCq7kKtDXKph7Tjv+Rchw==", "hbAIh");
    lIlllIIIllIlII[lIlllIIlIIIIII[104]] = lllllIIIIIIIIll("LyF/GwI3NDgcEi0jfwoeMmo3WB54Kz8NEi0wYFtMdn5xSFZiZA==", "BDQhv");
    lIlllIIIllIlII[lIlllIIlIIIIII[106]] = llllIlllllllIll("eHLhb2OiCjTz60V+/GjSUHjQN59fei4MP4zK5ft2z/Vs7DsnndpYPwZUgiamGZSPU2wccFcGALuloEAOrSHiC/t/aPeJ2oKo", "QaHMk");
    lIlllIIIllIlII[lIlllIIlIIIIII[107]] = llllIlllllllIll("pLA8xAWvvVcFe+3fR2m0IUUKgdB/XBoa4WklzqlA6IhmcaKsS6Wf+dIIlSCeVicDOuBuKCWaZ3PO+++pCNXEqkExW4dyUNP8t5pNkX3lKzSfpaucFM4eEsX1iqKAq0wFRmUk+vrAioS72d2ZNJUVSHtKK4mp/BR4zSj9Y6rzRGNZlqiDt8DVvA==", "ExXfY");
    lIlllIIIllIlII[lIlllIIlIIIIII[78]] = llllIlllllllIll("Dlx2whbirI9Qst3xeL0ObUSFKANWtEXoebClBjD+r5qyCy9z/saTEQ==", "jaHFv");
    lIlllIIIllIlII[lIlllIIlIIIIII[108]] = lllllIIIIIIIIll("LzwFaQcoNxQkGCA/BWkPLy0YMxNvHB8zAzUgPS4cKDcWBQsyPEshHy86LnZbcWhCfjUjM0tvQwdjUWc=", "AYqGj");
    lIlllIIIllIlII[lIlllIIlIIIIII[105]] = llllIllllllllII("N5ihqasVtKo2cfQrEHTcJy9BAhUJsG6irah7+iEqnq5XSiKeGFhx1w==", "uzYGw");
    lIlllIIIllIlII[lIlllIIlIIIIII[55]] = llllIlllllllIll("JfefdR9wq11nnut4kIYG69yoKZcg8xA3quyRfoDdTpLjja/0eB76o2sc7KUrJsbF", "wRiql");
    lIlllIIIllIlII[lIlllIIlIIIIII[110]] = lllllIIIIIIIIll("IgpWOxY6HxE8BiAIVioKP0EeeAp1DQotAyQ9GSYFKlVNckJvT1ho", "OoxHb");
    lIlllIIIllIlII[lIlllIIlIIIIII[111]] = llllIllllllllII("+8rII7p2tmV0tYbXGDYFCdMpzE8gk51xQI7bhrW8P8AOki/+r7Exkw==", "PXHzA");
    lIlllIIIllIlII[lIlllIIlIIIIII[112]] = llllIllllllllII("ixkxjzI3jl9xbBxrURrgmeojqvYs7CbwxMjS9zsT3TzHIu4jRWwHI0aje6VQmfupehrGMQKEb1AOBmgE/3fCQomOFLn3g5tlCbF8qBlaYROccI8xmc30JQ==", "JNCUr");
    lIlllIIIllIlII[lIlllIIlIIIIII[114]] = llllIlllllllIll("AXmzfXr1Ehi8euxRjrhob9klUK1PAlVfQxAC1xDZv4V1vK9dra6U3w==", "hEJLF");
    lIlllIIIllIlII[lIlllIIlIIIIII[115]] = llllIllllllllII("f/2A82tGaHPM5sMXfSXmZHOA66SIuhYFv3ecpZUMa9MjuWEYX764t6l05WWKkOzw", "BNmeF");
    lIlllIIIllIlII[lIlllIIlIIIIII[117]] = llllIllllllllII("6yH5b6vOYKerMZ651Y3XjN4AdsJxU4uLKVf1iePjcKf32DWWhDO8bu4I2qrbBoZEAA42diOyp2fwICwQy7vQzjEnKP+RxPO0", "ExGnh");
    lIlllIIIllIlII[lIlllIIlIIIIII[91]] = llllIlllllllIll("ZLfchNhzoQr6PACqlF7hXO2U+SUZYRGylRB6nNCnx3ho7BAjZfWvv+n4IMDTepemW4zILL+4PWU1V2CN67rveLAxoBAHt+v8", "DHTdo");
    lIlllIIIllIlII[lIlllIIlIIIIII[119]] = llllIlllllllIll("3uTwCV3VsRrrNVSoIvgc8CSQHuvX05IBYWmiLL6yI5/D6jHz5ZTO+bqMzrmdKm09TGjC/d3m064claaQAjfVcw==", "zDtpn");
    lIlllIIIllIlII[lIlllIIlIIIIII[120]] = llllIlllllllIll("BNG7DCd5wN+VIcNlbctHwzMGtRHaYKHh/4/g5A6QeS3s/nmZR7HvyQ==", "JuXWS");
    lIlllIIIllIlII[lIlllIIlIIIIII[96]] = llllIllllllllII("qSH8i+xFPDFkAEjanZx1iBTRrm2ABhaoxzR+CHnKNgSOH9Wg9BM2UQ==", "qCSxQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[113]] = lllllIIIIIIIIll("OwQ4QSg8DykMNzQHOEEgOxUlGzx7JCIbLCEYdgksMA0oMHJlUHtfGiVbflZ/dUFs", "UaLoE");
    lIlllIIIllIlII[lIlllIIlIIIIII[123]] = llllIlllllllIll("+bkK7uoY9YMzP+leXwMd6jZuHHqNjFujY+RIKVXvVnM9maVD/xJ2NLNjMZe+6bW8IOC8GpF31Y1GDwxYmyKzxRprXR9Q1c/E", "hdnkm");
    lIlllIIIllIlII[lIlllIIlIIIIII[125]] = llllIlllllllIll("RNZV9ZLdebq38Dom9PYcTJgknKEE0nfWw26jL2TfWWZcuRMRgA915b6yP5ajvuYV/gBYUIDChb7bJ/8XOY7AKw==", "lHiCH");
    lIlllIIIllIlII[lIlllIIlIIIIII[127]] = llllIlllllllIll("7sM+u+we1m/0slSJ91eEXssiDdwrxcx2quDZGr9N7H71AhR1dwsTrfLKJEJi5lq4HvTApNZwgkKGTg1KP3FtYA==", "AyaTW");
    lIlllIIIllIlII[lIlllIIlIIIIII[129]] = llllIllllllllII("jyx3U7UJ6PZ0mbywHlBj3FTsOpcaFrm+Y4dkbXX+Alz4E3+hCOhGpFUSEPHaBpUjFUOfLGKmhqg=", "HZnqJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[59]] = llllIlllllllIll("HHCYHBojj6zmKqByEUNzHhhQd7aka+7WUzGsxLVSMxmrv5f9pDGqP4dv+7yvlHf7JTKMN3xZPqIyImf3FD4p6IIqPsORq4yEa/h56Z9HPGxRXRoaDrLZCg==", "SCkmv");
    lIlllIIIllIlII[lIlllIIlIIIIII[132]] = lllllIIIIIIIIll("PAMMWSk7CB0UNjMADBErIAEdWSc+Dx0ZMHwDDhIqJkgqEio2AwogKyAKHDslIRI9ASE8EkIQISY2GQUwOwcUIy0xDQtNbHsgQldk", "RfxwD");
    lIlllIIIllIlII[lIlllIIlIIIIII[83]] = llllIlllllllIll("7UewucZBcVZvZdeQMT+IrIu2kWJ0CXhs0FfqLXB/cfj2/ryDkxw2i58OxqVF64MkONiAN1qgsVI51ZXJFvWFFC9/p1UqijAKlOUabG5j2X1RCxtnzQ2WKOhKE84SsBkr3rMkmua4ugx4qj80+u1ldqZIv0bqllUY", "ZWDQh");
    lIlllIIIllIlII[lIlllIIlIIIIII[134]] = llllIlllllllIll("Ezrq2fn7wMYaCwbb7Sqfusi5nulOu+llOelt03QNOwtkDOLLEZ920Bqq2/wtLgfk5rxUctjQ+QtcCy+aq+5L9GeA+aT05stT", "FteUX");
    lIlllIIIllIlII[lIlllIIlIIIIII[136]] = lllllIIIIIIIIll("FQ9NASUNGgoGNRcNTRA5CEQFQjlCGQYGCBkdIhw1KAMXETlCQiU0eC5QQw==", "xjcrQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[137]] = lllllIIIIIIIIll("FyBqMQIPNS02EhUiaiAeCmsich5AISsRARMxJypMTn9kYlY=", "zEDBv");
    lIlllIIIllIlII[lIlllIIlIIIIII[138]] = llllIllllllllII("q+cKYtDmGif71OODGqvREbSY2zT6MuXVX9SCKwV1HONZRyaE2plQuLtMQsx5jBh5syT2lBUOuzM=", "YiXwT");
    lIlllIIIllIlII[lIlllIIlIIIIII[139]] = lllllIIIIIIIIll("OSYZST0+LQgEIjYlGUkzOyoICSR5DgQJNTQxDAEkbSUYCTMIdFxTYWccFV14fg8DAiR4LgQJNTQxDAEkeCABDjU5N0IqOTkmDhUxMTdWXXA=", "WCmgP");
    lIlllIIIllIlII[lIlllIIlIIIIII[122]] = lllllIIIIIIIIll("FyhdGgQPPRodFBUqXQsYCmMVUEocPxoMHh4AEgcRHSgBU0FNd1NJUA==", "zMsip");
    lIlllIIIllIlII[lIlllIIlIIIIII[141]] = llllIlllllllIll("N3zWf8dUBAi/TFd0YhwT7hraSVQi/ZcE87BM+UcSnlFxw3EiAg8ot1OSw5g9e26iPePGShDevf5Wnu6mlxpG4FcExmH4utrAISdGzwjpNT9qeN2ZZA3PyQ==", "lQsNm");
    lIlllIIIllIlII[lIlllIIlIIIIII[143]] = llllIlllllllIll("q+N1+vSr0nvGUYDQhtvfOY/4/5l8ltqygkI9SnAY5tk8cO8erYma33Yrfpn8Vf2In3+U7DUflq+szFwCP9aMnfeigdqyKqWw3a3Em+ImHkAA/20V6xNkEg==", "KnJGA");
    lIlllIIIllIlII[lIlllIIlIIIIII[144]] = lllllIIIIIIIIll("CCMSfzkPKAMyJgcgEn89CC8SfxYKKQU6J1wgDzQ4AhlXZGRVc1YONVx3Xmt0RmZG", "fFfQT");
    lIlllIIIllIlII[lIlllIIlIIIIII[145]] = llllIllllllllII("Gt/L34h23OJ3scGCbHNXV47sZtGpmByS50zeQwaALPbYKzalc61OOQ==", "KaTDl");
    lIlllIIIllIlII[lIlllIIlIIIIII[147]] = llllIllllllllII("+ygTcwkKfRGkuCJvwNEavjkg9Dmh/FY61bh7RERAQGsR4FFmkvccZ/8xNZGpbSRr9bybIymQ8jy5HQRmnQ6cD0GlTm9zMMqfidGwaNcHiyeCk3kqaKKsfypTyW5aIYCB", "bXDMY");
    lIlllIIIllIlII[lIlllIIlIIIIII[109]] = llllIlllllllIll("00z0lHFvuUcUsRIYhLLlAsLWALjLnpRNwoCMMTpXzwU3zLWr7n0PwvX8eHIonJ8NXgKhlqOpfdKErnbUFH/vAK//uYZitk/7", "VJIAP");
    lIlllIIIllIlII[lIlllIIlIIIIII[149]] = llllIlllllllIll("h3yjvPC4olNwFz5xKBlggwu9fRup7j/TSR4HElB8+o0ivvBFsTMAzL8f/Zf+o5ZqyYd/U0+YoKrpY7J+/kuthKxSt9iKIFmU8IG0qZvmYOo=", "bvsCw");
    lIlllIIIllIlII[lIlllIIlIIIIII[47]] = lllllIIIIIIIIll("OxYHeCo8HRY1NTQVB3gkORoWODN7ARY4IzABFiRpMB0HPzMsXSEzKTEWARsmOxIUMzVvFRozKzEsRG5wZ0UsNX1nQkl2Z3U=", "UssVG");
    lIlllIIIllIlII[lIlllIIlIIIIII[151]] = llllIllllllllII("JntO7SSh0AkhKI0DpgEeKfUgWopxYG4TWk+4M9Grq8fio8zR6P2mnQ==", "llKxQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[118]] = llllIllllllllII("iPfip8u53nZKsHXfc0Ni6aHN6AjaoJj1Wh/+8V+j9yac+C7S1KSVw7J2PSn+rWSjTzBlAb3NhlU=", "QCdnd");
    lIlllIIIllIlII[lIlllIIlIIIIII[94]] = llllIlllllllIll("/ArjjnfXq2/ug2siern5pIpANrDlk4no0zvL5/UFmWb0A5pffnRMYge89OnOHyQsR76N3Y66GxbRiFjULQ3bzd5sB/9UcI7tHnS5ytP5obYemlSS+U93mzBgTEtJcvfn", "QSDHz");
    lIlllIIIllIlII[lIlllIIlIIIIII[51]] = llllIlllllllIll("tPv8M+CZHUAT//lmT15lQb8S1p3qFw/n4gP1bfL+eC+66KjuM5uD62lVNUERsbKKGJvKir8/dVuIo8+S+woTTA==", "oEoZp");
    lIlllIIIllIlII[lIlllIIlIIIIII[155]] = llllIlllllllIll("TfXKeGAD2PEbHDtZdPeK8HcmimdcqgXePhO+FG9vFjXfV0UC4GnFgcyzKsXmm6tFLYbrnraz024TiWJrzTfKNA==", "KYCsa");
    lIlllIIIllIlII[lIlllIIlIIIIII[156]] = llllIllllllllII("/sQhBvmFjBsDV2Xo6uItKuTZv+t/HpcMKMymSMSQgS3ZLm/N1eSSoA==", "oPRmn");
    lIlllIIIllIlII[lIlllIIlIIIIII[148]] = llllIllllllllII("T25+5Lf4GU4ZjaTkuNgUDf3yVBBiV8Euh24wkoJ7LMxCn3VUT+uHinwl7rCMAG1BcVbLeirEzha0fzy9piZUHR7onauZdv3LcNsiOM4cj34=", "dnPUP");
    lIlllIIIllIlII[lIlllIIlIIIIII[71]] = llllIllllllllII("bh+EAbHDSN1jXUkKOsuVImGfcFhMQ1h5nhOygbsWtp9iOFF9nyDGOw==", "ZUrRm");
    lIlllIIIllIlII[lIlllIIlIIIIII[157]] = lllllIIIIIIIIll("Nj8EXAoxNBURFTk8BFwENDMVHBN2Px4GDiwjXjcJLDMECzc0OwkXFQsKShQOPTYULVBoa0ZHOCxgQkNdeHpQ", "XZprg");
    lIlllIIIllIlII[lIlllIIlIIIIII[126]] = llllIllllllllII("lMrbnPJjrEiNYYWPmSFwJmOFtau6l6ZTDHhiYDynQ6YGXFf47pKOVpW18q1bGqCB", "nQIim");
    lIlllIIIllIlII[lIlllIIlIIIIII[158]] = llllIllllllllII("XCUlQ5PRsPuJNQJaW1PnQVGR5+y+f29H3UF/62cxcd86sac7kbm3LZrD0lWMTs4C", "BQafB");
    lIlllIIIllIlII[lIlllIIlIIIIII[152]] = llllIllllllllII("iW9AzPoCHpNoogi6Py647s3K7ygGNgYJi46lSUpQEurSeD/pvUpfRgmm8u3W2WHGAjW7WYtkj208xIewxqEKU7TGgrEgfBqA", "hnmDM");
    lIlllIIIllIlII[lIlllIIlIIIIII[86]] = llllIllllllllII("8kFzn+Egr/XRJm7BeSzFN/dA0NonqiweLQMHZsGB8D/gkW+U/RPRCA==", "nJcdN");
    lIlllIIIllIlII[lIlllIIlIIIIII[160]] = lllllIIIIIIIIll("NS1FNictOAIxNzcvRSc7KGYNdTtiKwQpPCpyXH9zeGhLZQ==", "XHkES");
    lIlllIIIllIlII[lIlllIIlIIIIII[162]] = llllIlllllllIll("qYSDaQwmZy/4xXXCr2a7zUQO611RSDGussLVEBsORR8Glt/mSLGkyqvSrrBbLd3bT/VpaP31BAHUyXyMxTRpoA==", "zUxKh");
    lIlllIIIllIlII[lIlllIIlIIIIII[76]] = llllIlllllllIll("xIfbvtpJ2kESs4WibXuFNmMyeiy1PnTxD9JiFCVlqX4bjVVZypPOP5AKf8CBHiIOWBIQwdB9TbZzdemRuoIHT8gWEYvsgAs5UIhr+ehjPSHEPA4lahgK6A==", "RUODX");
    lIlllIIIllIlII[lIlllIIlIIIIII[164]] = lllllIIIIIIIIll("CzJhOAcTJyY/FwkwYSkbFnkpextcMCMJGgo7LSQSFDMLIgASNiEoFjU0LicWAm1nDTUgGyEuB0k6JiUWBSUuLQdJMiE/GhIuYDsfBy4qOVwjOTsiBx8HIyoKAyV0DVowbW8=", "fWOKs");
    lIlllIIIllIlII[lIlllIIlIIIIII[163]] = llllIllllllllII("EBBYOpsS13Uqw+Dtk43UuIMa1UwwpwKEuIRRCrwVdbE7+jzhq0IAGQ==", "hNbxx");
    lIlllIIIllIlII[lIlllIIlIIIIII[165]] = lllllIIIIIIIIll("Py4wWyI4JSEWPTAtMFsqPz8tATZ/IjAQIn8OKgEmJTIBGys0OQcHNiI/JRl1NyIhGSsOfHREeWIUMU99YHFkVW8=", "QKDuO");
    lIlllIIIllIlII[lIlllIIlIIIIII[166]] = llllIlllllllIll("tkb8ff9viuliTGQsMY+kYul21TnflTzPgkaxl3v8l77Q9hDgh7kmMQ==", "IEcsr");
    lIlllIIIllIlII[lIlllIIlIIIIII[167]] = llllIlllllllIll("z4I7wjwuaJa+SdhKLKBJ2MBajo8sDDUowPMg4SO3RiCw34DRoIIB/IiKNN0l3vsq+owJBpSBfzmbEs43MMXbsq9sdWrrwe/e", "goDXM");
    lIlllIIIllIlII[lIlllIIlIIIIII[64]] = llllIllllllllII("Emv0fNMR4+2GThLjxpFHZyB/l36f4AIh0NMvyhKHaOyHESXy4na+YdD/HVwegSzbkspyko2CLIutQBnSmWwIn00zLn5zfn/vHUpc+XpennA=", "sCMMC");
    lIlllIIIllIlII[lIlllIIlIIIIII[168]] = llllIllllllllII("hfRMKfQMyTYpMIw4poFBKIIDohGDEdhrGvXhIEXkoVNGA9LLjI+E4A==", "uoJaL");
    lIlllIIIllIlII[lIlllIIlIIIIII[169]] = lllllIIIIIIIIll("OzYtahk8PTwnBjQ1LWoXOTo8KgB7HjAqETYhOCIAbzUwIRgxDG51QGFiBiFOZGdjZFR1", "USYDt");
    lIlllIIIllIlII[lIlllIIlIIIIII[170]] = llllIllllllllII("AhZ5dBDXZ7lH8LW78BrYSZGNVHguJ8xQkZRiODmOwRb8YpgyeTFdAA==", "KoRsy");
    lIlllIIIllIlII[lIlllIIlIIIIII[171]] = llllIllllllllII("ktsAtf2AIPK4cabX/FaR/x2PB1cLXrmLshSxbSI/reR9gup+mgRcauLHr0qZ9LItWQxOwezA63OWAaZaf/BY6Va0g66PXx3y7ke1H7eHOTrSkVk1GPfINq5uBqF11u2B", "efqoD");
    lIlllIIIllIlII[lIlllIIlIIIIII[172]] = llllIllllllllII("HqIJoLg/Lrt8BU+wiHGRfuE7l756KhnXScWmHnGMdAQMP2ZpNEeDgobs5Dx/2iLR3TsWDBqGbwUVe6smvNwRcEFeEkKs2coM", "bHkGC");
    lIlllIIIllIlII[lIlllIIlIIIIII[174]] = llllIlllllllIll("9JrISI/EXXccEh4gBC8Owdpk+XYzhxzXfHt56VYx4xqrcykzlqIX38ELTMUPX3vD", "VjhZi");
    lIlllIIIllIlII[lIlllIIlIIIIII[176]] = llllIllllllllII("hQU+0bkK1FHpqjzTZ1/zv4edADbgGLW4I8ccj4ta25SHoDJWhsEf+W9IhSDnQNmHzKolRVnPqsm/lDMgWEYpcg==", "CuHne");
    lIlllIIIllIlII[lIlllIIlIIIIII[177]] = lllllIIIIIIIIll("KQNWKRsxFhEuCysBVjgHNEgea190VkhqX3RWSGpfdFZIal90VkhqSwYJFzYKJQhCPQowMBk2GiFcUHM1fkZY", "DfxZo");
    lIlllIIIllIlII[lIlllIIlIIIIII[150]] = lllllIIIIIIIIll("HCt6CxwEPj0MDB4pehoAAWAySABLPjgZCxR0YEJIUW4=", "qNTxh");
    lIlllIIIllIlII[lIlllIIlIIIIII[178]] = lllllIIIIIIIIll("GDZ6NhYAIz0xBho0eicKBX0ydQpPITErBhAhESsWT2Jtf0JVc3Rl", "uSTEb");
    lIlllIIIllIlII[lIlllIIlIIIIII[89]] = llllIlllllllIll("WBH8X5veN3B0AXif2gRf1fcwoTpbD0ienWaaFrXv2398JBz6e+4YBNUMOz0nrUgd2fTUjzYaBD33bHk5lEU24A==", "JAHKH");
    lIlllIIIllIlII[lIlllIIlIIIIII[180]] = llllIlllllllIll("afrIakaLdn80kr6i8kvY2akpB2rJJ978q9sVL1/AZ/+ak1FMG4lIds0z1cqYYjMqPlWAFc3YC1A7IK2QadRU/EeoL5ugH5ftCDRLoL4+D8qEYTPq7z1u/LRMvJ/pBNyW", "MOBCW");
    lIlllIIIllIlII[lIlllIIlIIIIII[181]] = llllIlllllllIll("IsaDi2SAbCRAupyKDoquU8JDecTLPxCQulz4unGXh/JX8MQETh3VyQ==", "HJvID");
    lIlllIIIllIlII[lIlllIIlIIIIII[161]] = lllllIIIIIIIIll("GAQiRAgfDzMJFxcHIkQQAgg6RAgXFT5EJxoONQE1GRJsDBAYAglbUkFYY1I6GFt+QyxMQXY=", "vaVje");
    lIlllIIIllIlII[lIlllIIlIIIIII[182]] = llllIllllllllII("Mu16aghFzXCk4xR/vtce2rGZVQuqT2A441cGNaj1JV7eaFuwpL2hKIrBdBqirjQmra/nzDLzFkg=", "DsqLY");
    lIlllIIIllIlII[lIlllIIlIIIIII[184]] = llllIlllllllIll("xj+hcip4OudnIjD1+9qpc5JnTEM2ZcKCMu6DgDiQw661Clsk8b+Irrc60ElgfZvsZy9fSuz1puSzTXy8fYSj/Q==", "SiFum");
    lIlllIIIllIlII[lIlllIIlIIIIII[159]] = llllIlllllllIll("WtANswLrcIhTL/9p153JFS1gELWPqVV2SUsbFvvC3d7dVkcgVYbbF1Ux6iXHZBRSBtpmgMH7e48Atmw/da5DfjjUok9Z4rsHWsdAvoe8bNQ=", "igDbA");
    lIlllIIIllIlII[lIlllIIlIIIIII[49]] = lllllIIIIIIIIll("AhI/SRkFGS4EBg0RP0kXAB4uCQBCOiIJEQ8FKgEAVhEiAhgIKHxWQFtDFB5OXkBxR1RM", "lwKgt");
    lIlllIIIllIlII[lIlllIIlIIIIII[154]] = llllIllllllllII("b1NcW463APlLUpN0Le26jKCZbWHFUcHtsDcinwI4r99ZyzuMwywCtoZZDyFgvKxRZKbIUn9Wlbo=", "nNRzz");
    lIlllIIIllIlII[lIlllIIlIIIIII[42]] = lllllIIIIIIIIll("KCh3ADgwPTAHKCoqdxEkNWM/QyR/Px0SISQqPEl4f215Uw==", "EMYsL");
    lIlllIIIllIlII[lIlllIIlIIIIII[88]] = llllIllllllllII("0vIAmiOzZ9oQawALol1L36KLbcDvtSKT112GSYD2bSMtv8EOFMYpcXQJgma8wP3JldLOa74qCuE208O2nUzabCy+KZIvJmIZvI4J3wJiMaHk9BCZb3AvhRHcFNL0gGa9", "SYYgi");
    lIlllIIIllIlII[lIlllIIlIIIIII[186]] = llllIlllllllIll("CQKqOedE0gtNyQaPayE5WfzltjJpqC5kI4IxMVcczTObUPrPX3eH4hcOCdGm1LKr0nuZICy6neI=", "hGUDl");
    lIlllIIIllIlII[lIlllIIlIIIIII[128]] = llllIllllllllII("h/Yo9oElDbXibMYrSa6vbfE1yokRzc8NbZHWT+wzQFJ6WAdj4CaENg==", "nWXRM");
    lIlllIIIllIlII[lIlllIIlIIIIII[121]] = llllIllllllllII("qG+mWem+jZ0CIuk2JFCJtg+9DAaFrHtQNEWEbihVr3MFGHIbdsYuaYbk5rKUUO49l0fsmRKpc7I=", "LpftB");
    lIlllIIIllIlII[lIlllIIlIIIIII[142]] = llllIlllllllIll("9aY+jXCLrsyYCf5o+9nKyzA4x3v7KayIM2x7ast7IDlBz98c6G5BzA==", "EmoZc");
    lIlllIIIllIlII[lIlllIIlIIIIII[133]] = llllIllllllllII("LJITFCay4J4W2XD5mYZzh98edjEbiaFgeXiEdAoS+/tx64VkZOhyMzurIrTaP11+/ptNBu0/YaDSaisT1UxyVA+PSfRgB0EpRR9X1ORoPJDh8faEUtwmIKhp4YpnTzkh", "UzoFZ");
    lIlllIIIllIlII[lIlllIIlIIIIII[173]] = llllIlllllllIll("9iu4g35djG+LJuCTuttfOvSCzKOkPbM99jTOWRdbigIxxe6NbNukhA==", "LyloT");
    lIlllIIIllIlII[lIlllIIlIIIIII[190]] = llllIllllllllII("qEiuWr2V4jd+PqSiLP50BtN6Emgrntbki5NJ7/ts6FlBFr+HbMHcsHgbl9Jfya2btg1H1kU+Z+FImK46aZW855Qz1U4wHFImkY+F2K6xjPVnjYLeeffkumeNgt559+S6uPUJE08dukre/xZGWiSekw==", "CGCVK");
    lIlllIIIllIlII[lIlllIIlIIIIII[191]] = lllllIIIIIIIIll("Pw5AGgEnGwcdET0MQAsdIkUIWR1oBAAMET0fX1pPZlFOSVU=", "Rkniu");
    lIlllIIIllIlII[lIlllIIlIIIIII[124]] = lllllIIIIIIIIll("LAIuSAgrCT8FFyMBLkgALBMzEhxsFzYHHCcVdCMLNg4uHzUuBiMDF3gBLwgGHVZrVlR2XwUHX2orNAMRbQozCAAhFTsAEW0CNBIMNh51BwxtBi4SFysFLxIAMUgTJxE2FTMEEDYCYU8pLAIuSQgrCT8FFyMBLkkALBMzEhxtBjNJBDYTKA8HNxM/FUoLJi4SFysFLxIACwkpEgQsBD9dX2JH", "BgZfe");
    lIlllIIIllIlII[lIlllIIlIIIIII[116]] = lllllIIIIIIIIll("FDddIhAMIholABY1XTMMCXwVYQxDNwshCBY2FmtQQ3JTcQ==", "yRsQd");
    lIlllIIIllIlII[lIlllIIlIIIIII[192]] = lllllIIIIIIIIll("FiszViMRICIbPBkoM1YtFCciFjpWPCIWKh08IgpgPyIUDC8MKwoZIBkpIgp0HjspGxFJeX5JfEkRAUJmURh9WA==", "xNGxN");
    lIlllIIIllIlII[lIlllIIlIIIIII[185]] = llllIllllllllII("LIJNbCsHFPChimQL04uMqLs+HI4+XzVdyOWvr30IL30ob7kUVgpc9I0MWExJd7Swoh2R1Xmdixc=", "DYDRr");
    lIlllIIIllIlII[lIlllIIlIIIIII[188]] = llllIlllllllIll("M5SfEkP5LPBNn/KydD2TgWcaxaickLI9MM89nEj6R2/EW51rWGTDF7q0GrnT8cHe", "UdgGA");
    lIlllIIIllIlII[lIlllIIlIIIIII[194]] = llllIlllllllIll("rWn8lOKBn4KarydtDanUwL7sRgl3lXKdKXeuj2yGhu6BVt46Po/Gxen1yJKlStGC68iobdCI9tG7UdYwinpA0rgmBzdY0InXwn58ehv1eKmoob65j2gK5Upc76+M+EUaZeKDAD9p2LU=", "QXaZS");
    lIlllIIIllIlII[lIlllIIlIIIIII[195]] = llllIllllllllII("ScV1EVqfz93GgZscKEHIFrbZZ2dnaTxWh7UIAF4fvYZ0Q53HGZSZSQ==", "YgYZv");
    lIlllIIIllIlII[lIlllIIlIIIIII[183]] = llllIllllllllII("OLVzlYAozoEwfLcSfJtu0yC/WkIf0gV90IP9umcmOdCtyEC4kdFfy9hm/GiLrs0SuegnD98Lp2k=", "TYvre");
    lIlllIIIllIlII[lIlllIIlIIIIII[73]] = lllllIIIIIIIIll("DTM+ajoKOC8nJQIwPmo0Dz8vKiNNMyQwPhcvZAE5Fz8+PQcPNzMhJTAGcCIiDTUVc2dTZXgbM1l+BioyF3knLTkGNTglMRd5LyojCiIzaxINIiMwLlh/DH53Qw==", "cVJDW");
    lIlllIIIllIlII[lIlllIIlIIIIII[130]] = llllIllllllllII("Hm10zsNbA6i5tqDxNwVOTiHNr7lLFD6+ZKr9NEJCbjqVo+wI7qkYUowr0rt2+i8VCdYBo/7fUxTqnHSVLizfCTQWeU/jqc5TXq67UAPhaM4J1gGj/t9TFACXQuyyOEcKPuiMDesmLP2GltN43rGst5cGZFmV68eF", "xDBgS");
    lIlllIIIllIlII[lIlllIIlIIIIII[57]] = llllIlllllllIll("RU8tNCQe3/hGglRlvOQbe3wlVT7lmZ28GFeNDrHW9xg8Fd7Nbro600nkmDuheyvGM3QRz5KxN8JAxBRXm5l8jw==", "YsuRp");
    lIlllIIIllIlII[lIlllIIlIIIIII[199]] = llllIllllllllII("yvq2w0aDhXj+kHxhjsYsxLuLiRUe+iLeDcdAbkrSAGzGV78R5Lu+CQ==", "FPVNw");
    lIlllIIIllIlII[lIlllIIlIIIIII[201]] = llllIllllllllII("vbSk76qtEDwGckOiuh1rHdEy6YlFCC9BlkAKpLIN7h8H8TzvfRc+wA==", "TczIf");
    lIlllIIIllIlII[lIlllIIlIIIIII[202]] = llllIlllllllIll("g/WKpjQvqxb2Z2a3dnL/FpOlmqBuBGXR0sTXbRdtG3Bxcfvf3hiVOcDm6rdn+8r81z/B7qYs/zC4nth7yOKXqxZnP48why4Aa3zoKjwY9jk=", "bVQiS");
    lIlllIIIllIlII[lIlllIIlIIIIII[203]] = llllIlllllllIll("IeI4IqZetS7/YR8roaEF7W+BCIlz/dgmTVGIF5Qm6UU41AmUDDMWaLgdF6HA/lL8y0UkFKuWAFigYsRSTrx/b9mjl7XWoZzF", "SexIQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[204]] = lllllIIIIIIIIll("IQclWj4mDDQXIS4EJVo2IRY4ACphEj0VKioQfzE9OwslDQMjAygRIXUEJBowEFNpQGJ2UQ4VFnVKeDg5LhQwWz8uDDZbGjsHIxUxIwdqTnNv", "ObQtS");
    lIlllIIIllIlII[lIlllIIlIIIIII[205]] = llllIllllllllII("87mw37bCDKe5uAMmpnhYExROQyRxOoYrA0R9A99ccHbYpcOufWwRPju1YDZGTeWub0B+oU/Vkwo=", "wryFB");
    lIlllIIIllIlII[lIlllIIlIIIIII[39]] = llllIlllllllIll("PzwuxYx/zh78OccWpgc27FljPe7OxKefjuc10OHZM2iemIdFSRnOvbpGAZ4LkBm1eJ8BQcOwDT8=", "TBnIQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[81]] = lllllIIIIIIIIll("LBVjBAM0ACQDEy4XYxUfMV4rRx97HSwPJCQcKzMaJkp4TVdhUG1X", "ApMww");
    lIlllIIIllIlII[lIlllIIlIIIIII[45]] = lllllIIIIIIIIll("HQEVbTgaCgQgJxICFW02Hw0ELSFdAQ83PAcdTwY7Bw0VOgUfBRgmJyA0WyUgHQc+cmRDVVVwChIuW2t8NV5BYw==", "sdaCU");
    lIlllIIIllIlII[lIlllIIlIIIIII[140]] = llllIlllllllIll("9O+QFwjaYNdiL1Q4/QpNzvJOncqQWIQyTxbjO6bga1FnZVS6R5k1UQ==", "Lglxw");
    lIlllIIIllIlII[lIlllIIlIIIIII[206]] = lllllIIIIIIIIll("JBIjA0U7BzwORQIaJhZRJwcwEAo6HCdYQ2c/PwMdL1wgFgIiXBwWDjwSIQ0ZdUl1Qg==", "NsUbk");
    lIlllIIIllIlII[lIlllIIlIIIIII[179]] = lllllIIIIIIIIll("IBUXSiAnHgYHPy8WF0ouIhkGCjlgAgYKKSsCBhZjCRwwECw6FS4FIy8XBhZ3KAUNBxJ/R1pVf3gvCV5lZyZZRA==", "NpcdM");
    lIlllIIIllIlII[lIlllIIlIIIIII[207]] = llllIlllllllIll("i6zlG0NFrvXr9ANnLua2kLexRZVMU84CnWGIL5nI1wKzXaZGgGQC3Sb3d6+b3T5d", "USZnN");
    lIlllIIIllIlII[lIlllIIlIIIIII[208]] = llllIlllllllIll("03h8NhoAGoO1fdjfu75gobSe1lGfesbW1F1cVNxGsqWGP1SGJhKkBmC/IryORsBm4WAN/5J3k24LOsPLjPQ1IqvesDnMK2Fi", "fbWjD");
    lIlllIIIllIlII[lIlllIIlIIIIII[198]] = llllIlllllllIll("zlgqBlx8L5RIFfc+vwCc74gIeWn73AGv2Mo1+uLReQU0xTNj/ciHcRD2BmL4b9SL", "bzgED");
    lIlllIIIllIlII[lIlllIIlIIIIII[66]] = llllIllllllllII("5gzngHFjMeU1oXKBzJnipHezOtsHe4jqxeX1dNJxUn52OWmMo4LGJFXQYYz/neYt0Dux5K3cGu59iZ6XEdHlIA==", "iDDJK");
    lIlllIIIllIlII[lIlllIIlIIIIII[209]] = llllIllllllllII("72y+pEvw/vq4e5GoU1UayxSiXaqqZC+t6+vvee/j3yTsS2SantZNPA==", "RdKyX");
    lIlllIIIllIlII[lIlllIIlIIIIII[210]] = lllllIIIIIIIIll("FCs4YyQTICkuOxsoOGMqFicpIz1UAyUjLBk8LSs9QCglKCUeEXt8fUx4Ez1zSHt2bWla", "zNLMI");
    lIlllIIIllIlII[lIlllIIlIIIIII[197]] = llllIlllllllIll("MmGTuGd0E7VvLNQ0D+elMlshZFEikpqWZnyOe8qQB/YmoRmODVS0jM+ZNnLIfqC8", "ENLnB");
    lIlllIIIllIlII[lIlllIIlIIIIII[175]] = llllIllllllllII("IEH/F69t4J9+2zjxdcAPnXU0MXKkHKDnVTTfaqpx57D0wC/yGeh56zgz9sIk5vOP4+yE2P5graeRiA7C0wKRKDTNGHfrN0ay", "iDyKf");
    lIlllIIIllIlII[lIlllIIlIIIIII[53]] = llllIlllllllIll("+8NtFhtn9Jyok0aGT+xGQKYuwhbdkmH0wlt1aMVkqr3kqsXczifdGOMN2JOD0H5Z", "zUEoS");
    lIlllIIIllIlII[lIlllIIlIIIIII[211]] = llllIlllllllIll("VC3h/8nKL9uMKBKlo39kpYVmJUP50JtBe67aEVjBMNdrddF4KWD+tuS3/SWUgstFs55n9uFzZ0cHCsJPspReeZd0YHJ08C5TADUAMqzc0K8=", "tGSaS");
    lIlllIIIllIlII[lIlllIIlIIIIII[212]] = lllllIIIIIIIIll("JTZPBT09IwgCLSc0TxQhOH0HRiFyMRMTKCMXBBooMWlUTGloc0FW", "HSavI");
    lIlllIIIllIlII[lIlllIIlIIIIII[213]] = llllIlllllllIll("KWRrVWzPJDQBs5KlY3HDfhoCspLKbsQCDh1/wEH3958mC1qPaPcTWPydwLwThkadguldy4ugHkq1dbyLg6UCYrZTSB8qXuXp1vBx+kIQGBZIvBwUvipEEXG9Kt3tHDIvzdqDuuFQAsC1dbyLg6UCYrZTSB8qXuXp1vBx+kIQGBZIvBwUvipEEXG9Kt3tHDIvcQqux2HPW27wpmLm8JHGeg==", "RIqpo");
    lIlllIIIllIlII[lIlllIIlIIIIII[135]] = llllIlllllllIll("eiTeZn1nQLRlxwcj3FzoMa5IW6t9RQ89rVnvZH9c24xVpp+Q/jqpYB4hMGS9tyPG/Pxgt/RvKW5/3awVlHHnBQnNW+uYgCM6y42yksV0EaLHJ31tHoqGcQ==", "pFQtU");
    lIlllIIIllIlII[lIlllIIlIIIIII[214]] = lllllIIIIIIIIll("CSUuL28PJTYpby4lLCZ7AjcxIHtLAHEKe0M=", "cDXNA");
    lIlllIIIllIlII[lIlllIIlIIIIII[68]] = llllIlllllllIll("p6wfcFUmSSenluIE4ggHSMN80rbV62reUqsDLHnZywOSzYCaN8t59mt7mPyhToz5iBIVlxZjAaQMn98mn4F0qqkzZREZ0dpN", "nsCsV");
    lIlllIIIllIlII[lIlllIIlIIIIII[215]] = llllIllllllllII("hDzd7cZzsYe7UBVKyTqphSfY6vqmjp8bP+pD+1DrBN7t4+RIG1t7Vg==", "dVPND");
    lIlllIIIllIlII[lIlllIIlIIIIII[189]] = llllIllllllllII("VCrKapqQ+hfVE052e4le4Slfp09BNa9GdmuYf7/WYy6RGh8HE0KnUAuYmnXcgd4CJbJLflPObsHuoW+IvdHAQyVv7oW9gXIW4LOcxs+OjvXtHi57AGYhsLRZ8KegUOFZ4Saf8v4o8ON0tPJJwQMQiB20S/iKUxET", "dOrdH");
    lIlllIIIllIlII[lIlllIIlIIIIII[153]] = llllIlllllllIll("RezOieppPutQ42liRWDmFpS2GFym/Tqvcv3wEMkmC4InSJhwC95bGT2r0LixaSqj", "EqxuE");
    lIlllIIIllIlII[lIlllIIlIIIIII[200]] = llllIllllllllII("9oyf8ClUyoJKGDdukvbQWG26MtTNdlyQyseLh3Ii3vyTeuepKGgQzgt9ST7H6Zb80Ioe75rQaM0SgIt5/bQOf0hF32zrLgUwNPaIBj2h8rGPhV9JYdsMRQ==", "cRqPQ");
    lIlllIIIllIlII[lIlllIIlIIIIII[98]] = llllIllllllllII("54lcXE5HpGOHfTGxZq4b5BkCXLh7eqSrfdbojnTg8x+1aYoQvzxcRzdQZwsVgjcDHyHnpVh5lLwVitCA9rj6PkrrQgCqG52u", "omkui");
    lIlllIIIllIlII[lIlllIIlIIIIII[216]] = llllIllllllllII("9+kUFbNxdb+GrN3Q3stKt5wXWKSJdjOsjakniGSXx6fpoaK6nkXPxSpgYXQvrpJYzuf2rldfJjBnV4fhHQj0G1jA3cw089hm", "WJRwU");
    lIlllIIIllIlII[lIlllIIlIIIIII[217]] = llllIllllllllII("Z8Siq+fsiumRhXg4kjUhfH1KJYkYfXr48oXDVGa6uXR6p52JtnYauA==", "gwIGq");
    lIlllIIIllIlII[lIlllIIlIIIIII[218]] = llllIllllllllII("easwtmTDkc1K9kA4wpTbIWD2tkwdxk3R2eK7D3CwJLe5E9pXHPZV4g==", "DRIjy");
    lIlllIIIllIlII[lIlllIIlIIIIII[146]] = llllIllllllllII("NLjLd1xDtHwlv6ez3Xpo/Swj5P89aLG8GUtDwJdZ1EyN3XKCXozA4w==", "YYYKz");
    lIlllIIIllIlII[lIlllIIlIIIIII[193]] = llllIllllllllII("FBgkP55ULjhMwXgQCNT8XmcOBuH5+BXPGAdab8zIWP+iVrhJDKNYsbfmZZq6UOhcaKohSzeI0DHMTLTPtGp5/g==", "MHTDJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[187]] = llllIllllllllII("ozbRqF9Tv21Lw7iaLjSmiWEkEhnVoWCuxM6hao8B0TCBuMuzQAiCd6WGcQ5ralfJw4myvIBI7KM=", "WwWyb");
    lIlllIIIllIlII[lIlllIIlIIIIII[131]] = llllIlllllllIll("bxVcdVfHzt0tDO8ClfnObV+CbOVpSoYDgXoQrksOwr9shK0C/weUR2Srf+dQ2fM54fS8DshUrEk=", "iRIuJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[196]] = lllllIIIIIIIIll("PwdcMhwnEhs1DD0FXCMAIkwUcQBoMh4gCzcGMTMRIRYTLRtoUEhhSHJCUg==", "RbrAh");
    lIlllIIIllIlII[lIlllIIlIIIIII[219]] = llllIllllllllII("pfysxFlUMO/UrO70DSCkTPHXJ925ZZmaKlUtnlRgwLfCU2VzJ9FF8KnYaQsVwIJVt20rIreevilxDUq1lmHWk1Bk1zV6xugz", "nECoa");
    lIlllIIIllIlII[lIlllIIlIIIIII[38]] = llllIllllllllII("5IeGugciuZaGMnZtsSGO5bmxCNQG1qc2o2+X7IgirL25/9TItC6XDc/iEyoDXTppjVQ/+TAudqGI/hzbjtlhOw==", "JbZFU");
    lIlllIIIllIlII[lIlllIIlIIIIII[220]] = lllllIIIIIIIIll("FxMgQRQQGDEMCxgQIEEaFR8xAQ1XEzobEA0PeioXDR8gFikVFy0KCyombgkMFxULWElJQmMwHENefSlDWVY=", "yvToy");
    lIlllIIIllIlII[lIlllIIlIIIIII[221]] = llllIlllllllIll("JOlDKdiPVmQw7naUWpIGs7ItF9xOIRwFELau9Eqg2g2FLODMjdFSxRvwy74Y56Y2", "oBJAu");
    lIlllIIIllIlII[lIlllIIlIIIIII[222]] = llllIllllllllII("M+cRRKPUmESTmJucKzd9zkHtEfeyOuMMaD7lSNWN8JiVDkegC+aKaA==", "AADyl");
    lIlllIIIllIlII[lIlllIIlIIIIII[223]] = lllllIIIIIIIIll("GS5eAgIBOxkFEhssXhMeBGUWQEZEe0BBRkR7QEFGRHtAQUZEe0BBUjAkBRMaEXEXFAIiKhwEE05jWTVMVGs=", "tKpqv");
    lIlllIIIllIlII[lIlllIIlIIIIII[224]] = llllIlllllllIll("lkQMpFyK+y5cL3N97rR3O9PpWLtCFC4RLW09+EhvphohuTmAXasfcFAt1y7c8I71M6HOjH+r9+t4WEaP8QPKd81zZzGqCvOw", "XcvhY");
    lIlllIIIllIlII[lIlllIIlIIIIII[225]] = llllIlllllllIll("b0OIsxHf9u0mqRPFPh0L9xdw7pqdEG2uQ8+nbfqkyF2KmTtZ4KM+AQ==", "bUAQS");
    lIlllIIIllIlII[lIlllIIlIIIIII[226]] = lllllIIIIIIIIll("KTAmSS4uOzcEMSYzJkkmKSE7EzppJT4GOiInfC4tMTA8Eyw1LAILIj4wIF0lLjA+AxxwZWZRchg2aFZwfXVyRw==", "GURgC");
    lIlllIIIllIlII[lIlllIIlIIIIII[227]] = llllIllllllllII("yDvVXiovleOTGcmeo+M75HtWz2vRPC97E84Iy6sZTLbRxkpsLTTXdWZbX9sAw93wRwI2GxEp1wkmkWCf1jyabw==", "PVihE");
    lIlllIIIllIlII[lIlllIIlIIIIII[228]] = llllIllllllllII("jefrd8PXA++RZ7LYf6auG+OVcaMF71vYekTbFd7CbLit3l1TcMz4Ww==", "MFqJs");
    lIlllIIIllIlII[lIlllIIlIIIIII[229]] = llllIlllllllIll("dYE4hqYjm0CLkocL902PV5hj/nlmKTDeSJCEVgm7z8Rq9NcZEea+Ll2clxYrlC/Nf2V0RoKHMOsGOYY7CEhNGQ==", "InGok");
    lIlllIIIllIlII[lIlllIIlIIIIII[230]] = llllIlllllllIll("974jgGVBiIBSbMsmq4miS8sM6lQwWk1ZTQfHC5JQyGsWhoGsSWS7j+oOIdEbWtFoGVnH/DqJZJLhZqK1kNnYJw==", "DjDxJ");
    lIlllIIIllIlII[lIlllIIlIIIIII[231]] = lllllIIIIIIIIll("LDN5Axo0Jj4ECi4xeRIGMXgxQF97MTIELC0jMkpGaB9tUE4=", "AVWpn");
    lIlllIIIllIlII[lIlllIIlIIIIII[232]] = lllllIIIIIIIIll("GxBjODUDBSQ/JRkSYykpBlsreylMFiwnIgMZLD8kOhoiIAACT2UPBTI5Iy41WRgkJSQVBywtNVkQIz8oAgxiOy0XDCg5bjMbOSI1DyUhKjgTB3ZiGjJPbQ==", "vuMKA");
    lIlllIIIllIlII[lIlllIIlIIIIII[233]] = lllllIIIIIIIIll("CDMxawoPOCAmFQcwMWsECj8gKxNIMysxDhIvawAJEj8xPDcKNzwgFTUGfyMOAzohGlBWZ3JyOBxsd3NdRnZl", "fVEEg");
    lIlllIIIllIlII[lIlllIIlIIIIII[234]] = llllIlllllllIll("Q20FII57zW7LDXCBsJzP0tsrbCl1vECumc3DpL0VYUxIDs0NRkkJP52COUFhC3jukV5QjZGOc6LfU3R7b/qFow9VWf3QHOyyjYjcXILNQe2scTI+ujN+pA==", "Tvpaz");
    lIlllIIIllIlII[lIlllIIlIIIIII[235]] = lllllIIIIIIIIll("AjIAAmsEMhgEayUyAgt/CScXDXdSezInbCxpVg==", "hSvcE");
    lIlllIIIllIlII[lIlllIIlIIIIII[236]] = llllIllllllllII("UrFGyb8Xxy5kMFIxXBVllv/OFNa2+4j4lkhL1lZcah6qjS417nCGzZ9UQEI++le+T9lKwefjLasI/3j2Lvh84lmezB86MYGq", "MYmGN");
    lIlllIIIllIlII[lIlllIIlIIIIII[237]] = llllIllllllllII("sFpJKSBmkBrLHPnAtXPk910uBRK4UrtEYCSNUYTdQ0ZiQHwuFIRoDwEB/kJ4/4dwq9SkMPeF6fjo9H6zh08eRwmREuJ8LgV6fc8v1tf0myw=", "xzpbb");
    lIlllIIIllIlII[lIlllIIlIIIIII[238]] = llllIllllllllII("rTPCSqPkRe8Vo4rNKgIlQTjx5+AEy02besRsoH9lB4lGz/q+Zn0W+Q==", "tchRV");
    lIlllIIIllIlII[lIlllIIlIIIIII[239]] = llllIlllllllIll("Krq6tTuYuQQPB23dKV12O6KpR9pNThQt8FJBJDMOMH/j7jOAJpiH5ONpjv3jxLf77RaVQ+63e8HQFxrZSn3E1I3uyfU2jRSL0MHpGfJNu0zjaY7948S3+7LkFpoZvDSBSANQyAF1MSDvSCLbIiZOQU/unpr+Dpet", "sdoKv");
    lIlllIIIllIlII[lIlllIIlIIIIII[240]] = lllllIIIIIIIIll("JSIjVBwiKTIZAyohI1QSJy4yFAVlKiIWBSI3OxsILjV5LR45KzM5HSIiOQ5LLTI5GS58dW9NQxQmbVI9ISYhG14nJjkdXggrNgkCcAs5HwVkKj4UFCg1NhwFZDIjEx1kKjYOGWQGLxMCCis+HR8uIxU4SmILPRsHKmgiDhgnaBsTAj98bVpR", "KGWzq");
    lIlllIIIllIlII[lIlllIIlIIIIII[241]] = llllIllllllllII("wiZxK7KF/tS6akMUxuC4h0lX/LaoTGCY19wKNXKFeSK9TIWyvvZEIvrq9V8xL2tphcDLyNFHF2vpaDwEiVkgDcHc381JulunI17e4Xcwd1o9D8Lj24V0dksrg+FQCoxa", "SlHFb");
    lIlllIIIllIlII[lIlllIIlIIIIII[242]] = llllIlllllllIll("WuQVtyu2p2m5my5/OqGNuo/wbh30GG27q7oCV58cjQMcQKVxwq0BykFv2+P9fi1ELQx0Bfq0ss1dYb0780n/I+c3Z7JGYy+jNu6AyEwcalFgZ2+9/jzgYRdUoj+5bLGy9Sm+Efcw4mw=", "PfNvA");
    lIlllIIIllIlII[lIlllIIlIIIIII[243]] = llllIllllllllII("bhHMNyeS0HHtOqZw+ztywRE6NzgTOZ9as2ompAhGWwNDLWz6m64Ufw==", "pVOwx");
    lIlllIIIllIlII[lIlllIIlIIIIII[244]] = llllIllllllllII("EowkJeLQmRDSMUQrPmmGq64XG0qTPb8PwxvWMKToOcTX9D+gbsgQTwX0d2dssv8/pQJ3hDxo5dEtNEnkynmfsnVMC0EahmmcAaUxl/YIP55feTUSTomF3LRXk0VHP0TPLJr+qLSIXmzzmSXWladKoZgPWRIj3+LCHu3GQtK99Kp2SalTV7VV+omsxlw+6l1o", "wwetC");
    lIlllIIIllIlII[lIlllIIlIIIIII[245]] = lllllIIIIIIIIll("NhQRSyYxHwAGOTkXEUs+LBgJSwU3HysQJzQ9DBY/YhYAEXFwOEwpITkHBEonOR8CSgQ6GwAGP2NLRUU=", "XqeeK");
    lIlllIIIllIlII[lIlllIIlIIIIII[246]] = llllIlllllllIll("zL2i9+Gx2dhcKTnApK1wPY5ANaf+iktLZUMl9e8igtRc3fb2QuXCkw7+o97IIbNWNYRGBHWygdOE+XUuJIkT2q+fxQsSd5HG", "Wskoy");
    lIlllIIIllIlII[lIlllIIlIIIIII[247]] = lllllIIIIIIIIll("KxYidwEsHTM6HiQVIncJKwc/LRVrNjgtBTEKGjAaLB0xGw02Fmw/GSsQCW5cc0ZuBg0KSX5wJX9Tdg==", "EsVYl");
    lIlllIIIllIlII[lIlllIIlIIIIII[248]] = llllIllllllllII("OEnoYaa1DRYFb3WffGedSzJCFAN1hjCdCqdw6KZbi9cTlMoOkAZf2NW5B675RJQc", "pQXMD");
    lIlllIIIllIlII[lIlllIIlIIIIII[249]] = lllllIIIIIIIIll("FRF0JA0NBDMjHRcTdDURCFo8Z0hCEz8jPgoRPzlDUF0TbVlY", "xtZWy");
    lIlllIIIllIlII[lIlllIIlIIIIII[250]] = llllIlllllllIll("+0DmgiLf//k2+4oMYRIqQmVJvmZCi/1l0rah9zFOWlYWLArBPdUqnJMeu4a8S3l8xFghCl5BRNdEZlz/At1tcB6cK/xCEvLrNTv2JiOX7Bk=", "AXTpR");
    lIlllIIIllIlII[lIlllIIlIIIIII[251]] = llllIlllllllIll("pIKXNfgjEcdHDDVleVSTveFsvyy66CAhPtIrTlDu/5dYqZ4z73KPkuuPNbro+pRgu1n1y0iVwbQ=", "kyxfn");
    lIlllIIIllIlII[lIlllIIlIIIIII[252]] = llllIllllllllII("3oRpRpSzOzLHv/r/JPBBxgDIRGAlZEvsg1ei5wZlH6EYWgfzRGBpuw==", "yecXK");
    lIlllIIIllIlII[lIlllIIlIIIIII[253]] = llllIlllllllIll("7BemnM3SWy9krPEIQgkyrY1CT7B9p4N0FmOCCKlfxd0ON3SkDXlilA==", "avRpL");
    lIlllIIIllIlII[lIlllIIlIIIIII[254]] = lllllIIIIIIIIll("ODcyeiY/PCM3OTc0MnouOCYvIDJ4FyggIiIrfDI+ODEZY3tmYXQLL2x6CjouIn0rPSUzMTQ1LSJ9Izo/PyY/ew44Ji8gMm17AG5rdg==", "VRFTK");
    lIlllIIIllllll = null;
  }
  
  private static void lllllIIIIIllllI() {
    String str = (new Exception()).getStackTrace()[lIlllIIlIIIIII[0]].getFileName();
    lIlllIIIllllll = str.substring(str.indexOf("ä") + lIlllIIlIIIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllllllllII(String lllllllllllllllIlllIlllIIIllllII, String lllllllllllllllIlllIlllIIIlllIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIIIllllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIIIlllIll.getBytes(StandardCharsets.UTF_8)), lIlllIIlIIIIII[8]), "DES");
      Cipher lllllllllllllllIlllIlllIIIlllllI = Cipher.getInstance("DES");
      lllllllllllllllIlllIlllIIIlllllI.init(lIlllIIlIIIIII[2], lllllllllllllllIlllIlllIIIllllll);
      return new String(lllllllllllllllIlllIlllIIIlllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIIIllllIl) {
      lllllllllllllllIlllIlllIIIllllIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIIIIIIIll(String lllllllllllllllIlllIlllIIIlllIIl, String lllllllllllllllIlllIlllIIIlllIII) {
    lllllllllllllllIlllIlllIIIlllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIlllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlllIIIllIlll = new StringBuilder();
    char[] lllllllllllllllIlllIlllIIIllIllI = lllllllllllllllIlllIlllIIIlllIII.toCharArray();
    int lllllllllllllllIlllIlllIIIllIlIl = lIlllIIlIIIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIlllIIIlllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIlIIIIII[0];
    while (lllllIIIIlIlIlI(j, i)) {
      char lllllllllllllllIlllIlllIIIlllIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlllIIIllIlIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() == ("   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlllIIIllIlll);
  }
  
  private static String llllIlllllllIll(String lllllllllllllllIlllIlllIIIllIIIl, String lllllllllllllllIlllIlllIIIllIIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlllIIIllIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIIIllIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllIIIllIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllIIIllIIll.init(lIlllIIlIIIIII[2], lllllllllllllllIlllIlllIIIllIlII);
      return new String(lllllllllllllllIlllIlllIIIllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIIIllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlllIIIllIIlI) {
      lllllllllllllllIlllIlllIIIllIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIIIlIIlII() {
    lIlllIIlIIIIII = new int[256];
    lIlllIIlIIIIII[0] = "   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ -" ".length());
    lIlllIIlIIIIII[1] = " ".length();
    lIlllIIlIIIIII[2] = " ".length() << " ".length();
    lIlllIIlIIIIII[3] = "   ".length();
    lIlllIIlIIIIII[4] = " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[5] = 0x68 ^ 0x6D;
    lIlllIIlIIIIII[6] = "   ".length() << " ".length();
    lIlllIIlIIIIII[7] = 0x96 ^ 0xBF ^ (0xAA ^ 0xBD) << " ".length();
    lIlllIIlIIIIII[8] = " ".length() << "   ".length();
    lIlllIIlIIIIII[9] = 0x14 ^ 0x1D;
    lIlllIIlIIIIII[10] = (0xA4 ^ 0xA1) << " ".length();
    lIlllIIlIIIIII[11] = 0x65 ^ 0x6A ^ " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[12] = "   ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[13] = (0x32 ^ 0x3F) << " ".length() ^ 0x4F ^ 0x58;
    lIlllIIlIIIIII[14] = ((0x69 ^ 0x62) << " ".length() << " ".length() << " ".length() ^ 118 + 13 - 46 + 98) << " ".length();
    lIlllIIlIIIIII[15] = (0x4A ^ 0x4D) << " ".length() << " ".length() << " ".length() ^ 58 + 70 - 111 + 110;
    lIlllIIlIIIIII[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[17] = 0xBA ^ 0xAB;
    lIlllIIlIIIIII[18] = (0x28 ^ 0x53 ^ (0x5D ^ 0x64) << " ".length()) << " ".length();
    lIlllIIlIIIIII[19] = 0x5D ^ 0x4E;
    lIlllIIlIIIIII[20] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0x5C ^ 0x49) << " ".length() << " ".length();
    lIlllIIlIIIIII[21] = 0x6C ^ 0x79;
    lIlllIIlIIIIII[22] = ((0x7 ^ 0x8) << " ".length() ^ 0xA1 ^ 0xB4) << " ".length();
    lIlllIIlIIIIII[23] = 0x94 ^ 0x83;
    lIlllIIlIIIIII[24] = "   ".length() << "   ".length();
    lIlllIIlIIIIII[25] = (0x8A ^ 0x9B) << "   ".length() ^ 136 + 41 - 174 + 142;
    lIlllIIlIIIIII[26] = (0x6D ^ 0x60) << " ".length();
    lIlllIIlIIIIII[27] = (0xBD ^ 0xB2) << "   ".length() ^ 0x72 ^ 0x11;
    lIlllIIlIIIIII[28] = 38 + 183 - 103 + 105 + ((0x72 ^ 0x19) << " ".length()) - ((0x83 ^ 0x8E) << (0x49 ^ 0x4C)) + ((0xE4 ^ 0x91) << " ".length());
    lIlllIIlIIIIII[29] = (0x26 ^ 0x21) << " ".length() << " ".length();
    lIlllIIlIIIIII[30] = 0x62 ^ 0x7F;
    lIlllIIlIIIIII[31] = (0xB8 ^ 0xB7) << " ".length();
    lIlllIIlIIIIII[32] = 162 + 128 - 230 + 109 ^ (0x9E ^ 0xC5) << " ".length();
    lIlllIIlIIIIII[33] = " ".length() << (0x2E ^ 0x53 ^ (0x69 ^ 0x66) << "   ".length());
    lIlllIIlIIIIII[34] = (0x87 ^ 0x92) << "   ".length() ^ 79 + 98 - 53 + 13;
    lIlllIIlIIIIII[35] = (0xB3 ^ 0xA2) << " ".length();
    lIlllIIlIIIIII[36] = -((217344 + 614475 - 378897 + 838285 << " ".length()) + (142334 + 788327 - 486570 + 735780 << " ".length() << " ".length()) - (209423 + 372979 - -149998 + 40055 << " ".length() << " ".length()) + (33813 + 106618 - 93978 + 126088 << "   ".length()));
    lIlllIIlIIIIII[37] = 0x33 ^ 0x10;
    lIlllIIlIIIIII[38] = ((0xE ^ 0x41) << " ".length()) + 45 + 8 - -60 + 98 - 60 + 98 - 85 + 186 + (0xC6 ^ 0xAD);
    lIlllIIlIIIIII[39] = (0x53 ^ 0x8) << " ".length();
    lIlllIIlIIIIII[40] = ((0x73 ^ 0x78) << " ".length() << " ".length() ^ 0x95 ^ 0xB0) << " ".length() << " ".length();
    lIlllIIlIIIIII[41] = 0xB2 ^ 0x97;
    lIlllIIlIIIIII[42] = 111 + 145 - 174 + 73;
    lIlllIIlIIIIII[43] = (0x89 ^ 0x9A) << " ".length();
    lIlllIIlIIIIII[44] = 0x3D ^ 0x1A;
    lIlllIIlIIIIII[45] = ((0x75 ^ 0x6E) << " ".length() << " ".length() ^ 0xE1 ^ 0x9A) << "   ".length();
    lIlllIIlIIIIII[46] = (0x8B ^ 0xA4 ^ (0x2D ^ 0x38) << " ".length()) << "   ".length();
    lIlllIIlIIIIII[47] = 0xD3 ^ 0xA2;
    lIlllIIlIIIIII[48] = (0xFF ^ 0xC2) << " ".length() ^ 0x96 ^ 0xC5;
    lIlllIIlIIIIII[49] = 73 + 64 - 32 + 48;
    lIlllIIlIIIIII[50] = (0x23 ^ 0x36) << " ".length();
    lIlllIIlIIIIII[51] = 0x88 ^ 0xA1 ^ (0x3C ^ 0x2B) << " ".length() << " ".length();
    lIlllIIlIIIIII[52] = (0x13 ^ 0x16) << " ".length() ^ 0x76 ^ 0x57;
    lIlllIIlIIIIII[53] = ((0xA3 ^ 0xA6) << " ".length() ^ 0x51 ^ 0x6A) << " ".length() << " ".length();
    lIlllIIlIIIIII[54] = (0x2D ^ 0x26) << " ".length() << " ".length();
    lIlllIIlIIIIII[55] = (0x42 ^ 0x23) << " ".length() ^ 120 + 79 - 150 + 98;
    lIlllIIlIIIIII[56] = (0x53 ^ 0x58) << "   ".length() ^ 0x6 ^ 0x73;
    lIlllIIlIIIIII[57] = 62 + 33 - -37 + 13 + ((0xD7 ^ 0xC0) << " ".length()) - (0x52 ^ 0x67) + (0x62 ^ 0x47);
    lIlllIIlIIIIII[58] = (14 + 120 - 123 + 158 ^ (0x47 ^ 0x18) << " ".length()) << " ".length();
    lIlllIIlIIIIII[59] = (0x8 ^ 0x71) << " ".length() ^ 104 + 33 - 126 + 136;
    lIlllIIlIIIIII[60] = "   ".length() << (0xAB ^ 0xAE) ^ 0xFE ^ 0xB1;
    lIlllIIlIIIIII[61] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[62] = " ".length() << "   ".length() << " ".length();
    lIlllIIlIIIIII[63] = 0xC6 ^ 0xAD ^ (0xEA ^ 0xC7) << " ".length();
    lIlllIIlIIIIII[64] = 35 + 40 - -48 + 12;
    lIlllIIlIIIIII[65] = (0x6E ^ 0x77) << " ".length();
    lIlllIIlIIIIII[66] = ((0x2F ^ 0x22) << " ".length()) + (0x2D ^ 0x12) - -(0xFC ^ 0xBF) + (0xB8 ^ 0x9B);
    lIlllIIlIIIIII[67] = (0xB9 ^ 0xA6) << " ".length() << " ".length() ^ 0x40 ^ 0xF;
    lIlllIIlIIIIII[68] = (0x55 ^ 0x6A ^ (0xEA ^ 0xC7) << " ".length()) << " ".length();
    lIlllIIlIIIIII[69] = ((0x38 ^ 0x6B) << " ".length() ^ 102 + 39 - 19 + 49) << " ".length() << " ".length();
    lIlllIIlIIIIII[70] = 0x96 ^ 0xA3;
    lIlllIIlIIIIII[71] = 0x12 ^ 0x6B;
    lIlllIIlIIIIII[72] = (0x79 ^ 0x62) << " ".length();
    lIlllIIlIIIIII[73] = (0x54 ^ 0xD) + (0x1C ^ 0x9) - -(0x8A ^ 0x85) + ("   ".length() << " ".length() << " ".length() << " ".length());
    lIlllIIlIIIIII[74] = 0x12 ^ 0xD ^ (0x22 ^ 0x27) << "   ".length();
    lIlllIIlIIIIII[75] = ((0x6C ^ 0x31) << " ".length() ^ 163 + 73 - 157 + 110) << "   ".length();
    lIlllIIlIIIIII[76] = ((0x5 ^ 0x2) << " ".length() << " ".length()) + (0x6 ^ 0x45) - ((0x6F ^ 0x6A) << "   ".length()) + ((0x3D ^ 0x18) << " ".length());
    lIlllIIlIIIIII[77] = (0x29 ^ 0x1E) << " ".length() ^ 0xCE ^ 0x99;
    lIlllIIlIIIIII[78] = (46 + 41 - 79 + 151 ^ (0x98 ^ 0x8F) << "   ".length()) << " ".length();
    lIlllIIlIIIIII[79] = ((0xD4 ^ 0xC7) << "   ".length() ^ 96 + 115 - 161 + 83) << " ".length();
    lIlllIIlIIIIII[80] = 0x52 ^ 0x69;
    lIlllIIlIIIIII[81] = 139 + 25 - -13 + 6;
    lIlllIIlIIIIII[82] = (0x6B ^ 0x26 ^ (0x35 ^ 0x14) << " ".length()) << " ".length() << " ".length();
    lIlllIIlIIIIII[83] = (0x35 ^ 0x38) << " ".length() << " ".length() << " ".length() ^ 92 + 63 - 128 + 152;
    lIlllIIlIIIIII[84] = 0x32 ^ 0x6D ^ (0x6 ^ 0x37) << " ".length();
    lIlllIIlIIIIII[85] = (149 + 128 - 86 + 30 ^ (0x6 ^ 0x67) << " ".length()) << " ".length();
    lIlllIIlIIIIII[86] = ((0x5B ^ 0x4E) << " ".length() ^ 0x3C ^ 0x29) << " ".length();
    lIlllIIlIIIIII[87] = 0x32 ^ 0xD;
    lIlllIIlIIIIII[88] = (0x46 ^ 0x61) << " ".length() << " ".length();
    lIlllIIlIIIIII[89] = (0xCE ^ 0x87) << " ".length();
    lIlllIIlIIIIII[90] = 0x26 ^ 0x67;
    lIlllIIlIIIIII[91] = (0x2A ^ 0x21) << "   ".length();
    lIlllIIlIIIIII[92] = (0x89 ^ 0xA8) << " ".length();
    lIlllIIlIIIIII[93] = (0x64 ^ 0x79) << " ".length() << " ".length() ^ 0x5 ^ 0x32;
    lIlllIIlIIIIII[94] = (0x84 ^ 0x99) << " ".length() << " ".length();
    lIlllIIlIIIIII[95] = (0x3C ^ 0x2D) << " ".length() << " ".length();
    lIlllIIlIIIIII[96] = 33 + 159 - 162 + 199 ^ (0x3F ^ 0x60) << " ".length();
    lIlllIIlIIIIII[97] = 0x64 ^ 0x25 ^ " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[98] = 48 + 15 - -25 + 119;
    lIlllIIlIIIIII[99] = (0x35 ^ 0x16) << " ".length();
    lIlllIIlIIIIII[100] = 0xE4 ^ 0xA3;
    lIlllIIlIIIIII[101] = (0x9D ^ 0x94) << "   ".length();
    lIlllIIlIIIIII[102] = 0x63 ^ 0x2A;
    lIlllIIlIIIIII[103] = (0x29 ^ 0xC) << " ".length();
    lIlllIIlIIIIII[104] = 0x20 ^ 0x6B;
    lIlllIIlIIIIII[105] = (0x9F ^ 0x9A) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[106] = (0xB3 ^ 0xA0) << " ".length() << " ".length();
    lIlllIIlIIIIII[107] = 0x10 ^ 0x5D;
    lIlllIIlIIIIII[108] = 0x74 ^ 0x3B;
    lIlllIIlIIIIII[109] = 0x71 ^ 0x1E;
    lIlllIIlIIIIII[110] = (0xA4 ^ 0x8D) << " ".length();
    lIlllIIlIIIIII[111] = 0x10 ^ 0x43;
    lIlllIIlIIIIII[112] = (0xB6 ^ 0xA3) << " ".length() << " ".length();
    lIlllIIlIIIIII[113] = (0x53 ^ 0x54 ^ " ".length() << " ".length() << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIlIIIIII[114] = (0xA ^ 0x3F) << " ".length() << " ".length() ^ 122 + 10 - 65 + 62;
    lIlllIIlIIIIII[115] = (0xE8 ^ 0xC3) << " ".length();
    lIlllIIlIIIIII[116] = ((0x6A ^ 0x5F) << " ".length() << " ".length() ^ 101 + 106 - 199 + 127) << " ".length();
    lIlllIIlIIIIII[117] = 0xE1 ^ 0xB6;
    lIlllIIlIIIIII[118] = 0x6A ^ 0xB ^ (0xAA ^ 0xA3) << " ".length();
    lIlllIIlIIIIII[119] = (0x22 ^ 0x2F) << " ".length() << " ".length() ^ 0xDC ^ 0xB1;
    lIlllIIlIIIIII[120] = ((0x1E ^ 0x3B) << " ".length() ^ 0x52 ^ 0x35) << " ".length();
    lIlllIIlIIIIII[121] = 66 + 150 - 145 + 88;
    lIlllIIlIIIIII[122] = 0x3A ^ 0x53;
    lIlllIIlIIIIII[123] = 0xDB ^ 0x86;
    lIlllIIlIIIIII[124] = 0 + 75 - -71 + 19;
    lIlllIIlIIIIII[125] = (0x32 ^ 0x1D) << " ".length();
    lIlllIIlIIIIII[126] = 0xCD ^ 0xB6;
    lIlllIIlIIIIII[127] = 0x74 ^ 0x59 ^ (0x61 ^ 0x58) << " ".length();
    lIlllIIlIIIIII[128] = (189 + 112 - 92 + 32 ^ (0x22 ^ 0x7D) << " ".length()) << " ".length();
    lIlllIIlIIIIII[129] = "   ".length() << (0x33 ^ 0x36);
    lIlllIIlIIIIII[130] = (0xE ^ 0x59) << " ".length();
    lIlllIIlIIIIII[131] = (0x13 ^ 0x62 ^ (0x3B ^ 0x36) << " ".length()) << " ".length();
    lIlllIIlIIIIII[132] = (0x3F ^ 0xE) << " ".length();
    lIlllIIlIIIIII[133] = 112 + 101 - 211 + 159;
    lIlllIIlIIIIII[134] = (0x7E ^ 0x67) << " ".length() << " ".length();
    lIlllIIlIIIIII[135] = (0xDB ^ 0xC2) << "   ".length();
    lIlllIIlIIIIII[136] = (0x96 ^ 0x83) << " ".length() ^ 0x61 ^ 0x2E;
    lIlllIIlIIIIII[137] = ((0x7F ^ 0x68) << " ".length() ^ 0xB5 ^ 0xA8) << " ".length();
    lIlllIIlIIIIII[138] = (0x83 ^ 0xB6) << " ".length() << " ".length() ^ 69 + 157 - 172 + 125;
    lIlllIIlIIIIII[139] = (26 + 72 - 42 + 107 ^ (0xDC ^ 0x8B) << " ".length()) << "   ".length();
    lIlllIIlIIIIII[140] = 69 + 59 - 69 + 106 + (0xFB ^ 0x9A) - ((0x62 ^ 0x4B) << " ".length() << " ".length()) + (0xDC ^ 0x8B);
    lIlllIIlIIIIII[141] = (0x7A ^ 0x4F) << " ".length();
    lIlllIIlIIIIII[142] = (0x1E ^ 0x1B) << (0xF ^ 0xA);
    lIlllIIlIIIIII[143] = 0x2C ^ 0x47;
    lIlllIIlIIIIII[144] = (0x6F ^ 0x5A ^ (0x98 ^ 0x8F) << " ".length()) << " ".length() << " ".length();
    lIlllIIlIIIIII[145] = 0x6E ^ 0x3;
    lIlllIIlIIIIII[146] = (0x5B ^ 0x6C) + 59 + 104 - 14 + 30 - (0xFB ^ 0xB6) + ((0x42 ^ 0x59) << " ".length());
    lIlllIIlIIIIII[147] = ((0x7B ^ 0x7E) << " ".length() ^ 0x40 ^ 0x7D) << " ".length();
    lIlllIIlIIIIII[148] = (0x49 ^ 0x46) << "   ".length();
    lIlllIIlIIIIII[149] = ((0x61 ^ 0x2E) << " ".length() ^ 91 + 99 - 171 + 134) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[150] = ((0xBA ^ 0xB1) << "   ".length() ^ 0xE7 ^ 0xB6) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[151] = ((0xE ^ 0x51) << " ".length() ^ 77 + 104 - 73 + 27) << " ".length();
    lIlllIIlIIIIII[152] = 0x62 ^ 0x1F;
    lIlllIIlIIIIII[153] = ((0xEC ^ 0xB9) << " ".length()) + ((0x47 ^ 0x64) << " ".length() << " ".length()) - ((0x21 ^ 0x3E) << " ".length() << " ".length()) + (0x31 ^ 0x22);
    lIlllIIlIIIIII[154] = (0x38 ^ 0x75) << " ".length();
    lIlllIIlIIIIII[155] = ("   ".length() ^ (0x25 ^ 0x22) << "   ".length()) << " ".length();
    lIlllIIlIIIIII[156] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0x7D ^ 0x3A;
    lIlllIIlIIIIII[157] = (0x26 ^ 0x1B) << " ".length();
    lIlllIIlIIIIII[158] = (0x7F ^ 0x60) << " ".length() << " ".length();
    lIlllIIlIIIIII[159] = (0x62 ^ 0x1B ^ (0x74 ^ 0x41) << " ".length()) << "   ".length();
    lIlllIIlIIIIII[160] = 7 + 104 - 28 + 44;
    lIlllIIlIIIIII[161] = 127 + 138 - 256 + 140;
    lIlllIIlIIIIII[162] = " ".length() << (0x71 ^ 0x3C ^ (0xAC ^ 0x89) << " ".length());
    lIlllIIlIIIIII[163] = ((0x54 ^ 0x15) << " ".length()) + ((0xBD ^ 0x86) << " ".length()) - ((0xD6 ^ 0xA5) << " ".length()) + (0x5B ^ 0x2A);
    lIlllIIlIIIIII[164] = (0x21 ^ 0x60) << " ".length();
    lIlllIIlIIIIII[165] = (0x98 ^ 0xB9) << " ".length() << " ".length();
    lIlllIIlIIIIII[166] = 118 + 26 - 50 + 39;
    lIlllIIlIIIIII[167] = (0xF1 ^ 0xB2) << " ".length();
    lIlllIIlIIIIII[168] = (0xAC ^ 0x81 ^ (0xC ^ 0x3) << " ".length() << " ".length()) << "   ".length();
    lIlllIIlIIIIII[169] = (0xCB ^ 0xB8) + (" ".length() << (0xA2 ^ 0xA7)) - (0x7C ^ 0x5B) + (0x34 ^ 0x29);
    lIlllIIlIIIIII[170] = ((0x62 ^ 0x73) << " ".length() << " ".length() ^ " ".length()) << " ".length();
    lIlllIIlIIIIII[171] = ((0x1C ^ 0x2D) << " ".length()) + ((0x97 ^ 0x9A) << " ".length() << " ".length()) - ((0x1A ^ 0x5) << " ".length() << " ".length()) + (0x51 ^ 0x20);
    lIlllIIlIIIIII[172] = (0x8F ^ 0xAC) << " ".length() << " ".length();
    lIlllIIlIIIIII[173] = (0x3D ^ 0x6C) << " ".length();
    lIlllIIlIIIIII[174] = ("   ".length() << " ".length() << " ".length() << " ".length()) + ((0x5C ^ 0x4D) << " ".length() << " ".length()) - (0x8B ^ 0xC4) + ((0x9 ^ 0x4) << "   ".length());
    lIlllIIlIIIIII[175] = 84 + 108 - 54 + 57;
    lIlllIIlIIIIII[176] = (0xE2 ^ 0xA5) << " ".length();
    lIlllIIlIIIIII[177] = 69 + 8 - 57 + 123;
    lIlllIIlIIIIII[178] = 70 + 32 - 28 + 71;
    lIlllIIlIIIIII[179] = 125 + 128 - 241 + 175;
    lIlllIIlIIIIII[180] = (0x4C ^ 0x15) + ((0x45 ^ 0x5E) << " ".length()) - ((0x11 ^ 0x8) << " ".length()) + ((0x2C ^ 0x37) << " ".length());
    lIlllIIlIIIIII[181] = ("   ".length() ^ (0x2B ^ 0x38) << " ".length()) << " ".length() << " ".length();
    lIlllIIlIIIIII[182] = (0xCF ^ 0x84) << " ".length();
    lIlllIIlIIIIII[183] = (" ".length() << "   ".length() << " ".length() ^ 0xFF ^ 0x94) << " ".length() << " ".length();
    lIlllIIlIIIIII[184] = ("   ".length() << " ".length()) + ((0x50 ^ 0x19) << " ".length()) - (0x7 ^ 0x2C) + ((0xD4 ^ 0xC1) << " ".length());
    lIlllIIlIIIIII[185] = (0x26 ^ 0x33) << "   ".length();
    lIlllIIlIIIIII[186] = 125 + 109 - 80 + 3;
    lIlllIIlIIIIII[187] = ((0x3C ^ 0xD) << " ".length() << " ".length()) + ((0x2A ^ 0x2F) << " ".length() << " ".length() << " ".length()) - ((0xC6 ^ 0x8B) << " ".length()) + (0x1A ^ 0x41);
    lIlllIIlIIIIII[188] = ((0xCB ^ 0xC0) << "   ".length()) + ((0x52 ^ 0x55) << " ".length() << " ".length() << " ".length()) - ((0xC8 ^ 0xC3) << " ".length() << " ".length()) + (0x47 ^ 0x4A);
    lIlllIIlIIIIII[189] = ((0x6 ^ 0x19) << " ".length() ^ 0xAB ^ 0xA6) << " ".length() << " ".length();
    lIlllIIlIIIIII[190] = 145 + 74 - 151 + 95;
    lIlllIIlIIIIII[191] = (0x8D ^ 0xA4) << " ".length() << " ".length();
    lIlllIIlIIIIII[192] = (0x7 ^ 0x5C) + ((0x37 ^ 0x16) << " ".length() << " ".length()) - (0x53 ^ 0x10) + (0x49 ^ 0x42);
    lIlllIIlIIIIII[193] = (0xB2 ^ 0x87) << " ".length() << " ".length();
    lIlllIIlIIIIII[194] = (0x5D ^ 0x8) << " ".length();
    lIlllIIlIIIIII[195] = 117 + 40 - 112 + 126;
    lIlllIIlIIIIII[196] = 75 + 139 - 57 + 58;
    lIlllIIlIIIIII[197] = (0x5 ^ 0x64) << " ".length();
    lIlllIIlIIIIII[198] = ((0x23 ^ 0x3A) << " ".length() << " ".length() ^ 0x87 ^ 0xBC) << " ".length();
    lIlllIIlIIIIII[199] = (20 + 114 - 106 + 101 ^ (0xE2 ^ 0xA7) << " ".length()) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[200] = (0x35 ^ 0x52) << " ".length();
    lIlllIIlIIIIII[201] = 134 + 56 - 156 + 143;
    lIlllIIlIIIIII[202] = ((0xC0 ^ 0xC5) << "   ".length() ^ 0xA ^ 0x7B) << " ".length();
    lIlllIIlIIIIII[203] = 146 + 0 - -19 + 14;
    lIlllIIlIIIIII[204] = ("   ".length() << " ".length() ^ 0xBF ^ 0x94) << " ".length() << " ".length();
    lIlllIIlIIIIII[205] = ((0x68 ^ 0x7D) << " ".length() << " ".length()) + ((0x9A ^ 0x89) << "   ".length()) - ((0x2B ^ 0x40) << " ".length()) + 69 + 15 - 27 + 102;
    lIlllIIlIIIIII[206] = ((0x44 ^ 0x23) << " ".length() ^ 24 + 105 - -7 + 11) << " ".length();
    lIlllIIlIIIIII[207] = (22 + 97 - 73 + 93 ^ (0x46 ^ 0x6F) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIIlIIIIII[208] = ((0x33 ^ 0xA) << " ".length()) + 147 + 106 - 173 + 77 - ((0x26 ^ 0x39) << "   ".length()) + ((0x11 ^ 0x42) << " ".length());
    lIlllIIlIIIIII[209] = "   ".length() << "   ".length() << " ".length();
    lIlllIIlIIIIII[210] = (0x19 ^ 0x38) + ((0xB4 ^ 0xB1) << " ".length()) - -(0xEC ^ 0xAE) + ((0xBA ^ 0xAF) << " ".length() << " ".length());
    lIlllIIlIIIIII[211] = (0xE3 ^ 0x9A) + ((0x4B ^ 0x68) << " ".length() << " ".length()) - ((0xB1 ^ 0xBE) << " ".length() << " ".length() << " ".length()) + ((0xB8 ^ 0xB3) << " ".length() << " ".length() << " ".length());
    lIlllIIlIIIIII[212] = (0xC ^ 0x6F) << " ".length();
    lIlllIIlIIIIII[213] = ((0x6 ^ 0xD) << " ".length() << " ".length() << " ".length()) + ("   ".length() << "   ".length() << " ".length()) - ((0xDC ^ 0xB1) << " ".length()) + (0x93 ^ 0xA2);
    lIlllIIlIIIIII[214] = 156 + 166 - 278 + 157;
    lIlllIIlIIIIII[215] = (0x4C ^ 0x23) + ((0x69 ^ 0x70) << "   ".length()) - (0xD1 ^ 0xBC) + " ".length();
    lIlllIIlIIIIII[216] = (0x4D ^ 0x78 ^ (0x82 ^ 0x85) << "   ".length()) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[217] = ((0x73 ^ 0x62) << "   ".length()) + 24 + 179 - 45 + 43 - 155 + 40 - 138 + 108 + (0x4D ^ 0x68);
    lIlllIIlIIIIII[218] = (0xE7 ^ 0x8E) << " ".length();
    lIlllIIlIIIIII[219] = ((0x45 ^ 0x40) << (0x86 ^ 0x83) ^ 140 + 67 - 125 + 105) << "   ".length();
    lIlllIIlIIIIII[220] = (0x18 ^ 0x75) << " ".length();
    lIlllIIlIIIIII[221] = ((0x6D ^ 0x7A) << " ".length() << " ".length()) + ((0x50 ^ 0x17) << " ".length()) - ("   ".length() << "   ".length() << " ".length()) + 150 + 154 - 287 + 160;
    lIlllIIlIIIIII[222] = (0x10 ^ 0x27) << " ".length() << " ".length();
    lIlllIIlIIIIII[223] = 180 + 186 - 205 + 60;
    lIlllIIlIIIIII[224] = (0x38 ^ 0x57) << " ".length();
    lIlllIIlIIIIII[225] = ((0x35 ^ 0x38) << " ".length() << " ".length()) + ((0x40 ^ 0x4B) << "   ".length()) - (0xDD ^ 0x8A) + ((0xFB ^ 0xAE) << " ".length());
    lIlllIIlIIIIII[226] = (0x61 ^ 0xE ^ (0x45 ^ 0x48) << "   ".length()) << (0xDD ^ 0x98 ^ " ".length() << "   ".length() << " ".length());
    lIlllIIlIIIIII[227] = (0xB7 ^ 0x90) + 116 + 103 - 87 + 5 - ((0x12 ^ 0xB) << " ".length()) + (0xF4 ^ 0x97);
    lIlllIIlIIIIII[228] = (0xF0 ^ 0x81) << " ".length();
    lIlllIIlIIIIII[229] = ((0x3F ^ 0x16) << " ".length()) + 83 + 93 - 103 + 58 - ((0x3D ^ 0x2C) << " ".length() << " ".length()) + ((0x41 ^ 0x68) << " ".length());
    lIlllIIlIIIIII[230] = ((0xCD ^ 0xC4) << " ".length() << " ".length() << " ".length() ^ 90 + 129 - 75 + 25) << " ".length() << " ".length();
    lIlllIIlIIIIII[231] = (0x28 ^ 0x19) + ((0x76 ^ 0x73) << " ".length() << " ".length()) - -(0x24 ^ 0x2B) + 10 + 56 - -39 + 40;
    lIlllIIlIIIIII[232] = (0x66 ^ 0x15) << " ".length();
    lIlllIIlIIIIII[233] = 190 + 124 - 259 + 176;
    lIlllIIlIIIIII[234] = (0x9C ^ 0x81) << "   ".length();
    lIlllIIlIIIIII[235] = ((0x14 ^ 0x65) << " ".length()) + ((0x11 ^ 0x1C) << " ".length()) - 76 + 48 - 85 + 90 + ((0x9B ^ 0xAC) << " ".length());
    lIlllIIlIIIIII[236] = ((0xBF ^ 0xB8) << " ".length() << " ".length() ^ 0x24 ^ 0x4D) << " ".length();
    lIlllIIlIIIIII[237] = 75 + 122 - 56 + 94;
    lIlllIIlIIIIII[238] = (0x46 ^ 0x7D) << " ".length() << " ".length();
    lIlllIIlIIIIII[239] = 145 + 104 - 56 + 44;
    lIlllIIlIIIIII[240] = (0x39 ^ 0x34 ^ (0x5A ^ 0x67) << " ".length()) << " ".length();
    lIlllIIlIIIIII[241] = (0xB1 ^ 0xAC) + 145 + 180 - 256 + 124 - 49 + 82 - 51 + 101 + ((0xEE ^ 0x8D) << " ".length());
    lIlllIIlIIIIII[242] = ((0x52 ^ 0x7D) << " ".length() ^ 0xC3 ^ 0x92) << " ".length() << " ".length() << " ".length();
    lIlllIIlIIIIII[243] = (0x26 ^ 0x43) + (0x1 ^ 0xA) - (0x16 ^ 0x1F) + ((0x2A ^ 0x6F) << " ".length());
    lIlllIIlIIIIII[244] = (0x6B ^ 0x12) << " ".length();
    lIlllIIlIIIIII[245] = 212 + 103 - 285 + 213;
    lIlllIIlIIIIII[246] = (" ".length() << " ".length() << " ".length() ^ 0x55 ^ 0x6C) << " ".length() << " ".length();
    lIlllIIlIIIIII[247] = (0x12 ^ 0x43) + (" ".length() << (0x5A ^ 0x5D)) - 35 + 63 - 66 + 141 + 189 + 206 - 332 + 146;
    lIlllIIlIIIIII[248] = ((0x41 ^ 0x6A) & (0x52 ^ 0x79 ^ 0xFFFFFFFF) ^ 0x29 ^ 0x52) << " ".length();
    lIlllIIlIIIIII[249] = 85 + 50 - 71 + 63 + ((0x65 ^ 0x40) << " ".length()) - (0x18 ^ 0x65) + 108 + 75 - 79 + 67;
    lIlllIIlIIIIII[250] = (0x86 ^ 0x99) << "   ".length();
    lIlllIIlIIIIII[251] = 30 + 58 - 41 + 94 + 102 + 199 - 212 + 116 - (130 + 41 - 127 + 93 << " ".length()) + 175 + 68 - 78 + 12;
    lIlllIIlIIIIII[252] = (0x4A ^ 0x37) << " ".length();
    lIlllIIlIIIIII[253] = 14 + 118 - 17 + 42 + ((0x68 ^ 0x4B) << " ".length() << " ".length()) - ((0x63 ^ 0x1A) << " ".length()) + ((0xBD ^ 0x8C) << " ".length() << " ".length());
    lIlllIIlIIIIII[254] = ((0x48 ^ 0x5F) << "   ".length() ^ 36 + 102 - 122 + 119) << " ".length() << " ".length();
    lIlllIIlIIIIII[255] = 195 + 137 - 195 + 90 + ((0x57 ^ 0x44) << " ".length()) - (0x8E ^ 0x91) + (0x53 ^ 0x40);
  }
  
  private static boolean lllllIIIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIIIlIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIIIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIIIlIlIll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lllllIIIIlIlIIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lllllIIIIllIIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lllllIIIIllIIlI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lllllIIIIlIlIII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllIIIIllIIII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllIIIIlIlllI(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lllllIIIIlIllll(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lllllIIIIllIllI(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lllllIIIIlIllII(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lllllIIIIlIIlIl(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIIlIIllI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIIIlIIlll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIIIllIlIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIIIllIlII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIIIllIlll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIIlllIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIIlllIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lllllIIIIllllII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lllllIIIIllllIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */