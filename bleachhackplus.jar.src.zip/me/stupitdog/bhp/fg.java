package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fg extends au {
  public static f100000000000000000000.Mode colorModel;
  
  private static String[] llIIIIIIIIIllI;
  
  private static Class[] llIIIIIIIIIlll;
  
  private static final String[] llIIIIIIIIlIII;
  
  private static String[] llIIIIIIIIlIIl;
  
  private static final int[] llIIIIIIIIllII;
  
  public fg() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIllllIlIllIllI	Lme/stupitdog/bhp/fg;
  }
  
  public void setup() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: aload_1
    //   9: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   12: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   15: iconst_3
    //   16: iaload
    //   17: aaload
    //   18: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   23: ldc ''
    //   25: invokevirtual length : ()I
    //   28: pop2
    //   29: aload_1
    //   30: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   36: iconst_4
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 1 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   44: ldc ''
    //   46: invokevirtual length : ()I
    //   49: pop2
    //   50: aload_0
    //   51: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   54: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   57: iconst_5
    //   58: iaload
    //   59: aaload
    //   60: aload_1
    //   61: getstatic me/stupitdog/bhp/fg.llIIIIIIIIlIII : [Ljava/lang/String;
    //   64: getstatic me/stupitdog/bhp/fg.llIIIIIIIIllII : [I
    //   67: bipush #6
    //   69: iaload
    //   70: aaload
    //   71: <illegal opcode> 2 : (Lme/stupitdog/bhp/fg;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)Lme/stupitdog/bhp/f100000000000000000000$Mode;
    //   76: <illegal opcode> 3 : (Lme/stupitdog/bhp/f100000000000000000000$Mode;)V
    //   81: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	82	0	lllllllllllllllIllIllllIlIllIlIl	Lme/stupitdog/bhp/fg;
    //   8	74	1	lllllllllllllllIllIllllIlIllIlII	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	74	1	lllllllllllllllIllIllllIlIllIlII	Ljava/util/ArrayList<Ljava/lang/String;>;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/fg;)V
    //   6: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIllllIlIllIIll	Lme/stupitdog/bhp/fg;
  }
  
  static {
    lIIIIIIIlllIIllI();
    lIIIIIIIlllIIlII();
    lIIIIIIIlllIIIll();
    lIIIIIIIllIlllll();
  }
  
  private static CallSite lIIIIIIIllIllllI(MethodHandles.Lookup lllllllllllllllIllIllllIlIlIlIlI, String lllllllllllllllIllIllllIlIlIlIIl, MethodType lllllllllllllllIllIllllIlIlIlIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllllIlIllIIII = llIIIIIIIIIllI[Integer.parseInt(lllllllllllllllIllIllllIlIlIlIIl)].split(llIIIIIIIIlIII[llIIIIIIIIllII[7]]);
      Class<?> lllllllllllllllIllIllllIlIlIllll = Class.forName(lllllllllllllllIllIllllIlIllIIII[llIIIIIIIIllII[0]]);
      String lllllllllllllllIllIllllIlIlIlllI = lllllllllllllllIllIllllIlIllIIII[llIIIIIIIIllII[1]];
      MethodHandle lllllllllllllllIllIllllIlIlIllIl = null;
      int lllllllllllllllIllIllllIlIlIllII = lllllllllllllllIllIllllIlIllIIII[llIIIIIIIIllII[3]].length();
      if (lIIIIIIIlllIIlll(lllllllllllllllIllIllllIlIlIllII, llIIIIIIIIllII[2])) {
        MethodType lllllllllllllllIllIllllIlIllIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllllIlIllIIII[llIIIIIIIIllII[2]], fg.class.getClassLoader());
        if (lIIIIIIIlllIlIII(lllllllllllllllIllIllllIlIlIllII, llIIIIIIIIllII[2])) {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findVirtual(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIlI);
          "".length();
          if (((0x39 ^ 0x1C) & (0x8D ^ 0xA8 ^ 0xFFFFFFFF)) == " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findStatic(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIlI);
        } 
        "".length();
        if ("   ".length() != "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllllIlIllIIIl = llIIIIIIIIIlll[Integer.parseInt(lllllllllllllllIllIllllIlIllIIII[llIIIIIIIIllII[2]])];
        if (lIIIIIIIlllIlIII(lllllllllllllllIllIllllIlIlIllII, llIIIIIIIIllII[3])) {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findGetter(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIIl);
          "".length();
          if ("   ".length() == " ".length())
            return null; 
        } else if (lIIIIIIIlllIlIII(lllllllllllllllIllIllllIlIlIllII, llIIIIIIIIllII[4])) {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findStaticGetter(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIIl);
          "".length();
          if (" ".length() >= "   ".length())
            return null; 
        } else if (lIIIIIIIlllIlIII(lllllllllllllllIllIllllIlIlIllII, llIIIIIIIIllII[5])) {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findSetter(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIllllIlIlIllIl = lllllllllllllllIllIllllIlIlIlIlI.findStaticSetter(lllllllllllllllIllIllllIlIlIllll, lllllllllllllllIllIllllIlIlIlllI, lllllllllllllllIllIllllIlIllIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllllIlIlIllIl);
    } catch (Exception lllllllllllllllIllIllllIlIlIlIll) {
      lllllllllllllllIllIllllIlIlIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIllIlllll() {
    llIIIIIIIIIllI = new String[llIIIIIIIIllII[5]];
    llIIIIIIIIIllI[llIIIIIIIIllII[0]] = llIIIIIIIIlIII[llIIIIIIIIllII[8]];
    llIIIIIIIIIllI[llIIIIIIIIllII[4]] = llIIIIIIIIlIII[llIIIIIIIIllII[9]];
    llIIIIIIIIIllI[llIIIIIIIIllII[1]] = llIIIIIIIIlIII[llIIIIIIIIllII[10]];
    llIIIIIIIIIllI[llIIIIIIIIllII[2]] = llIIIIIIIIlIII[llIIIIIIIIllII[11]];
    llIIIIIIIIIllI[llIIIIIIIIllII[3]] = llIIIIIIIIlIII[llIIIIIIIIllII[12]];
    llIIIIIIIIIlll = new Class[llIIIIIIIIllII[2]];
    llIIIIIIIIIlll[llIIIIIIIIllII[1]] = f100000000000000000000.Mode.class;
    llIIIIIIIIIlll[llIIIIIIIIllII[0]] = f13.class;
  }
  
  private static void lIIIIIIIlllIIIll() {
    llIIIIIIIIlIII = new String[llIIIIIIIIllII[13]];
    llIIIIIIIIlIII[llIIIIIIIIllII[0]] = lIIIIIIIlllIIIII(llIIIIIIIIlIIl[llIIIIIIIIllII[0]], llIIIIIIIIlIIl[llIIIIIIIIllII[1]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[1]] = lIIIIIIIlllIIIII(llIIIIIIIIlIIl[llIIIIIIIIllII[2]], llIIIIIIIIlIIl[llIIIIIIIIllII[3]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[2]] = lIIIIIIIlllIIIIl(llIIIIIIIIlIIl[llIIIIIIIIllII[4]], llIIIIIIIIlIIl[llIIIIIIIIllII[5]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[3]] = lIIIIIIIlllIIIlI(llIIIIIIIIlIIl[llIIIIIIIIllII[6]], llIIIIIIIIlIIl[llIIIIIIIIllII[7]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[4]] = lIIIIIIIlllIIIIl(llIIIIIIIIlIIl[llIIIIIIIIllII[8]], llIIIIIIIIlIIl[llIIIIIIIIllII[9]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[5]] = lIIIIIIIlllIIIII(llIIIIIIIIlIIl[llIIIIIIIIllII[10]], llIIIIIIIIlIIl[llIIIIIIIIllII[11]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[6]] = lIIIIIIIlllIIIIl(llIIIIIIIIlIIl[llIIIIIIIIllII[12]], llIIIIIIIIlIIl[llIIIIIIIIllII[13]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[7]] = lIIIIIIIlllIIIlI(llIIIIIIIIlIIl[llIIIIIIIIllII[14]], llIIIIIIIIlIIl[llIIIIIIIIllII[15]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[8]] = lIIIIIIIlllIIIlI(llIIIIIIIIlIIl[llIIIIIIIIllII[16]], llIIIIIIIIlIIl[llIIIIIIIIllII[17]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[9]] = lIIIIIIIlllIIIlI(llIIIIIIIIlIIl[llIIIIIIIIllII[18]], llIIIIIIIIlIIl[llIIIIIIIIllII[19]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[10]] = lIIIIIIIlllIIIIl(llIIIIIIIIlIIl[llIIIIIIIIllII[20]], llIIIIIIIIlIIl[llIIIIIIIIllII[21]]);
    llIIIIIIIIlIII[llIIIIIIIIllII[11]] = lIIIIIIIlllIIIIl("WgGS7+bW6ws9FIT4GkxYxCCqxiHj2yNApmsvWPQOHGQF7+Ty7Es78tKsXAud1JRKDr5bfC3aIMpK0VxWHGInnil9lzRExSWum7zW41yKDs2ifbzuxWN+m2wBTOG4vT4acAYjXnxVYiwMzxt3h0vWWzqdNtU8SX55FZvRZHqaeNuWm2D0eicjjMTh9tr6zW8u", "mDrWl");
    llIIIIIIIIlIII[llIIIIIIIIllII[12]] = lIIIIIIIlllIIIlI("PQFoKwAlFC8sED8DaDocIEogP04zCyo3Bh0LIj0YalV8eFRwRGZ4", "PdFXt");
    llIIIIIIIIlIIl = null;
  }
  
  private static void lIIIIIIIlllIIlII() {
    String str = (new Exception()).getStackTrace()[llIIIIIIIIllII[0]].getFileName();
    llIIIIIIIIlIIl = str.substring(str.indexOf("ä") + llIIIIIIIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIlllIIIIl(String lllllllllllllllIllIllllIlIlIIlII, String lllllllllllllllIllIllllIlIlIIIll) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIlIlIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIlIlIIIll.getBytes(StandardCharsets.UTF_8)), llIIIIIIIIllII[8]), "DES");
      Cipher lllllllllllllllIllIllllIlIlIIllI = Cipher.getInstance("DES");
      lllllllllllllllIllIllllIlIlIIllI.init(llIIIIIIIIllII[2], lllllllllllllllIllIllllIlIlIIlll);
      return new String(lllllllllllllllIllIllllIlIlIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIlIlIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIlIlIIlIl) {
      lllllllllllllllIllIllllIlIlIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIlllIIIII(String lllllllllllllllIllIllllIlIIlllll, String lllllllllllllllIllIllllIlIIllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIllllIlIlIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIlIIllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllllIlIlIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllllIlIlIIIIl.init(llIIIIIIIIllII[2], lllllllllllllllIllIllllIlIlIIIlI);
      return new String(lllllllllllllllIllIllllIlIlIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIlIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllllIlIlIIIII) {
      lllllllllllllllIllIllllIlIlIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIlllIIIlI(String lllllllllllllllIllIllllIlIIlllII, String lllllllllllllllIllIllllIlIIllIll) {
    lllllllllllllllIllIllllIlIIlllII = new String(Base64.getDecoder().decode(lllllllllllllllIllIllllIlIIlllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllllIlIIllIlI = new StringBuilder();
    char[] lllllllllllllllIllIllllIlIIllIIl = lllllllllllllllIllIllllIlIIllIll.toCharArray();
    int lllllllllllllllIllIllllIlIIllIII = llIIIIIIIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllllIlIIlllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIIIllII[0];
    while (lIIIIIIIlllIlIIl(j, i)) {
      char lllllllllllllllIllIllllIlIIlllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllllIlIIllIII++;
      j++;
      "".length();
      if ((((0xF ^ 0x74) << " ".length() ^ 154 + 165 - 225 + 95) & ((0x42 ^ 0x4F) << "   ".length() ^ 0x7C ^ 0x5F ^ -" ".length()) & (((0x71 ^ 0x5A) << " ".length() << " ".length() ^ 19 + 66 - 53 + 129) & (0x6E ^ 0x1D ^ (0x2C ^ 0x13) << " ".length() ^ -" ".length()) ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllllIlIIllIlI);
  }
  
  private static void lIIIIIIIlllIIllI() {
    llIIIIIIIIllII = new int[22];
    llIIIIIIIIllII[0] = (0x15 ^ 0x7A ^ (0x3B ^ 0x34) << "   ".length()) << " ".length() << " ".length() & ((0xB5 ^ 0x9E ^ (0x43 ^ 0x4C) << " ".length() << " ".length()) << " ".length() << " ".length() ^ -" ".length());
    llIIIIIIIIllII[1] = " ".length();
    llIIIIIIIIllII[2] = " ".length() << " ".length();
    llIIIIIIIIllII[3] = "   ".length();
    llIIIIIIIIllII[4] = " ".length() << " ".length() << " ".length();
    llIIIIIIIIllII[5] = 0x50 ^ 0x55;
    llIIIIIIIIllII[6] = "   ".length() << " ".length();
    llIIIIIIIIllII[7] = 0x4C ^ 0x4B;
    llIIIIIIIIllII[8] = " ".length() << "   ".length();
    llIIIIIIIIllII[9] = 0x3F ^ 0x36;
    llIIIIIIIIllII[10] = (0xAE ^ 0xAB) << " ".length();
    llIIIIIIIIllII[11] = 0x8D ^ 0x86;
    llIIIIIIIIllII[12] = "   ".length() << " ".length() << " ".length();
    llIIIIIIIIllII[13] = (0x62 ^ 0x29) << " ".length() ^ 49 + 118 - 139 + 127;
    llIIIIIIIIllII[14] = (0xF ^ 0x8) << " ".length();
    llIIIIIIIIllII[15] = 0x54 ^ 0x5B;
    llIIIIIIIIllII[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIIIllII[17] = 0x4F ^ 0x5E;
    llIIIIIIIIllII[18] = (0x6A ^ 0x63) << " ".length();
    llIIIIIIIIllII[19] = 0x9E ^ 0x8D;
    llIIIIIIIIllII[20] = (0xA0 ^ 0xA5) << " ".length() << " ".length();
    llIIIIIIIIllII[21] = 0xE ^ 0x1B;
  }
  
  private static boolean lIIIIIIIlllIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIlllIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIlllIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fg.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */