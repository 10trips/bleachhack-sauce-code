package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fz {
  public String id;
  
  public String name;
  
  private static String[] llIIIlllIlIIIl;
  
  private static Class[] llIIIlllIlIIlI;
  
  private static final String[] llIIIlllIlIIll;
  
  private static String[] llIIIlllIlIlII;
  
  private static final int[] llIIIlllIlIlIl;
  
  public fz(String lllllllllllllllIllIlIIIIlllIIIlI, String lllllllllllllllIllIlIIIIlllIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/fz;Ljava/lang/String;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/fz;Ljava/lang/String;)V
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIllIlIIIIlllIIIll	Lme/stupitdog/bhp/fz;
    //   0	19	1	lllllllllllllllIllIlIIIIlllIIIlI	Ljava/lang/String;
    //   0	19	2	lllllllllllllllIllIlIIIIlllIIIIl	Ljava/lang/String;
  }
  
  public String getId() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lme/stupitdog/bhp/fz;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIIIlllIIIII	Lme/stupitdog/bhp/fz;
  }
  
  public String getName() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lme/stupitdog/bhp/fz;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIIIIllIlllll	Lme/stupitdog/bhp/fz;
  }
  
  static {
    lIIIIlIlIlllllll();
    lIIIIlIlIllllllI();
    lIIIIlIlIlllllIl();
    lIIIIlIlIllllIlI();
  }
  
  private static CallSite lIIIIlIlIllllIIl(MethodHandles.Lookup lllllllllllllllIllIlIIIIllIlIllI, String lllllllllllllllIllIlIIIIllIlIlIl, MethodType lllllllllllllllIllIlIIIIllIlIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIIIllIlllII = llIIIlllIlIIIl[Integer.parseInt(lllllllllllllllIllIlIIIIllIlIlIl)].split(llIIIlllIlIIll[llIIIlllIlIlIl[0]]);
      Class<?> lllllllllllllllIllIlIIIIllIllIll = Class.forName(lllllllllllllllIllIlIIIIllIlllII[llIIIlllIlIlIl[0]]);
      String lllllllllllllllIllIlIIIIllIllIlI = lllllllllllllllIllIlIIIIllIlllII[llIIIlllIlIlIl[1]];
      MethodHandle lllllllllllllllIllIlIIIIllIllIIl = null;
      int lllllllllllllllIllIlIIIIllIllIII = lllllllllllllllIllIlIIIIllIlllII[llIIIlllIlIlIl[2]].length();
      if (lIIIIlIllIIIIIII(lllllllllllllllIllIlIIIIllIllIII, llIIIlllIlIlIl[3])) {
        MethodType lllllllllllllllIllIlIIIIllIllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIIIllIlllII[llIIIlllIlIlIl[3]], fz.class.getClassLoader());
        if (lIIIIlIllIIIIIIl(lllllllllllllllIllIlIIIIllIllIII, llIIIlllIlIlIl[3])) {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findVirtual(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIllllI);
          "".length();
          if ((0x56 ^ 0x53) <= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findStatic(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIllllI);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIIIllIlllIl = llIIIlllIlIIlI[Integer.parseInt(lllllllllllllllIllIlIIIIllIlllII[llIIIlllIlIlIl[3]])];
        if (lIIIIlIllIIIIIIl(lllllllllllllllIllIlIIIIllIllIII, llIIIlllIlIlIl[2])) {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findGetter(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIlllIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIllIIIIIIl(lllllllllllllllIllIlIIIIllIllIII, llIIIlllIlIlIl[4])) {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findStaticGetter(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIlllIl);
          "".length();
          if (-" ".length() >= 0)
            return null; 
        } else if (lIIIIlIllIIIIIIl(lllllllllllllllIllIlIIIIllIllIII, llIIIlllIlIlIl[5])) {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findSetter(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIlllIl);
          "".length();
          if ("   ".length() == " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIIIllIllIIl = lllllllllllllllIllIlIIIIllIlIllI.findStaticSetter(lllllllllllllllIllIlIIIIllIllIll, lllllllllllllllIllIlIIIIllIllIlI, lllllllllllllllIllIlIIIIllIlllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIIIllIllIIl);
    } catch (Exception lllllllllllllllIllIlIIIIllIlIlll) {
      lllllllllllllllIllIlIIIIllIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlIllllIlI() {
    llIIIlllIlIIIl = new String[llIIIlllIlIlIl[4]];
    llIIIlllIlIIIl[llIIIlllIlIlIl[0]] = llIIIlllIlIIll[llIIIlllIlIlIl[1]];
    llIIIlllIlIIIl[llIIIlllIlIlIl[3]] = llIIIlllIlIIll[llIIIlllIlIlIl[3]];
    llIIIlllIlIIIl[llIIIlllIlIlIl[1]] = llIIIlllIlIIll[llIIIlllIlIlIl[2]];
    llIIIlllIlIIIl[llIIIlllIlIlIl[2]] = llIIIlllIlIIll[llIIIlllIlIlIl[4]];
    llIIIlllIlIIlI = new Class[llIIIlllIlIlIl[1]];
    llIIIlllIlIIlI[llIIIlllIlIlIl[0]] = String.class;
  }
  
  private static void lIIIIlIlIlllllIl() {
    llIIIlllIlIIll = new String[llIIIlllIlIlIl[5]];
    llIIIlllIlIIll[llIIIlllIlIlIl[0]] = lIIIIlIlIllllIll(llIIIlllIlIlII[llIIIlllIlIlIl[0]], llIIIlllIlIlII[llIIIlllIlIlIl[1]]);
    llIIIlllIlIIll[llIIIlllIlIlIl[1]] = lIIIIlIlIlllllII(llIIIlllIlIlII[llIIIlllIlIlIl[3]], llIIIlllIlIlII[llIIIlllIlIlIl[2]]);
    llIIIlllIlIIll[llIIIlllIlIlIl[3]] = lIIIIlIlIlllllII(llIIIlllIlIlII[llIIIlllIlIlIl[4]], llIIIlllIlIlII[llIIIlllIlIlIl[5]]);
    llIIIlllIlIIll[llIIIlllIlIlIl[2]] = lIIIIlIlIlllllII(llIIIlllIlIlII[llIIIlllIlIlIl[6]], llIIIlllIlIlII[llIIIlllIlIlIl[7]]);
    llIIIlllIlIIll[llIIIlllIlIlIl[4]] = lIIIIlIlIlllllII(llIIIlllIlIlII[llIIIlllIlIlIl[8]], llIIIlllIlIlII[llIIIlllIlIlIl[9]]);
    llIIIlllIlIlII = null;
  }
  
  private static void lIIIIlIlIllllllI() {
    String str = (new Exception()).getStackTrace()[llIIIlllIlIlIl[0]].getFileName();
    llIIIlllIlIlII = str.substring(str.indexOf("ä") + llIIIlllIlIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIlIlllllII(String lllllllllllllllIllIlIIIIllIlIIII, String lllllllllllllllIllIlIIIIllIIllll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIllIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIllIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIIllIlIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIIllIlIIlI.init(llIIIlllIlIlIl[3], lllllllllllllllIllIlIIIIllIlIIll);
      return new String(lllllllllllllllIllIlIIIIllIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIllIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIllIlIIIl) {
      lllllllllllllllIllIlIIIIllIlIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIlIllllIll(String lllllllllllllllIllIlIIIIllIIlIll, String lllllllllllllllIllIlIIIIllIIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIllIIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIllIIlIlI.getBytes(StandardCharsets.UTF_8)), llIIIlllIlIlIl[8]), "DES");
      Cipher lllllllllllllllIllIlIIIIllIIllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIllIIllIl.init(llIIIlllIlIlIl[3], lllllllllllllllIllIlIIIIllIIlllI);
      return new String(lllllllllllllllIllIlIIIIllIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIllIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIllIIllII) {
      lllllllllllllllIllIlIIIIllIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIlIlllllll() {
    llIIIlllIlIlIl = new int[10];
    llIIIlllIlIlIl[0] = ("   ".length() << " ".length() << " ".length() ^ 0x1B ^ 0x4E) & (14 + 147 - 26 + 18 ^ "   ".length() << "   ".length() << " ".length() ^ -" ".length());
    llIIIlllIlIlIl[1] = " ".length();
    llIIIlllIlIlIl[2] = "   ".length();
    llIIIlllIlIlIl[3] = " ".length() << " ".length();
    llIIIlllIlIlIl[4] = " ".length() << " ".length() << " ".length();
    llIIIlllIlIlIl[5] = 0x1E ^ 0x1B;
    llIIIlllIlIlIl[6] = "   ".length() << " ".length();
    llIIIlllIlIlIl[7] = 0x67 ^ 0x60;
    llIIIlllIlIlIl[8] = " ".length() << "   ".length();
    llIIIlllIlIlIl[9] = 0x27 ^ 0x2E;
  }
  
  private static boolean lIIIIlIllIIIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllIIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fz.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */