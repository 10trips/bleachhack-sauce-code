package me.stupitdog.bhp;

import com.lukflug.panelstudio.settings.KeybindSetting;
import com.lukflug.panelstudio.settings.Toggleable;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.common.eventhandler.EventBus;

public class au implements Toggleable, KeybindSetting {
  public String name;
  
  public String bracket;
  
  public String description;
  
  public f13 category;
  
  public boolean toggled;
  
  public f100000000000000000000.Boolean draw;
  
  public int key;
  
  public static Minecraft mc;
  
  private static String[] lIllIllIllIlll;
  
  private static Class[] lIllIllIlllIII;
  
  private static final String[] lIllIlllIlIlII;
  
  private static String[] lIllIlllIlllIl;
  
  private static final int[] lIllIlllIllllI;
  
  public au(String lllllllllllllllIllllIIIlllIIllIl, String lllllllllllllllIllllIIIlllIIllII, String lllllllllllllllIllllIIIlllIIlIll, f13 lllllllllllllllIllllIIIlllIIlIlI, int lllllllllllllllIllllIIIlllIIlIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   18: aload_0
    //   19: aload_3
    //   20: <illegal opcode> 2 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   25: aload_0
    //   26: aload #4
    //   28: <illegal opcode> 3 : (Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;)V
    //   33: aload_0
    //   34: iload #5
    //   36: <illegal opcode> 4 : (Lme/stupitdog/bhp/au;I)V
    //   41: aload_0
    //   42: aload_0
    //   43: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   46: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   49: iconst_0
    //   50: iaload
    //   51: aaload
    //   52: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   55: iconst_1
    //   56: iaload
    //   57: <illegal opcode> 5 : (Lme/stupitdog/bhp/au;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   62: <illegal opcode> 6 : (Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   67: aload_0
    //   68: <illegal opcode> 7 : (Lme/stupitdog/bhp/au;)V
    //   73: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	74	0	lllllllllllllllIllllIIIlllIIlllI	Lme/stupitdog/bhp/au;
    //   0	74	1	lllllllllllllllIllllIIIlllIIllIl	Ljava/lang/String;
    //   0	74	2	lllllllllllllllIllllIIIlllIIllII	Ljava/lang/String;
    //   0	74	3	lllllllllllllllIllllIIIlllIIlIll	Ljava/lang/String;
    //   0	74	4	lllllllllllllllIllllIIIlllIIlIlI	Lme/stupitdog/bhp/f13;
    //   0	74	5	lllllllllllllllIllllIIIlllIIlIIl	I
  }
  
  public void setup() {}
  
  public void enable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   4: iconst_1
    //   5: iaload
    //   6: <illegal opcode> 8 : (Lme/stupitdog/bhp/au;Z)V
    //   11: <illegal opcode> 9 : ()Lme/zero/alpine/EventManager;
    //   16: aload_0
    //   17: <illegal opcode> 10 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   22: <illegal opcode> 11 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   27: aload_0
    //   28: <illegal opcode> 12 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   33: aload_0
    //   34: <illegal opcode> 13 : (Lme/stupitdog/bhp/au;)V
    //   39: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	40	0	lllllllllllllllIllllIIIlllIIIlll	Lme/stupitdog/bhp/au;
  }
  
  public void disable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 8 : (Lme/stupitdog/bhp/au;Z)V
    //   11: <illegal opcode> 9 : ()Lme/zero/alpine/EventManager;
    //   16: aload_0
    //   17: <illegal opcode> 14 : (Lme/zero/alpine/EventManager;Ljava/lang/Object;)V
    //   22: <illegal opcode> 11 : ()Lnet/minecraftforge/fml/common/eventhandler/EventBus;
    //   27: aload_0
    //   28: <illegal opcode> 15 : (Lnet/minecraftforge/fml/common/eventhandler/EventBus;Ljava/lang/Object;)V
    //   33: aload_0
    //   34: <illegal opcode> 16 : (Lme/stupitdog/bhp/au;)V
    //   39: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	40	0	lllllllllllllllIllllIIIlllIIIllI	Lme/stupitdog/bhp/au;
  }
  
  public void onEnable() {}
  
  public void onDisable() {}
  
  public void update() {}
  
  public void render() {}
  
  public void toggle() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: <illegal opcode> 17 : (Lme/stupitdog/bhp/au;)Z
    //   7: invokestatic llllIllIIllIlIl : (I)Z
    //   10: ifeq -> 92
    //   13: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop
    //   24: ldc ' '
    //   26: invokevirtual length : ()I
    //   29: bipush #62
    //   31: bipush #53
    //   33: ixor
    //   34: ldc ' '
    //   36: invokevirtual length : ()I
    //   39: ldc ' '
    //   41: invokevirtual length : ()I
    //   44: ishl
    //   45: ishl
    //   46: ixor
    //   47: ldc ' '
    //   49: invokevirtual length : ()I
    //   52: ishl
    //   53: sipush #148
    //   56: sipush #175
    //   59: ixor
    //   60: ldc ' '
    //   62: invokevirtual length : ()I
    //   65: ishl
    //   66: sipush #152
    //   69: sipush #195
    //   72: ixor
    //   73: ixor
    //   74: ldc ' '
    //   76: invokevirtual length : ()I
    //   79: ishl
    //   80: ldc ' '
    //   82: invokevirtual length : ()I
    //   85: ineg
    //   86: ixor
    //   87: iand
    //   88: ifeq -> 97
    //   91: return
    //   92: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   95: iconst_0
    //   96: iaload
    //   97: <illegal opcode> 18 : (Lme/stupitdog/bhp/au;Z)V
    //   102: aload_0
    //   103: <illegal opcode> 17 : (Lme/stupitdog/bhp/au;)Z
    //   108: invokestatic llllIllIIllIllI : (I)Z
    //   111: ifeq -> 400
    //   114: aload_0
    //   115: <illegal opcode> 19 : (Lme/stupitdog/bhp/au;)V
    //   120: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   125: <illegal opcode> 21 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   130: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   133: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   136: iconst_1
    //   137: iaload
    //   138: aaload
    //   139: <illegal opcode> 22 : (Lme/stupitdog/bhp/av;Ljava/lang/String;)Lme/stupitdog/bhp/au;
    //   144: <illegal opcode> 23 : (Lme/stupitdog/bhp/au;)Z
    //   149: invokestatic llllIllIIllIllI : (I)Z
    //   152: ifeq -> 335
    //   155: aload_0
    //   156: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   161: <illegal opcode> 25 : ()Lme/stupitdog/bhp/f13;
    //   166: invokestatic llllIllIIllIlll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   169: ifeq -> 335
    //   172: <illegal opcode> 26 : ()Ljava/lang/String;
    //   177: aload_0
    //   178: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   183: invokestatic llllIllIIlllIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   186: ifeq -> 273
    //   189: new java/lang/StringBuilder
    //   192: dup
    //   193: invokespecial <init> : ()V
    //   196: <illegal opcode> 28 : ()Lnet/minecraft/util/text/TextFormatting;
    //   201: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   206: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   209: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   212: iconst_2
    //   213: iaload
    //   214: aaload
    //   215: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: <illegal opcode> 31 : ()Lnet/minecraft/util/text/TextFormatting;
    //   225: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   230: aload_0
    //   231: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   236: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: <illegal opcode> 32 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   246: <illegal opcode> 33 : (Ljava/lang/String;)V
    //   251: ldc ''
    //   253: invokevirtual length : ()I
    //   256: pop
    //   257: ldc ' '
    //   259: invokevirtual length : ()I
    //   262: ineg
    //   263: ldc ' '
    //   265: invokevirtual length : ()I
    //   268: ineg
    //   269: if_icmpge -> 335
    //   272: return
    //   273: new java/lang/StringBuilder
    //   276: dup
    //   277: invokespecial <init> : ()V
    //   280: <illegal opcode> 28 : ()Lnet/minecraft/util/text/TextFormatting;
    //   285: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   290: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   293: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   296: iconst_3
    //   297: iaload
    //   298: aaload
    //   299: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: <illegal opcode> 31 : ()Lnet/minecraft/util/text/TextFormatting;
    //   309: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   314: aload_0
    //   315: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   320: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: <illegal opcode> 32 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   330: <illegal opcode> 34 : (Ljava/lang/String;)V
    //   335: aload_0
    //   336: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   341: <illegal opcode> 35 : (Ljava/lang/String;)V
    //   346: ldc ''
    //   348: invokevirtual length : ()I
    //   351: pop
    //   352: bipush #28
    //   354: bipush #21
    //   356: ixor
    //   357: ldc '   '
    //   359: invokevirtual length : ()I
    //   362: ishl
    //   363: bipush #19
    //   365: bipush #110
    //   367: ixor
    //   368: ixor
    //   369: bipush #74
    //   371: bipush #123
    //   373: ixor
    //   374: ldc ' '
    //   376: invokevirtual length : ()I
    //   379: ishl
    //   380: sipush #197
    //   383: sipush #146
    //   386: ixor
    //   387: ixor
    //   388: ldc ' '
    //   390: invokevirtual length : ()I
    //   393: ineg
    //   394: ixor
    //   395: iand
    //   396: ifeq -> 654
    //   399: return
    //   400: aload_0
    //   401: <illegal opcode> 36 : (Lme/stupitdog/bhp/au;)V
    //   406: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   411: <illegal opcode> 21 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   416: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   419: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   422: iconst_4
    //   423: iaload
    //   424: aaload
    //   425: <illegal opcode> 22 : (Lme/stupitdog/bhp/av;Ljava/lang/String;)Lme/stupitdog/bhp/au;
    //   430: <illegal opcode> 23 : (Lme/stupitdog/bhp/au;)Z
    //   435: invokestatic llllIllIIllIllI : (I)Z
    //   438: ifeq -> 643
    //   441: <illegal opcode> 37 : ()Lnet/minecraft/client/Minecraft;
    //   446: <illegal opcode> 38 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   451: invokestatic llllIllIIlllIIl : (Ljava/lang/Object;)Z
    //   454: ifeq -> 643
    //   457: aload_0
    //   458: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   463: <illegal opcode> 25 : ()Lme/stupitdog/bhp/f13;
    //   468: invokestatic llllIllIIllIlll : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   471: ifeq -> 643
    //   474: <illegal opcode> 26 : ()Ljava/lang/String;
    //   479: aload_0
    //   480: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   485: invokestatic llllIllIIlllIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   488: ifeq -> 580
    //   491: new java/lang/StringBuilder
    //   494: dup
    //   495: invokespecial <init> : ()V
    //   498: <illegal opcode> 39 : ()Lnet/minecraft/util/text/TextFormatting;
    //   503: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   508: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   511: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   514: iconst_5
    //   515: iaload
    //   516: aaload
    //   517: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   522: <illegal opcode> 31 : ()Lnet/minecraft/util/text/TextFormatting;
    //   527: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   532: aload_0
    //   533: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   538: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   543: <illegal opcode> 32 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   548: <illegal opcode> 33 : (Ljava/lang/String;)V
    //   553: ldc ''
    //   555: invokevirtual length : ()I
    //   558: pop
    //   559: ldc ' '
    //   561: invokevirtual length : ()I
    //   564: ldc ' '
    //   566: invokevirtual length : ()I
    //   569: ldc ' '
    //   571: invokevirtual length : ()I
    //   574: ishl
    //   575: ishl
    //   576: ifgt -> 643
    //   579: return
    //   580: new java/lang/StringBuilder
    //   583: dup
    //   584: invokespecial <init> : ()V
    //   587: <illegal opcode> 39 : ()Lnet/minecraft/util/text/TextFormatting;
    //   592: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   597: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   600: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   603: bipush #6
    //   605: iaload
    //   606: aaload
    //   607: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   612: <illegal opcode> 31 : ()Lnet/minecraft/util/text/TextFormatting;
    //   617: <illegal opcode> 29 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   622: aload_0
    //   623: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   628: <illegal opcode> 30 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   633: <illegal opcode> 32 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   638: <illegal opcode> 34 : (Ljava/lang/String;)V
    //   643: aload_0
    //   644: <illegal opcode> 27 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   649: <illegal opcode> 35 : (Ljava/lang/String;)V
    //   654: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	655	0	lllllllllllllllIllllIIIlllIIIIIl	Lme/stupitdog/bhp/au;
  }
  
  public String getName() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 40 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIlllIIIIII	Lme/stupitdog/bhp/au;
  }
  
  public void setName(String lllllllllllllllIllllIIIllIlllllI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIllllll	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIlllllI	Ljava/lang/String;
  }
  
  public String getBracket() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 41 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIllllIl	Lme/stupitdog/bhp/au;
  }
  
  public void setBracket(String lllllllllllllllIllllIIIllIlllIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 1 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIllllII	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIlllIll	Ljava/lang/String;
  }
  
  public String getDescription() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 42 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIlllIlI	Lme/stupitdog/bhp/au;
  }
  
  public void setDescription(String lllllllllllllllIllllIIIllIlllIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 2 : (Lme/stupitdog/bhp/au;Ljava/lang/String;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIlllIIl	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIlllIII	Ljava/lang/String;
  }
  
  public f13 getCategory() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 43 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIllIlll	Lme/stupitdog/bhp/au;
  }
  
  public void setCategory(f13 lllllllllllllllIllllIIIllIllIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 3 : (Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIllIllI	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIllIlIl	Lme/stupitdog/bhp/f13;
  }
  
  public boolean isToggled() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 17 : (Lme/stupitdog/bhp/au;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIllIlII	Lme/stupitdog/bhp/au;
  }
  
  public void setToggled(boolean lllllllllllllllIllllIIIllIllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: <illegal opcode> 18 : (Lme/stupitdog/bhp/au;Z)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIllIIll	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIllIIlI	Z
  }
  
  public boolean isDraw() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 44 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: <illegal opcode> 45 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllllIIIllIllIIIl	Lme/stupitdog/bhp/au;
  }
  
  public void setDraw(boolean lllllllllllllllIllllIIIllIlIllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 44 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   6: iload_1
    //   7: <illegal opcode> 46 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;Z)V
    //   12: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllllIIIllIllIIII	Lme/stupitdog/bhp/au;
    //   0	13	1	lllllllllllllllIllllIIIllIlIllll	Z
  }
  
  public int getKey() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 47 : (Lme/stupitdog/bhp/au;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIlIlllI	Lme/stupitdog/bhp/au;
  }
  
  public void setKey(int lllllllllllllllIllllIIIllIlIllII) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: <illegal opcode> 4 : (Lme/stupitdog/bhp/au;I)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllllIIIllIlIllIl	Lme/stupitdog/bhp/au;
    //   0	8	1	lllllllllllllllIllllIIIllIlIllII	I
  }
  
  protected f100000000000000000000.Integer registerInteger(String lllllllllllllllIllllIIIllIlIlIlI, int lllllllllllllllIllllIIIllIlIlIIl, int lllllllllllllllIllllIIIllIlIlIII, int lllllllllllllllIllllIIIllIlIIlll) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f100000000000000000000$Integer
    //   3: dup
    //   4: aload_1
    //   5: aload_0
    //   6: aload_0
    //   7: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   12: iload_2
    //   13: iload_3
    //   14: iload #4
    //   16: invokespecial <init> : (Ljava/lang/String;Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;III)V
    //   19: astore #5
    //   21: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   26: <illegal opcode> 48 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   31: aload #5
    //   33: <illegal opcode> 49 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000;)V
    //   38: aload #5
    //   40: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	41	0	lllllllllllllllIllllIIIllIlIlIll	Lme/stupitdog/bhp/au;
    //   0	41	1	lllllllllllllllIllllIIIllIlIlIlI	Ljava/lang/String;
    //   0	41	2	lllllllllllllllIllllIIIllIlIlIIl	I
    //   0	41	3	lllllllllllllllIllllIIIllIlIlIII	I
    //   0	41	4	lllllllllllllllIllllIIIllIlIIlll	I
    //   21	20	5	lllllllllllllllIllllIIIllIlIIllI	Lme/stupitdog/bhp/f100000000000000000000$Integer;
  }
  
  protected f100000000000000000000.Double registerDouble(String lllllllllllllllIllllIIIllIlIIlII, double lllllllllllllllIllllIIIllIlIIIll, double lllllllllllllllIllllIIIllIlIIIlI, double lllllllllllllllIllllIIIllIlIIIIl) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f100000000000000000000$Double
    //   3: dup
    //   4: aload_1
    //   5: aload_0
    //   6: aload_0
    //   7: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   12: dload_2
    //   13: dload #4
    //   15: dload #6
    //   17: invokespecial <init> : (Ljava/lang/String;Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;DDD)V
    //   20: astore #8
    //   22: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   27: <illegal opcode> 48 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   32: aload #8
    //   34: <illegal opcode> 49 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000;)V
    //   39: aload #8
    //   41: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllllIIIllIlIIlIl	Lme/stupitdog/bhp/au;
    //   0	42	1	lllllllllllllllIllllIIIllIlIIlII	Ljava/lang/String;
    //   0	42	2	lllllllllllllllIllllIIIllIlIIIll	D
    //   0	42	4	lllllllllllllllIllllIIIllIlIIIlI	D
    //   0	42	6	lllllllllllllllIllllIIIllIlIIIIl	D
    //   22	20	8	lllllllllllllllIllllIIIllIlIIIII	Lme/stupitdog/bhp/f100000000000000000000$Double;
  }
  
  protected f100000000000000000000.Boolean registerBoolean(String lllllllllllllllIllllIIIllIIllllI, boolean lllllllllllllllIllllIIIllIIlllIl) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f100000000000000000000$Boolean
    //   3: dup
    //   4: aload_1
    //   5: aload_0
    //   6: aload_0
    //   7: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   12: iload_2
    //   13: invokespecial <init> : (Ljava/lang/String;Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;Z)V
    //   16: astore_3
    //   17: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   22: <illegal opcode> 48 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   27: aload_3
    //   28: <illegal opcode> 49 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000;)V
    //   33: aload_3
    //   34: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	35	0	lllllllllllllllIllllIIIllIIlllll	Lme/stupitdog/bhp/au;
    //   0	35	1	lllllllllllllllIllllIIIllIIllllI	Ljava/lang/String;
    //   0	35	2	lllllllllllllllIllllIIIllIIlllIl	Z
    //   17	18	3	lllllllllllllllIllllIIIllIIlllII	Lme/stupitdog/bhp/f100000000000000000000$Boolean;
  }
  
  protected f100000000000000000000.Mode registerMode(String lllllllllllllllIllllIIIllIIllIlI, List<String> lllllllllllllllIllllIIIllIIllIIl, String lllllllllllllllIllllIIIllIIllIII) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f100000000000000000000$Mode
    //   3: dup
    //   4: aload_1
    //   5: aload_0
    //   6: aload_0
    //   7: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   12: aload_2
    //   13: aload_3
    //   14: invokespecial <init> : (Ljava/lang/String;Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;Ljava/util/List;Ljava/lang/String;)V
    //   17: astore #4
    //   19: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   24: <illegal opcode> 48 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   29: aload #4
    //   31: <illegal opcode> 49 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000;)V
    //   36: aload #4
    //   38: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	39	0	lllllllllllllllIllllIIIllIIllIll	Lme/stupitdog/bhp/au;
    //   0	39	1	lllllllllllllllIllllIIIllIIllIlI	Ljava/lang/String;
    //   0	39	2	lllllllllllllllIllllIIIllIIllIIl	Ljava/util/List;
    //   0	39	3	lllllllllllllllIllllIIIllIIllIII	Ljava/lang/String;
    //   19	20	4	lllllllllllllllIllllIIIllIIlIlll	Lme/stupitdog/bhp/f100000000000000000000$Mode;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	39	2	lllllllllllllllIllllIIIllIIllIIl	Ljava/util/List<Ljava/lang/String;>;
  }
  
  protected f100000000000000000000.ColorSetting registerColor(String lllllllllllllllIllllIIIllIIlIlIl, f01 lllllllllllllllIllllIIIllIIlIlII) {
    // Byte code:
    //   0: new me/stupitdog/bhp/f100000000000000000000$ColorSetting
    //   3: dup
    //   4: aload_1
    //   5: aload_0
    //   6: aload_0
    //   7: <illegal opcode> 24 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   12: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   15: iconst_0
    //   16: iaload
    //   17: aload_2
    //   18: invokespecial <init> : (Ljava/lang/String;Lme/stupitdog/bhp/au;Lme/stupitdog/bhp/f13;ZLme/stupitdog/bhp/f01;)V
    //   21: astore_3
    //   22: <illegal opcode> 20 : ()Lme/stupitdog/bhp/f9;
    //   27: <illegal opcode> 48 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f1000000000000000000000;
    //   32: aload_3
    //   33: <illegal opcode> 49 : (Lme/stupitdog/bhp/f1000000000000000000000;Lme/stupitdog/bhp/f100000000000000000000;)V
    //   38: aload_3
    //   39: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	40	0	lllllllllllllllIllllIIIllIIlIllI	Lme/stupitdog/bhp/au;
    //   0	40	1	lllllllllllllllIllllIIIllIIlIlIl	Ljava/lang/String;
    //   0	40	2	lllllllllllllllIllllIIIllIIlIlII	Lme/stupitdog/bhp/f01;
    //   22	18	3	lllllllllllllllIllllIIIllIIlIIll	Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
  }
  
  protected f100000000000000000000.ColorSetting registerColor(String lllllllllllllllIllllIIIllIIlIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: new me/stupitdog/bhp/f01
    //   5: dup
    //   6: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   9: bipush #7
    //   11: iaload
    //   12: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   15: bipush #8
    //   17: iaload
    //   18: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   21: bipush #9
    //   23: iaload
    //   24: invokespecial <init> : (III)V
    //   27: <illegal opcode> 50 : (Lme/stupitdog/bhp/au;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   32: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	33	0	lllllllllllllllIllllIIIllIIlIIlI	Lme/stupitdog/bhp/au;
    //   0	33	1	lllllllllllllllIllllIIIllIIlIIIl	Ljava/lang/String;
  }
  
  public final boolean isOn() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 17 : (Lme/stupitdog/bhp/au;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIIllIIlIIII	Lme/stupitdog/bhp/au;
  }
  
  public String getKeyName() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 47 : (Lme/stupitdog/bhp/au;)I
    //   6: invokestatic llllIllIIlllIlI : (I)Z
    //   9: ifeq -> 30
    //   12: aload_0
    //   13: <illegal opcode> 47 : (Lme/stupitdog/bhp/au;)I
    //   18: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   21: bipush #10
    //   23: iaload
    //   24: invokestatic llllIllIIlllIll : (II)Z
    //   27: ifeq -> 41
    //   30: getstatic me/stupitdog/bhp/au.lIllIlllIlIlII : [Ljava/lang/String;
    //   33: getstatic me/stupitdog/bhp/au.lIllIlllIllllI : [I
    //   36: bipush #11
    //   38: iaload
    //   39: aaload
    //   40: areturn
    //   41: aload_0
    //   42: <illegal opcode> 47 : (Lme/stupitdog/bhp/au;)I
    //   47: <illegal opcode> 51 : (I)Ljava/lang/String;
    //   52: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	53	0	lllllllllllllllIllllIIIllIIIllll	Lme/stupitdog/bhp/au;
  }
  
  static {
    // Byte code:
    //   0: invokestatic llllIllIIllIlII : ()V
    //   3: invokestatic llllIllIIllIIll : ()V
    //   6: invokestatic llllIllIIllIIlI : ()V
    //   9: invokestatic llllIllIIlIIIlI : ()V
    //   12: <illegal opcode> 52 : ()Lnet/minecraft/client/Minecraft;
    //   17: <illegal opcode> 53 : (Lnet/minecraft/client/Minecraft;)V
    //   22: return
  }
  
  private static CallSite llllIlIlllIIIlI(MethodHandles.Lookup lllllllllllllllIllllIIIllIIIIllI, String lllllllllllllllIllllIIIllIIIIlIl, MethodType lllllllllllllllIllllIIIllIIIIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIIllIIIllII = lIllIllIllIlll[Integer.parseInt(lllllllllllllllIllllIIIllIIIIlIl)].split(lIllIlllIlIlII[lIllIlllIllllI[12]]);
      Class<?> lllllllllllllllIllllIIIllIIIlIll = Class.forName(lllllllllllllllIllllIIIllIIIllII[lIllIlllIllllI[0]]);
      String lllllllllllllllIllllIIIllIIIlIlI = lllllllllllllllIllllIIIllIIIllII[lIllIlllIllllI[1]];
      MethodHandle lllllllllllllllIllllIIIllIIIlIIl = null;
      int lllllllllllllllIllllIIIllIIIlIII = lllllllllllllllIllllIIIllIIIllII[lIllIlllIllllI[3]].length();
      if (llllIllIIllllIl(lllllllllllllllIllllIIIllIIIlIII, lIllIlllIllllI[2])) {
        MethodType lllllllllllllllIllllIIIllIIIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIIllIIIllII[lIllIlllIllllI[2]], au.class.getClassLoader());
        if (llllIllIIlllllI(lllllllllllllllIllllIIIllIIIlIII, lIllIlllIllllI[2])) {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findVirtual(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIlllI);
          "".length();
          if (-" ".length() > " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findStatic(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIlllI);
        } 
        "".length();
        if ("   ".length() < "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIIllIIIllIl = lIllIllIlllIII[Integer.parseInt(lllllllllllllllIllllIIIllIIIllII[lIllIlllIllllI[2]])];
        if (llllIllIIlllllI(lllllllllllllllIllllIIIllIIIlIII, lIllIlllIllllI[3])) {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findGetter(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIllIl);
          "".length();
          if (" ".length() <= -" ".length())
            return null; 
        } else if (llllIllIIlllllI(lllllllllllllllIllllIIIllIIIlIII, lIllIlllIllllI[4])) {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findStaticGetter(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIllIl);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (llllIllIIlllllI(lllllllllllllllIllllIIIllIIIlIII, lIllIlllIllllI[5])) {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findSetter(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllllIIIllIIIlIIl = lllllllllllllllIllllIIIllIIIIllI.findStaticSetter(lllllllllllllllIllllIIIllIIIlIll, lllllllllllllllIllllIIIllIIIlIlI, lllllllllllllllIllllIIIllIIIllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIIllIIIlIIl);
    } catch (Exception lllllllllllllllIllllIIIllIIIIlll) {
      lllllllllllllllIllllIIIllIIIIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIIlIIIlI() {
    lIllIllIllIlll = new String[lIllIlllIllllI[13]];
    lIllIllIllIlll[lIllIlllIllllI[11]] = lIllIlllIlIlII[lIllIlllIllllI[14]];
    lIllIllIllIlll[lIllIlllIllllI[15]] = lIllIlllIlIlII[lIllIlllIllllI[16]];
    lIllIllIllIlll[lIllIlllIllllI[17]] = lIllIlllIlIlII[lIllIlllIllllI[18]];
    lIllIllIllIlll[lIllIlllIllllI[4]] = lIllIlllIlIlII[lIllIlllIllllI[19]];
    lIllIllIllIlll[lIllIlllIllllI[20]] = lIllIlllIlIlII[lIllIlllIllllI[21]];
    lIllIllIllIlll[lIllIlllIllllI[22]] = lIllIlllIlIlII[lIllIlllIllllI[23]];
    lIllIllIllIlll[lIllIlllIllllI[24]] = lIllIlllIlIlII[lIllIlllIllllI[25]];
    lIllIllIllIlll[lIllIlllIllllI[18]] = lIllIlllIlIlII[lIllIlllIllllI[20]];
    lIllIllIllIlll[lIllIlllIllllI[26]] = lIllIlllIlIlII[lIllIlllIllllI[27]];
    lIllIllIllIlll[lIllIlllIllllI[21]] = lIllIlllIlIlII[lIllIlllIllllI[28]];
    lIllIllIllIlll[lIllIlllIllllI[29]] = lIllIlllIlIlII[lIllIlllIllllI[30]];
    lIllIllIllIlll[lIllIlllIllllI[31]] = lIllIlllIlIlII[lIllIlllIllllI[32]];
    lIllIllIllIlll[lIllIlllIllllI[5]] = lIllIlllIlIlII[lIllIlllIllllI[33]];
    lIllIllIllIlll[lIllIlllIllllI[34]] = lIllIlllIlIlII[lIllIlllIllllI[17]];
    lIllIllIllIlll[lIllIlllIllllI[35]] = lIllIlllIlIlII[lIllIlllIllllI[22]];
    lIllIllIllIlll[lIllIlllIllllI[36]] = lIllIlllIlIlII[lIllIlllIllllI[37]];
    lIllIllIllIlll[lIllIlllIllllI[23]] = lIllIlllIlIlII[lIllIlllIllllI[34]];
    lIllIllIllIlll[lIllIlllIllllI[33]] = lIllIlllIlIlII[lIllIlllIllllI[38]];
    lIllIllIllIlll[lIllIlllIllllI[39]] = lIllIlllIlIlII[lIllIlllIllllI[40]];
    lIllIllIllIlll[lIllIlllIllllI[41]] = lIllIlllIlIlII[lIllIlllIllllI[42]];
    lIllIllIllIlll[lIllIlllIllllI[25]] = lIllIlllIlIlII[lIllIlllIllllI[29]];
    lIllIllIllIlll[lIllIlllIllllI[40]] = lIllIlllIlIlII[lIllIlllIllllI[43]];
    lIllIllIllIlll[lIllIlllIllllI[0]] = lIllIlllIlIlII[lIllIlllIllllI[44]];
    lIllIllIllIlll[lIllIlllIllllI[45]] = lIllIlllIlIlII[lIllIlllIllllI[46]];
    lIllIllIllIlll[lIllIlllIllllI[47]] = lIllIlllIlIlII[lIllIlllIllllI[48]];
    lIllIllIllIlll[lIllIlllIllllI[48]] = lIllIlllIlIlII[lIllIlllIllllI[49]];
    lIllIllIllIlll[lIllIlllIllllI[42]] = lIllIlllIlIlII[lIllIlllIllllI[24]];
    lIllIllIllIlll[lIllIlllIllllI[50]] = lIllIlllIlIlII[lIllIlllIllllI[51]];
    lIllIllIllIlll[lIllIlllIllllI[27]] = lIllIlllIlIlII[lIllIlllIllllI[31]];
    lIllIllIllIlll[lIllIlllIllllI[12]] = lIllIlllIlIlII[lIllIlllIllllI[41]];
    lIllIllIllIlll[lIllIlllIllllI[52]] = lIllIlllIlIlII[lIllIlllIllllI[26]];
    lIllIllIllIlll[lIllIlllIllllI[16]] = lIllIlllIlIlII[lIllIlllIllllI[53]];
    lIllIllIllIlll[lIllIlllIllllI[44]] = lIllIlllIlIlII[lIllIlllIllllI[35]];
    lIllIllIllIlll[lIllIlllIllllI[28]] = lIllIlllIlIlII[lIllIlllIllllI[54]];
    lIllIllIllIlll[lIllIlllIllllI[54]] = lIllIlllIlIlII[lIllIlllIllllI[55]];
    lIllIllIllIlll[lIllIlllIllllI[51]] = lIllIlllIlIlII[lIllIlllIllllI[50]];
    lIllIllIllIlll[lIllIlllIllllI[32]] = lIllIlllIlIlII[lIllIlllIllllI[36]];
    lIllIllIllIlll[lIllIlllIllllI[46]] = lIllIlllIlIlII[lIllIlllIllllI[39]];
    lIllIllIllIlll[lIllIlllIllllI[55]] = lIllIlllIlIlII[lIllIlllIllllI[15]];
    lIllIllIllIlll[lIllIlllIllllI[6]] = lIllIlllIlIlII[lIllIlllIllllI[56]];
    lIllIllIllIlll[lIllIlllIllllI[57]] = lIllIlllIlIlII[lIllIlllIllllI[57]];
    lIllIllIllIlll[lIllIlllIllllI[30]] = lIllIlllIlIlII[lIllIlllIllllI[47]];
    lIllIllIllIlll[lIllIlllIllllI[49]] = lIllIlllIlIlII[lIllIlllIllllI[52]];
    lIllIllIllIlll[lIllIlllIllllI[38]] = lIllIlllIlIlII[lIllIlllIllllI[45]];
    lIllIllIllIlll[lIllIlllIllllI[37]] = lIllIlllIlIlII[lIllIlllIllllI[58]];
    lIllIllIllIlll[lIllIlllIllllI[53]] = lIllIlllIlIlII[lIllIlllIllllI[13]];
    lIllIllIllIlll[lIllIlllIllllI[3]] = lIllIlllIlIlII[lIllIlllIllllI[59]];
    lIllIllIllIlll[lIllIlllIllllI[1]] = lIllIlllIlIlII[lIllIlllIllllI[60]];
    lIllIllIllIlll[lIllIlllIllllI[19]] = lIllIlllIlIlII[lIllIlllIllllI[61]];
    lIllIllIllIlll[lIllIlllIllllI[58]] = lIllIlllIlIlII[lIllIlllIllllI[62]];
    lIllIllIllIlll[lIllIlllIllllI[56]] = lIllIlllIlIlII[lIllIlllIllllI[63]];
    lIllIllIllIlll[lIllIlllIllllI[14]] = lIllIlllIlIlII[lIllIlllIllllI[64]];
    lIllIllIllIlll[lIllIlllIllllI[43]] = lIllIlllIlIlII[lIllIlllIllllI[65]];
    lIllIllIllIlll[lIllIlllIllllI[2]] = lIllIlllIlIlII[lIllIlllIllllI[66]];
    lIllIllIlllIII = new Class[lIllIlllIllllI[21]];
    lIllIllIlllIII[lIllIlllIllllI[1]] = f13.class;
    lIllIllIlllIII[lIllIlllIllllI[12]] = av.class;
    lIllIllIlllIII[lIllIlllIllllI[5]] = EventBus.class;
    lIllIllIlllIII[lIllIlllIllllI[19]] = f1000000000000000000000.class;
    lIllIllIlllIII[lIllIlllIllllI[16]] = Minecraft.class;
    lIllIllIlllIII[lIllIlllIllllI[3]] = f100000000000000000000.Boolean.class;
    lIllIllIlllIII[lIllIlllIllllI[0]] = String.class;
    lIllIllIlllIII[lIllIlllIllllI[18]] = WorldClient.class;
    lIllIllIlllIII[lIllIlllIllllI[11]] = f9.class;
    lIllIllIlllIII[lIllIlllIllllI[6]] = boolean.class;
    lIllIllIlllIII[lIllIlllIllllI[4]] = EventManager.class;
    lIllIllIlllIII[lIllIlllIllllI[2]] = int.class;
    lIllIllIlllIII[lIllIlllIllllI[14]] = TextFormatting.class;
  }
  
  private static void llllIllIIllIIlI() {
    lIllIlllIlIlII = new String[lIllIlllIllllI[67]];
    lIllIlllIlIlII[lIllIlllIllllI[0]] = llllIllIIlIIIll(lIllIlllIlllIl[lIllIlllIllllI[0]], lIllIlllIlllIl[lIllIlllIllllI[1]]);
    lIllIlllIlIlII[lIllIlllIllllI[1]] = llllIllIIlIIlII(lIllIlllIlllIl[lIllIlllIllllI[2]], lIllIlllIlllIl[lIllIlllIllllI[3]]);
    lIllIlllIlIlII[lIllIlllIllllI[2]] = llllIllIIlIIlII(lIllIlllIlllIl[lIllIlllIllllI[4]], lIllIlllIlllIl[lIllIlllIllllI[5]]);
    lIllIlllIlIlII[lIllIlllIllllI[3]] = llllIllIIlIIIll(lIllIlllIlllIl[lIllIlllIllllI[6]], lIllIlllIlllIl[lIllIlllIllllI[11]]);
    lIllIlllIlIlII[lIllIlllIllllI[4]] = llllIllIIlIIlIl(lIllIlllIlllIl[lIllIlllIllllI[12]], lIllIlllIlllIl[lIllIlllIllllI[14]]);
    lIllIlllIlIlII[lIllIlllIllllI[5]] = llllIllIIlIIlIl(lIllIlllIlllIl[lIllIlllIllllI[16]], lIllIlllIlllIl[lIllIlllIllllI[18]]);
    lIllIlllIlIlII[lIllIlllIllllI[6]] = llllIllIIlIIlII(lIllIlllIlllIl[lIllIlllIllllI[19]], lIllIlllIlllIl[lIllIlllIllllI[21]]);
    lIllIlllIlIlII[lIllIlllIllllI[11]] = llllIllIIlIIIll(lIllIlllIlllIl[lIllIlllIllllI[23]], lIllIlllIlllIl[lIllIlllIllllI[25]]);
    lIllIlllIlIlII[lIllIlllIllllI[12]] = llllIllIIlIIIll(lIllIlllIlllIl[lIllIlllIllllI[20]], lIllIlllIlllIl[lIllIlllIllllI[27]]);
    lIllIlllIlIlII[lIllIlllIllllI[14]] = llllIllIIlIIlIl(lIllIlllIlllIl[lIllIlllIllllI[28]], lIllIlllIlllIl[lIllIlllIllllI[30]]);
    lIllIlllIlIlII[lIllIlllIllllI[16]] = llllIllIIlIIlII(lIllIlllIlllIl[lIllIlllIllllI[32]], lIllIlllIlllIl[lIllIlllIllllI[33]]);
    lIllIlllIlIlII[lIllIlllIllllI[18]] = llllIllIIlIIlIl(lIllIlllIlllIl[lIllIlllIllllI[17]], lIllIlllIlllIl[lIllIlllIllllI[22]]);
    lIllIlllIlIlII[lIllIlllIllllI[19]] = llllIllIIlIIIll(lIllIlllIlllIl[lIllIlllIllllI[37]], lIllIlllIlllIl[lIllIlllIllllI[34]]);
    lIllIlllIlIlII[lIllIlllIllllI[21]] = llllIllIIlIIlII("uAmHfdqD34AOFWdpLDEgl8b+Ml0z5+lWbkwrApiqxNrmMo6hF8oqcg==", "GCUsK");
    lIllIlllIlIlII[lIllIlllIllllI[23]] = llllIllIIlIIlIl("o0tUwAUPVlqZTumDInjO/aUBWTDNDpF/2qNAISzqTqj0KGRKss+y3A==", "QOsiK");
    lIllIlllIlIlII[lIllIlllIllllI[25]] = llllIllIIlIIIll("PSloAjslPC8FKz8raBMnIGIgQH9gfHZBf2B8fB0uIzgIHjs5Ki8SLiQlKR91YHZmUW9wbGY=", "PLFqO");
    lIllIlllIlIlII[lIllIlllIllllI[20]] = llllIllIIlIIlIl("QicyUu7Q11PhRA9zn6DYagVIDGixk1nUPneJjEm1+6ELlZ0Tm5QWnwkaFXkjkyA3Mg9HHrIWf1R2exhrOYhBFg==", "qgZhU");
    lIllIlllIlIlII[lIllIlllIllllI[27]] = llllIllIIlIIIll("FyQEYzQQLxUuKxgnBGMsDSgcYy0cOQRjDRw5BAs2CywROS0QLxd3CzwFSnRjWWFQbQ==", "yApMY");
    lIllIlllIlIlII[lIllIlllIllllI[28]] = llllIllIIlIIIll("PQZZFSElEx4SMT8EWQQ9IE0WE28/DTIINDIPElx9eTVNRnU=", "PcwfU");
    lIllIlllIlIlII[lIllIlllIllllI[30]] = llllIllIIlIIlII("YPxKpM1m2rLkIBGU+UUAs96I+VXw9IGaWOrzVwJjl4usx6bV0EqPrVNlD3yT5kRNcjasNyBv7KP79Zj2O6f4WcIDVSGZvZ1r1L0EL7Oc/Pw=", "VwdKi");
    lIllIlllIlIlII[lIllIlllIllllI[32]] = llllIllIIlIIlII("2QSzDoLzQJGlPTjHk4GKsRPppRKRGFV1j11OXFjRQC0=", "EfMFM");
    lIllIlllIlIlII[lIllIlllIllllI[33]] = llllIllIIlIIlII("TECR7/KeUW6GUX1b3w+/VUZvKJXZdBlFopNm67wSfwNFO0e+6vm7xn00rkCoV0FW0yZLRAkXXe9V5MGJNVqrQC6Xq29kFzLMCHClwmC3AkAxObRP+Kt+UTE5tE/4q35ROAh4xtdAho6WnHNTuZ4B2w==", "gUZCk");
    lIllIlllIlIlII[lIllIlllIllllI[17]] = llllIllIIlIIlIl("WZDcUzEO2btH1gpmnPgaa/k49zos0A7NQFDshoGU7QrrgaPqPSYH4Q==", "UJBQQ");
    lIllIlllIlIlII[lIllIlllIllllI[22]] = llllIllIIlIIlII("ajJmlQ2iZLOIalDhYqfud1A+hRaIqOvaQoO845GXHMc+sd5Ngji3Mg==", "noZhL");
    lIllIlllIlIlII[lIllIlllIllllI[37]] = llllIllIIlIIlII("ohHmHCNemj/5mXgqQZ75n1ZZDEHgAeAKguuxQbYBF9QaML5pHkgM7L6t0IN1toJmd60MLgeaiOf8VU9WabWAwA==", "OkmPe");
    lIllIlllIlIlII[lIllIlllIllllI[34]] = llllIllIIlIIlII("lrIK2jioIgN3XYNoajx5Ab5ESN8fpLI0P6C2Oqlw6DH6hZjYwLVlVslcy5h0uDcMQuiW4O9aw1D/P7Wrs/5X9LjOd7apRS6F", "UOvsM");
    lIllIlllIlIlII[lIllIlllIllllI[38]] = llllIllIIlIIlIl("eHt3j9ovm0M8zR78a0ellikrUJSxz/Wr0DPnBnHc4qDuKW7yqQ0zZg==", "TuDwn");
    lIllIlllIlIlII[lIllIlllIllllI[40]] = llllIllIIlIIIll("JStYPgU9Ph85FScpWC8ZOGAQfEF4fkZ9QXh+Rn1BeH5GfUF4fkZ9VQohGSEUKSBMPhQ8GBchBC10XhdYHnRWbQ==", "HNvMq");
    lIllIlllIlIlII[lIllIlllIllllI[42]] = llllIllIIlIIlIl("8IdkE3nibEXpkYAFJMVLu9eFZ5Q0pzeDxxkBrrhXqLyyxYHg2ehJOVRyZZEXxQT8nHiS++DK8xM=", "kcWrX");
    lIllIlllIlIlII[lIllIlllIllllI[29]] = llllIllIIlIIIll("HhUdaSYZHgwkOREWHSEkAhcMaS0dHEckJB0dBillFQYMKT8YEQcjJxUCRwI9FR4dBT4DShwpORUXADQ/FQJTbwcaER8mZBwRByBkPxIDIigES0ARcVBQ", "ppiGK");
    lIllIlllIlIlII[lIllIlllIllllI[43]] = llllIllIIlIIlII("vflLh9bxFnwsoKNaZJRWWx+8BO8iGTzZxbt9RF62O7wCibM4C3L18/32JqKF3aqI1MAEH9HsE+0=", "fqvLR");
    lIllIlllIlIlII[lIllIlllIllllI[44]] = llllIllIIlIIlIl("7sHYXo47vNcZI44WKDFSEBdCEKjFsdL8JYs9JE5d/Iozxd2Y7eUnRg==", "UvMaL");
    lIllIlllIlIlII[lIllIlllIllllI[46]] = llllIllIIlIIlIl("knUtjqEpMIZlPZTg4QvtxYDK1w3PWHwydPMxPrbUke2zoFaEEPZIwpMOaVWy6ej8zmvAdS+svD2LJoZsNPowmFyrEj6ujqsK0VWWW+XZhsSNC/slY+jB+g==", "aTgRJ");
    lIllIlllIlIlII[lIllIlllIllllI[48]] = llllIllIIlIIIll("CgZtAyQSEyoENAgEbRI4F00iBWoVBiQZIxMGMTM/CwwxSngrCSIGMUgPIh43SDA3AjkJBHg8PQJMMAQlFwo3FD8ATCEYIEgFc0FrTi8uFX8UFzYAORMHLBd/BQszXzZWU3NAYFdTc0BgV1NzQGBXU3NAYFdHAB88CBEQFSQTCi0Xa11DYw==", "gcCpP");
    lIllIlllIlIlII[lIllIlllIllllI[49]] = llllIllIIlIIIll("NCdaNz0sMh0wLTYlWiYhKWwVMHMqJxogCjEjAAksKjEVIyxjajguKC8jWygoNyVbFz0rKxojcnAUTmQ=", "YBtDI");
    lIllIlllIlIlII[lIllIlllIllllI[24]] = llllIllIIlIIlII("AVM2KbLeJSylB20Se//5iLhRX4lJc0s8gvCPpBsAl3t81hDMYQahdd8pZpv6WxoisC1kqXyO9n8=", "aujXx");
    lIllIlllIlIlII[lIllIlllIllllI[51]] = llllIllIIlIIlII("kb7QV9dnAH6VfTg37KEpsgjAIrnwl+b3GEKMFeS7zMI=", "DSKpY");
    lIllIlllIlIlII[lIllIlllIllllI[31]] = llllIllIIlIIlIl("+lURFRpjNXU46i61FPormFNvKWFWpC/OZoUcz9eg3nQacQSkCMF65Q==", "IYrzW");
    lIllIlllIlIlII[lIllIlllIllllI[41]] = llllIllIIlIIIll("LCBLODk0NQw/KS4iSyklMWsEPncyIBEfIiYiCS4pe20/Yht7ZUU=", "AEeKM");
    lIllIlllIlIlII[lIllIlllIllllI[26]] = llllIllIIlIIlIl("eYPnqKUeU4W7Czh22vfMRuvK9zn6qfiVgHzHi5/hodpq79qrp0eh4M6GTVZwUPwmABFT3zpnNmHVPcVtLH1q9w==", "UlRjx");
    lIllIlllIlIlII[lIllIlllIllllI[53]] = llllIllIIlIIlIl("5gL2BVtNlwD+vC9AG7wb+I4PaoBvf4Sk2oSMHosis1m883bw43rnzgPdnqQm7QT4Nl7wuCcaheJLQdtIBp6O9g==", "ffxrL");
    lIllIlllIlIlII[lIllIlllIllllI[35]] = llllIllIIlIIIll("ODwQaTk/NwEkJjc/EGkhIjAIaSAzIRBpADMhEAE7JDQFMyA/NwN9Ax4QMAJub2NEZ3R2", "VYdGT");
    lIllIlllIlIlII[lIllIlllIllllI[54]] = llllIllIIlIIlIl("tGiLor0bs70nXIHN36IZ6jx13Mvzou+u/KKXXFvPPdK7bW+G3BHLcw==", "ZpYxl");
    lIllIlllIlIlII[lIllIlllIllllI[55]] = llllIllIIlIIlII("oIBSI37Ig5tO2RvHqeaQHPYCRe58vbsPSxzGM7sgC405msXTkmoZfw==", "OKlwp");
    lIllIlllIlIlII[lIllIlllIllllI[50]] = llllIllIIlIIlIl("mSl/94gdccHJ7ZlP3+pPSdWXnNLvdgeEkXYl3OEA0Cvsl0kdSKsLbA==", "AJlFW");
    lIllIlllIlIlII[lIllIlllIllllI[36]] = llllIllIIlIIlIl("pBbg3aaqgobi+RL3mNN4w71B7dreMXfwW6TAjgaoggPYK2X10gpmWQ==", "uoPnO");
    lIllIlllIlIlII[lIllIlllIllllI[39]] = llllIllIIlIIlIl("KV+3gZQgGsqD1svUj1A0Ek7hut5hZafFWSdLgSRlccVCiMx3wg2hS+3MNSkuxYILifhmtVG41YsWTZwlpgtmew==", "tCBvT");
    lIllIlllIlIlII[lIllIlllIllllI[15]] = llllIllIIlIIlII("iiuppoNZl4jM4uOJK3e2YiiVu3uQNYscwBUiE5DIYPwCCs7+76Oy+Q==", "kScgi");
    lIllIlllIlIlII[lIllIlllIllllI[56]] = llllIllIIlIIlIl("TJkRJgPrG+i4MTIddqrj7IarTV/5AjTXX3vU0K+jIxgZbuPuV9OsOA==", "yluIY");
    lIllIlllIlIlII[lIllIlllIllllI[57]] = llllIllIIlIIIll("JhdsBQA+AisCECQVbBQcO1wkR0R7QnJGRHtCckZEe0JyRkR7QnJGRHETJhInLgY2HxosSGo6GS5dMQIBOxs2EhssXSAeBGQUc0ZEe0JyRkR7QnJGRHtCckZEe0JyTV0dSGJW", "KrBvt");
    lIllIlllIlIlII[lIllIlllIllllI[47]] = llllIllIIlIIlIl("43IurG5eOd5arQUQVyEgCmmVsw8wb04DaMW+4JLMxI81jO4OGivaHg==", "GaVfB");
    lIllIlllIlIlII[lIllIlllIllllI[52]] = llllIllIIlIIlII("L11ayD5PDREdNaka06hDrfBbpX9MEBlzY7QLd84QqzA7Ww0R4KeiEfwVUOW5WIIQ6EH9sajyA+OG4RRwcGAiog==", "BHmIC");
    lIllIlllIlIlII[lIllIlllIllllI[45]] = llllIllIIlIIlII("/Pc4lM0KD+MsYpHbipmZW75rs/zjk81L5RrnzESkeJDb0eKMrzL6Xy1QgNNrppHDUMvS15gnrmc=", "wFMRE");
    lIllIlllIlIlII[lIllIlllIllllI[58]] = llllIllIIlIIlIl("M+Ws7pHu8O5EuxAdAne51ZQrvWNgiiVFu7yao/5UYdq2aMt/T16A5wES/ABGrxKYvRwLlMFQYyv980+nC37ScQ==", "EBoaK");
    lIllIlllIlIlII[lIllIlllIllllI[13]] = llllIllIIlIIlIl("mG8PotPOe/JMoRKM3InI03YApTNKLzrEojTvNk5tLhY=", "ShFhu");
    lIllIlllIlIlII[lIllIlllIllllI[59]] = llllIllIIlIIlIl("hb7SQ8faorkpaDrJjLzs8Fa6tlyBldVNlfx4dXGwee6zrEtC1IwwGw==", "vIJIu");
    lIllIlllIlIlII[lIllIlllIllllI[60]] = llllIllIIlIIlII("tkdXrfK8wGArxixfBD/Jz7094MCk2S+98UfWowsbfOEUf0oy6omVxw==", "JdkFf");
    lIllIlllIlIlII[lIllIlllIllllI[61]] = llllIllIIlIIIll("BCsDRj0DIBILIgsoAw4/GCkSRjYHIlkLPwcjGAZ+DzgSBiQCLxkMPA88WS0mDyADKiUZdAUNNwM9Aw0iUGY7AjEcL1gEMQQpWCcyACsUHGtDGE1IcA==", "jNwhP");
    lIllIlllIlIlII[lIllIlllIllllI[62]] = llllIllIIlIIlII("8qbxskHdh5YbK3xLxOXuci2cGVRB24TL+5KKHaYu7f2MIT0yGZZqag==", "kPPsf");
    lIllIlllIlIlII[lIllIlllIllllI[63]] = llllIllIIlIIlIl("s/oE7l4X9sYOSy6zEOYEhuHQ2gUyDFld8uhGNUXzxh31kMkJEKn97q+bku0yMdCL", "utjcb");
    lIllIlllIlIlII[lIllIlllIllllI[64]] = llllIllIIlIIlII("gwUTNSTsjJ4UHkx2E/bvTZC3lFHeqOHnRR0JGkn+y1nJOiYzea33Mg==", "DZdSr");
    lIllIlllIlIlII[lIllIlllIllllI[65]] = llllIllIIlIIIll("MgIVKW80Ag0vbwsXESEvPyEWIS08BhFyICgTBiYlYksvIiAuAkwkIDYETBs1KgoNL3pxLwkpNzlMDykvP0wwPDMxDQQKNDEPBy0zY1lDaA==", "XccHA");
    lIllIlllIlIlII[lIllIlllIllllI[66]] = llllIllIIlIIIll("JSFHJiY9NAAhNicjRzc6OGoIIGgsIRo2ICE0HTw9Jn5Zb3JoZEl1", "HDiUR");
    lIllIlllIlllIl = null;
  }
  
  private static void llllIllIIllIIll() {
    String str = (new Exception()).getStackTrace()[lIllIlllIllllI[0]].getFileName();
    lIllIlllIlllIl = str.substring(str.indexOf("ä") + lIllIlllIllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIllIIlIIlII(String lllllllllllllllIllllIIIllIIIIIII, String lllllllllllllllIllllIIIlIlllllll) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIllIIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIlllllll.getBytes(StandardCharsets.UTF_8)), lIllIlllIllllI[12]), "DES");
      Cipher lllllllllllllllIllllIIIllIIIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllllIIIllIIIIIlI.init(lIllIlllIllllI[2], lllllllllllllllIllllIIIllIIIIIll);
      return new String(lllllllllllllllIllllIIIllIIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIllIIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIllIIIIIIl) {
      lllllllllllllllIllllIIIllIIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIllIIlIIIll(String lllllllllllllllIllllIIIlIlllllIl, String lllllllllllllllIllllIIIlIlllllII) {
    lllllllllllllllIllllIIIlIlllllIl = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIlllllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIIlIllllIll = new StringBuilder();
    char[] lllllllllllllllIllllIIIlIllllIlI = lllllllllllllllIllllIIIlIlllllII.toCharArray();
    int lllllllllllllllIllllIIIlIllllIIl = lIllIlllIllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIIlIlllllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlllIllllI[0];
    while (llllIllIIllllll(j, i)) {
      char lllllllllllllllIllllIIIlIllllllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIIlIllllIIl++;
      j++;
      "".length();
      if ((((0xFB ^ 0x9E) << " ".length() ^ 12 + 99 - 58 + 88) & ((0xAE ^ 0xB5) << " ".length() ^ 0x6 ^ 0x77 ^ -" ".length())) != ((154 + 59 - 136 + 176 ^ (0x12 ^ 0x7) << "   ".length()) & (0x6C ^ 0x35 ^ "   ".length() << " ".length() << " ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIIlIllllIll);
  }
  
  private static String llllIllIIlIIlIl(String lllllllllllllllIllllIIIlIlllIlIl, String lllllllllllllllIllllIIIlIlllIlII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIlIllllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIlllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIIlIlllIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIIlIlllIlll.init(lIllIlllIllllI[2], lllllllllllllllIllllIIIlIllllIII);
      return new String(lllllllllllllllIllllIIIlIlllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIlllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIlIlllIllI) {
      lllllllllllllllIllllIIIlIlllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIllIIllIlII() {
    lIllIlllIllllI = new int[68];
    lIllIlllIllllI[0] = (0x17 ^ 0x74) & (0x4C ^ 0x2F ^ 0xFFFFFFFF);
    lIllIlllIllllI[1] = " ".length();
    lIllIlllIllllI[2] = " ".length() << " ".length();
    lIllIlllIllllI[3] = "   ".length();
    lIllIlllIllllI[4] = " ".length() << " ".length() << " ".length();
    lIllIlllIllllI[5] = 0x70 ^ 0x6B ^ (0x5D ^ 0x52) << " ".length();
    lIllIlllIllllI[6] = "   ".length() << " ".length();
    lIllIlllIllllI[7] = (0x84 ^ 0xA9) << " ".length();
    lIllIlllIllllI[8] = 35 + 107 - 61 + 64;
    lIllIlllIllllI[9] = (0x1B ^ 0x14) << " ".length() << " ".length() << " ".length();
    lIllIlllIllllI[10] = 60 + 66 - 16 + 143 + ((0x84 ^ 0xBB) << " ".length() << " ".length()) - (86 + 51 - 135 + 125 << " ".length()) + (" ".length() << " ".length() << " ".length());
    lIllIlllIllllI[11] = (0xD2 ^ 0x87) << " ".length() ^ 12 + 33 - 36 + 164;
    lIllIlllIllllI[12] = " ".length() << "   ".length();
    lIllIlllIllllI[13] = (0x66 ^ 0x7D) << " ".length();
    lIllIlllIllllI[14] = 0x96 ^ 0x9F;
    lIllIlllIllllI[15] = 0x63 ^ 0x4C;
    lIllIlllIllllI[16] = (66 + 141 - 60 + 8 ^ (0xC2 ^ 0x8D) << " ".length()) << " ".length();
    lIllIlllIllllI[17] = (0x13 ^ 0x18) << " ".length();
    lIllIlllIllllI[18] = (0x47 ^ 0x48) << " ".length() << " ".length() ^ 0x34 ^ 0x3;
    lIllIlllIllllI[19] = "   ".length() << " ".length() << " ".length();
    lIllIlllIllllI[20] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIlllIllllI[21] = (0x70 ^ 0x59) << " ".length() << " ".length() ^ 30 + 117 - 81 + 103;
    lIllIlllIllllI[22] = 0x53 ^ 0x44;
    lIllIlllIllllI[23] = (0x18 ^ 0x1F) << " ".length();
    lIllIlllIllllI[24] = 48 + 41 - 55 + 129 ^ " ".length() << (0xB6 ^ 0xB1);
    lIllIlllIllllI[25] = 0x58 ^ 0x57;
    lIllIlllIllllI[26] = 0x36 ^ 0x21 ^ "   ".length() << " ".length() << " ".length() << " ".length();
    lIllIlllIllllI[27] = 0x96 ^ 0x87;
    lIllIlllIllllI[28] = (0x27 ^ 0x2E) << " ".length();
    lIllIlllIllllI[29] = 0x14 ^ 0x9;
    lIllIlllIllllI[30] = 0x2F ^ 0x78 ^ (0x7B ^ 0x6A) << " ".length() << " ".length();
    lIllIlllIllllI[31] = 133 + 82 - 71 + 39 ^ (0x50 ^ 0x19) << " ".length();
    lIllIlllIllllI[32] = (0x72 ^ 0x77) << " ".length() << " ".length();
    lIllIlllIllllI[33] = 0x3B ^ 0x2E;
    lIllIlllIllllI[34] = 0xDD ^ 0xC4;
    lIllIlllIllllI[35] = 111 + 47 - 50 + 29 ^ (0x9 ^ 0xC) << (0x21 ^ 0x24);
    lIllIlllIllllI[36] = (0x9A ^ 0x85) << " ".length() ^ 0x6D ^ 0x7E;
    lIllIlllIllllI[37] = "   ".length() << "   ".length();
    lIllIlllIllllI[38] = (0xB2 ^ 0xBF) << " ".length();
    lIllIlllIllllI[39] = (0xA9 ^ 0xBE) << " ".length();
    lIllIlllIllllI[40] = 0x31 ^ 0x2A;
    lIllIlllIllllI[41] = (0x9 ^ 0x1A) << " ".length();
    lIllIlllIllllI[42] = ((0xCA ^ 0xC7) << " ".length() << " ".length() ^ 0x31 ^ 0x2) << " ".length() << " ".length();
    lIllIlllIllllI[43] = (0xD6 ^ 0xC7 ^ (0x70 ^ 0x7F) << " ".length()) << " ".length();
    lIllIlllIllllI[44] = 11 + 119 - 102 + 107 ^ (0x3A ^ 0x29) << "   ".length();
    lIllIlllIllllI[45] = (0x56 ^ 0x5B) << " ".length() << " ".length();
    lIllIlllIllllI[46] = " ".length() << (0xAA ^ 0xAF);
    lIllIlllIllllI[47] = (0xDF ^ 0xC6) << " ".length();
    lIllIlllIllllI[48] = (0x56 ^ 0x77) << " ".length() << " ".length() ^ 138 + 148 - 183 + 62;
    lIllIlllIllllI[49] = (111 + 34 - 81 + 79 ^ (0xD1 ^ 0x9E) << " ".length()) << " ".length();
    lIllIlllIllllI[50] = (0x3 ^ 0x8) << " ".length() << " ".length();
    lIllIlllIllllI[51] = ((0x3D ^ 0x66) << " ".length() ^ 25 + 128 - 106 + 144) << " ".length() << " ".length();
    lIllIlllIllllI[52] = 107 + 103 - 73 + 20 ^ (0xD ^ 0x5A) << " ".length();
    lIllIlllIllllI[53] = (0xA ^ 0x51 ^ (0x61 ^ 0x4E) << " ".length()) << "   ".length();
    lIllIlllIllllI[54] = (101 + 177 - 154 + 67 ^ (0x2A ^ 0x7F) << " ".length()) << " ".length();
    lIllIlllIllllI[55] = " ".length() << (0xC5 ^ 0xC0) ^ 0xBE ^ 0xB5;
    lIllIlllIllllI[56] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIllIlllIllllI[57] = (0x20 ^ 0x71) << " ".length() ^ 59 + 61 - 62 + 89;
    lIllIlllIllllI[58] = 0x1D ^ 0x28;
    lIllIlllIllllI[59] = (0x11 ^ 0x58) << " ".length() ^ 122 + 111 - 107 + 39;
    lIllIlllIllllI[60] = ((0x4C ^ 0x47) << "   ".length() ^ 0xDA ^ 0x85) << "   ".length();
    lIllIlllIllllI[61] = 0x7E ^ 0x47;
    lIllIlllIllllI[62] = (0x95 ^ 0x88) << " ".length();
    lIllIlllIllllI[63] = 0xD ^ 0x36;
    lIllIlllIllllI[64] = ((0x61 ^ 0x6A) << " ".length() << " ".length() << " ".length() ^ 64 + 31 - 14 + 110) << " ".length() << " ".length();
    lIllIlllIllllI[65] = (0xA ^ 0x1) << "   ".length() ^ 0xC6 ^ 0xA3;
    lIllIlllIllllI[66] = ((0x9A ^ 0x89) << "   ".length() ^ 74 + 44 - -2 + 15) << " ".length();
    lIllIlllIllllI[67] = 126 + 30 - 87 + 90 ^ (0x80 ^ 0x85) << (0xE ^ 0xB);
  }
  
  private static boolean llllIllIIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIllIIllllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIllIIllllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIllIIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean llllIllIIllIlll(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean llllIllIIlllIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllIllIIlllIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllIllIIllIllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllIllIIllIlIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean llllIllIIlllIlI(int paramInt) {
    return (paramInt > 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\au.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */