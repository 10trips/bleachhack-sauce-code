package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.Entity;

public class f10000000000000000000000000000000000 extends fs {
  private final Entity entity;
  
  private static String[] lIllIIllIIIllI;
  
  private static Class[] lIllIIllIIIlll;
  
  private static final String[] lIllIIllIIlIII;
  
  private static String[] lIllIIllIIlIIl;
  
  private static final int[] lIllIIllIIlIll;
  
  public f10000000000000000000000000000000000(Entity lllllllllllllllIlllllIIllIIlIIlI) {
    this.entity = lllllllllllllllIlllllIIllIIlIIlI;
  }
  
  public Entity getEntity() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lme/stupitdog/bhp/f10000000000000000000000000000000000;)Lnet/minecraft/entity/Entity;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllllIIllIIlIIIl	Lme/stupitdog/bhp/f10000000000000000000000000000000000;
  }
  
  static {
    llllIIIlIlIIIll();
    llllIIIlIlIIIIl();
    llllIIIlIIlllll();
    llllIIIlIIllIlI();
  }
  
  private static CallSite llllIIIlIIllIIl(MethodHandles.Lookup lllllllllllllllIlllllIIllIIIlIII, String lllllllllllllllIlllllIIllIIIIlll, MethodType lllllllllllllllIlllllIIllIIIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIIllIIIlllI = lIllIIllIIIllI[Integer.parseInt(lllllllllllllllIlllllIIllIIIIlll)].split(lIllIIllIIlIII[lIllIIllIIlIll[0]]);
      Class<?> lllllllllllllllIlllllIIllIIIllIl = Class.forName(lllllllllllllllIlllllIIllIIIlllI[lIllIIllIIlIll[0]]);
      String lllllllllllllllIlllllIIllIIIllII = lllllllllllllllIlllllIIllIIIlllI[lIllIIllIIlIll[1]];
      MethodHandle lllllllllllllllIlllllIIllIIIlIll = null;
      int lllllllllllllllIlllllIIllIIIlIlI = lllllllllllllllIlllllIIllIIIlllI[lIllIIllIIlIll[2]].length();
      if (llllIIIlIlIIlII(lllllllllllllllIlllllIIllIIIlIlI, lIllIIllIIlIll[3])) {
        MethodType lllllllllllllllIlllllIIllIIlIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIIllIIIlllI[lIllIIllIIlIll[3]], f10000000000000000000000000000000000.class.getClassLoader());
        if (llllIIIlIlIIlIl(lllllllllllllllIlllllIIllIIIlIlI, lIllIIllIIlIll[3])) {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findVirtual(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIlIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findStatic(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIlIIII);
        } 
        "".length();
        if ("   ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIIllIIIllll = lIllIIllIIIlll[Integer.parseInt(lllllllllllllllIlllllIIllIIIlllI[lIllIIllIIlIll[3]])];
        if (llllIIIlIlIIlIl(lllllllllllllllIlllllIIllIIIlIlI, lIllIIllIIlIll[2])) {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findGetter(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIIllll);
          "".length();
          if (-" ".length() == ((112 + 81 - 60 + 18 ^ (0x8E ^ 0xC3) << " ".length()) << " ".length() << " ".length() & (((0x86 ^ 0x99) << " ".length() << " ".length() ^ 0xD ^ 0x7C) << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else if (llllIIIlIlIIlIl(lllllllllllllllIlllllIIllIIIlIlI, lIllIIllIIlIll[4])) {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findStaticGetter(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIIllll);
          "".length();
          if (null != null)
            return null; 
        } else if (llllIIIlIlIIlIl(lllllllllllllllIlllllIIllIIIlIlI, lIllIIllIIlIll[5])) {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findSetter(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIIllll);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllllIIllIIIlIll = lllllllllllllllIlllllIIllIIIlIII.findStaticSetter(lllllllllllllllIlllllIIllIIIllIl, lllllllllllllllIlllllIIllIIIllII, lllllllllllllllIlllllIIllIIIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIIllIIIlIll);
    } catch (Exception lllllllllllllllIlllllIIllIIIlIIl) {
      lllllllllllllllIlllllIIllIIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIlIIllIlI() {
    lIllIIllIIIllI = new String[lIllIIllIIlIll[1]];
    lIllIIllIIIllI[lIllIIllIIlIll[0]] = lIllIIllIIlIII[lIllIIllIIlIll[1]];
    lIllIIllIIIlll = new Class[lIllIIllIIlIll[1]];
    lIllIIllIIIlll[lIllIIllIIlIll[0]] = Entity.class;
  }
  
  private static void llllIIIlIIlllll() {
    lIllIIllIIlIII = new String[lIllIIllIIlIll[3]];
    lIllIIllIIlIII[lIllIIllIIlIll[0]] = llllIIIlIIllIll(lIllIIllIIlIIl[lIllIIllIIlIll[0]], lIllIIllIIlIIl[lIllIIllIIlIll[1]]);
    lIllIIllIIlIII[lIllIIllIIlIll[1]] = llllIIIlIIllllI(lIllIIllIIlIIl[lIllIIllIIlIll[3]], lIllIIllIIlIIl[lIllIIllIIlIll[2]]);
    lIllIIllIIlIIl = null;
  }
  
  private static void llllIIIlIlIIIIl() {
    String str = (new Exception()).getStackTrace()[lIllIIllIIlIll[0]].getFileName();
    lIllIIllIIlIIl = str.substring(str.indexOf("ä") + lIllIIllIIlIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIlIIllllI(String lllllllllllllllIlllllIIllIIIIIlI, String lllllllllllllllIlllllIIllIIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIllIIIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIllIIIIIIl.getBytes(StandardCharsets.UTF_8)), lIllIIllIIlIll[6]), "DES");
      Cipher lllllllllllllllIlllllIIllIIIIlII = Cipher.getInstance("DES");
      lllllllllllllllIlllllIIllIIIIlII.init(lIllIIllIIlIll[3], lllllllllllllllIlllllIIllIIIIlIl);
      return new String(lllllllllllllllIlllllIIllIIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIllIIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIllIIIIIll) {
      lllllllllllllllIlllllIIllIIIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIlIIllIll(String lllllllllllllllIlllllIIlIlllllIl, String lllllllllllllllIlllllIIlIlllllII) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIllIIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIlIlllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIIlIlllllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIIlIlllllll.init(lIllIIllIIlIll[3], lllllllllllllllIlllllIIllIIIIIII);
      return new String(lllllllllllllllIlllllIIlIlllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIlIlllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIlIllllllI) {
      lllllllllllllllIlllllIIlIllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIlIlIIIll() {
    lIllIIllIIlIll = new int[7];
    lIllIIllIIlIll[0] = (0x20 ^ 0x29) << " ".length() & ((0xA6 ^ 0xAF) << " ".length() ^ 0xFFFFFFFF);
    lIllIIllIIlIll[1] = " ".length();
    lIllIIllIIlIll[2] = "   ".length();
    lIllIIllIIlIll[3] = " ".length() << " ".length();
    lIllIIllIIlIll[4] = " ".length() << " ".length() << " ".length();
    lIllIIllIIlIll[5] = (0x7 ^ 0x22) << " ".length() ^ 0x6A ^ 0x25;
    lIllIIllIIlIll[6] = " ".length() << "   ".length();
  }
  
  private static boolean llllIIIlIlIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIIlIlIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f10000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */