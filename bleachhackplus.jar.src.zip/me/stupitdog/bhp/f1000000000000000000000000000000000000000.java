package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class f1000000000000000000000000000000000000000 extends au {
  @EventHandler
  public Listener<f100000000000.Send> listener;
  
  private static String[] llIIlIIlllIlll;
  
  private static Class[] llIIlIIllllIII;
  
  private static final String[] llIIlIIllllIIl;
  
  private static String[] llIIlIIllllIlI;
  
  private static final int[] llIIlIIllllllI;
  
  public f1000000000000000000000000000000000000000() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllIIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllIIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllIIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/f1000000000000000000000000000000000000000.llIIlIIllllllI : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: <illegal opcode> 1 : (Lme/stupitdog/bhp/f1000000000000000000000000000000000000000;Lme/zero/alpine/listener/Listener;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	68	0	lllllllllllllllIllIIllIIIlIIllll	Lme/stupitdog/bhp/f1000000000000000000000000000000000000000;
  }
  
  static {
    lIIIIlllIIIIlIIl();
    lIIIIlllIIIIIlII();
    lIIIIlllIIIIIIll();
    lIIIIllIllllllll();
  }
  
  private static CallSite lIIIIllIlllllllI(MethodHandles.Lookup lllllllllllllllIllIIllIIIlIIIlIl, String lllllllllllllllIllIIllIIIlIIIlII, MethodType lllllllllllllllIllIIllIIIlIIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIIIlIIlIll = llIIlIIlllIlll[Integer.parseInt(lllllllllllllllIllIIllIIIlIIIlII)].split(llIIlIIllllIIl[llIIlIIllllllI[3]]);
      Class<?> lllllllllllllllIllIIllIIIlIIlIlI = Class.forName(lllllllllllllllIllIIllIIIlIIlIll[llIIlIIllllllI[0]]);
      String lllllllllllllllIllIIllIIIlIIlIIl = lllllllllllllllIllIIllIIIlIIlIll[llIIlIIllllllI[1]];
      MethodHandle lllllllllllllllIllIIllIIIlIIlIII = null;
      int lllllllllllllllIllIIllIIIlIIIlll = lllllllllllllllIllIIllIIIlIIlIll[llIIlIIllllllI[3]].length();
      if (lIIIIlllIIIIllIl(lllllllllllllllIllIIllIIIlIIIlll, llIIlIIllllllI[2])) {
        MethodType lllllllllllllllIllIIllIIIlIIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIIIlIIlIll[llIIlIIllllllI[2]], f1000000000000000000000000000000000000000.class.getClassLoader());
        if (lIIIIlllIIIIlllI(lllllllllllllllIllIIllIIIlIIIlll, llIIlIIllllllI[2])) {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findVirtual(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findStatic(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllIl);
        } 
        "".length();
        if (-"  ".length() > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIIIlIIllII = llIIlIIllllIII[Integer.parseInt(lllllllllllllllIllIIllIIIlIIlIll[llIIlIIllllllI[2]])];
        if (lIIIIlllIIIIlllI(lllllllllllllllIllIIllIIIlIIIlll, llIIlIIllllllI[3])) {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findGetter(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllII);
          "".length();
          if (((0x55 ^ 0x5A) << " ".length() & ((0x90 ^ 0x9F) << " ".length() ^ 0xFFFFFFFF)) != ((0x87 ^ 0xAE) << " ".length() & ((0x43 ^ 0x6A) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lIIIIlllIIIIlllI(lllllllllllllllIllIIllIIIlIIIlll, llIIlIIllllllI[4])) {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findStaticGetter(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllII);
          "".length();
          if ("   ".length() < "   ".length())
            return null; 
        } else if (lIIIIlllIIIIlllI(lllllllllllllllIllIIllIIIlIIIlll, llIIlIIllllllI[5])) {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findSetter(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIllIIIlIIlIII = lllllllllllllllIllIIllIIIlIIIlIl.findStaticSetter(lllllllllllllllIllIIllIIIlIIlIlI, lllllllllllllllIllIIllIIIlIIlIIl, lllllllllllllllIllIIllIIIlIIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIIIlIIlIII);
    } catch (Exception lllllllllllllllIllIIllIIIlIIIllI) {
      lllllllllllllllIllIIllIIIlIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIllllllll() {
    llIIlIIlllIlll = new String[llIIlIIllllllI[4]];
    llIIlIIlllIlll[llIIlIIllllllI[3]] = llIIlIIllllIIl[llIIlIIllllllI[4]];
    llIIlIIlllIlll[llIIlIIllllllI[2]] = llIIlIIllllIIl[llIIlIIllllllI[5]];
    llIIlIIlllIlll[llIIlIIllllllI[0]] = llIIlIIllllIIl[llIIlIIllllllI[6]];
    llIIlIIlllIlll[llIIlIIllllllI[1]] = llIIlIIllllIIl[llIIlIIllllllI[7]];
    llIIlIIllllIII = new Class[llIIlIIllllllI[2]];
    llIIlIIllllIII[llIIlIIllllllI[1]] = Listener.class;
    llIIlIIllllIII[llIIlIIllllllI[0]] = f13.class;
  }
  
  private static void lIIIIlllIIIIIIll() {
    llIIlIIllllIIl = new String[llIIlIIllllllI[8]];
    llIIlIIllllIIl[llIIlIIllllllI[0]] = lIIIIlllIIIIIIII(llIIlIIllllIlI[llIIlIIllllllI[0]], llIIlIIllllIlI[llIIlIIllllllI[1]]);
    llIIlIIllllIIl[llIIlIIllllllI[1]] = lIIIIlllIIIIIIIl(llIIlIIllllIlI[llIIlIIllllllI[2]], llIIlIIllllIlI[llIIlIIllllllI[3]]);
    llIIlIIllllIIl[llIIlIIllllllI[2]] = lIIIIlllIIIIIIII(llIIlIIllllIlI[llIIlIIllllllI[4]], llIIlIIllllIlI[llIIlIIllllllI[5]]);
    llIIlIIllllIIl[llIIlIIllllllI[3]] = lIIIIlllIIIIIIIl(llIIlIIllllIlI[llIIlIIllllllI[6]], llIIlIIllllIlI[llIIlIIllllllI[7]]);
    llIIlIIllllIIl[llIIlIIllllllI[4]] = lIIIIlllIIIIIIIl(llIIlIIllllIlI[llIIlIIllllllI[8]], llIIlIIllllIlI[llIIlIIllllllI[9]]);
    llIIlIIllllIIl[llIIlIIllllllI[5]] = lIIIIlllIIIIIIIl(llIIlIIllllIlI[llIIlIIllllllI[10]], llIIlIIllllIlI[llIIlIIllllllI[11]]);
    llIIlIIllllIIl[llIIlIIllllllI[6]] = lIIIIlllIIIIIIlI(llIIlIIllllIlI[llIIlIIllllllI[12]], llIIlIIllllIlI[llIIlIIllllllI[13]]);
    llIIlIIllllIIl[llIIlIIllllllI[7]] = lIIIIlllIIIIIIlI(llIIlIIllllIlI[llIIlIIllllllI[14]], llIIlIIllllIlI[llIIlIIllllllI[15]]);
    llIIlIIllllIlI = null;
  }
  
  private static void lIIIIlllIIIIIlII() {
    String str = (new Exception()).getStackTrace()[llIIlIIllllllI[0]].getFileName();
    llIIlIIllllIlI = str.substring(str.indexOf("ä") + llIIlIIllllllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlllIIIIIIIl(String lllllllllllllllIllIIllIIIIllllll, String lllllllllllllllIllIIllIIIIlllllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIIIlIIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIIIIlllllI.getBytes(StandardCharsets.UTF_8)), llIIlIIllllllI[8]), "DES");
      Cipher lllllllllllllllIllIIllIIIlIIIIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIIIlIIIIIl.init(llIIlIIllllllI[2], lllllllllllllllIllIIllIIIlIIIIlI);
      return new String(lllllllllllllllIllIIllIIIlIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIIIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIIIlIIIIII) {
      lllllllllllllllIllIIllIIIlIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlllIIIIIIlI(String lllllllllllllllIllIIllIIIIlllIlI, String lllllllllllllllIllIIllIIIIlllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIIIIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIIIIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIIIIllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIIIIllllII.init(llIIlIIllllllI[2], lllllllllllllllIllIIllIIIIllllIl);
      return new String(lllllllllllllllIllIIllIIIIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIIIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIIIIlllIll) {
      lllllllllllllllIllIIllIIIIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlllIIIIIIII(String lllllllllllllllIllIIllIIIIllIlll, String lllllllllllllllIllIIllIIIIllIllI) {
    lllllllllllllllIllIIllIIIIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllIIIIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllIIIIllIlIl = new StringBuilder();
    char[] lllllllllllllllIllIIllIIIIllIlII = lllllllllllllllIllIIllIIIIllIllI.toCharArray();
    int lllllllllllllllIllIIllIIIIllIIll = llIIlIIllllllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIllIIIIllIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIllllllI[0];
    while (lIIIIlllIIIlIIlI(j, i)) {
      char lllllllllllllllIllIIllIIIIlllIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllIIIIllIIll++;
      j++;
      "".length();
      if ((0xDA ^ 0x9D ^ (0x51 ^ 0x70) << " ".length()) <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllIIIIllIlIl);
  }
  
  private static void lIIIIlllIIIIlIIl() {
    llIIlIIllllllI = new int[16];
    llIIlIIllllllI[0] = (0x5D ^ 0x16) & (0xDC ^ 0x97 ^ 0xFFFFFFFF);
    llIIlIIllllllI[1] = " ".length();
    llIIlIIllllllI[2] = " ".length() << " ".length();
    llIIlIIllllllI[3] = "   ".length();
    llIIlIIllllllI[4] = " ".length() << " ".length() << " ".length();
    llIIlIIllllllI[5] = 0xD0 ^ 0x9F ^ (0xA0 ^ 0x85) << " ".length();
    llIIlIIllllllI[6] = "   ".length() << " ".length();
    llIIlIIllllllI[7] = 0xA6 ^ 0xA1;
    llIIlIIllllllI[8] = " ".length() << "   ".length();
    llIIlIIllllllI[9] = 0x7E ^ 0x77;
    llIIlIIllllllI[10] = (0x60 ^ 0x65) << " ".length();
    llIIlIIllllllI[11] = 0x4D ^ 0x46;
    llIIlIIllllllI[12] = "   ".length() << " ".length() << " ".length();
    llIIlIIllllllI[13] = 0xB3 ^ 0xBE;
    llIIlIIllllllI[14] = (0x36 ^ 0x31) << " ".length();
    llIIlIIllllllI[15] = 0x27 ^ 0x6E ^ (0x2B ^ 0x8) << " ".length();
  }
  
  private static boolean lIIIIlllIIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlllIIIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlllIIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlllIIIIlIll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f1000000000000000000000000000000000000000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */