package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;

public class an extends au {
  f100000000000000000000.Double speed;
  
  private static String[] llIIIlIlIIIIlI;
  
  private static Class[] llIIIlIlIIIIll;
  
  private static final String[] llIIIlIlIlllll;
  
  private static String[] llIIIlIllIIIll;
  
  private static final int[] llIIIlIllIIlll;
  
  public an() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/an.llIIIlIlIlllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/an.llIIIlIllIIlll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/an.llIIIlIlIlllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/an.llIIIlIllIIlll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/an.llIIIlIlIlllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/an.llIIIlIllIIlll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/an.llIIIlIllIIlll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlIlIIlllIlIIl	Lme/stupitdog/bhp/an;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/an.llIIIlIlIlllll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/an.llIIIlIllIIlll : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: ldc2_w 0.4
    //   14: ldc2_w 0.2
    //   17: ldc2_w 1.5
    //   20: <illegal opcode> 1 : (Lme/stupitdog/bhp/an;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   25: <illegal opcode> 2 : (Lme/stupitdog/bhp/an;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIllIlIlIIlllIlIII	Lme/stupitdog/bhp/an;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/block/Block;
    //   5: aload_0
    //   6: <illegal opcode> 4 : (Lme/stupitdog/bhp/an;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   11: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   16: d2f
    //   17: putfield field_149765_K : F
    //   20: <illegal opcode> 6 : ()Lnet/minecraft/block/Block;
    //   25: aload_0
    //   26: <illegal opcode> 4 : (Lme/stupitdog/bhp/an;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   31: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   36: d2f
    //   37: putfield field_149765_K : F
    //   40: <illegal opcode> 7 : ()Lnet/minecraft/block/Block;
    //   45: aload_0
    //   46: <illegal opcode> 4 : (Lme/stupitdog/bhp/an;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   51: <illegal opcode> 5 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   56: d2f
    //   57: putfield field_149765_K : F
    //   60: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	61	0	lllllllllllllllIllIlIlIIlllIIlll	Lme/stupitdog/bhp/an;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 3 : ()Lnet/minecraft/block/Block;
    //   5: ldc 0.98
    //   7: putfield field_149765_K : F
    //   10: <illegal opcode> 6 : ()Lnet/minecraft/block/Block;
    //   15: ldc 0.98
    //   17: putfield field_149765_K : F
    //   20: <illegal opcode> 7 : ()Lnet/minecraft/block/Block;
    //   25: ldc 0.98
    //   27: putfield field_149765_K : F
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIllIlIlIIlllIIllI	Lme/stupitdog/bhp/an;
  }
  
  static {
    lIIIIlIIIllIIIlI();
    lIIIIlIIIlIllIIl();
    lIIIIlIIIlIllIII();
    lIIIIlIIIlIlIIII();
  }
  
  private static CallSite lIIIIlIIIIIlIlII(MethodHandles.Lookup lllllllllllllllIllIlIlIIllIlllIl, String lllllllllllllllIllIlIlIIllIlllII, MethodType lllllllllllllllIllIlIlIIllIllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlIIlllIIIll = llIIIlIlIIIIlI[Integer.parseInt(lllllllllllllllIllIlIlIIllIlllII)].split(llIIIlIlIlllll[llIIIlIllIIlll[4]]);
      Class<?> lllllllllllllllIllIlIlIIlllIIIlI = Class.forName(lllllllllllllllIllIlIlIIlllIIIll[llIIIlIllIIlll[0]]);
      String lllllllllllllllIllIlIlIIlllIIIIl = lllllllllllllllIllIlIlIIlllIIIll[llIIIlIllIIlll[1]];
      MethodHandle lllllllllllllllIllIlIlIIlllIIIII = null;
      int lllllllllllllllIllIlIlIIllIlllll = lllllllllllllllIllIlIlIIlllIIIll[llIIIlIllIIlll[3]].length();
      if (lIIIIlIIIllIIIll(lllllllllllllllIllIlIlIIllIlllll, llIIIlIllIIlll[2])) {
        MethodType lllllllllllllllIllIlIlIIlllIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlIIlllIIIll[llIIIlIllIIlll[2]], an.class.getClassLoader());
        if (lIIIIlIIIllIIlII(lllllllllllllllIllIlIlIIllIlllll, llIIIlIllIIlll[2])) {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findVirtual(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlIl);
          "".length();
          if (" ".length() < " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findStatic(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlIl);
        } 
        "".length();
        if (((0xA4 ^ 0x9F) & (0x48 ^ 0x73 ^ 0xFFFFFFFF)) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlIIlllIIlII = llIIIlIlIIIIll[Integer.parseInt(lllllllllllllllIllIlIlIIlllIIIll[llIIIlIllIIlll[2]])];
        if (lIIIIlIIIllIIlII(lllllllllllllllIllIlIlIIllIlllll, llIIIlIllIIlll[3])) {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findGetter(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlII);
          "".length();
          if (((0xC0 ^ 0x8F) & (0x54 ^ 0x1B ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (lIIIIlIIIllIIlII(lllllllllllllllIllIlIlIIllIlllll, llIIIlIllIIlll[4])) {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findStaticGetter(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlII);
          "".length();
          if (-((0x9B ^ 0x84) << " ".length() ^ (0xD8 ^ 0xC5) << " ".length()) >= 0)
            return null; 
        } else if (lIIIIlIIIllIIlII(lllllllllllllllIllIlIlIIllIlllll, llIIIlIllIIlll[5])) {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findSetter(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIllIlllIl.findStaticSetter(lllllllllllllllIllIlIlIIlllIIIlI, lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIlllIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlIIlllIIIII);
    } catch (Exception lllllllllllllllIllIlIlIIllIllllI) {
      lllllllllllllllIllIlIlIIllIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIIlIlIIII() {
    llIIIlIlIIIIlI = new String[llIIIlIllIIlll[6]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[3]] = llIIIlIlIlllll[llIIIlIllIIlll[5]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[2]] = llIIIlIlIlllll[llIIIlIllIIlll[7]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[0]] = llIIIlIlIlllll[llIIIlIllIIlll[8]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[5]] = llIIIlIlIlllll[llIIIlIllIIlll[6]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[1]] = llIIIlIlIlllll[llIIIlIllIIlll[9]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[4]] = llIIIlIlIlllll[llIIIlIllIIlll[10]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[8]] = llIIIlIlIlllll[llIIIlIllIIlll[11]];
    llIIIlIlIIIIlI[llIIIlIllIIlll[7]] = llIIIlIlIlllll[llIIIlIllIIlll[12]];
    llIIIlIlIIIIll = new Class[llIIIlIllIIlll[4]];
    llIIIlIlIIIIll[llIIIlIllIIlll[1]] = f100000000000000000000.Double.class;
    llIIIlIlIIIIll[llIIIlIllIIlll[0]] = f13.class;
    llIIIlIlIIIIll[llIIIlIllIIlll[3]] = float.class;
    llIIIlIlIIIIll[llIIIlIllIIlll[2]] = Block.class;
  }
  
  private static void lIIIIlIIIlIllIII() {
    llIIIlIlIlllll = new String[llIIIlIllIIlll[13]];
    llIIIlIlIlllll[llIIIlIllIIlll[0]] = lIIIIlIIIlIlIIIl(llIIIlIllIIIll[llIIIlIllIIlll[0]], llIIIlIllIIIll[llIIIlIllIIlll[1]]);
    llIIIlIlIlllll[llIIIlIllIIlll[1]] = lIIIIlIIIlIlIIlI(llIIIlIllIIIll[llIIIlIllIIlll[2]], llIIIlIllIIIll[llIIIlIllIIlll[3]]);
    llIIIlIlIlllll[llIIIlIllIIlll[2]] = lIIIIlIIIlIlIIlI(llIIIlIllIIIll[llIIIlIllIIlll[4]], llIIIlIllIIIll[llIIIlIllIIlll[5]]);
    llIIIlIlIlllll[llIIIlIllIIlll[3]] = lIIIIlIIIlIlIIll(llIIIlIllIIIll[llIIIlIllIIlll[7]], llIIIlIllIIIll[llIIIlIllIIlll[8]]);
    llIIIlIlIlllll[llIIIlIllIIlll[4]] = lIIIIlIIIlIlIIIl(llIIIlIllIIIll[llIIIlIllIIlll[6]], llIIIlIllIIIll[llIIIlIllIIlll[9]]);
    llIIIlIlIlllll[llIIIlIllIIlll[5]] = lIIIIlIIIlIlIIlI(llIIIlIllIIIll[llIIIlIllIIlll[10]], llIIIlIllIIIll[llIIIlIllIIlll[11]]);
    llIIIlIlIlllll[llIIIlIllIIlll[7]] = lIIIIlIIIlIlIIlI(llIIIlIllIIIll[llIIIlIllIIlll[12]], llIIIlIllIIIll[llIIIlIllIIlll[13]]);
    llIIIlIlIlllll[llIIIlIllIIlll[8]] = lIIIIlIIIlIlIIlI(llIIIlIllIIIll[llIIIlIllIIlll[14]], llIIIlIllIIIll[llIIIlIllIIlll[15]]);
    llIIIlIlIlllll[llIIIlIllIIlll[6]] = lIIIIlIIIlIlIIIl(llIIIlIllIIIll[llIIIlIllIIlll[16]], llIIIlIllIIIll[llIIIlIllIIlll[17]]);
    llIIIlIlIlllll[llIIIlIllIIlll[9]] = lIIIIlIIIlIlIIIl("DBJAJiAUBwchMA4QQDc8EVkPO24TEgk8JxUSHBE7FBUCMG5JOwQ0IgBYAjQ6Blg9ISYIGQluECUzRxk5BFgdISERHhoxOwZYDD0kThFfZWRRR15lZFFHXmVkUUdeZWRRR15xEA4CDDkxWk1OdQ==", "awnUT");
    llIIIlIlIlllll[llIIIlIllIIlll[10]] = lIIIIlIIIlIlIIlI("psAi56AX21/WQ/mMyRaPS87IBWkTBtpLHhRTU/i9geM=", "HqicV");
    llIIIlIlIlllll[llIIIlIllIIlll[11]] = lIIIIlIIIlIlIIll("UrpdE+SYB7g6zck/+Y0mP2QfZR07noaPeQRpQX/Vf3Fy6K9crffuMvgV1uhFjd+5MVtd4QySuSY=", "wIkqH");
    llIIIlIlIlllll[llIIIlIllIIlll[12]] = lIIIIlIIIlIlIIIl("CQ8daycOBAwmOAYMHWsjCQMdawgLBQouOV0MACAmAzVYcHpTWloaKQ1QW39qR0pJ", "gjiEJ");
    llIIIlIllIIIll = null;
  }
  
  private static void lIIIIlIIIlIllIIl() {
    String str = (new Exception()).getStackTrace()[llIIIlIllIIlll[0]].getFileName();
    llIIIlIllIIIll = str.substring(str.indexOf("ä") + llIIIlIllIIlll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIIlIlIIlI(String lllllllllllllllIllIlIlIIllIlIlll, String lllllllllllllllIllIlIlIIllIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIIllIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIllIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlIIllIllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlIIllIllIIl.init(llIIIlIllIIlll[2], lllllllllllllllIllIlIlIIllIllIlI);
      return new String(lllllllllllllllIllIlIlIIllIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIllIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIIllIllIII) {
      lllllllllllllllIllIlIlIIllIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIIlIlIIll(String lllllllllllllllIllIlIlIIllIlIIlI, String lllllllllllllllIllIlIlIIllIlIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIIllIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIllIlIIIl.getBytes(StandardCharsets.UTF_8)), llIIIlIllIIlll[6]), "DES");
      Cipher lllllllllllllllIllIlIlIIllIlIlII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlIIllIlIlII.init(llIIIlIllIIlll[2], lllllllllllllllIllIlIlIIllIlIlIl);
      return new String(lllllllllllllllIllIlIlIIllIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIllIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIIllIlIIll) {
      lllllllllllllllIllIlIlIIllIlIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIIlIlIIIl(String lllllllllllllllIllIlIlIIllIIllll, String lllllllllllllllIllIlIlIIllIIlllI) {
    lllllllllllllllIllIlIlIIllIIllll = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIllIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlIIllIIllIl = new StringBuilder();
    char[] lllllllllllllllIllIlIlIIllIIllII = lllllllllllllllIllIlIlIIllIIlllI.toCharArray();
    int lllllllllllllllIllIlIlIIllIIlIll = llIIIlIllIIlll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIlIIllIIllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIllIIlll[0];
    while (lIIIIlIIIllIIlIl(j, i)) {
      char lllllllllllllllIllIlIlIIllIlIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIlIIllIIlIll++;
      j++;
      "".length();
      if (-" ".length() > -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlIIllIIllIl);
  }
  
  private static void lIIIIlIIIllIIIlI() {
    llIIIlIllIIlll = new int[18];
    llIIIlIllIIlll[0] = (0x1C ^ 0x7F ^ (0x1A ^ 0x5) << " ".length() << " ".length()) << " ".length() & (((0x37 ^ 0x3C) << " ".length() << " ".length() << " ".length() ^ 147 + 66 - 112 + 74) << " ".length() ^ -" ".length());
    llIIIlIllIIlll[1] = " ".length();
    llIIIlIllIIlll[2] = " ".length() << " ".length();
    llIIIlIllIIlll[3] = "   ".length();
    llIIIlIllIIlll[4] = " ".length() << " ".length() << " ".length();
    llIIIlIllIIlll[5] = " ".length() << "   ".length() << " ".length() ^ 0x13 ^ 0x56;
    llIIIlIllIIlll[6] = " ".length() << "   ".length();
    llIIIlIllIIlll[7] = "   ".length() << " ".length();
    llIIIlIllIIlll[8] = 0x29 ^ 0x2E;
    llIIIlIllIIlll[9] = " ".length() << "   ".length() << " ".length() ^ 0x8A ^ 0xC3;
    llIIIlIllIIlll[10] = (0x8 ^ 0xD) << " ".length();
    llIIIlIllIIlll[11] = 0x6C ^ 0x67;
    llIIIlIllIIlll[12] = "   ".length() << " ".length() << " ".length();
    llIIIlIllIIlll[13] = 0x9B ^ 0x96;
    llIIIlIllIIlll[14] = (0x48 ^ 0x4F) << " ".length();
    llIIIlIllIIlll[15] = (0x33 ^ 0x38) << " ".length() << " ".length() ^ 0x14 ^ 0x37;
    llIIIlIllIIlll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIlIllIIlll[17] = (0x28 ^ 0x25) << " ".length() << " ".length() ^ 0x99 ^ 0xBC;
  }
  
  private static boolean lIIIIlIIIllIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIIllIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIIllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\an.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */