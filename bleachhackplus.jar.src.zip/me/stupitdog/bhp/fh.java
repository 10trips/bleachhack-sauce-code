package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fh {
  private String name;
  
  private String description;
  
  private String syntax;
  
  private static String[] lIllIIlllIllIl;
  
  private static Class[] lIllIIlllIlllI;
  
  private static final String[] lIllIIlllIllll;
  
  private static String[] lIllIIllllIIII;
  
  private static final int[] lIllIIllllIIIl;
  
  public fh(String lllllllllllllllIlllllIIIIlllIlIl, String lllllllllllllllIlllllIIIIlllIlII, String lllllllllllllllIlllllIIIIlllIIll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lme/stupitdog/bhp/fh;Ljava/lang/String;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lme/stupitdog/bhp/fh;Ljava/lang/String;)V
    //   18: aload_0
    //   19: aload_3
    //   20: <illegal opcode> 2 : (Lme/stupitdog/bhp/fh;Ljava/lang/String;)V
    //   25: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	26	0	lllllllllllllllIlllllIIIIlllIllI	Lme/stupitdog/bhp/fh;
    //   0	26	1	lllllllllllllllIlllllIIIIlllIlIl	Ljava/lang/String;
    //   0	26	2	lllllllllllllllIlllllIIIIlllIlII	Ljava/lang/String;
    //   0	26	3	lllllllllllllllIlllllIIIIlllIIll	Ljava/lang/String;
  }
  
  public String getName() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllllIIIIlllIIlI	Lme/stupitdog/bhp/fh;
  }
  
  public String getDescription() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllllIIIIlllIIIl	Lme/stupitdog/bhp/fh;
  }
  
  public String getSyntax() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lme/stupitdog/bhp/fh;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllllIIIIlllIIII	Lme/stupitdog/bhp/fh;
  }
  
  public void runCommand(String[] lllllllllllllllIlllllIIIIllIlllI) {}
  
  static {
    llllIIIllllIIlI();
    llllIIIllllIIIl();
    llllIIIllllIIII();
    llllIIIlllIllII();
  }
  
  private static CallSite llllIIIlllIlIll(MethodHandles.Lookup lllllllllllllllIlllllIIIIllIIlIl, String lllllllllllllllIlllllIIIIllIIlII, MethodType lllllllllllllllIlllllIIIIllIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIIIIllIlIll = lIllIIlllIllIl[Integer.parseInt(lllllllllllllllIlllllIIIIllIIlII)].split(lIllIIlllIllll[lIllIIllllIIIl[0]]);
      Class<?> lllllllllllllllIlllllIIIIllIlIlI = Class.forName(lllllllllllllllIlllllIIIIllIlIll[lIllIIllllIIIl[0]]);
      String lllllllllllllllIlllllIIIIllIlIIl = lllllllllllllllIlllllIIIIllIlIll[lIllIIllllIIIl[1]];
      MethodHandle lllllllllllllllIlllllIIIIllIlIII = null;
      int lllllllllllllllIlllllIIIIllIIlll = lllllllllllllllIlllllIIIIllIlIll[lIllIIllllIIIl[2]].length();
      if (llllIIIllllIIll(lllllllllllllllIlllllIIIIllIIlll, lIllIIllllIIIl[3])) {
        MethodType lllllllllllllllIlllllIIIIllIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIIIIllIlIll[lIllIIllllIIIl[3]], fh.class.getClassLoader());
        if (llllIIIllllIlII(lllllllllllllllIlllllIIIIllIIlll, lIllIIllllIIIl[3])) {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findVirtual(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findStatic(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllIl);
        } 
        "".length();
        if ("   ".length() <= ((0x5D ^ 0x76 ^ (0x70 ^ 0x6B) << " ".length()) & (0xC7 ^ 0x8A ^ (0xB0 ^ 0xB5) << " ".length() << " ".length() << " ".length() ^ -" ".length())))
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIIIIllIllII = lIllIIlllIlllI[Integer.parseInt(lllllllllllllllIlllllIIIIllIlIll[lIllIIllllIIIl[3]])];
        if (llllIIIllllIlII(lllllllllllllllIlllllIIIIllIIlll, lIllIIllllIIIl[2])) {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findGetter(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllII);
          "".length();
          if (((0x44 ^ 0x25) & (0x2A ^ 0x4B ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (llllIIIllllIlII(lllllllllllllllIlllllIIIIllIIlll, lIllIIllllIIIl[4])) {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findStaticGetter(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllII);
          "".length();
          if (-" ".length() > "   ".length())
            return null; 
        } else if (llllIIIllllIlII(lllllllllllllllIlllllIIIIllIIlll, lIllIIllllIIIl[5])) {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findSetter(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllII);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIlllllIIIIllIlIII = lllllllllllllllIlllllIIIIllIIlIl.findStaticSetter(lllllllllllllllIlllllIIIIllIlIlI, lllllllllllllllIlllllIIIIllIlIIl, lllllllllllllllIlllllIIIIllIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIIIIllIlIII);
    } catch (Exception lllllllllllllllIlllllIIIIllIIllI) {
      lllllllllllllllIlllllIIIIllIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIlllIllII() {
    lIllIIlllIllIl = new String[lIllIIllllIIIl[6]];
    lIllIIlllIllIl[lIllIIllllIIIl[4]] = lIllIIlllIllll[lIllIIllllIIIl[1]];
    lIllIIlllIllIl[lIllIIllllIIIl[1]] = lIllIIlllIllll[lIllIIllllIIIl[3]];
    lIllIIlllIllIl[lIllIIllllIIIl[2]] = lIllIIlllIllll[lIllIIllllIIIl[2]];
    lIllIIlllIllIl[lIllIIllllIIIl[0]] = lIllIIlllIllll[lIllIIllllIIIl[4]];
    lIllIIlllIllIl[lIllIIllllIIIl[3]] = lIllIIlllIllll[lIllIIllllIIIl[5]];
    lIllIIlllIllIl[lIllIIllllIIIl[5]] = lIllIIlllIllll[lIllIIllllIIIl[6]];
    lIllIIlllIlllI = new Class[lIllIIllllIIIl[1]];
    lIllIIlllIlllI[lIllIIllllIIIl[0]] = String.class;
  }
  
  private static void llllIIIllllIIII() {
    lIllIIlllIllll = new String[lIllIIllllIIIl[7]];
    lIllIIlllIllll[lIllIIllllIIIl[0]] = llllIIIlllIllIl(lIllIIllllIIII[lIllIIllllIIIl[0]], lIllIIllllIIII[lIllIIllllIIIl[1]]);
    lIllIIlllIllll[lIllIIllllIIIl[1]] = llllIIIlllIllIl(lIllIIllllIIII[lIllIIllllIIIl[3]], lIllIIllllIIII[lIllIIllllIIIl[2]]);
    lIllIIlllIllll[lIllIIllllIIIl[3]] = llllIIIlllIlllI(lIllIIllllIIII[lIllIIllllIIIl[4]], lIllIIllllIIII[lIllIIllllIIIl[5]]);
    lIllIIlllIllll[lIllIIllllIIIl[2]] = llllIIIlllIllll(lIllIIllllIIII[lIllIIllllIIIl[6]], lIllIIllllIIII[lIllIIllllIIIl[7]]);
    lIllIIlllIllll[lIllIIllllIIIl[4]] = llllIIIlllIllIl(lIllIIllllIIII[lIllIIllllIIIl[8]], lIllIIllllIIII[lIllIIllllIIIl[9]]);
    lIllIIlllIllll[lIllIIllllIIIl[5]] = llllIIIlllIllIl(lIllIIllllIIII[lIllIIllllIIIl[10]], lIllIIllllIIII[lIllIIllllIIIl[11]]);
    lIllIIlllIllll[lIllIIllllIIIl[6]] = llllIIIlllIlllI(lIllIIllllIIII[lIllIIllllIIIl[12]], lIllIIllllIIII[lIllIIllllIIIl[13]]);
    lIllIIllllIIII = null;
  }
  
  private static void llllIIIllllIIIl() {
    String str = (new Exception()).getStackTrace()[lIllIIllllIIIl[0]].getFileName();
    lIllIIllllIIII = str.substring(str.indexOf("ä") + lIllIIllllIIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIlllIllIl(String lllllllllllllllIlllllIIIIlIlllll, String lllllllllllllllIlllllIIIIlIllllI) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIIllIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIIlIllllI.getBytes(StandardCharsets.UTF_8)), lIllIIllllIIIl[8]), "DES");
      Cipher lllllllllllllllIlllllIIIIllIIIIl = Cipher.getInstance("DES");
      lllllllllllllllIlllllIIIIllIIIIl.init(lIllIIllllIIIl[3], lllllllllllllllIlllllIIIIllIIIlI);
      return new String(lllllllllllllllIlllllIIIIllIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIlIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIIllIIIII) {
      lllllllllllllllIlllllIIIIllIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIlllIlllI(String lllllllllllllllIlllllIIIIlIlllII, String lllllllllllllllIlllllIIIIlIllIll) {
    lllllllllllllllIlllllIIIIlIlllII = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIlIlllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIIIIlIllIlI = new StringBuilder();
    char[] lllllllllllllllIlllllIIIIlIllIIl = lllllllllllllllIlllllIIIIlIllIll.toCharArray();
    int lllllllllllllllIlllllIIIIlIllIII = lIllIIllllIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllllIIIIlIlllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIIllllIIIl[0];
    while (llllIIIllllIlIl(j, i)) {
      char lllllllllllllllIlllllIIIIlIlllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllllIIIIlIllIII++;
      j++;
      "".length();
      if (" ".length() << " ".length() == " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllllIIIIlIllIlI);
  }
  
  private static String llllIIIlllIllll(String lllllllllllllllIlllllIIIIlIlIlII, String lllllllllllllllIlllllIIIIlIlIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllllIIIIlIlIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIIIIlIlIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIIIIlIlIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIIIIlIlIllI.init(lIllIIllllIIIl[3], lllllllllllllllIlllllIIIIlIlIlll);
      return new String(lllllllllllllllIlllllIIIIlIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIIIIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIIIIlIlIlIl) {
      lllllllllllllllIlllllIIIIlIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIllllIIlI() {
    lIllIIllllIIIl = new int[14];
    lIllIIllllIIIl[0] = (0xBD ^ 0xB2) << " ".length() << " ".length() & ((0x3E ^ 0x31) << " ".length() << " ".length() ^ 0xFFFFFFFF);
    lIllIIllllIIIl[1] = " ".length();
    lIllIIllllIIIl[2] = "   ".length();
    lIllIIllllIIIl[3] = " ".length() << " ".length();
    lIllIIllllIIIl[4] = " ".length() << " ".length() << " ".length();
    lIllIIllllIIIl[5] = 0x27 ^ 0x7E ^ (0x25 ^ 0x32) << " ".length() << " ".length();
    lIllIIllllIIIl[6] = "   ".length() << " ".length();
    lIllIIllllIIIl[7] = 0x3A ^ 0x3D;
    lIllIIllllIIIl[8] = " ".length() << "   ".length();
    lIllIIllllIIIl[9] = " ".length() << (0x3 ^ 0x6) ^ 0xA4 ^ 0x8D;
    lIllIIllllIIIl[10] = (0x3A ^ 0x3F) << " ".length();
    lIllIIllllIIIl[11] = 0x43 ^ 0x48;
    lIllIIllllIIIl[12] = "   ".length() << " ".length() << " ".length();
    lIllIIllllIIIl[13] = 0xCE ^ 0xC1 ^ " ".length() << " ".length();
  }
  
  private static boolean llllIIIllllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIIllllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIIllllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fh.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */