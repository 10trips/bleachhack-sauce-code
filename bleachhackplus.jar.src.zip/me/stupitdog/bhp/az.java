package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class az extends au {
  f100000000000000000000.Integer scale;
  
  f100000000000000000000.Boolean showHealth;
  
  f100000000000000000000.Boolean showArmor;
  
  f100000000000000000000.Boolean reverse;
  
  @EventHandler
  private final Listener<f10000000000000000> nameEvent;
  
  @EventHandler
  private final Listener<RenderWorldLastEvent> onRender;
  
  private static String[] llIIlIlIlIIIIl;
  
  private static Class[] llIIlIlIlIIIlI;
  
  private static final String[] llIIllIlIIIlll;
  
  private static String[] llIIllIlIIlIII;
  
  private static final int[] llIIllIlIIlIIl;
  
  public az() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: <illegal opcode> invoke : ()Lme/zero/alpine/listener/EventHook;
    //   51: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   54: iconst_0
    //   55: iaload
    //   56: anewarray java/util/function/Predicate
    //   59: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   62: putfield nameEvent : Lme/zero/alpine/listener/Listener;
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: aload_0
    //   71: <illegal opcode> invoke : (Lme/stupitdog/bhp/az;)Lme/zero/alpine/listener/EventHook;
    //   76: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   79: iconst_0
    //   80: iaload
    //   81: anewarray java/util/function/Predicate
    //   84: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   87: putfield onRender : Lme/zero/alpine/listener/Listener;
    //   90: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	91	0	lllllllllllllllIllIIIlIIIllIIIII	Lme/stupitdog/bhp/az;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   14: iconst_2
    //   15: iaload
    //   16: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   19: iconst_1
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   24: iconst_4
    //   25: iaload
    //   26: <illegal opcode> 1 : (Lme/stupitdog/bhp/az;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   31: <illegal opcode> 2 : (Lme/stupitdog/bhp/az;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   36: aload_0
    //   37: aload_0
    //   38: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   41: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   44: iconst_5
    //   45: iaload
    //   46: aaload
    //   47: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   50: iconst_1
    //   51: iaload
    //   52: <illegal opcode> 3 : (Lme/stupitdog/bhp/az;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   57: <illegal opcode> 4 : (Lme/stupitdog/bhp/az;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   62: aload_0
    //   63: aload_0
    //   64: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   67: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   70: iconst_4
    //   71: iaload
    //   72: aaload
    //   73: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   76: iconst_1
    //   77: iaload
    //   78: <illegal opcode> 3 : (Lme/stupitdog/bhp/az;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   83: <illegal opcode> 5 : (Lme/stupitdog/bhp/az;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   88: aload_0
    //   89: aload_0
    //   90: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   93: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   96: bipush #6
    //   98: iaload
    //   99: aaload
    //   100: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   103: iconst_1
    //   104: iaload
    //   105: <illegal opcode> 3 : (Lme/stupitdog/bhp/az;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   110: <illegal opcode> 6 : (Lme/stupitdog/bhp/az;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   115: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	116	0	lllllllllllllllIllIIIlIIIlIlllll	Lme/stupitdog/bhp/az;
  }
  
  private void renderNameTag(EntityPlayer lllllllllllllllIllIIIlIIIlIlIIll, double lllllllllllllllIllIIIlIIIlIlIIlI, double lllllllllllllllIllIIIlIIIlIlIIIl, double lllllllllllllllIllIIIlIIIlIlIIII, float lllllllllllllllIllIIIlIIIlIIllll) {
    // Byte code:
    //   0: dload #4
    //   2: dstore #9
    //   4: dload #9
    //   6: aload_1
    //   7: <illegal opcode> 7 : (Lnet/minecraft/entity/player/EntityPlayer;)Z
    //   12: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   15: ifeq -> 54
    //   18: ldc2_w 0.5
    //   21: ldc ''
    //   23: invokevirtual length : ()I
    //   26: pop
    //   27: bipush #72
    //   29: bipush #9
    //   31: ixor
    //   32: ldc ' '
    //   34: invokevirtual length : ()I
    //   37: ishl
    //   38: bipush #69
    //   40: bipush #99
    //   42: iadd
    //   43: bipush #113
    //   45: isub
    //   46: bipush #80
    //   48: iadd
    //   49: ixor
    //   50: ifgt -> 57
    //   53: return
    //   54: ldc2_w 0.7
    //   57: dadd
    //   58: dstore #9
    //   60: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   65: <illegal opcode> 9 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/entity/Entity;
    //   70: astore #11
    //   72: <illegal opcode> 10 : ()Z
    //   77: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   80: ifeq -> 99
    //   83: aload #11
    //   85: invokestatic lIIIlIIlIlIIIllI : (Ljava/lang/Object;)Z
    //   88: ifeq -> 99
    //   91: new java/lang/AssertionError
    //   94: dup
    //   95: invokespecial <init> : ()V
    //   98: athrow
    //   99: aload #11
    //   101: <illegal opcode> 11 : (Lnet/minecraft/entity/Entity;)D
    //   106: dstore #12
    //   108: aload #11
    //   110: <illegal opcode> 12 : (Lnet/minecraft/entity/Entity;)D
    //   115: dstore #14
    //   117: aload #11
    //   119: <illegal opcode> 13 : (Lnet/minecraft/entity/Entity;)D
    //   124: dstore #16
    //   126: aload #11
    //   128: aload_0
    //   129: aload #11
    //   131: <illegal opcode> 14 : (Lnet/minecraft/entity/Entity;)D
    //   136: aload #11
    //   138: <illegal opcode> 11 : (Lnet/minecraft/entity/Entity;)D
    //   143: fload #8
    //   145: invokespecial interpolate : (DDF)D
    //   148: putfield field_70165_t : D
    //   151: aload #11
    //   153: aload_0
    //   154: aload #11
    //   156: <illegal opcode> 15 : (Lnet/minecraft/entity/Entity;)D
    //   161: aload #11
    //   163: <illegal opcode> 12 : (Lnet/minecraft/entity/Entity;)D
    //   168: fload #8
    //   170: invokespecial interpolate : (DDF)D
    //   173: putfield field_70163_u : D
    //   176: aload #11
    //   178: aload_0
    //   179: aload #11
    //   181: <illegal opcode> 16 : (Lnet/minecraft/entity/Entity;)D
    //   186: aload #11
    //   188: <illegal opcode> 13 : (Lnet/minecraft/entity/Entity;)D
    //   193: fload #8
    //   195: invokespecial interpolate : (DDF)D
    //   198: putfield field_70161_v : D
    //   201: aload_0
    //   202: aload_1
    //   203: invokespecial getDisplayTag : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   206: astore #18
    //   208: aload #11
    //   210: dload_2
    //   211: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   216: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   221: <illegal opcode> 18 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   226: dadd
    //   227: dload #4
    //   229: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   234: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   239: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   244: dadd
    //   245: dload #6
    //   247: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   252: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   257: <illegal opcode> 20 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   262: dadd
    //   263: <illegal opcode> 21 : (Lnet/minecraft/entity/Entity;DDD)D
    //   268: dstore #19
    //   270: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   275: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   280: aload #18
    //   282: <illegal opcode> 23 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;)I
    //   287: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   290: iconst_2
    //   291: iaload
    //   292: idiv
    //   293: istore #21
    //   295: ldc2_w 0.0018
    //   298: aload_0
    //   299: <illegal opcode> 24 : (Lme/stupitdog/bhp/az;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   304: <illegal opcode> 25 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   309: i2d
    //   310: dload #19
    //   312: ldc2_w 0.3
    //   315: dmul
    //   316: dmul
    //   317: dadd
    //   318: ldc2_w 1000.0
    //   321: ddiv
    //   322: dstore #22
    //   324: ldc2_w 0.0245
    //   327: dstore #22
    //   329: dload #22
    //   331: d2f
    //   332: fstore #24
    //   334: <illegal opcode> 26 : ()V
    //   339: <illegal opcode> 27 : ()V
    //   344: <illegal opcode> 28 : ()V
    //   349: fconst_1
    //   350: ldc_w -1500000.0
    //   353: <illegal opcode> 29 : (FF)V
    //   358: <illegal opcode> 30 : ()V
    //   363: dload_2
    //   364: d2f
    //   365: dload #9
    //   367: d2f
    //   368: ldc_w 1.4
    //   371: fadd
    //   372: dload #6
    //   374: d2f
    //   375: <illegal opcode> 31 : (FFF)V
    //   380: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   385: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   390: <illegal opcode> 32 : (Lnet/minecraft/client/renderer/entity/RenderManager;)F
    //   395: fneg
    //   396: fconst_0
    //   397: fconst_1
    //   398: fconst_0
    //   399: <illegal opcode> 33 : (FFFF)V
    //   404: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   409: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   414: <illegal opcode> 34 : (Lnet/minecraft/client/renderer/entity/RenderManager;)F
    //   419: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   424: <illegal opcode> 35 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   429: <illegal opcode> 36 : (Lnet/minecraft/client/settings/GameSettings;)I
    //   434: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   437: iconst_2
    //   438: iaload
    //   439: invokestatic lIIIlIIlIlIIIlll : (II)Z
    //   442: ifeq -> 506
    //   445: ldc_w -1.0
    //   448: ldc ''
    //   450: invokevirtual length : ()I
    //   453: pop
    //   454: ldc ' '
    //   456: invokevirtual length : ()I
    //   459: ldc ' '
    //   461: invokevirtual length : ()I
    //   464: ldc ' '
    //   466: invokevirtual length : ()I
    //   469: ishl
    //   470: ishl
    //   471: sipush #146
    //   474: sipush #151
    //   477: ixor
    //   478: ldc_w '   '
    //   481: invokevirtual length : ()I
    //   484: ishl
    //   485: sipush #130
    //   488: sipush #135
    //   491: ixor
    //   492: ldc_w '   '
    //   495: invokevirtual length : ()I
    //   498: ishl
    //   499: iconst_m1
    //   500: ixor
    //   501: iand
    //   502: if_icmpge -> 507
    //   505: return
    //   506: fconst_1
    //   507: fconst_0
    //   508: fconst_0
    //   509: <illegal opcode> 33 : (FFFF)V
    //   514: fload #24
    //   516: fneg
    //   517: fload #24
    //   519: fneg
    //   520: fload #24
    //   522: <illegal opcode> 37 : (FFF)V
    //   527: <illegal opcode> 38 : ()V
    //   532: <illegal opcode> 39 : ()V
    //   537: <illegal opcode> 39 : ()V
    //   542: iload #21
    //   544: ineg
    //   545: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   548: iconst_2
    //   549: iaload
    //   550: isub
    //   551: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   554: iconst_1
    //   555: iaload
    //   556: isub
    //   557: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   562: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   567: <illegal opcode> 40 : (Lnet/minecraft/client/gui/FontRenderer;)I
    //   572: ineg
    //   573: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   576: iconst_1
    //   577: iaload
    //   578: iadd
    //   579: iload #21
    //   581: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   584: iconst_3
    //   585: iaload
    //   586: iadd
    //   587: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   590: iconst_0
    //   591: iaload
    //   592: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   595: bipush #7
    //   597: iaload
    //   598: <illegal opcode> 41 : (IIIII)V
    //   603: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   608: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   613: aload #18
    //   615: iload #21
    //   617: ineg
    //   618: i2f
    //   619: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   624: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   629: <illegal opcode> 40 : (Lnet/minecraft/client/gui/FontRenderer;)I
    //   634: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   637: iconst_1
    //   638: iaload
    //   639: isub
    //   640: ineg
    //   641: i2f
    //   642: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   645: bipush #8
    //   647: iaload
    //   648: <illegal opcode> 42 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   653: ldc ''
    //   655: invokevirtual length : ()I
    //   658: pop2
    //   659: aload_1
    //   660: <illegal opcode> 43 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   665: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   670: astore #25
    //   672: aload #25
    //   674: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   679: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   682: ifeq -> 727
    //   685: aload #25
    //   687: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   692: instanceof net/minecraft/item/ItemTool
    //   695: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   698: ifeq -> 717
    //   701: aload #25
    //   703: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   708: instanceof net/minecraft/item/ItemArmor
    //   711: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   714: ifeq -> 727
    //   717: aload #25
    //   719: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   722: iconst_1
    //   723: iaload
    //   724: putfield field_77994_a : I
    //   727: aload #25
    //   729: <illegal opcode> 47 : (Lnet/minecraft/item/ItemStack;)Z
    //   734: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   737: ifeq -> 869
    //   740: aload #25
    //   742: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   747: <illegal opcode> 48 : ()Lnet/minecraft/item/Item;
    //   752: invokestatic lIIIlIIlIlIIlIII : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   755: ifeq -> 869
    //   758: aload #25
    //   760: <illegal opcode> 49 : (Lnet/minecraft/item/ItemStack;)Ljava/lang/String;
    //   765: astore #26
    //   767: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   772: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   777: aload #26
    //   779: <illegal opcode> 23 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;)I
    //   784: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   787: iconst_2
    //   788: iaload
    //   789: idiv
    //   790: istore #27
    //   792: <illegal opcode> 50 : ()V
    //   797: ldc_w 0.75
    //   800: ldc_w 0.75
    //   803: fconst_0
    //   804: <illegal opcode> 51 : (FFF)V
    //   809: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   814: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   819: aload #26
    //   821: iload #27
    //   823: ineg
    //   824: i2f
    //   825: aload_0
    //   826: aload_1
    //   827: invokespecial getBiggestArmorTag : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   830: ldc_w 18.0
    //   833: fadd
    //   834: fneg
    //   835: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   838: bipush #8
    //   840: iaload
    //   841: <illegal opcode> 42 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   846: ldc ''
    //   848: invokevirtual length : ()I
    //   851: pop2
    //   852: ldc_w 1.5
    //   855: ldc_w 1.5
    //   858: fconst_1
    //   859: <illegal opcode> 51 : (FFF)V
    //   864: <illegal opcode> 52 : ()V
    //   869: aload_0
    //   870: <illegal opcode> 53 : (Lme/stupitdog/bhp/az;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   875: <illegal opcode> 54 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   880: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   883: ifeq -> 1492
    //   886: <illegal opcode> 26 : ()V
    //   891: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   894: bipush #9
    //   896: iaload
    //   897: istore #26
    //   899: aload_1
    //   900: <illegal opcode> 55 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   905: <illegal opcode> 56 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   910: <illegal opcode> 57 : (Lnet/minecraft/util/NonNullList;)Ljava/util/Iterator;
    //   915: astore #27
    //   917: aload #27
    //   919: <illegal opcode> 58 : (Ljava/util/Iterator;)Z
    //   924: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   927: ifeq -> 974
    //   930: aload #27
    //   932: <illegal opcode> 59 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   937: checkcast net/minecraft/item/ItemStack
    //   940: astore #28
    //   942: aload #28
    //   944: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   947: ifeq -> 953
    //   950: iinc #26, -8
    //   953: ldc ''
    //   955: invokevirtual length : ()I
    //   958: pop
    //   959: ldc ' '
    //   961: invokevirtual length : ()I
    //   964: ldc ' '
    //   966: invokevirtual length : ()I
    //   969: ishl
    //   970: ifge -> 917
    //   973: return
    //   974: iinc #26, -8
    //   977: aload_1
    //   978: <illegal opcode> 60 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   983: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   988: astore #27
    //   990: aload #27
    //   992: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   997: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1000: ifeq -> 1045
    //   1003: aload #27
    //   1005: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1010: instanceof net/minecraft/item/ItemTool
    //   1013: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   1016: ifeq -> 1035
    //   1019: aload #27
    //   1021: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1026: instanceof net/minecraft/item/ItemArmor
    //   1029: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1032: ifeq -> 1045
    //   1035: aload #27
    //   1037: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   1040: iconst_1
    //   1041: iaload
    //   1042: putfield field_77994_a : I
    //   1045: aload_0
    //   1046: aload #27
    //   1048: iload #26
    //   1050: invokespecial renderItemStack : (Lnet/minecraft/item/ItemStack;I)V
    //   1053: iinc #26, 16
    //   1056: aload_0
    //   1057: <illegal opcode> 61 : (Lme/stupitdog/bhp/az;)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   1062: <illegal opcode> 54 : (Lme/stupitdog/bhp/f100000000000000000000$Boolean;)Z
    //   1067: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1070: ifeq -> 1313
    //   1073: aload_1
    //   1074: <illegal opcode> 55 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   1079: <illegal opcode> 56 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   1084: <illegal opcode> 57 : (Lnet/minecraft/util/NonNullList;)Ljava/util/Iterator;
    //   1089: astore #28
    //   1091: aload #28
    //   1093: <illegal opcode> 58 : (Ljava/util/Iterator;)Z
    //   1098: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1101: ifeq -> 1234
    //   1104: aload #28
    //   1106: <illegal opcode> 59 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   1111: checkcast net/minecraft/item/ItemStack
    //   1114: astore #29
    //   1116: aload #29
    //   1118: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   1121: ifeq -> 1199
    //   1124: aload #29
    //   1126: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   1131: astore #30
    //   1133: aload #30
    //   1135: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   1140: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1143: ifeq -> 1188
    //   1146: aload #30
    //   1148: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1153: instanceof net/minecraft/item/ItemTool
    //   1156: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   1159: ifeq -> 1178
    //   1162: aload #30
    //   1164: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1169: instanceof net/minecraft/item/ItemArmor
    //   1172: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1175: ifeq -> 1188
    //   1178: aload #30
    //   1180: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   1183: iconst_1
    //   1184: iaload
    //   1185: putfield field_77994_a : I
    //   1188: aload_0
    //   1189: aload #30
    //   1191: iload #26
    //   1193: invokespecial renderItemStack : (Lnet/minecraft/item/ItemStack;I)V
    //   1196: iinc #26, 16
    //   1199: ldc ''
    //   1201: invokevirtual length : ()I
    //   1204: pop
    //   1205: ldc ' '
    //   1207: invokevirtual length : ()I
    //   1210: ldc ' '
    //   1212: invokevirtual length : ()I
    //   1215: ishl
    //   1216: ldc ' '
    //   1218: invokevirtual length : ()I
    //   1221: ldc ' '
    //   1223: invokevirtual length : ()I
    //   1226: ishl
    //   1227: iconst_m1
    //   1228: ixor
    //   1229: iand
    //   1230: ifeq -> 1091
    //   1233: return
    //   1234: ldc ''
    //   1236: invokevirtual length : ()I
    //   1239: pop
    //   1240: sipush #142
    //   1243: sipush #141
    //   1246: iadd
    //   1247: sipush #141
    //   1250: isub
    //   1251: bipush #13
    //   1253: iadd
    //   1254: bipush #99
    //   1256: bipush #70
    //   1258: ixor
    //   1259: ldc ' '
    //   1261: invokevirtual length : ()I
    //   1264: ldc ' '
    //   1266: invokevirtual length : ()I
    //   1269: ishl
    //   1270: ishl
    //   1271: ixor
    //   1272: ldc ' '
    //   1274: invokevirtual length : ()I
    //   1277: ishl
    //   1278: bipush #11
    //   1280: bipush #74
    //   1282: ixor
    //   1283: bipush #65
    //   1285: bipush #102
    //   1287: ixor
    //   1288: ldc ' '
    //   1290: invokevirtual length : ()I
    //   1293: ishl
    //   1294: ixor
    //   1295: ldc ' '
    //   1297: invokevirtual length : ()I
    //   1300: ishl
    //   1301: ldc ' '
    //   1303: invokevirtual length : ()I
    //   1306: ineg
    //   1307: ixor
    //   1308: iand
    //   1309: ifeq -> 1479
    //   1312: return
    //   1313: aload_1
    //   1314: <illegal opcode> 55 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   1319: <illegal opcode> 56 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   1324: <illegal opcode> 62 : (Lnet/minecraft/util/NonNullList;)I
    //   1329: istore #28
    //   1331: iload #28
    //   1333: invokestatic lIIIlIIlIlIIlIlI : (I)Z
    //   1336: ifeq -> 1479
    //   1339: aload_1
    //   1340: <illegal opcode> 55 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   1345: <illegal opcode> 56 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   1350: iload #28
    //   1352: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   1355: iconst_1
    //   1356: iaload
    //   1357: isub
    //   1358: <illegal opcode> 63 : (Lnet/minecraft/util/NonNullList;I)Ljava/lang/Object;
    //   1363: checkcast net/minecraft/item/ItemStack
    //   1366: astore #29
    //   1368: aload #29
    //   1370: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   1375: astore #30
    //   1377: aload #30
    //   1379: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   1384: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1387: ifeq -> 1432
    //   1390: aload #30
    //   1392: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1397: instanceof net/minecraft/item/ItemTool
    //   1400: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   1403: ifeq -> 1422
    //   1406: aload #30
    //   1408: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   1413: instanceof net/minecraft/item/ItemArmor
    //   1416: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   1419: ifeq -> 1432
    //   1422: aload #30
    //   1424: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   1427: iconst_1
    //   1428: iaload
    //   1429: putfield field_77994_a : I
    //   1432: aload_0
    //   1433: aload #30
    //   1435: iload #26
    //   1437: invokespecial renderItemStack : (Lnet/minecraft/item/ItemStack;I)V
    //   1440: iinc #26, 16
    //   1443: iinc #28, -1
    //   1446: ldc ''
    //   1448: invokevirtual length : ()I
    //   1451: pop
    //   1452: bipush #71
    //   1454: bipush #64
    //   1456: iadd
    //   1457: bipush #79
    //   1459: isub
    //   1460: bipush #103
    //   1462: iadd
    //   1463: bipush #54
    //   1465: bipush #123
    //   1467: ixor
    //   1468: ldc ' '
    //   1470: invokevirtual length : ()I
    //   1473: ishl
    //   1474: ixor
    //   1475: ifgt -> 1331
    //   1478: return
    //   1479: aload_0
    //   1480: aload #25
    //   1482: iload #26
    //   1484: invokespecial renderItemStack : (Lnet/minecraft/item/ItemStack;I)V
    //   1487: <illegal opcode> 64 : ()V
    //   1492: aload #11
    //   1494: dload #12
    //   1496: putfield field_70165_t : D
    //   1499: aload #11
    //   1501: dload #14
    //   1503: putfield field_70163_u : D
    //   1506: aload #11
    //   1508: dload #16
    //   1510: putfield field_70161_v : D
    //   1513: <illegal opcode> 65 : ()V
    //   1518: <illegal opcode> 66 : ()V
    //   1523: <illegal opcode> 67 : ()V
    //   1528: fconst_1
    //   1529: ldc_w 1500000.0
    //   1532: <illegal opcode> 29 : (FF)V
    //   1537: <illegal opcode> 64 : ()V
    //   1542: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   767	102	26	lllllllllllllllIllIIIlIIIlIllllI	Ljava/lang/String;
    //   792	77	27	lllllllllllllllIllIIIlIIIlIlllIl	I
    //   942	11	28	lllllllllllllllIllIIIlIIIlIlllII	Lnet/minecraft/item/ItemStack;
    //   1133	66	30	lllllllllllllllIllIIIlIIIlIllIll	Lnet/minecraft/item/ItemStack;
    //   1116	83	29	lllllllllllllllIllIIIlIIIlIllIlI	Lnet/minecraft/item/ItemStack;
    //   1368	75	29	lllllllllllllllIllIIIlIIIlIllIIl	Lnet/minecraft/item/ItemStack;
    //   1377	66	30	lllllllllllllllIllIIIlIIIlIllIII	Lnet/minecraft/item/ItemStack;
    //   1331	148	28	lllllllllllllllIllIIIlIIIlIlIlll	I
    //   899	593	26	lllllllllllllllIllIIIlIIIlIlIllI	I
    //   990	502	27	lllllllllllllllIllIIIlIIIlIlIlIl	Lnet/minecraft/item/ItemStack;
    //   0	1543	0	lllllllllllllllIllIIIlIIIlIlIlII	Lme/stupitdog/bhp/az;
    //   0	1543	1	lllllllllllllllIllIIIlIIIlIlIIll	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	1543	2	lllllllllllllllIllIIIlIIIlIlIIlI	D
    //   0	1543	4	lllllllllllllllIllIIIlIIIlIlIIIl	D
    //   0	1543	6	lllllllllllllllIllIIIlIIIlIlIIII	D
    //   0	1543	8	lllllllllllllllIllIIIlIIIlIIllll	F
    //   4	1539	9	lllllllllllllllIllIIIlIIIlIIlllI	D
    //   72	1471	11	lllllllllllllllIllIIIlIIIlIIllIl	Lnet/minecraft/entity/Entity;
    //   108	1435	12	lllllllllllllllIllIIIlIIIlIIllII	D
    //   117	1426	14	lllllllllllllllIllIIIlIIIlIIlIll	D
    //   126	1417	16	lllllllllllllllIllIIIlIIIlIIlIlI	D
    //   208	1335	18	lllllllllllllllIllIIIlIIIlIIlIIl	Ljava/lang/String;
    //   270	1273	19	lllllllllllllllIllIIIlIIIlIIlIII	D
    //   295	1248	21	lllllllllllllllIllIIIlIIIlIIIlll	I
    //   324	1219	22	lllllllllllllllIllIIIlIIIlIIIllI	D
    //   334	1209	24	lllllllllllllllIllIIIlIIIlIIIlIl	F
    //   672	871	25	lllllllllllllllIllIIIlIIIlIIIlII	Lnet/minecraft/item/ItemStack;
  }
  
  private void renderItemStack(ItemStack lllllllllllllllIllIIIlIIIlIIIIlI, int lllllllllllllllIllIIIlIIIlIIIIIl) {
    // Byte code:
    //   0: <illegal opcode> 26 : ()V
    //   5: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   8: iconst_1
    //   9: iaload
    //   10: <illegal opcode> 68 : (Z)V
    //   15: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   18: bipush #10
    //   20: iaload
    //   21: <illegal opcode> 69 : (I)V
    //   26: <illegal opcode> 27 : ()V
    //   31: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   36: <illegal opcode> 70 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   41: ldc_w -150.0
    //   44: putfield field_77023_b : F
    //   47: <illegal opcode> 71 : ()V
    //   52: <illegal opcode> 65 : ()V
    //   57: <illegal opcode> 72 : ()V
    //   62: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   67: <illegal opcode> 70 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   72: aload_1
    //   73: iload_2
    //   74: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   77: bipush #11
    //   79: iaload
    //   80: <illegal opcode> 73 : (Lnet/minecraft/client/renderer/RenderItem;Lnet/minecraft/item/ItemStack;II)V
    //   85: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   90: <illegal opcode> 70 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   95: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   100: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   105: aload_1
    //   106: iload_2
    //   107: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   110: bipush #11
    //   112: iaload
    //   113: <illegal opcode> 74 : (Lnet/minecraft/client/renderer/RenderItem;Lnet/minecraft/client/gui/FontRenderer;Lnet/minecraft/item/ItemStack;II)V
    //   118: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   123: <illegal opcode> 70 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/RenderItem;
    //   128: fconst_0
    //   129: putfield field_77023_b : F
    //   132: <illegal opcode> 75 : ()V
    //   137: <illegal opcode> 76 : ()V
    //   142: <illegal opcode> 77 : ()V
    //   147: ldc_w 0.5
    //   150: ldc_w 0.5
    //   153: ldc_w 0.5
    //   156: <illegal opcode> 37 : (FFF)V
    //   161: <illegal opcode> 38 : ()V
    //   166: aload_0
    //   167: aload_1
    //   168: iload_2
    //   169: invokespecial renderEnchantmentText : (Lnet/minecraft/item/ItemStack;I)V
    //   172: <illegal opcode> 65 : ()V
    //   177: fconst_2
    //   178: fconst_2
    //   179: fconst_2
    //   180: <illegal opcode> 37 : (FFF)V
    //   185: <illegal opcode> 64 : ()V
    //   190: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	191	0	lllllllllllllllIllIIIlIIIlIIIIll	Lme/stupitdog/bhp/az;
    //   0	191	1	lllllllllllllllIllIIIlIIIlIIIIlI	Lnet/minecraft/item/ItemStack;
    //   0	191	2	lllllllllllllllIllIIIlIIIlIIIIIl	I
  }
  
  private void renderEnchantmentText(ItemStack lllllllllllllllIllIIIlIIIIlllIll, int lllllllllllllllIllIIIlIIIIlllIlI) {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   3: bipush #12
    //   5: iaload
    //   6: istore_3
    //   7: aload_1
    //   8: <illegal opcode> 78 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList;
    //   13: astore #4
    //   15: aload #4
    //   17: <illegal opcode> 79 : (Lnet/minecraft/nbt/NBTTagList;)I
    //   22: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: invokestatic lIIIlIIlIlIIlIll : (II)Z
    //   30: ifeq -> 83
    //   33: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   38: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   43: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   46: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   49: bipush #13
    //   51: iaload
    //   52: aaload
    //   53: iload_2
    //   54: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   57: iconst_2
    //   58: iaload
    //   59: imul
    //   60: i2f
    //   61: iload_3
    //   62: i2f
    //   63: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   66: bipush #14
    //   68: iaload
    //   69: <illegal opcode> 42 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   74: ldc ''
    //   76: invokevirtual length : ()I
    //   79: pop2
    //   80: iinc #3, -8
    //   83: aload_1
    //   84: <illegal opcode> 80 : (Lnet/minecraft/item/ItemStack;)Z
    //   89: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   92: ifeq -> 410
    //   95: aload_1
    //   96: <illegal opcode> 81 : (Lnet/minecraft/item/ItemStack;)I
    //   101: istore #5
    //   103: iload #5
    //   105: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   108: bipush #15
    //   110: iaload
    //   111: invokestatic lIIIlIIlIlIIllII : (II)Z
    //   114: ifeq -> 179
    //   117: new java/lang/StringBuilder
    //   120: dup
    //   121: invokespecial <init> : ()V
    //   124: aload_0
    //   125: <illegal opcode> 82 : (Lme/stupitdog/bhp/az;)Ljava/lang/String;
    //   130: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   138: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   141: bipush #16
    //   143: iaload
    //   144: aaload
    //   145: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   155: astore #6
    //   157: ldc ''
    //   159: invokevirtual length : ()I
    //   162: pop
    //   163: ldc_w '   '
    //   166: invokevirtual length : ()I
    //   169: ldc ' '
    //   171: invokevirtual length : ()I
    //   174: ineg
    //   175: if_icmpgt -> 295
    //   178: return
    //   179: iload #5
    //   181: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   184: bipush #17
    //   186: iaload
    //   187: invokestatic lIIIlIIlIlIIllII : (II)Z
    //   190: ifeq -> 255
    //   193: new java/lang/StringBuilder
    //   196: dup
    //   197: invokespecial <init> : ()V
    //   200: aload_0
    //   201: <illegal opcode> 82 : (Lme/stupitdog/bhp/az;)Ljava/lang/String;
    //   206: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   214: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   217: bipush #18
    //   219: iaload
    //   220: aaload
    //   221: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   231: astore #6
    //   233: ldc ''
    //   235: invokevirtual length : ()I
    //   238: pop
    //   239: ldc ' '
    //   241: invokevirtual length : ()I
    //   244: ineg
    //   245: ldc ' '
    //   247: invokevirtual length : ()I
    //   250: ineg
    //   251: if_icmpeq -> 295
    //   254: return
    //   255: new java/lang/StringBuilder
    //   258: dup
    //   259: invokespecial <init> : ()V
    //   262: aload_0
    //   263: <illegal opcode> 82 : (Lme/stupitdog/bhp/az;)Ljava/lang/String;
    //   268: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   276: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   279: bipush #19
    //   281: iaload
    //   282: aaload
    //   283: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   293: astore #6
    //   295: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   300: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/FontRenderer;
    //   305: new java/lang/StringBuilder
    //   308: dup
    //   309: invokespecial <init> : ()V
    //   312: aload #6
    //   314: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   319: iload #5
    //   321: <illegal opcode> 85 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   326: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   329: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   332: bipush #20
    //   334: iaload
    //   335: aaload
    //   336: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   346: iload_2
    //   347: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   350: iconst_2
    //   351: iaload
    //   352: imul
    //   353: i2f
    //   354: iload_3
    //   355: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   358: bipush #21
    //   360: iaload
    //   361: invokestatic lIIIlIIlIlIIllIl : (II)Z
    //   364: ifeq -> 390
    //   367: iload_3
    //   368: i2f
    //   369: ldc ''
    //   371: invokevirtual length : ()I
    //   374: pop
    //   375: ldc ' '
    //   377: invokevirtual length : ()I
    //   380: ldc ' '
    //   382: invokevirtual length : ()I
    //   385: ishl
    //   386: ifgt -> 393
    //   389: return
    //   390: ldc_w -62.0
    //   393: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   396: bipush #8
    //   398: iaload
    //   399: <illegal opcode> 42 : (Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;FFI)I
    //   404: ldc ''
    //   406: invokevirtual length : ()I
    //   409: pop2
    //   410: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   157	22	6	lllllllllllllllIllIIIlIIIlIIIIII	Ljava/lang/String;
    //   233	22	6	lllllllllllllllIllIIIlIIIIllllll	Ljava/lang/String;
    //   103	307	5	lllllllllllllllIllIIIlIIIIlllllI	I
    //   295	115	6	lllllllllllllllIllIIIlIIIIllllIl	Ljava/lang/String;
    //   0	411	0	lllllllllllllllIllIIIlIIIIllllII	Lme/stupitdog/bhp/az;
    //   0	411	1	lllllllllllllllIllIIIlIIIIlllIll	Lnet/minecraft/item/ItemStack;
    //   0	411	2	lllllllllllllllIllIIIlIIIIlllIlI	I
    //   7	404	3	lllllllllllllllIllIIIlIIIIlllIIl	I
    //   15	396	4	lllllllllllllllIllIIIlIIIIlllIII	Lnet/minecraft/nbt/NBTTagList;
  }
  
  private float getBiggestArmorTag(EntityPlayer lllllllllllllllIllIIIlIIIIlIIllI) {
    // Byte code:
    //   0: fconst_0
    //   1: fstore_2
    //   2: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   5: iconst_0
    //   6: iaload
    //   7: istore_3
    //   8: aload_1
    //   9: <illegal opcode> 55 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   14: <illegal opcode> 56 : (Lnet/minecraft/entity/player/InventoryPlayer;)Lnet/minecraft/util/NonNullList;
    //   19: <illegal opcode> 57 : (Lnet/minecraft/util/NonNullList;)Ljava/util/Iterator;
    //   24: astore #4
    //   26: aload #4
    //   28: <illegal opcode> 58 : (Ljava/util/Iterator;)Z
    //   33: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   36: ifeq -> 223
    //   39: aload #4
    //   41: <illegal opcode> 59 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   46: checkcast net/minecraft/item/ItemStack
    //   49: astore #5
    //   51: fconst_0
    //   52: fstore #6
    //   54: aload #5
    //   56: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   59: ifeq -> 175
    //   62: aload #5
    //   64: <illegal opcode> 78 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList;
    //   69: astore #7
    //   71: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   74: iconst_0
    //   75: iaload
    //   76: istore #8
    //   78: iload #8
    //   80: aload #7
    //   82: <illegal opcode> 79 : (Lnet/minecraft/nbt/NBTTagList;)I
    //   87: invokestatic lIIIlIIlIlIIllIl : (II)Z
    //   90: ifeq -> 175
    //   93: aload #7
    //   95: iload #8
    //   97: <illegal opcode> 86 : (Lnet/minecraft/nbt/NBTTagList;I)Lnet/minecraft/nbt/NBTTagCompound;
    //   102: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   105: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   108: bipush #22
    //   110: iaload
    //   111: aaload
    //   112: <illegal opcode> 87 : (Lnet/minecraft/nbt/NBTTagCompound;Ljava/lang/String;)S
    //   117: istore #9
    //   119: iload #9
    //   121: <illegal opcode> 88 : (I)Lnet/minecraft/enchantment/Enchantment;
    //   126: astore #10
    //   128: aload #10
    //   130: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   133: ifeq -> 150
    //   136: fload #6
    //   138: ldc_w 8.0
    //   141: fadd
    //   142: fstore #6
    //   144: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   147: iconst_1
    //   148: iaload
    //   149: istore_3
    //   150: iinc #8, 1
    //   153: ldc ''
    //   155: invokevirtual length : ()I
    //   158: pop
    //   159: ldc ' '
    //   161: invokevirtual length : ()I
    //   164: ineg
    //   165: ldc ' '
    //   167: invokevirtual length : ()I
    //   170: if_icmplt -> 78
    //   173: fconst_0
    //   174: freturn
    //   175: fload #6
    //   177: fload_2
    //   178: invokestatic lIIIlIIlIlIIlllI : (FF)I
    //   181: invokestatic lIIIlIIlIlIIlIlI : (I)Z
    //   184: ifeq -> 190
    //   187: fload #6
    //   189: fstore_2
    //   190: ldc ''
    //   192: invokevirtual length : ()I
    //   195: pop
    //   196: ldc ' '
    //   198: invokevirtual length : ()I
    //   201: ldc ' '
    //   203: invokevirtual length : ()I
    //   206: ldc ' '
    //   208: invokevirtual length : ()I
    //   211: ldc ' '
    //   213: invokevirtual length : ()I
    //   216: ishl
    //   217: ishl
    //   218: if_icmple -> 26
    //   221: fconst_0
    //   222: freturn
    //   223: aload_1
    //   224: <illegal opcode> 43 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   229: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   234: astore #4
    //   236: aload #4
    //   238: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   243: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   246: ifeq -> 397
    //   249: fconst_0
    //   250: fstore #5
    //   252: aload #4
    //   254: <illegal opcode> 78 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList;
    //   259: astore #6
    //   261: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   264: iconst_0
    //   265: iaload
    //   266: istore #7
    //   268: iload #7
    //   270: aload #6
    //   272: <illegal opcode> 79 : (Lnet/minecraft/nbt/NBTTagList;)I
    //   277: invokestatic lIIIlIIlIlIIllIl : (II)Z
    //   280: ifeq -> 382
    //   283: aload #6
    //   285: iload #7
    //   287: <illegal opcode> 86 : (Lnet/minecraft/nbt/NBTTagList;I)Lnet/minecraft/nbt/NBTTagCompound;
    //   292: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   295: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   298: bipush #23
    //   300: iaload
    //   301: aaload
    //   302: <illegal opcode> 87 : (Lnet/minecraft/nbt/NBTTagCompound;Ljava/lang/String;)S
    //   307: istore #8
    //   309: iload #8
    //   311: <illegal opcode> 88 : (I)Lnet/minecraft/enchantment/Enchantment;
    //   316: astore #9
    //   318: aload #9
    //   320: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   323: ifeq -> 340
    //   326: fload #5
    //   328: ldc_w 8.0
    //   331: fadd
    //   332: fstore #5
    //   334: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   337: iconst_1
    //   338: iaload
    //   339: istore_3
    //   340: iinc #7, 1
    //   343: ldc ''
    //   345: invokevirtual length : ()I
    //   348: pop
    //   349: ldc ' '
    //   351: invokevirtual length : ()I
    //   354: ldc ' '
    //   356: invokevirtual length : ()I
    //   359: ldc ' '
    //   361: invokevirtual length : ()I
    //   364: ishl
    //   365: ishl
    //   366: ldc ' '
    //   368: invokevirtual length : ()I
    //   371: ldc ' '
    //   373: invokevirtual length : ()I
    //   376: ishl
    //   377: if_icmpgt -> 268
    //   380: fconst_0
    //   381: freturn
    //   382: fload #5
    //   384: fload_2
    //   385: invokestatic lIIIlIIlIlIIlllI : (FF)I
    //   388: invokestatic lIIIlIIlIlIIlIlI : (I)Z
    //   391: ifeq -> 397
    //   394: fload #5
    //   396: fstore_2
    //   397: aload_1
    //   398: <illegal opcode> 60 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   403: <illegal opcode> 44 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack;
    //   408: astore #5
    //   410: aload #5
    //   412: <illegal opcode> 45 : (Lnet/minecraft/item/ItemStack;)Z
    //   417: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   420: ifeq -> 555
    //   423: fconst_0
    //   424: fstore #6
    //   426: aload #5
    //   428: <illegal opcode> 78 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList;
    //   433: astore #7
    //   435: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   438: iconst_0
    //   439: iaload
    //   440: istore #8
    //   442: iload #8
    //   444: aload #7
    //   446: <illegal opcode> 79 : (Lnet/minecraft/nbt/NBTTagList;)I
    //   451: invokestatic lIIIlIIlIlIIllIl : (II)Z
    //   454: ifeq -> 540
    //   457: aload #7
    //   459: iload #8
    //   461: <illegal opcode> 86 : (Lnet/minecraft/nbt/NBTTagList;I)Lnet/minecraft/nbt/NBTTagCompound;
    //   466: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   469: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   472: bipush #24
    //   474: iaload
    //   475: aaload
    //   476: <illegal opcode> 87 : (Lnet/minecraft/nbt/NBTTagCompound;Ljava/lang/String;)S
    //   481: istore #9
    //   483: iload #9
    //   485: <illegal opcode> 88 : (I)Lnet/minecraft/enchantment/Enchantment;
    //   490: astore #10
    //   492: aload #10
    //   494: invokestatic lIIIlIIlIlIIlIIl : (Ljava/lang/Object;)Z
    //   497: ifeq -> 514
    //   500: fload #6
    //   502: ldc_w 8.0
    //   505: fadd
    //   506: fstore #6
    //   508: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   511: iconst_1
    //   512: iaload
    //   513: istore_3
    //   514: iinc #8, 1
    //   517: ldc ''
    //   519: invokevirtual length : ()I
    //   522: pop
    //   523: ldc_w '   '
    //   526: invokevirtual length : ()I
    //   529: ldc ' '
    //   531: invokevirtual length : ()I
    //   534: ineg
    //   535: if_icmpgt -> 442
    //   538: fconst_0
    //   539: freturn
    //   540: fload #6
    //   542: fload_2
    //   543: invokestatic lIIIlIIlIlIIlllI : (FF)I
    //   546: invokestatic lIIIlIIlIlIIlIlI : (I)Z
    //   549: ifeq -> 555
    //   552: fload #6
    //   554: fstore_2
    //   555: iload_3
    //   556: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   559: ifeq -> 579
    //   562: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   565: iconst_0
    //   566: iaload
    //   567: ldc ''
    //   569: invokevirtual length : ()I
    //   572: pop
    //   573: aconst_null
    //   574: ifnull -> 585
    //   577: fconst_0
    //   578: freturn
    //   579: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   582: bipush #25
    //   584: iaload
    //   585: i2f
    //   586: fload_2
    //   587: fadd
    //   588: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   119	31	9	lllllllllllllllIllIIIlIIIIllIlll	S
    //   128	22	10	lllllllllllllllIllIIIlIIIIllIllI	Lnet/minecraft/enchantment/Enchantment;
    //   78	97	8	lllllllllllllllIllIIIlIIIIllIlIl	I
    //   71	104	7	lllllllllllllllIllIIIlIIIIllIlII	Lnet/minecraft/nbt/NBTTagList;
    //   54	136	6	lllllllllllllllIllIIIlIIIIllIIll	F
    //   51	139	5	lllllllllllllllIllIIIlIIIIllIIlI	Lnet/minecraft/item/ItemStack;
    //   309	31	8	lllllllllllllllIllIIIlIIIIllIIIl	S
    //   318	22	9	lllllllllllllllIllIIIlIIIIllIIII	Lnet/minecraft/enchantment/Enchantment;
    //   268	114	7	lllllllllllllllIllIIIlIIIIlIllll	I
    //   252	145	5	lllllllllllllllIllIIIlIIIIlIlllI	F
    //   261	136	6	lllllllllllllllIllIIIlIIIIlIllIl	Lnet/minecraft/nbt/NBTTagList;
    //   483	31	9	lllllllllllllllIllIIIlIIIIlIllII	S
    //   492	22	10	lllllllllllllllIllIIIlIIIIlIlIll	Lnet/minecraft/enchantment/Enchantment;
    //   442	98	8	lllllllllllllllIllIIIlIIIIlIlIlI	I
    //   426	129	6	lllllllllllllllIllIIIlIIIIlIlIIl	F
    //   435	120	7	lllllllllllllllIllIIIlIIIIlIlIII	Lnet/minecraft/nbt/NBTTagList;
    //   0	589	0	lllllllllllllllIllIIIlIIIIlIIlll	Lme/stupitdog/bhp/az;
    //   0	589	1	lllllllllllllllIllIIIlIIIIlIIllI	Lnet/minecraft/entity/player/EntityPlayer;
    //   2	587	2	lllllllllllllllIllIIIlIIIIlIIlIl	F
    //   8	581	3	lllllllllllllllIllIIIlIIIIlIIlII	Z
    //   236	353	4	lllllllllllllllIllIIIlIIIIlIIIll	Lnet/minecraft/item/ItemStack;
    //   410	179	5	lllllllllllllllIllIIIlIIIIlIIIlI	Lnet/minecraft/item/ItemStack;
  }
  
  private String getDisplayTag(EntityPlayer lllllllllllllllIllIIIlIIIIlIIIII) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 89 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   6: astore_2
    //   7: aload_0
    //   8: aload_1
    //   9: <illegal opcode> 90 : (Lme/stupitdog/bhp/az;Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   14: astore_3
    //   15: aload_0
    //   16: aload_1
    //   17: <illegal opcode> 91 : (Lme/stupitdog/bhp/az;Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   22: astore #4
    //   24: <illegal opcode> 92 : ()Lme/stupitdog/bhp/f9;
    //   29: <illegal opcode> 93 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/a;
    //   34: new java/lang/StringBuilder
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: aload_1
    //   42: <illegal opcode> 94 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/util/UUID;
    //   47: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   52: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   55: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   58: bipush #26
    //   60: iaload
    //   61: aaload
    //   62: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   72: <illegal opcode> 96 : (Lme/stupitdog/bhp/a;Ljava/lang/String;)Z
    //   77: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   80: ifeq -> 130
    //   83: new java/lang/StringBuilder
    //   86: dup
    //   87: invokespecial <init> : ()V
    //   90: <illegal opcode> 97 : ()Lnet/minecraft/util/text/TextFormatting;
    //   95: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   100: aload_2
    //   101: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   111: astore_2
    //   112: ldc ''
    //   114: invokevirtual length : ()I
    //   117: pop
    //   118: ldc_w '  '
    //   121: invokevirtual length : ()I
    //   124: ineg
    //   125: iflt -> 159
    //   128: aconst_null
    //   129: areturn
    //   130: new java/lang/StringBuilder
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: <illegal opcode> 98 : ()Lnet/minecraft/util/text/TextFormatting;
    //   142: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   147: aload_2
    //   148: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   158: astore_2
    //   159: new java/lang/StringBuilder
    //   162: dup
    //   163: invokespecial <init> : ()V
    //   166: aload_3
    //   167: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   175: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   178: bipush #27
    //   180: iaload
    //   181: aaload
    //   182: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: aload_2
    //   188: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: <illegal opcode> 98 : ()Lnet/minecraft/util/text/TextFormatting;
    //   198: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   203: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   206: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   209: bipush #28
    //   211: iaload
    //   212: aaload
    //   213: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   218: aload #4
    //   220: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   230: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	231	0	lllllllllllllllIllIIIlIIIIlIIIIl	Lme/stupitdog/bhp/az;
    //   0	231	1	lllllllllllllllIllIIIlIIIIlIIIII	Lnet/minecraft/entity/player/EntityPlayer;
    //   7	224	2	lllllllllllllllIllIIIlIIIIIlllll	Ljava/lang/String;
    //   15	216	3	lllllllllllllllIllIIIlIIIIIllllI	Ljava/lang/String;
    //   24	207	4	lllllllllllllllIllIIIlIIIIIlllIl	Ljava/lang/String;
  }
  
  public String getPing(EntityPlayer lllllllllllllllIllIIIlIIIIIllIII) {
    // Byte code:
    //   0: <illegal opcode> 8 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 99 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   10: <illegal opcode> 100 : (Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast net/minecraft/client/network/NetHandlerPlayClient
    //   18: aload_1
    //   19: <illegal opcode> 94 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/util/UUID;
    //   24: <illegal opcode> 101 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Ljava/util/UUID;)Lnet/minecraft/client/network/NetworkPlayerInfo;
    //   29: <illegal opcode> 102 : (Lnet/minecraft/client/network/NetworkPlayerInfo;)I
    //   34: istore_2
    //   35: new java/lang/StringBuilder
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: iload_2
    //   43: <illegal opcode> 85 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   48: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   51: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   54: bipush #29
    //   56: iaload
    //   57: aaload
    //   58: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   68: astore_3
    //   69: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   72: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   75: bipush #30
    //   77: iaload
    //   78: aaload
    //   79: astore #4
    //   81: iload_2
    //   82: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   85: bipush #31
    //   87: iaload
    //   88: invokestatic lIIIlIIlIlIIllll : (II)Z
    //   91: ifeq -> 107
    //   94: iload_2
    //   95: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   98: bipush #31
    //   100: iaload
    //   101: invokestatic lIIIlIIlIlIIllIl : (II)Z
    //   104: ifeq -> 146
    //   107: new java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: <illegal opcode> 103 : ()Lnet/minecraft/util/text/TextFormatting;
    //   119: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   124: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   127: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   130: bipush #25
    //   132: iaload
    //   133: aaload
    //   134: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   144: astore #4
    //   146: iload_2
    //   147: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   150: bipush #32
    //   152: iaload
    //   153: invokestatic lIIIlIIlIlIIlIll : (II)Z
    //   156: ifeq -> 198
    //   159: new java/lang/StringBuilder
    //   162: dup
    //   163: invokespecial <init> : ()V
    //   166: <illegal opcode> 104 : ()Lnet/minecraft/util/text/TextFormatting;
    //   171: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   176: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   179: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   182: bipush #33
    //   184: iaload
    //   185: aaload
    //   186: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   196: astore #4
    //   198: iload_2
    //   199: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   202: bipush #34
    //   204: iaload
    //   205: invokestatic lIIIlIIlIlIIlIll : (II)Z
    //   208: ifeq -> 250
    //   211: new java/lang/StringBuilder
    //   214: dup
    //   215: invokespecial <init> : ()V
    //   218: <illegal opcode> 105 : ()Lnet/minecraft/util/text/TextFormatting;
    //   223: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   228: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   231: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   234: bipush #35
    //   236: iaload
    //   237: aaload
    //   238: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   248: astore #4
    //   250: iload_2
    //   251: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   254: bipush #36
    //   256: iaload
    //   257: invokestatic lIIIlIIlIlIIlIll : (II)Z
    //   260: ifeq -> 302
    //   263: new java/lang/StringBuilder
    //   266: dup
    //   267: invokespecial <init> : ()V
    //   270: <illegal opcode> 106 : ()Lnet/minecraft/util/text/TextFormatting;
    //   275: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   280: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   283: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   286: bipush #37
    //   288: iaload
    //   289: aaload
    //   290: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   295: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   300: astore #4
    //   302: new java/lang/StringBuilder
    //   305: dup
    //   306: invokespecial <init> : ()V
    //   309: aload #4
    //   311: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: aload_3
    //   317: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   322: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   327: astore_3
    //   328: aload_3
    //   329: areturn
    //   330: astore_2
    //   331: aconst_null
    //   332: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   35	295	2	lllllllllllllllIllIIIlIIIIIlllII	I
    //   69	261	3	lllllllllllllllIllIIIlIIIIIllIll	Ljava/lang/String;
    //   81	249	4	lllllllllllllllIllIIIlIIIIIllIlI	Ljava/lang/String;
    //   0	333	0	lllllllllllllllIllIIIlIIIIIllIIl	Lme/stupitdog/bhp/az;
    //   0	333	1	lllllllllllllllIllIIIlIIIIIllIII	Lnet/minecraft/entity/player/EntityPlayer;
    // Exception table:
    //   from	to	target	type
    //   0	329	330	java/lang/Exception
  }
  
  public String getHealth(EntityPlayer lllllllllllllllIllIIIlIIIIIlIllI) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: aload_1
    //   8: <illegal opcode> 107 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   13: aload_1
    //   14: <illegal opcode> 108 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   19: fadd
    //   20: <illegal opcode> 109 : (Ljava/lang/StringBuilder;F)Ljava/lang/StringBuilder;
    //   25: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   28: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   31: bipush #38
    //   33: iaload
    //   34: aaload
    //   35: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   45: astore_2
    //   46: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   49: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   52: bipush #17
    //   54: iaload
    //   55: aaload
    //   56: astore_3
    //   57: aload_1
    //   58: <illegal opcode> 107 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   63: ldc_w 36.0
    //   66: invokestatic lIIIlIIlIlIlIIII : (FF)I
    //   69: invokestatic lIIIlIIlIlIlIIIl : (I)Z
    //   72: ifeq -> 113
    //   75: new java/lang/StringBuilder
    //   78: dup
    //   79: invokespecial <init> : ()V
    //   82: <illegal opcode> 103 : ()Lnet/minecraft/util/text/TextFormatting;
    //   87: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   92: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   95: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   98: bipush #39
    //   100: iaload
    //   101: aaload
    //   102: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   112: astore_3
    //   113: aload_1
    //   114: <illegal opcode> 107 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   119: ldc_w 15.0
    //   122: invokestatic lIIIlIIlIlIlIIII : (FF)I
    //   125: invokestatic lIIIlIIlIlIlIIIl : (I)Z
    //   128: ifeq -> 169
    //   131: new java/lang/StringBuilder
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: <illegal opcode> 104 : ()Lnet/minecraft/util/text/TextFormatting;
    //   143: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   148: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   151: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   154: bipush #40
    //   156: iaload
    //   157: aaload
    //   158: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   168: astore_3
    //   169: aload_1
    //   170: <illegal opcode> 107 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   175: ldc_w 10.0
    //   178: invokestatic lIIIlIIlIlIlIIII : (FF)I
    //   181: invokestatic lIIIlIIlIlIlIIIl : (I)Z
    //   184: ifeq -> 225
    //   187: new java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial <init> : ()V
    //   194: <illegal opcode> 105 : ()Lnet/minecraft/util/text/TextFormatting;
    //   199: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   204: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   207: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   210: bipush #41
    //   212: iaload
    //   213: aaload
    //   214: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   224: astore_3
    //   225: aload_1
    //   226: <illegal opcode> 107 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   231: ldc_w 5.0
    //   234: invokestatic lIIIlIIlIlIlIIII : (FF)I
    //   237: invokestatic lIIIlIIlIlIlIIIl : (I)Z
    //   240: ifeq -> 281
    //   243: new java/lang/StringBuilder
    //   246: dup
    //   247: invokespecial <init> : ()V
    //   250: <illegal opcode> 106 : ()Lnet/minecraft/util/text/TextFormatting;
    //   255: <illegal opcode> 95 : (Ljava/lang/StringBuilder;Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   260: getstatic me/stupitdog/bhp/az.llIIllIlIIIlll : [Ljava/lang/String;
    //   263: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   266: bipush #42
    //   268: iaload
    //   269: aaload
    //   270: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   280: astore_3
    //   281: new java/lang/StringBuilder
    //   284: dup
    //   285: invokespecial <init> : ()V
    //   288: aload_3
    //   289: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: aload_2
    //   295: <illegal opcode> 83 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: <illegal opcode> 84 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   305: astore_2
    //   306: aload_2
    //   307: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	308	0	lllllllllllllllIllIIIlIIIIIlIlll	Lme/stupitdog/bhp/az;
    //   0	308	1	lllllllllllllllIllIIIlIIIIIlIllI	Lnet/minecraft/entity/player/EntityPlayer;
    //   46	262	2	lllllllllllllllIllIIIlIIIIIlIlIl	Ljava/lang/String;
    //   57	251	3	lllllllllllllllIllIIIlIIIIIlIlII	Ljava/lang/String;
  }
  
  private double interpolate(double lllllllllllllllIllIIIlIIIIIlIIlI, double lllllllllllllllIllIIIlIIIIIlIIIl, float lllllllllllllllIllIIIlIIIIIlIIII) {
    return lllllllllllllllIllIIIlIIIIIlIIlI + (lllllllllllllllIllIIIlIIIIIlIIIl - lllllllllllllllIllIIIlIIIIIlIIlI) * lllllllllllllllIllIIIlIIIIIlIIII;
  }
  
  public String section_sign() {
    return llIIllIlIIIlll[llIIllIlIIlIIl[43]];
  }
  
  public static int getItemDamage(ItemStack lllllllllllllllIllIIIlIIIIIIlllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 110 : (Lnet/minecraft/item/ItemStack;)I
    //   6: aload_0
    //   7: <illegal opcode> 111 : (Lnet/minecraft/item/ItemStack;)I
    //   12: isub
    //   13: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIllIIIlIIIIIIlllI	Lnet/minecraft/item/ItemStack;
  }
  
  public static float getDamageInPercent(ItemStack lllllllllllllllIllIIIlIIIIIIllIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 112 : (Lnet/minecraft/item/ItemStack;)I
    //   6: i2f
    //   7: aload_0
    //   8: <illegal opcode> 110 : (Lnet/minecraft/item/ItemStack;)I
    //   13: i2f
    //   14: fdiv
    //   15: ldc_w 100.0
    //   18: fmul
    //   19: freturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIIIlIIIIIIllIl	Lnet/minecraft/item/ItemStack;
  }
  
  public static int getRoundedDamage(ItemStack lllllllllllllllIllIIIlIIIIIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 113 : (Lnet/minecraft/item/ItemStack;)F
    //   6: f2i
    //   7: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIIlIIIIIIllII	Lnet/minecraft/item/ItemStack;
  }
  
  public static boolean hasDurability(ItemStack lllllllllllllllIllIIIlIIIIIIlIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 46 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   6: astore_1
    //   7: aload_1
    //   8: instanceof net/minecraft/item/ItemArmor
    //   11: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   14: ifeq -> 47
    //   17: aload_1
    //   18: instanceof net/minecraft/item/ItemSword
    //   21: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   24: ifeq -> 47
    //   27: aload_1
    //   28: instanceof net/minecraft/item/ItemTool
    //   31: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   34: ifeq -> 47
    //   37: aload_1
    //   38: instanceof net/minecraft/item/ItemShield
    //   41: invokestatic lIIIlIIlIlIIIlII : (I)Z
    //   44: ifeq -> 105
    //   47: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   50: iconst_1
    //   51: iaload
    //   52: ldc ''
    //   54: invokevirtual length : ()I
    //   57: pop
    //   58: ldc ' '
    //   60: invokevirtual length : ()I
    //   63: ldc ' '
    //   65: invokevirtual length : ()I
    //   68: ldc ' '
    //   70: invokevirtual length : ()I
    //   73: ishl
    //   74: ishl
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ldc ' '
    //   82: invokevirtual length : ()I
    //   85: ishl
    //   86: if_icmpne -> 110
    //   89: ldc_w '   '
    //   92: invokevirtual length : ()I
    //   95: ldc_w '   '
    //   98: invokevirtual length : ()I
    //   101: iconst_m1
    //   102: ixor
    //   103: iand
    //   104: ireturn
    //   105: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   108: iconst_0
    //   109: iaload
    //   110: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	111	0	lllllllllllllllIllIIIlIIIIIIlIll	Lnet/minecraft/item/ItemStack;
    //   7	104	1	lllllllllllllllIllIIIlIIIIIIlIlI	Lnet/minecraft/item/Item;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIlIIlIlIIIIll : ()V
    //   3: invokestatic lIIIlIIlIlIIIIlI : ()V
    //   6: invokestatic lIIIlIIlIlIIIIIl : ()V
    //   9: invokestatic lIIIlIIlIIllllIl : ()V
    //   12: ldc me/stupitdog/bhp/az
    //   14: <illegal opcode> 134 : (Ljava/lang/Class;)Z
    //   19: invokestatic lIIIlIIlIlIIIlIl : (I)Z
    //   22: ifeq -> 57
    //   25: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   28: iconst_1
    //   29: iaload
    //   30: ldc ''
    //   32: invokevirtual length : ()I
    //   35: pop
    //   36: ldc ' '
    //   38: invokevirtual length : ()I
    //   41: ldc ' '
    //   43: invokevirtual length : ()I
    //   46: ldc ' '
    //   48: invokevirtual length : ()I
    //   51: ishl
    //   52: ishl
    //   53: ifge -> 62
    //   56: return
    //   57: getstatic me/stupitdog/bhp/az.llIIllIlIIlIIl : [I
    //   60: iconst_0
    //   61: iaload
    //   62: putstatic me/stupitdog/bhp/az.$assertionsDisabled : Z
    //   65: return
  }
  
  private static CallSite lIIIIlllIlllIIII(MethodHandles.Lookup lllllllllllllllIllIIIIlllllllIlI, String lllllllllllllllIllIIIIlllllllIIl, MethodType lllllllllllllllIllIIIIlllllllIII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIlIIIIIIIIII = llIIlIlIlIIIIl[Integer.parseInt(lllllllllllllllIllIIIIlllllllIIl)].split(llIIllIlIIIlll[llIIllIlIIlIIl[44]]);
      Class<?> lllllllllllllllIllIIIIllllllllll = Class.forName(lllllllllllllllIllIIIlIIIIIIIIII[llIIllIlIIlIIl[0]]);
      String lllllllllllllllIllIIIIlllllllllI = lllllllllllllllIllIIIlIIIIIIIIII[llIIllIlIIlIIl[1]];
      MethodHandle lllllllllllllllIllIIIIllllllllIl = null;
      int lllllllllllllllIllIIIIllllllllII = lllllllllllllllIllIIIlIIIIIIIIII[llIIllIlIIlIIl[3]].length();
      if (lIIIlIIlIlIIllll(lllllllllllllllIllIIIIllllllllII, llIIllIlIIlIIl[2])) {
        MethodType lllllllllllllllIllIIIlIIIIIIIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIlIIIIIIIIII[llIIllIlIIlIIl[2]], az.class.getClassLoader());
        if (lIIIlIIlIlIIIlll(lllllllllllllllIllIIIIllllllllII, llIIllIlIIlIIl[2])) {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findVirtual(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIlI);
          "".length();
          if (" ".length() != " ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findStatic(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIlI);
        } 
        "".length();
        if (((0x8 ^ 0x1) << "   ".length() & ((0x34 ^ 0x3D) << "   ".length() ^ 0xFFFFFFFF)) != 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIlIIIIIIIIIl = llIIlIlIlIIIlI[Integer.parseInt(lllllllllllllllIllIIIlIIIIIIIIII[llIIllIlIIlIIl[2]])];
        if (lIIIlIIlIlIIIlll(lllllllllllllllIllIIIIllllllllII, llIIllIlIIlIIl[3])) {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findGetter(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIIl);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else if (lIIIlIIlIlIIIlll(lllllllllllllllIllIIIIllllllllII, llIIllIlIIlIIl[5])) {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findStaticGetter(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIIl);
          "".length();
          if (((0x40 ^ 0x63) << " ".length() & ((0x66 ^ 0x45) << " ".length() ^ 0xFFFFFFFF)) >= " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIlIIlIlIIIlll(lllllllllllllllIllIIIIllllllllII, llIIllIlIIlIIl[4])) {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findSetter(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIIl);
          "".length();
          if (((0x70 ^ 0x7F) << " ".length() & ((0x7A ^ 0x75) << " ".length() ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllIIIIllllllllIl = lllllllllllllllIllIIIIlllllllIlI.findStaticSetter(lllllllllllllllIllIIIIllllllllll, lllllllllllllllIllIIIIlllllllllI, lllllllllllllllIllIIIlIIIIIIIIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIIllllllllIl);
    } catch (Exception lllllllllllllllIllIIIIlllllllIll) {
      lllllllllllllllIllIIIIlllllllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIlIIllllIl() {
    llIIlIlIlIIIIl = new String[llIIllIlIIlIIl[45]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[46]] = llIIllIlIIIlll[llIIllIlIIlIIl[47]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[48]] = llIIllIlIIIlll[llIIllIlIIlIIl[49]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[50]] = llIIllIlIIIlll[llIIllIlIIlIIl[51]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[29]] = llIIllIlIIIlll[llIIllIlIIlIIl[52]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[53]] = llIIllIlIIIlll[llIIllIlIIlIIl[54]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[55]] = llIIllIlIIIlll[llIIllIlIIlIIl[56]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[57]] = llIIllIlIIIlll[llIIllIlIIlIIl[58]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[59]] = llIIllIlIIIlll[llIIllIlIIlIIl[60]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[37]] = llIIllIlIIIlll[llIIllIlIIlIIl[61]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[62]] = llIIllIlIIIlll[llIIllIlIIlIIl[63]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[52]] = llIIllIlIIIlll[llIIllIlIIlIIl[64]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[65]] = llIIllIlIIIlll[llIIllIlIIlIIl[66]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[4]] = llIIllIlIIIlll[llIIllIlIIlIIl[67]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[0]] = llIIllIlIIIlll[llIIllIlIIlIIl[68]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[69]] = llIIllIlIIIlll[llIIllIlIIlIIl[70]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[23]] = llIIllIlIIIlll[llIIllIlIIlIIl[71]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[72]] = llIIllIlIIIlll[llIIllIlIIlIIl[73]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[74]] = llIIllIlIIIlll[llIIllIlIIlIIl[75]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[76]] = llIIllIlIIIlll[llIIllIlIIlIIl[65]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[70]] = llIIllIlIIIlll[llIIllIlIIlIIl[77]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[38]] = llIIllIlIIIlll[llIIllIlIIlIIl[78]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[28]] = llIIllIlIIIlll[llIIllIlIIlIIl[76]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[79]] = llIIllIlIIIlll[llIIllIlIIlIIl[80]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[81]] = llIIllIlIIIlll[llIIllIlIIlIIl[53]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[82]] = llIIllIlIIIlll[llIIllIlIIlIIl[83]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[84]] = llIIllIlIIIlll[llIIllIlIIlIIl[50]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[85]] = llIIllIlIIIlll[llIIllIlIIlIIl[86]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[20]] = llIIllIlIIIlll[llIIllIlIIlIIl[87]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[2]] = llIIllIlIIIlll[llIIllIlIIlIIl[15]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[31]] = llIIllIlIIIlll[llIIllIlIIlIIl[88]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[60]] = llIIllIlIIIlll[llIIllIlIIlIIl[89]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[61]] = llIIllIlIIIlll[llIIllIlIIlIIl[79]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[90]] = llIIllIlIIIlll[llIIllIlIIlIIl[91]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[92]] = llIIllIlIIIlll[llIIllIlIIlIIl[69]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[71]] = llIIllIlIIIlll[llIIllIlIIlIIl[93]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[94]] = llIIllIlIIIlll[llIIllIlIIlIIl[62]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[95]] = llIIllIlIIIlll[llIIllIlIIlIIl[96]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[97]] = llIIllIlIIIlll[llIIllIlIIlIIl[95]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[86]] = llIIllIlIIIlll[llIIllIlIIlIIl[46]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[15]] = llIIllIlIIIlll[llIIllIlIIlIIl[98]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[30]] = llIIllIlIIIlll[llIIllIlIIlIIl[59]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[5]] = llIIllIlIIIlll[llIIllIlIIlIIl[99]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[16]] = llIIllIlIIIlll[llIIllIlIIlIIl[100]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[101]] = llIIllIlIIIlll[llIIllIlIIlIIl[82]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[77]] = llIIllIlIIIlll[llIIllIlIIlIIl[102]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[103]] = llIIllIlIIIlll[llIIllIlIIlIIl[104]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[105]] = llIIllIlIIIlll[llIIllIlIIlIIl[105]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[13]] = llIIllIlIIIlll[llIIllIlIIlIIl[106]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[24]] = llIIllIlIIIlll[llIIllIlIIlIIl[31]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[107]] = llIIllIlIIIlll[llIIllIlIIlIIl[81]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[108]] = llIIllIlIIIlll[llIIllIlIIlIIl[48]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[109]] = llIIllIlIIIlll[llIIllIlIIlIIl[103]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[110]] = llIIllIlIIIlll[llIIllIlIIlIIl[57]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[111]] = llIIllIlIIIlll[llIIllIlIIlIIl[110]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[96]] = llIIllIlIIIlll[llIIllIlIIlIIl[97]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[112]] = llIIllIlIIIlll[llIIllIlIIlIIl[113]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[114]] = llIIllIlIIIlll[llIIllIlIIlIIl[115]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[115]] = llIIllIlIIIlll[llIIllIlIIlIIl[114]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[3]] = llIIllIlIIIlll[llIIllIlIIlIIl[74]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[116]] = llIIllIlIIIlll[llIIllIlIIlIIl[116]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[25]] = llIIllIlIIIlll[llIIllIlIIlIIl[55]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[117]] = llIIllIlIIIlll[llIIllIlIIlIIl[118]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[119]] = llIIllIlIIIlll[llIIllIlIIlIIl[85]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[120]] = llIIllIlIIIlll[llIIllIlIIlIIl[90]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[118]] = llIIllIlIIIlll[llIIllIlIIlIIl[121]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[67]] = llIIllIlIIIlll[llIIllIlIIlIIl[122]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[35]] = llIIllIlIIIlll[llIIllIlIIlIIl[108]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[98]] = llIIllIlIIIlll[llIIllIlIIlIIl[123]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[51]] = llIIllIlIIIlll[llIIllIlIIlIIl[124]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[39]] = llIIllIlIIIlll[llIIllIlIIlIIl[125]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[83]] = llIIllIlIIIlll[llIIllIlIIlIIl[126]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[17]] = llIIllIlIIIlll[llIIllIlIIlIIl[127]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[87]] = llIIllIlIIIlll[llIIllIlIIlIIl[128]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[125]] = llIIllIlIIIlll[llIIllIlIIlIIl[129]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[124]] = llIIllIlIIIlll[llIIllIlIIlIIl[130]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[123]] = llIIllIlIIIlll[llIIllIlIIlIIl[109]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[88]] = llIIllIlIIIlll[llIIllIlIIlIIl[131]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[93]] = llIIllIlIIIlll[llIIllIlIIlIIl[132]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[63]] = llIIllIlIIIlll[llIIllIlIIlIIl[133]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[47]] = llIIllIlIIIlll[llIIllIlIIlIIl[134]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[54]] = llIIllIlIIIlll[llIIllIlIIlIIl[72]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[49]] = llIIllIlIIIlll[llIIllIlIIlIIl[135]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[122]] = llIIllIlIIIlll[llIIllIlIIlIIl[136]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[137]] = llIIllIlIIIlll[llIIllIlIIlIIl[119]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[26]] = llIIllIlIIIlll[llIIllIlIIlIIl[137]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[78]] = llIIllIlIIIlll[llIIllIlIIlIIl[112]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[89]] = llIIllIlIIIlll[llIIllIlIIlIIl[138]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[135]] = llIIllIlIIIlll[llIIllIlIIlIIl[94]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[139]] = llIIllIlIIIlll[llIIllIlIIlIIl[101]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[100]] = llIIllIlIIIlll[llIIllIlIIlIIl[140]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[22]] = llIIllIlIIIlll[llIIllIlIIlIIl[117]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[58]] = llIIllIlIIIlll[llIIllIlIIlIIl[141]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[73]] = llIIllIlIIIlll[llIIllIlIIlIIl[142]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[40]] = llIIllIlIIIlll[llIIllIlIIlIIl[111]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[143]] = llIIllIlIIIlll[llIIllIlIIlIIl[144]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[56]] = llIIllIlIIIlll[llIIllIlIIlIIl[92]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[141]] = llIIllIlIIIlll[llIIllIlIIlIIl[120]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[106]] = llIIllIlIIIlll[llIIllIlIIlIIl[145]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[44]] = llIIllIlIIIlll[llIIllIlIIlIIl[143]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[42]] = llIIllIlIIIlll[llIIllIlIIlIIl[139]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[102]] = llIIllIlIIIlll[llIIllIlIIlIIl[107]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[6]] = llIIllIlIIIlll[llIIllIlIIlIIl[84]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[1]] = llIIllIlIIIlll[llIIllIlIIlIIl[146]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[130]] = llIIllIlIIIlll[llIIllIlIIlIIl[45]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[80]] = llIIllIlIIIlll[llIIllIlIIlIIl[147]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[19]] = llIIllIlIIIlll[llIIllIlIIlIIl[148]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[27]] = llIIllIlIIIlll[llIIllIlIIlIIl[149]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[133]] = llIIllIlIIIlll[llIIllIlIIlIIl[150]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[43]] = llIIllIlIIIlll[llIIllIlIIlIIl[151]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[91]] = llIIllIlIIIlll[llIIllIlIIlIIl[152]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[18]] = llIIllIlIIIlll[llIIllIlIIlIIl[153]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[126]] = llIIllIlIIIlll[llIIllIlIIlIIl[154]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[41]] = llIIllIlIIIlll[llIIllIlIIlIIl[155]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[66]] = llIIllIlIIIlll[llIIllIlIIlIIl[156]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[68]] = llIIllIlIIIlll[llIIllIlIIlIIl[157]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[129]] = llIIllIlIIIlll[llIIllIlIIlIIl[158]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[99]] = llIIllIlIIIlll[llIIllIlIIlIIl[159]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[134]] = llIIllIlIIIlll[llIIllIlIIlIIl[160]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[146]] = llIIllIlIIIlll[llIIllIlIIlIIl[32]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[138]] = llIIllIlIIIlll[llIIllIlIIlIIl[161]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[140]] = llIIllIlIIIlll[llIIllIlIIlIIl[162]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[128]] = llIIllIlIIIlll[llIIllIlIIlIIl[163]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[136]] = llIIllIlIIIlll[llIIllIlIIlIIl[164]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[131]] = llIIllIlIIIlll[llIIllIlIIlIIl[165]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[33]] = llIIllIlIIIlll[llIIllIlIIlIIl[166]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[104]] = llIIllIlIIIlll[llIIllIlIIlIIl[167]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[142]] = llIIllIlIIIlll[llIIllIlIIlIIl[168]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[121]] = llIIllIlIIIlll[llIIllIlIIlIIl[169]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[75]] = llIIllIlIIIlll[llIIllIlIIlIIl[170]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[145]] = llIIllIlIIIlll[llIIllIlIIlIIl[171]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[132]] = llIIllIlIIIlll[llIIllIlIIlIIl[172]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[127]] = llIIllIlIIIlll[llIIllIlIIlIIl[173]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[113]] = llIIllIlIIIlll[llIIllIlIIlIIl[174]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[64]] = llIIllIlIIIlll[llIIllIlIIlIIl[175]];
    llIIlIlIlIIIIl[llIIllIlIIlIIl[144]] = llIIllIlIIIlll[llIIllIlIIlIIl[176]];
    llIIlIlIlIIIlI = new Class[llIIllIlIIlIIl[25]];
    llIIlIlIlIIIlI[llIIllIlIIlIIl[1]] = Listener.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[26]] = a.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[4]] = boolean.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[18]] = GameSettings.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[30]] = EntityPlayerSP.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[23]] = NonNullList.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[2]] = f100000000000000000000.Integer.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[24]] = f9.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[13]] = FontRenderer.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[28]] = WorldClient.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[22]] = InventoryPlayer.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[27]] = TextFormatting.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[19]] = int.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[3]] = f100000000000000000000.Boolean.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[20]] = Item.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[5]] = Minecraft.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[6]] = double.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[0]] = f13.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[16]] = float.class;
    llIIlIlIlIIIlI[llIIllIlIIlIIl[29]] = List.class;
  }
  
  private static void lIIIlIIlIlIIIIIl() {
    llIIllIlIIIlll = new String[llIIllIlIIlIIl[177]];
    llIIllIlIIIlll[llIIllIlIIlIIl[0]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[0]], llIIllIlIIlIII[llIIllIlIIlIIl[1]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[1]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[2]], llIIllIlIIlIII[llIIllIlIIlIIl[3]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[2]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[5]], llIIllIlIIlIII[llIIllIlIIlIIl[4]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[3]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[6]], llIIllIlIIlIII[llIIllIlIIlIIl[13]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[5]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[16]], llIIllIlIIlIII[llIIllIlIIlIIl[18]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[4]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[19]], llIIllIlIIlIII[llIIllIlIIlIIl[20]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[6]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[22]], llIIllIlIIlIII[llIIllIlIIlIIl[23]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[13]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[24]], llIIllIlIIlIII[llIIllIlIIlIIl[26]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[16]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[27]], llIIllIlIIlIII[llIIllIlIIlIIl[28]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[18]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[29]], llIIllIlIIlIII[llIIllIlIIlIIl[30]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[19]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[25]], llIIllIlIIlIII[llIIllIlIIlIIl[33]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[20]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[35]], llIIllIlIIlIII[llIIllIlIIlIIl[37]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[22]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[38]], llIIllIlIIlIII[llIIllIlIIlIIl[17]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[23]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[39]], llIIllIlIIlIII[llIIllIlIIlIIl[40]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[24]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[41]], llIIllIlIIlIII[llIIllIlIIlIIl[42]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[26]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[43]], llIIllIlIIlIII[llIIllIlIIlIIl[44]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[27]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[47]], llIIllIlIIlIII[llIIllIlIIlIIl[49]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[28]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[51]], llIIllIlIIlIII[llIIllIlIIlIIl[52]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[29]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[54]], llIIllIlIIlIII[llIIllIlIIlIIl[56]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[30]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[58]], llIIllIlIIlIII[llIIllIlIIlIIl[60]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[25]] = lIIIlIIlIIlllllI(llIIllIlIIlIII[llIIllIlIIlIIl[61]], llIIllIlIIlIII[llIIllIlIIlIIl[63]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[33]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[64]], llIIllIlIIlIII[llIIllIlIIlIIl[66]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[35]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[67]], llIIllIlIIlIII[llIIllIlIIlIIl[68]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[37]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[70]], llIIllIlIIlIII[llIIllIlIIlIIl[71]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[38]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[73]], llIIllIlIIlIII[llIIllIlIIlIIl[75]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[17]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[65]], llIIllIlIIlIII[llIIllIlIIlIIl[77]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[39]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[78]], llIIllIlIIlIII[llIIllIlIIlIIl[76]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[40]] = lIIIlIIlIIllllll(llIIllIlIIlIII[llIIllIlIIlIIl[80]], llIIllIlIIlIII[llIIllIlIIlIIl[53]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[41]] = lIIIlIIlIlIIIIII(llIIllIlIIlIII[llIIllIlIIlIIl[83]], llIIllIlIIlIII[llIIllIlIIlIIl[50]]);
    llIIllIlIIIlll[llIIllIlIIlIIl[42]] = lIIIlIIlIIllllll("MlSNsYw5wqc=", "AojkY");
    llIIllIlIIIlll[llIIllIlIIlIIl[43]] = lIIIlIIlIlIIIIII("XIcAXz6zbbQ=", "bJcJn");
    llIIllIlIIIlll[llIIllIlIIlIIl[44]] = lIIIlIIlIIllllll("U9ByMofbuiU=", "ObsVa");
    llIIllIlIIIlll[llIIllIlIIlIIl[47]] = lIIIlIIlIIlllllI("AREwQCQGGiENOw4SMEAqAx0hAD1BOS0ALAwGJQg9VRIxACowRXNbfFZNGw8vVVxtIicKAGsDIAERJxwoCQBrDSUGESoaZh0RKgosHRE2QRsKGiALOyYAIQNyVVRk", "otDnI");
    llIIllIlIIIlll[llIIllIlIIlIIl[49]] = lIIIlIIlIIllllll("xRh5s0FiYW6A7j4sumYiXc/5Tiu2ZPHppFZAiPrP50P6VVefXqA5coUDUxCZtKVFFXMyKGKj/FYR+9HT0doWBA==", "JSMhJ");
    llIIllIlIIIlll[llIIllIlIIlIIl[51]] = lIIIlIIlIlIIIIII("lJQc9bITfrvMVEfprB+yYdJPuDIbVH1lrDfd+FMtfh9aweY8quz3Cp6+q7pGwi45EkknYQBmHZc/0VFAKBb2ZYGgQgUZOMDc", "IUGUp");
    llIIllIlIIIlll[llIIllIlIIlIIl[52]] = lIIIlIIlIlIIIIII("WtbaNvwwimm2zNS39qJWVMq/LSUWOs6JjTQcAaCpwfqTsET12K+dgJdhXjyOgz0sV65OXtCzA/x7aHLNEBZ3SdAY3wL7jUzE", "fXeYn");
    llIIllIlIIIlll[llIIllIlIIlIIl[54]] = lIIIlIIlIIllllll("3DvyzOCGAAZkWI3A8qrKXQCuyrwfKl3rxjW0m2w79STAzUy/sqsz5DTDJG5p6kaAi6+VkleNfpg+DwViMAS2oQ==", "JAQZg");
    llIIllIlIIIlll[llIIllIlIIlIIl[56]] = lIIIlIIlIIlllllI("BTRcJTcdIRsiJwc2XDQrGH8Ub3kBPwEiIgYyF2xyXGtSdmNI", "hQrVC");
    llIIllIlIIIlll[llIIllIlIIlIIl[58]] = lIIIlIIlIIllllll("TsGN4LGFdxz66KWRZLvuWiMVu3QeEug/F6mrkd3ttgR6aoT3WGSWDwXR3G9R2wtFZeLkg0WVTv7ZS+Qte+6Tmw==", "gOTRa");
    llIIllIlIIIlll[llIIllIlIIlIIl[60]] = lIIIlIIlIIllllll("1fWi+87pnBzV+8LlO8vTJN7g9+kAnjKzGgWJS38OvoRlYrYBhq19OJFEbnFElXWrhtZI/svKL/wyrAO8tv4zPBwxmRPyd94r", "qizya");
    llIIllIlIIIlll[llIIllIlIIlIIl[61]] = lIIIlIIlIIllllll("i7/Kq5T5yoysBVwJGdCA7NrX3MoQ/6lVOjPfQ+4eEy2YNdKd2A2Gl4dxn0c/i2T0tp4qFdvUlAY7cfhhLMffnI7RDPHMRA6TK1msd9Le+i4=", "DQiiT");
    llIIllIlIIIlll[llIIllIlIIlIIl[63]] = lIIIlIIlIIllllll("4//iEt82u+ouJnxMn5yvHWE5fQ0hgsqz4W6GGgnCNvZ6BjK3qqVeItuldv/OI+VoHKfH/5EJ2jJjz505JGwF7RaaMMXPDvKL", "tytDB");
    llIIllIlIIIlll[llIIllIlIIlIIl[64]] = lIIIlIIlIIlllllI("LwMcZTQoCA0oKyAAHGU6LQ8NJS1vKwElPCIUCS0tewABLjUlOV96bXZSNzJjeFxIa3k=", "AfhKY");
    llIIllIlIIIlll[llIIllIlIIlIIl[66]] = lIIIlIIlIIllllll("JR6J9Suorc1WFq2fGrHhxRSkWfY3Lffs3/jDONK3Dd1Udpt6U+FwvrxBrQ0ku5Tj", "nZKmS");
    llIIllIlIIIlll[llIIllIlIIlIIl[67]] = lIIIlIIlIlIIIIII("3EsaiCZRzX+CO1usTUTxUFW3b6Ocz82p28QP6oyW0Np0j8f0VJoxNg==", "DfQPB");
    llIIllIlIIIlll[llIIllIlIIlIIl[68]] = lIIIlIIlIIllllll("hT0rLfqycYAktpS2KU5AL4sBR77FiHQniYTKAIHyksV3FAoNvpN0jg==", "kjsgB");
    llIIllIlIIIlll[llIIllIlIIlIIl[70]] = lIIIlIIlIIllllll("VHzFyrpyjfPQ3BzXg/mZ2Y6bzLgaAB39TFzcjd6vhuOWqGzRLZYg6qxtQ98ZwseVaoNK0ERGRM0qXMrRvoVI+Sh/v9ObaXPU", "DrNuZ");
    llIIllIlIIIlll[llIIllIlIIlIIl[71]] = lIIIlIIlIIllllll("ZS+xqzSLKNsxzOTRMZtYPKQur/5EhPrfZE+b8KaJR1kniQDrtjxrYU9L2uE3WnKr", "feLVy");
    llIIllIlIIIlll[llIIllIlIIlIIl[73]] = lIIIlIIlIIlllllI("CwhvCRYTHSgOBgkKbxgKFkMgAFgBCDUzFgMABRsPBwokQEoqAyQOTQsELx8BFAwnDk0PGSQXTS8ZJBcxEgwiEVlPJHta", "fmAzb");
    llIIllIlIIIlll[llIIllIlIIlIIl[75]] = lIIIlIIlIlIIIIII("8QGHykmMbAFqNJZAwsC9b2Y/ImLYaCGtIm13c/ChdCDP0GVtWJzRsNziNUiDJ6XEyY4V38ZGA8djZWKSqVRB0EKB7FsZzhwiMSyIfkSQBl9bwnBLy7nPiIm6GWpfmQ1N", "tGtkm");
    llIIllIlIIIlll[llIIllIlIIlIIl[65]] = lIIIlIIlIIlllllI("GS5JCj0BOw4NLRssSRshBGUGA3MHIwgOCAYmCAtzR3FHWWk=", "tKgyI");
    llIIllIlIIIlll[llIIllIlIIlIIl[77]] = lIIIlIIlIlIIIIII("JJyDGAMIXw6T7F+T39KhlrKgdKd16voOGwDNAzLMRQSSQBDfpC7n1BmF84gZAS/cevrVGzhUx08odyNmXuT9f7t1l1mAvVgRNeqwgmPonsw=", "SpOjk");
    llIIllIlIIIlll[llIIllIlIIlIIl[78]] = lIIIlIIlIIllllll("Fjc0JGvPLZbZdpmx6MRbivrNPH7xQZP2gwShwdC6HXs=", "cHlbl");
    llIIllIlIIIlll[llIIllIlIIlIIl[76]] = lIIIlIIlIIllllll("iBEYT2W4O8bW2jWwpXoGN1izXx4anuOKKLrbYQqc8wakiAkywnZ81K2aMqgSpf9BV8IO7t8w84BBDXrgpgqJHpyrKZ7cO5jprLNoTbhVcQSVU17ghNrcUvJtOurKBorxFqSCi3Ya1J8=", "cirTd");
    llIIllIlIIIlll[llIIllIlIIlIIl[80]] = lIIIlIIlIlIIIIII("U4FkvF9TtZYURJhk9u/EGwxFffxUH1OONgueu4FA47l4LRULA/1ZZtrUHvMgOOv2Ah8W2QduJLJUC4JqnNqRiQ==", "yIkTt");
    llIIllIlIIIlll[llIIllIlIIlIIl[53]] = lIIIlIIlIIlllllI("LAJfFCE0FxgTMS4AXwU9MUkQHW8mAgU1OjQJFQIxBQYcBjIkXVkrOyQTXgo8LwISFTQnE14OISQKXi4hJAoiEzQiDEpOHHtH", "AgqgU");
    llIIllIlIIIlll[llIIllIlIIlIIl[83]] = lIIIlIIlIIllllll("q0ccV6khs14WORAwqd/OpxocjUx9WSZGY5W3laCEto4DzoWhXbO6RqAnnzbuiBcRhgr7vs/OkvrWIG9qMEhHQQ==", "voWfF");
    llIIllIlIIIlll[llIIllIlIIlIIl[50]] = lIIIlIIlIIlllllI("DxN2KzgXBjEsKA0RdjokElg+aXxSRmhofFJGaGh8UkZoaHxYFTk2LwcaYnBlNEx4eA==", "bvXXL");
    llIIllIlIIIlll[llIIllIlIIlIIl[86]] = lIIIlIIlIlIIIIII("hpJKACgN/Hljn5/P649V64KxRE6KWydLrnrqxo+hzikMRK/rioHR4hEbEX8kQBK9LmLaeqZ0ywwjQYnugJID/aIFB+kcNde2nzqMyBk6aGg=", "euTcX");
    llIIllIlIIIlll[llIIllIlIIlIIl[87]] = lIIIlIIlIIllllll("t+TrJhxaeuJbaG/UE5z5kfldiRiqEbtxZo6KnDyYJf3kHt5LUkBOqBhEyw+L2J8y", "GZTQH");
    llIIllIlIIIlll[llIIllIlIIlIIl[15]] = lIIIlIIlIlIIIIII("WQ1OHAlBs2elq4+YBUX+CgcoZ1p7V640rQdPtWuHjMNlkErquIKXzQ==", "RLxpM");
    llIIllIlIIIlll[llIIllIlIIlIIl[88]] = lIIIlIIlIIllllll("wqqOrFDVUXG653Y9pJGfC946/c1vjnMy82grHDTlUCWE+8P6u50dJDt9Uw1pUCHA5lV7viDngJXA7I1EtqgF9FufMslfto7g", "dCdEI");
    llIIllIlIIIlll[llIIllIlIIlIIl[89]] = lIIIlIIlIIlllllI("JDU1Zz8jPiQqICs2NWcxJjkkJyZkIiQnNi8iJDt8DTwSPTM+NQwoPCs3JDtoLCUvKg17Z3h4Zn0PLXN6YwZ7aQ==", "JPAIR");
    llIIllIlIIIlll[llIIllIlIIlIIl[79]] = lIIIlIIlIIlllllI("KS8TSCouJAIFNSYsE0gkKyMCCDNpLRIPaQElCRIVIiQDAzUiOF0ALiImAzlwf3hfXhglcFZWfWdqRw==", "GJgfG");
    llIIllIlIIIlll[llIIllIlIIlIIl[91]] = lIIIlIIlIlIIIIII("70o6O1ZcwLybNaiO5EXvmBjnmg8ERRoSowQsiwQlgRKjzJlyChH/bVRTUBH37HWermyaPU4Uk2fjTbktHe4lLcj24RUANI61NI4DQwSQzVk=", "fbLDQ");
    llIIllIlIIIlll[llIIllIlIIlIIl[69]] = lIIIlIIlIlIIIIII("Nv64fZst4P0rgWTRaDtd9K5XN9mCMA2xee7ObXksdNxPxwuLjdyzIfe0h1mn57z18ogH0Is1YD7vbrLe34w73Q==", "MLgoF");
    llIIllIlIIIlll[llIIllIlIIlIIl[93]] = lIIIlIIlIIlllllI("KycMVxgsLB0aByQkDFccMScVVzwxJxUqASQhE0MTLCcUHSp0e0hAR30dH0NAf2JYWQ==", "EBxyu");
    llIIllIlIIIlll[llIIllIlIIlIIl[62]] = lIIIlIIlIIllllll("XkrjEcc6XrbHJQPlXpUG2tf6T2yVFQWasBxmEkEBX7KqEJplmcn0gmEk7Zr5kB/d2C5x85i8JkEUXMo4LNMevQ==", "uNMnu");
    llIIllIlIIIlll[llIIllIlIIlIIl[96]] = lIIIlIIlIlIIIIII("Ny6ooB/59aeCxLLR0h6A4Miea+NCmXHiO1QgygXw3hwCxcd8KWBIarOAuXOM4cCZ1fFhydQ2Oc9o2daQ8X0OHmqV/APqt2LR", "uIIMm");
    llIIllIlIIIlll[llIIllIlIIlIIl[95]] = lIIIlIIlIlIIIIII("V67GQ6qOH1+oN2GZanvxJyOZNrceuIEqNH8SxoFXY5GWyMgJOBSxshahYdvKyDCiaAcXse1wQ3JbcP8EToos67ZA4kFKEe7klyGZbwezEXlXJ4Qmy10e5g==", "KMeOz");
    llIIllIlIIIlll[llIIllIlIIlIIl[46]] = lIIIlIIlIIlllllI("IS48C18+OyMGXwI7LxgQPyA4UBkqPAQPCT91YkMrcW9q", "KOJjq");
    llIIllIlIIIlll[llIIllIlIIlIIl[98]] = lIIIlIIlIlIIIIII("P3TewavoFoDqlwX0v8acwLQYrdXmxD59ddaqHlZly4Pw4myyFhohnw5OjqtEPsUjITBql/RR6/ngDwISNzvXTyfREH2xAnNMzTRjB/CgN3oNFgiBNteFDaMB7GAJQTue", "mpMTA");
    llIIllIlIIIlll[llIIllIlIIlIIl[59]] = lIIIlIIlIIlllllI("Gw4DfwgcBRIyFxQNA38GGQISPxFbGRI/ARAZEiNLEAUDOBEMRSU0CxEOBRwEGwoQNBdPDR40CRE0QGlSRlooPF9DUVdxRQ==", "ukwQe");
    llIIllIlIIIlll[llIIllIlIIlIIl[99]] = lIIIlIIlIIlllllI("PiNXOD0mNhA/LTwhVykhI2gYMXMgLhY8ATYnFT8haXVDa2lzZlk=", "SFyKI");
    llIIllIlIIIlll[llIIllIlIIlIIl[100]] = lIIIlIIlIIlllllI("BTFcCw0dJBsMHQczXBoRGHoTAkMFN0hMQ0h0Ulg=", "hTrxy");
    llIIllIlIIIlll[llIIllIlIIlIIl[82]] = lIIIlIIlIlIIIIII("RuXzTolQ7oJ4xHd8HYz2bES8q5trZCFWFcuc+ivbsUxxzvx/cyiXDZ/ce6wY4KQpHAj1GTYEunNuWlyKBo0qHg==", "RBmWL");
    llIIllIlIIIlll[llIIllIlIIlIIl[102]] = lIIIlIIlIIlllllI("GwUTSQgDHRMLShsHEQkDGFkzK1VFTRMLNxcWGAICTl8yISJdIU5H", "twtgd");
    llIIllIlIIIlll[llIIllIlIIlIIl[104]] = lIIIlIIlIIlllllI("LDQcOWMqNAQ/YxUhGDEjIRcfMSEiMBhiLDYlDzYpfH0mMiwwNEU0LCgyRQs5NDwEP3ZvGQA5Oyd6BjkjIXo5LD8vOw0aOC85Dj0/fW9KeA==", "FUjXM");
    llIIllIlIIIlll[llIIllIlIIlIIl[105]] = lIIIlIIlIIllllll("TAFmiB7si7iFV0hIjAKzQl3Zdv4jYUhsYR4m2ELUnRglzgmpUjiUQ/TDadCZlUqCiiaRmbrCs2buenORl2ANJbDpt96AycsPAxBajy8GQyg=", "YEfGP");
    llIIllIlIIIlll[llIIllIlIIlIIl[106]] = lIIIlIIlIlIIIIII("iskCV7mzmTA/Cw0zdMxXSJXZMafwIoaA4maPG/nnaLtoeR+rpnQrWgo5cQBVcjZNZC9X6x25kr8dNE7wDfgqzQ==", "JZuqb");
    llIIllIlIIIlll[llIIllIlIIlIIl[31]] = lIIIlIIlIIllllll("bAb1F4ZSgdlYA5+BWRygqhJei1OxgXupT3P+kpSUZsKOiCuaDIyFrYX4OsXvK4XX", "jVYBD");
    llIIllIlIIIlll[llIIllIlIIlIIl[81]] = lIIIlIIlIlIIIIII("0ystFfbnw4AmGbKOXoy8hTHChd78SGpZrWzP1Bog7wvmd6kxgeOPJZwnz5UmlxF/7Su4h2pKsG4WV5pstPBN7m+mNU4/Xq0t", "gczht");
    llIIllIlIIIlll[llIIllIlIIlIIl[48]] = lIIIlIIlIlIIIIII("DLLsNaqBqM8LTtajtJE5U9kymfGPIlnGu1s/QYPyk9c+xdNIp+suA8ZwBfCYBNcAJ1arKM6LZ8U=", "EelMU");
    llIIllIlIIIlll[llIIllIlIIlIIl[103]] = lIIIlIIlIIlllllI("HQYndxQaDTY6CxIFJ3ccHRc6LQBdEz84ABYRfRwXBwonICkfAio8C0kFJjcaLFJiaUhHUAw4M0lLeh9DU0M=", "scSYy");
    llIIllIlIIIlll[llIIllIlIIlIIl[57]] = lIIIlIIlIIllllll("5ko2KONk4hP/ZLUvngWpCGnvBRr3nWkbSg710HP3FF+nevKB91IMTzdfc5ak8knuucASLPfFz3wjI6aX3dAo4A==", "annqz");
    llIIllIlIIIlll[llIIllIlIIlIIl[110]] = lIIIlIIlIlIIIIII("ZstagPHNM/wI025VzI6Ou1WzKQv2z+bzNSUwgNED/u2hSv095VnxgKpVvSw04yoC7mMKmpyHQioGu8Rfig3WuFEPxZSh7yaH8Pj8kvfJ/sE=", "Zqpqi");
    llIIllIlIIIlll[llIIllIlIIlIIl[97]] = lIIIlIIlIIlllllI("Kz0lRC4sNjQJMSQ+JUQgKTE0BDdrKjQEJyAqNBhtAjQCHiIxPRwLLSQ/NBh5Iy0/CRx0b2hbcHcHMFBrH3EHUGM=", "EXQjC");
    llIIllIlIIIlll[llIIllIlIIlIIl[113]] = lIIIlIIlIIlllllI("Kg0mfxQtBjcyCyUOJn8aKAE3Pw1qJTs/HCcaMzcNfg47NBUgN2VgTXdRDTZDdVFocVlk", "DhRQy");
    llIIllIlIIIlll[llIIllIlIIlIIl[115]] = lIIIlIIlIIllllll("LuRNl9+81PNMlQ0aYsadyXX3SwOvA3niLYN9NyP7CJqW24kT6u8WVCsW2OrPOHgcO5RDv51uiGEx2VNFeeIsWqRUz5HLZsuU9EQMvH154oH0U9cFYT/ufQ==", "rBUNk");
    llIIllIlIIIlll[llIIllIlIIlIIl[114]] = lIIIlIIlIIlllllI("JSkjYC4iIjItMSoqI2AmJS8/Ly0/ITIgN2UJOS0rKiIjIyYlOG0oNiUvCH97fn5hfBwodn8HagciMjpsJiU5KyA5LTE6bC4iNCYiJTg6Ky0/YxIgICMtOTouLiIjdXlr", "KLWNC");
    llIIllIlIIIlll[llIIllIlIIlIIl[74]] = lIIIlIIlIlIIIIII("cnmkss9wLplf/1UalYtovmjlPeICQXrJkbhpl84U2+ySgL/5JyWaJhip3eTB2fkjwZDS159QxHwa6Ko0JqycxyxBhW+CRTbbL2jT7zMbbK4DFkgsLVvCuQMWSCwtW8K5bA93oxV7zoQ7luc//VE69w==", "ikhOC");
    llIIllIlIIIlll[llIIllIlIIlIIl[116]] = lIIIlIIlIlIIIIII("bZeqRbONyI+n1oEnvnZfNOuul8wL/h8hqAS1neDTHoPjiJ1yngXSNvjKtb9fpiIqncvpu0dBJNjBTZw4r5v4Kr21GsplsOo8nzuye7WnbdqM/8YFAqfsya94rNnlbbpO", "uSkAt");
    llIIllIlIIIlll[llIIllIlIIlIIl[55]] = lIIIlIIlIIllllll("FrXAEUP4VqxLhhJUbFGdY7RtQ9b8DtUyXJM4ipYVUbx1SmGzpK7ba3ZPKFe3t4rJ24cPaeA1KOkeaa8fB8hNaZ3t17RDdbIW", "ZolDJ");
    llIIllIlIIIlll[llIIllIlIIlIIl[118]] = lIIIlIIlIIlllllI("JhUMbSEhHh0gPikWDG0vJBkdLThmAx03OCEeHzBiDxEVJh8tBAwqIi8DQiUlLRwcHH19QUx2fRcTQnJ8clBYYw==", "HpxCL");
    llIIllIlIIIlll[llIIllIlIIlIIl[85]] = lIIIlIIlIIlllllI("FAw+dj8TBy87IBsPPnYxFgAvNiZUBD80JhMZJjkrHxtkDz0IBS4bPhMMJCxoHAAvNDYlXnloY0o2I2JjQlNqeHI=", "ziJXR");
    llIIllIlIIIlll[llIIllIlIIlIIl[90]] = lIIIlIIlIIllllll("4I/Kqm13RfFMdnEO2MOhxlXJbiYtPAP2m/Hk+KT0D93X2XO3yVFTt+5el5wqg5WkswbaPowUiMMsDOZl99CYhA==", "CzzWh");
    llIIllIlIIIlll[llIIllIlIIlIIl[121]] = lIIIlIIlIIllllll("nUxAnMw1pQaVMNgzNnkQVSKQBObdlYZbzRiWcwmktijHp1l9jIkBNE8qzJc0ql8k", "sdbIt");
    llIIllIlIIIlll[llIIllIlIIlIIl[122]] = lIIIlIIlIIlllllI("IxA7WiokGyoXNSwTO1ouORAiWg45ECInMywWJE4hOBssK3B6THtCGCFPZ10LIxA7WyokGyoXNSwTO1suORAiWw45ECInMywWJE99bVU=", "MuOtG");
    llIIllIlIIIlll[llIIllIlIIlIIl[108]] = lIIIlIIlIIlllllI("PS8iRgM6JDMLHDIsIkYNPyMzBhp9Bz8GCzA4Nw4aaSw/DQI3FWFZWmV8CRhUZHB2SE4=", "SJVhn");
    llIIllIlIIIlll[llIIllIlIIlIIl[123]] = lIIIlIIlIIlllllI("FCkgZCgTIjEpNxsqIGQmFiUxJDFUPjEkIR8+MThrPSAHPiQOKRkrKxsrMTh/HDk6KRpLe217dEITN3BtUxpuag==", "zLTJE");
    llIIllIlIIIlll[llIIllIlIIlIIl[124]] = lIIIlIIlIlIIIIII("F+/3A3AH65Ll+ZJkCRON3UKNLTVaiThcds+pvgv/C+abbOFdIjfddwdgPwV9RGhvQBHwRdX3qXye1N+yRZdFD815sNYcDr98", "KWdml");
    llIIllIlIIIlll[llIIllIlIIlIIl[125]] = lIIIlIIlIIllllll("f2qqeaURyuReZ8bNqCeSF6gF0mmF+T5aoIOKsuclP7kX0vqDM86Z0NHwudd3ZpiSDq9THQHtes7CUPstLm456cfRmYmRMzRK", "fkBRr");
    llIIllIlIIIlll[llIIllIlIIlIIl[126]] = lIIIlIIlIlIIIIII("ECseW9y41VP6u10wk8+B7Kw5ipWHLY4mqF+UOSb184jRwyq+sGNk1j4z70ElrtesVt3olRLS4V/mhiltz/i02FZVQjTc6V/N", "lWVEG");
    llIIllIlIIIlll[llIIllIlIIlIIl[127]] = lIIIlIIlIlIIIIII("R8xM/BVxS1zZUZ61WPVsuLu4wAKbg7kmgIFumXmWjECQYurpXpVHmXlHTElCf1lZZ+fDDxUVKXllbXklulVJ+A==", "iZenk");
    llIIllIlIIIlll[llIIllIlIIlIIl[128]] = lIIIlIIlIlIIIIII("ymHUI68DkSOyQOf1GcGnbU0298pAQeUDdHxnqyOv/+yx5xxMLjjPdV5tO6ZwBwCa", "XRvPD");
    llIIllIlIIIlll[llIIllIlIIlIIl[129]] = lIIIlIIlIIllllll("8ebJlLMXBZC+L0vE+qFZw243vbfaTE38C2YP/96osMC5esEAdMTyfnIZLL3yIoCZPqvp714I/1+X1z4g1x2Ie2cfrl3Iv2iPtHevPId/a0Dny4liW3/CfQf1zwFI1Su+soEkwTlqdZMoEH06y6mUNDZXKOosb8javfDWnr4h1jjFdR9qBE281g==", "EfXwg");
    llIIllIlIIIlll[llIIllIlIIlIIl[130]] = lIIIlIIlIIlllllI("EgcZJW0NEgYobTcEBSEgDBVVNiYJEwY2JjYJAQo2FApVbA8SBxklbBQHASNsNwQFISAMXUYIKRkQDmsvGQgIawwaDAonN0NcTw==", "xfoDC");
    llIIllIlIIIlll[llIIllIlIIlIIl[109]] = lIIIlIIlIlIIIIII("bDCBhTMK2mqwEW9VHUVUcXSq+kjB+6XF1ljpyzo+c76nnXnr7aKIXYsjVV2+oiQgLpjdEkrgcMg9X+MGcMnS5mutqth6gW+WgaIOjFbmvatTR7Bxf6q7jo+Qonj+mqo+tj0WhPUmmnM=", "MGtQw");
    llIIllIlIIIlll[llIIllIlIIlIIl[131]] = lIIIlIIlIlIIIIII("o9ncWfWQ9YDPZBk0GHODp3NYckRwudBmwDbVvnvNv4pIC2wr4avZUQ==", "zVclQ");
    llIIllIlIIIlll[llIIllIlIIlIIl[132]] = lIIIlIIlIIllllll("P0Hwc4eczU5Lhx/4wGzw8vQNem9+24P3RuGwPgFsEPzo9lTx/nDHp/RTbiHMxNjzkrRu4Y2z80PlPBq6vXD/188aVskKBQxR", "poDCX");
    llIIllIlIIIlll[llIIllIlIIlIIl[133]] = lIIIlIIlIIllllll("VllbX0bq6MBPX9oWTQcQrg2XrwosBWmzblknSfZHSFVEEyZYXiujO4+HlxBJaZuU", "RVcYj");
    llIIllIlIIIlll[llIIllIlIIlIIl[134]] = lIIIlIIlIIllllll("mD/dRrIn0LEYGMixaQU8F6/A5Kru/X+bBKFn8p8RZJ9QVBd/YK10qRUxvBk8XlQNbLvt8VsyOnZDJSux/Zw9kXQd8qAeEu5T", "dWWGW");
    llIIllIlIIIlll[llIIllIlIIlIIl[72]] = lIIIlIIlIIlllllI("Bz0ybRkANiMgBgg+Mm0XBTEjLQBHKyM3AAA2ITBaLjkrJicMLDIqGg4rfCUdDDQiHENda3RzKyZid3NOSXhm", "iXFCt");
    llIIllIlIIIlll[llIIllIlIIlIIl[135]] = lIIIlIIlIIllllll("WAqhJujDm7Qi5YgkCdVeqX/t6KW+FI5cALEmpMyU1/KswINfbsqRNW0R7/tnC2eqhhfxeOB+3ZDfxAeBVZwQWRyP8fj6C8YD", "euigB");
    llIIllIlIIIlll[llIIllIlIIlIIl[136]] = lIIIlIIlIIllllll("38p35QYqSC5STwf6S89OrQN4zaIzroeS4pWKi/ZOVyA73cuyPPdCk6X9Ul1I7Ynv4ZXFOg1FmmM=", "OZFZP");
    llIIllIlIIIlll[llIIllIlIIlIIl[119]] = lIIIlIIlIIlllllI("ITckJFc+IjspVwc/ITFDIiI3Nxg/OSB/UWIaOCQPKnknMRAneRsxHDk3JioLcGxyZQ==", "KVREy");
    llIIllIlIIIlll[llIIllIlIIlIIl[137]] = lIIIlIIlIIllllll("i2cv4dAudymE0AnN1PeCJ6uLA40r6XM+GID7PpUqhCow1RVQBoga42me3df6h+Xb", "McERg");
    llIIllIlIIIlll[llIIllIlIIlIIl[112]] = lIIIlIIlIIlllllI("CSooSCcRMigKZQkoKggsCnYIKnpXYigKGwkoAgc/FDE3XGNPDnVG", "fXOfK");
    llIIllIlIIIlll[llIIllIlIIlIIl[138]] = lIIIlIIlIIllllll("cdj177JdxkZU5RrO/tI5d1Qkr/uZN6ZUDku7qcC6cp+KUIzLpdn00PP7wdyX8mVO", "axsmC");
    llIIllIlIIIlll[llIIllIlIIlIIl[94]] = lIIIlIIlIlIIIIII("zWQIXwXIe56JovzQQHSXoLfCXCRPIjVoSm7IxoKhqzglHjDZk7EjMCKIAdtJRqGxqgNj9g+EzbOy81VREqt5lbdks6dUSOwqnlTiNaaQ7H0=", "SRygk");
    llIIllIlIIIlll[llIIllIlIIlIIl[101]] = lIIIlIIlIIlllllI("BAoQVDUDAQEZKgsJEFQ9BBsNDiFEHwgbIQ8dSj82HgYQAwgGDh0fKlAJDR80DjBTSmlcXjsMYlxVRFp4", "jodzX");
    llIIllIlIIIlll[llIIllIlIIlIIl[140]] = lIIIlIIlIlIIIIII("iAg9bPDNCIjt475wM0AdgQ4fWnsIdVemxcFIhZr72ERXRuhtGnamonp9ObPfH5lnk5dzn/1j73dcXH6w6F0G0V+WhSROmqfV5pN8jauJyv3bAwmwpnufdKOXH4xB18bVoNwlDHLpLdJB7A5D7T/d9WgYBm/hV7wCRGRd7VXXqCx/iNL3aUZozw==", "wlhlF");
    llIIllIlIIIlll[llIIllIlIIlIIl[117]] = lIIIlIIlIIllllll("dXxQs1ryV5xIjE1cjr//tTwFzutoN92M8ZOytkMHXZQq209hffBvfRNBQihssLJb", "mDvUP");
    llIIllIlIIIlll[llIIllIlIIlIIl[141]] = lIIIlIIlIIllllll("A7bj1JcjjeS16OzSOu6NZyRRGChF6qpcAe+u+5vqoU3pARqviR1bB1w+QD1fzKcurnfjtfjp88FsS/R5nyBXDqTOBvKbamdM", "MTpSm");
    llIIllIlIIIlll[llIIllIlIIlIIl[142]] = lIIIlIIlIlIIIIII("+H5nIUoXPD38BmBRaUB6JhoFzxkeso6AOILyZVNGunBm6ThjmfG3XrT5k/mo04nt", "aBYYi");
    llIIllIlIIIlll[llIIllIlIIlIIl[111]] = lIIIlIIlIIllllll("GZFRYF8NrLsiUYSNZpBJF63M/msVWOwwQnZIoK3ozFVUHewy0KToaPKikN23XFtqz4hSMwNE/bXEwsGdJo0Vrw==", "enNvP");
    llIIllIlIIIlll[llIIllIlIIlIIl[144]] = lIIIlIIlIIlllllI("PQYOTSs6DR8ANDIFDk0jPRcTFz99ExYCPzYRVCYoJwoOGhY/AgMGNGkFEwYqNzxNU3dgVSU2fGVZWkNm", "SczcF");
    llIIllIlIIIlll[llIIllIlIIlIIl[92]] = lIIIlIIlIlIIIIII("dFoCioNEcisUQJjJLGUvYRzeAjTLIMpunyVcZqAlK35IuDShQP7X/UqIkSVAeDtYI96BRP2CYftkx/UQtr4f8LyF4ozY76pc", "HcCoN");
    llIIllIlIIIlll[llIIllIlIIlIIl[120]] = lIIIlIIlIlIIIIII("f17V62Njt4S/yFyoRfbNwKeMccsoIO5J48ANIKF14mfJ7tOsWI4bhf+OyJXN3n7yApF0Wx9iAvK69fALV/e0Nw==", "bnPSG");
    llIIllIlIIIlll[llIIllIlIIlIIl[145]] = lIIIlIIlIIllllll("ghGcLp4QG2A4T6rRt7//knqUWY5DyByftKGGjH3Wf+0KKl9oK64Qa8o6Q6Evpy3XgcaorKNdJ74=", "IMtJI");
    llIIllIlIIIlll[llIIllIlIIlIIl[143]] = lIIIlIIlIIllllll("uZkgceKg4aw2JjvNh2+csL7AGN5+Crd5W0wZCQvKXVCyfkGXJB4Q7EYAepIWySKpGqVnMzFfHpqKqBtaSNO+yN88u5elP9Xg", "hueWE");
    llIIllIlIIIlll[llIIllIlIIlIIl[139]] = lIIIlIIlIIllllll("T9GkfRI9rnNxyDKMBo53lScDoMwPTbJGcMTTSWVDUHXDFNoCqiKIsuVGwd57i1NWHmEaIc2G1EFi22EY5jCqS04Z6YsWRAFK", "rVMBR");
    llIIllIlIIIlll[llIIllIlIIlIIl[107]] = lIIIlIIlIIlllllI("DSoeTQIKIQ8AHQIpHk0MDyYPDRtNPQ8NCwY9DxFBJCM5Fw4XKicCAQIoDxFVBToEADBSeFNTV1oQBVlHShlQQw==", "cOjco");
    llIIllIlIIIlll[llIIllIlIIlIIl[84]] = lIIIlIIlIIllllll("opHmParMa/nHLBgOO6Ss14bhvT7AnQmHxkSpTo3KqvVFvBT/mWKLXw==", "anzIm");
    llIIllIlIIIlll[llIIllIlIIlIIl[146]] = lIIIlIIlIIlllllI("Oj1iKTMiKCUuIzg/YjgvJ3YtIH0lPSszNCM9PhMpIz0rPzVtcAAwJiE5YzYmOT9jCTMlMSI9fB4RBXMLOj1jKTMiKCUuIzg/YzgvJ3cqa3dnaHxqd2dofGp3Z2h8andnaHxqYx42OD8gMip3YGd3", "WXLZG");
    llIIllIlIIIlll[llIIllIlIIlIIl[45]] = lIIIlIIlIlIIIIII("2tkLUfTpEEwEb0Nb4GdUzGyYT255wI/JS+bHEbQimW5Fg4Mrg31LchU9M1Y6Ob/NqcGwU63wENk=", "kWfNl");
    llIIllIlIIIlll[llIIllIlIIlIIl[147]] = lIIIlIIlIIlllllI("CzViADETICUHIQk3YhEtFn4qQnVWYHxDdVZgfEN1VmB8Q3VWYHxDYSQ/Ix8gBz52FCASBi0fMANqZFofXHBs", "fPLsE");
    llIIllIlIIIlll[llIIllIlIIlIIl[148]] = lIIIlIIlIIllllll("OIkfJQA/sAQtQB/epCroxxkelnb75WQ2VW+nupm9GM8GKKpFnbGSR2u6miydw+LC", "LxGPC");
    llIIllIlIIIlll[llIIllIlIIlIIl[149]] = lIIIlIIlIlIIIIII("RXo4PRQQHQsaRIoQFmlHzt98bLuJAGlSFI5qR8Y1/3q58U5YXmfaJHYSFTKKBvKz", "rWwfe");
    llIIllIlIIIlll[llIIllIlIIlIIl[150]] = lIIIlIIlIIlllllI("Gh8GaSMdFBckPBUcBmknAB8faQcAHx8UOhUZGX0oARQRGHlDQ0d/ER9AWm4HTlpS", "tzrGN");
    llIIllIlIIIlll[llIIllIlIIlIIl[151]] = lIIIlIIlIIllllll("wCaqMBL6MnKJzSlmt1cBzmWUIAwDw7C0nWoONH77N622q1V1IWkfosHzhx9IyC5Az4u81gRKuFkGXFuZj8+Bl42P6z70alxd", "NhwnR");
    llIIllIlIIIlll[llIIllIlIIlIIl[152]] = lIIIlIIlIIlllllI("LCgtXy4rIzwSMSMrLV8gLiQ8HzdsPzwfJyc/PANtBSEKBSI2KBQQLSMqPAN5JDg3EhxzemBAcXMSH0traxtjUQ==", "BMYqC");
    llIIllIlIIIlll[llIIllIlIIlIIl[153]] = lIIIlIIlIIllllll("lXqdMc7J6j2mSWunrDJZVdJrGaNJQjeEjlproHMKTyCYKtHyrm/tifsrnGqS9kJMeI3adD7APAF+uqZvLVe508hWVgGZntpCLwhx1owANFRztIpOAdQVSA==", "ssvOM");
    llIIllIlIIIlll[llIIllIlIIlIIl[154]] = lIIIlIIlIIlllllI("HCglaA4bIzQlERMrJWgAHiQ0KBdcIzQyFB0/OmgtFzkmKREZHT0nGhc/GCgFHXc3Mw0REmBxW0p4YhkASGV4D1lSbQ==", "rMQFc");
    llIIllIlIIIlll[llIIllIlIIlIIl[155]] = lIIIlIIlIIllllll("jWfPRQ5WGDX0vqV4t7u8h/Rp0UKsb16tLsCL/jOp5Na0agwuYl7Jp3iWdb6VnSF1MhE3ag4j4RZrAiH5nsAQHjO01xb1UHav", "mmxWq");
    llIIllIlIIIlll[llIIllIlIIlIIl[156]] = lIIIlIIlIIllllll("DrbtxFC3tJUc/udpbe2tyV/mJuq7CnAGvJNRPcLI2rMYPypKV+v1DoByZ6cdL+nDHQMVEEc6MSXS2pdlhl+hE5l5vPZ2H1yr0XbmcuFKl2t0z+B9lvWfYjqh1w1c0yEI", "BIzXZ");
    llIIllIlIIIlll[llIIllIlIIlIIl[157]] = lIIIlIIlIIlllllI("DDcQVwMLPAEaHAM0EFcHFjcJVycWNwkqGgMxD0MIFzwHJllVa1JLMRFoTFA0WHJE", "bRdyn");
    llIIllIlIIIlll[llIIllIlIIlIIl[158]] = lIIIlIIlIIllllll("+11QnOa+ev244C8n6qxrQdXyA3muldxkkYkcoUu0CGZBDm2B0JbrNR+A+m0hQ2Po3aDRHE0W6K8=", "NJZwO");
    llIIllIlIIIlll[llIIllIlIIlIIl[159]] = lIIIlIIlIIlllllI("AAIGXzUHCRcSKg8BBl87Ag4XHyxAFRcfPAsVFwN2PAIcFT0cLgYUNVQBBx87MVZKQWxbVy0TYkYrHBQsQQobHz0NFRMXLEEOBhQ1QS4GFDU9ExMSM1UuO1gOVEdS", "ngrqX");
    llIIllIlIIIlll[llIIllIlIIlIIl[160]] = lIIIlIIlIIlllllI("JDc5Wz4jPCgWISs0OVs6PjcgWxo+NyAmJysxJk81PzwuKmR9a3hHDCNoZVwacHJt", "JRMuS");
    llIIllIlIIIlll[llIIllIlIIlIIl[32]] = lIIIlIIlIlIIIIII("/Kprx7vjO2ma+qif0Ou4pVyFUt0HX/PlRLSLgXonrYpyYd9ybAg7yhxtNUk0UTFT", "zWoqA");
    llIIllIlIIIlll[llIIllIlIIlIIl[161]] = lIIIlIIlIIllllll("+ypp4Vz8MDT3t+6Q6nsGKDuIwTU36IyLySeLoajSS/+852jVk5cay8f+AQ6bnr26LOUflXy3e0NZZCzAnChg6WwpzGU9GPbrcxDtAlzt9P4=", "DzBaK");
    llIIllIlIIIlll[llIIllIlIIlIIl[162]] = lIIIlIIlIIllllll("QQzzb+kZVRhhtYiBASngg+3unVO1LcHvynASIT1pJXI0918cuxJnUchnnfHuXILwHzuIUHsRaNB08pA5O6Swrzn69F86AW3NOyUIvMtdylVSh4/3ZQra3F8zvZB5STCB", "ApBhR");
    llIIllIlIIIlll[llIIllIlIIlIIl[163]] = lIIIlIIlIIllllll("mdYSsaauUG1clL6yQfwZrM0o+IQbjfJyuG5JIPiyHff7RlHn87kzaOvuc8JCfUjmz8JhdQkswow=", "NREXT");
    llIIllIlIIIlll[llIIllIlIIlIIl[164]] = lIIIlIIlIIlllllI("IiYcQyUlLQ0OOi0lHEMrICoNAzxiDgEDLS8xCQs8diUBCCQoHF9cfHhyNwhyfXRSTWhs", "LChmH");
    llIIllIlIIIlll[llIIllIlIIlIIl[165]] = lIIIlIIlIlIIIIII("L9yCUxlC0d9Vp/kjDMX+fVhOzd/ePeP3Ovua9zVMlUnqpxf0qKYqbPPtPQYYLCIFYSxVR+9cAP9gDRR5BB9THg==", "TGIpR");
    llIIllIlIIIlll[llIIllIlIIlIIl[166]] = lIIIlIIlIIlllllI("GjQNdykdPxw6NhU3DXchGiUQLT1aFBctLQAoQz8xGjImbnREYEgGIk55PR0AXRVDeWQ=", "tQyYD");
    llIIllIlIIIlll[llIIllIlIIlIIl[167]] = lIIIlIIlIlIIIIII("bgJRBxk+tkHuTQkBMyHBMpXjlrhGpSWxGTIMDsvn9CM1GB8edWzXE3k4AmNDkEoZH270zqY9hKVmxOZZICe4pWN6BF1wDLRP", "obUTW");
    llIIllIlIIIlll[llIIllIlIIlIIl[168]] = lIIIlIIlIIllllll("FLHAB/sDwwBvnvyQDC5+Mozz4vl0gdTtMlrtR89zr5S2Z5pjQBtY+RINhyX7QEs2dQZ/pBp16K9JD+ubkaeUAA==", "ehuwh");
    llIIllIlIIIlll[llIIllIlIIlIIl[169]] = lIIIlIIlIlIIIIII("O3Ejk1gqqLX1tfBarUB0Wzlqkj+39WQNdiiPiL/fpMm2uEdbFJvpbRzfIjXDhDnk390DFm4k1Fk=", "vIIjK");
    llIIllIlIIIlll[llIIllIlIIlIIl[170]] = lIIIlIIlIIllllll("WBlo/lUcBBBXFmVkc9sWCyGKyv8wD9VwpnHFBp9WCAHXWPB2KPZl1Mjpw9BMyuzm/Mpp9rVxNXRKe8IBOBjhI3cvw5PfCzL4", "ctApL");
    llIIllIlIIIlll[llIIllIlIIlIIl[171]] = lIIIlIIlIIlllllI("Nyg7RQ8wIyoIEDgrO0UBNSQqBRZ3PyoFBjw/KhlMPCM7AhYgYx0ODD0oPSYDNywoDhBjKyYODj0SeFNVa3sQCFhvd29LQg==", "YMOkb");
    llIIllIlIIIlll[llIIllIlIIlIIl[172]] = lIIIlIIlIlIIIIII("aGLtvjx7RJC1jtM1Lmo+9h45bsELdKYWkcl4yDYDVlAdmS2r5SxrxRgomZqATHNKnLGiWK2Lft2Zt96Y5q8JqA==", "tBVPQ");
    llIIllIlIIIlll[llIIllIlIIlIIl[173]] = lIIIlIIlIIlllllI("ByIWRBwAKQcJAwghFkQEHS4ORAUMPxZEJQw/FiweGyoDHgUAKQVQNjsCJyRLWHFYSlFJZw==", "iGbjq");
    llIIllIlIIIlll[llIIllIlIIlIIl[174]] = lIIIlIIlIIlllllI("Gj8cfR0dNA0wAhU8HH0eFi5GHTIgDgk0Mxs3GDwFGj5SNQUaOTdkRENsXQwUTnIkORECO0c/ERo9RwAEBjMGNEtdCVJzUA==", "tZhSp");
    llIIllIlIIIlll[llIIllIlIIlIIl[175]] = lIIIlIIlIIlllllI("CQENSAoOChwFFQYCDUgECw0cCBNJAwwPSSELFxI1AgodAxUCFkMAEgkHJldQUlRPVTgGXlEqDQYSGEkLBgoeSTQTFhAIAFwiPy9OLl5ZRg==", "gdyfg");
    llIIllIlIIIlll[llIIllIlIIlIIl[176]] = lIIIlIIlIIlllllI("JCs/Tz0jIC4CIisoP08zJicuDyRkPC4PNC88LhN+LyA/CCQzYBkEPi4rOSwxJC8sBCJwKCIEPC4RfFlneHsUA2p8dGtBcA==", "JNKaP");
    llIIllIlIIlIII = null;
  }
  
  private static void lIIIlIIlIlIIIIlI() {
    String str = (new Exception()).getStackTrace()[llIIllIlIIlIIl[0]].getFileName();
    llIIllIlIIlIII = str.substring(str.indexOf("ä") + llIIllIlIIlIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIlIIlllllI(String lllllllllllllllIllIIIIllllllIllI, String lllllllllllllllIllIIIIllllllIlIl) {
    lllllllllllllllIllIIIIllllllIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIIllllllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIIllllllIlII = new StringBuilder();
    char[] lllllllllllllllIllIIIIllllllIIll = lllllllllllllllIllIIIIllllllIlIl.toCharArray();
    int lllllllllllllllIllIIIIllllllIIlI = llIIllIlIIlIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIIllllllIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIlIIlIIl[0];
    while (lIIIlIIlIlIIllIl(j, i)) {
      char lllllllllllllllIllIIIIllllllIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIIllllllIIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIIllllllIlII);
  }
  
  private static String lIIIlIIlIlIIIIII(String lllllllllllllllIllIIIIlllllIlllI, String lllllllllllllllIllIIIIlllllIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIIllllllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIlllllIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIIllllllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIIllllllIIII.init(llIIllIlIIlIIl[2], lllllllllllllllIllIIIIllllllIIIl);
      return new String(lllllllllllllllIllIIIIllllllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIlllllIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIIlllllIllll) {
      lllllllllllllllIllIIIIlllllIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIlIIllllll(String lllllllllllllllIllIIIIlllllIlIIl, String lllllllllllllllIllIIIIlllllIlIII) {
    try {
      SecretKeySpec lllllllllllllllIllIIIIlllllIllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIlllllIlIII.getBytes(StandardCharsets.UTF_8)), llIIllIlIIlIIl[16]), "DES");
      Cipher lllllllllllllllIllIIIIlllllIlIll = Cipher.getInstance("DES");
      lllllllllllllllIllIIIIlllllIlIll.init(llIIllIlIIlIIl[2], lllllllllllllllIllIIIIlllllIllII);
      return new String(lllllllllllllllIllIIIIlllllIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIlllllIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIIlllllIlIlI) {
      lllllllllllllllIllIIIIlllllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIlIlIIIIll() {
    llIIllIlIIlIIl = new int[178];
    llIIllIlIIlIIl[0] = (0xB7 ^ 0x86) & (0xAD ^ 0x9C ^ 0xFFFFFFFF);
    llIIllIlIIlIIl[1] = " ".length();
    llIIllIlIIlIIl[2] = " ".length() << " ".length();
    llIIllIlIIlIIl[3] = "   ".length();
    llIIllIlIIlIIl[4] = "   ".length() << " ".length() ^ "   ".length();
    llIIllIlIIlIIl[5] = " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[6] = "   ".length() << " ".length();
    llIIllIlIIlIIl[7] = -(1780837678 + 889898697 - 617312591 + 91822902);
    llIIllIlIIlIIl[8] = -" ".length();
    llIIllIlIIlIIl[9] = -(0xB7 ^ 0xBF);
    llIIllIlIIlIIl[10] = " ".length() << " ".length() << "   ".length();
    llIIllIlIIlIIl[11] = -(0xBE ^ 0xA3);
    llIIllIlIIlIIl[12] = -(0x67 ^ 0x42);
    llIIllIlIIlIIl[13] = 0x0 ^ 0x7;
    llIIllIlIIlIIl[14] = -(1045420 + 810314 - 1353160 + 3180311 + 421745 + 411120 - 336495 + 323719 - 2730208 + 3998983 - 6339602 + 3690796 + (651786 + 1593757 - 1253215 + 785337 << " ".length()));
    llIIllIlIIlIIl[15] = (0x8B ^ 0x84) << " ".length() << " ".length();
    llIIllIlIIlIIl[16] = " ".length() << "   ".length();
    llIIllIlIIlIIl[17] = 0x63 ^ 0x44 ^ (0xB5 ^ 0xAA) << " ".length();
    llIIllIlIIlIIl[18] = (0xBD ^ 0x92) << " ".length() << " ".length() ^ 133 + 51 - 176 + 173;
    llIIllIlIIlIIl[19] = (0x9D ^ 0x98) << " ".length();
    llIIllIlIIlIIl[20] = 0x58 ^ 0x53;
    llIIllIlIIlIIl[21] = -((0x4F ^ 0x2) << " ".length() ^ (0x5 ^ 0x2C) << " ".length() << " ".length());
    llIIllIlIIlIIl[22] = "   ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[23] = (0x63 ^ 0x66) << "   ".length() ^ 0x65 ^ 0x40;
    llIIllIlIIlIIl[24] = (46 + 48 - -57 + 48 ^ "   ".length() << "   ".length() << " ".length()) << " ".length();
    llIIllIlIIlIIl[25] = (89 + 14 - 38 + 70 ^ (0x31 ^ 0x70) << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[26] = 0xCA ^ 0xC5;
    llIIllIlIIlIIl[27] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[28] = 0x44 ^ 0x55;
    llIIllIlIIlIIl[29] = (0x2 ^ 0xB) << " ".length();
    llIIllIlIIlIIl[30] = 0x9D ^ 0x8E;
    llIIllIlIIlIIl[31] = (0x7A ^ 0x7F) << " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[32] = (0x65 ^ 0x2E) << " ".length();
    llIIllIlIIlIIl[33] = (0x68 ^ 0x27) << " ".length() ^ 127 + 76 - 111 + 47;
    llIIllIlIIlIIl[34] = (0x3D ^ 0x24) << "   ".length();
    llIIllIlIIlIIl[35] = ((0x45 ^ 0x6E) << " ".length() << " ".length() ^ 27 + 148 - 17 + 9) << " ".length();
    llIIllIlIIlIIl[36] = (0x41 ^ 0x3C) << " ".length();
    llIIllIlIIlIIl[37] = 0x7F ^ 0x68;
    llIIllIlIIlIIl[38] = "   ".length() << "   ".length();
    llIIllIlIIlIIl[39] = (0x5 ^ 0x8) << " ".length();
    llIIllIlIIlIIl[40] = 61 + 125 - 169 + 116 ^ (0x3C ^ 0x73) << " ".length();
    llIIllIlIIlIIl[41] = ((0x4 ^ 0x1B) << " ".length() << " ".length() ^ 0x5F ^ 0x24) << " ".length() << " ".length();
    llIIllIlIIlIIl[42] = 0xAB ^ 0xB6;
    llIIllIlIIlIIl[43] = ((0xC ^ 0x1D) << " ".length() ^ 0x29 ^ 0x4) << " ".length();
    llIIllIlIIlIIl[44] = 0x1A ^ 0x3F ^ (0x36 ^ 0x2B) << " ".length();
    llIIllIlIIlIIl[45] = ((0x5F ^ 0x48) << " ".length()) + "   ".length() - -(0x9 ^ 0x37) + ("   ".length() << "   ".length());
    llIIllIlIIlIIl[46] = (0xB4 ^ 0x97) << " ".length();
    llIIllIlIIlIIl[47] = " ".length() << (0x15 ^ 0x26 ^ (0x5B ^ 0x40) << " ".length());
    llIIllIlIIlIIl[48] = (13 + 93 - 26 + 67 ^ (0x21 ^ 0x7C) << " ".length()) << " ".length();
    llIIllIlIIlIIl[49] = (0x8 ^ 0x4F) << " ".length() ^ 164 + 36 - 155 + 130;
    llIIllIlIIlIIl[50] = 0x7A ^ 0x43;
    llIIllIlIIlIIl[51] = ((0x2 ^ 0x17) << " ".length() << " ".length() ^ 0x26 ^ 0x63) << " ".length();
    llIIllIlIIlIIl[52] = (0x87 ^ 0xA6) << " ".length() ^ 0x29 ^ 0x48;
    llIIllIlIIlIIl[53] = 57 + 32 - 38 + 132 ^ " ".length() << (0x43 ^ 0x44);
    llIIllIlIIlIIl[54] = (0x80 ^ 0x89) << " ".length() << " ".length();
    llIIllIlIIlIIl[55] = ((0x2E ^ 0x75) << " ".length() ^ 22 + 106 - 52 + 85) << " ".length() << " ".length();
    llIIllIlIIlIIl[56] = 0x7A ^ 0x5F;
    llIIllIlIIlIIl[57] = ((0x55 ^ 0x5C) << "   ".length() ^ 0x44 ^ 0x19) << " ".length() << " ".length();
    llIIllIlIIlIIl[58] = (0x98 ^ 0x91 ^ (0x69 ^ 0x64) << " ".length()) << " ".length();
    llIIllIlIIlIIl[59] = (0x20 ^ 0x1 ^ (0xA ^ 0xF) << "   ".length()) << "   ".length();
    llIIllIlIIlIIl[60] = 0x79 ^ 0x5E;
    llIIllIlIIlIIl[61] = (0x5B ^ 0x5E) << "   ".length();
    llIIllIlIIlIIl[62] = 0x5B ^ 0x18;
    llIIllIlIIlIIl[63] = 0xA9 ^ 0x80;
    llIIllIlIIlIIl[64] = (0x2A ^ 0x15 ^ (0x17 ^ 0x2) << " ".length()) << " ".length();
    llIIllIlIIlIIl[65] = ("   ".length() << " ".length() ^ 0xBD ^ 0xA2) << " ".length();
    llIIllIlIIlIIl[66] = 0xC9 ^ 0x88 ^ (0x3B ^ 0xE) << " ".length();
    llIIllIlIIlIIl[67] = (0x84 ^ 0x89 ^ "   ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[68] = 0x52 ^ 0x5B ^ (0xB4 ^ 0xBD) << " ".length() << " ".length();
    llIIllIlIIlIIl[69] = 0x6C ^ 0x2D;
    llIIllIlIIlIIl[70] = (0x6 ^ 0x11) << " ".length();
    llIIllIlIIlIIl[71] = (0x86 ^ 0xAD) << " ".length() << " ".length() ^ 89 + 13 - -23 + 6;
    llIIllIlIIlIIl[72] = (0xC6 ^ 0x99 ^ (0x1B ^ 0x10) << "   ".length()) << " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[73] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[74] = (0x11 ^ 0x3C) << " ".length();
    llIIllIlIIlIIl[75] = 0x4F ^ 0x7E;
    llIIllIlIIlIIl[76] = 107 + 29 - 24 + 41 ^ (0xBD ^ 0x96) << " ".length() << " ".length();
    llIIllIlIIlIIl[77] = 52 + 180 - 76 + 31 ^ (0xB5 ^ 0xA4) << "   ".length();
    llIIllIlIIlIIl[78] = (0x31 ^ 0x3C) << " ".length() << " ".length();
    llIIllIlIIlIIl[79] = 0xB0 ^ 0x8F;
    llIIllIlIIlIIl[80] = (0x29 ^ 0x32) << " ".length();
    llIIllIlIIlIIl[81] = 0xE7 ^ 0xB6;
    llIIllIlIIlIIl[82] = 0x38 ^ 0x73;
    llIIllIlIIlIIl[83] = ((0x31 ^ 0xC) << " ".length() ^ 0xF2 ^ 0x8F) << "   ".length();
    llIIllIlIIlIIl[84] = ("   ".length() << " ".length()) + (0x3E ^ 0x43) - ((0x41 ^ 0x7C) << " ".length()) + ((0x1E ^ 0x1) << " ".length() << " ".length());
    llIIllIlIIlIIl[85] = (0x38 ^ 0x31 ^ (0x8B ^ 0x98) << " ".length()) << " ".length();
    llIIllIlIIlIIl[86] = ((0x8B ^ 0xA2) << " ".length() ^ 0xC6 ^ 0x89) << " ".length();
    llIIllIlIIlIIl[87] = 0x64 ^ 0x5F;
    llIIllIlIIlIIl[88] = 0x32 ^ 0x5D ^ (0x7F ^ 0x56) << " ".length();
    llIIllIlIIlIIl[89] = (0x1E ^ 0x1) << " ".length();
    llIIllIlIIlIIl[90] = 0xE3 ^ 0xBC;
    llIIllIlIIlIIl[91] = " ".length() << "   ".length() << " ".length();
    llIIllIlIIlIIl[92] = ((0x5C ^ 0x57) << " ".length() << " ".length()) + ((0x9D ^ 0xAE) << " ".length()) - ("   ".length() << " ".length() << " ".length() << " ".length()) + (0xE ^ 0x13);
    llIIllIlIIlIIl[93] = (0x45 ^ 0x64) << " ".length();
    llIIllIlIIlIIl[94] = 0x7A ^ 0xD;
    llIIllIlIIlIIl[95] = 0x5B ^ 0x1E;
    llIIllIlIIlIIl[96] = (143 + 74 - 171 + 135 ^ (0x2C ^ 0x5) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[97] = (0x3B ^ 0x46 ^ (0x4C ^ 0x67) << " ".length()) << " ".length();
    llIIllIlIIlIIl[98] = 143 + 117 - 121 + 56 ^ (0x6 ^ 0x27) << " ".length() << " ".length();
    llIIllIlIIlIIl[99] = 0xD1 ^ 0x98;
    llIIllIlIIlIIl[100] = (0xAE ^ 0x8B) << " ".length();
    llIIllIlIIlIIl[101] = (0x40 ^ 0x25 ^ (0x5A ^ 0x6F) << " ".length()) << "   ".length();
    llIIllIlIIlIIl[102] = (41 + 72 - 1 + 45 ^ (0x54 ^ 0x13) << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[103] = 0x54 ^ 0x9 ^ (0x38 ^ 0x3F) << " ".length();
    llIIllIlIIlIIl[104] = 0x6F ^ 0x34 ^ (0x63 ^ 0x68) << " ".length();
    llIIllIlIIlIIl[105] = ((0x5 ^ 0x22) << " ".length() ^ 0x77 ^ 0x1E) << " ".length();
    llIIllIlIIlIIl[106] = 0x77 ^ 0x38;
    llIIllIlIIlIIl[107] = (0x2F ^ 0x2 ^ "   ".length() << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[108] = (0x23 ^ 0x12) << " ".length();
    llIIllIlIIlIIl[109] = 147 + 190 - 311 + 211 ^ (0xF1 ^ 0xB2) << " ".length();
    llIIllIlIIlIIl[110] = (0x19 ^ 0x32) << " ".length() ^ "   ".length();
    llIIllIlIIlIIl[111] = 0xB ^ 0x76;
    llIIllIlIIlIIl[112] = 0x11 ^ 0x64;
    llIIllIlIIlIIl[113] = 0xDF ^ 0x88;
    llIIllIlIIlIIl[114] = 0xD4 ^ 0x8D;
    llIIllIlIIlIIl[115] = (0x71 ^ 0x7A) << "   ".length();
    llIIllIlIIlIIl[116] = (0x5F ^ 0x6E) << " ".length() << " ".length() ^ 68 + 47 - -4 + 40;
    llIIllIlIIlIIl[117] = ((0xB5 ^ 0x9A) << " ".length() ^ 0xDC ^ 0xBF) << " ".length();
    llIIllIlIIlIIl[118] = 0x32 ^ 0x3 ^ (0x16 ^ 0xD) << " ".length() << " ".length();
    llIIllIlIIlIIl[119] = 0x6 ^ 0x75;
    llIIllIlIIlIIl[120] = " ".length() << (82 + 109 - 130 + 90 ^ (0xA2 ^ 0xAB) << " ".length() << " ".length() << " ".length());
    llIIllIlIIlIIl[121] = "   ".length() << (0x64 ^ 0x61);
    llIIllIlIIlIIl[122] = 0x20 ^ 0x41;
    llIIllIlIIlIIl[123] = (0xA1 ^ 0x88) << " ".length() << " ".length() ^ 98 + 193 - 131 + 39;
    llIIllIlIIlIIl[124] = (0x82 ^ 0x9B) << " ".length() << " ".length();
    llIIllIlIIlIIl[125] = 0xD ^ 0x68;
    llIIllIlIIlIIl[126] = (0x2A ^ 0x19) << " ".length();
    llIIllIlIIlIIl[127] = 112 + 105 - 175 + 125 ^ "   ".length() << "   ".length() << " ".length();
    llIIllIlIIlIIl[128] = (0x4A ^ 0x47) << "   ".length();
    llIIllIlIIlIIl[129] = 0x2A ^ 0x1D ^ (0xA3 ^ 0x8C) << " ".length();
    llIIllIlIIlIIl[130] = (0x37 ^ 0x2) << " ".length();
    llIIllIlIIlIIl[131] = (0x53 ^ 0x48) << " ".length() << " ".length();
    llIIllIlIIlIIl[132] = (0x6B ^ 0x70) << " ".length() << " ".length() ^ " ".length();
    llIIllIlIIlIIl[133] = (0xBE ^ 0x89) << " ".length();
    llIIllIlIIlIIl[134] = 0xC ^ 0x4D ^ (0x5F ^ 0x48) << " ".length();
    llIIllIlIIlIIl[135] = 0x15 ^ 0x64;
    llIIllIlIIlIIl[136] = ((0xDC ^ 0xC5) << " ".length() ^ 0x6F ^ 0x64) << " ".length();
    llIIllIlIIlIIl[137] = ((0x6D ^ 0x66) << "   ".length() ^ 0xE6 ^ 0xA3) << " ".length() << " ".length();
    llIIllIlIIlIIl[138] = (0xD3 ^ 0x96 ^ (0xA4 ^ 0x9B) << " ".length()) << " ".length();
    llIIllIlIIlIIl[139] = (0x8 ^ 0x41) + ((0x2B ^ 0x30) << " ".length() << " ".length()) - ((0xB3 ^ 0xAC) << " ".length() << " ".length()) + ((0x8F ^ 0xAA) << " ".length());
    llIIllIlIIlIIl[140] = (0x60 ^ 0x5D) << " ".length() << " ".length() ^ 33 + 110 - 100 + 98;
    llIIllIlIIlIIl[141] = 41 + 74 - -123 + 11 ^ (0x39 ^ 0x78) << " ".length();
    llIIllIlIIlIIl[142] = ((0xB9 ^ 0x92) << " ".length() ^ 0x77 ^ 0x3E) << " ".length() << " ".length();
    llIIllIlIIlIIl[143] = (0x8 ^ 0x49) << " ".length();
    llIIllIlIIlIIl[144] = (0x79 ^ 0x66 ^ " ".length() << (0x7E ^ 0x7B)) << " ".length();
    llIIllIlIIlIIl[145] = 62 + 42 - 70 + 95;
    llIIllIlIIlIIl[146] = (0x4C ^ 0xF) << " ".length();
    llIIllIlIIlIIl[147] = (0x6B ^ 0x7A) << "   ".length();
    llIIllIlIIlIIl[148] = ((0x73 ^ 0x62) << " ".length()) + (0x7 ^ 0x14) - -(0x9E ^ 0x95) + (0x5D ^ 0x14);
    llIIllIlIIlIIl[149] = (0x7A ^ 0x3F) << " ".length();
    llIIllIlIIlIIl[150] = 43 + 25 - -41 + 30;
    llIIllIlIIlIIl[151] = (0x6A ^ 0x49) << " ".length() << " ".length();
    llIIllIlIIlIIl[152] = 21 + 4 - -86 + 30;
    llIIllIlIIlIIl[153] = (54 + 66 - 69 + 80 ^ (0xA7 ^ 0x96) << " ".length() << " ".length()) << " ".length();
    llIIllIlIIlIIl[154] = 39 + 91 - 39 + 52;
    llIIllIlIIlIIl[155] = (0xA0 ^ 0xA9) << " ".length() << " ".length() << " ".length();
    llIIllIlIIlIIl[156] = " ".length() + (0xA ^ 0x63) - ((0xA9 ^ 0x98) << " ".length()) + 50 + 115 - 140 + 112;
    llIIllIlIIlIIl[157] = (0x52 ^ 0x1B) << " ".length();
    llIIllIlIIlIIl[158] = 75 + 145 - 119 + 46;
    llIIllIlIIlIIl[159] = (20 + 29 - -51 + 29 ^ (0x5E ^ 0x77) << " ".length() << " ".length()) << " ".length() << " ".length();
    llIIllIlIIlIIl[160] = 114 + 127 - 115 + 23;
    llIIllIlIIlIIl[161] = 59 + 34 - 87 + 131 + ((0x8B ^ 0xA0) << " ".length()) - ((0x27 ^ 0x34) << " ".length() << " ".length()) + (" ".length() << " ".length() << " ".length());
    llIIllIlIIlIIl[162] = ((0x65 ^ 0x5C) << " ".length() ^ 0x40 ^ 0x21) << "   ".length();
    llIIllIlIIlIIl[163] = 38 + 12 - -41 + 62;
    llIIllIlIIlIIl[164] = (0x34 ^ 0x3D ^ (0x74 ^ 0x65) << " ".length() << " ".length()) << " ".length();
    llIIllIlIIlIIl[165] = (0x15 ^ 0x52) + (0x4B ^ 0x4C) - -(0x45 ^ 0x5) + (0x9B ^ 0x96);
    llIIllIlIIlIIl[166] = (0x67 ^ 0x40) << " ".length() << " ".length();
    llIIllIlIIlIIl[167] = ((0x74 ^ 0x47) << " ".length()) + (0x23 ^ 0x32) - "   ".length() + (0x3F ^ 0x16);
    llIIllIlIIlIIl[168] = (0x5 ^ 0x4A) << " ".length();
    llIIllIlIIlIIl[169] = 94 + 4 - 68 + 129;
    llIIllIlIIlIIl[170] = (0x47 ^ 0x42) << (0x75 ^ 0x70);
    llIIllIlIIlIIl[171] = (" ".length() << "   ".length() << " ".length()) + ((0xB0 ^ 0x97) << " ".length() << " ".length()) - ((0x24 ^ 0x3F) << " ".length() << " ".length()) + (0x7F ^ 0x4E);
    llIIllIlIIlIIl[172] = (0x57 ^ 0x6) << " ".length();
    llIIllIlIIlIIl[173] = 58 + 17 - -86 + 2;
    llIIllIlIIlIIl[174] = (0x86 ^ 0xAF) << " ".length() << " ".length();
    llIIllIlIIlIIl[175] = (0xDD ^ 0x9A) + ((0x54 ^ 0x51) << "   ".length()) - -(0x60 ^ 0x72) + ((0x39 ^ 0x30) << " ".length() << " ".length());
    llIIllIlIIlIIl[176] = (0x1D ^ 0x4E) << " ".length();
    llIIllIlIIlIIl[177] = 134 + 94 - 125 + 64;
  }
  
  private static boolean lIIIlIIlIlIIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIlIlIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 >= paramInt2);
  }
  
  private static boolean lIIIlIIlIlIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIlIlIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIlIlIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lIIIlIIlIlIIlIII(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIlIIlIlIIlIIl(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIlIIlIlIIIllI(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIlIIlIlIIIlII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIlIIlIlIIIlIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIlIIlIlIlIIIl(int paramInt) {
    return (paramInt < 0);
  }
  
  private static boolean lIIIlIIlIlIIlIlI(int paramInt) {
    return (paramInt > 0);
  }
  
  private static int lIIIlIIlIlIIlllI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIlIIlIlIlIIII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIlIIlIlIlIIlI(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\az.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */