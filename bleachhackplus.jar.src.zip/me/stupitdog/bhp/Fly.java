package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.PlayerCapabilities;

public class Fly extends au {
  private static String[] llIIIIIIIIIIIl;
  
  private static Class[] llIIIIIIIIIIlI;
  
  private static final String[] llIIIIIIlIIlIl;
  
  private static String[] llIIIIIIlIIllI;
  
  private static final int[] llIIIIIIlIlIll;
  
  public Fly() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIIlIl : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIIlIl : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIIlIl : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllIlllIllllIIIll	Lme/stupitdog/bhp/Fly;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   15: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   18: iconst_0
    //   19: iaload
    //   20: putfield field_75101_c : Z
    //   23: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   28: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   33: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   38: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   41: iconst_0
    //   42: iaload
    //   43: putfield field_75100_b : Z
    //   46: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIllIlllIllllIIIlI	Lme/stupitdog/bhp/Fly;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   15: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   18: iconst_1
    //   19: iaload
    //   20: putfield field_75101_c : Z
    //   23: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   28: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   33: <illegal opcode> 3 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/PlayerCapabilities;
    //   38: getstatic me/stupitdog/bhp/Fly.llIIIIIIlIlIll : [I
    //   41: iconst_1
    //   42: iaload
    //   43: putfield field_75100_b : Z
    //   46: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   51: <illegal opcode> 4 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/settings/GameSettings;
    //   56: <illegal opcode> 5 : (Lnet/minecraft/client/settings/GameSettings;)Lnet/minecraft/client/settings/KeyBinding;
    //   61: <illegal opcode> 6 : (Lnet/minecraft/client/settings/KeyBinding;)Z
    //   66: invokestatic lIIIIIIlIIllllll : (I)Z
    //   69: ifeq -> 88
    //   72: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   77: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   82: ldc2_w -0.04
    //   85: putfield field_70181_x : D
    //   88: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	89	0	lllllllllllllllIllIlllIllllIIIIl	Lme/stupitdog/bhp/Fly;
  }
  
  static {
    lIIIIIIlIIllllIl();
    lIIIIIIlIIllIIll();
    lIIIIIIlIIllIIlI();
    lIIIIIIlIIlIlllI();
  }
  
  private static CallSite lIIIIIIIllIlIIIl(MethodHandles.Lookup lllllllllllllllIllIlllIlllIllIII, String lllllllllllllllIllIlllIlllIlIlll, MethodType lllllllllllllllIllIlllIlllIlIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIlllIllllI = llIIIIIIIIIIIl[Integer.parseInt(lllllllllllllllIllIlllIlllIlIlll)].split(llIIIIIIlIIlIl[llIIIIIIlIlIll[3]]);
      Class<?> lllllllllllllllIllIlllIlllIlllIl = Class.forName(lllllllllllllllIllIlllIlllIllllI[llIIIIIIlIlIll[0]]);
      String lllllllllllllllIllIlllIlllIlllII = lllllllllllllllIllIlllIlllIllllI[llIIIIIIlIlIll[1]];
      MethodHandle lllllllllllllllIllIlllIlllIllIll = null;
      int lllllllllllllllIllIlllIlllIllIlI = lllllllllllllllIllIlllIlllIllllI[llIIIIIIlIlIll[3]].length();
      if (lIIIIIIlIlIIIIII(lllllllllllllllIllIlllIlllIllIlI, llIIIIIIlIlIll[2])) {
        MethodType lllllllllllllllIllIlllIllllIIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIlllIllllI[llIIIIIIlIlIll[2]], Fly.class.getClassLoader());
        if (lIIIIIIlIlIIIIlI(lllllllllllllllIllIlllIlllIllIlI, llIIIIIIlIlIll[2])) {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findVirtual(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIllllIIIII);
          "".length();
          if ("   ".length() == " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findStatic(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIllllIIIII);
        } 
        "".length();
        if (" ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIlllIlllll = llIIIIIIIIIIlI[Integer.parseInt(lllllllllllllllIllIlllIlllIllllI[llIIIIIIlIlIll[2]])];
        if (lIIIIIIlIlIIIIlI(lllllllllllllllIllIlllIlllIllIlI, llIIIIIIlIlIll[3])) {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findGetter(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIlllIlllll);
          "".length();
          if (("   ".length() << (0x71 ^ 0x24 ^ (0xD ^ 0x8) << " ".length() << " ".length() << " ".length()) & ("   ".length() << (95 + 81 - 6 + 29 ^ (0x0 ^ 0x61) << " ".length()) ^ -" ".length())) >= " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIlIlIIIIlI(lllllllllllllllIllIlllIlllIllIlI, llIIIIIIlIlIll[4])) {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findStaticGetter(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIlllIlllll);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIlIlIIIIlI(lllllllllllllllIllIlllIlllIllIlI, llIIIIIIlIlIll[5])) {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findSetter(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIlllIlllll);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIlllIlllIllIll = lllllllllllllllIllIlllIlllIllIII.findStaticSetter(lllllllllllllllIllIlllIlllIlllIl, lllllllllllllllIllIlllIlllIlllII, lllllllllllllllIllIlllIlllIlllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIlllIllIll);
    } catch (Exception lllllllllllllllIllIlllIlllIllIIl) {
      lllllllllllllllIllIlllIlllIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIlIlllI() {
    llIIIIIIIIIIIl = new String[llIIIIIIlIlIll[6]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[3]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[4]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[5]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[5]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[0]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[7]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[2]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[6]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[4]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[8]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[7]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[9]];
    llIIIIIIIIIIIl[llIIIIIIlIlIll[1]] = llIIIIIIlIIlIl[llIIIIIIlIlIll[10]];
    llIIIIIIIIIIlI = new Class[llIIIIIIlIlIll[8]];
    llIIIIIIIIIIlI[llIIIIIIlIlIll[4]] = boolean.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[6]] = double.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[7]] = KeyBinding.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[2]] = EntityPlayerSP.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[5]] = GameSettings.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[3]] = PlayerCapabilities.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[0]] = f13.class;
    llIIIIIIIIIIlI[llIIIIIIlIlIll[1]] = Minecraft.class;
  }
  
  private static void lIIIIIIlIIllIIlI() {
    llIIIIIIlIIlIl = new String[llIIIIIIlIlIll[11]];
    llIIIIIIlIIlIl[llIIIIIIlIlIll[0]] = lIIIIIIlIIlIllll(llIIIIIIlIIllI[llIIIIIIlIlIll[0]], llIIIIIIlIIllI[llIIIIIIlIlIll[1]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[1]] = lIIIIIIlIIlIllll(llIIIIIIlIIllI[llIIIIIIlIlIll[2]], llIIIIIIlIIllI[llIIIIIIlIlIll[3]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[2]] = lIIIIIIlIIllIIII(llIIIIIIlIIllI[llIIIIIIlIlIll[4]], llIIIIIIlIIllI[llIIIIIIlIlIll[5]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[3]] = lIIIIIIlIIllIIIl(llIIIIIIlIIllI[llIIIIIIlIlIll[7]], llIIIIIIlIIllI[llIIIIIIlIlIll[6]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[4]] = lIIIIIIlIIllIIIl(llIIIIIIlIIllI[llIIIIIIlIlIll[8]], llIIIIIIlIIllI[llIIIIIIlIlIll[9]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[5]] = lIIIIIIlIIllIIIl(llIIIIIIlIIllI[llIIIIIIlIlIll[10]], llIIIIIIlIIllI[llIIIIIIlIlIll[11]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[7]] = lIIIIIIlIIlIllll(llIIIIIIlIIllI[llIIIIIIlIlIll[12]], llIIIIIIlIIllI[llIIIIIIlIlIll[13]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[6]] = lIIIIIIlIIllIIIl(llIIIIIIlIIllI[llIIIIIIlIlIll[14]], llIIIIIIlIIllI[llIIIIIIlIlIll[15]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[8]] = lIIIIIIlIIllIIII(llIIIIIIlIIllI[llIIIIIIlIlIll[16]], llIIIIIIlIIllI[llIIIIIIlIlIll[17]]);
    llIIIIIIlIIlIl[llIIIIIIlIlIll[9]] = lIIIIIIlIIllIIII("GwYifgwcDTMzExQFIn4CGQozPhVbEDMkFRwNMSNPPgYvEggbBz8+Bk8FIz4CKlJjYVVCUwk0W11KDGpBVQ==", "ucVPa");
    llIIIIIIlIIlIl[llIIIIIIlIlIll[10]] = lIIIIIIlIIllIIII("FSBFOx4NNQI8DhciRSoCCGstJBNCKAhyW0JlS2hK", "xEkHj");
    llIIIIIIlIIllI = null;
  }
  
  private static void lIIIIIIlIIllIIll() {
    String str = (new Exception()).getStackTrace()[llIIIIIIlIlIll[0]].getFileName();
    llIIIIIIlIIllI = str.substring(str.indexOf("ä") + llIIIIIIlIlIll[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIIlIllll(String lllllllllllllllIllIlllIlllIlIIlI, String lllllllllllllllIllIlllIlllIlIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlllIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlllIlIIIl.getBytes(StandardCharsets.UTF_8)), llIIIIIIlIlIll[8]), "DES");
      Cipher lllllllllllllllIllIlllIlllIlIlII = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIlllIlIlII.init(llIIIIIIlIlIll[2], lllllllllllllllIllIlllIlllIlIlIl);
      return new String(lllllllllllllllIllIlllIlllIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlllIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlllIlIIll) {
      lllllllllllllllIllIlllIlllIlIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIIllIIIl(String lllllllllllllllIllIlllIlllIIllIl, String lllllllllllllllIllIlllIlllIIllII) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlllIlIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlllIIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIlllIIllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIlllIIllll.init(llIIIIIIlIlIll[2], lllllllllllllllIllIlllIlllIlIIII);
      return new String(lllllllllllllllIllIlllIlllIIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlllIIlllI) {
      lllllllllllllllIllIlllIlllIIlllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIIllIIII(String lllllllllllllllIllIlllIlllIIlIlI, String lllllllllllllllIllIlllIlllIIlIIl) {
    lllllllllllllllIllIlllIlllIIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIlllIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIlllIIlIII = new StringBuilder();
    char[] lllllllllllllllIllIlllIlllIIIlll = lllllllllllllllIllIlllIlllIIlIIl.toCharArray();
    int lllllllllllllllIllIlllIlllIIIllI = llIIIIIIlIlIll[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIlllIIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIlIlIll[0];
    while (lIIIIIIlIlIIIllI(j, i)) {
      char lllllllllllllllIllIlllIlllIIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIlllIIIllI++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIlllIIlIII);
  }
  
  private static void lIIIIIIlIIllllIl() {
    llIIIIIIlIlIll = new int[18];
    llIIIIIIlIlIll[0] = (0x7F ^ 0x3C) & (0x49 ^ 0xA ^ 0xFFFFFFFF);
    llIIIIIIlIlIll[1] = " ".length();
    llIIIIIIlIlIll[2] = " ".length() << " ".length();
    llIIIIIIlIlIll[3] = "   ".length();
    llIIIIIIlIlIll[4] = " ".length() << " ".length() << " ".length();
    llIIIIIIlIlIll[5] = (0x96 ^ 0xB7) << " ".length() ^ 0x4B ^ 0xC;
    llIIIIIIlIlIll[6] = 37 + 119 - -2 + 31 ^ (0xFD ^ 0xA0) << " ".length();
    llIIIIIIlIlIll[7] = "   ".length() << " ".length();
    llIIIIIIlIlIll[8] = " ".length() << "   ".length();
    llIIIIIIlIlIll[9] = (0x7C ^ 0x7B) << "   ".length() ^ 0xAB ^ 0x9A;
    llIIIIIIlIlIll[10] = (0x77 ^ 0x50 ^ (0xBF ^ 0xAE) << " ".length()) << " ".length();
    llIIIIIIlIlIll[11] = 0x78 ^ 0x73;
    llIIIIIIlIlIll[12] = "   ".length() << " ".length() << " ".length();
    llIIIIIIlIlIll[13] = 0x8E ^ 0xAB ^ (0x8 ^ 0xD) << "   ".length();
    llIIIIIIlIlIll[14] = ((0xA3 ^ 0xA6) << " ".length() << " ".length() ^ 0xF ^ 0x1C) << " ".length();
    llIIIIIIlIlIll[15] = 0xD7 ^ 0x8E ^ (0xEB ^ 0xC0) << " ".length();
    llIIIIIIlIlIll[16] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIlIlIll[17] = 0xBE ^ 0xAF;
  }
  
  private static boolean lIIIIIIlIlIIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlIlIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlIlIIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIlIIllllll(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\Fly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */