package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class f03 extends Tessellator {
  public static f03 INSTANCE;
  
  private static String[] lIllIIllIllIll;
  
  private static Class[] lIllIIllIlllII;
  
  private static final String[] lIlllIlIIIIIll;
  
  private static String[] lIlllIlIIIIllI;
  
  private static final int[] lIlllIlIIIIlll;
  
  public f03() {
    super(lIlllIlIIIIlll[0]);
  }
  
  public static void prepare(int lllllllllllllllIlllIllIIIllIIIll) {
    // Byte code:
    //   0: <illegal opcode> 0 : ()V
    //   5: iload_0
    //   6: <illegal opcode> 1 : (I)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIllIIIllIIIll	I
  }
  
  public static void prepareGL() {
    // Byte code:
    //   0: <illegal opcode> 2 : ()Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
    //   5: <illegal opcode> 3 : ()Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
    //   10: <illegal opcode> 4 : ()Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
    //   15: <illegal opcode> 5 : ()Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
    //   20: <illegal opcode> 6 : (Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
    //   25: ldc 1.5
    //   27: <illegal opcode> 7 : (F)V
    //   32: <illegal opcode> 8 : ()V
    //   37: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   40: iconst_1
    //   41: iaload
    //   42: <illegal opcode> 9 : (Z)V
    //   47: <illegal opcode> 10 : ()V
    //   52: <illegal opcode> 11 : ()V
    //   57: <illegal opcode> 12 : ()V
    //   62: <illegal opcode> 13 : ()V
    //   67: <illegal opcode> 14 : ()V
    //   72: fconst_1
    //   73: fconst_1
    //   74: fconst_1
    //   75: <illegal opcode> 15 : (FFF)V
    //   80: return
  }
  
  public static void begin(int lllllllllllllllIlllIllIIIllIIIlI) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: iload_0
    //   11: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   16: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIlllIllIIIllIIIlI	I
  }
  
  public static void release() {
    // Byte code:
    //   0: <illegal opcode> 20 : ()V
    //   5: <illegal opcode> 21 : ()V
    //   10: return
  }
  
  public static void render() {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 22 : (Lme/stupitdog/bhp/f03;)V
    //   10: return
  }
  
  public static void releaseGL() {
    // Byte code:
    //   0: <illegal opcode> 23 : ()V
    //   5: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   8: iconst_2
    //   9: iaload
    //   10: <illegal opcode> 9 : (Z)V
    //   15: <illegal opcode> 24 : ()V
    //   20: <illegal opcode> 10 : ()V
    //   25: <illegal opcode> 25 : ()V
    //   30: fconst_1
    //   31: fconst_1
    //   32: fconst_1
    //   33: <illegal opcode> 15 : (FFF)V
    //   38: fconst_1
    //   39: fconst_1
    //   40: fconst_1
    //   41: fconst_1
    //   42: <illegal opcode> 26 : (FFFF)V
    //   47: return
  }
  
  public static void drawBox(AxisAlignedBB lllllllllllllllIlllIllIIIllIIIIl, int lllllllllllllllIlllIllIIIllIIIII, int lllllllllllllllIlllIllIIIlIlllll) {
    // Byte code:
    //   0: iload_1
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore_3
    //   14: iload_1
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: iconst_5
    //   19: iaload
    //   20: iushr
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: iconst_4
    //   25: iaload
    //   26: iand
    //   27: istore #4
    //   29: iload_1
    //   30: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   33: bipush #6
    //   35: iaload
    //   36: iushr
    //   37: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   40: iconst_4
    //   41: iaload
    //   42: iand
    //   43: istore #5
    //   45: iload_1
    //   46: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   49: iconst_4
    //   50: iaload
    //   51: iand
    //   52: istore #6
    //   54: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   59: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   64: aload_0
    //   65: iload #4
    //   67: iload #5
    //   69: iload #6
    //   71: iload_3
    //   72: iload_2
    //   73: <illegal opcode> 27 : (Lnet/minecraft/client/renderer/BufferBuilder;Lnet/minecraft/util/math/AxisAlignedBB;IIIII)V
    //   78: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	0	lllllllllllllllIlllIllIIIllIIIIl	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	79	1	lllllllllllllllIlllIllIIIllIIIII	I
    //   0	79	2	lllllllllllllllIlllIllIIIlIlllll	I
    //   14	65	3	lllllllllllllllIlllIllIIIlIllllI	I
    //   29	50	4	lllllllllllllllIlllIllIIIlIlllIl	I
    //   45	34	5	lllllllllllllllIlllIllIIIlIlllII	I
    //   54	25	6	lllllllllllllllIlllIllIIIlIllIll	I
  }
  
  public static void drawBox(BlockPos lllllllllllllllIlllIllIIIlIllIlI, int lllllllllllllllIlllIllIIIlIllIIl, int lllllllllllllllIlllIllIIIlIllIII) {
    // Byte code:
    //   0: iload_1
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore_3
    //   14: iload_1
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: iconst_5
    //   19: iaload
    //   20: iushr
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: iconst_4
    //   25: iaload
    //   26: iand
    //   27: istore #4
    //   29: iload_1
    //   30: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   33: bipush #6
    //   35: iaload
    //   36: iushr
    //   37: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   40: iconst_4
    //   41: iaload
    //   42: iand
    //   43: istore #5
    //   45: iload_1
    //   46: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   49: iconst_4
    //   50: iaload
    //   51: iand
    //   52: istore #6
    //   54: aload_0
    //   55: iload #4
    //   57: iload #5
    //   59: iload #6
    //   61: iload_3
    //   62: iload_2
    //   63: <illegal opcode> 28 : (Lnet/minecraft/util/math/BlockPos;IIIII)V
    //   68: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	69	0	lllllllllllllllIlllIllIIIlIllIlI	Lnet/minecraft/util/math/BlockPos;
    //   0	69	1	lllllllllllllllIlllIllIIIlIllIIl	I
    //   0	69	2	lllllllllllllllIlllIllIIIlIllIII	I
    //   14	55	3	lllllllllllllllIlllIllIIIlIlIlll	I
    //   29	40	4	lllllllllllllllIlllIllIIIlIlIllI	I
    //   45	24	5	lllllllllllllllIlllIllIIIlIlIlIl	I
    //   54	15	6	lllllllllllllllIlllIllIIIlIlIlII	I
  }
  
  public static void drawHalfBox(BlockPos lllllllllllllllIlllIllIIIlIlIIll, int lllllllllllllllIlllIllIIIlIlIIlI, int lllllllllllllllIlllIllIIIlIlIIIl) {
    // Byte code:
    //   0: iload_1
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore_3
    //   14: iload_1
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: iconst_5
    //   19: iaload
    //   20: iushr
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: iconst_4
    //   25: iaload
    //   26: iand
    //   27: istore #4
    //   29: iload_1
    //   30: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   33: bipush #6
    //   35: iaload
    //   36: iushr
    //   37: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   40: iconst_4
    //   41: iaload
    //   42: iand
    //   43: istore #5
    //   45: iload_1
    //   46: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   49: iconst_4
    //   50: iaload
    //   51: iand
    //   52: istore #6
    //   54: aload_0
    //   55: iload #4
    //   57: iload #5
    //   59: iload #6
    //   61: iload_3
    //   62: iload_2
    //   63: <illegal opcode> 29 : (Lnet/minecraft/util/math/BlockPos;IIIII)V
    //   68: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	69	0	lllllllllllllllIlllIllIIIlIlIIll	Lnet/minecraft/util/math/BlockPos;
    //   0	69	1	lllllllllllllllIlllIllIIIlIlIIlI	I
    //   0	69	2	lllllllllllllllIlllIllIIIlIlIIIl	I
    //   14	55	3	lllllllllllllllIlllIllIIIlIlIIII	I
    //   29	40	4	lllllllllllllllIlllIllIIIlIIllll	I
    //   45	24	5	lllllllllllllllIlllIllIIIlIIlllI	I
    //   54	15	6	lllllllllllllllIlllIllIIIlIIllIl	I
  }
  
  public static void drawHalfBox(float lllllllllllllllIlllIllIIIlIIllII, float lllllllllllllllIlllIllIIIlIIlIll, float lllllllllllllllIlllIllIIIlIIlIlI, int lllllllllllllllIlllIllIIIlIIlIIl, int lllllllllllllllIlllIllIIIlIIlIII) {
    // Byte code:
    //   0: iload_3
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore #5
    //   15: iload_3
    //   16: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   19: iconst_5
    //   20: iaload
    //   21: iushr
    //   22: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   25: iconst_4
    //   26: iaload
    //   27: iand
    //   28: istore #6
    //   30: iload_3
    //   31: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   34: bipush #6
    //   36: iaload
    //   37: iushr
    //   38: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   41: iconst_4
    //   42: iaload
    //   43: iand
    //   44: istore #7
    //   46: iload_3
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_4
    //   51: iaload
    //   52: iand
    //   53: istore #8
    //   55: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   60: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   65: fload_0
    //   66: fload_1
    //   67: fload_2
    //   68: fconst_1
    //   69: ldc 0.5
    //   71: fconst_1
    //   72: iload #6
    //   74: iload #7
    //   76: iload #8
    //   78: iload #5
    //   80: iload #4
    //   82: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   87: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	0	lllllllllllllllIlllIllIIIlIIllII	F
    //   0	88	1	lllllllllllllllIlllIllIIIlIIlIll	F
    //   0	88	2	lllllllllllllllIlllIllIIIlIIlIlI	F
    //   0	88	3	lllllllllllllllIlllIllIIIlIIlIIl	I
    //   0	88	4	lllllllllllllllIlllIllIIIlIIlIII	I
    //   15	73	5	lllllllllllllllIlllIllIIIlIIIlll	I
    //   30	58	6	lllllllllllllllIlllIllIIIlIIIllI	I
    //   46	42	7	lllllllllllllllIlllIllIIIlIIIlIl	I
    //   55	33	8	lllllllllllllllIlllIllIIIlIIIlII	I
  }
  
  public static void drawBox(float lllllllllllllllIlllIllIIIlIIIIll, float lllllllllllllllIlllIllIIIlIIIIlI, float lllllllllllllllIlllIllIIIlIIIIIl, int lllllllllllllllIlllIllIIIlIIIIII, int lllllllllllllllIlllIllIIIIllllll) {
    // Byte code:
    //   0: iload_3
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore #5
    //   15: iload_3
    //   16: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   19: iconst_5
    //   20: iaload
    //   21: iushr
    //   22: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   25: iconst_4
    //   26: iaload
    //   27: iand
    //   28: istore #6
    //   30: iload_3
    //   31: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   34: bipush #6
    //   36: iaload
    //   37: iushr
    //   38: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   41: iconst_4
    //   42: iaload
    //   43: iand
    //   44: istore #7
    //   46: iload_3
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_4
    //   51: iaload
    //   52: iand
    //   53: istore #8
    //   55: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   60: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   65: fload_0
    //   66: fload_1
    //   67: fload_2
    //   68: fconst_1
    //   69: fconst_1
    //   70: fconst_1
    //   71: iload #6
    //   73: iload #7
    //   75: iload #8
    //   77: iload #5
    //   79: iload #4
    //   81: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   86: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	87	0	lllllllllllllllIlllIllIIIlIIIIll	F
    //   0	87	1	lllllllllllllllIlllIllIIIlIIIIlI	F
    //   0	87	2	lllllllllllllllIlllIllIIIlIIIIIl	F
    //   0	87	3	lllllllllllllllIlllIllIIIlIIIIII	I
    //   0	87	4	lllllllllllllllIlllIllIIIIllllll	I
    //   15	72	5	lllllllllllllllIlllIllIIIIlllllI	I
    //   30	57	6	lllllllllllllllIlllIllIIIIllllIl	I
    //   46	41	7	lllllllllllllllIlllIllIIIIllllII	I
    //   55	32	8	lllllllllllllllIlllIllIIIIlllIll	I
  }
  
  public static void drawBox(BlockPos lllllllllllllllIlllIllIIIIlllIlI, int lllllllllllllllIlllIllIIIIlllIIl, int lllllllllllllllIlllIllIIIIlllIII, int lllllllllllllllIlllIllIIIIllIlll, int lllllllllllllllIlllIllIIIIllIllI, int lllllllllllllllIlllIllIIIIllIlIl) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: aload_0
    //   11: <illegal opcode> 31 : (Lnet/minecraft/util/math/BlockPos;)I
    //   16: i2f
    //   17: aload_0
    //   18: <illegal opcode> 32 : (Lnet/minecraft/util/math/BlockPos;)I
    //   23: i2f
    //   24: aload_0
    //   25: <illegal opcode> 33 : (Lnet/minecraft/util/math/BlockPos;)I
    //   30: i2f
    //   31: fconst_1
    //   32: fconst_1
    //   33: fconst_1
    //   34: iload_1
    //   35: iload_2
    //   36: iload_3
    //   37: iload #4
    //   39: iload #5
    //   41: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   46: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIlllIllIIIIlllIlI	Lnet/minecraft/util/math/BlockPos;
    //   0	47	1	lllllllllllllllIlllIllIIIIlllIIl	I
    //   0	47	2	lllllllllllllllIlllIllIIIIlllIII	I
    //   0	47	3	lllllllllllllllIlllIllIIIIllIlll	I
    //   0	47	4	lllllllllllllllIlllIllIIIIllIllI	I
    //   0	47	5	lllllllllllllllIlllIllIIIIllIlIl	I
  }
  
  public static void drawHalfBox(BlockPos lllllllllllllllIlllIllIIIIllIlII, int lllllllllllllllIlllIllIIIIllIIll, int lllllllllllllllIlllIllIIIIllIIlI, int lllllllllllllllIlllIllIIIIllIIIl, int lllllllllllllllIlllIllIIIIllIIII, int lllllllllllllllIlllIllIIIIlIllll) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: aload_0
    //   11: <illegal opcode> 31 : (Lnet/minecraft/util/math/BlockPos;)I
    //   16: i2f
    //   17: aload_0
    //   18: <illegal opcode> 32 : (Lnet/minecraft/util/math/BlockPos;)I
    //   23: i2f
    //   24: aload_0
    //   25: <illegal opcode> 33 : (Lnet/minecraft/util/math/BlockPos;)I
    //   30: i2f
    //   31: fconst_1
    //   32: ldc 0.5
    //   34: fconst_1
    //   35: iload_1
    //   36: iload_2
    //   37: iload_3
    //   38: iload #4
    //   40: iload #5
    //   42: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   47: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	48	0	lllllllllllllllIlllIllIIIIllIlII	Lnet/minecraft/util/math/BlockPos;
    //   0	48	1	lllllllllllllllIlllIllIIIIllIIll	I
    //   0	48	2	lllllllllllllllIlllIllIIIIllIIlI	I
    //   0	48	3	lllllllllllllllIlllIllIIIIllIIIl	I
    //   0	48	4	lllllllllllllllIlllIllIIIIllIIII	I
    //   0	48	5	lllllllllllllllIlllIllIIIIlIllll	I
  }
  
  public static void drawBox(Vec3d lllllllllllllllIlllIllIIIIlIlllI, int lllllllllllllllIlllIllIIIIlIllIl, int lllllllllllllllIlllIllIIIIlIllII, int lllllllllllllllIlllIllIIIIlIlIll, int lllllllllllllllIlllIllIIIIlIlIlI, int lllllllllllllllIlllIllIIIIlIlIIl) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: aload_0
    //   11: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;)D
    //   16: d2f
    //   17: aload_0
    //   18: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   23: d2f
    //   24: aload_0
    //   25: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   30: d2f
    //   31: fconst_1
    //   32: fconst_1
    //   33: fconst_1
    //   34: iload_1
    //   35: iload_2
    //   36: iload_3
    //   37: iload #4
    //   39: iload #5
    //   41: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   46: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	47	0	lllllllllllllllIlllIllIIIIlIlllI	Lnet/minecraft/util/math/Vec3d;
    //   0	47	1	lllllllllllllllIlllIllIIIIlIllIl	I
    //   0	47	2	lllllllllllllllIlllIllIIIIlIllII	I
    //   0	47	3	lllllllllllllllIlllIllIIIIlIlIll	I
    //   0	47	4	lllllllllllllllIlllIllIIIIlIlIlI	I
    //   0	47	5	lllllllllllllllIlllIllIIIIlIlIIl	I
  }
  
  public static BufferBuilder getBufferBuilder() {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: areturn
  }
  
  public static void drawBox(BufferBuilder lllllllllllllllIlllIllIIIIlIlIII, float lllllllllllllllIlllIllIIIIlIIlll, float lllllllllllllllIlllIllIIIIlIIllI, float lllllllllllllllIlllIllIIIIlIIlIl, float lllllllllllllllIlllIllIIIIlIIlII, float lllllllllllllllIlllIllIIIIlIIIll, float lllllllllllllllIlllIllIIIIlIIIlI, int lllllllllllllllIlllIllIIIIlIIIIl, int lllllllllllllllIlllIllIIIIlIIIII, int lllllllllllllllIlllIllIIIIIlllll, int lllllllllllllllIlllIllIIIIIllllI, int lllllllllllllllIlllIllIIIIIlllIl) {
    // Byte code:
    //   0: iload #11
    //   2: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   5: iconst_2
    //   6: iaload
    //   7: iand
    //   8: invokestatic lllllIIllIIlllI : (I)Z
    //   11: ifeq -> 146
    //   14: aload_0
    //   15: fload_1
    //   16: fload #4
    //   18: fadd
    //   19: f2d
    //   20: fload_2
    //   21: f2d
    //   22: fload_3
    //   23: f2d
    //   24: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   29: iload #7
    //   31: iload #8
    //   33: iload #9
    //   35: iload #10
    //   37: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   42: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   47: aload_0
    //   48: fload_1
    //   49: fload #4
    //   51: fadd
    //   52: f2d
    //   53: fload_2
    //   54: f2d
    //   55: fload_3
    //   56: fload #6
    //   58: fadd
    //   59: f2d
    //   60: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   65: iload #7
    //   67: iload #8
    //   69: iload #9
    //   71: iload #10
    //   73: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   78: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   83: aload_0
    //   84: fload_1
    //   85: f2d
    //   86: fload_2
    //   87: f2d
    //   88: fload_3
    //   89: fload #6
    //   91: fadd
    //   92: f2d
    //   93: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   98: iload #7
    //   100: iload #8
    //   102: iload #9
    //   104: iload #10
    //   106: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   111: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   116: aload_0
    //   117: fload_1
    //   118: f2d
    //   119: fload_2
    //   120: f2d
    //   121: fload_3
    //   122: f2d
    //   123: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   128: iload #7
    //   130: iload #8
    //   132: iload #9
    //   134: iload #10
    //   136: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   141: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   146: iload #11
    //   148: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   151: bipush #7
    //   153: iaload
    //   154: iand
    //   155: invokestatic lllllIIllIIlllI : (I)Z
    //   158: ifeq -> 305
    //   161: aload_0
    //   162: fload_1
    //   163: fload #4
    //   165: fadd
    //   166: f2d
    //   167: fload_2
    //   168: fload #5
    //   170: fadd
    //   171: f2d
    //   172: fload_3
    //   173: f2d
    //   174: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   179: iload #7
    //   181: iload #8
    //   183: iload #9
    //   185: iload #10
    //   187: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   192: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   197: aload_0
    //   198: fload_1
    //   199: f2d
    //   200: fload_2
    //   201: fload #5
    //   203: fadd
    //   204: f2d
    //   205: fload_3
    //   206: f2d
    //   207: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   212: iload #7
    //   214: iload #8
    //   216: iload #9
    //   218: iload #10
    //   220: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   225: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   230: aload_0
    //   231: fload_1
    //   232: f2d
    //   233: fload_2
    //   234: fload #5
    //   236: fadd
    //   237: f2d
    //   238: fload_3
    //   239: fload #6
    //   241: fadd
    //   242: f2d
    //   243: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   248: iload #7
    //   250: iload #8
    //   252: iload #9
    //   254: iload #10
    //   256: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   261: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   266: aload_0
    //   267: fload_1
    //   268: fload #4
    //   270: fadd
    //   271: f2d
    //   272: fload_2
    //   273: fload #5
    //   275: fadd
    //   276: f2d
    //   277: fload_3
    //   278: fload #6
    //   280: fadd
    //   281: f2d
    //   282: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   287: iload #7
    //   289: iload #8
    //   291: iload #9
    //   293: iload #10
    //   295: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   300: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   305: iload #11
    //   307: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   310: bipush #8
    //   312: iaload
    //   313: iand
    //   314: invokestatic lllllIIllIIlllI : (I)Z
    //   317: ifeq -> 452
    //   320: aload_0
    //   321: fload_1
    //   322: fload #4
    //   324: fadd
    //   325: f2d
    //   326: fload_2
    //   327: f2d
    //   328: fload_3
    //   329: f2d
    //   330: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   335: iload #7
    //   337: iload #8
    //   339: iload #9
    //   341: iload #10
    //   343: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   348: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   353: aload_0
    //   354: fload_1
    //   355: f2d
    //   356: fload_2
    //   357: f2d
    //   358: fload_3
    //   359: f2d
    //   360: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   365: iload #7
    //   367: iload #8
    //   369: iload #9
    //   371: iload #10
    //   373: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   378: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   383: aload_0
    //   384: fload_1
    //   385: f2d
    //   386: fload_2
    //   387: fload #5
    //   389: fadd
    //   390: f2d
    //   391: fload_3
    //   392: f2d
    //   393: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   398: iload #7
    //   400: iload #8
    //   402: iload #9
    //   404: iload #10
    //   406: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   411: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   416: aload_0
    //   417: fload_1
    //   418: fload #4
    //   420: fadd
    //   421: f2d
    //   422: fload_2
    //   423: fload #5
    //   425: fadd
    //   426: f2d
    //   427: fload_3
    //   428: f2d
    //   429: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   434: iload #7
    //   436: iload #8
    //   438: iload #9
    //   440: iload #10
    //   442: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   447: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   452: iload #11
    //   454: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   457: bipush #6
    //   459: iaload
    //   460: iand
    //   461: invokestatic lllllIIllIIlllI : (I)Z
    //   464: ifeq -> 611
    //   467: aload_0
    //   468: fload_1
    //   469: f2d
    //   470: fload_2
    //   471: f2d
    //   472: fload_3
    //   473: fload #6
    //   475: fadd
    //   476: f2d
    //   477: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   482: iload #7
    //   484: iload #8
    //   486: iload #9
    //   488: iload #10
    //   490: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   495: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   500: aload_0
    //   501: fload_1
    //   502: fload #4
    //   504: fadd
    //   505: f2d
    //   506: fload_2
    //   507: f2d
    //   508: fload_3
    //   509: fload #6
    //   511: fadd
    //   512: f2d
    //   513: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   518: iload #7
    //   520: iload #8
    //   522: iload #9
    //   524: iload #10
    //   526: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   531: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   536: aload_0
    //   537: fload_1
    //   538: fload #4
    //   540: fadd
    //   541: f2d
    //   542: fload_2
    //   543: fload #5
    //   545: fadd
    //   546: f2d
    //   547: fload_3
    //   548: fload #6
    //   550: fadd
    //   551: f2d
    //   552: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   557: iload #7
    //   559: iload #8
    //   561: iload #9
    //   563: iload #10
    //   565: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   570: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   575: aload_0
    //   576: fload_1
    //   577: f2d
    //   578: fload_2
    //   579: fload #5
    //   581: fadd
    //   582: f2d
    //   583: fload_3
    //   584: fload #6
    //   586: fadd
    //   587: f2d
    //   588: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   593: iload #7
    //   595: iload #8
    //   597: iload #9
    //   599: iload #10
    //   601: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   606: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   611: iload #11
    //   613: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   616: iconst_5
    //   617: iaload
    //   618: iand
    //   619: invokestatic lllllIIllIIlllI : (I)Z
    //   622: ifeq -> 757
    //   625: aload_0
    //   626: fload_1
    //   627: f2d
    //   628: fload_2
    //   629: f2d
    //   630: fload_3
    //   631: f2d
    //   632: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   637: iload #7
    //   639: iload #8
    //   641: iload #9
    //   643: iload #10
    //   645: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   650: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   655: aload_0
    //   656: fload_1
    //   657: f2d
    //   658: fload_2
    //   659: f2d
    //   660: fload_3
    //   661: fload #6
    //   663: fadd
    //   664: f2d
    //   665: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   670: iload #7
    //   672: iload #8
    //   674: iload #9
    //   676: iload #10
    //   678: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   683: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   688: aload_0
    //   689: fload_1
    //   690: f2d
    //   691: fload_2
    //   692: fload #5
    //   694: fadd
    //   695: f2d
    //   696: fload_3
    //   697: fload #6
    //   699: fadd
    //   700: f2d
    //   701: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   706: iload #7
    //   708: iload #8
    //   710: iload #9
    //   712: iload #10
    //   714: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   719: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   724: aload_0
    //   725: fload_1
    //   726: f2d
    //   727: fload_2
    //   728: fload #5
    //   730: fadd
    //   731: f2d
    //   732: fload_3
    //   733: f2d
    //   734: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   739: iload #7
    //   741: iload #8
    //   743: iload #9
    //   745: iload #10
    //   747: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   752: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   757: iload #11
    //   759: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   762: bipush #9
    //   764: iaload
    //   765: iand
    //   766: invokestatic lllllIIllIIlllI : (I)Z
    //   769: ifeq -> 916
    //   772: aload_0
    //   773: fload_1
    //   774: fload #4
    //   776: fadd
    //   777: f2d
    //   778: fload_2
    //   779: f2d
    //   780: fload_3
    //   781: fload #6
    //   783: fadd
    //   784: f2d
    //   785: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   790: iload #7
    //   792: iload #8
    //   794: iload #9
    //   796: iload #10
    //   798: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   803: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   808: aload_0
    //   809: fload_1
    //   810: fload #4
    //   812: fadd
    //   813: f2d
    //   814: fload_2
    //   815: f2d
    //   816: fload_3
    //   817: f2d
    //   818: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   823: iload #7
    //   825: iload #8
    //   827: iload #9
    //   829: iload #10
    //   831: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   836: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   841: aload_0
    //   842: fload_1
    //   843: fload #4
    //   845: fadd
    //   846: f2d
    //   847: fload_2
    //   848: fload #5
    //   850: fadd
    //   851: f2d
    //   852: fload_3
    //   853: f2d
    //   854: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   859: iload #7
    //   861: iload #8
    //   863: iload #9
    //   865: iload #10
    //   867: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   872: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   877: aload_0
    //   878: fload_1
    //   879: fload #4
    //   881: fadd
    //   882: f2d
    //   883: fload_2
    //   884: fload #5
    //   886: fadd
    //   887: f2d
    //   888: fload_3
    //   889: fload #6
    //   891: fadd
    //   892: f2d
    //   893: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   898: iload #7
    //   900: iload #8
    //   902: iload #9
    //   904: iload #10
    //   906: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   911: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   916: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	917	0	lllllllllllllllIlllIllIIIIlIlIII	Lnet/minecraft/client/renderer/BufferBuilder;
    //   0	917	1	lllllllllllllllIlllIllIIIIlIIlll	F
    //   0	917	2	lllllllllllllllIlllIllIIIIlIIllI	F
    //   0	917	3	lllllllllllllllIlllIllIIIIlIIlIl	F
    //   0	917	4	lllllllllllllllIlllIllIIIIlIIlII	F
    //   0	917	5	lllllllllllllllIlllIllIIIIlIIIll	F
    //   0	917	6	lllllllllllllllIlllIllIIIIlIIIlI	F
    //   0	917	7	lllllllllllllllIlllIllIIIIlIIIIl	I
    //   0	917	8	lllllllllllllllIlllIllIIIIlIIIII	I
    //   0	917	9	lllllllllllllllIlllIllIIIIIlllll	I
    //   0	917	10	lllllllllllllllIlllIllIIIIIllllI	I
    //   0	917	11	lllllllllllllllIlllIllIIIIIlllIl	I
  }
  
  public static void drawBox(BufferBuilder lllllllllllllllIlllIllIIIIIlllII, AxisAlignedBB lllllllllllllllIlllIllIIIIIllIll, int lllllllllllllllIlllIllIIIIIllIlI, int lllllllllllllllIlllIllIIIIIllIIl, int lllllllllllllllIlllIllIIIIIllIII, int lllllllllllllllIlllIllIIIIIlIlll, int lllllllllllllllIlllIllIIIIIlIllI) {
    // Byte code:
    //   0: iload #6
    //   2: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   5: iconst_2
    //   6: iaload
    //   7: iand
    //   8: invokestatic lllllIIllIIlllI : (I)Z
    //   11: ifeq -> 174
    //   14: aload_0
    //   15: aload_1
    //   16: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   21: aload_1
    //   22: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   27: aload_1
    //   28: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   33: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   38: iload_2
    //   39: iload_3
    //   40: iload #4
    //   42: iload #5
    //   44: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   49: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   54: aload_0
    //   55: aload_1
    //   56: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   61: aload_1
    //   62: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   67: aload_1
    //   68: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   73: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   78: iload_2
    //   79: iload_3
    //   80: iload #4
    //   82: iload #5
    //   84: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   89: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   94: aload_0
    //   95: aload_1
    //   96: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   101: aload_1
    //   102: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   107: aload_1
    //   108: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   113: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   118: iload_2
    //   119: iload_3
    //   120: iload #4
    //   122: iload #5
    //   124: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   129: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   134: aload_0
    //   135: aload_1
    //   136: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   141: aload_1
    //   142: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   147: aload_1
    //   148: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   153: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   158: iload_2
    //   159: iload_3
    //   160: iload #4
    //   162: iload #5
    //   164: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   169: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   174: iload #6
    //   176: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   179: bipush #7
    //   181: iaload
    //   182: iand
    //   183: invokestatic lllllIIllIIlllI : (I)Z
    //   186: ifeq -> 349
    //   189: aload_0
    //   190: aload_1
    //   191: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   196: aload_1
    //   197: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   202: aload_1
    //   203: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   208: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   213: iload_2
    //   214: iload_3
    //   215: iload #4
    //   217: iload #5
    //   219: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   224: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   229: aload_0
    //   230: aload_1
    //   231: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   236: aload_1
    //   237: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   242: aload_1
    //   243: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   248: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   253: iload_2
    //   254: iload_3
    //   255: iload #4
    //   257: iload #5
    //   259: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   264: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   269: aload_0
    //   270: aload_1
    //   271: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   276: aload_1
    //   277: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   282: aload_1
    //   283: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   288: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   293: iload_2
    //   294: iload_3
    //   295: iload #4
    //   297: iload #5
    //   299: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   304: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   309: aload_0
    //   310: aload_1
    //   311: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   316: aload_1
    //   317: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   322: aload_1
    //   323: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   328: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   333: iload_2
    //   334: iload_3
    //   335: iload #4
    //   337: iload #5
    //   339: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   344: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   349: iload #6
    //   351: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   354: bipush #8
    //   356: iaload
    //   357: iand
    //   358: invokestatic lllllIIllIIlllI : (I)Z
    //   361: ifeq -> 524
    //   364: aload_0
    //   365: aload_1
    //   366: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   371: aload_1
    //   372: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   377: aload_1
    //   378: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   383: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   388: iload_2
    //   389: iload_3
    //   390: iload #4
    //   392: iload #5
    //   394: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   399: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   404: aload_0
    //   405: aload_1
    //   406: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   411: aload_1
    //   412: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   417: aload_1
    //   418: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   423: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   428: iload_2
    //   429: iload_3
    //   430: iload #4
    //   432: iload #5
    //   434: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   439: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   444: aload_0
    //   445: aload_1
    //   446: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   451: aload_1
    //   452: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   457: aload_1
    //   458: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   463: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   468: iload_2
    //   469: iload_3
    //   470: iload #4
    //   472: iload #5
    //   474: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   479: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   484: aload_0
    //   485: aload_1
    //   486: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   491: aload_1
    //   492: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   497: aload_1
    //   498: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   503: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   508: iload_2
    //   509: iload_3
    //   510: iload #4
    //   512: iload #5
    //   514: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   519: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   524: iload #6
    //   526: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   529: bipush #6
    //   531: iaload
    //   532: iand
    //   533: invokestatic lllllIIllIIlllI : (I)Z
    //   536: ifeq -> 699
    //   539: aload_0
    //   540: aload_1
    //   541: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   546: aload_1
    //   547: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   552: aload_1
    //   553: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   558: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   563: iload_2
    //   564: iload_3
    //   565: iload #4
    //   567: iload #5
    //   569: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   574: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   579: aload_0
    //   580: aload_1
    //   581: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   586: aload_1
    //   587: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   592: aload_1
    //   593: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   598: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   603: iload_2
    //   604: iload_3
    //   605: iload #4
    //   607: iload #5
    //   609: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   614: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   619: aload_0
    //   620: aload_1
    //   621: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   626: aload_1
    //   627: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   632: aload_1
    //   633: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   638: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   643: iload_2
    //   644: iload_3
    //   645: iload #4
    //   647: iload #5
    //   649: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   654: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   659: aload_0
    //   660: aload_1
    //   661: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   666: aload_1
    //   667: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   672: aload_1
    //   673: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   678: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   683: iload_2
    //   684: iload_3
    //   685: iload #4
    //   687: iload #5
    //   689: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   694: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   699: iload #6
    //   701: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   704: iconst_5
    //   705: iaload
    //   706: iand
    //   707: invokestatic lllllIIllIIlllI : (I)Z
    //   710: ifeq -> 873
    //   713: aload_0
    //   714: aload_1
    //   715: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   720: aload_1
    //   721: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   726: aload_1
    //   727: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   732: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   737: iload_2
    //   738: iload_3
    //   739: iload #4
    //   741: iload #5
    //   743: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   748: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   753: aload_0
    //   754: aload_1
    //   755: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   760: aload_1
    //   761: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   766: aload_1
    //   767: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   772: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   777: iload_2
    //   778: iload_3
    //   779: iload #4
    //   781: iload #5
    //   783: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   788: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   793: aload_0
    //   794: aload_1
    //   795: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   800: aload_1
    //   801: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   806: aload_1
    //   807: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   812: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   817: iload_2
    //   818: iload_3
    //   819: iload #4
    //   821: iload #5
    //   823: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   828: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   833: aload_0
    //   834: aload_1
    //   835: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   840: aload_1
    //   841: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   846: aload_1
    //   847: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   852: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   857: iload_2
    //   858: iload_3
    //   859: iload #4
    //   861: iload #5
    //   863: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   868: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   873: iload #6
    //   875: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   878: bipush #9
    //   880: iaload
    //   881: iand
    //   882: invokestatic lllllIIllIIlllI : (I)Z
    //   885: ifeq -> 1048
    //   888: aload_0
    //   889: aload_1
    //   890: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   895: aload_1
    //   896: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   901: aload_1
    //   902: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   907: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   912: iload_2
    //   913: iload_3
    //   914: iload #4
    //   916: iload #5
    //   918: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   923: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   928: aload_0
    //   929: aload_1
    //   930: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   935: aload_1
    //   936: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   941: aload_1
    //   942: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   947: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   952: iload_2
    //   953: iload_3
    //   954: iload #4
    //   956: iload #5
    //   958: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   963: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   968: aload_0
    //   969: aload_1
    //   970: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   975: aload_1
    //   976: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   981: aload_1
    //   982: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   987: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   992: iload_2
    //   993: iload_3
    //   994: iload #4
    //   996: iload #5
    //   998: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1003: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   1008: aload_0
    //   1009: aload_1
    //   1010: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1015: aload_1
    //   1016: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1021: aload_1
    //   1022: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1027: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1032: iload_2
    //   1033: iload_3
    //   1034: iload #4
    //   1036: iload #5
    //   1038: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1043: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   1048: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1049	0	lllllllllllllllIlllIllIIIIIlllII	Lnet/minecraft/client/renderer/BufferBuilder;
    //   0	1049	1	lllllllllllllllIlllIllIIIIIllIll	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	1049	2	lllllllllllllllIlllIllIIIIIllIlI	I
    //   0	1049	3	lllllllllllllllIlllIllIIIIIllIIl	I
    //   0	1049	4	lllllllllllllllIlllIllIIIIIllIII	I
    //   0	1049	5	lllllllllllllllIlllIllIIIIIlIlll	I
    //   0	1049	6	lllllllllllllllIlllIllIIIIIlIllI	I
  }
  
  public static void drawSmallBox(Vec3d lllllllllllllllIlllIllIIIIIlIlIl, int lllllllllllllllIlllIllIIIIIlIlII, int lllllllllllllllIlllIllIIIIIlIIll, int lllllllllllllllIlllIllIIIIIlIIlI, int lllllllllllllllIlllIllIIIIIlIIIl, int lllllllllllllllIlllIllIIIIIlIIII) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: aload_0
    //   11: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;)D
    //   16: d2f
    //   17: aload_0
    //   18: <illegal opcode> 35 : (Lnet/minecraft/util/math/Vec3d;)D
    //   23: d2f
    //   24: aload_0
    //   25: <illegal opcode> 36 : (Lnet/minecraft/util/math/Vec3d;)D
    //   30: d2f
    //   31: ldc_w 0.3
    //   34: ldc_w 0.3
    //   37: ldc_w 0.3
    //   40: iload_1
    //   41: iload_2
    //   42: iload_3
    //   43: iload #4
    //   45: iload #5
    //   47: <illegal opcode> 30 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIIII)V
    //   52: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	53	0	lllllllllllllllIlllIllIIIIIlIlIl	Lnet/minecraft/util/math/Vec3d;
    //   0	53	1	lllllllllllllllIlllIllIIIIIlIlII	I
    //   0	53	2	lllllllllllllllIlllIllIIIIIlIIll	I
    //   0	53	3	lllllllllllllllIlllIllIIIIIlIIlI	I
    //   0	53	4	lllllllllllllllIlllIllIIIIIlIIIl	I
    //   0	53	5	lllllllllllllllIlllIllIIIIIlIIII	I
  }
  
  public static void drawLines(BufferBuilder lllllllllllllllIlllIllIIIIIIllll, float lllllllllllllllIlllIllIIIIIIlllI, float lllllllllllllllIlllIllIIIIIIllIl, float lllllllllllllllIlllIllIIIIIIllII, float lllllllllllllllIlllIllIIIIIIlIll, float lllllllllllllllIlllIllIIIIIIlIlI, float lllllllllllllllIlllIllIIIIIIlIIl, int lllllllllllllllIlllIllIIIIIIlIII, int lllllllllllllllIlllIllIIIIIIIlll, int lllllllllllllllIlllIllIIIIIIIllI, int lllllllllllllllIlllIllIIIIIIIlIl, int lllllllllllllllIlllIllIIIIIIIlII) {
    // Byte code:
    //   0: iload #11
    //   2: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   5: bipush #10
    //   7: iaload
    //   8: iand
    //   9: invokestatic lllllIIllIIlllI : (I)Z
    //   12: ifeq -> 78
    //   15: aload_0
    //   16: fload_1
    //   17: f2d
    //   18: fload_2
    //   19: f2d
    //   20: fload_3
    //   21: f2d
    //   22: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   27: iload #7
    //   29: iload #8
    //   31: iload #9
    //   33: iload #10
    //   35: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   40: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   45: aload_0
    //   46: fload_1
    //   47: f2d
    //   48: fload_2
    //   49: f2d
    //   50: fload_3
    //   51: fload #6
    //   53: fadd
    //   54: f2d
    //   55: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   60: iload #7
    //   62: iload #8
    //   64: iload #9
    //   66: iload #10
    //   68: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   73: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   78: iload #11
    //   80: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   83: bipush #11
    //   85: iaload
    //   86: iand
    //   87: invokestatic lllllIIllIIlllI : (I)Z
    //   90: ifeq -> 162
    //   93: aload_0
    //   94: fload_1
    //   95: f2d
    //   96: fload_2
    //   97: fload #5
    //   99: fadd
    //   100: f2d
    //   101: fload_3
    //   102: f2d
    //   103: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   108: iload #7
    //   110: iload #8
    //   112: iload #9
    //   114: iload #10
    //   116: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   121: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   126: aload_0
    //   127: fload_1
    //   128: f2d
    //   129: fload_2
    //   130: fload #5
    //   132: fadd
    //   133: f2d
    //   134: fload_3
    //   135: fload #6
    //   137: fadd
    //   138: f2d
    //   139: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   144: iload #7
    //   146: iload #8
    //   148: iload #9
    //   150: iload #10
    //   152: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   157: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   162: iload #11
    //   164: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   167: bipush #12
    //   169: iaload
    //   170: iand
    //   171: invokestatic lllllIIllIIlllI : (I)Z
    //   174: ifeq -> 246
    //   177: aload_0
    //   178: fload_1
    //   179: fload #4
    //   181: fadd
    //   182: f2d
    //   183: fload_2
    //   184: f2d
    //   185: fload_3
    //   186: f2d
    //   187: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   192: iload #7
    //   194: iload #8
    //   196: iload #9
    //   198: iload #10
    //   200: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   205: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   210: aload_0
    //   211: fload_1
    //   212: fload #4
    //   214: fadd
    //   215: f2d
    //   216: fload_2
    //   217: f2d
    //   218: fload_3
    //   219: fload #6
    //   221: fadd
    //   222: f2d
    //   223: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   228: iload #7
    //   230: iload #8
    //   232: iload #9
    //   234: iload #10
    //   236: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   241: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   246: iload #11
    //   248: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   251: bipush #13
    //   253: iaload
    //   254: iand
    //   255: invokestatic lllllIIllIIlllI : (I)Z
    //   258: ifeq -> 336
    //   261: aload_0
    //   262: fload_1
    //   263: fload #4
    //   265: fadd
    //   266: f2d
    //   267: fload_2
    //   268: fload #5
    //   270: fadd
    //   271: f2d
    //   272: fload_3
    //   273: f2d
    //   274: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   279: iload #7
    //   281: iload #8
    //   283: iload #9
    //   285: iload #10
    //   287: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   292: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   297: aload_0
    //   298: fload_1
    //   299: fload #4
    //   301: fadd
    //   302: f2d
    //   303: fload_2
    //   304: fload #5
    //   306: fadd
    //   307: f2d
    //   308: fload_3
    //   309: fload #6
    //   311: fadd
    //   312: f2d
    //   313: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   318: iload #7
    //   320: iload #8
    //   322: iload #9
    //   324: iload #10
    //   326: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   331: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   336: iload #11
    //   338: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   341: bipush #14
    //   343: iaload
    //   344: iand
    //   345: invokestatic lllllIIllIIlllI : (I)Z
    //   348: ifeq -> 414
    //   351: aload_0
    //   352: fload_1
    //   353: f2d
    //   354: fload_2
    //   355: f2d
    //   356: fload_3
    //   357: f2d
    //   358: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   363: iload #7
    //   365: iload #8
    //   367: iload #9
    //   369: iload #10
    //   371: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   376: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   381: aload_0
    //   382: fload_1
    //   383: fload #4
    //   385: fadd
    //   386: f2d
    //   387: fload_2
    //   388: f2d
    //   389: fload_3
    //   390: f2d
    //   391: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   396: iload #7
    //   398: iload #8
    //   400: iload #9
    //   402: iload #10
    //   404: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   409: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   414: iload #11
    //   416: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   419: bipush #15
    //   421: iaload
    //   422: iand
    //   423: invokestatic lllllIIllIIlllI : (I)Z
    //   426: ifeq -> 498
    //   429: aload_0
    //   430: fload_1
    //   431: f2d
    //   432: fload_2
    //   433: fload #5
    //   435: fadd
    //   436: f2d
    //   437: fload_3
    //   438: f2d
    //   439: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   444: iload #7
    //   446: iload #8
    //   448: iload #9
    //   450: iload #10
    //   452: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   457: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   462: aload_0
    //   463: fload_1
    //   464: fload #4
    //   466: fadd
    //   467: f2d
    //   468: fload_2
    //   469: fload #5
    //   471: fadd
    //   472: f2d
    //   473: fload_3
    //   474: f2d
    //   475: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   480: iload #7
    //   482: iload #8
    //   484: iload #9
    //   486: iload #10
    //   488: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   493: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   498: iload #11
    //   500: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   503: bipush #16
    //   505: iaload
    //   506: iand
    //   507: invokestatic lllllIIllIIlllI : (I)Z
    //   510: ifeq -> 582
    //   513: aload_0
    //   514: fload_1
    //   515: f2d
    //   516: fload_2
    //   517: f2d
    //   518: fload_3
    //   519: fload #6
    //   521: fadd
    //   522: f2d
    //   523: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   528: iload #7
    //   530: iload #8
    //   532: iload #9
    //   534: iload #10
    //   536: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   541: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   546: aload_0
    //   547: fload_1
    //   548: fload #4
    //   550: fadd
    //   551: f2d
    //   552: fload_2
    //   553: f2d
    //   554: fload_3
    //   555: fload #6
    //   557: fadd
    //   558: f2d
    //   559: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   564: iload #7
    //   566: iload #8
    //   568: iload #9
    //   570: iload #10
    //   572: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   577: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   582: iload #11
    //   584: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   587: bipush #17
    //   589: iaload
    //   590: iand
    //   591: invokestatic lllllIIllIIlllI : (I)Z
    //   594: ifeq -> 672
    //   597: aload_0
    //   598: fload_1
    //   599: f2d
    //   600: fload_2
    //   601: fload #5
    //   603: fadd
    //   604: f2d
    //   605: fload_3
    //   606: fload #6
    //   608: fadd
    //   609: f2d
    //   610: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   615: iload #7
    //   617: iload #8
    //   619: iload #9
    //   621: iload #10
    //   623: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   628: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   633: aload_0
    //   634: fload_1
    //   635: fload #4
    //   637: fadd
    //   638: f2d
    //   639: fload_2
    //   640: fload #5
    //   642: fadd
    //   643: f2d
    //   644: fload_3
    //   645: fload #6
    //   647: fadd
    //   648: f2d
    //   649: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   654: iload #7
    //   656: iload #8
    //   658: iload #9
    //   660: iload #10
    //   662: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   667: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   672: iload #11
    //   674: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   677: bipush #18
    //   679: iaload
    //   680: iand
    //   681: invokestatic lllllIIllIIlllI : (I)Z
    //   684: ifeq -> 750
    //   687: aload_0
    //   688: fload_1
    //   689: f2d
    //   690: fload_2
    //   691: f2d
    //   692: fload_3
    //   693: f2d
    //   694: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   699: iload #7
    //   701: iload #8
    //   703: iload #9
    //   705: iload #10
    //   707: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   712: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   717: aload_0
    //   718: fload_1
    //   719: f2d
    //   720: fload_2
    //   721: fload #5
    //   723: fadd
    //   724: f2d
    //   725: fload_3
    //   726: f2d
    //   727: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   732: iload #7
    //   734: iload #8
    //   736: iload #9
    //   738: iload #10
    //   740: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   745: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   750: iload #11
    //   752: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   755: bipush #19
    //   757: iaload
    //   758: iand
    //   759: invokestatic lllllIIllIIlllI : (I)Z
    //   762: ifeq -> 834
    //   765: aload_0
    //   766: fload_1
    //   767: fload #4
    //   769: fadd
    //   770: f2d
    //   771: fload_2
    //   772: f2d
    //   773: fload_3
    //   774: f2d
    //   775: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   780: iload #7
    //   782: iload #8
    //   784: iload #9
    //   786: iload #10
    //   788: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   793: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   798: aload_0
    //   799: fload_1
    //   800: fload #4
    //   802: fadd
    //   803: f2d
    //   804: fload_2
    //   805: fload #5
    //   807: fadd
    //   808: f2d
    //   809: fload_3
    //   810: f2d
    //   811: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   816: iload #7
    //   818: iload #8
    //   820: iload #9
    //   822: iload #10
    //   824: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   829: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   834: iload #11
    //   836: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   839: iconst_3
    //   840: iaload
    //   841: iand
    //   842: invokestatic lllllIIllIIlllI : (I)Z
    //   845: ifeq -> 917
    //   848: aload_0
    //   849: fload_1
    //   850: f2d
    //   851: fload_2
    //   852: f2d
    //   853: fload_3
    //   854: fload #6
    //   856: fadd
    //   857: f2d
    //   858: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   863: iload #7
    //   865: iload #8
    //   867: iload #9
    //   869: iload #10
    //   871: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   876: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   881: aload_0
    //   882: fload_1
    //   883: f2d
    //   884: fload_2
    //   885: fload #5
    //   887: fadd
    //   888: f2d
    //   889: fload_3
    //   890: fload #6
    //   892: fadd
    //   893: f2d
    //   894: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   899: iload #7
    //   901: iload #8
    //   903: iload #9
    //   905: iload #10
    //   907: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   912: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   917: iload #11
    //   919: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   922: bipush #20
    //   924: iaload
    //   925: iand
    //   926: invokestatic lllllIIllIIlllI : (I)Z
    //   929: ifeq -> 1007
    //   932: aload_0
    //   933: fload_1
    //   934: fload #4
    //   936: fadd
    //   937: f2d
    //   938: fload_2
    //   939: f2d
    //   940: fload_3
    //   941: fload #6
    //   943: fadd
    //   944: f2d
    //   945: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   950: iload #7
    //   952: iload #8
    //   954: iload #9
    //   956: iload #10
    //   958: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   963: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   968: aload_0
    //   969: fload_1
    //   970: fload #4
    //   972: fadd
    //   973: f2d
    //   974: fload_2
    //   975: fload #5
    //   977: fadd
    //   978: f2d
    //   979: fload_3
    //   980: fload #6
    //   982: fadd
    //   983: f2d
    //   984: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   989: iload #7
    //   991: iload #8
    //   993: iload #9
    //   995: iload #10
    //   997: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1002: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   1007: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1008	0	lllllllllllllllIlllIllIIIIIIllll	Lnet/minecraft/client/renderer/BufferBuilder;
    //   0	1008	1	lllllllllllllllIlllIllIIIIIIlllI	F
    //   0	1008	2	lllllllllllllllIlllIllIIIIIIllIl	F
    //   0	1008	3	lllllllllllllllIlllIllIIIIIIllII	F
    //   0	1008	4	lllllllllllllllIlllIllIIIIIIlIll	F
    //   0	1008	5	lllllllllllllllIlllIllIIIIIIlIlI	F
    //   0	1008	6	lllllllllllllllIlllIllIIIIIIlIIl	F
    //   0	1008	7	lllllllllllllllIlllIllIIIIIIlIII	I
    //   0	1008	8	lllllllllllllllIlllIllIIIIIIIlll	I
    //   0	1008	9	lllllllllllllllIlllIllIIIIIIIllI	I
    //   0	1008	10	lllllllllllllllIlllIllIIIIIIIlIl	I
    //   0	1008	11	lllllllllllllllIlllIllIIIIIIIlII	I
  }
  
  public static void drawBoundingBox(AxisAlignedBB lllllllllllllllIlllIllIIIIIIIIll, float lllllllllllllllIlllIllIIIIIIIIlI, int lllllllllllllllIlllIllIIIIIIIIIl, int lllllllllllllllIlllIllIIIIIIIIII, int lllllllllllllllIlllIlIllllllllll, int lllllllllllllllIlllIlIlllllllllI) {
    // Byte code:
    //   0: <illegal opcode> 46 : ()V
    //   5: <illegal opcode> 10 : ()V
    //   10: <illegal opcode> 11 : ()V
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: bipush #21
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: bipush #22
    //   26: iaload
    //   27: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   30: iconst_1
    //   31: iaload
    //   32: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   35: iconst_2
    //   36: iaload
    //   37: <illegal opcode> 47 : (IIII)V
    //   42: <illegal opcode> 8 : ()V
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_1
    //   51: iaload
    //   52: <illegal opcode> 9 : (Z)V
    //   57: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   60: bipush #23
    //   62: iaload
    //   63: <illegal opcode> 48 : (I)V
    //   68: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   71: bipush #24
    //   73: iaload
    //   74: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   77: bipush #25
    //   79: iaload
    //   80: <illegal opcode> 49 : (II)V
    //   85: fload_1
    //   86: <illegal opcode> 50 : (F)V
    //   91: <illegal opcode> 51 : ()Lnet/minecraft/client/renderer/Tessellator;
    //   96: astore #6
    //   98: aload #6
    //   100: <illegal opcode> 52 : (Lnet/minecraft/client/renderer/Tessellator;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   105: astore #7
    //   107: aload #7
    //   109: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   112: bipush #26
    //   114: iaload
    //   115: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   120: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   125: aload #7
    //   127: aload_0
    //   128: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   133: aload_0
    //   134: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   139: aload_0
    //   140: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   145: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   150: iload_2
    //   151: iload_3
    //   152: iload #4
    //   154: iload #5
    //   156: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   161: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   166: aload #7
    //   168: aload_0
    //   169: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   174: aload_0
    //   175: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   180: aload_0
    //   181: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   186: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   191: iload_2
    //   192: iload_3
    //   193: iload #4
    //   195: iload #5
    //   197: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   202: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   207: aload #7
    //   209: aload_0
    //   210: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   215: aload_0
    //   216: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   221: aload_0
    //   222: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   227: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   232: iload_2
    //   233: iload_3
    //   234: iload #4
    //   236: iload #5
    //   238: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   243: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   248: aload #7
    //   250: aload_0
    //   251: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   256: aload_0
    //   257: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   262: aload_0
    //   263: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   268: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   273: iload_2
    //   274: iload_3
    //   275: iload #4
    //   277: iload #5
    //   279: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   284: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   289: aload #7
    //   291: aload_0
    //   292: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   297: aload_0
    //   298: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   303: aload_0
    //   304: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   309: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   314: iload_2
    //   315: iload_3
    //   316: iload #4
    //   318: iload #5
    //   320: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   325: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   330: aload #6
    //   332: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   337: aload #7
    //   339: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   342: bipush #26
    //   344: iaload
    //   345: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   350: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   355: aload #7
    //   357: aload_0
    //   358: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   363: aload_0
    //   364: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   369: aload_0
    //   370: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   375: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   380: iload_2
    //   381: iload_3
    //   382: iload #4
    //   384: iload #5
    //   386: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   391: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   396: aload #7
    //   398: aload_0
    //   399: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   404: aload_0
    //   405: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   410: aload_0
    //   411: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   416: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   421: iload_2
    //   422: iload_3
    //   423: iload #4
    //   425: iload #5
    //   427: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   432: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   437: aload #7
    //   439: aload_0
    //   440: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   445: aload_0
    //   446: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   451: aload_0
    //   452: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   457: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   462: iload_2
    //   463: iload_3
    //   464: iload #4
    //   466: iload #5
    //   468: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   473: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   478: aload #7
    //   480: aload_0
    //   481: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   486: aload_0
    //   487: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   492: aload_0
    //   493: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   498: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   503: iload_2
    //   504: iload_3
    //   505: iload #4
    //   507: iload #5
    //   509: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   514: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   519: aload #7
    //   521: aload_0
    //   522: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   527: aload_0
    //   528: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   533: aload_0
    //   534: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   539: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   544: iload_2
    //   545: iload_3
    //   546: iload #4
    //   548: iload #5
    //   550: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   555: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   560: aload #6
    //   562: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   567: aload #7
    //   569: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   572: iconst_2
    //   573: iaload
    //   574: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   579: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   584: aload #7
    //   586: aload_0
    //   587: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   592: aload_0
    //   593: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   598: aload_0
    //   599: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   604: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   609: iload_2
    //   610: iload_3
    //   611: iload #4
    //   613: iload #5
    //   615: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   620: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   625: aload #7
    //   627: aload_0
    //   628: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   633: aload_0
    //   634: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   639: aload_0
    //   640: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   645: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   650: iload_2
    //   651: iload_3
    //   652: iload #4
    //   654: iload #5
    //   656: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   661: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   666: aload #7
    //   668: aload_0
    //   669: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   674: aload_0
    //   675: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   680: aload_0
    //   681: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   686: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   691: iload_2
    //   692: iload_3
    //   693: iload #4
    //   695: iload #5
    //   697: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   702: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   707: aload #7
    //   709: aload_0
    //   710: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   715: aload_0
    //   716: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   721: aload_0
    //   722: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   727: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   732: iload_2
    //   733: iload_3
    //   734: iload #4
    //   736: iload #5
    //   738: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   743: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   748: aload #7
    //   750: aload_0
    //   751: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   756: aload_0
    //   757: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   762: aload_0
    //   763: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   768: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   773: iload_2
    //   774: iload_3
    //   775: iload #4
    //   777: iload #5
    //   779: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   784: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   789: aload #7
    //   791: aload_0
    //   792: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   797: aload_0
    //   798: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   803: aload_0
    //   804: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   809: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   814: iload_2
    //   815: iload_3
    //   816: iload #4
    //   818: iload #5
    //   820: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   825: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   830: aload #7
    //   832: aload_0
    //   833: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   838: aload_0
    //   839: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   844: aload_0
    //   845: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   850: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   855: iload_2
    //   856: iload_3
    //   857: iload #4
    //   859: iload #5
    //   861: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   866: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   871: aload #7
    //   873: aload_0
    //   874: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   879: aload_0
    //   880: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   885: aload_0
    //   886: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   891: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   896: iload_2
    //   897: iload_3
    //   898: iload #4
    //   900: iload #5
    //   902: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   907: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   912: aload #6
    //   914: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   919: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   922: bipush #23
    //   924: iaload
    //   925: <illegal opcode> 54 : (I)V
    //   930: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   933: iconst_2
    //   934: iaload
    //   935: <illegal opcode> 9 : (Z)V
    //   940: <illegal opcode> 25 : ()V
    //   945: <illegal opcode> 24 : ()V
    //   950: <illegal opcode> 55 : ()V
    //   955: <illegal opcode> 56 : ()V
    //   960: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	961	0	lllllllllllllllIlllIllIIIIIIIIll	Lnet/minecraft/util/math/AxisAlignedBB;
    //   0	961	1	lllllllllllllllIlllIllIIIIIIIIlI	F
    //   0	961	2	lllllllllllllllIlllIllIIIIIIIIIl	I
    //   0	961	3	lllllllllllllllIlllIllIIIIIIIIII	I
    //   0	961	4	lllllllllllllllIlllIlIllllllllll	I
    //   0	961	5	lllllllllllllllIlllIlIlllllllllI	I
    //   98	863	6	lllllllllllllllIlllIlIllllllllIl	Lnet/minecraft/client/renderer/Tessellator;
    //   107	854	7	lllllllllllllllIlllIlIllllllllII	Lnet/minecraft/client/renderer/BufferBuilder;
  }
  
  public static void drawBoundingBoxBlockPos(BlockPos lllllllllllllllIlllIlIlllllllIll, float lllllllllllllllIlllIlIlllllllIlI, int lllllllllllllllIlllIlIlllllllIIl, int lllllllllllllllIlllIlIlllllllIII, int lllllllllllllllIlllIlIllllllIlll, int lllllllllllllllIlllIlIllllllIllI) {
    // Byte code:
    //   0: <illegal opcode> 46 : ()V
    //   5: <illegal opcode> 10 : ()V
    //   10: <illegal opcode> 11 : ()V
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: bipush #21
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: bipush #22
    //   26: iaload
    //   27: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   30: iconst_1
    //   31: iaload
    //   32: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   35: iconst_2
    //   36: iaload
    //   37: <illegal opcode> 47 : (IIII)V
    //   42: <illegal opcode> 8 : ()V
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_1
    //   51: iaload
    //   52: <illegal opcode> 9 : (Z)V
    //   57: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   60: bipush #23
    //   62: iaload
    //   63: <illegal opcode> 48 : (I)V
    //   68: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   71: bipush #24
    //   73: iaload
    //   74: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   77: bipush #25
    //   79: iaload
    //   80: <illegal opcode> 49 : (II)V
    //   85: fload_1
    //   86: <illegal opcode> 50 : (F)V
    //   91: <illegal opcode> 57 : ()Lnet/minecraft/client/Minecraft;
    //   96: astore #6
    //   98: aload_0
    //   99: <illegal opcode> 58 : (Lnet/minecraft/util/math/BlockPos;)I
    //   104: i2d
    //   105: aload #6
    //   107: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   112: <illegal opcode> 60 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   117: dsub
    //   118: dstore #7
    //   120: aload_0
    //   121: <illegal opcode> 61 : (Lnet/minecraft/util/math/BlockPos;)I
    //   126: i2d
    //   127: aload #6
    //   129: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   134: <illegal opcode> 62 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   139: dsub
    //   140: dstore #9
    //   142: aload_0
    //   143: <illegal opcode> 63 : (Lnet/minecraft/util/math/BlockPos;)I
    //   148: i2d
    //   149: aload #6
    //   151: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   156: <illegal opcode> 64 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   161: dsub
    //   162: dstore #11
    //   164: new net/minecraft/util/math/AxisAlignedBB
    //   167: dup
    //   168: dload #7
    //   170: dload #9
    //   172: dload #11
    //   174: dload #7
    //   176: dconst_1
    //   177: dadd
    //   178: dload #9
    //   180: dconst_1
    //   181: dadd
    //   182: dload #11
    //   184: dconst_1
    //   185: dadd
    //   186: invokespecial <init> : (DDDDDD)V
    //   189: astore #13
    //   191: <illegal opcode> 51 : ()Lnet/minecraft/client/renderer/Tessellator;
    //   196: astore #14
    //   198: aload #14
    //   200: <illegal opcode> 52 : (Lnet/minecraft/client/renderer/Tessellator;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   205: astore #15
    //   207: aload #15
    //   209: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   212: bipush #26
    //   214: iaload
    //   215: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   220: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   225: aload #15
    //   227: aload #13
    //   229: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   234: aload #13
    //   236: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   241: aload #13
    //   243: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   248: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   253: iload_2
    //   254: iload_3
    //   255: iload #4
    //   257: iload #5
    //   259: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   264: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   269: aload #15
    //   271: aload #13
    //   273: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   278: aload #13
    //   280: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   285: aload #13
    //   287: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   292: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   297: iload_2
    //   298: iload_3
    //   299: iload #4
    //   301: iload #5
    //   303: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   308: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   313: aload #15
    //   315: aload #13
    //   317: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   322: aload #13
    //   324: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   329: aload #13
    //   331: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   336: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   341: iload_2
    //   342: iload_3
    //   343: iload #4
    //   345: iload #5
    //   347: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   352: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   357: aload #15
    //   359: aload #13
    //   361: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   366: aload #13
    //   368: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   373: aload #13
    //   375: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   380: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   385: iload_2
    //   386: iload_3
    //   387: iload #4
    //   389: iload #5
    //   391: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   396: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   401: aload #15
    //   403: aload #13
    //   405: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   410: aload #13
    //   412: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   417: aload #13
    //   419: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   424: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   429: iload_2
    //   430: iload_3
    //   431: iload #4
    //   433: iload #5
    //   435: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   440: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   445: aload #14
    //   447: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   452: aload #15
    //   454: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   457: bipush #26
    //   459: iaload
    //   460: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   465: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   470: aload #15
    //   472: aload #13
    //   474: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   479: aload #13
    //   481: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   486: aload #13
    //   488: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   493: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   498: iload_2
    //   499: iload_3
    //   500: iload #4
    //   502: iload #5
    //   504: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   509: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   514: aload #15
    //   516: aload #13
    //   518: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   523: aload #13
    //   525: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   530: aload #13
    //   532: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   537: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   542: iload_2
    //   543: iload_3
    //   544: iload #4
    //   546: iload #5
    //   548: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   553: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   558: aload #15
    //   560: aload #13
    //   562: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   567: aload #13
    //   569: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   574: aload #13
    //   576: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   581: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   586: iload_2
    //   587: iload_3
    //   588: iload #4
    //   590: iload #5
    //   592: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   597: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   602: aload #15
    //   604: aload #13
    //   606: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   611: aload #13
    //   613: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   618: aload #13
    //   620: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   625: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   630: iload_2
    //   631: iload_3
    //   632: iload #4
    //   634: iload #5
    //   636: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   641: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   646: aload #15
    //   648: aload #13
    //   650: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   655: aload #13
    //   657: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   662: aload #13
    //   664: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   669: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   674: iload_2
    //   675: iload_3
    //   676: iload #4
    //   678: iload #5
    //   680: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   685: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   690: aload #14
    //   692: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   697: aload #15
    //   699: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   702: iconst_2
    //   703: iaload
    //   704: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   709: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   714: aload #15
    //   716: aload #13
    //   718: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   723: aload #13
    //   725: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   730: aload #13
    //   732: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   737: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   742: iload_2
    //   743: iload_3
    //   744: iload #4
    //   746: iload #5
    //   748: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   753: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   758: aload #15
    //   760: aload #13
    //   762: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   767: aload #13
    //   769: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   774: aload #13
    //   776: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   781: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   786: iload_2
    //   787: iload_3
    //   788: iload #4
    //   790: iload #5
    //   792: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   797: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   802: aload #15
    //   804: aload #13
    //   806: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   811: aload #13
    //   813: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   818: aload #13
    //   820: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   825: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   830: iload_2
    //   831: iload_3
    //   832: iload #4
    //   834: iload #5
    //   836: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   841: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   846: aload #15
    //   848: aload #13
    //   850: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   855: aload #13
    //   857: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   862: aload #13
    //   864: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   869: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   874: iload_2
    //   875: iload_3
    //   876: iload #4
    //   878: iload #5
    //   880: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   885: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   890: aload #15
    //   892: aload #13
    //   894: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   899: aload #13
    //   901: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   906: aload #13
    //   908: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   913: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   918: iload_2
    //   919: iload_3
    //   920: iload #4
    //   922: iload #5
    //   924: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   929: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   934: aload #15
    //   936: aload #13
    //   938: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   943: aload #13
    //   945: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   950: aload #13
    //   952: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   957: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   962: iload_2
    //   963: iload_3
    //   964: iload #4
    //   966: iload #5
    //   968: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   973: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   978: aload #15
    //   980: aload #13
    //   982: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   987: aload #13
    //   989: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   994: aload #13
    //   996: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1001: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1006: iload_2
    //   1007: iload_3
    //   1008: iload #4
    //   1010: iload #5
    //   1012: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1017: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   1022: aload #15
    //   1024: aload #13
    //   1026: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1031: aload #13
    //   1033: <illegal opcode> 45 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1038: aload #13
    //   1040: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   1045: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1050: iload_2
    //   1051: iload_3
    //   1052: iload #4
    //   1054: iload #5
    //   1056: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   1061: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   1066: aload #14
    //   1068: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   1073: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   1076: bipush #23
    //   1078: iaload
    //   1079: <illegal opcode> 54 : (I)V
    //   1084: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   1087: iconst_2
    //   1088: iaload
    //   1089: <illegal opcode> 9 : (Z)V
    //   1094: <illegal opcode> 25 : ()V
    //   1099: <illegal opcode> 24 : ()V
    //   1104: <illegal opcode> 55 : ()V
    //   1109: <illegal opcode> 56 : ()V
    //   1114: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1115	0	lllllllllllllllIlllIlIlllllllIll	Lnet/minecraft/util/math/BlockPos;
    //   0	1115	1	lllllllllllllllIlllIlIlllllllIlI	F
    //   0	1115	2	lllllllllllllllIlllIlIlllllllIIl	I
    //   0	1115	3	lllllllllllllllIlllIlIlllllllIII	I
    //   0	1115	4	lllllllllllllllIlllIlIllllllIlll	I
    //   0	1115	5	lllllllllllllllIlllIlIllllllIllI	I
    //   98	1017	6	lllllllllllllllIlllIlIllllllIlIl	Lnet/minecraft/client/Minecraft;
    //   120	995	7	lllllllllllllllIlllIlIllllllIlII	D
    //   142	973	9	lllllllllllllllIlllIlIllllllIIll	D
    //   164	951	11	lllllllllllllllIlllIlIllllllIIlI	D
    //   191	924	13	lllllllllllllllIlllIlIllllllIIIl	Lnet/minecraft/util/math/AxisAlignedBB;
    //   198	917	14	lllllllllllllllIlllIlIllllllIIII	Lnet/minecraft/client/renderer/Tessellator;
    //   207	908	15	lllllllllllllllIlllIlIlllllIllll	Lnet/minecraft/client/renderer/BufferBuilder;
  }
  
  public static void drawBoundingBoxBottomBlockPos(BlockPos lllllllllllllllIlllIlIlllllIlllI, float lllllllllllllllIlllIlIlllllIllIl, int lllllllllllllllIlllIlIlllllIllII, int lllllllllllllllIlllIlIlllllIlIll, int lllllllllllllllIlllIlIlllllIlIlI, int lllllllllllllllIlllIlIlllllIlIIl) {
    // Byte code:
    //   0: <illegal opcode> 46 : ()V
    //   5: <illegal opcode> 10 : ()V
    //   10: <illegal opcode> 11 : ()V
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: bipush #21
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: bipush #22
    //   26: iaload
    //   27: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   30: iconst_1
    //   31: iaload
    //   32: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   35: iconst_2
    //   36: iaload
    //   37: <illegal opcode> 47 : (IIII)V
    //   42: <illegal opcode> 8 : ()V
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_1
    //   51: iaload
    //   52: <illegal opcode> 9 : (Z)V
    //   57: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   60: bipush #23
    //   62: iaload
    //   63: <illegal opcode> 48 : (I)V
    //   68: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   71: bipush #24
    //   73: iaload
    //   74: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   77: bipush #25
    //   79: iaload
    //   80: <illegal opcode> 49 : (II)V
    //   85: fload_1
    //   86: <illegal opcode> 50 : (F)V
    //   91: <illegal opcode> 57 : ()Lnet/minecraft/client/Minecraft;
    //   96: astore #6
    //   98: aload_0
    //   99: <illegal opcode> 58 : (Lnet/minecraft/util/math/BlockPos;)I
    //   104: i2d
    //   105: aload #6
    //   107: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   112: <illegal opcode> 60 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   117: dsub
    //   118: dstore #7
    //   120: aload_0
    //   121: <illegal opcode> 61 : (Lnet/minecraft/util/math/BlockPos;)I
    //   126: i2d
    //   127: aload #6
    //   129: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   134: <illegal opcode> 62 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   139: dsub
    //   140: dstore #9
    //   142: aload_0
    //   143: <illegal opcode> 63 : (Lnet/minecraft/util/math/BlockPos;)I
    //   148: i2d
    //   149: aload #6
    //   151: <illegal opcode> 59 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/entity/RenderManager;
    //   156: <illegal opcode> 64 : (Lnet/minecraft/client/renderer/entity/RenderManager;)D
    //   161: dsub
    //   162: dstore #11
    //   164: new net/minecraft/util/math/AxisAlignedBB
    //   167: dup
    //   168: dload #7
    //   170: dload #9
    //   172: dload #11
    //   174: dload #7
    //   176: dconst_1
    //   177: dadd
    //   178: dload #9
    //   180: dconst_1
    //   181: dadd
    //   182: dload #11
    //   184: dconst_1
    //   185: dadd
    //   186: invokespecial <init> : (DDDDDD)V
    //   189: astore #13
    //   191: <illegal opcode> 51 : ()Lnet/minecraft/client/renderer/Tessellator;
    //   196: astore #14
    //   198: aload #14
    //   200: <illegal opcode> 52 : (Lnet/minecraft/client/renderer/Tessellator;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   205: astore #15
    //   207: aload #15
    //   209: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   212: bipush #26
    //   214: iaload
    //   215: <illegal opcode> 18 : ()Lnet/minecraft/client/renderer/vertex/VertexFormat;
    //   220: <illegal opcode> 19 : (Lnet/minecraft/client/renderer/BufferBuilder;ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
    //   225: aload #15
    //   227: aload #13
    //   229: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   234: aload #13
    //   236: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   241: aload #13
    //   243: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   248: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   253: iload_2
    //   254: iload_3
    //   255: iload #4
    //   257: iload #5
    //   259: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   264: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   269: aload #15
    //   271: aload #13
    //   273: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   278: aload #13
    //   280: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   285: aload #13
    //   287: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   292: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   297: iload_2
    //   298: iload_3
    //   299: iload #4
    //   301: iload #5
    //   303: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   308: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   313: aload #15
    //   315: aload #13
    //   317: <illegal opcode> 40 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   322: aload #13
    //   324: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   329: aload #13
    //   331: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   336: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   341: iload_2
    //   342: iload_3
    //   343: iload #4
    //   345: iload #5
    //   347: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   352: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   357: aload #15
    //   359: aload #13
    //   361: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   366: aload #13
    //   368: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   373: aload #13
    //   375: <illegal opcode> 43 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   380: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   385: iload_2
    //   386: iload_3
    //   387: iload #4
    //   389: iload #5
    //   391: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   396: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   401: aload #15
    //   403: aload #13
    //   405: <illegal opcode> 44 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   410: aload #13
    //   412: <illegal opcode> 41 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   417: aload #13
    //   419: <illegal opcode> 42 : (Lnet/minecraft/util/math/AxisAlignedBB;)D
    //   424: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   429: iload_2
    //   430: iload_3
    //   431: iload #4
    //   433: iload #5
    //   435: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   440: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   445: aload #14
    //   447: <illegal opcode> 53 : (Lnet/minecraft/client/renderer/Tessellator;)V
    //   452: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   455: bipush #23
    //   457: iaload
    //   458: <illegal opcode> 54 : (I)V
    //   463: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   466: iconst_2
    //   467: iaload
    //   468: <illegal opcode> 9 : (Z)V
    //   473: <illegal opcode> 25 : ()V
    //   478: <illegal opcode> 24 : ()V
    //   483: <illegal opcode> 55 : ()V
    //   488: <illegal opcode> 56 : ()V
    //   493: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	494	0	lllllllllllllllIlllIlIlllllIlllI	Lnet/minecraft/util/math/BlockPos;
    //   0	494	1	lllllllllllllllIlllIlIlllllIllIl	F
    //   0	494	2	lllllllllllllllIlllIlIlllllIllII	I
    //   0	494	3	lllllllllllllllIlllIlIlllllIlIll	I
    //   0	494	4	lllllllllllllllIlllIlIlllllIlIlI	I
    //   0	494	5	lllllllllllllllIlllIlIlllllIlIIl	I
    //   98	396	6	lllllllllllllllIlllIlIlllllIlIII	Lnet/minecraft/client/Minecraft;
    //   120	374	7	lllllllllllllllIlllIlIlllllIIlll	D
    //   142	352	9	lllllllllllllllIlllIlIlllllIIllI	D
    //   164	330	11	lllllllllllllllIlllIlIlllllIIlIl	D
    //   191	303	13	lllllllllllllllIlllIlIlllllIIlII	Lnet/minecraft/util/math/AxisAlignedBB;
    //   198	296	14	lllllllllllllllIlllIlIlllllIIIll	Lnet/minecraft/client/renderer/Tessellator;
    //   207	287	15	lllllllllllllllIlllIlIlllllIIIlI	Lnet/minecraft/client/renderer/BufferBuilder;
  }
  
  public static void drawBoxBottom(BufferBuilder lllllllllllllllIlllIlIlllllIIIIl, float lllllllllllllllIlllIlIlllllIIIII, float lllllllllllllllIlllIlIllllIlllll, float lllllllllllllllIlllIlIllllIllllI, float lllllllllllllllIlllIlIllllIlllIl, float lllllllllllllllIlllIlIllllIlllII, float lllllllllllllllIlllIlIllllIllIll, int lllllllllllllllIlllIlIllllIllIlI, int lllllllllllllllIlllIlIllllIllIIl, int lllllllllllllllIlllIlIllllIllIII, int lllllllllllllllIlllIlIllllIlIlll) {
    // Byte code:
    //   0: aload_0
    //   1: fload_1
    //   2: fload #4
    //   4: fadd
    //   5: f2d
    //   6: fload_2
    //   7: f2d
    //   8: fload_3
    //   9: f2d
    //   10: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   15: iload #7
    //   17: iload #8
    //   19: iload #9
    //   21: iload #10
    //   23: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   28: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   33: aload_0
    //   34: fload_1
    //   35: fload #4
    //   37: fadd
    //   38: f2d
    //   39: fload_2
    //   40: f2d
    //   41: fload_3
    //   42: fload #6
    //   44: fadd
    //   45: f2d
    //   46: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   51: iload #7
    //   53: iload #8
    //   55: iload #9
    //   57: iload #10
    //   59: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   64: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   69: aload_0
    //   70: fload_1
    //   71: f2d
    //   72: fload_2
    //   73: f2d
    //   74: fload_3
    //   75: fload #6
    //   77: fadd
    //   78: f2d
    //   79: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   84: iload #7
    //   86: iload #8
    //   88: iload #9
    //   90: iload #10
    //   92: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   97: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   102: aload_0
    //   103: fload_1
    //   104: f2d
    //   105: fload_2
    //   106: f2d
    //   107: fload_3
    //   108: f2d
    //   109: <illegal opcode> 37 : (Lnet/minecraft/client/renderer/BufferBuilder;DDD)Lnet/minecraft/client/renderer/BufferBuilder;
    //   114: iload #7
    //   116: iload #8
    //   118: iload #9
    //   120: iload #10
    //   122: <illegal opcode> 38 : (Lnet/minecraft/client/renderer/BufferBuilder;IIII)Lnet/minecraft/client/renderer/BufferBuilder;
    //   127: <illegal opcode> 39 : (Lnet/minecraft/client/renderer/BufferBuilder;)V
    //   132: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	133	0	lllllllllllllllIlllIlIlllllIIIIl	Lnet/minecraft/client/renderer/BufferBuilder;
    //   0	133	1	lllllllllllllllIlllIlIlllllIIIII	F
    //   0	133	2	lllllllllllllllIlllIlIllllIlllll	F
    //   0	133	3	lllllllllllllllIlllIlIllllIllllI	F
    //   0	133	4	lllllllllllllllIlllIlIllllIlllIl	F
    //   0	133	5	lllllllllllllllIlllIlIllllIlllII	F
    //   0	133	6	lllllllllllllllIlllIlIllllIllIll	F
    //   0	133	7	lllllllllllllllIlllIlIllllIllIlI	I
    //   0	133	8	lllllllllllllllIlllIlIllllIllIIl	I
    //   0	133	9	lllllllllllllllIlllIlIllllIllIII	I
    //   0	133	10	lllllllllllllllIlllIlIllllIlIlll	I
  }
  
  public static void drawBoxBottom(BlockPos lllllllllllllllIlllIlIllllIlIllI, int lllllllllllllllIlllIlIllllIlIlIl) {
    // Byte code:
    //   0: iload_1
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore_2
    //   14: iload_1
    //   15: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   18: iconst_5
    //   19: iaload
    //   20: iushr
    //   21: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   24: iconst_4
    //   25: iaload
    //   26: iand
    //   27: istore_3
    //   28: iload_1
    //   29: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   32: bipush #6
    //   34: iaload
    //   35: iushr
    //   36: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   39: iconst_4
    //   40: iaload
    //   41: iand
    //   42: istore #4
    //   44: iload_1
    //   45: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   48: iconst_4
    //   49: iaload
    //   50: iand
    //   51: istore #5
    //   53: aload_0
    //   54: iload_3
    //   55: iload #4
    //   57: iload #5
    //   59: iload_2
    //   60: <illegal opcode> 65 : (Lnet/minecraft/util/math/BlockPos;IIII)V
    //   65: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	66	0	lllllllllllllllIlllIlIllllIlIllI	Lnet/minecraft/util/math/BlockPos;
    //   0	66	1	lllllllllllllllIlllIlIllllIlIlIl	I
    //   14	52	2	lllllllllllllllIlllIlIllllIlIlII	I
    //   28	38	3	lllllllllllllllIlllIlIllllIlIIll	I
    //   44	22	4	lllllllllllllllIlllIlIllllIlIIlI	I
    //   53	13	5	lllllllllllllllIlllIlIllllIlIIIl	I
  }
  
  public static void drawBoxBottom(float lllllllllllllllIlllIlIllllIlIIII, float lllllllllllllllIlllIlIllllIIllll, float lllllllllllllllIlllIlIllllIIlllI, int lllllllllllllllIlllIlIllllIIllIl) {
    // Byte code:
    //   0: iload_3
    //   1: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   4: iconst_3
    //   5: iaload
    //   6: iushr
    //   7: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   10: iconst_4
    //   11: iaload
    //   12: iand
    //   13: istore #4
    //   15: iload_3
    //   16: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   19: iconst_5
    //   20: iaload
    //   21: iushr
    //   22: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   25: iconst_4
    //   26: iaload
    //   27: iand
    //   28: istore #5
    //   30: iload_3
    //   31: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   34: bipush #6
    //   36: iaload
    //   37: iushr
    //   38: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   41: iconst_4
    //   42: iaload
    //   43: iand
    //   44: istore #6
    //   46: iload_3
    //   47: getstatic me/stupitdog/bhp/f03.lIlllIlIIIIlll : [I
    //   50: iconst_4
    //   51: iaload
    //   52: iand
    //   53: istore #7
    //   55: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   60: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   65: fload_0
    //   66: fload_1
    //   67: fload_2
    //   68: fconst_1
    //   69: fconst_1
    //   70: fconst_1
    //   71: iload #5
    //   73: iload #6
    //   75: iload #7
    //   77: iload #4
    //   79: <illegal opcode> 66 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIII)V
    //   84: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	85	0	lllllllllllllllIlllIlIllllIlIIII	F
    //   0	85	1	lllllllllllllllIlllIlIllllIIllll	F
    //   0	85	2	lllllllllllllllIlllIlIllllIIlllI	F
    //   0	85	3	lllllllllllllllIlllIlIllllIIllIl	I
    //   15	70	4	lllllllllllllllIlllIlIllllIIllII	I
    //   30	55	5	lllllllllllllllIlllIlIllllIIlIll	I
    //   46	39	6	lllllllllllllllIlllIlIllllIIlIlI	I
    //   55	30	7	lllllllllllllllIlllIlIllllIIlIIl	I
  }
  
  public static void drawBoxBottom(BlockPos lllllllllllllllIlllIlIllllIIlIII, int lllllllllllllllIlllIlIllllIIIlll, int lllllllllllllllIlllIlIllllIIIllI, int lllllllllllllllIlllIlIllllIIIlIl, int lllllllllllllllIlllIlIllllIIIlII) {
    // Byte code:
    //   0: <illegal opcode> 16 : ()Lme/stupitdog/bhp/f03;
    //   5: <illegal opcode> 17 : (Lme/stupitdog/bhp/f03;)Lnet/minecraft/client/renderer/BufferBuilder;
    //   10: aload_0
    //   11: <illegal opcode> 58 : (Lnet/minecraft/util/math/BlockPos;)I
    //   16: i2f
    //   17: aload_0
    //   18: <illegal opcode> 61 : (Lnet/minecraft/util/math/BlockPos;)I
    //   23: i2f
    //   24: aload_0
    //   25: <illegal opcode> 63 : (Lnet/minecraft/util/math/BlockPos;)I
    //   30: i2f
    //   31: fconst_1
    //   32: fconst_1
    //   33: fconst_1
    //   34: iload_1
    //   35: iload_2
    //   36: iload_3
    //   37: iload #4
    //   39: <illegal opcode> 66 : (Lnet/minecraft/client/renderer/BufferBuilder;FFFFFFIIII)V
    //   44: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	45	0	lllllllllllllllIlllIlIllllIIlIII	Lnet/minecraft/util/math/BlockPos;
    //   0	45	1	lllllllllllllllIlllIlIllllIIIlll	I
    //   0	45	2	lllllllllllllllIlllIlIllllIIIllI	I
    //   0	45	3	lllllllllllllllIlllIlIllllIIIlIl	I
    //   0	45	4	lllllllllllllllIlllIlIllllIIIlII	I
  }
  
  static {
    // Byte code:
    //   0: invokestatic lllllIIllIIllIl : ()V
    //   3: invokestatic lllllIIllIIllII : ()V
    //   6: invokestatic lllllIIllIIlIll : ()V
    //   9: invokestatic lllllIIllIIIllI : ()V
    //   12: new me/stupitdog/bhp/f03
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: <illegal opcode> 67 : (Lme/stupitdog/bhp/f03;)V
    //   24: return
  }
  
  private static CallSite llllIIIllIIIIlI(MethodHandles.Lookup lllllllllllllllIlllIlIlllIlllIll, String lllllllllllllllIlllIlIlllIlllIlI, MethodType lllllllllllllllIlllIlIlllIlllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIlIllllIIIIIl = lIllIIllIllIll[Integer.parseInt(lllllllllllllllIlllIlIlllIlllIlI)].split(lIlllIlIIIIIll[lIlllIlIIIIlll[1]]);
      Class<?> lllllllllllllllIlllIlIllllIIIIII = Class.forName(lllllllllllllllIlllIlIllllIIIIIl[lIlllIlIIIIlll[1]]);
      String lllllllllllllllIlllIlIlllIllllll = lllllllllllllllIlllIlIllllIIIIIl[lIlllIlIIIIlll[2]];
      MethodHandle lllllllllllllllIlllIlIlllIlllllI = null;
      int lllllllllllllllIlllIlIlllIllllIl = lllllllllllllllIlllIlIllllIIIIIl[lIlllIlIIIIlll[26]].length();
      if (lllllIIllIIllll(lllllllllllllllIlllIlIlllIllllIl, lIlllIlIIIIlll[7])) {
        MethodType lllllllllllllllIlllIlIllllIIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIllllIIIIIl[lIlllIlIIIIlll[7]], f03.class.getClassLoader());
        if (lllllIIllIlIIII(lllllllllllllllIlllIlIlllIllllIl, lIlllIlIIIIlll[7])) {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findVirtual(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIll);
          "".length();
          if (" ".length() << " ".length() << " ".length() < ((0x37 ^ 0x5E ^ (0xAC ^ 0x8F) << " ".length()) << " ".length() & ((102 + 144 - 173 + 160 ^ (0xE8 ^ 0x8B) << " ".length()) << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findStatic(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIll);
        } 
        "".length();
        if (-" ".length() >= " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIlIllllIIIIlI = lIllIIllIlllII[Integer.parseInt(lllllllllllllllIlllIlIllllIIIIIl[lIlllIlIIIIlll[7]])];
        if (lllllIIllIlIIII(lllllllllllllllIlllIlIlllIllllIl, lIlllIlIIIIlll[26])) {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findGetter(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIlI);
          "".length();
          if (-" ".length() > 0)
            return null; 
        } else if (lllllIIllIlIIII(lllllllllllllllIlllIlIlllIllllIl, lIlllIlIIIIlll[8])) {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findStaticGetter(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIlI);
          "".length();
          if (-"   ".length() > 0)
            return null; 
        } else if (lllllIIllIlIIII(lllllllllllllllIlllIlIlllIllllIl, lIlllIlIIIIlll[14])) {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findSetter(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIlI);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIlIlllIlllllI = lllllllllllllllIlllIlIlllIlllIll.findStaticSetter(lllllllllllllllIlllIlIllllIIIIII, lllllllllllllllIlllIlIlllIllllll, lllllllllllllllIlllIlIllllIIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIlIlllIlllllI);
    } catch (Exception lllllllllllllllIlllIlIlllIllllII) {
      lllllllllllllllIlllIlIlllIllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIllIIIllI() {
    lIllIIllIllIll = new String[lIlllIlIIIIlll[27]];
    lIllIIllIllIll[lIlllIlIIIIlll[28]] = lIlllIlIIIIIll[lIlllIlIIIIlll[2]];
    lIllIIllIllIll[lIlllIlIIIIlll[29]] = lIlllIlIIIIIll[lIlllIlIIIIlll[7]];
    lIllIIllIllIll[lIlllIlIIIIlll[30]] = lIlllIlIIIIIll[lIlllIlIIIIlll[26]];
    lIllIIllIllIll[lIlllIlIIIIlll[31]] = lIlllIlIIIIIll[lIlllIlIIIIlll[8]];
    lIllIIllIllIll[lIlllIlIIIIlll[32]] = lIlllIlIIIIIll[lIlllIlIIIIlll[14]];
    lIllIIllIllIll[lIlllIlIIIIlll[33]] = lIlllIlIIIIIll[lIlllIlIIIIlll[15]];
    lIllIIllIllIll[lIlllIlIIIIlll[11]] = lIlllIlIIIIIll[lIlllIlIIIIlll[34]];
    lIllIIllIllIll[lIlllIlIIIIlll[35]] = lIlllIlIIIIIll[lIlllIlIIIIlll[6]];
    lIllIIllIllIll[lIlllIlIIIIlll[36]] = lIlllIlIIIIIll[lIlllIlIIIIlll[16]];
    lIllIIllIllIll[lIlllIlIIIIlll[15]] = lIlllIlIIIIIll[lIlllIlIIIIlll[17]];
    lIllIIllIllIll[lIlllIlIIIIlll[37]] = lIlllIlIIIIIll[lIlllIlIIIIlll[38]];
    lIllIIllIllIll[lIlllIlIIIIlll[14]] = lIlllIlIIIIIll[lIlllIlIIIIlll[39]];
    lIllIIllIllIll[lIlllIlIIIIlll[40]] = lIlllIlIIIIIll[lIlllIlIIIIlll[32]];
    lIllIIllIllIll[lIlllIlIIIIlll[5]] = lIlllIlIIIIIll[lIlllIlIIIIlll[31]];
    lIllIIllIllIll[lIlllIlIIIIlll[41]] = lIlllIlIIIIIll[lIlllIlIIIIlll[36]];
    lIllIIllIllIll[lIlllIlIIIIlll[42]] = lIlllIlIIIIIll[lIlllIlIIIIlll[5]];
    lIllIIllIllIll[lIlllIlIIIIlll[1]] = lIlllIlIIIIIll[lIlllIlIIIIlll[10]];
    lIllIIllIllIll[lIlllIlIIIIlll[43]] = lIlllIlIIIIIll[lIlllIlIIIIlll[11]];
    lIllIIllIllIll[lIlllIlIIIIlll[13]] = lIlllIlIIIIIll[lIlllIlIIIIlll[29]];
    lIllIIllIllIll[lIlllIlIIIIlll[8]] = lIlllIlIIIIIll[lIlllIlIIIIlll[18]];
    lIllIIllIllIll[lIlllIlIIIIlll[17]] = lIlllIlIIIIIll[lIlllIlIIIIlll[44]];
    lIllIIllIllIll[lIlllIlIIIIlll[45]] = lIlllIlIIIIIll[lIlllIlIIIIlll[46]];
    lIllIIllIllIll[lIlllIlIIIIlll[47]] = lIlllIlIIIIIll[lIlllIlIIIIlll[48]];
    lIllIIllIllIll[lIlllIlIIIIlll[38]] = lIlllIlIIIIIll[lIlllIlIIIIlll[3]];
    lIllIIllIllIll[lIlllIlIIIIlll[49]] = lIlllIlIIIIIll[lIlllIlIIIIlll[50]];
    lIllIIllIllIll[lIlllIlIIIIlll[51]] = lIlllIlIIIIIll[lIlllIlIIIIlll[52]];
    lIllIIllIllIll[lIlllIlIIIIlll[53]] = lIlllIlIIIIIll[lIlllIlIIIIlll[42]];
    lIllIIllIllIll[lIlllIlIIIIlll[3]] = lIlllIlIIIIIll[lIlllIlIIIIlll[54]];
    lIllIIllIllIll[lIlllIlIIIIlll[48]] = lIlllIlIIIIIll[lIlllIlIIIIlll[28]];
    lIllIIllIllIll[lIlllIlIIIIlll[55]] = lIlllIlIIIIIll[lIlllIlIIIIlll[56]];
    lIllIIllIllIll[lIlllIlIIIIlll[52]] = lIlllIlIIIIIll[lIlllIlIIIIlll[51]];
    lIllIIllIllIll[lIlllIlIIIIlll[39]] = lIlllIlIIIIIll[lIlllIlIIIIlll[9]];
    lIllIIllIllIll[lIlllIlIIIIlll[34]] = lIlllIlIIIIIll[lIlllIlIIIIlll[12]];
    lIllIIllIllIll[lIlllIlIIIIlll[57]] = lIlllIlIIIIIll[lIlllIlIIIIlll[13]];
    lIllIIllIllIll[lIlllIlIIIIlll[58]] = lIlllIlIIIIIll[lIlllIlIIIIlll[35]];
    lIllIIllIllIll[lIlllIlIIIIlll[19]] = lIlllIlIIIIIll[lIlllIlIIIIlll[19]];
    lIllIIllIllIll[lIlllIlIIIIlll[12]] = lIlllIlIIIIIll[lIlllIlIIIIlll[59]];
    lIllIIllIllIll[lIlllIlIIIIlll[60]] = lIlllIlIIIIIll[lIlllIlIIIIlll[58]];
    lIllIIllIllIll[lIlllIlIIIIlll[20]] = lIlllIlIIIIIll[lIlllIlIIIIlll[49]];
    lIllIIllIllIll[lIlllIlIIIIlll[44]] = lIlllIlIIIIIll[lIlllIlIIIIlll[20]];
    lIllIIllIllIll[lIlllIlIIIIlll[61]] = lIlllIlIIIIIll[lIlllIlIIIIlll[55]];
    lIllIIllIllIll[lIlllIlIIIIlll[62]] = lIlllIlIIIIIll[lIlllIlIIIIlll[63]];
    lIllIIllIllIll[lIlllIlIIIIlll[54]] = lIlllIlIIIIIll[lIlllIlIIIIlll[40]];
    lIllIIllIllIll[lIlllIlIIIIlll[7]] = lIlllIlIIIIIll[lIlllIlIIIIlll[64]];
    lIllIIllIllIll[lIlllIlIIIIlll[26]] = lIlllIlIIIIIll[lIlllIlIIIIlll[65]];
    lIllIIllIllIll[lIlllIlIIIIlll[46]] = lIlllIlIIIIIll[lIlllIlIIIIlll[66]];
    lIllIIllIllIll[lIlllIlIIIIlll[67]] = lIlllIlIIIIIll[lIlllIlIIIIlll[37]];
    lIllIIllIllIll[lIlllIlIIIIlll[64]] = lIlllIlIIIIIll[lIlllIlIIIIlll[33]];
    lIllIIllIllIll[lIlllIlIIIIlll[68]] = lIlllIlIIIIIll[lIlllIlIIIIlll[47]];
    lIllIIllIllIll[lIlllIlIIIIlll[10]] = lIlllIlIIIIIll[lIlllIlIIIIlll[69]];
    lIllIIllIllIll[lIlllIlIIIIlll[56]] = lIlllIlIIIIIll[lIlllIlIIIIlll[61]];
    lIllIIllIllIll[lIlllIlIIIIlll[6]] = lIlllIlIIIIIll[lIlllIlIIIIlll[41]];
    lIllIIllIllIll[lIlllIlIIIIlll[70]] = lIlllIlIIIIIll[lIlllIlIIIIlll[30]];
    lIllIIllIllIll[lIlllIlIIIIlll[71]] = lIlllIlIIIIIll[lIlllIlIIIIlll[71]];
    lIllIIllIllIll[lIlllIlIIIIlll[72]] = lIlllIlIIIIIll[lIlllIlIIIIlll[53]];
    lIllIIllIllIll[lIlllIlIIIIlll[9]] = lIlllIlIIIIIll[lIlllIlIIIIlll[57]];
    lIllIIllIllIll[lIlllIlIIIIlll[73]] = lIlllIlIIIIIll[lIlllIlIIIIlll[67]];
    lIllIIllIllIll[lIlllIlIIIIlll[63]] = lIlllIlIIIIIll[lIlllIlIIIIlll[74]];
    lIllIIllIllIll[lIlllIlIIIIlll[65]] = lIlllIlIIIIIll[lIlllIlIIIIlll[70]];
    lIllIIllIllIll[lIlllIlIIIIlll[69]] = lIlllIlIIIIIll[lIlllIlIIIIlll[62]];
    lIllIIllIllIll[lIlllIlIIIIlll[18]] = lIlllIlIIIIIll[lIlllIlIIIIlll[73]];
    lIllIIllIllIll[lIlllIlIIIIlll[75]] = lIlllIlIIIIIll[lIlllIlIIIIlll[72]];
    lIllIIllIllIll[lIlllIlIIIIlll[16]] = lIlllIlIIIIIll[lIlllIlIIIIlll[43]];
    lIllIIllIllIll[lIlllIlIIIIlll[50]] = lIlllIlIIIIIll[lIlllIlIIIIlll[68]];
    lIllIIllIllIll[lIlllIlIIIIlll[66]] = lIlllIlIIIIIll[lIlllIlIIIIlll[75]];
    lIllIIllIllIll[lIlllIlIIIIlll[74]] = lIlllIlIIIIIll[lIlllIlIIIIlll[45]];
    lIllIIllIllIll[lIlllIlIIIIlll[59]] = lIlllIlIIIIIll[lIlllIlIIIIlll[60]];
    lIllIIllIllIll[lIlllIlIIIIlll[2]] = lIlllIlIIIIIll[lIlllIlIIIIlll[27]];
    lIllIIllIlllII = new Class[lIlllIlIIIIlll[15]];
    lIllIIllIlllII[lIlllIlIIIIlll[1]] = GlStateManager.SourceFactor.class;
    lIllIIllIlllII[lIlllIlIIIIlll[8]] = double.class;
    lIllIIllIlllII[lIlllIlIIIIlll[7]] = f03.class;
    lIllIIllIlllII[lIlllIlIIIIlll[14]] = int.class;
    lIllIIllIlllII[lIlllIlIIIIlll[2]] = GlStateManager.DestFactor.class;
    lIllIIllIlllII[lIlllIlIIIIlll[26]] = VertexFormat.class;
  }
  
  private static void lllllIIllIIlIll() {
    lIlllIlIIIIIll = new String[lIlllIlIIIIlll[76]];
    lIlllIlIIIIIll[lIlllIlIIIIlll[1]] = lllllIIllIIIlll(lIlllIlIIIIllI[lIlllIlIIIIlll[1]], lIlllIlIIIIllI[lIlllIlIIIIlll[2]]);
    lIlllIlIIIIIll[lIlllIlIIIIlll[2]] = lllllIIllIIlIII(lIlllIlIIIIllI[lIlllIlIIIIlll[7]], lIlllIlIIIIllI[lIlllIlIIIIlll[26]]);
    lIlllIlIIIIIll[lIlllIlIIIIlll[7]] = lllllIIllIIlIII(lIlllIlIIIIllI[lIlllIlIIIIlll[8]], lIlllIlIIIIllI[lIlllIlIIIIlll[14]]);
    lIlllIlIIIIIll[lIlllIlIIIIlll[26]] = lllllIIllIIIlll(lIlllIlIIIIllI[lIlllIlIIIIlll[15]], lIlllIlIIIIllI[lIlllIlIIIIlll[34]]);
    lIlllIlIIIIIll[lIlllIlIIIIlll[8]] = lllllIIllIIlIIl(lIlllIlIIIIllI[lIlllIlIIIIlll[6]], lIlllIlIIIIllI[lIlllIlIIIIlll[16]]);
    lIlllIlIIIIIll[lIlllIlIIIIlll[14]] = lllllIIllIIIlll("kyr6j6AmQNEYN8rQQhsJ317F7+SXy7XLwEQceeqkiM617OufoJZYkcVViJMOO4i62JDjWwi/vyeElUArzb90sXbB05R7kDDz", "TEsuA");
    lIlllIlIIIIIll[lIlllIlIIIIlll[15]] = lllllIIllIIlIIl("FRAybCoNCDIuaBUSMCwhFkwSDndLWDIuAxQDNy4jQEocaxBAQg==", "zbUBF");
    lIlllIlIIIIIll[lIlllIlIIIIlll[34]] = lllllIIllIIlIIl("GTEhZjUeOjArKhYyIWY7Gz0wJixZJjAmPBImMDp2ATEnPD0PehEtPhYhOTwOEiYhLSAxOyclOQMnby4xEjgxF2lPZWJ4bigyb3tiV3R1aA==", "wTUHX");
    lIlllIlIIIIIll[lIlllIlIIIIlll[6]] = lllllIIllIIlIIl("LxAHSwsoGxYGFCATB0sTNRwfSwsgARtLMCQWQAFcJxwWCQIeQkFRUnkqEV9Se1VTRQ==", "Ausef");
    lIlllIlIIIIIll[lIlllIlIIIIlll[16]] = lllllIIllIIIlll("xOl8eFS7oorohszIFd6Uwj8hzP372PI5upKN6bf0Pv2xdL0AT3khLFxl+hRfFq7NXwR0De695l9rHog/PKQV/4c34ex/Dx9y", "OYeRs");
    lIlllIlIIIIIll[lIlllIlIIIIlll[17]] = lllllIIllIIIlll("W5LSQWExLowh081f9y4G3lmECddCbU8q3OchKxOmZ3HhcTpayTSobDW2CnlIgf4ZvMJFgo44vFAQ+5grJ2Xxe0wN4ksyv1jxjyxNCIhtVSsX6fQr9i+47VkA3CvTGkhT80d+ztaFkhQoII36b6qi6f+Nh2PSjS4PBSH76Dd4bSgK3zP7j+CSK1AsIlYR+ANaJRvXDbcKv13hcTpayTSobFP4s+PaIsPRZYIWTVuPhVmu7a2stCE01jW/jIGFWEkO5SBAgFz4rU6OkPswmQNvE/aC6gvLp/d+37GMd+M1ksONMwivMwwpCdnqO3Fi1Q0nY2AueCykV/qYjO2YVi4nxImZw/fkUoc9Qf+KmCAGfA7P0M/vAjVRqj/o2sR+eQg67Rn6MhdqmNKJOf6yWZdpJQ==", "WKvqm");
    lIlllIlIIIIIll[lIlllIlIIIIlll[38]] = lllllIIllIIlIII("avMUrdV/cNeofnOPwS+S59sScVax5KcEGhoyggn3VqvRokf9BdhLofOUgJNzsL2ZFMU0k6fthSdhr0VylltPQ6t2xA7zAjRq", "afdHT");
    lIlllIlIIIIIll[lIlllIlIIIIlll[39]] = lllllIIllIIlIII("ZgpdtFjnbcXCNKAt87VcaTDP/O5Dxz9kmm9eb+eEw9HGdBef5Vc8cPXpLZeIcVE5fz/KdXfGwx/t1nBjCE7L3yGYHKBLpCiZ", "VxAXF");
    lIlllIlIIIIIll[lIlllIlIIIIlll[32]] = lllllIIllIIIlll("oGjHN8K4zAdNS3dDHtiTSWaQQcm7mVimZZw+WomTgqwq2FRJ5r3ih4hIM7BnI9ZpaFJl9Jm6rS1YzpWaxhphfw==", "qXFrb");
    lIlllIlIIIIIll[lIlllIlIIIIlll[31]] = lllllIIllIIlIIl("CxJiKQ4TByUuHgkQYjgSFlkqaklcPgIJLic5Dx9AVE1selpG", "fwLZz");
    lIlllIlIIIIIll[lIlllIlIIIIlll[36]] = lllllIIllIIIlll("WoysqCqPYszZvOCtagynIybC/Zelqx+5WSfcq/byNpeEN5NB4syPqFlAiVLIxbuEYVyjQYNWKFv01V9zS9NQ9xXPkzIJoIAOIxoAC6nQd7EcMOlMD1Rhk44fcZn1CV81XKdqdzgjkXDZGwszrDBzjg==", "aJlYl");
    lIlllIlIIIIIll[lIlllIlIIIIlll[5]] = lllllIIllIIlIII("cJIKVNpgKQjh6zKSQGme7ijANAN4+0DzhI5OJ0AqxRa3EaB6m6E7/Nf88QFtlphSTLsL2j6WN/0+4wKX6BuMS/I7L+iXes/pcF0ux4UJllM01XEunalJkkOaZAMkOMusY6Pme+zGBasy11jH/EEiGQQo3pZf+IYMeDWAFuC/9ys=", "GLiYB");
    lIlllIlIIIIIll[lIlllIlIIIIlll[10]] = lllllIIllIIlIIl("LgZ2PRU2EzE6BSwEdiwJM00+flJ5EyorESIRPQkteUtxGFtj", "CcXNa");
    lIlllIlIIIIIll[lIlllIlIIIIlll[11]] = lllllIIllIIlIIl("PSEdWjw6KgwXIzIiHVokJy0FWjwyMAFaEz8rCh8BPDdTEjg2KA0rYGRzUEJgDCdTQWtzZEk=", "SDitQ");
    lIlllIlIIIIIll[lIlllIlIIIIlll[29]] = lllllIIllIIlIII("0w8NrkCOqdvySo1+BtrIZ1UOpwFCK8WPv44sy31o9w/NNOTWXRr0TWNDR1tdrVoV1W1jGt4Aku8=", "OCzqx");
    lIlllIlIIIIIll[lIlllIlIIIIlll[18]] = lllllIIllIIlIII("+60g+NPOdrhKvoRABIbEkV50zmaCrbxLLJXtPhaiNz4nppvnClZhjBDpyFuz1gbfrqizVxNSG7iYXhuhQhziGO35h2PwtTqJ", "wxfZB");
    lIlllIlIIIIIll[lIlllIlIIIIlll[44]] = lllllIIllIIlIII("bttDSu+ISsbbiSN/Z+OFOODla9rZMzNnSnl1V0vCaMHW9xX3P9yii0r81Y+2Di+vAKIdHf+3bXPmbQzVdo0pNxJ2vmw17c8A", "wrxPY");
    lIlllIlIIIIIll[lIlllIlIIIIlll[46]] = lllllIIllIIlIIl("GRJWHToBBxEaKhsQVgwmBFkeXn1OEwoPOTYYACwhAAMXA3RcOxYLOlsaEQArFwUZCDpbFBQHKxoDVxwrGhMdHCsGWDobKBISCiw7HRscCzxPMT4oCDIxMScHPV4uVG4=", "twxnN");
    lIlllIlIIIIIll[lIlllIlIIIIlll[48]] = lllllIIllIIIlll("9XBXbm/9TsumwxemRvsRDUMRlfTXmPqnYQMmy2EnvzBAAAnsBE6unQ==", "PNZbF");
    lIlllIlIIIIIll[lIlllIlIIIIlll[3]] = lllllIIllIIlIIl("CyMXbSYMKAYgOQQgF20oCS8GLT9LNAYtLwA0BjFlIiowNyoRIy4iJQQhBjFxAzMNIBRUcVpzclIZCnljTBBZYw==", "eFcCK");
    lIlllIlIIIIIll[lIlllIlIIIIlll[50]] = lllllIIllIIlIIl("LAMsbAsrCD0hFCMALGwFLg89LBJsFD0sAicUPTBIABM+JAMwJC0rCiYDKngANwg7HVd6V251Ux0CYmpPFFx4Yg==", "BfXBf");
    lIlllIlIIIIIll[lIlllIlIIIIlll[52]] = lllllIIllIIlIIl("Ggo4QSYdASkMORUJOEE+AAYgQSYVGyRBCRgALwQbGxx2CT4aDBNefENWeVcUGlVkRgJOT2w=", "toLoK");
    lIlllIlIIIIIll[lIlllIlIIIIlll[42]] = lllllIIllIIlIII("OwEZiz6b81rwshT86E3Ux958EnPFw/5f8xew87JTt0dlVwnJoYWTnUupkX6v99XKaaoygZDsSj/2NDRv62sJHkzEDyeswNt9", "uvgFM");
    lIlllIlIIIIIll[lIlllIlIIIIlll[54]] = lllllIIllIIlIIl("IAoRbzgnAQAiJy8JEW82IgYALyFgHQAvMSsdADN7CQM2NTQ6CiggOy8IADNvKBoLIgp/WFxxbHYwEnt9ZzlfYQ==", "NoeAU");
    lIlllIlIIIIIll[lIlllIlIIIIlll[28]] = lllllIIllIIIlll("8yRHVrDGrhDlx2P+gkg0wYyfXxCu5vpNlsJFIcKbfJ50lXnhpQJrrTjGarbe4F7nSL7vOHZKLc4972pHW+t7gNawM9cqrBDm", "hWuBx");
    lIlllIlIIIIIll[lIlllIlIIIIlll[56]] = lllllIIllIIlIII("uRj0FDhbWXExEqjIc+NEuKtZ4XaQRUNpMGXPfJlqnsp1i2rg6AdqGnzs+NjhBnbzSIuxGkh6KjHSsr6AjVMaGw==", "vkDKn");
    lIlllIlIIIIIll[lIlllIlIIIIlll[51]] = lllllIIllIIIlll("3p/I16a6KGL/cPXmJ6qaXfEn5qLlEZIy3KAL6L4HDmUuFdSgeu1yaFBBoagp5BuW", "GUDUj");
    lIlllIlIIIIIll[lIlllIlIIIIlll[9]] = lllllIIllIIlIIl("HR8nWjsaFDYXJBIcJ1o1HxM2GiJdCDYaMhYINgZ4NBYAADcHHx4VOBIdNgZsFQ89FwlCTWpFYkMlNU5+WixpVA==", "szStV");
    lIlllIlIIIIIll[lIlllIlIIIIlll[12]] = lllllIIllIIIlll("vWC/f00nuo+EFulcQkOvnSPoDR10QU9Zo/W/jyvrvZ6fvm71f4zXD+Y2kkU79mwrbfIiFBVNxbCtDHBmjOD6o2nPlw48OC2B", "bIRQg");
    lIlllIlIIIIIll[lIlllIlIIIIlll[13]] = lllllIIllIIlIII("Us99kL1q1B26xtGD+mhUZNWABaghr5WgMhWAapCQRkl43Qiw+qsSim7joGNB2UAhFpql7KIKA5Kwtinv37nD5kmEQdEvU50y", "xejCn");
    lIlllIlIIIIIll[lIlllIlIIIIlll[35]] = lllllIIllIIIlll("yLJw5oNiXHBf7mMBPObSSxBkucN0yzMEKfQBM4cMSUMp8KL3gTj9aYQAGpWZcpg5drhV1ojvvSzQg5/gYmpsnTw8hCs6va/94mOA3aQhMOMeKOfWBNPVlgIGZDvfHVogtP2FMXbxjaw38OiGsuoLsLmWgW0xXFCa", "QFwXm");
    lIlllIlIIIIIll[lIlllIlIIIIlll[19]] = lllllIIllIIlIII("gTmc1vK1+tHPFtuBNyvIzf452xUQF491RT75w8hLNmGXIeyaWQowGkNhA/zPNn6jqRNooR1C6R0=", "evJlU");
    lIlllIlIIIIIll[lIlllIlIIIIlll[59]] = lllllIIllIIlIIl("Dy8QVB0IJAEZAgAsEFQFFSMIVB0APgxUMg0lBxEgDjleHAUPKTtLR1ZzUUgvEXBMUzlbakQ=", "aJdzp");
    lIlllIlIIIIIll[lIlllIlIIIIlll[58]] = lllllIIllIIIlll("ZjzlbFgUr8QjlxvwTq/BTIawS2EH/18aDVby64W0/3c/6JO5jMUG2A==", "LsYXr");
    lIlllIlIIIIIll[lIlllIlIIIIlll[49]] = lllllIIllIIlIIl("PRcdSwo6HAwGFTIUHUsSJxsFSwoyBgFLJisbGiQLOhUHAAMRMFMDDjYeDTpQYUFaUzg3SF1fR3NS", "Srieg");
    lIlllIlIIIIIll[lIlllIlIIIIlll[20]] = lllllIIllIIlIII("ML9jDv1WVyicWSqCJb85Dv/g4fWmHdj5ZFK+qXnDq7oAfF2h4+PQGQ==", "upbNm");
    lIlllIlIIIIIll[lIlllIlIIIIlll[55]] = lllllIIllIIlIII("TPbwQh+xHPqP/tC51bfA4S4GaQDaT9629pfqeo6L0eUx/kwjZcqFLFRlKGTzNXXZkMLRprjDnqbpyrKyhVCjXwLc3KgnFlovN4+MNrAWP3MXLXoQz9QgUvBWlb8uGqIHM3gZS9P5TPk=", "Utwck");
    lIlllIlIIIIIll[lIlllIlIIIIlll[63]] = lllllIIllIIlIII("T8KOiwRA4zJPL4iLP5Pq0scFWiOFTUbmNkqQ9oNLBFR2CKKGKcyHw7KAft8kRzClRaXVSy5vHSjHkYrnKyvPDJfo+mQzxYud", "yQJYE");
    lIlllIlIIIIIll[lIlllIlIIIIlll[40]] = lllllIIllIIlIIl("AwpaERcbHx0WBwEIWgALHkESUlBUCwYDFCwADFhLIgERFkwDBhoHABwOEhZMGxsdDkwDDgAKTCwDGwEIPgAHWSonJj0rSjhVVA==", "notbc");
    lIlllIlIIIIIll[lIlllIlIIIIlll[64]] = lllllIIllIIIlll("4p0naK/IJl63mz3iUnBdb6vjLXEqgsDMJ51BkPJlh8Id2K1lAG1rQCOKauYX992DoszEegh1uO5aPuiGPGaEPR1X9H7bvFkauXrbFdj3xq4=", "xttsU");
    lIlllIlIIIIIll[lIlllIlIIIIlll[65]] = lllllIIllIIIlll("zZL+jJGh8YhK5TaGuOs+YV9NNpR4DSiswbZqG9pmHu2vhffm99EJU8Pbda/sfWPAN+u6enZ2KyjZdhAu27OtSGkclMeuW0DSxlaL2YhKiTta+513EmwFOg==", "yulvx");
    lIlllIlIIIIIll[lIlllIlIIIIlll[66]] = lllllIIllIIlIIl("IBB0Iyc4BTMkNyISdDI7PVs8YGB3Ey8+MBJCYmNrfCo7antkI2Bwcw==", "MuZPS");
    lIlllIlIIIIIll[lIlllIlIIIIlll[37]] = lllllIIllIIlIIl("HAoHawkbARYmFhMJB2sHHgYWKxBcIhorAREdEiMQSAkGKwctWEJxVUIwC39MWyMdIBBdAhorAREdEiMQXQwfLAEcG1wIDRwKEDcFFBtIf0Q=", "rosEd");
    lIlllIlIIIIIll[lIlllIlIIIIlll[33]] = lllllIIllIIlIIl("GAcyVycfDCMaOBcEMlc/AgsqVycXFi5XCw4LNTgmHwUoHC40IHwfIxMOIiZ9RFFySRUXWHJDalZC", "vbFyJ");
    lIlllIlIIIIIll[lIlllIlIIIIlll[47]] = lllllIIllIIIlll("ZM9y5IVkj9ItbaLrZ/RpVSOvk9rloxGLozCjva6FHSjh86w25ErYohLFhI8Qz4G/IlwphefaUGGLynkC/dGjaEXa+shC7pKn", "OVCwW");
    lIlllIlIIIIIll[lIlllIlIIIIlll[69]] = lllllIIllIIIlll("xe7J6YCL3p/4ZMxvESokXceTV0GsitxWvb4de9PINQKFAdz+LAjFa4cUHRCdMa/YSA2OhTRXtf/ZDtx+gKkREj02i7VQ6NEhFR1WLm7UROGhGR6zEDDBCQ==", "qquxZ");
    lIlllIlIIIIIll[lIlllIlIIIIlll[61]] = lllllIIllIIlIIl("IQldPR05HBo6DSMLXSwBPEIVflp2CAEvHg4DC3RBAAIWOkYhBR0rCj4NFTpGLwAaKwc4QwErBygJASsbYy4GKA8pHjE7ACAIFjxSCio1CC8KJToHIAVFJXRJ", "LlsNi");
    lIlllIlIIIIIll[lIlllIlIIIIlll[41]] = lllllIIllIIlIII("xKeaWAbzbo99/t94nztnWOYTaW0U7a/i7orE19po6tfvHA39Lbc0vyu2u7BNR3hAcnakl9AmHGDNDnkvboHn86UT5E+Ow7A0", "XYxwf");
    lIlllIlIIIIIll[lIlllIlIIIIlll[30]] = lllllIIllIIIlll("uU7QT3hgX+qF3lriPTSvc1Gx37zT4d9k/XwL/Wx6Yh3K+Y5Z7uNMPYHYigCCyYV7tmqGol1rLB6Ph+udg13Sm7NjAtuYPZzwn8/reAlzkmWcppZlNjwxBFb3FakT/elBIU37s2anWAA=", "YIhvk");
    lIlllIlIIIIIll[lIlllIlIIIIlll[71]] = lllllIIllIIlIII("18KjKMEcK2bqNcULmzsIjcaOkCzZ+4tgCDMZRjVq70RtWjnTZ//d5w==", "XKnuC");
    lIlllIlIIIIIll[lIlllIlIIIIlll[53]] = lllllIIllIIIlll("4zYbnxjx1uUC3vU2PVO86UijDghFDA884r6/eRlL/fcR+VlITXi7/9bq37ARU9t5tHSjA+kFBYgEtqzUyXWZQbfVob8c/9Fh", "ciiLb");
    lIlllIlIIIIIll[lIlllIlIIIIlll[57]] = lllllIIllIIlIII("nwk7VSerwwTisrm0yC6NYl6AFriyjcFsL0qzFVg1FaohqMsglZ6umpdZxjzxJAPRDBrpeegfzSk=", "oGMiU");
    lIlllIlIIIIIll[lIlllIlIIIIlll[67]] = lllllIIllIIIlll("exn/zKgSfNbmQbQm697FjBSAyZIyTYn7C1g3i0Nu4v22StaCtQS3O0JmyvYLqJ15ilbXvXzNj3A=", "jDDvK");
    lIlllIlIIIIIll[lIlllIlIIIIlll[74]] = lllllIIllIIlIIl("Bh8ZQBkBFAgNBgkcGUABHBMBQBkJDgVANRATHi8YAR0DCxAqOFcIHQ0WCTFDWkleVysLQFlUVEha", "hzmnt");
    lIlllIlIIIIIll[lIlllIlIIIIlll[70]] = lllllIIllIIIlll("plVAmpKmGCnIu2P2ELovGh24TjtfmGps/YJo+oG0ut4Mc4IuN/U9u/PFuo9O+264PgTuN2zApAIEHjI9VqbPMA==", "IuDsD");
    lIlllIlIIIIIll[lIlllIlIIIIlll[62]] = lllllIIllIIIlll("WYbT4HosRGpY6tQSc3ebbNgG2PX5BZVc078klsX1ADSCzquj5MFbCWcMgIqMNZFD", "SWuPD");
    lIlllIlIIIIIll[lIlllIlIIIIlll[73]] = lllllIIllIIIlll("5P3SghFzgH1XuagDniRPhyX3jQryOVXn6EB1GaDkR3QkCye8rgaX1Q==", "PmsYx");
    lIlllIlIIIIIll[lIlllIlIIIIlll[72]] = lllllIIllIIlIIl("FCNYOh0MNh89DRYhWCsBCWgQeVpDIgQoHjspDgsGDTIZJFNRChgsHVYrHycMGjQXLx1WMwIgBVYrFz0BVgQaJgoSFhk6UjAPPwBAL3xW", "yFvIi");
    lIlllIlIIIIIll[lIlllIlIIIIlll[43]] = lllllIIllIIIlll("43PwUa9G9mFZS/iwY8nJ8+atxCgRaoJ35FR+A5Q4zqafG1y96Lgb4RQsffUWD6zZLubM+rHrQXpV2RVTfB6tA7PklXF+/u+i", "TwNMq");
    lIlllIlIIIIIll[lIlllIlIIIIlll[68]] = lllllIIllIIlIII("lla4avlkXjCbY+hWkdKxcIx07T06n6zUzuRW/GOJjuV10h/RBcatI85QARrDcZdbOMuEGsyA5cIdWedM2fWPIfB6qnCPE6ja", "enCeU");
    lIlllIlIIIIIll[lIlllIlIIIIlll[75]] = lllllIIllIIlIII("7tNjIJPggjgWC070Tmo3FCcwVihnP2TqU9mP8zX0nrx6hHZCOdF4rNac8oMgC+c59/yiYUsdesVPXpMjTaUN+iFX+CLHQPB8", "yZEzq");
    lIlllIlIIIIIll[lIlllIlIIIIlll[45]] = lllllIIllIIIlll("+mD2deaoQWe4v9BpLildWmR6nrxr7HkV9iNM4zW3lHhIRWNeSl0ENl7O8UEWV+i8eZMfduq2uXw=", "tdRpZ");
    lIlllIlIIIIIll[lIlllIlIIIIlll[60]] = lllllIIllIIIlll("T1Bs+9sJJu++zLWZk9KFEHHsXL/vww1wTV39idErxnDLjAsW29jVhhQxxNeCK33ky8G6cs8A2bESc2cCveuxY7bphdDxIpMECjPFLQUJemFDJfhwOQSX2AxgKeyM3Tvpy4wLFtvY1YarbG7anQmZUQ==", "EFqZk");
    lIlllIlIIIIIll[lIlllIlIIIIlll[27]] = lllllIIllIIIlll("GYJ+7upnZFrT+h7NTsCfUv0ZUVE3KdyvZ46/PC9ZXJ0fo/y2ZkNOhA==", "fNjYC");
    lIlllIlIIIIllI = null;
  }
  
  private static void lllllIIllIIllII() {
    String str = (new Exception()).getStackTrace()[lIlllIlIIIIlll[1]].getFileName();
    lIlllIlIIIIllI = str.substring(str.indexOf("ä") + lIlllIlIIIIlll[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllIIllIIlIII(String lllllllllllllllIlllIlIlllIllIlIl, String lllllllllllllllIlllIlIlllIllIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlllIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlllIllIlII.getBytes(StandardCharsets.UTF_8)), lIlllIlIIIIlll[6]), "DES");
      Cipher lllllllllllllllIlllIlIlllIllIlll = Cipher.getInstance("DES");
      lllllllllllllllIlllIlIlllIllIlll.init(lIlllIlIIIIlll[7], lllllllllllllllIlllIlIlllIlllIII);
      return new String(lllllllllllllllIlllIlIlllIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlllIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlllIllIllI) {
      lllllllllllllllIlllIlIlllIllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllIIllIIlIIl(String lllllllllllllllIlllIlIlllIllIIlI, String lllllllllllllllIlllIlIlllIllIIIl) {
    lllllllllllllllIlllIlIlllIllIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIlllIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIlIlllIllIIII = new StringBuilder();
    char[] lllllllllllllllIlllIlIlllIlIllll = lllllllllllllllIlllIlIlllIllIIIl.toCharArray();
    int lllllllllllllllIlllIlIlllIlIlllI = lIlllIlIIIIlll[1];
    char[] arrayOfChar1 = lllllllllllllllIlllIlIlllIllIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIlIIIIlll[1];
    while (lllllIIllIlIIIl(j, i)) {
      char lllllllllllllllIlllIlIlllIllIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIlIlllIlIlllI++;
      j++;
      "".length();
      if ((((0x96 ^ 0x87) << "   ".length() ^ 94 + 25 - -30 + 2) & (0x78 ^ 0x7F ^ "   ".length() << "   ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIlIlllIllIIII);
  }
  
  private static String lllllIIllIIIlll(String lllllllllllllllIlllIlIlllIlIlIlI, String lllllllllllllllIlllIlIlllIlIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIlIlllIlIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlllIlIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlIlllIlIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlIlllIlIllII.init(lIlllIlIIIIlll[7], lllllllllllllllIlllIlIlllIlIllIl);
      return new String(lllllllllllllllIlllIlIlllIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlllIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIlIlllIlIlIll) {
      lllllllllllllllIlllIlIlllIlIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllIIllIIllIl() {
    lIlllIlIIIIlll = new int[77];
    lIlllIlIIIIlll[0] = " ".length() << (0xBB ^ 0xAE);
    lIlllIlIIIIlll[1] = "   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ 0xFFFFFFFF);
    lIlllIlIIIIlll[2] = " ".length();
    lIlllIlIIIIlll[3] = "   ".length() << "   ".length();
    lIlllIlIIIIlll[4] = ("   ".length() << " ".length()) + 145 + 141 - 187 + 56 - ((0x6D ^ 0x7E) << " ".length()) + ((0x45 ^ 0x64) << " ".length() << " ".length());
    lIlllIlIIIIlll[5] = " ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIIIlll[6] = " ".length() << "   ".length();
    lIlllIlIIIIlll[7] = " ".length() << " ".length();
    lIlllIlIIIIlll[8] = " ".length() << " ".length() << " ".length();
    lIlllIlIIIIlll[9] = " ".length() << (115 + 65 - 25 + 40 ^ (0xEE ^ 0x8D) << " ".length());
    lIlllIlIIIIlll[10] = 0xD0 ^ 0xC1;
    lIlllIlIIIIlll[11] = (0x0 ^ 0x9) << " ".length();
    lIlllIlIIIIlll[12] = (0x7 ^ 0x18) << " ".length() ^ 0x4E ^ 0x51;
    lIlllIlIIIIlll[13] = (0x2C ^ 0x3D) << " ".length();
    lIlllIlIIIIlll[14] = 0xF ^ 0x28 ^ (0xA1 ^ 0xB0) << " ".length();
    lIlllIlIIIIlll[15] = "   ".length() << " ".length();
    lIlllIlIIIIlll[16] = 80 + 53 - 55 + 65 ^ (0x25 ^ 0x66) << " ".length();
    lIlllIlIIIIlll[17] = ((0xB8 ^ 0xA7) << " ".length() ^ 0xFF ^ 0xC4) << " ".length();
    lIlllIlIIIIlll[18] = (0x90 ^ 0x95) << " ".length() << " ".length();
    lIlllIlIIIIlll[19] = (154 + 25 - 79 + 57 ^ (0xAA ^ 0x8F) << " ".length() << " ".length()) << " ".length() << " ".length();
    lIlllIlIIIIlll[20] = (0xA3 ^ 0xA6) << "   ".length();
    lIlllIlIIIIlll[21] = 5 + 331 - 207 + 256 << " ".length();
    lIlllIlIIIIlll[22] = 626 + 494 - 568 + 219;
    lIlllIlIIIIlll[23] = (181 + 65 - 169 + 162 ^ (0x13 ^ 0x48) << " ".length()) << ((0x9D ^ 0xB0) << " ".length() ^ 0xED ^ 0xB2);
    lIlllIlIIIIlll[24] = ("   ".length() << " ".length() << " ".length() << " ".length()) + 816 + 227 - 96 + 170 - 460 + 587 - 764 + 380 + 959 + 74 - 159 + 201 << " ".length();
    lIlllIlIIIIlll[25] = (160 + 177 - 245 + 297 << " ".length() << " ".length()) + 1238 + 1277 - 1724 + 1324 - 1168 + 215 - -114 + 1140 + 976 + 351 - 565 + 381 << " ".length();
    lIlllIlIIIIlll[26] = "   ".length();
    lIlllIlIIIIlll[27] = (0xD3 ^ 0xC2) << " ".length() << " ".length();
    lIlllIlIIIIlll[28] = 0x6C ^ 0x71;
    lIlllIlIIIIlll[29] = 0x68 ^ 0x7B;
    lIlllIlIIIIlll[30] = 0x16 ^ 0x23;
    lIlllIlIIIIlll[31] = (0x32 ^ 0x35) << " ".length();
    lIlllIlIIIIlll[32] = 0xBE ^ 0xB3;
    lIlllIlIIIIlll[33] = "   ".length() << " ".length() << " ".length() << " ".length();
    lIlllIlIIIIlll[34] = 0xB6 ^ 0xB1;
    lIlllIlIIIIlll[35] = 0x44 ^ 0x67;
    lIlllIlIIIIlll[36] = 0xBF ^ 0xB0;
    lIlllIlIIIIlll[37] = 0x5F ^ 0x7A ^ (0x63 ^ 0x66) << " ".length();
    lIlllIlIIIIlll[38] = 71 + 49 - 69 + 88 ^ " ".length() << (0xC4 ^ 0xC3);
    lIlllIlIIIIlll[39] = "   ".length() << " ".length() << " ".length();
    lIlllIlIIIIlll[40] = 0xC ^ 0x27;
    lIlllIlIIIIlll[41] = ((0x1C ^ 0x4F) << " ".length() ^ 42 + 98 - 91 + 122) << " ".length() << " ".length();
    lIlllIlIIIIlll[42] = 0x5E ^ 0x45;
    lIlllIlIIIIlll[43] = (0x73 ^ 0x74) << " ".length() ^ 0x23 ^ 0x12;
    lIlllIlIIIIlll[44] = 0x4D ^ 0x58;
    lIlllIlIIIIlll[45] = (157 + 143 - 216 + 77 ^ " ".length() << (0x7F ^ 0x78)) << " ".length();
    lIlllIlIIIIlll[46] = ((0xCE ^ 0xC3) << " ".length() ^ 0x59 ^ 0x48) << " ".length();
    lIlllIlIIIIlll[47] = (0x32 ^ 0x3F) << " ".length() << " ".length() ^ 0x4 ^ 0x1;
    lIlllIlIIIIlll[48] = 0xBE ^ 0x8B ^ (0x8E ^ 0x9F) << " ".length();
    lIlllIlIIIIlll[49] = 12 + 71 - -35 + 45 ^ (0x72 ^ 0x53) << " ".length() << " ".length();
    lIlllIlIIIIlll[50] = 0x8B ^ 0x92;
    lIlllIlIIIIlll[51] = 76 + 61 - 3 + 5 ^ (0x3C ^ 0x19) << " ".length() << " ".length();
    lIlllIlIIIIlll[52] = (0x2B ^ 0x26) << " ".length();
    lIlllIlIIIIlll[53] = 0x63 ^ 0x54;
    lIlllIlIIIIlll[54] = (0xB8 ^ 0xBF) << " ".length() << " ".length();
    lIlllIlIIIIlll[55] = 0x3 ^ 0x2A;
    lIlllIlIIIIlll[56] = ((0x12 ^ 0x35) << " ".length() << " ".length() ^ 5 + 73 - 63 + 132) << " ".length();
    lIlllIlIIIIlll[57] = (0x1B ^ 0x1C) << "   ".length();
    lIlllIlIIIIlll[58] = (0xA7 ^ 0xB4) << " ".length();
    lIlllIlIIIIlll[59] = 0x3B ^ 0x1E;
    lIlllIlIIIIlll[60] = 0x44 ^ 0x7;
    lIlllIlIIIIlll[61] = 0x71 ^ 0x42;
    lIlllIlIIIIlll[62] = (0x5A ^ 0x55) << " ".length() << " ".length();
    lIlllIlIIIIlll[63] = (0x66 ^ 0x73) << " ".length();
    lIlllIlIIIIlll[64] = (0x8C ^ 0x87) << " ".length() << " ".length();
    lIlllIlIIIIlll[65] = 0x8B ^ 0xA6;
    lIlllIlIIIIlll[66] = ((0x6F ^ 0x64) << " ".length() << " ".length() ^ 0x15 ^ 0x2E) << " ".length();
    lIlllIlIIIIlll[67] = (0x98 ^ 0x91) << " ".length() ^ 0x2C ^ 0x7;
    lIlllIlIIIIlll[68] = " ".length() << "   ".length() << " ".length();
    lIlllIlIIIIlll[69] = (0xAD ^ 0xB4) << " ".length();
    lIlllIlIIIIlll[70] = 0xBF ^ 0x84;
    lIlllIlIIIIlll[71] = ((0x4A ^ 0x45) << " ".length() << " ".length() ^ 0x7D ^ 0x5A) << " ".length();
    lIlllIlIIIIlll[72] = (0xA8 ^ 0xB7) << " ".length();
    lIlllIlIIIIlll[73] = (0x6B ^ 0x7A) << " ".length() ^ 0x0 ^ 0x1F;
    lIlllIlIIIIlll[74] = (158 + 152 - 200 + 49 ^ (0x69 ^ 0x28) << " ".length()) << " ".length();
    lIlllIlIIIIlll[75] = (0x4 ^ 0x1B) << "   ".length() ^ 25 + 41 - 38 + 157;
    lIlllIlIIIIlll[76] = 0x37 ^ 0x72;
  }
  
  private static boolean lllllIIllIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllIIllIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllIIllIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllIIllIIlllI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f03.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */