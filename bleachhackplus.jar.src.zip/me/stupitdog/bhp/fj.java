package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class fj extends Thread {
  private static String[] llIIIIllIlllII;
  
  private static Class[] llIIIIllIlllIl;
  
  private static final String[] llIIIIllIllllI;
  
  private static String[] llIIIIlllIIIII;
  
  private static final int[] llIIIIlllIIlII;
  
  public void run() {
    // Byte code:
    //   0: <illegal opcode> 0 : ()V
    //   5: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	6	0	lllllllllllllllIllIllIIIIIlIIllI	Lme/stupitdog/bhp/fj;
  }
  
  public static void saveConfig() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   5: <illegal opcode> 2 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   10: getstatic me/stupitdog/bhp/fj.llIIIIllIllllI : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/fj.llIIIIlllIIlII : [I
    //   16: iconst_0
    //   17: iaload
    //   18: aaload
    //   19: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;Ljava/lang/String;)Lme/stupitdog/bhp/au;
    //   24: getstatic me/stupitdog/bhp/fj.llIIIIlllIIlII : [I
    //   27: iconst_0
    //   28: iaload
    //   29: <illegal opcode> 4 : (Lme/stupitdog/bhp/au;Z)V
    //   34: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   39: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   44: <illegal opcode> 6 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   49: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   54: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   59: <illegal opcode> 7 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   64: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   69: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   74: <illegal opcode> 8 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   79: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   84: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   89: <illegal opcode> 9 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   94: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   99: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   104: <illegal opcode> 10 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   109: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   114: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   119: <illegal opcode> 11 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   124: <illegal opcode> 1 : ()Lme/stupitdog/bhp/f9;
    //   129: <illegal opcode> 5 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/f10000000000000000000;
    //   134: <illegal opcode> 12 : (Lme/stupitdog/bhp/f10000000000000000000;)V
    //   139: ldc ''
    //   141: invokevirtual length : ()I
    //   144: pop
    //   145: ldc '   '
    //   147: invokevirtual length : ()I
    //   150: ldc '   '
    //   152: invokevirtual length : ()I
    //   155: if_icmpeq -> 166
    //   158: return
    //   159: astore_0
    //   160: aload_0
    //   161: <illegal opcode> 13 : (Ljava/io/IOException;)V
    //   166: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   160	6	0	lllllllllllllllIllIllIIIIIlIIlIl	Ljava/io/IOException;
    // Exception table:
    //   from	to	target	type
    //   0	139	159	java/io/IOException
  }
  
  static {
    lIIIIIllIIllIlll();
    lIIIIIllIIllIlIl();
    lIIIIIllIIllIlII();
    lIIIIIllIIlIlllI();
  }
  
  private static CallSite lIIIIIllIIlIllIl(MethodHandles.Lookup lllllllllllllllIllIllIIIIIIlllII, String lllllllllllllllIllIllIIIIIIllIll, MethodType lllllllllllllllIllIllIIIIIIllIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIIIIlIIIlI = llIIIIllIlllII[Integer.parseInt(lllllllllllllllIllIllIIIIIIllIll)].split(llIIIIllIllllI[llIIIIlllIIlII[1]]);
      Class<?> lllllllllllllllIllIllIIIIIlIIIIl = Class.forName(lllllllllllllllIllIllIIIIIlIIIlI[llIIIIlllIIlII[0]]);
      String lllllllllllllllIllIllIIIIIlIIIII = lllllllllllllllIllIllIIIIIlIIIlI[llIIIIlllIIlII[1]];
      MethodHandle lllllllllllllllIllIllIIIIIIlllll = null;
      int lllllllllllllllIllIllIIIIIIllllI = lllllllllllllllIllIllIIIIIlIIIlI[llIIIIlllIIlII[2]].length();
      if (lIIIIIllIIlllIII(lllllllllllllllIllIllIIIIIIllllI, llIIIIlllIIlII[3])) {
        MethodType lllllllllllllllIllIllIIIIIlIIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIIIIlIIIlI[llIIIIlllIIlII[3]], fj.class.getClassLoader());
        if (lIIIIIllIIlllIIl(lllllllllllllllIllIllIIIIIIllllI, llIIIIlllIIlII[3])) {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findVirtual(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIlII);
          "".length();
          if (("   ".length() << (0xE3 ^ 0x8A ^ (0x5B ^ 0x40) << " ".length() << " ".length()) & ("   ".length() << ((0x8B ^ 0x9E) << " ".length() << " ".length() ^ 0xC8 ^ 0x99) ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findStatic(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIlII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIIIIlIIIll = llIIIIllIlllIl[Integer.parseInt(lllllllllllllllIllIllIIIIIlIIIlI[llIIIIlllIIlII[3]])];
        if (lIIIIIllIIlllIIl(lllllllllllllllIllIllIIIIIIllllI, llIIIIlllIIlII[2])) {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findGetter(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIIll);
          "".length();
          if (-((0xF5 ^ 0xC0) << " ".length() ^ 0x39 ^ 0x56) >= 0)
            return null; 
        } else if (lIIIIIllIIlllIIl(lllllllllllllllIllIllIIIIIIllllI, llIIIIlllIIlII[4])) {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findStaticGetter(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIIll);
          "".length();
          if (-" ".length() > " ".length() << " ".length())
            return null; 
        } else if (lIIIIIllIIlllIIl(lllllllllllllllIllIllIIIIIIllllI, llIIIIlllIIlII[5])) {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findSetter(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIIll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIllIIIIIIlllll = lllllllllllllllIllIllIIIIIIlllII.findStaticSetter(lllllllllllllllIllIllIIIIIlIIIIl, lllllllllllllllIllIllIIIIIlIIIII, lllllllllllllllIllIllIIIIIlIIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIIIIIlllll);
    } catch (Exception lllllllllllllllIllIllIIIIIIlllIl) {
      lllllllllllllllIllIllIIIIIIlllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIIlIlllI() {
    llIIIIllIlllII = new String[llIIIIlllIIlII[6]];
    llIIIIllIlllII[llIIIIlllIIlII[7]] = llIIIIllIllllI[llIIIIlllIIlII[3]];
    llIIIIllIlllII[llIIIIlllIIlII[5]] = llIIIIllIllllI[llIIIIlllIIlII[2]];
    llIIIIllIlllII[llIIIIlllIIlII[8]] = llIIIIllIllllI[llIIIIlllIIlII[4]];
    llIIIIllIlllII[llIIIIlllIIlII[2]] = llIIIIllIllllI[llIIIIlllIIlII[5]];
    llIIIIllIlllII[llIIIIlllIIlII[9]] = llIIIIllIllllI[llIIIIlllIIlII[10]];
    llIIIIllIlllII[llIIIIlllIIlII[11]] = llIIIIllIllllI[llIIIIlllIIlII[9]];
    llIIIIllIlllII[llIIIIlllIIlII[0]] = llIIIIllIllllI[llIIIIlllIIlII[7]];
    llIIIIllIlllII[llIIIIlllIIlII[12]] = llIIIIllIllllI[llIIIIlllIIlII[12]];
    llIIIIllIlllII[llIIIIlllIIlII[13]] = llIIIIllIllllI[llIIIIlllIIlII[13]];
    llIIIIllIlllII[llIIIIlllIIlII[1]] = llIIIIllIllllI[llIIIIlllIIlII[8]];
    llIIIIllIlllII[llIIIIlllIIlII[14]] = llIIIIllIllllI[llIIIIlllIIlII[11]];
    llIIIIllIlllII[llIIIIlllIIlII[4]] = llIIIIllIllllI[llIIIIlllIIlII[14]];
    llIIIIllIlllII[llIIIIlllIIlII[3]] = llIIIIllIllllI[llIIIIlllIIlII[6]];
    llIIIIllIlllII[llIIIIlllIIlII[10]] = llIIIIllIllllI[llIIIIlllIIlII[15]];
    llIIIIllIlllIl = new Class[llIIIIlllIIlII[2]];
    llIIIIllIlllIl[llIIIIlllIIlII[3]] = f10000000000000000000.class;
    llIIIIllIlllIl[llIIIIlllIIlII[1]] = av.class;
    llIIIIllIlllIl[llIIIIlllIIlII[0]] = f9.class;
  }
  
  private static void lIIIIIllIIllIlII() {
    llIIIIllIllllI = new String[llIIIIlllIIlII[16]];
    llIIIIllIllllI[llIIIIlllIIlII[0]] = lIIIIIllIIlIllll(llIIIIlllIIIII[llIIIIlllIIlII[0]], llIIIIlllIIIII[llIIIIlllIIlII[1]]);
    llIIIIllIllllI[llIIIIlllIIlII[1]] = lIIIIIllIIllIIII(llIIIIlllIIIII[llIIIIlllIIlII[3]], llIIIIlllIIIII[llIIIIlllIIlII[2]]);
    llIIIIllIllllI[llIIIIlllIIlII[3]] = lIIIIIllIIllIIII(llIIIIlllIIIII[llIIIIlllIIlII[4]], llIIIIlllIIIII[llIIIIlllIIlII[5]]);
    llIIIIllIllllI[llIIIIlllIIlII[2]] = lIIIIIllIIlIllll(llIIIIlllIIIII[llIIIIlllIIlII[10]], llIIIIlllIIIII[llIIIIlllIIlII[9]]);
    llIIIIllIllllI[llIIIIlllIIlII[4]] = lIIIIIllIIllIIIl(llIIIIlllIIIII[llIIIIlllIIlII[7]], llIIIIlllIIIII[llIIIIlllIIlII[12]]);
    llIIIIllIllllI[llIIIIlllIIlII[5]] = lIIIIIllIIlIllll(llIIIIlllIIIII[llIIIIlllIIlII[13]], llIIIIlllIIIII[llIIIIlllIIlII[8]]);
    llIIIIllIllllI[llIIIIlllIIlII[10]] = lIIIIIllIIllIIIl("5HmLNL+DyR3SupvnizaQRfki0hIBKRlobAa73uj6GRuGTxGD1s7xJ/3djE6dOOSfwuTaOUbdHx/uD6eLScc5Rw==", "LUnji");
    llIIIIllIllllI[llIIIIlllIIlII[9]] = lIIIIIllIIllIIII("Ff9fIACfcoa67BtRm39w+o9HI0Ow0iRVGrDK2geKqCNJDVgck+9hURJw4fgncGyD04qTv2g/pQroAZli9W/63g==", "GGDDd");
    llIIIIllIllllI[llIIIIlllIIlII[7]] = lIIIIIllIIllIIIl("kpw25JLBesUIDPkpxnnSmGCYDYyUszXQNUs27pScq7H0lJNP0ujU/Q==", "LyFrj");
    llIIIIllIllllI[llIIIIlllIIlII[12]] = lIIIIIllIIllIIIl("x5UxlDDSCSkbUGninzxD1yhVSlgakdEIYgd+a1rIdlKVn6i6Bfki6TC8rtWVupZHFaqSxC0bRHfAtmMK1IhTJ0zW/P4t3+Ef", "DhEZv");
    llIIIIllIllllI[llIIIIlllIIlII[13]] = lIIIIIllIIllIIII("vYehvXaxeuR3Rih8j6BCTfaJ7WKjRaUnaHuR7stdarkoqCQsgeyQimxsuadMBs/buKhgwlr5Pp152FQUyn1rbA==", "VLWnd");
    llIIIIllIllllI[llIIIIlllIIlII[8]] = lIIIIIllIIllIIIl("/GGXHGtKB9xUNMEvqnAsx5RnqA96uzw25kzfDFOBYsJc7jen8HthVQ==", "BjdNC");
    llIIIIllIllllI[llIIIIlllIIlII[11]] = lIIIIIllIIlIllll("JA4OF2YnAFY/BwsXGxM4OgYXGHI+HREYPB0bGRUjGh0ZFS10R1Egcm5P", "NoxvH");
    llIIIIllIllllI[llIIIIlllIIlII[14]] = lIIIIIllIIllIIII("dU02wG/v8+h6hEnOgEiV9rVcrwGsfJ6FYGeEp/Ql4B3TkvyjBl2LEA==", "OeALr");
    llIIIIllIllllI[llIIIIlllIIlII[6]] = lIIIIIllIIlIllll("HBJtIjAEByolIB4QbTMsAVklaH4cGCckKBQ6Ij8lFhIxa3VLV2Nx", "qwCQD");
    llIIIIllIllllI[llIIIIlllIIlII[15]] = lIIIIIllIIllIIII("hRgDGUOmkTr+NSQQANs+quq3/uWt2rxt4tKjdrek81mZE2SQlaUxFEWHsEHyGZdGkfSfqVNZsj5LsnfWaVcbyg==", "DmaFJ");
    llIIIIlllIIIII = null;
  }
  
  private static void lIIIIIllIIllIlIl() {
    String str = (new Exception()).getStackTrace()[llIIIIlllIIlII[0]].getFileName();
    llIIIIlllIIIII = str.substring(str.indexOf("ä") + llIIIIlllIIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIllIIllIIIl(String lllllllllllllllIllIllIIIIIIlIllI, String lllllllllllllllIllIllIIIIIIlIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIIIIllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIIIIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIIIIIllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIIIIIllIII.init(llIIIIlllIIlII[3], lllllllllllllllIllIllIIIIIIllIIl);
      return new String(lllllllllllllllIllIllIIIIIIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIIIIlIlll) {
      lllllllllllllllIllIllIIIIIIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIllIIlIllll(String lllllllllllllllIllIllIIIIIIlIIll, String lllllllllllllllIllIllIIIIIIlIIlI) {
    lllllllllllllllIllIllIIIIIIlIIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIIIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIIIIIlIIIl = new StringBuilder();
    char[] lllllllllllllllIllIllIIIIIIlIIII = lllllllllllllllIllIllIIIIIIlIIlI.toCharArray();
    int lllllllllllllllIllIllIIIIIIIllll = llIIIIlllIIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIIIIIlIIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIlllIIlII[0];
    while (lIIIIIllIIlllIlI(j, i)) {
      char lllllllllllllllIllIllIIIIIIlIlII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIIIIIIllll++;
      j++;
      "".length();
      if (" ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIIIIIlIIIl);
  }
  
  private static String lIIIIIllIIllIIII(String lllllllllllllllIllIllIIIIIIIlIll, String lllllllllllllllIllIllIIIIIIIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIIIIIIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIIIIIlIlI.getBytes(StandardCharsets.UTF_8)), llIIIIlllIIlII[7]), "DES");
      Cipher lllllllllllllllIllIllIIIIIIIllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIIIIIIllIl.init(llIIIIlllIIlII[3], lllllllllllllllIllIllIIIIIIIlllI);
      return new String(lllllllllllllllIllIllIIIIIIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIIIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIIIIIIllII) {
      lllllllllllllllIllIllIIIIIIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIllIIllIlll() {
    llIIIIlllIIlII = new int[17];
    llIIIIlllIIlII[0] = (0xA0 ^ 0xA9) & (0x30 ^ 0x39 ^ 0xFFFFFFFF);
    llIIIIlllIIlII[1] = " ".length();
    llIIIIlllIIlII[2] = "   ".length();
    llIIIIlllIIlII[3] = " ".length() << " ".length();
    llIIIIlllIIlII[4] = " ".length() << " ".length() << " ".length();
    llIIIIlllIIlII[5] = "   ".length() << " ".length() ^ "   ".length();
    llIIIIlllIIlII[6] = (0x77 ^ 0x10 ^ "   ".length() << (0x39 ^ 0x3C)) << " ".length();
    llIIIIlllIIlII[7] = " ".length() << "   ".length();
    llIIIIlllIIlII[8] = (0xAA ^ 0x81) << " ".length() ^ 0x4D ^ 0x10;
    llIIIIlllIIlII[9] = (0xC3 ^ 0xC6) << (0xC ^ 0x9) ^ 145 + 104 - 96 + 14;
    llIIIIlllIIlII[10] = "   ".length() << " ".length();
    llIIIIlllIIlII[11] = "   ".length() << " ".length() << " ".length();
    llIIIIlllIIlII[12] = (0x65 ^ 0x6E) << " ".length() ^ 0x54 ^ 0x4B;
    llIIIIlllIIlII[13] = (0x8B ^ 0xA2 ^ (0xA ^ 0x1) << " ".length() << " ".length()) << " ".length();
    llIIIIlllIIlII[14] = 0xCF ^ 0xC2;
    llIIIIlllIIlII[15] = 0x8E ^ 0xB3 ^ (0x13 ^ 0xA) << " ".length();
    llIIIIlllIIlII[16] = " ".length() << " ".length() << " ".length() << " ".length();
  }
  
  private static boolean lIIIIIllIIlllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIllIIlllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIllIIlllIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\fj.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */