package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class av {
  private Minecraft mc;
  
  public ArrayList<au> modules;
  
  private static String[] lIllIlIlIIIIIl;
  
  private static Class[] lIllIlIlIIIIlI;
  
  private static final String[] lIllIlIlIIlllI;
  
  private static String[] lIllIlIlIIllll;
  
  private static final int[] lIllIlIlIlIIII;
  
  public av() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: <illegal opcode> 0 : ()Lnet/minecraft/client/Minecraft;
    //   10: <illegal opcode> 1 : (Lme/stupitdog/bhp/av;Lnet/minecraft/client/Minecraft;)V
    //   15: aload_0
    //   16: new java/util/ArrayList
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: <illegal opcode> 2 : (Lme/stupitdog/bhp/av;Ljava/util/ArrayList;)V
    //   28: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	29	0	lllllllllllllllIllllIlIlllIIlIll	Lme/stupitdog/bhp/av;
  }
  
  public void init() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   6: new me/stupitdog/bhp/fe
    //   9: dup
    //   10: invokespecial <init> : ()V
    //   13: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop2
    //   24: aload_0
    //   25: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   30: new me/stupitdog/bhp/fg
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   42: ldc ''
    //   44: invokevirtual length : ()I
    //   47: pop2
    //   48: aload_0
    //   49: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   54: new me/stupitdog/bhp/fl
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   66: ldc ''
    //   68: invokevirtual length : ()I
    //   71: pop2
    //   72: aload_0
    //   73: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   78: new me/stupitdog/bhp/am
    //   81: dup
    //   82: invokespecial <init> : ()V
    //   85: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   90: ldc ''
    //   92: invokevirtual length : ()I
    //   95: pop2
    //   96: aload_0
    //   97: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   102: new me/stupitdog/bhp/f100000000
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   114: ldc ''
    //   116: invokevirtual length : ()I
    //   119: pop2
    //   120: aload_0
    //   121: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   126: new me/stupitdog/bhp/f0d
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   138: ldc ''
    //   140: invokevirtual length : ()I
    //   143: pop2
    //   144: aload_0
    //   145: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   150: new me/stupitdog/bhp/f0e
    //   153: dup
    //   154: invokespecial <init> : ()V
    //   157: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   162: ldc ''
    //   164: invokevirtual length : ()I
    //   167: pop2
    //   168: aload_0
    //   169: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   174: new me/stupitdog/bhp/f0g
    //   177: dup
    //   178: invokespecial <init> : ()V
    //   181: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   186: ldc ''
    //   188: invokevirtual length : ()I
    //   191: pop2
    //   192: aload_0
    //   193: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   198: new me/stupitdog/bhp/f0h
    //   201: dup
    //   202: invokespecial <init> : ()V
    //   205: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   210: ldc ''
    //   212: invokevirtual length : ()I
    //   215: pop2
    //   216: aload_0
    //   217: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   222: new me/stupitdog/bhp/f0i
    //   225: dup
    //   226: invokespecial <init> : ()V
    //   229: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   234: ldc ''
    //   236: invokevirtual length : ()I
    //   239: pop2
    //   240: aload_0
    //   241: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   246: new me/stupitdog/bhp/f2
    //   249: dup
    //   250: invokespecial <init> : ()V
    //   253: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   258: ldc ''
    //   260: invokevirtual length : ()I
    //   263: pop2
    //   264: aload_0
    //   265: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   270: new me/stupitdog/bhp/f5
    //   273: dup
    //   274: invokespecial <init> : ()V
    //   277: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   282: ldc ''
    //   284: invokevirtual length : ()I
    //   287: pop2
    //   288: aload_0
    //   289: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   294: new me/stupitdog/bhp/f6
    //   297: dup
    //   298: invokespecial <init> : ()V
    //   301: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   306: ldc ''
    //   308: invokevirtual length : ()I
    //   311: pop2
    //   312: aload_0
    //   313: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   318: new me/stupitdog/bhp/f8
    //   321: dup
    //   322: invokespecial <init> : ()V
    //   325: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   330: ldc ''
    //   332: invokevirtual length : ()I
    //   335: pop2
    //   336: aload_0
    //   337: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   342: new me/stupitdog/bhp/f10
    //   345: dup
    //   346: invokespecial <init> : ()V
    //   349: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   354: ldc ''
    //   356: invokevirtual length : ()I
    //   359: pop2
    //   360: aload_0
    //   361: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   366: new me/stupitdog/bhp/fk
    //   369: dup
    //   370: invokespecial <init> : ()V
    //   373: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   378: ldc ''
    //   380: invokevirtual length : ()I
    //   383: pop2
    //   384: aload_0
    //   385: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   390: new me/stupitdog/bhp/aj
    //   393: dup
    //   394: invokespecial <init> : ()V
    //   397: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   402: ldc ''
    //   404: invokevirtual length : ()I
    //   407: pop2
    //   408: aload_0
    //   409: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   414: new me/stupitdog/bhp/f1000000000
    //   417: dup
    //   418: invokespecial <init> : ()V
    //   421: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   426: ldc ''
    //   428: invokevirtual length : ()I
    //   431: pop2
    //   432: aload_0
    //   433: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   438: new me/stupitdog/bhp/f1000000000000000000000000000000
    //   441: dup
    //   442: invokespecial <init> : ()V
    //   445: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   450: ldc ''
    //   452: invokevirtual length : ()I
    //   455: pop2
    //   456: aload_0
    //   457: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   462: new me/stupitdog/bhp/f1000000000000000000000000000000000
    //   465: dup
    //   466: invokespecial <init> : ()V
    //   469: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   474: ldc ''
    //   476: invokevirtual length : ()I
    //   479: pop2
    //   480: aload_0
    //   481: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   486: new me/stupitdog/bhp/f05
    //   489: dup
    //   490: invokespecial <init> : ()V
    //   493: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   498: ldc ''
    //   500: invokevirtual length : ()I
    //   503: pop2
    //   504: aload_0
    //   505: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   510: new me/stupitdog/bhp/f08
    //   513: dup
    //   514: invokespecial <init> : ()V
    //   517: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   522: ldc ''
    //   524: invokevirtual length : ()I
    //   527: pop2
    //   528: aload_0
    //   529: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   534: new me/stupitdog/bhp/fu
    //   537: dup
    //   538: invokespecial <init> : ()V
    //   541: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   546: ldc ''
    //   548: invokevirtual length : ()I
    //   551: pop2
    //   552: aload_0
    //   553: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   558: new me/stupitdog/bhp/f11
    //   561: dup
    //   562: invokespecial <init> : ()V
    //   565: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   570: ldc ''
    //   572: invokevirtual length : ()I
    //   575: pop2
    //   576: aload_0
    //   577: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   582: new me/stupitdog/bhp/fn
    //   585: dup
    //   586: invokespecial <init> : ()V
    //   589: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   594: ldc ''
    //   596: invokevirtual length : ()I
    //   599: pop2
    //   600: aload_0
    //   601: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   606: new me/stupitdog/bhp/ax
    //   609: dup
    //   610: invokespecial <init> : ()V
    //   613: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   618: ldc ''
    //   620: invokevirtual length : ()I
    //   623: pop2
    //   624: aload_0
    //   625: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   630: new me/stupitdog/bhp/f100000000000000000000000000
    //   633: dup
    //   634: invokespecial <init> : ()V
    //   637: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   642: ldc ''
    //   644: invokevirtual length : ()I
    //   647: pop2
    //   648: aload_0
    //   649: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   654: new me/stupitdog/bhp/f1000000000000000000000000000000000000000
    //   657: dup
    //   658: invokespecial <init> : ()V
    //   661: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   666: ldc ''
    //   668: invokevirtual length : ()I
    //   671: pop2
    //   672: aload_0
    //   673: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   678: new me/stupitdog/bhp/f1
    //   681: dup
    //   682: invokespecial <init> : ()V
    //   685: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   690: ldc ''
    //   692: invokevirtual length : ()I
    //   695: pop2
    //   696: aload_0
    //   697: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   702: new me/stupitdog/bhp/f3
    //   705: dup
    //   706: invokespecial <init> : ()V
    //   709: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   714: ldc ''
    //   716: invokevirtual length : ()I
    //   719: pop2
    //   720: aload_0
    //   721: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   726: new me/stupitdog/bhp/f4
    //   729: dup
    //   730: invokespecial <init> : ()V
    //   733: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   738: ldc ''
    //   740: invokevirtual length : ()I
    //   743: pop2
    //   744: aload_0
    //   745: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   750: new me/stupitdog/bhp/fc
    //   753: dup
    //   754: invokespecial <init> : ()V
    //   757: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   762: ldc ''
    //   764: invokevirtual length : ()I
    //   767: pop2
    //   768: aload_0
    //   769: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   774: new me/stupitdog/bhp/ac
    //   777: dup
    //   778: invokespecial <init> : ()V
    //   781: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   786: ldc ''
    //   788: invokevirtual length : ()I
    //   791: pop2
    //   792: aload_0
    //   793: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   798: new me/stupitdog/bhp/as
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   810: ldc ''
    //   812: invokevirtual length : ()I
    //   815: pop2
    //   816: aload_0
    //   817: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   822: new me/stupitdog/bhp/f1000
    //   825: dup
    //   826: invokespecial <init> : ()V
    //   829: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   834: ldc ''
    //   836: invokevirtual length : ()I
    //   839: pop2
    //   840: aload_0
    //   841: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   846: new me/stupitdog/bhp/f0a
    //   849: dup
    //   850: invokespecial <init> : ()V
    //   853: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   858: ldc ''
    //   860: invokevirtual length : ()I
    //   863: pop2
    //   864: aload_0
    //   865: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   870: new me/stupitdog/bhp/f0c
    //   873: dup
    //   874: invokespecial <init> : ()V
    //   877: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   882: ldc ''
    //   884: invokevirtual length : ()I
    //   887: pop2
    //   888: aload_0
    //   889: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   894: new me/stupitdog/bhp/f7
    //   897: dup
    //   898: invokespecial <init> : ()V
    //   901: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   906: ldc ''
    //   908: invokevirtual length : ()I
    //   911: pop2
    //   912: aload_0
    //   913: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   918: new me/stupitdog/bhp/an
    //   921: dup
    //   922: invokespecial <init> : ()V
    //   925: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   930: ldc ''
    //   932: invokevirtual length : ()I
    //   935: pop2
    //   936: aload_0
    //   937: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   942: new me/stupitdog/bhp/aq
    //   945: dup
    //   946: invokespecial <init> : ()V
    //   949: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   954: ldc ''
    //   956: invokevirtual length : ()I
    //   959: pop2
    //   960: aload_0
    //   961: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   966: new me/stupitdog/bhp/f10000000
    //   969: dup
    //   970: invokespecial <init> : ()V
    //   973: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   978: ldc ''
    //   980: invokevirtual length : ()I
    //   983: pop2
    //   984: aload_0
    //   985: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   990: new me/stupitdog/bhp/f1000000000000
    //   993: dup
    //   994: invokespecial <init> : ()V
    //   997: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1002: ldc ''
    //   1004: invokevirtual length : ()I
    //   1007: pop2
    //   1008: aload_0
    //   1009: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1014: new me/stupitdog/bhp/f1000000000000000000
    //   1017: dup
    //   1018: invokespecial <init> : ()V
    //   1021: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1026: ldc ''
    //   1028: invokevirtual length : ()I
    //   1031: pop2
    //   1032: aload_0
    //   1033: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1038: new me/stupitdog/bhp/f10000000000000000000000000
    //   1041: dup
    //   1042: invokespecial <init> : ()V
    //   1045: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1050: ldc ''
    //   1052: invokevirtual length : ()I
    //   1055: pop2
    //   1056: aload_0
    //   1057: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1062: new me/stupitdog/bhp/f1000000000000000000000000000
    //   1065: dup
    //   1066: invokespecial <init> : ()V
    //   1069: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1074: ldc ''
    //   1076: invokevirtual length : ()I
    //   1079: pop2
    //   1080: aload_0
    //   1081: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1086: new me/stupitdog/bhp/f100000000000000000000000000000
    //   1089: dup
    //   1090: invokespecial <init> : ()V
    //   1093: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1098: ldc ''
    //   1100: invokevirtual length : ()I
    //   1103: pop2
    //   1104: aload_0
    //   1105: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1110: new me/stupitdog/bhp/fo
    //   1113: dup
    //   1114: invokespecial <init> : ()V
    //   1117: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1122: ldc ''
    //   1124: invokevirtual length : ()I
    //   1127: pop2
    //   1128: aload_0
    //   1129: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1134: new me/stupitdog/bhp/fp
    //   1137: dup
    //   1138: invokespecial <init> : ()V
    //   1141: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1146: ldc ''
    //   1148: invokevirtual length : ()I
    //   1151: pop2
    //   1152: aload_0
    //   1153: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1158: new me/stupitdog/bhp/fv
    //   1161: dup
    //   1162: invokespecial <init> : ()V
    //   1165: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1170: ldc ''
    //   1172: invokevirtual length : ()I
    //   1175: pop2
    //   1176: aload_0
    //   1177: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1182: new me/stupitdog/bhp/Fly
    //   1185: dup
    //   1186: invokespecial <init> : ()V
    //   1189: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1194: ldc ''
    //   1196: invokevirtual length : ()I
    //   1199: pop2
    //   1200: aload_0
    //   1201: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1206: new me/stupitdog/bhp/fy
    //   1209: dup
    //   1210: invokespecial <init> : ()V
    //   1213: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1218: ldc ''
    //   1220: invokevirtual length : ()I
    //   1223: pop2
    //   1224: aload_0
    //   1225: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1230: new me/stupitdog/bhp/ae
    //   1233: dup
    //   1234: invokespecial <init> : ()V
    //   1237: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1242: ldc ''
    //   1244: invokevirtual length : ()I
    //   1247: pop2
    //   1248: aload_0
    //   1249: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1254: new me/stupitdog/bhp/ay
    //   1257: dup
    //   1258: invokespecial <init> : ()V
    //   1261: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1266: ldc ''
    //   1268: invokevirtual length : ()I
    //   1271: pop2
    //   1272: aload_0
    //   1273: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1278: new me/stupitdog/bhp/f10000
    //   1281: dup
    //   1282: invokespecial <init> : ()V
    //   1285: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1290: ldc ''
    //   1292: invokevirtual length : ()I
    //   1295: pop2
    //   1296: aload_0
    //   1297: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1302: new me/stupitdog/bhp/f100000
    //   1305: dup
    //   1306: invokespecial <init> : ()V
    //   1309: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1314: ldc ''
    //   1316: invokevirtual length : ()I
    //   1319: pop2
    //   1320: aload_0
    //   1321: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1326: new me/stupitdog/bhp/f1000000000000000
    //   1329: dup
    //   1330: invokespecial <init> : ()V
    //   1333: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1338: ldc ''
    //   1340: invokevirtual length : ()I
    //   1343: pop2
    //   1344: aload_0
    //   1345: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1350: new me/stupitdog/bhp/f1000000000000000000000000000000000000
    //   1353: dup
    //   1354: invokespecial <init> : ()V
    //   1357: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1362: ldc ''
    //   1364: invokevirtual length : ()I
    //   1367: pop2
    //   1368: aload_0
    //   1369: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1374: new me/stupitdog/bhp/fb
    //   1377: dup
    //   1378: invokespecial <init> : ()V
    //   1381: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1386: ldc ''
    //   1388: invokevirtual length : ()I
    //   1391: pop2
    //   1392: aload_0
    //   1393: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1398: new me/stupitdog/bhp/fr
    //   1401: dup
    //   1402: invokespecial <init> : ()V
    //   1405: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1410: ldc ''
    //   1412: invokevirtual length : ()I
    //   1415: pop2
    //   1416: aload_0
    //   1417: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1422: new me/stupitdog/bhp/fx
    //   1425: dup
    //   1426: invokespecial <init> : ()V
    //   1429: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1434: ldc ''
    //   1436: invokevirtual length : ()I
    //   1439: pop2
    //   1440: aload_0
    //   1441: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1446: new me/stupitdog/bhp/aa
    //   1449: dup
    //   1450: invokespecial <init> : ()V
    //   1453: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1458: ldc ''
    //   1460: invokevirtual length : ()I
    //   1463: pop2
    //   1464: aload_0
    //   1465: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1470: new me/stupitdog/bhp/ai
    //   1473: dup
    //   1474: invokespecial <init> : ()V
    //   1477: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1482: ldc ''
    //   1484: invokevirtual length : ()I
    //   1487: pop2
    //   1488: aload_0
    //   1489: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1494: new me/stupitdog/bhp/az
    //   1497: dup
    //   1498: invokespecial <init> : ()V
    //   1501: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1506: ldc ''
    //   1508: invokevirtual length : ()I
    //   1511: pop2
    //   1512: aload_0
    //   1513: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1518: new me/stupitdog/bhp/f1000000
    //   1521: dup
    //   1522: invokespecial <init> : ()V
    //   1525: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1530: ldc ''
    //   1532: invokevirtual length : ()I
    //   1535: pop2
    //   1536: aload_0
    //   1537: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1542: new me/stupitdog/bhp/f10000000000000000000000
    //   1545: dup
    //   1546: invokespecial <init> : ()V
    //   1549: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1554: ldc ''
    //   1556: invokevirtual length : ()I
    //   1559: pop2
    //   1560: aload_0
    //   1561: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   1566: new me/stupitdog/bhp/f1000000000000000000000000
    //   1569: dup
    //   1570: invokespecial <init> : ()V
    //   1573: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   1578: ldc ''
    //   1580: invokevirtual length : ()I
    //   1583: pop2
    //   1584: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	1585	0	lllllllllllllllIllllIlIlllIIlIlI	Lme/stupitdog/bhp/av;
  }
  
  public au getModule(String lllllllllllllllIllllIlIlllIIIlll) {
    // Byte code:
    //   0: <illegal opcode> 5 : ()Lme/stupitdog/bhp/f9;
    //   5: <illegal opcode> 6 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   10: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   15: <illegal opcode> 7 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   20: astore_2
    //   21: aload_2
    //   22: <illegal opcode> 8 : (Ljava/util/Iterator;)Z
    //   27: invokestatic llllIIlllIIlIIl : (I)Z
    //   30: ifeq -> 81
    //   33: aload_2
    //   34: <illegal opcode> 9 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   39: checkcast me/stupitdog/bhp/au
    //   42: astore_3
    //   43: aload_3
    //   44: <illegal opcode> 10 : (Lme/stupitdog/bhp/au;)Ljava/lang/String;
    //   49: aload_1
    //   50: <illegal opcode> 11 : (Ljava/lang/String;Ljava/lang/String;)Z
    //   55: invokestatic llllIIlllIIlIIl : (I)Z
    //   58: ifeq -> 63
    //   61: aload_3
    //   62: areturn
    //   63: ldc ''
    //   65: invokevirtual length : ()I
    //   68: pop
    //   69: sipush #149
    //   72: sipush #144
    //   75: ixor
    //   76: ifne -> 21
    //   79: aconst_null
    //   80: areturn
    //   81: aconst_null
    //   82: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   43	20	3	lllllllllllllllIllllIlIlllIIlIIl	Lme/stupitdog/bhp/au;
    //   0	83	0	lllllllllllllllIllllIlIlllIIlIII	Lme/stupitdog/bhp/av;
    //   0	83	1	lllllllllllllllIllllIlIlllIIIlll	Ljava/lang/String;
  }
  
  public ArrayList<au> getModulesInCategory(f13 lllllllllllllllIllllIlIlllIIIlII) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: <illegal opcode> 5 : ()Lme/stupitdog/bhp/f9;
    //   13: <illegal opcode> 6 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   18: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   23: <illegal opcode> 7 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   28: astore_3
    //   29: aload_3
    //   30: <illegal opcode> 8 : (Ljava/util/Iterator;)Z
    //   35: invokestatic llllIIlllIIlIIl : (I)Z
    //   38: ifeq -> 126
    //   41: aload_3
    //   42: <illegal opcode> 9 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   47: checkcast me/stupitdog/bhp/au
    //   50: astore #4
    //   52: aload #4
    //   54: <illegal opcode> 12 : (Lme/stupitdog/bhp/au;)Lme/stupitdog/bhp/f13;
    //   59: aload_1
    //   60: invokestatic llllIIlllIIlIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   63: ifeq -> 80
    //   66: aload_2
    //   67: aload #4
    //   69: <illegal opcode> 4 : (Ljava/util/ArrayList;Ljava/lang/Object;)Z
    //   74: ldc ''
    //   76: invokevirtual length : ()I
    //   79: pop2
    //   80: ldc ''
    //   82: invokevirtual length : ()I
    //   85: pop
    //   86: bipush #89
    //   88: bipush #92
    //   90: ixor
    //   91: ldc_w ' '
    //   94: invokevirtual length : ()I
    //   97: ishl
    //   98: sipush #184
    //   101: sipush #189
    //   104: ixor
    //   105: ldc_w ' '
    //   108: invokevirtual length : ()I
    //   111: ishl
    //   112: iconst_m1
    //   113: ixor
    //   114: iand
    //   115: ldc_w '   '
    //   118: invokevirtual length : ()I
    //   121: if_icmpne -> 29
    //   124: aconst_null
    //   125: areturn
    //   126: aload_2
    //   127: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   52	28	4	lllllllllllllllIllllIlIlllIIIllI	Lme/stupitdog/bhp/au;
    //   0	128	0	lllllllllllllllIllllIlIlllIIIlIl	Lme/stupitdog/bhp/av;
    //   0	128	1	lllllllllllllllIllllIlIlllIIIlII	Lme/stupitdog/bhp/f13;
    //   8	120	2	lllllllllllllllIllllIlIlllIIIIll	Ljava/util/ArrayList;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   8	120	2	lllllllllllllllIllllIlIlllIIIIll	Ljava/util/ArrayList<Lme/stupitdog/bhp/au;>;
  }
  
  @SubscribeEvent
  public void onTick(TickEvent.ClientTickEvent lllllllllllllllIllllIlIlllIIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 13 : (Lme/stupitdog/bhp/av;)Lnet/minecraft/client/Minecraft;
    //   6: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   11: invokestatic llllIIlllIIlIll : (Ljava/lang/Object;)Z
    //   14: ifeq -> 89
    //   17: <illegal opcode> 5 : ()Lme/stupitdog/bhp/f9;
    //   22: <illegal opcode> 6 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   27: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   32: <illegal opcode> 7 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   37: astore_2
    //   38: aload_2
    //   39: <illegal opcode> 8 : (Ljava/util/Iterator;)Z
    //   44: invokestatic llllIIlllIIlIIl : (I)Z
    //   47: ifeq -> 89
    //   50: aload_2
    //   51: <illegal opcode> 9 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   56: checkcast me/stupitdog/bhp/au
    //   59: astore_3
    //   60: aload_3
    //   61: <illegal opcode> 15 : (Lme/stupitdog/bhp/au;)Z
    //   66: invokestatic llllIIlllIIlIIl : (I)Z
    //   69: ifeq -> 78
    //   72: aload_3
    //   73: <illegal opcode> 16 : (Lme/stupitdog/bhp/au;)V
    //   78: ldc ''
    //   80: invokevirtual length : ()I
    //   83: pop
    //   84: aconst_null
    //   85: ifnull -> 38
    //   88: return
    //   89: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   60	18	3	lllllllllllllllIllllIlIlllIIIIlI	Lme/stupitdog/bhp/au;
    //   0	90	0	lllllllllllllllIllllIlIlllIIIIIl	Lme/stupitdog/bhp/av;
    //   0	90	1	lllllllllllllllIllllIlIlllIIIIII	Lnet/minecraftforge/fml/common/gameevent/TickEvent$ClientTickEvent;
  }
  
  @SubscribeEvent
  public void onKey(InputEvent.KeyInputEvent lllllllllllllllIllllIlIllIllllIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 13 : (Lme/stupitdog/bhp/av;)Lnet/minecraft/client/Minecraft;
    //   6: <illegal opcode> 14 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   11: invokestatic llllIIlllIIlIll : (Ljava/lang/Object;)Z
    //   14: ifeq -> 167
    //   17: aload_0
    //   18: <illegal opcode> 13 : (Lme/stupitdog/bhp/av;)Lnet/minecraft/client/Minecraft;
    //   23: <illegal opcode> 17 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   28: invokestatic llllIIlllIIlIll : (Ljava/lang/Object;)Z
    //   31: ifeq -> 167
    //   34: <illegal opcode> 18 : ()Z
    //   39: invokestatic llllIIlllIIlIIl : (I)Z
    //   42: ifeq -> 167
    //   45: <illegal opcode> 5 : ()Lme/stupitdog/bhp/f9;
    //   50: <illegal opcode> 6 : (Lme/stupitdog/bhp/f9;)Lme/stupitdog/bhp/av;
    //   55: <illegal opcode> 3 : (Lme/stupitdog/bhp/av;)Ljava/util/ArrayList;
    //   60: <illegal opcode> 7 : (Ljava/util/ArrayList;)Ljava/util/Iterator;
    //   65: astore_2
    //   66: aload_2
    //   67: <illegal opcode> 8 : (Ljava/util/Iterator;)Z
    //   72: invokestatic llllIIlllIIlIIl : (I)Z
    //   75: ifeq -> 167
    //   78: aload_2
    //   79: <illegal opcode> 9 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   84: checkcast me/stupitdog/bhp/au
    //   87: astore_3
    //   88: aload_3
    //   89: <illegal opcode> 19 : (Lme/stupitdog/bhp/au;)I
    //   94: <illegal opcode> 20 : ()I
    //   99: invokestatic llllIIlllIIllII : (II)Z
    //   102: ifeq -> 111
    //   105: aload_3
    //   106: <illegal opcode> 21 : (Lme/stupitdog/bhp/au;)V
    //   111: ldc ''
    //   113: invokevirtual length : ()I
    //   116: pop
    //   117: sipush #232
    //   120: sipush #197
    //   123: ixor
    //   124: ldc_w ' '
    //   127: invokevirtual length : ()I
    //   130: ishl
    //   131: sipush #239
    //   134: sipush #194
    //   137: ixor
    //   138: ldc_w ' '
    //   141: invokevirtual length : ()I
    //   144: ishl
    //   145: iconst_m1
    //   146: ixor
    //   147: iand
    //   148: bipush #16
    //   150: bipush #115
    //   152: ixor
    //   153: sipush #248
    //   156: sipush #155
    //   159: ixor
    //   160: iconst_m1
    //   161: ixor
    //   162: iand
    //   163: if_icmpeq -> 66
    //   166: return
    //   167: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   88	23	3	lllllllllllllllIllllIlIllIllllll	Lme/stupitdog/bhp/au;
    //   0	168	0	lllllllllllllllIllllIlIllIlllllI	Lme/stupitdog/bhp/av;
    //   0	168	1	lllllllllllllllIllllIlIllIllllIl	Lnet/minecraftforge/fml/common/gameevent/InputEvent$KeyInputEvent;
  }
  
  static {
    llllIIlllIIlIII();
    llllIIlllIIIlll();
    llllIIlllIIIllI();
    llllIIlllIIIIlI();
  }
  
  private static CallSite llllIIllIlIIlll(MethodHandles.Lookup lllllllllllllllIllllIlIllIllIlII, String lllllllllllllllIllllIlIllIllIIll, MethodType lllllllllllllllIllllIlIllIllIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIlIllIlllIlI = lIllIlIlIIIIIl[Integer.parseInt(lllllllllllllllIllllIlIllIllIIll)].split(lIllIlIlIIlllI[lIllIlIlIlIIII[0]]);
      Class<?> lllllllllllllllIllllIlIllIlllIIl = Class.forName(lllllllllllllllIllllIlIllIlllIlI[lIllIlIlIlIIII[0]]);
      String lllllllllllllllIllllIlIllIlllIII = lllllllllllllllIllllIlIllIlllIlI[lIllIlIlIlIIII[1]];
      MethodHandle lllllllllllllllIllllIlIllIllIlll = null;
      int lllllllllllllllIllllIlIllIllIllI = lllllllllllllllIllllIlIllIlllIlI[lIllIlIlIlIIII[2]].length();
      if (llllIIlllIIllIl(lllllllllllllllIllllIlIllIllIllI, lIllIlIlIlIIII[3])) {
        MethodType lllllllllllllllIllllIlIllIllllII = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlIllIlllIlI[lIllIlIlIlIIII[3]], av.class.getClassLoader());
        if (llllIIlllIIllII(lllllllllllllllIllllIlIllIllIllI, lIllIlIlIlIIII[3])) {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findVirtual(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIllllII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findStatic(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIllllII);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIlIllIlllIll = lIllIlIlIIIIlI[Integer.parseInt(lllllllllllllllIllllIlIllIlllIlI[lIllIlIlIlIIII[3]])];
        if (llllIIlllIIllII(lllllllllllllllIllllIlIllIllIllI, lIllIlIlIlIIII[2])) {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findGetter(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIlllIll);
          "".length();
          if (" ".length() << " ".length() == (((0x63 ^ 0x7A) << " ".length() << " ".length() ^ 0x3B ^ 0x16) & ((0xA ^ 0x3F) << " ".length() ^ 0xE1 ^ 0xC2 ^ -" ".length())))
            return null; 
        } else if (llllIIlllIIllII(lllllllllllllllIllllIlIllIllIllI, lIllIlIlIlIIII[4])) {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findStaticGetter(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIlllIll);
          "".length();
          if (" ".length() << " ".length() << " ".length() < -" ".length())
            return null; 
        } else if (llllIIlllIIllII(lllllllllllllllIllllIlIllIllIllI, lIllIlIlIlIIII[5])) {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findSetter(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIlllIll);
          "".length();
          if (((0x91 ^ 0xBA) << " ".length() & ((0x85 ^ 0xAE) << " ".length() ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIllllIlIllIllIlll = lllllllllllllllIllllIlIllIllIlII.findStaticSetter(lllllllllllllllIllllIlIllIlllIIl, lllllllllllllllIllllIlIllIlllIII, lllllllllllllllIllllIlIllIlllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIlIllIllIlll);
    } catch (Exception lllllllllllllllIllllIlIllIllIlIl) {
      lllllllllllllllIllllIlIllIllIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlllIIIIlI() {
    lIllIlIlIIIIIl = new String[lIllIlIlIlIIII[6]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[7]] = lIllIlIlIIlllI[lIllIlIlIlIIII[1]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[0]] = lIllIlIlIIlllI[lIllIlIlIlIIII[3]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[5]] = lIllIlIlIIlllI[lIllIlIlIlIIII[2]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[8]] = lIllIlIlIIlllI[lIllIlIlIlIIII[4]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[9]] = lIllIlIlIIlllI[lIllIlIlIlIIII[5]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[10]] = lIllIlIlIIlllI[lIllIlIlIlIIII[11]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[12]] = lIllIlIlIIlllI[lIllIlIlIlIIII[13]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[1]] = lIllIlIlIIlllI[lIllIlIlIlIIII[14]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[3]] = lIllIlIlIIlllI[lIllIlIlIlIIII[7]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[15]] = lIllIlIlIIlllI[lIllIlIlIlIIII[16]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[2]] = lIllIlIlIIlllI[lIllIlIlIlIIII[12]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[17]] = lIllIlIlIIlllI[lIllIlIlIlIIII[9]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[13]] = lIllIlIlIIlllI[lIllIlIlIlIIII[17]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[16]] = lIllIlIlIIlllI[lIllIlIlIlIIII[18]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[4]] = lIllIlIlIIlllI[lIllIlIlIlIIII[19]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[20]] = lIllIlIlIIlllI[lIllIlIlIlIIII[8]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[18]] = lIllIlIlIIlllI[lIllIlIlIlIIII[15]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[11]] = lIllIlIlIIlllI[lIllIlIlIlIIII[20]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[21]] = lIllIlIlIIlllI[lIllIlIlIlIIII[21]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[22]] = lIllIlIlIIlllI[lIllIlIlIlIIII[22]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[14]] = lIllIlIlIIlllI[lIllIlIlIlIIII[10]];
    lIllIlIlIIIIIl[lIllIlIlIlIIII[19]] = lIllIlIlIIlllI[lIllIlIlIlIIII[6]];
    lIllIlIlIIIIlI = new Class[lIllIlIlIlIIII[11]];
    lIllIlIlIIIIlI[lIllIlIlIlIIII[5]] = WorldClient.class;
    lIllIlIlIIIIlI[lIllIlIlIlIIII[0]] = Minecraft.class;
    lIllIlIlIIIIlI[lIllIlIlIlIIII[2]] = av.class;
    lIllIlIlIIIIlI[lIllIlIlIlIIII[3]] = f9.class;
    lIllIlIlIIIIlI[lIllIlIlIlIIII[4]] = EntityPlayerSP.class;
    lIllIlIlIIIIlI[lIllIlIlIlIIII[1]] = ArrayList.class;
  }
  
  private static void llllIIlllIIIllI() {
    lIllIlIlIIlllI = new String[lIllIlIlIlIIII[23]];
    lIllIlIlIIlllI[lIllIlIlIlIIII[0]] = llllIIlllIIIIll(lIllIlIlIIllll[lIllIlIlIlIIII[0]], lIllIlIlIIllll[lIllIlIlIlIIII[1]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[1]] = llllIIlllIIIlII(lIllIlIlIIllll[lIllIlIlIlIIII[3]], lIllIlIlIIllll[lIllIlIlIlIIII[2]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[3]] = llllIIlllIIIlIl(lIllIlIlIIllll[lIllIlIlIlIIII[4]], lIllIlIlIIllll[lIllIlIlIlIIII[5]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[2]] = llllIIlllIIIlIl(lIllIlIlIIllll[lIllIlIlIlIIII[11]], lIllIlIlIIllll[lIllIlIlIlIIII[13]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[4]] = llllIIlllIIIIll(lIllIlIlIIllll[lIllIlIlIlIIII[14]], lIllIlIlIIllll[lIllIlIlIlIIII[7]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[5]] = llllIIlllIIIlII(lIllIlIlIIllll[lIllIlIlIlIIII[16]], lIllIlIlIIllll[lIllIlIlIlIIII[12]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[11]] = llllIIlllIIIlIl(lIllIlIlIIllll[lIllIlIlIlIIII[9]], lIllIlIlIIllll[lIllIlIlIlIIII[17]]);
    lIllIlIlIIlllI[lIllIlIlIlIIII[13]] = llllIIlllIIIIll("MxAmNF41ED4yXgoFIjwePks1JAU4HSMcFzceIjAzOAI1b1gVGzEjEXYdMTsXdiIkJxk3Fmt8KmNRcA==", "YqPUp");
    lIllIlIlIIlllI[lIllIlIlIlIIII[14]] = llllIIlllIIIlII("iPn81LKY3/GUAI+F/GSnyj60eUt4YuQBizR63S6gg6s=", "PsyAe");
    lIllIlIlIIlllI[lIllIlIlIlIIII[7]] = llllIIlllIIIIll("ODRcICAgIRsnMDo2XDE8JX8TJW44PhYmODAiSGJudXFSc3Q=", "UQrST");
    lIllIlIlIIlllI[lIllIlIlIlIIII[16]] = llllIIlllIIIlIl("vK4oWl6qxAiSrHndx0xLFOB7sajmTOb5BvxwghdX6ZdiDUv2StL0gBQEWpk99fuQ6ZlftBA40zA=", "KVPmq");
    lIllIlIlIIlllI[lIllIlIlIlIIII[12]] = llllIIlllIIIlII("Kgv6aBG5tqdOCE8wNyT3G2QEKkipLZUb6A1WoroJLW9Wy58bo/YMEQ==", "dNKQH");
    lIllIlIlIIlllI[lIllIlIlIlIIII[9]] = llllIIlllIIIIll("BTxgHgYdKScZFgc+YA8aGHcvG0gFOnRdSEh5bg==", "hYNmr");
    lIllIlIlIIlllI[lIllIlIlIlIIII[17]] = llllIIlllIIIIll("HDIVBEgDJwoJSDchEQQfOjoQEVwfJwYXBwI8EV9OXx8JBBAXfBYRDxp8KhEDBDIXChRNaUNF", "vScef");
    lIllIlIlIIlllI[lIllIlIlIlIIII[18]] = llllIIlllIIIlII("mNWaJiBa1N73MMtBB1pB0nH/OLm6hA5eGCKRC0xFL2HLW9VfR6R0RsFvKqnWY3Bmehp5m6uU42o=", "RjJHP");
    lIllIlIlIIlllI[lIllIlIlIlIIII[19]] = llllIIlllIIIIll("ATUbJ2MeIAQqYyomHyc0Jz0eMncKMAl8ZSc+DDAsRDgMKCpEGw8sKAggVm8XUXRN", "kTmFM");
    lIllIlIlIIlllI[lIllIlIlIlIIII[8]] = llllIIlllIIIlIl("Ne/ECVHHX5IWNQENRwiDjRr+KtzMiYxTVJqpeN891qyHaLFn6xWObwzRH//PKRgA", "iBlDu");
    lIllIlIlIIlllI[lIllIlIlIlIIII[15]] = llllIIlllIIIIll("NBEAeywzGhE2MzsSAHsiNh0ROzV0OR07JDkGFTM1YBIdMC0+K0NkdWlNKzJ7bk5UdWE=", "ZttUA");
    lIllIlIlIIlllI[lIllIlIlIlIIII[20]] = llllIIlllIIIIll("Bz1LHS0fKAwaPQU/SwwxGnYDV2MHNwEbNQ8VBAA4DT0XVGpQeEVO", "jXenY");
    lIllIlIlIIlllI[lIllIlIlIlIIII[21]] = llllIIlllIIIIll("Ijd6Jxg6Ij0gCCA1ejYEP3w1IVYoNyAfCTZofH0ldXJ0", "ORTTl");
    lIllIlIlIIlllI[lIllIlIlIlIIII[22]] = llllIIlllIIIlIl("UD080BrK43H8ejwEAsNfOYIEM1Q5HVD/ZKbLzZrakeTUjlfyAq0ieMG75q/5/4+K", "uNHEv");
    lIllIlIlIIlllI[lIllIlIlIlIIII[10]] = llllIIlllIIIIll("PDcDJ2UjIhwqZR8iEDQqIjkHfCM3JTsjMyJsXW8RbHZV", "VVuFK");
    lIllIlIlIIlllI[lIllIlIlIlIIII[6]] = llllIIlllIIIlII("KkO4r6pvDg5QNPMdmyuWEUu2a05HHCcoAQ7qZwTpqmq5h+QrOC1V8g==", "HvXth");
    lIllIlIlIIllll = null;
  }
  
  private static void llllIIlllIIIlll() {
    String str = (new Exception()).getStackTrace()[lIllIlIlIlIIII[0]].getFileName();
    lIllIlIlIIllll = str.substring(str.indexOf("ä") + lIllIlIlIlIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIlllIIIlII(String lllllllllllllllIllllIlIllIlIlllI, String lllllllllllllllIllllIlIllIlIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIllIllIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIllIlIllIl.getBytes(StandardCharsets.UTF_8)), lIllIlIlIlIIII[14]), "DES");
      Cipher lllllllllllllllIllllIlIllIllIIII = Cipher.getInstance("DES");
      lllllllllllllllIllllIlIllIllIIII.init(lIllIlIlIlIIII[3], lllllllllllllllIllllIlIllIllIIIl);
      return new String(lllllllllllllllIllllIlIllIllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIllIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIllIlIllll) {
      lllllllllllllllIllllIlIllIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIlllIIIIll(String lllllllllllllllIllllIlIllIlIlIll, String lllllllllllllllIllllIlIllIlIlIlI) {
    lllllllllllllllIllllIlIllIlIlIll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIlIllIlIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIlIllIlIlIIl = new StringBuilder();
    char[] lllllllllllllllIllllIlIllIlIlIII = lllllllllllllllIllllIlIllIlIlIlI.toCharArray();
    int lllllllllllllllIllllIlIllIlIIlll = lIllIlIlIlIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIlIllIlIlIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIlIlIlIIII[0];
    while (llllIIlllIIlllI(j, i)) {
      char lllllllllllllllIllllIlIllIlIllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIlIllIlIIlll++;
      j++;
      "".length();
      if (" ".length() >= "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIlIllIlIlIIl);
  }
  
  private static String llllIIlllIIIlIl(String lllllllllllllllIllllIlIllIlIIIll, String lllllllllllllllIllllIlIllIlIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllllIlIllIlIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlIllIlIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIlIllIlIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIlIllIlIIlIl.init(lIllIlIlIlIIII[3], lllllllllllllllIllllIlIllIlIIllI);
      return new String(lllllllllllllllIllllIlIllIlIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlIllIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIlIllIlIIlII) {
      lllllllllllllllIllllIlIllIlIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIlllIIlIII() {
    lIllIlIlIlIIII = new int[24];
    lIllIlIlIlIIII[0] = (0xB9 ^ 0xBE) & (0x66 ^ 0x61 ^ 0xFFFFFFFF);
    lIllIlIlIlIIII[1] = " ".length();
    lIllIlIlIlIIII[2] = "   ".length();
    lIllIlIlIlIIII[3] = " ".length() << " ".length();
    lIllIlIlIlIIII[4] = " ".length() << " ".length() << " ".length();
    lIllIlIlIlIIII[5] = (0x29 ^ 0x48) << " ".length() ^ 71 + 44 - -4 + 80;
    lIllIlIlIlIIII[6] = (0x70 ^ 0x7B) << " ".length();
    lIllIlIlIlIIII[7] = (0x19 ^ 0x24) << " ".length() ^ 0xF2 ^ 0x81;
    lIllIlIlIlIIII[8] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllIlIlIlIIII[9] = "   ".length() << " ".length() << " ".length();
    lIllIlIlIlIIII[10] = 0x5C ^ 0x7B ^ (0x84 ^ 0x9D) << " ".length();
    lIllIlIlIlIIII[11] = "   ".length() << " ".length();
    lIllIlIlIlIIII[12] = 0x64 ^ 0x6F;
    lIllIlIlIlIIII[13] = 82 + 100 - 138 + 93 ^ (0x4E ^ 0x9) << " ".length();
    lIllIlIlIlIIII[14] = " ".length() << "   ".length();
    lIllIlIlIlIIII[15] = 0x7F ^ 0x6E;
    lIllIlIlIlIIII[16] = (0xF ^ 0xA) << " ".length();
    lIllIlIlIlIIII[17] = 0x76 ^ 0x7B;
    lIllIlIlIlIIII[18] = (0x84 ^ 0x83) << " ".length();
    lIllIlIlIlIIII[19] = 0x90 ^ 0x9F;
    lIllIlIlIlIIII[20] = (0x1A ^ 0x13) << " ".length();
    lIllIlIlIlIIII[21] = (0xFB ^ 0xA0) << " ".length() ^ 76 + 116 - 131 + 104;
    lIllIlIlIlIIII[22] = ((0x35 ^ 0x30) << "   ".length() ^ 0x93 ^ 0xBE) << " ".length() << " ".length();
    lIllIlIlIlIIII[23] = 108 + 62 - 12 + 25 ^ (0x74 ^ 0x71) << (0xE ^ 0xB);
  }
  
  private static boolean llllIIlllIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIlllIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIlllIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIIlllIIlIlI(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean llllIIlllIIlIll(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllIIlllIIlIIl(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\av.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */