package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class f8 extends au {
  f100000000000000000000.Integer delay;
  
  f100000000000000000000.Double range;
  
  f100000000000000000000.Boolean render;
  
  f100000000000000000000.ColorSetting color;
  
  private int playerHotbarSlot;
  
  private int lastHotbarSlot;
  
  private EntityPlayer closestTarget;
  
  private String lastTickTargetName;
  
  private int bedSlot;
  
  private BlockPos placeTarget;
  
  private float rotVar;
  
  private int blocksPlaced;
  
  private double diffXZ;
  
  private boolean firstRun;
  
  private boolean nowTop;
  
  @EventHandler
  public Listener<RenderWorldLastEvent> listener;
  
  private static String[] lIllllIIllIIII;
  
  private static Class[] lIllllIIllIIIl;
  
  private static final String[] llIIIIIIIlllll;
  
  private static String[] llIIIIIIlIIIll;
  
  private static final int[] llIIIIIIlIIlII;
  
  public f8() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/zero/alpine/listener/Listener
    //   45: dup
    //   46: aload_0
    //   47: <illegal opcode> invoke : (Lme/stupitdog/bhp/f8;)Lme/zero/alpine/listener/EventHook;
    //   52: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   55: iconst_0
    //   56: iaload
    //   57: anewarray java/util/function/Predicate
    //   60: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   63: <illegal opcode> 1 : (Lme/stupitdog/bhp/f8;Lme/zero/alpine/listener/Listener;)V
    //   68: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	69	0	lllllllllllllllIllIlllIlllIIIlIl	Lme/stupitdog/bhp/f8;
  }
  
  public void setup() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   5: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   8: iconst_3
    //   9: iaload
    //   10: aaload
    //   11: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   14: iconst_4
    //   15: iaload
    //   16: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   19: iconst_1
    //   20: iaload
    //   21: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   24: iconst_4
    //   25: iaload
    //   26: <illegal opcode> 2 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;III)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   31: <illegal opcode> 3 : (Lme/stupitdog/bhp/f8;Lme/stupitdog/bhp/f100000000000000000000$Integer;)V
    //   36: aload_0
    //   37: aload_0
    //   38: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   41: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   44: iconst_5
    //   45: iaload
    //   46: aaload
    //   47: ldc2_w 4.4
    //   50: dconst_0
    //   51: ldc2_w 6.0
    //   54: <illegal opcode> 4 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;DDD)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   59: <illegal opcode> 5 : (Lme/stupitdog/bhp/f8;Lme/stupitdog/bhp/f100000000000000000000$Double;)V
    //   64: aload_0
    //   65: aload_0
    //   66: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   69: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   72: bipush #6
    //   74: iaload
    //   75: aaload
    //   76: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   79: iconst_1
    //   80: iaload
    //   81: <illegal opcode> 6 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;Z)Lme/stupitdog/bhp/f100000000000000000000$Boolean;
    //   86: <illegal opcode> 7 : (Lme/stupitdog/bhp/f8;Lme/stupitdog/bhp/f100000000000000000000$Boolean;)V
    //   91: aload_0
    //   92: aload_0
    //   93: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   96: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   99: bipush #7
    //   101: iaload
    //   102: aaload
    //   103: new me/stupitdog/bhp/f01
    //   106: dup
    //   107: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   110: bipush #8
    //   112: iaload
    //   113: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   116: bipush #8
    //   118: iaload
    //   119: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   122: bipush #8
    //   124: iaload
    //   125: invokespecial <init> : (III)V
    //   128: <illegal opcode> 8 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;Lme/stupitdog/bhp/f01;)Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;
    //   133: <illegal opcode> 9 : (Lme/stupitdog/bhp/f8;Lme/stupitdog/bhp/f100000000000000000000$ColorSetting;)V
    //   138: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	139	0	lllllllllllllllIllIlllIlllIIIlII	Lme/stupitdog/bhp/f8;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIIlIIllllII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 23
    //   16: aload_0
    //   17: <illegal opcode> 12 : (Lme/stupitdog/bhp/f8;)V
    //   22: return
    //   23: aload_0
    //   24: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   27: iconst_1
    //   28: iaload
    //   29: <illegal opcode> 13 : (Lme/stupitdog/bhp/f8;Z)V
    //   34: aload_0
    //   35: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   38: iconst_0
    //   39: iaload
    //   40: <illegal opcode> 14 : (Lme/stupitdog/bhp/f8;I)V
    //   45: aload_0
    //   46: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   51: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   56: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   61: <illegal opcode> 16 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   66: <illegal opcode> 17 : (Lme/stupitdog/bhp/f8;I)V
    //   71: aload_0
    //   72: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   75: bipush #9
    //   77: iaload
    //   78: <illegal opcode> 18 : (Lme/stupitdog/bhp/f8;I)V
    //   83: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	84	0	lllllllllllllllIllIlllIlllIIIIll	Lme/stupitdog/bhp/f8;
  }
  
  public void onDisable() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIIlIIllllII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 17
    //   16: return
    //   17: aload_0
    //   18: <illegal opcode> 19 : (Lme/stupitdog/bhp/f8;)I
    //   23: aload_0
    //   24: <illegal opcode> 20 : (Lme/stupitdog/bhp/f8;)I
    //   29: invokestatic lIIIIIIlIIlllllI : (II)Z
    //   32: ifeq -> 77
    //   35: aload_0
    //   36: <illegal opcode> 20 : (Lme/stupitdog/bhp/f8;)I
    //   41: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   44: bipush #9
    //   46: iaload
    //   47: invokestatic lIIIIIIlIIlllllI : (II)Z
    //   50: ifeq -> 77
    //   53: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   58: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   63: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   68: aload_0
    //   69: <illegal opcode> 20 : (Lme/stupitdog/bhp/f8;)I
    //   74: putfield field_70461_c : I
    //   77: aload_0
    //   78: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   81: bipush #9
    //   83: iaload
    //   84: <illegal opcode> 17 : (Lme/stupitdog/bhp/f8;I)V
    //   89: aload_0
    //   90: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   93: bipush #9
    //   95: iaload
    //   96: <illegal opcode> 18 : (Lme/stupitdog/bhp/f8;I)V
    //   101: aload_0
    //   102: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   105: iconst_0
    //   106: iaload
    //   107: <illegal opcode> 14 : (Lme/stupitdog/bhp/f8;I)V
    //   112: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	113	0	lllllllllllllllIllIlllIlllIIIIlI	Lme/stupitdog/bhp/f8;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: invokestatic lIIIIIIlIIllllII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 17
    //   16: return
    //   17: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   22: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   27: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   32: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   35: ifeq -> 59
    //   38: getstatic me/stupitdog/bhp/f8.llIIIIIIIlllll : [Ljava/lang/String;
    //   41: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   44: bipush #10
    //   46: iaload
    //   47: aaload
    //   48: <illegal opcode> 22 : (Ljava/lang/String;)V
    //   53: aload_0
    //   54: <illegal opcode> 12 : (Lme/stupitdog/bhp/f8;)V
    //   59: aload_0
    //   60: invokespecial findClosestTarget : ()V
    //   63: ldc ''
    //   65: invokevirtual length : ()I
    //   68: pop
    //   69: ldc ' '
    //   71: invokevirtual length : ()I
    //   74: ineg
    //   75: ifle -> 80
    //   78: return
    //   79: astore_1
    //   80: aload_0
    //   81: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   86: invokestatic lIIIIIIlIIllllII : (Ljava/lang/Object;)Z
    //   89: ifeq -> 136
    //   92: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   97: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   102: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   107: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   110: ifeq -> 136
    //   113: aload_0
    //   114: <illegal opcode> 24 : (Lme/stupitdog/bhp/f8;)Z
    //   119: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   122: ifeq -> 136
    //   125: aload_0
    //   126: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   129: iconst_0
    //   130: iaload
    //   131: <illegal opcode> 13 : (Lme/stupitdog/bhp/f8;Z)V
    //   136: aload_0
    //   137: <illegal opcode> 24 : (Lme/stupitdog/bhp/f8;)Z
    //   142: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   145: ifeq -> 209
    //   148: aload_0
    //   149: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   154: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   157: ifeq -> 209
    //   160: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   165: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   170: <illegal opcode> 21 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   175: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   178: ifeq -> 209
    //   181: aload_0
    //   182: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   185: iconst_0
    //   186: iaload
    //   187: <illegal opcode> 13 : (Lme/stupitdog/bhp/f8;Z)V
    //   192: aload_0
    //   193: aload_0
    //   194: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   199: <illegal opcode> 25 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   204: <illegal opcode> 26 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;)V
    //   209: aload_0
    //   210: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   215: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   218: ifeq -> 278
    //   221: aload_0
    //   222: <illegal opcode> 27 : (Lme/stupitdog/bhp/f8;)Ljava/lang/String;
    //   227: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   230: ifeq -> 278
    //   233: aload_0
    //   234: <illegal opcode> 27 : (Lme/stupitdog/bhp/f8;)Ljava/lang/String;
    //   239: aload_0
    //   240: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   245: <illegal opcode> 25 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   250: <illegal opcode> 28 : (Ljava/lang/String;Ljava/lang/Object;)Z
    //   255: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   258: ifeq -> 278
    //   261: aload_0
    //   262: aload_0
    //   263: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   268: <illegal opcode> 25 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   273: <illegal opcode> 26 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;)V
    //   278: aload_0
    //   279: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   284: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   289: <illegal opcode> 29 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/util/math/Vec3d;
    //   294: aload_0
    //   295: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   300: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   305: <illegal opcode> 31 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)D
    //   310: <illegal opcode> 32 : (Lme/stupitdog/bhp/f8;D)V
    //   315: ldc ''
    //   317: invokevirtual length : ()I
    //   320: pop
    //   321: ldc ' '
    //   323: invokevirtual length : ()I
    //   326: ineg
    //   327: ldc ' '
    //   329: invokevirtual length : ()I
    //   332: ldc ' '
    //   334: invokevirtual length : ()I
    //   337: ldc ' '
    //   339: invokevirtual length : ()I
    //   342: ishl
    //   343: ishl
    //   344: if_icmple -> 349
    //   347: return
    //   348: astore_1
    //   349: aload_0
    //   350: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   355: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   358: ifeq -> 943
    //   361: aload_0
    //   362: aload_0
    //   363: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   368: <illegal opcode> 25 : (Lnet/minecraft/entity/player/EntityPlayer;)Ljava/lang/String;
    //   373: <illegal opcode> 33 : (Lme/stupitdog/bhp/f8;Ljava/lang/String;)V
    //   378: aload_0
    //   379: new net/minecraft/util/math/BlockPos
    //   382: dup
    //   383: aload_0
    //   384: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   389: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   394: dconst_1
    //   395: dconst_1
    //   396: dconst_0
    //   397: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   402: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   405: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   410: aload_0
    //   411: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   414: iconst_0
    //   415: iaload
    //   416: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   421: aload_0
    //   422: ldc_w 90.0
    //   425: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   430: aload_0
    //   431: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   436: astore_1
    //   437: aload_0
    //   438: aload_1
    //   439: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   442: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   445: ifeq -> 502
    //   448: aload_0
    //   449: new net/minecraft/util/math/BlockPos
    //   452: dup
    //   453: aload_0
    //   454: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   459: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   464: ldc2_w -1.0
    //   467: dconst_1
    //   468: dconst_0
    //   469: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   474: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   477: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   482: aload_0
    //   483: ldc_w -90.0
    //   486: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   491: aload_0
    //   492: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   495: iconst_0
    //   496: iaload
    //   497: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   502: aload_0
    //   503: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   508: astore_2
    //   509: aload_0
    //   510: aload_2
    //   511: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   514: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   517: ifeq -> 572
    //   520: aload_0
    //   521: new net/minecraft/util/math/BlockPos
    //   524: dup
    //   525: aload_0
    //   526: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   531: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   536: dconst_0
    //   537: dconst_1
    //   538: dconst_1
    //   539: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   544: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   547: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   552: aload_0
    //   553: ldc_w 180.0
    //   556: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   561: aload_0
    //   562: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   565: iconst_0
    //   566: iaload
    //   567: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   572: aload_0
    //   573: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   578: astore_3
    //   579: aload_0
    //   580: aload_3
    //   581: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   584: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   587: ifeq -> 642
    //   590: aload_0
    //   591: new net/minecraft/util/math/BlockPos
    //   594: dup
    //   595: aload_0
    //   596: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   601: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   606: dconst_0
    //   607: dconst_1
    //   608: ldc2_w -1.0
    //   611: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   616: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   619: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   624: aload_0
    //   625: fconst_0
    //   626: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   631: aload_0
    //   632: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   635: iconst_0
    //   636: iaload
    //   637: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   642: aload_0
    //   643: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   648: astore #4
    //   650: aload_0
    //   651: aload #4
    //   653: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   656: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   659: ifeq -> 716
    //   662: aload_0
    //   663: new net/minecraft/util/math/BlockPos
    //   666: dup
    //   667: aload_0
    //   668: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   673: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   678: dconst_0
    //   679: ldc2_w 2.0
    //   682: ldc2_w -1.0
    //   685: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   690: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   693: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   698: aload_0
    //   699: fconst_0
    //   700: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   705: aload_0
    //   706: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   709: iconst_1
    //   710: iaload
    //   711: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   716: aload_0
    //   717: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   722: astore #5
    //   724: aload_0
    //   725: <illegal opcode> 39 : (Lme/stupitdog/bhp/f8;)Z
    //   730: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   733: ifeq -> 793
    //   736: aload_0
    //   737: aload #5
    //   739: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   742: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   745: ifeq -> 793
    //   748: aload_0
    //   749: new net/minecraft/util/math/BlockPos
    //   752: dup
    //   753: aload_0
    //   754: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   759: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   764: ldc2_w -1.0
    //   767: ldc2_w 2.0
    //   770: dconst_0
    //   771: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   776: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   779: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   784: aload_0
    //   785: ldc_w -90.0
    //   788: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   793: aload_0
    //   794: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   799: astore #6
    //   801: aload_0
    //   802: <illegal opcode> 39 : (Lme/stupitdog/bhp/f8;)Z
    //   807: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   810: ifeq -> 868
    //   813: aload_0
    //   814: aload #6
    //   816: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   819: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   822: ifeq -> 868
    //   825: aload_0
    //   826: new net/minecraft/util/math/BlockPos
    //   829: dup
    //   830: aload_0
    //   831: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   836: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   841: dconst_0
    //   842: ldc2_w 2.0
    //   845: dconst_1
    //   846: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   851: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   854: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   859: aload_0
    //   860: ldc_w 180.0
    //   863: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   868: aload_0
    //   869: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   874: astore #7
    //   876: aload_0
    //   877: <illegal opcode> 39 : (Lme/stupitdog/bhp/f8;)Z
    //   882: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   885: ifeq -> 943
    //   888: aload_0
    //   889: aload #7
    //   891: invokespecial canPlaceBed : (Lnet/minecraft/util/math/BlockPos;)Z
    //   894: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   897: ifeq -> 943
    //   900: aload_0
    //   901: new net/minecraft/util/math/BlockPos
    //   904: dup
    //   905: aload_0
    //   906: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   911: <illegal opcode> 30 : (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/util/math/Vec3d;
    //   916: dconst_1
    //   917: ldc2_w 2.0
    //   920: dconst_0
    //   921: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   926: invokespecial <init> : (Lnet/minecraft/util/math/Vec3d;)V
    //   929: <illegal opcode> 35 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/util/math/BlockPos;)V
    //   934: aload_0
    //   935: ldc_w 90.0
    //   938: <illegal opcode> 37 : (Lme/stupitdog/bhp/f8;F)V
    //   943: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   948: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   953: <illegal opcode> 41 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   958: <illegal opcode> 42 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   963: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   968: <illegal opcode> 43 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   973: aload_0
    //   974: <illegal opcode> test : (Lme/stupitdog/bhp/f8;)Ljava/util/function/Predicate;
    //   979: <illegal opcode> 43 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   984: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   989: <illegal opcode> 44 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   994: <illegal opcode> 45 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/stream/Stream;
    //   999: <illegal opcode> accept : ()Ljava/util/function/Consumer;
    //   1004: <illegal opcode> 46 : (Ljava/util/stream/Stream;Ljava/util/function/Consumer;)V
    //   1009: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1014: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1019: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   1024: aload_0
    //   1025: <illegal opcode> 48 : (Lme/stupitdog/bhp/f8;)Lme/stupitdog/bhp/f100000000000000000000$Integer;
    //   1030: <illegal opcode> 49 : (Lme/stupitdog/bhp/f100000000000000000000$Integer;)I
    //   1035: irem
    //   1036: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   1039: ifeq -> 1089
    //   1042: aload_0
    //   1043: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   1048: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   1051: ifeq -> 1089
    //   1054: aload_0
    //   1055: invokespecial findBeds : ()V
    //   1058: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   1063: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1068: astore_1
    //   1069: aload_1
    //   1070: dup
    //   1071: <illegal opcode> 47 : (Lnet/minecraft/client/entity/EntityPlayerSP;)I
    //   1076: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   1079: iconst_1
    //   1080: iaload
    //   1081: iadd
    //   1082: putfield field_70173_aa : I
    //   1085: aload_0
    //   1086: invokespecial doDaMagic : ()V
    //   1089: ldc ''
    //   1091: invokevirtual length : ()I
    //   1094: pop
    //   1095: sipush #157
    //   1098: sipush #152
    //   1101: ixor
    //   1102: ineg
    //   1103: iflt -> 1114
    //   1106: return
    //   1107: astore_1
    //   1108: aload_1
    //   1109: <illegal opcode> 50 : (Ljava/lang/NullPointerException;)V
    //   1114: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   437	506	1	lllllllllllllllIllIlllIllIlllIlI	Lnet/minecraft/util/math/BlockPos;
    //   509	434	2	lllllllllllllllIllIlllIllIlllIIl	Lnet/minecraft/util/math/BlockPos;
    //   579	364	3	lllllllllllllllIllIlllIllIllIlll	Lnet/minecraft/util/math/BlockPos;
    //   650	293	4	lllllllllllllllIllIlllIllIllIllI	Lnet/minecraft/util/math/BlockPos;
    //   724	219	5	lllllllllllllllIllIlllIllIllIlII	Lnet/minecraft/util/math/BlockPos;
    //   801	142	6	lllllllllllllllIllIlllIllIllIIlI	Lnet/minecraft/util/math/BlockPos;
    //   876	67	7	lllllllllllllllIllIlllIllIllIIIl	Lnet/minecraft/util/math/BlockPos;
    //   1069	20	1	lllllllllllllllIllIlllIllIlIllll	Lnet/minecraft/client/entity/EntityPlayerSP;
    //   1108	6	1	lllllllllllllllIllIlllIllIlIllIl	Ljava/lang/NullPointerException;
    //   0	1115	0	lllllllllllllllIllIlllIllIlIllII	Lme/stupitdog/bhp/f8;
    // Exception table:
    //   from	to	target	type
    //   59	63	79	java/lang/NullPointerException
    //   278	315	348	java/lang/NullPointerException
    //   349	1089	1107	java/lang/NullPointerException
  }
  
  private void doDaMagic() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 51 : (Lme/stupitdog/bhp/f8;)D
    //   6: aload_0
    //   7: <illegal opcode> 52 : (Lme/stupitdog/bhp/f8;)Lme/stupitdog/bhp/f100000000000000000000$Double;
    //   12: <illegal opcode> 53 : (Lme/stupitdog/bhp/f100000000000000000000$Double;)D
    //   17: invokestatic lIIIIIIlIlIIIlIl : (DD)I
    //   20: invokestatic lIIIIIIlIlIIIlll : (I)Z
    //   23: ifeq -> 462
    //   26: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   29: iconst_0
    //   30: iaload
    //   31: istore_1
    //   32: iload_1
    //   33: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   36: bipush #11
    //   38: iaload
    //   39: invokestatic lIIIIIIlIlIIlIII : (II)Z
    //   42: ifeq -> 196
    //   45: aload_0
    //   46: <illegal opcode> 54 : (Lme/stupitdog/bhp/f8;)I
    //   51: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   54: bipush #9
    //   56: iaload
    //   57: invokestatic lIIIIIIlIIlllllI : (II)Z
    //   60: ifeq -> 74
    //   63: ldc ''
    //   65: invokevirtual length : ()I
    //   68: pop
    //   69: aconst_null
    //   70: ifnull -> 196
    //   73: return
    //   74: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   79: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   84: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   89: iload_1
    //   90: <illegal opcode> 55 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   95: astore_2
    //   96: aload_2
    //   97: <illegal opcode> 56 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   102: instanceof net/minecraft/item/ItemBed
    //   105: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   108: ifeq -> 182
    //   111: aload_0
    //   112: iload_1
    //   113: dup_x1
    //   114: <illegal opcode> 57 : (Lme/stupitdog/bhp/f8;I)V
    //   119: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   122: bipush #9
    //   124: iaload
    //   125: invokestatic lIIIIIIlIIlllllI : (II)Z
    //   128: ifeq -> 196
    //   131: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   136: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   141: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   146: aload_0
    //   147: <illegal opcode> 54 : (Lme/stupitdog/bhp/f8;)I
    //   152: putfield field_70461_c : I
    //   155: ldc ''
    //   157: invokevirtual length : ()I
    //   160: pop
    //   161: ldc ' '
    //   163: invokevirtual length : ()I
    //   166: ldc ' '
    //   168: invokevirtual length : ()I
    //   171: ishl
    //   172: ldc ' '
    //   174: invokevirtual length : ()I
    //   177: ineg
    //   178: if_icmpgt -> 196
    //   181: return
    //   182: iinc #1, 1
    //   185: ldc ''
    //   187: invokevirtual length : ()I
    //   190: pop
    //   191: aconst_null
    //   192: ifnull -> 32
    //   195: return
    //   196: aload_0
    //   197: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   200: bipush #9
    //   202: iaload
    //   203: <illegal opcode> 57 : (Lme/stupitdog/bhp/f8;I)V
    //   208: aload_0
    //   209: <illegal opcode> 58 : (Lme/stupitdog/bhp/f8;)I
    //   214: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   217: ifeq -> 451
    //   220: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   225: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   230: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   235: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   240: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   245: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   250: <illegal opcode> 16 : (Lnet/minecraft/entity/player/InventoryPlayer;)I
    //   255: <illegal opcode> 55 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   260: <illegal opcode> 56 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   265: instanceof net/minecraft/item/ItemBed
    //   268: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   271: ifeq -> 451
    //   274: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   279: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   284: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   289: new net/minecraft/network/play/client/CPacketEntityAction
    //   292: dup
    //   293: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   298: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   303: <illegal opcode> 60 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   308: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   311: <illegal opcode> 61 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   316: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   321: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   326: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   331: new net/minecraft/network/play/client/CPacketPlayer$Rotation
    //   334: dup
    //   335: aload_0
    //   336: <illegal opcode> 62 : (Lme/stupitdog/bhp/f8;)F
    //   341: fconst_0
    //   342: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   347: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   352: <illegal opcode> 63 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Z
    //   357: invokespecial <init> : (FFZ)V
    //   360: <illegal opcode> 61 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   365: aload_0
    //   366: new net/minecraft/util/math/BlockPos
    //   369: dup
    //   370: aload_0
    //   371: <illegal opcode> 38 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/util/math/BlockPos;
    //   376: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   379: <illegal opcode> 64 : ()Lnet/minecraft/util/EnumFacing;
    //   384: invokespecial placeBlock : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V
    //   387: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   392: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   397: <illegal opcode> 59 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/client/network/NetHandlerPlayClient;
    //   402: new net/minecraft/network/play/client/CPacketEntityAction
    //   405: dup
    //   406: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   411: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   416: <illegal opcode> 65 : ()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
    //   421: invokespecial <init> : (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
    //   424: <illegal opcode> 61 : (Lnet/minecraft/client/network/NetHandlerPlayClient;Lnet/minecraft/network/Packet;)V
    //   429: aload_0
    //   430: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   433: iconst_1
    //   434: iaload
    //   435: <illegal opcode> 14 : (Lme/stupitdog/bhp/f8;I)V
    //   440: aload_0
    //   441: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   444: iconst_0
    //   445: iaload
    //   446: <illegal opcode> 36 : (Lme/stupitdog/bhp/f8;Z)V
    //   451: aload_0
    //   452: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   455: iconst_0
    //   456: iaload
    //   457: <illegal opcode> 14 : (Lme/stupitdog/bhp/f8;I)V
    //   462: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   96	89	2	lllllllllllllllIllIlllIllIlIIIII	Lnet/minecraft/item/ItemStack;
    //   32	430	1	lllllllllllllllIllIlllIllIIlllll	I
    //   0	463	0	lllllllllllllllIllIlllIllIIllllI	Lme/stupitdog/bhp/f8;
  }
  
  private void findBeds() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 66 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   10: invokestatic lIIIIIIlIlIIIlII : (Ljava/lang/Object;)Z
    //   13: ifeq -> 35
    //   16: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   21: <illegal opcode> 66 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   26: instanceof net/minecraft/client/gui/inventory/GuiContainer
    //   29: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   32: ifeq -> 289
    //   35: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   40: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   45: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   50: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   53: iconst_0
    //   54: iaload
    //   55: <illegal opcode> 55 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   60: <illegal opcode> 56 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   65: <illegal opcode> 67 : ()Lnet/minecraft/item/Item;
    //   70: invokestatic lIIIIIIlIlIIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   73: ifeq -> 289
    //   76: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   79: bipush #11
    //   81: iaload
    //   82: istore_1
    //   83: iload_1
    //   84: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   87: bipush #12
    //   89: iaload
    //   90: invokestatic lIIIIIIlIlIIlIII : (II)Z
    //   93: ifeq -> 289
    //   96: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   101: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   106: <illegal opcode> 15 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   111: iload_1
    //   112: <illegal opcode> 55 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   117: <illegal opcode> 56 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   122: <illegal opcode> 67 : ()Lnet/minecraft/item/Item;
    //   127: invokestatic lIIIIIIlIlIIlIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   130: ifeq -> 270
    //   133: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   138: <illegal opcode> 68 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   143: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   148: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   153: <illegal opcode> 69 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   158: <illegal opcode> 70 : (Lnet/minecraft/inventory/Container;)I
    //   163: iload_1
    //   164: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   167: iconst_0
    //   168: iaload
    //   169: <illegal opcode> 71 : ()Lnet/minecraft/inventory/ClickType;
    //   174: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   179: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   184: <illegal opcode> 72 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
    //   189: ldc ''
    //   191: invokevirtual length : ()I
    //   194: pop2
    //   195: ldc ''
    //   197: invokevirtual length : ()I
    //   200: pop
    //   201: sipush #215
    //   204: sipush #132
    //   207: ixor
    //   208: ldc ' '
    //   210: invokevirtual length : ()I
    //   213: ishl
    //   214: bipush #42
    //   216: bipush #75
    //   218: iadd
    //   219: bipush #98
    //   221: isub
    //   222: bipush #124
    //   224: iadd
    //   225: ixor
    //   226: ldc ' '
    //   228: invokevirtual length : ()I
    //   231: ishl
    //   232: sipush #156
    //   235: sipush #149
    //   238: ixor
    //   239: ldc_w '   '
    //   242: invokevirtual length : ()I
    //   245: ishl
    //   246: bipush #15
    //   248: bipush #110
    //   250: ixor
    //   251: ixor
    //   252: ldc ' '
    //   254: invokevirtual length : ()I
    //   257: ishl
    //   258: ldc ' '
    //   260: invokevirtual length : ()I
    //   263: ineg
    //   264: ixor
    //   265: iand
    //   266: ifge -> 289
    //   269: return
    //   270: iinc #1, 1
    //   273: ldc ''
    //   275: invokevirtual length : ()I
    //   278: pop
    //   279: ldc_w '   '
    //   282: invokevirtual length : ()I
    //   285: ifge -> 83
    //   288: return
    //   289: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   83	206	1	lllllllllllllllIllIlllIllIIlllIl	I
    //   0	290	0	lllllllllllllllIllIlllIllIIlllII	Lme/stupitdog/bhp/f8;
  }
  
  private boolean canPlaceBed(BlockPos lllllllllllllllIllIlllIllIIllIII) {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: aload_1
    //   11: <illegal opcode> 73 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   16: <illegal opcode> 74 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   21: <illegal opcode> 75 : ()Lnet/minecraft/block/Block;
    //   26: invokestatic lIIIIIIlIlIIlIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   29: ifeq -> 64
    //   32: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   37: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   42: aload_1
    //   43: <illegal opcode> 73 : (Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
    //   48: <illegal opcode> 74 : (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/block/Block;
    //   53: <illegal opcode> 76 : ()Lnet/minecraft/block/Block;
    //   58: invokestatic lIIIIIIlIlIIlIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   61: ifeq -> 177
    //   64: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   69: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   74: ldc_w net/minecraft/entity/Entity
    //   77: new net/minecraft/util/math/AxisAlignedBB
    //   80: dup
    //   81: aload_1
    //   82: invokespecial <init> : (Lnet/minecraft/util/math/BlockPos;)V
    //   85: <illegal opcode> 77 : (Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
    //   90: <illegal opcode> 78 : (Ljava/util/List;)Z
    //   95: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   98: ifeq -> 177
    //   101: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   104: iconst_1
    //   105: iaload
    //   106: ldc ''
    //   108: invokevirtual length : ()I
    //   111: pop
    //   112: aconst_null
    //   113: ifnull -> 182
    //   116: bipush #79
    //   118: bipush #32
    //   120: ixor
    //   121: bipush #59
    //   123: bipush #28
    //   125: ixor
    //   126: ldc ' '
    //   128: invokevirtual length : ()I
    //   131: ishl
    //   132: ixor
    //   133: ldc ' '
    //   135: invokevirtual length : ()I
    //   138: ishl
    //   139: bipush #58
    //   141: bipush #123
    //   143: ixor
    //   144: ldc ' '
    //   146: invokevirtual length : ()I
    //   149: ishl
    //   150: bipush #51
    //   152: bipush #49
    //   154: iadd
    //   155: bipush #-16
    //   157: isub
    //   158: bipush #47
    //   160: iadd
    //   161: ixor
    //   162: ldc ' '
    //   164: invokevirtual length : ()I
    //   167: ishl
    //   168: ldc ' '
    //   170: invokevirtual length : ()I
    //   173: ineg
    //   174: ixor
    //   175: iand
    //   176: ireturn
    //   177: getstatic me/stupitdog/bhp/f8.llIIIIIIlIIlII : [I
    //   180: iconst_0
    //   181: iaload
    //   182: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	183	0	lllllllllllllllIllIlllIllIIllIlI	Lme/stupitdog/bhp/f8;
    //   0	183	1	lllllllllllllllIllIlllIllIIllIII	Lnet/minecraft/util/math/BlockPos;
  }
  
  private void findClosestTarget() {
    // Byte code:
    //   0: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   10: <illegal opcode> 79 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   15: astore_1
    //   16: aload_0
    //   17: aconst_null
    //   18: <illegal opcode> 80 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   23: aload_1
    //   24: <illegal opcode> 81 : (Ljava/util/List;)Ljava/util/Iterator;
    //   29: astore_2
    //   30: aload_2
    //   31: <illegal opcode> 82 : (Ljava/util/Iterator;)Z
    //   36: invokestatic lIIIIIIlIlIIIIll : (I)Z
    //   39: ifeq -> 336
    //   42: aload_2
    //   43: <illegal opcode> 83 : (Ljava/util/Iterator;)Ljava/lang/Object;
    //   48: checkcast net/minecraft/entity/player/EntityPlayer
    //   51: astore_3
    //   52: aload_3
    //   53: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   58: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   63: invokestatic lIIIIIIlIlIIlIlI : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   66: ifeq -> 89
    //   69: ldc ''
    //   71: invokevirtual length : ()I
    //   74: pop
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ldc ' '
    //   82: invokevirtual length : ()I
    //   85: if_icmpge -> 30
    //   88: return
    //   89: aload_3
    //   90: <illegal opcode> 84 : (Lnet/minecraft/entity/Entity;)Z
    //   95: invokestatic lIIIIIIlIlIIIIIl : (I)Z
    //   98: ifeq -> 180
    //   101: ldc ''
    //   103: invokevirtual length : ()I
    //   106: pop
    //   107: sipush #155
    //   110: sipush #138
    //   113: ixor
    //   114: ldc_w '   '
    //   117: invokevirtual length : ()I
    //   120: ishl
    //   121: bipush #42
    //   123: bipush #43
    //   125: iadd
    //   126: bipush #-13
    //   128: isub
    //   129: bipush #31
    //   131: iadd
    //   132: ixor
    //   133: ldc ' '
    //   135: invokevirtual length : ()I
    //   138: ishl
    //   139: ldc ' '
    //   141: invokevirtual length : ()I
    //   144: bipush #24
    //   146: bipush #31
    //   148: ixor
    //   149: ishl
    //   150: bipush #57
    //   152: bipush #38
    //   154: iadd
    //   155: bipush #56
    //   157: isub
    //   158: bipush #98
    //   160: iadd
    //   161: ixor
    //   162: ldc ' '
    //   164: invokevirtual length : ()I
    //   167: ishl
    //   168: ldc ' '
    //   170: invokevirtual length : ()I
    //   173: ineg
    //   174: ixor
    //   175: iand
    //   176: ifeq -> 30
    //   179: return
    //   180: aload_3
    //   181: <illegal opcode> 85 : (Lnet/minecraft/entity/player/EntityPlayer;)F
    //   186: fconst_0
    //   187: invokestatic lIIIIIIlIlIIlIll : (FF)I
    //   190: invokestatic lIIIIIIlIlIIIlll : (I)Z
    //   193: ifeq -> 211
    //   196: ldc ''
    //   198: invokevirtual length : ()I
    //   201: pop
    //   202: ldc ' '
    //   204: invokevirtual length : ()I
    //   207: ifne -> 30
    //   210: return
    //   211: aload_0
    //   212: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   217: invokestatic lIIIIIIlIIllllII : (Ljava/lang/Object;)Z
    //   220: ifeq -> 251
    //   223: aload_0
    //   224: aload_3
    //   225: <illegal opcode> 80 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   230: ldc ''
    //   232: invokevirtual length : ()I
    //   235: pop
    //   236: ldc ' '
    //   238: invokevirtual length : ()I
    //   241: ldc_w '   '
    //   244: invokevirtual length : ()I
    //   247: if_icmple -> 315
    //   250: return
    //   251: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   256: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   261: aload_3
    //   262: <illegal opcode> 86 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;)F
    //   267: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   272: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   277: aload_0
    //   278: <illegal opcode> 23 : (Lme/stupitdog/bhp/f8;)Lnet/minecraft/entity/player/EntityPlayer;
    //   283: <illegal opcode> 86 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/entity/Entity;)F
    //   288: invokestatic lIIIIIIlIlIIllII : (FF)I
    //   291: invokestatic lIIIIIIlIlIIllIl : (I)Z
    //   294: ifeq -> 308
    //   297: ldc ''
    //   299: invokevirtual length : ()I
    //   302: pop
    //   303: aconst_null
    //   304: ifnull -> 30
    //   307: return
    //   308: aload_0
    //   309: aload_3
    //   310: <illegal opcode> 80 : (Lme/stupitdog/bhp/f8;Lnet/minecraft/entity/player/EntityPlayer;)V
    //   315: ldc ''
    //   317: invokevirtual length : ()I
    //   320: pop
    //   321: ldc ' '
    //   323: invokevirtual length : ()I
    //   326: ldc_w '   '
    //   329: invokevirtual length : ()I
    //   332: if_icmpne -> 30
    //   335: return
    //   336: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   52	263	3	lllllllllllllllIllIlllIllIIIlllI	Lnet/minecraft/entity/player/EntityPlayer;
    //   0	337	0	lllllllllllllllIllIlllIllIIIllIl	Lme/stupitdog/bhp/f8;
    //   16	321	1	lllllllllllllllIllIlllIllIIIllII	Ljava/util/List;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   16	321	1	lllllllllllllllIllIlllIllIIIllII	Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;
  }
  
  private void placeBlock(BlockPos lllllllllllllllIllIlllIllIIIlIlI, EnumFacing lllllllllllllllIllIlllIllIIIlIII) {
    // Byte code:
    //   0: aload_1
    //   1: aload_2
    //   2: <illegal opcode> 87 : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
    //   7: astore_3
    //   8: aload_2
    //   9: <illegal opcode> 88 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/EnumFacing;
    //   14: astore #4
    //   16: new net/minecraft/util/math/Vec3d
    //   19: dup
    //   20: aload_3
    //   21: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   24: ldc2_w 0.5
    //   27: ldc2_w 0.5
    //   30: ldc2_w 0.5
    //   33: <illegal opcode> 34 : (Lnet/minecraft/util/math/Vec3d;DDD)Lnet/minecraft/util/math/Vec3d;
    //   38: new net/minecraft/util/math/Vec3d
    //   41: dup
    //   42: aload #4
    //   44: <illegal opcode> 89 : (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3i;
    //   49: invokespecial <init> : (Lnet/minecraft/util/math/Vec3i;)V
    //   52: ldc2_w 0.5
    //   55: <illegal opcode> 90 : (Lnet/minecraft/util/math/Vec3d;D)Lnet/minecraft/util/math/Vec3d;
    //   60: <illegal opcode> 91 : (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
    //   65: astore #5
    //   67: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   72: <illegal opcode> 68 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   77: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   82: <illegal opcode> 11 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   87: <illegal opcode> 10 : ()Lnet/minecraft/client/Minecraft;
    //   92: <illegal opcode> 40 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   97: aload_3
    //   98: aload #4
    //   100: aload #5
    //   102: <illegal opcode> 92 : ()Lnet/minecraft/util/EnumHand;
    //   107: <illegal opcode> 93 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   112: ldc ''
    //   114: invokevirtual length : ()I
    //   117: pop2
    //   118: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	119	0	lllllllllllllllIllIlllIllIIIlIll	Lme/stupitdog/bhp/f8;
    //   0	119	1	lllllllllllllllIllIlllIllIIIlIlI	Lnet/minecraft/util/math/BlockPos;
    //   0	119	2	lllllllllllllllIllIlllIllIIIlIII	Lnet/minecraft/util/EnumFacing;
    //   8	111	3	lllllllllllllllIllIlllIllIIIIllI	Lnet/minecraft/util/math/BlockPos;
    //   16	103	4	lllllllllllllllIllIlllIllIIIIlII	Lnet/minecraft/util/EnumFacing;
    //   67	52	5	lllllllllllllllIllIlllIllIIIIIlI	Lnet/minecraft/util/math/Vec3d;
  }
  
  public static boolean isLiving(Entity lllllllllllllllIllIlllIllIIIIIII) {
    return lllllllllllllllIllIlllIllIIIIIII instanceof net.minecraft.entity.EntityLivingBase;
  }
  
  static {
    lIIIIIIlIIlllIll();
    lIIIIIIlIIlIllIl();
    lIIIIIIlIIlIllII();
    lIIIIIIlIIIlllII();
  }
  
  private static CallSite llllllIlIlllIlI(MethodHandles.Lookup lllllllllllllllIllIlllIlIllIIlIl, String lllllllllllllllIllIlllIlIllIIlII, MethodType lllllllllllllllIllIlllIlIllIIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIlIllIlIll = lIllllIIllIIII[Integer.parseInt(lllllllllllllllIllIlllIlIllIIlII)].split(llIIIIIIIlllll[llIIIIIIlIIlII[13]]);
      Class<?> lllllllllllllllIllIlllIlIllIlIlI = Class.forName(lllllllllllllllIllIlllIlIllIlIll[llIIIIIIlIIlII[0]]);
      String lllllllllllllllIllIlllIlIllIlIIl = lllllllllllllllIllIlllIlIllIlIll[llIIIIIIlIIlII[1]];
      MethodHandle lllllllllllllllIllIlllIlIllIlIII = null;
      int lllllllllllllllIllIlllIlIllIIlll = lllllllllllllllIllIlllIlIllIlIll[llIIIIIIlIIlII[3]].length();
      if (lIIIIIIlIlIlIIIl(lllllllllllllllIllIlllIlIllIIlll, llIIIIIIlIIlII[2])) {
        MethodType lllllllllllllllIllIlllIlIllIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIlIllIlIll[llIIIIIIlIIlII[2]], f8.class.getClassLoader());
        if (lIIIIIIlIlIlIIlI(lllllllllllllllIllIlllIlIllIIlll, llIIIIIIlIIlII[2])) {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findVirtual(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findStatic(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllIl);
        } 
        "".length();
        if (-" ".length() > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIlIllIllII = lIllllIIllIIIl[Integer.parseInt(lllllllllllllllIllIlllIlIllIlIll[llIIIIIIlIIlII[2]])];
        if (lIIIIIIlIlIlIIlI(lllllllllllllllIllIlllIlIllIIlll, llIIIIIIlIIlII[3])) {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findGetter(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIlIlIlIIlI(lllllllllllllllIllIlllIlIllIIlll, llIIIIIIlIIlII[5])) {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findStaticGetter(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIIlIlIlIIlI(lllllllllllllllIllIlllIlIllIIlll, llIIIIIIlIIlII[6])) {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findSetter(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlllIlIllIlIII = lllllllllllllllIllIlllIlIllIIlIl.findStaticSetter(lllllllllllllllIllIlllIlIllIlIlI, lllllllllllllllIllIlllIlIllIlIIl, lllllllllllllllIllIlllIlIllIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIlIllIlIII);
    } catch (Exception lllllllllllllllIllIlllIlIllIIllI) {
      lllllllllllllllIllIlllIlIllIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIIlllII() {
    lIllllIIllIIII = new String[llIIIIIIlIIlII[14]];
    lIllllIIllIIII[llIIIIIIlIIlII[15]] = llIIIIIIIlllll[llIIIIIIlIIlII[11]];
    lIllllIIllIIII[llIIIIIIlIIlII[16]] = llIIIIIIIlllll[llIIIIIIlIIlII[17]];
    lIllllIIllIIII[llIIIIIIlIIlII[18]] = llIIIIIIIlllll[llIIIIIIlIIlII[19]];
    lIllllIIllIIII[llIIIIIIlIIlII[20]] = llIIIIIIIlllll[llIIIIIIlIIlII[21]];
    lIllllIIllIIII[llIIIIIIlIIlII[22]] = llIIIIIIIlllll[llIIIIIIlIIlII[23]];
    lIllllIIllIIII[llIIIIIIlIIlII[24]] = llIIIIIIIlllll[llIIIIIIlIIlII[25]];
    lIllllIIllIIII[llIIIIIIlIIlII[26]] = llIIIIIIIlllll[llIIIIIIlIIlII[27]];
    lIllllIIllIIII[llIIIIIIlIIlII[28]] = llIIIIIIIlllll[llIIIIIIlIIlII[29]];
    lIllllIIllIIII[llIIIIIIlIIlII[30]] = llIIIIIIIlllll[llIIIIIIlIIlII[31]];
    lIllllIIllIIII[llIIIIIIlIIlII[32]] = llIIIIIIIlllll[llIIIIIIlIIlII[33]];
    lIllllIIllIIII[llIIIIIIlIIlII[34]] = llIIIIIIIlllll[llIIIIIIlIIlII[16]];
    lIllllIIllIIII[llIIIIIIlIIlII[35]] = llIIIIIIIlllll[llIIIIIIlIIlII[4]];
    lIllllIIllIIII[llIIIIIIlIIlII[36]] = llIIIIIIIlllll[llIIIIIIlIIlII[37]];
    lIllllIIllIIII[llIIIIIIlIIlII[38]] = llIIIIIIIlllll[llIIIIIIlIIlII[39]];
    lIllllIIllIIII[llIIIIIIlIIlII[40]] = llIIIIIIIlllll[llIIIIIIlIIlII[41]];
    lIllllIIllIIII[llIIIIIIlIIlII[42]] = llIIIIIIIlllll[llIIIIIIlIIlII[43]];
    lIllllIIllIIII[llIIIIIIlIIlII[44]] = llIIIIIIIlllll[llIIIIIIlIIlII[45]];
    lIllllIIllIIII[llIIIIIIlIIlII[46]] = llIIIIIIIlllll[llIIIIIIlIIlII[47]];
    lIllllIIllIIII[llIIIIIIlIIlII[48]] = llIIIIIIIlllll[llIIIIIIlIIlII[38]];
    lIllllIIllIIII[llIIIIIIlIIlII[49]] = llIIIIIIIlllll[llIIIIIIlIIlII[22]];
    lIllllIIllIIII[llIIIIIIlIIlII[13]] = llIIIIIIIlllll[llIIIIIIlIIlII[50]];
    lIllllIIllIIII[llIIIIIIlIIlII[51]] = llIIIIIIIlllll[llIIIIIIlIIlII[52]];
    lIllllIIllIIII[llIIIIIIlIIlII[41]] = llIIIIIIIlllll[llIIIIIIlIIlII[53]];
    lIllllIIllIIII[llIIIIIIlIIlII[54]] = llIIIIIIIlllll[llIIIIIIlIIlII[55]];
    lIllllIIllIIII[llIIIIIIlIIlII[1]] = llIIIIIIIlllll[llIIIIIIlIIlII[56]];
    lIllllIIllIIII[llIIIIIIlIIlII[45]] = llIIIIIIIlllll[llIIIIIIlIIlII[44]];
    lIllllIIllIIII[llIIIIIIlIIlII[57]] = llIIIIIIIlllll[llIIIIIIlIIlII[58]];
    lIllllIIllIIII[llIIIIIIlIIlII[59]] = llIIIIIIIlllll[llIIIIIIlIIlII[12]];
    lIllllIIllIIII[llIIIIIIlIIlII[60]] = llIIIIIIIlllll[llIIIIIIlIIlII[61]];
    lIllllIIllIIII[llIIIIIIlIIlII[29]] = llIIIIIIIlllll[llIIIIIIlIIlII[32]];
    lIllllIIllIIII[llIIIIIIlIIlII[62]] = llIIIIIIIlllll[llIIIIIIlIIlII[63]];
    lIllllIIllIIII[llIIIIIIlIIlII[4]] = llIIIIIIIlllll[llIIIIIIlIIlII[64]];
    lIllllIIllIIII[llIIIIIIlIIlII[65]] = llIIIIIIIlllll[llIIIIIIlIIlII[66]];
    lIllllIIllIIII[llIIIIIIlIIlII[55]] = llIIIIIIIlllll[llIIIIIIlIIlII[67]];
    lIllllIIllIIII[llIIIIIIlIIlII[64]] = llIIIIIIIlllll[llIIIIIIlIIlII[68]];
    lIllllIIllIIII[llIIIIIIlIIlII[63]] = llIIIIIIIlllll[llIIIIIIlIIlII[69]];
    lIllllIIllIIII[llIIIIIIlIIlII[43]] = llIIIIIIIlllll[llIIIIIIlIIlII[70]];
    lIllllIIllIIII[llIIIIIIlIIlII[37]] = llIIIIIIIlllll[llIIIIIIlIIlII[71]];
    lIllllIIllIIII[llIIIIIIlIIlII[17]] = llIIIIIIIlllll[llIIIIIIlIIlII[65]];
    lIllllIIllIIII[llIIIIIIlIIlII[72]] = llIIIIIIIlllll[llIIIIIIlIIlII[73]];
    lIllllIIllIIII[llIIIIIIlIIlII[74]] = llIIIIIIIlllll[llIIIIIIlIIlII[20]];
    lIllllIIllIIII[llIIIIIIlIIlII[75]] = llIIIIIIIlllll[llIIIIIIlIIlII[76]];
    lIllllIIllIIII[llIIIIIIlIIlII[77]] = llIIIIIIIlllll[llIIIIIIlIIlII[78]];
    lIllllIIllIIII[llIIIIIIlIIlII[3]] = llIIIIIIIlllll[llIIIIIIlIIlII[28]];
    lIllllIIllIIII[llIIIIIIlIIlII[79]] = llIIIIIIIlllll[llIIIIIIlIIlII[24]];
    lIllllIIllIIII[llIIIIIIlIIlII[80]] = llIIIIIIIlllll[llIIIIIIlIIlII[62]];
    lIllllIIllIIII[llIIIIIIlIIlII[81]] = llIIIIIIIlllll[llIIIIIIlIIlII[82]];
    lIllllIIllIIII[llIIIIIIlIIlII[83]] = llIIIIIIIlllll[llIIIIIIlIIlII[84]];
    lIllllIIllIIII[llIIIIIIlIIlII[6]] = llIIIIIIIlllll[llIIIIIIlIIlII[85]];
    lIllllIIllIIII[llIIIIIIlIIlII[47]] = llIIIIIIIlllll[llIIIIIIlIIlII[86]];
    lIllllIIllIIII[llIIIIIIlIIlII[53]] = llIIIIIIIlllll[llIIIIIIlIIlII[87]];
    lIllllIIllIIII[llIIIIIIlIIlII[88]] = llIIIIIIIlllll[llIIIIIIlIIlII[54]];
    lIllllIIllIIII[llIIIIIIlIIlII[58]] = llIIIIIIIlllll[llIIIIIIlIIlII[60]];
    lIllllIIllIIII[llIIIIIIlIIlII[89]] = llIIIIIIIlllll[llIIIIIIlIIlII[90]];
    lIllllIIllIIII[llIIIIIIlIIlII[73]] = llIIIIIIIlllll[llIIIIIIlIIlII[36]];
    lIllllIIllIIII[llIIIIIIlIIlII[5]] = llIIIIIIIlllll[llIIIIIIlIIlII[91]];
    lIllllIIllIIII[llIIIIIIlIIlII[50]] = llIIIIIIIlllll[llIIIIIIlIIlII[92]];
    lIllllIIllIIII[llIIIIIIlIIlII[84]] = llIIIIIIIlllll[llIIIIIIlIIlII[93]];
    lIllllIIllIIII[llIIIIIIlIIlII[67]] = llIIIIIIIlllll[llIIIIIIlIIlII[46]];
    lIllllIIllIIII[llIIIIIIlIIlII[94]] = llIIIIIIIlllll[llIIIIIIlIIlII[30]];
    lIllllIIllIIII[llIIIIIIlIIlII[69]] = llIIIIIIIlllll[llIIIIIIlIIlII[40]];
    lIllllIIllIIII[llIIIIIIlIIlII[95]] = llIIIIIIIlllll[llIIIIIIlIIlII[81]];
    lIllllIIllIIII[llIIIIIIlIIlII[11]] = llIIIIIIIlllll[llIIIIIIlIIlII[96]];
    lIllllIIllIIII[llIIIIIIlIIlII[2]] = llIIIIIIIlllll[llIIIIIIlIIlII[88]];
    lIllllIIllIIII[llIIIIIIlIIlII[68]] = llIIIIIIIlllll[llIIIIIIlIIlII[49]];
    lIllllIIllIIII[llIIIIIIlIIlII[96]] = llIIIIIIIlllll[llIIIIIIlIIlII[97]];
    lIllllIIllIIII[llIIIIIIlIIlII[66]] = llIIIIIIIlllll[llIIIIIIlIIlII[98]];
    lIllllIIllIIII[llIIIIIIlIIlII[71]] = llIIIIIIIlllll[llIIIIIIlIIlII[15]];
    lIllllIIllIIII[llIIIIIIlIIlII[99]] = llIIIIIIIlllll[llIIIIIIlIIlII[59]];
    lIllllIIllIIII[llIIIIIIlIIlII[61]] = llIIIIIIIlllll[llIIIIIIlIIlII[100]];
    lIllllIIllIIII[llIIIIIIlIIlII[93]] = llIIIIIIIlllll[llIIIIIIlIIlII[101]];
    lIllllIIllIIII[llIIIIIIlIIlII[101]] = llIIIIIIIlllll[llIIIIIIlIIlII[77]];
    lIllllIIllIIII[llIIIIIIlIIlII[102]] = llIIIIIIIlllll[llIIIIIIlIIlII[94]];
    lIllllIIllIIII[llIIIIIIlIIlII[31]] = llIIIIIIIlllll[llIIIIIIlIIlII[103]];
    lIllllIIllIIII[llIIIIIIlIIlII[104]] = llIIIIIIIlllll[llIIIIIIlIIlII[57]];
    lIllllIIllIIII[llIIIIIIlIIlII[21]] = llIIIIIIIlllll[llIIIIIIlIIlII[35]];
    lIllllIIllIIII[llIIIIIIlIIlII[10]] = llIIIIIIIlllll[llIIIIIIlIIlII[105]];
    lIllllIIllIIII[llIIIIIIlIIlII[82]] = llIIIIIIIlllll[llIIIIIIlIIlII[89]];
    lIllllIIllIIII[llIIIIIIlIIlII[12]] = llIIIIIIIlllll[llIIIIIIlIIlII[106]];
    lIllllIIllIIII[llIIIIIIlIIlII[92]] = llIIIIIIIlllll[llIIIIIIlIIlII[107]];
    lIllllIIllIIII[llIIIIIIlIIlII[91]] = llIIIIIIIlllll[llIIIIIIlIIlII[108]];
    lIllllIIllIIII[llIIIIIIlIIlII[52]] = llIIIIIIIlllll[llIIIIIIlIIlII[79]];
    lIllllIIllIIII[llIIIIIIlIIlII[105]] = llIIIIIIIlllll[llIIIIIIlIIlII[104]];
    lIllllIIllIIII[llIIIIIIlIIlII[90]] = llIIIIIIIlllll[llIIIIIIlIIlII[26]];
    lIllllIIllIIII[llIIIIIIlIIlII[25]] = llIIIIIIIlllll[llIIIIIIlIIlII[75]];
    lIllllIIllIIII[llIIIIIIlIIlII[86]] = llIIIIIIIlllll[llIIIIIIlIIlII[102]];
    lIllllIIllIIII[llIIIIIIlIIlII[106]] = llIIIIIIIlllll[llIIIIIIlIIlII[18]];
    lIllllIIllIIII[llIIIIIIlIIlII[109]] = llIIIIIIIlllll[llIIIIIIlIIlII[72]];
    lIllllIIllIIII[llIIIIIIlIIlII[108]] = llIIIIIIIlllll[llIIIIIIlIIlII[99]];
    lIllllIIllIIII[llIIIIIIlIIlII[33]] = llIIIIIIIlllll[llIIIIIIlIIlII[110]];
    lIllllIIllIIII[llIIIIIIlIIlII[87]] = llIIIIIIIlllll[llIIIIIIlIIlII[109]];
    lIllllIIllIIII[llIIIIIIlIIlII[7]] = llIIIIIIIlllll[llIIIIIIlIIlII[111]];
    lIllllIIllIIII[llIIIIIIlIIlII[56]] = llIIIIIIIlllll[llIIIIIIlIIlII[80]];
    lIllllIIllIIII[llIIIIIIlIIlII[110]] = llIIIIIIIlllll[llIIIIIIlIIlII[95]];
    lIllllIIllIIII[llIIIIIIlIIlII[76]] = llIIIIIIIlllll[llIIIIIIlIIlII[51]];
    lIllllIIllIIII[llIIIIIIlIIlII[112]] = llIIIIIIIlllll[llIIIIIIlIIlII[113]];
    lIllllIIllIIII[llIIIIIIlIIlII[103]] = llIIIIIIIlllll[llIIIIIIlIIlII[42]];
    lIllllIIllIIII[llIIIIIIlIIlII[97]] = llIIIIIIIlllll[llIIIIIIlIIlII[83]];
    lIllllIIllIIII[llIIIIIIlIIlII[107]] = llIIIIIIIlllll[llIIIIIIlIIlII[74]];
    lIllllIIllIIII[llIIIIIIlIIlII[23]] = llIIIIIIIlllll[llIIIIIIlIIlII[112]];
    lIllllIIllIIII[llIIIIIIlIIlII[111]] = llIIIIIIIlllll[llIIIIIIlIIlII[48]];
    lIllllIIllIIII[llIIIIIIlIIlII[113]] = llIIIIIIIlllll[llIIIIIIlIIlII[34]];
    lIllllIIllIIII[llIIIIIIlIIlII[98]] = llIIIIIIIlllll[llIIIIIIlIIlII[14]];
    lIllllIIllIIII[llIIIIIIlIIlII[0]] = llIIIIIIIlllll[llIIIIIIlIIlII[114]];
    lIllllIIllIIII[llIIIIIIlIIlII[100]] = llIIIIIIIlllll[llIIIIIIlIIlII[115]];
    lIllllIIllIIII[llIIIIIIlIIlII[19]] = llIIIIIIIlllll[llIIIIIIlIIlII[116]];
    lIllllIIllIIII[llIIIIIIlIIlII[85]] = llIIIIIIIlllll[llIIIIIIlIIlII[117]];
    lIllllIIllIIII[llIIIIIIlIIlII[39]] = llIIIIIIIlllll[llIIIIIIlIIlII[118]];
    lIllllIIllIIII[llIIIIIIlIIlII[78]] = llIIIIIIIlllll[llIIIIIIlIIlII[119]];
    lIllllIIllIIII[llIIIIIIlIIlII[70]] = llIIIIIIIlllll[llIIIIIIlIIlII[120]];
    lIllllIIllIIII[llIIIIIIlIIlII[27]] = llIIIIIIIlllll[llIIIIIIlIIlII[121]];
    lIllllIIllIIIl = new Class[llIIIIIIlIIlII[22]];
    lIllllIIllIIIl[llIIIIIIlIIlII[33]] = NetHandlerPlayClient.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[23]] = double.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[3]] = f100000000000000000000.Double.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[2]] = f100000000000000000000.Integer.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[13]] = boolean.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[29]] = WorldClient.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[6]] = f100000000000000000000.ColorSetting.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[47]] = Block.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[16]] = CPacketEntityAction.Action.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[45]] = ClickType.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[0]] = f13.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[19]] = EntityPlayer.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[4]] = EnumFacing.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[37]] = GuiScreen.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[5]] = f100000000000000000000.Boolean.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[10]] = EntityPlayerSP.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[38]] = EnumHand.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[43]] = Container.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[41]] = PlayerControllerMP.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[11]] = int.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[27]] = float.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[7]] = Minecraft.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[1]] = Listener.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[21]] = String.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[17]] = InventoryPlayer.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[39]] = Item.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[25]] = BlockPos.class;
    lIllllIIllIIIl[llIIIIIIlIIlII[31]] = List.class;
  }
  
  private static void lIIIIIIlIIlIllII() {
    llIIIIIIIlllll = new String[llIIIIIIlIIlII[122]];
    llIIIIIIIlllll[llIIIIIIlIIlII[0]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[0]], llIIIIIIlIIIll[llIIIIIIlIIlII[1]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[1]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[2]], llIIIIIIlIIIll[llIIIIIIlIIlII[3]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[2]] = lIIIIIIlIIIllllI(llIIIIIIlIIIll[llIIIIIIlIIlII[5]], llIIIIIIlIIIll[llIIIIIIlIIlII[6]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[3]] = lIIIIIIlIIIlllll(llIIIIIIlIIIll[llIIIIIIlIIlII[7]], llIIIIIIlIIIll[llIIIIIIlIIlII[10]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[5]] = lIIIIIIlIIIlllll(llIIIIIIlIIIll[llIIIIIIlIIlII[13]], llIIIIIIlIIIll[llIIIIIIlIIlII[11]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[6]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[17]], llIIIIIIlIIIll[llIIIIIIlIIlII[19]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[7]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[21]], llIIIIIIlIIIll[llIIIIIIlIIlII[23]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[10]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[25]], llIIIIIIlIIIll[llIIIIIIlIIlII[27]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[13]] = lIIIIIIlIIIlllll(llIIIIIIlIIIll[llIIIIIIlIIlII[29]], llIIIIIIlIIIll[llIIIIIIlIIlII[31]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[11]] = lIIIIIIlIIIlllll(llIIIIIIlIIIll[llIIIIIIlIIlII[33]], llIIIIIIlIIIll[llIIIIIIlIIlII[16]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[17]] = lIIIIIIlIIIlllIl(llIIIIIIlIIIll[llIIIIIIlIIlII[4]], llIIIIIIlIIIll[llIIIIIIlIIlII[37]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[19]] = lIIIIIIlIIIlllll(llIIIIIIlIIIll[llIIIIIIlIIlII[39]], llIIIIIIlIIIll[llIIIIIIlIIlII[41]]);
    llIIIIIIIlllll[llIIIIIIlIIlII[21]] = lIIIIIIlIIIlllIl("JZVBbME+CAjyc9zpKwtImypAyV5CCuX10FCgpIjPoqWMwv9shlS1cRf7WY4wHGjzwtMWXCkOJRstZxkPd085Eg==", "cejFb");
    llIIIIIIIlllll[llIIIIIIlIIlII[23]] = lIIIIIIlIIIlllIl("XbgIikF5zcCsdQ4yChZVC5KuFnUyDKCCVou0E/sGFdgazDwbbWKqsUfsUdSnIntg78WqjwuIOFo=", "axWoW");
    llIIIIIIIlllll[llIIIIIIlIIlII[25]] = lIIIIIIlIIIlllll("HD1rEQcEKCwWFx4/awAbAXYjU0NBaHVSQ0FodVJDQWh1UkNBaHVSVzU3MAAfFGIiBwcnOSkXFktwbCZJUXg=", "qXEbs");
    llIIIIIIIlllll[llIIIIIIlIIlII[27]] = lIIIIIIlIIIlllll("PyQnYig4LzYvNzAnJ2IwJSg/YgA/ND4EJD8laQEEGA8MBAQfBWl+cmthc2xl", "QASLE");
    llIIIIIIIlllll[llIIIIIIlIIlII[29]] = lIIIIIIlIIIlllll("BBBkOw0cBSM8HQYSZCoRGVsscEMbFCQvHFNGcGhZSQ==", "iuJHy");
    llIIIIIIIlllll[llIIIIIIlIIlII[31]] = lIIIIIIlIIIllllI("93a4cbb6RgIrYk6ouvEchiLSrXczi9COfE3NtIrN0ukROdUf0CtIcvT1yPKDYKblHfxFE293Wb4=", "eOMcw");
    llIIIIIIIlllll[llIIIIIIlIIlII[33]] = lIIIIIIlIIIlllll("ITFiFw05JCUQHSMzYgYRPHoqXEM8OC0HHBg1PgMcOG59UENsdGw=", "LTLdy");
    llIIIIIIIlllll[llIIIIIIlIIlII[16]] = lIIIIIIlIIIlllll("MjgTJl80OAsgXxw2ECUdPWMTJh0tPCohS3AdTAsbOS8EaB05NwJoNTcsBysUY2NF", "XYeGq");
    llIIIIIIIlllll[llIIIIIIlIIlII[4]] = lIIIIIIlIIIllllI("FBAq5u8XkQFJtmOgJsv05VkIflQQLiXso61XNYU/9GJSQt3Cf0LFvoYVSF7etmuslWrjALBcGbsmu8CSEFBzyA==", "VMaVV");
    llIIIIIIIlllll[llIIIIIIlIIlII[37]] = lIIIIIIlIIIllllI("gL5FHFTkt7hgCHArzZB4CtziYYd8bldFBFQ4yfHVIdMKGzB//f0KlCmDdEwBr9qgBOD2WS9rZHtBdX9jtcS9BQ==", "AtTeZ");
    llIIIIIIIlllll[llIIIIIIlIIlII[39]] = lIIIIIIlIIIlllIl("OK5qf6rGzx6M34ltq1A1DcKtM7nART0ZQT99QQ2Qu7qH7cWIjHTFbol5wLH2QT8Z", "LfvSD");
    llIIIIIIIlllll[llIIIIIIlIIlII[41]] = lIIIIIIlIIIlllIl("ShpL3uAZNgx7egYB3aFq9X3K/swAOXSpJ8HOzwSkrXv4bL5aaFW+e/sxfFnrGgm67cd2KRsw+i4nuDbrTZe8Y80C/WYJtQwt", "OARAT");
    llIIIIIIIlllll[llIIIIIIlIIlII[43]] = lIIIIIIlIIIllllI("yZloNpuKswezYl/4FLGWT8ygwTuCA2S+Pgcj1TdY4qQt9AR7qH6emOi0JcfjxzoedDlz+rcZPY+PB0T23pcS5ZuRkMOGQhQRUT5OKEyAVFwP9qAmIS7TZ8QFMbkyjZp7", "HiDZR");
    llIIIIIIIlllll[llIIIIIIlIIlII[45]] = lIIIIIIlIIIlllll("JSQaeSUiLws0OionGnk9PygCeSUqNQZ5Hi4iXTNyLTQANBd8c1pjeRQiVH8MDwVHGyYuNUE6ISUkDSUpLTVBIjwiLUE6KT8pQQEtKHIKbHJrYQ==", "KAnWH");
    llIIIIIIIlllll[llIIIIIIlIIlII[47]] = lIIIIIIlIIIllllI("V6newfvNc8QLjwv3r+SQVaNZCUOZ8TP+0264u9SicUwQ20psfi46mR4ypFvC0F4kZ+8uiOOSTNQ=", "ZoytN");
    llIIIIIIIlllll[llIIIIIIlIIlII[38]] = lIIIIIIlIIIlllll("LSMOWSsqKB8UNCIgDlklLy8fGTJtIxQDLzc/VDIoNy8ODhYvJwMSNBAWQBEzLSUlQHZzd0soIHluPjMCagJAV2Y=", "CFzwF");
    llIIIIIIIlllll[llIIIIIIlIIlII[22]] = lIIIIIIlIIIlllll("KDwtdBsvNzw5BCc/LXQVKjA8NAJoNCw2Ai8pNTsPIyt3DRk0NT0ZGi88Ny5MICw3OSl3YWluT3MGKWBeCjc8LlkrMDc/FTQ4Py5ZMy0wNlkrOC0yWQQ1NjkdFjYqYV8KNzwuWSswNz8VNDg/LlkkNTY5HWkqLTsCI3YQGBopOjIJAictPGFMZnk=", "FYYZv");
    llIIIIIIIlllll[llIIIIIIlIIlII[50]] = lIIIIIIlIIIlllIl("2553VbAfszCZeAixr8FQnyFlygbQsYVSIiVd8Lyfgam+7wPVNQNSrQeH5UVNLmyTsorA0JiSVKO1up7z2SgS+1ZJ+nxQvOIToZ0fVmpBFFgF+o8iWZGnKwZnE3jSPW7Coi0bZjQsMSCiLRtmNCwxIAC6t9yc78h2QmVe8lmmdQLGqZJEjTf2Qw==", "OcIAl");
    llIIIIIIIlllll[llIIIIIIlIIlII[52]] = lIIIIIIlIIIlllIl("5/odM6yWxodY3OaUYnl8s//ZkZTnk8PSB81eBSfRdFjUYuw4eoz0GA==", "RqrMb");
    llIIIIIIIlllll[llIIIIIIlIIlII[53]] = lIIIIIIlIIIlllIl("6upF/FU/fVNN+Cf5rdXHZPDUgHfIzfni1UXI/QVAVxMo1J+VftwTuzu8AYrlrwzm", "DFMys");
    llIIIIIIIlllll[llIIIIIIlIIlII[55]] = lIIIIIIlIIIlllIl("LiHsxpZ4RpzosFYJzlBXXinJcwvjA9s17ksc0gKD3sqBqGBiqaWNyysArmRgRheRiW/sc81Rtc8NAEnSsfFADYCwqmmmoP4ckBahfDvQ3S80ZJ03CLAduw==", "ReKea");
    llIIIIIIIlllll[llIIIIIIlIIlII[56]] = lIIIIIIlIIIlllll("PAZvMD8kEyg3Lz4EbyEjIU0ne3E9CjI3Lj8GM3l6a0NhY2tx", "QcACK");
    llIIIIIIIlllll[llIIIIIIlIIlII[44]] = lIIIIIIlIIIlllIl("GdCaG2PTzlOk+jV0ZQHOxtbM01WseS6mfgWN6gLqiK+vVeye2p4nRulaeeKQ56y+eMfzWEDvceoykhPtjOWD6fV2IFGZi3znHohoCGWNyW0=", "OlwLn");
    llIIIIIIIlllll[llIIIIIIlIIlII[58]] = lIIIIIIlIIIlllIl("zvkIaygMGq+OjPWb+sC+18xl5QQmtX/wOJzIZ5RRyQ+368oqQqzHQf9jm6dLoCTz", "BuetZ");
    llIIIIIIIlllll[llIIIIIIlIIlII[12]] = lIIIIIIlIIIlllIl("6YlMKJs+EhCRyh+LV2SbnzV6n1Z3Td7Qpw3yxSEsV+HAlfavMoeVGSVrU5euxuzvl4RnXnqTxXCWv7Ac64CFb/SzHcSRhmdxbjoP3SSRWs6wonUkSoqSxjk0KIvIuufNBBqs6FveprAdeJo4V/bDFdegtzRr2IGDBD6OaazVbsYHq2BVUlFJZg==", "WBbJj");
    llIIIIIIIlllll[llIIIIIIlIIlII[61]] = lIIIIIIlIIIlllIl("OZsFV1PgKNo2NxuebjAwyLOuJcYfgKbmTlR+BsOM6hLRIhCOtxfdrV+ZARsoA+07bVtM2WL1hvljly7snxX0zbxK5eO7J/arDjO8GtIfBcnvZ5ryM3q0lim1BZY3iIioA0E4y4Vq9H8=", "QsKRY");
    llIIIIIIIlllll[llIIIIIIlIIlII[32]] = lIIIIIIlIIIllllI("ndm5MJd4CJo7eVt2crg3svq6uMvcNWZsYuCNRtjgxQNfoyf8Hji2oTFodnI9A5sKn2KEkN3JBgU9r4iDy7pznQ==", "qlFgM");
    llIIIIIIIlllll[llIIIIIIlIIlII[63]] = lIIIIIIlIIIllllI("RDq9RJnuYGPjnTbeSxKr2YiUL0tqmKpS6KrGnQ7q/VfUfDxRWfdzBw==", "nqOvc");
    llIIIIIIIlllll[llIIIIIIlIIlII[64]] = lIIIIIIlIIIlllll("FBNYEQcMBh8WFxYRWAAbCVgQWkkJGhcbFgs+GRYRGAQlDhwNTE9YU1lW", "yvvbs");
    llIIIIIIIlllll[llIIIIIIlIIlII[66]] = lIIIIIIlIIIlllll("FjIhVhQROTAbCxkxIVYaFD4wFg1WMjsMEAwuez0XDD4hASkUNiwdCysHbx4QHTsxJ05IZmJLJhk2b0FDWHd1", "xWUxy");
    llIIIIIIIlllll[llIIIIIIlIIlII[67]] = lIIIIIIlIIIlllll("AQF8HxsZFDsYCwMDfA4HHEo0VFUIDTQKNzZeY19VTERyTE8=", "ldRlo");
    llIIIIIIIlllll[llIIIIIIlIIlII[68]] = lIIIIIIlIIIlllIl("9fCd8rxCOPPl3yjAncKV+k1EEYsIxb9PIuAUe8JpybsXEk6EIudm9WRcON+IHbV2ltFNrWiPzg0=", "jwppk");
    llIIIIIIIlllll[llIIIIIIlIIlII[69]] = lIIIIIIlIIIlllll("PgFWHR4mFBEaDjwDVgwCI0oeVlA9Cw86BSNeQFRKc0Q=", "Sdxnj");
    llIIIIIIIlllll[llIIIIIIlIIlII[70]] = lIIIIIIlIIIlllIl("NEBcHKRKE8j/Unan9JQ4vDKTnxa5C5Sydl0HOLtQRKZMSDaxJk4L8g==", "brQSm");
    llIIIIIIIlllll[llIIIIIIlIIlII[71]] = lIIIIIIlIIIlllll("NDIXWRkzOQYUBjsxF1kXNj4GGQB0Mg0DHS4uTTIaLj4XDiQ2NhoSBgkHWREdPzsHKENrZ1pEKzgcWU5OendD", "ZWcwt");
    llIIIIIIIlllll[llIIIIIIlIIlII[65]] = lIIIIIIlIIIlllIl("sGNTG6qEzlTiP4yqMTNibezn/5fkM2FnophoEfAgJ0U=", "TBapy");
    llIIIIIIIlllll[llIIIIIIlIIlII[73]] = lIIIIIIlIIIllllI("BXl05Q11UNImiFUUfTiaYGcDxYewpUPQIV81+AlH4mT9bpuWJnjzTZfsmrymP06J8RnMhFRQqn4=", "aKQUi");
    llIIIIIIIlllll[llIIIIIIlIIlII[20]] = lIIIIIIlIIIlllIl("GfZrzWAy0H04zBw11ed3ClE0pzkv3+F4ZuvDGcAjLb0AovmXLdrswMzDPjGLaWQK", "WWtgO");
    llIIIIIIIlllll[llIIIIIIlIIlII[76]] = lIIIIIIlIIIlllll("Gw8GXQMcBBcQHBQMBl0NGQMXHRpbBwcfGhwaHhIXEBhcIwIUExcBLRoEBgEBGQYXASMlUBQGABY1Q0tZRVNLLA9PQj4dCwFFHxoAEAkAEggBRREfBxAEBlwLGx4bBxdaLxwHBwETIh8PDA8AID5OJhwWGloHGx0LFhgTFRpaCR4aCxseXR4bGR4bAwIUExcBQSIFAB8KNgYbFgABUT4dCwFFHxoAEAkAEggBRQcHBxlFHxIaHUUwHwEWASIcHU4mHBYaWgcbHQsWGBMVGlofBhoCWi8cBgMzCxEaABJRPh0LAUUfGgAQCQASCAFFBwcHGUUfEhodRSQWDUYOST8AEB5dHgcbDxEBDxMeXQYaHAZdNgAABzoSABFRWz8AEB5dHgcbDxEBDxMeXQYaHAZdNgAABzMQGhwFHCELBh8eB1VPSlI=", "ujrsn");
    llIIIIIIIlllll[llIIIIIIlIIlII[78]] = lIIIIIIlIIIlllll("ABFsMhYYBCs1BgITbCMKHVokeVgOGC0yBx4AFiAQChE2e1NcTmJhQk1U", "mtBAb");
    llIIIIIIIlllll[llIIIIIIlIIlII[28]] = lIIIIIIlIIIlllll("KxFJOB4zBA4/DikTSSkCNloBc1AiEQsqE3xGXWtKZlRH", "FtgKj");
    llIIIIIIIlllll[llIIIIIIlIIlII[24]] = lIIIIIIlIIIllllI("nmx9hdW2hP1nYIbA8FNpxHa9JjUrS0eAkdtVU9y4DkfpowsyKzkaxzxl4XPIuWLygS8QBShKkvcUH7BTJaWr2MfsPRGUubnd6W4UiONIuUkGfh8b/iERzQ==", "QiaLI");
    llIIIIIIIlllll[llIIIIIIlIIlII[62]] = lIIIIIIlIIIlllll("Ki1iPA4yOCU7HigvYi0SN2Yqfkp3eHx/Snd4fH9Kd3h8f0p3eHx/XgQnICAIFC04OxMpL3YoHzMeLSMPInJkZjYqLWM8DjI4JTseKC9jLRI3Zyp/S3xybG8=", "GHLOz");
    llIIIIIIIlllll[llIIIIIIlIIlII[82]] = lIIIIIIlIIIllllI("fyC5I6bhO+laFE5SKkKq68xtf/4IcnR+LMDuZQyzjddyFtFfpYJ0WeEuN0XOCf0zrqDHzvJDP5I=", "jtICX");
    llIIIIIIIlllll[llIIIIIIlIIlII[84]] = lIIIIIIlIIIllllI("8o00m5zQQ48v5OMQJSxgcWVu22s7jjq2Dl2Gb3vMdChdqmerkxsM7bwZ2e5NUxWsZLcjNn7szewYAQbrEr0U1k5CwKh00XcU6XpH+UEFdXVJCdVoAOTfa3sA3iWAhwBc", "QBsbm");
    llIIIIIIIlllll[llIIIIIIlIIlII[85]] = lIIIIIIlIIIlllll("AQNoMTIZFi82IgMBaCAuHEggenweByglI1ZVfGJmTEZm", "lfFBF");
    llIIIIIIIlllll[llIIIIIIlIIlII[86]] = lIIIIIIlIIIllllI("XnlukPH4js6bTqVy/FZCDjRN9z0K/jeuSt0b0Of7R3LuSbhmzPDmzwQaQ4wugiFO", "WbkzP");
    llIIIIIIIlllll[llIIIIIIlIIlII[87]] = lIIIIIIlIIIlllIl("lZuw4yECGbLKX/OGDFlYi1iIcCzDa007kVdTcMtzL2mrgkkdMKeYxyA6UBHRU3y9TYHu6nQF9LP2UyD7Ej6AIL6FAO/KzidrPfN6SVWfbNvbcFIOpcJROw==", "fyeaP");
    llIIIIIIIlllll[llIIIIIIlIIlII[54]] = lIIIIIIlIIIlllll("NCwfZRQzJw4oCzsvH2UaNiAOJQ10JB4nDTM5ByoAPztFGxU7MA45OjUnHzkWNiUOOTQKcw0+FzkWWnNOanBTFBhgYSICMBYnDj9WNyAFLhooKA0/VjMnHS4XLiYZMlYZJQIoEg4wGy5CFicOP1Y3IAUuGigoDT9WPycfIg0jZhsnGCMsGWQ8ND0CPwAKJQoyHChyQgcXPz1EJhA0LAg5GDw9RCINPyREAg0/JDg/GDkiUHFZeg==", "ZIkKy");
    llIIIIIIIlllll[llIIIIIIlIIlII[60]] = lIIIIIIlIIIlllll("KiNsPREyNis6ASghbCwNN2gkdl83KiMtABMnMCkAM3xzel9nZmJuRQ==", "GFBNe");
    llIIIIIIIlllll[llIIIIIIlIIlII[90]] = lIIIIIIlIIIlllll("DS86XhQKJCsTCwIsOl4aDyMrHg1NLyAEEBczYDUXFyM6CSkPKzcVCzAadBYMDSkRR0lTeXwvHVliAh4cF2UjGRcGKTwRHxdlKx4NCj43XzwNPicEAFhjCEpZQw==", "cJNpy");
    llIIIIIIIlllll[llIIIIIIlIIlII[36]] = lIIIIIIlIIIlllll("HDB2Ow0EJTE8HR4ydioRAXs+cEMVMDQpAEtnYmhZUQ==", "qUXHy");
    llIIIIIIIlllll[llIIIIIIlIIlII[91]] = lIIIIIIlIIIlllll("AABGADAYFQEHIAICRhEsHUsOS34fAA8aNxkAGjcrGAcEFn5FKQISMgxKBBIqCko7BzYECw9IACkhQT8pCEobBzEdDBwXKwpKChs0QgNZQ3RdVVhDdF1VWEN0XVVYQ3RdVVhXAAIQCh8hVl9IUw==", "mehsD");
    llIIIIIIIlllll[llIIIIIIlIIlII[92]] = lIIIIIIlIIIllllI("AJvRKosfMgnoU7/H1GdP42wIPaso1JIi8MhOck+OlvF8urHkbD5mLq3eXOHcdtSQTIzW+vmjGuYwC/dlvC8tojfHKsuAuy/o1LCkzNqDON1aHo8DhzSrvcMvazonQjiz", "KFqqI");
    llIIIIIIIlllll[llIIIIIIlIIlII[93]] = lIIIIIIlIIIlllIl("ipKHtjVa1XE0+w9VEnQkQceum64gsifeuT+TOBmoW5XRIvZkWTninjyGoDtqN4YhGOekSC8kun5OIRgU1kqeTseoQCu1d4bif0VLpt85a9I=", "ISfYT");
    llIIIIIIIlllll[llIIIIIIlIIlII[46]] = lIIIIIIlIIIlllll("MzcXMWIsIgg8YhU/EiR2KiITNS00bEl5ADM3FzFjLCIIPGMqIhM1LTR5MiQ+PDcMa3Z5dg==", "YVaPL");
    llIIIIIIIlllll[llIIIIIIlIIlII[30]] = lIIIIIIlIIIlllll("AAU3D1cfECgCVyYNMhpDAxAkHBgeCzNUUUMoKw8PC0s0GhAGSwgaHBgFNQELUV5hTg==", "jdAny");
    llIIIIIIIlllll[llIIIIIIlIIlII[40]] = lIIIIIIlIIIllllI("N/XxQKAmeeWvh7Jc1Ge4gfRH+LVM9O93SYXCwmjvR1Pew+QlMLS71+EXBv9FfWeDyuJ7a2a7IFwg6lvow5dluPA7UGfA0j5VcFROniplMsr9J4L5EvP8WA==", "ZpqVm");
    llIIIIIIIlllll[llIIIIIIlIIlII[81]] = lIIIIIIlIIIllllI("kCYES2XzqtpukPEXi938bsOaD0w1bg+i3ssCvRUURrXjdcaoWOFG8w==", "OnwCW");
    llIIIIIIIlllll[llIIIIIIlIIlII[96]] = lIIIIIIlIIIlllll("ADNsOjgYJis9KAIxbCskHXgkcXYOOS4mPldjeGlsTXZi", "mVBIL");
    llIIIIIIIlllll[llIIIIIIlIIlII[88]] = lIIIIIIlIIIlllIl("TlaRjsW8ziTzZ6lFO9RM4vNP4Pj7A2NPsn5Weh32RjGtHwGuR3EYa0Ht86XSDbh7lZUE4VJ40zFpaSJRTLyl4y6w1NZj8WqWFeahRwI1krz+MC5Ao5HXfv4wLkCjkdd+ezvfDwEc9eNoT/1D83/6Zw==", "EdMLf");
    llIIIIIIIlllll[llIIIIIIlIIlII[49]] = lIIIIIIlIIIlllll("CSICC08WNx0GTxA3Bg8ADm0nHhMGIhlQBwovAA8TWWs4AAAVIlsfFQovWwwUDSAAAw4NbCQYBAcqFwsVBnhdJgsCNRVFFBcqGEUSFzERCwxMEAAYBAIuT1BBQw==", "cCtja");
    llIIIIIIIlllll[llIIIIIIlIIlII[97]] = lIIIIIIlIIIlllll("BQcafwQCDAsyGwoEGn8ABRQLPx0EEBd/KgcLDTo9EhILazo8Iz5rW15YTnFJSw==", "kbnQi");
    llIIIIIIIlllll[llIIIIIIlIIlII[98]] = lIIIIIIlIIIllllI("UJF/TkHbRAIO12vOQtRS9dyGUj3ba331rHvDXvoCYztnBwlYXXOyzJLFgxq1qSqtellTUoQ3d73dI0nyO8jvLlHHwcSSmQyc", "QnvMy");
    llIIIIIIIlllll[llIIIIIIlIIlII[15]] = lIIIIIIlIIIllllI("5xFBGsaxWZVxGikOtDP5QPMCgES+AfYGKtM/jb6TJsLdWJP7Np2/RYLHjpIRp1im/dwnc14bzm11O31drs1uOCWX9E3f4jke", "wfLhD");
    llIIIIIIIlllll[llIIIIIIlIIlII[59]] = lIIIIIIlIIIlllll("LxYVeiooHQQ3NSAVFXoyNRoNeiogBwl6BS0cAj8XLgBbMjIvED5lcHZKVGIYLklJfQ57U0E=", "AsaTG");
    llIIIIIIIlllll[llIIIIIIlIIlII[100]] = lIIIIIIlIIIllllI("OcD/5ERGOqSpz/GiHzkPPS3e4Xf9QfAwo33usqPIIkO8SMVbbTZvbQ==", "WWtpb");
    llIIIIIIIlllll[llIIIIIIlIIlII[101]] = lIIIIIIlIIIlllIl("TVRI2zsL9+dvrifBr7BQOznfN204V1vxpS9sieRUKnSpVSOFw65tggzs6SojmJ0cdtaeC01k/Xc=", "DbzrF");
    llIIIIIIIlllll[llIIIIIIlIIlII[77]] = lIIIIIIlIIIllllI("joLslsdqeVRzEni0GThUnBb8ZuJizkdnrtQLhkM1X5uibUpRkjPMSp8YCCObUq8NSf7Aj3Uo6TAmEZv3E6vnjy4M4vwXErUf", "pOxLI");
    llIIIIIIIlllll[llIIIIIIlIIlII[94]] = lIIIIIIlIIIlllll("BgBGOjceFQE9JwQCRisrG0sOcXkZAAYtJhlfXHNjS0U=", "kehIC");
    llIIIIIIIlllll[llIIIIIIlIIlII[103]] = lIIIIIIlIIIlllIl("+4lodRkovBsYATWiye4aIl60eVaY4VsnNlF5WvTYvFtQnDRrhSI/iAVAn/YBWtob", "QjqBA");
    llIIIIIIIlllll[llIIIIIIlIIlII[57]] = lIIIIIIlIIIllllI("ug/cuNioUd8yZDYdPw/x+6x22SuDBJAWYb+v5+WKXZjH1o+8tJJYdxwKCRMIo1SWZ5oDjIkDX5+v0C8hpFf8UrZi2wkVPBILHwtRUi+y93FnmgOMiQNfn6/QLyGkV/xStmLbCRU8EgtYSiWwf2iKVQ==", "fnvQD");
    llIIIIIIIlllll[llIIIIIIlIIlII[35]] = lIIIIIIlIIIlllll("KCBWBREwNRECASoiVhQNNWseTl8xKh8RCSB/UF8zf2VY", "EExve");
    llIIIIIIIlllll[llIIIIIIlIIlII[105]] = lIIIIIIlIIIlllll("KAJGBRAwFwECACoARhQMNUkOTl43AgYSATddXExEZUdIVg==", "Eghvd");
    llIIIIIIIlllll[llIIIIIIlIIlII[89]] = lIIIIIIlIIIllllI("9X7z/ZQB/EH6/9wwIjAMZQBBWyWZB7mZdgS4bduzIdSf+iH6A/8Vy2Ae9Dsu2Nvv12LehdEuBwrHJgmnhSDIBGNi/N9W/uzMKX/jnpl4KUwEcSis5Ke11zAhAfJpN9Ac", "zTAUS");
    llIIIIIIIlllll[llIIIIIIlIIlII[106]] = lIIIIIIlIIIlllIl("6Z5cQy+5czwLVFb1uvU6yS+GEed5zw40f4X3wk/kn6I1phkcb2NspQ==", "NDfZR");
    llIIIIIIIlllll[llIIIIIIlIIlII[107]] = lIIIIIIlIIIllllI("2nG5TtLslsi7hWRYkVgMbaGe119IEsU+6Q7zxH4BMiSmRcS4mp+A8hK8V9AlmuJKYyIe7k5te4d3ih3vLlQ10mPu4YG45upKIP3amMk4SkQQx7BWYdU6Dg==", "dMpga");
    llIIIIIIIlllll[llIIIIIIlIIlII[108]] = lIIIIIIlIIIlllll("BDAQXSMDOwEQPAszEF07HjwIXQsEIAk1Lwk8ChR0LhozPXRYZV5Tbkp1", "jUdsN");
    llIIIIIIIlllll[llIIIIIIlIIlII[79]] = lIIIIIIlIIIlllIl("rMSZZhQRZD3x3gO4M+ucde/ePOIhlbos2sng/0WNcCHd9d3ABHSXUp55FsQvY+34MUFEMLh+QAiOnM6NpwPjea0dWjRM8p9KyGBtaEpSq+5LxR6qKUrrkPhA4MMtgJTq", "PTbzk");
    llIIIIIIIlllll[llIIIIIIlIIlII[104]] = lIIIIIIlIIIllllI("JO5PkUkOlt72c973uma3+6f7ew/U1A9nM4uTH5ssyuxAwbGYeLRwPIxsGAaq2hOh8bYxdasBWX0QUQCtYMMsGg==", "ghZsS");
    llIIIIIIIlllll[llIIIIIIlIIlII[26]] = lIIIIIIlIIIllllI("HKbV/4iSUS903wKGL9n1odRk+OaM6CNrVeuVuiZqTVr3a7bRHLSjOw==", "Kihnx");
    llIIIIIIIlllll[llIIIIIIlIIlII[75]] = lIIIIIIlIIIlllIl("wefgH5FcJfm3bY2gz3i/q9L3xSDzXMOI4v2n9fQG46gvPTjzegIFMQFSZOu6+VVg", "ZSGdN");
    llIIIIIIIlllll[llIIIIIIlIIlII[102]] = lIIIIIIlIIIllllI("8LHV3fvhEnnyWbJLXm/g/sHmdGM/prZYW8GNZLON/+fsyN9Jg2wXDg==", "HuQJL");
    llIIIIIIIlllll[llIIIIIIlIIlII[18]] = lIIIIIIlIIIllllI("oni+bsbqmsQ6Tnc6rOq5Fgk660D9wt/nNQPP8ZSkiZtNpJtVfTDswGz3FJcf+FX3uHLdnWXODrsYqhKJ7fYhk66bCqTweCcLAE4SOZTTpsW4ct2dZc4OuxiqEont9iGTVU6D5iH4pQm7MJNEc8+T7jhQ3oec8Sn8", "SOcQM");
    llIIIIIIIlllll[llIIIIIIlIIlII[72]] = lIIIIIIlIIIlllIl("WfCOdDxjkVty4JIJXcOtxTbYdfxQvN+3DgJBCAC24nSzRUnWVUf01aEPBr2M91JK3dgKsoIqK191ttFO3Cl302Gx1XwdJHBNs4HnUdDlyhbe635Fk6O9WpSzKoigPuUA", "YGlRM");
    llIIIIIIIlllll[llIIIIIIlIIlII[99]] = lIIIIIIlIIIllllI("9klYnW+h9DDTSxAm122VZpv4n4TrngqcWdmbgdxR6Hldqf9YMJdhq/Ol9EeV3AjlIcYyhO5cJ8Jm4WkeJ4PA66u+fAva2nfnZhQOpAoMf2NuHiN2mya+mw==", "yZhDc");
    llIIIIIIIlllll[llIIIIIIlIIlII[110]] = lIIIIIIlIIIlllll("LCdYKyE0Mh8sMS4lWDo9MWwQYG8tIwUsHS42FDknEi4ZLG94eFZ4dWFi", "ABvXU");
    llIIIIIIIlllll[llIIIIIIlIIlII[109]] = lIIIIIIlIIIlllIl("CbA7f5qlgP6Viz/DM7xoi94IpzmpuQMxtCA8yEtQbvnXn0DbpQC8wL4agbDNU5LHY0kMwhuLz0p4A9IAHKrUuA==", "fBMaV");
    llIIIIIIIlllll[llIIIIIIlIIlII[111]] = lIIIIIIlIIIlllll("HT9EICMFKgMnMx89RDE/AHQMa20CPw06JAQ/GBE4HzYPMjlKciY5NgY7RT82Hj1FACMCMwQ0bCpzJj4yXykeJicZLg48MF84AiN4FmtaY2dAalpjZ0BqWmNnQGpaY2dAak4ROB82DzI5S2BKcw==", "pZjSW");
    llIIIIIIIlllll[llIIIIIIlIIlII[80]] = lIIIIIIlIIIlllIl("HkVDtEWvHgafAzzwZlQNHS2gtdd+ZCt2NSGxVB7gXoSXgVaTU2Nfaj6jCkt54nEozz1A7OwweKg=", "RHDLR");
    llIIIIIIIlllll[llIIIIIIlIIlII[95]] = lIIIIIIlIIIlllll("ISEMZgMmKh0rHC4iDGYbOy0UZgMuMBBmLCMrGyM+IDdCLhshJyd5WXh9TXoxP35QYSd1ZFg=", "ODxHn");
    llIIIIIIIlllll[llIIIIIIlIIlII[51]] = lIIIIIIlIIIllllI("B8gEGvqMLTI8NHc3ee/VnV+hOK5YJBcjbEKcntE6IjEOLbtqRV4erQkNVrt+fdfs9fKUyCuUEI4=", "JZugA");
    llIIIIIIIlllll[llIIIIIIlIIlII[113]] = lIIIIIIlIIIllllI("qMm9whFOfOUh2c7zd957YVlWxkhOGkw5jHHMn1tk89HloNdS9McoGSKglaTwnFmy", "ySZrq");
    llIIIIIIIlllll[llIIIIIIlIIlII[42]] = lIIIIIIlIIIlllll("JAQjG0k7ETwWSQcRMAgGOgonQA8vFhsfHzpffVM9dEV1", "NeUzg");
    llIIIIIIIlllll[llIIIIIIlIIlII[83]] = lIIIIIIlIIIlllIl("3RQzlx1ieRr5k76QpiQN1ZecyxbfIw2lsqp8JCwupenACzcDm1otmnaK6DUEnqgCla/Kkd539qVswDzIw1ovDuxbhIlvPSLDGKSs31UeUaFqlyUE0RTTdw==", "gLesX");
    llIIIIIIIlllll[llIIIIIIlIIlII[74]] = lIIIIIIlIIIlllll("CQYiQD8ODTMNIAYFIkAnEwo6QBcJFjsoMwQKOAloARY4DQ1WVGBZYVM8MlR6Ti84CyZIDj8ANwQRNwgmSBYiBz5IJjgbPyECNQc8AFhsTnI=", "gcVnR");
    llIIIIIIIlllll[llIIIIIIlIIlII[112]] = lIIIIIIlIIIllllI("Eez0SUPN36UbhAx+AwnmnwSZ6GXypwcUWFer2neAWPc9pjq55JM0Mg==", "mpBXX");
    llIIIIIIIlllll[llIIIIIIlIIlII[48]] = lIIIIIIlIIIllllI("F8/PpE7TtsVlzKSoYAGbBEpZR+bvgbmzXxV8SDhdBk8=", "SCcwo");
    llIIIIIIIlllll[llIIIIIIlIIlII[34]] = lIIIIIIlIIIlllll("Cw1ENC0TGAMzPQkPRCUxFkYMd2hcDw8zGwodD31xTyFQZ3k=", "fhjGY");
    llIIIIIIIlllll[llIIIIIIlIIlII[14]] = lIIIIIIlIIIllllI("O4xtxQNxOvpfRDQ96FJAU4hTaBfYQ3wXtG97Z9Ut8nd1GBNMYqYNadeqKxoCmRC32ikfH2lMTfU=", "alUvz");
    llIIIIIIIlllll[llIIIIIIlIIlII[114]] = lIIIIIIlIIIllllI("kHuZxwhh0isYm47YeqEEGC1wXLaoNC0djHo6+6RUDMx/1smC+z15fA==", "zjMMc");
    llIIIIIIIlllll[llIIIIIIlIIlII[115]] = lIIIIIIlIIIlllIl("owCKIQ5FsecHHnURPHG19WfftIf+QbPYeSJWoYXzE5Q=", "XspSG");
    llIIIIIIIlllll[llIIIIIIlIIlII[116]] = lIIIIIIlIIIlllll("JSk/fAAiIi4xHyoqP3wOJyUuPBllASI8CCg+KjQZcSoiNwEvE3xjWXh1FDVXfHZrck0=", "KLKRm");
    llIIIIIIIlllll[llIIIIIIlIIlII[117]] = lIIIIIIlIIIlllIl("jIcgK1+PDda2eHD+Lb6BkPXT6+42okFiVjACsMK7rNEgjsiOJSr2TA==", "uuaNj");
    llIIIIIIIlllll[llIIIIIIlIIlII[118]] = lIIIIIIlIIIllllI("ctu/y/3QT6bagHg3GISXcXxDYbMo9e5ydSJ1Dsrr8BY42IZ0tU6O811zwySeabI4uSp5J9wLD5YjhU88WLhQWU1SGViocdFy", "KVqXq");
    llIIIIIIIlllll[llIIIIIIlIIlII[119]] = lIIIIIIlIIIlllIl("8VfOqFe+hTNkNey4pE0OlcRWnqcHGT/WS+AjxzuuaNpAbzAHqwn6JA==", "IcHYL");
    llIIIIIIIlllll[llIIIIIIlIIlII[120]] = lIIIIIIlIIIlllIl("M+jgQEg6GXNVh5rx32NMOdmKxbvPCeLE8xkbK4RlVEgx8dvHa1ZeYOnzItY15/8HnnODOA6PYa8S4KHLa3A4o1XYYIEaLc+Tr6EMKCJ0G5koncCkoiBTuw==", "VsBGr");
    llIIIIIIIlllll[llIIIIIIlIIlII[121]] = lIIIIIIlIIIlllll("KSkFbDguIhQhJyYqBWw2KyUULCFpKR82PDM1Xwc7MyUFOwUrLQgnJxQcSyQ8IiAVHWJ2fEZzCiU1S3NlfWxRYg==", "GLqBU");
    llIIIIIIlIIIll = null;
  }
  
  private static void lIIIIIIlIIlIllIl() {
    String str = (new Exception()).getStackTrace()[llIIIIIIlIIlII[0]].getFileName();
    llIIIIIIlIIIll = str.substring(str.indexOf("ä") + llIIIIIIlIIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIIIlllll(String lllllllllllllllIllIlllIlIllIIIIl, String lllllllllllllllIllIlllIlIllIIIII) {
    lllllllllllllllIllIlllIlIllIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIllIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIlIlIlllll = new StringBuilder();
    char[] lllllllllllllllIllIlllIlIlIllllI = lllllllllllllllIllIlllIlIllIIIII.toCharArray();
    int lllllllllllllllIllIlllIlIlIlllIl = llIIIIIIlIIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIlIllIIIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIlIIlII[0];
    while (lIIIIIIlIlIIlIII(j, i)) {
      char lllllllllllllllIllIlllIlIllIIIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIlIlIlllIl++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() < " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIlIlIlllll);
  }
  
  private static String lIIIIIIlIIIllllI(String lllllllllllllllIllIlllIlIlIllIIl, String lllllllllllllllIllIlllIlIlIllIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlIlIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlIlIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIlIlIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIlIlIllIll.init(llIIIIIIlIIlII[2], lllllllllllllllIllIlllIlIlIlllII);
      return new String(lllllllllllllllIllIlllIlIlIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlIlIllIlI) {
      lllllllllllllllIllIlllIlIlIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIIIlllIl(String lllllllllllllllIllIlllIlIlIlIlII, String lllllllllllllllIllIlllIlIlIlIIll) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlIlIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlIlIlIIll.getBytes(StandardCharsets.UTF_8)), llIIIIIIlIIlII[13]), "DES");
      Cipher lllllllllllllllIllIlllIlIlIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIlIlIlIllI.init(llIIIIIIlIIlII[2], lllllllllllllllIllIlllIlIlIlIlll);
      return new String(lllllllllllllllIllIlllIlIlIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlIlIlIlIl) {
      lllllllllllllllIllIlllIlIlIlIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIlllIll() {
    llIIIIIIlIIlII = new int[123];
    llIIIIIIlIIlII[0] = (0xE2 ^ 0xC7) << " ".length() & ((0x6D ^ 0x48) << " ".length() ^ 0xFFFFFFFF);
    llIIIIIIlIIlII[1] = " ".length();
    llIIIIIIlIIlII[2] = " ".length() << " ".length();
    llIIIIIIlIIlII[3] = "   ".length();
    llIIIIIIlIIlII[4] = (0x47 ^ 0x42) << " ".length() << " ".length();
    llIIIIIIlIIlII[5] = " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[6] = (0x66 ^ 0x69) << " ".length() ^ 0xA3 ^ 0xB8;
    llIIIIIIlIIlII[7] = "   ".length() << " ".length();
    llIIIIIIlIIlII[8] = ((0xCB ^ 0xC0) << " ".length() << " ".length()) + ((0x61 ^ 0x66) << " ".length()) - ("   ".length() << " ".length() << " ".length() << " ".length()) + 111 + 130 - 180 + 184;
    llIIIIIIlIIlII[9] = -" ".length();
    llIIIIIIlIIlII[10] = "   ".length() << " ".length() << " ".length() ^ 0x25 ^ 0x2E;
    llIIIIIIlIIlII[11] = 0x26 ^ 0x2F;
    llIIIIIIlIIlII[12] = ((0x43 ^ 0x4E) << " ".length() ^ 0x2C ^ 0x3F) << " ".length() << " ".length();
    llIIIIIIlIIlII[13] = " ".length() << "   ".length();
    llIIIIIIlIIlII[14] = 0xD4 ^ 0xBB;
    llIIIIIIlIIlII[15] = (0xA9 ^ 0xBA) << " ".length() << " ".length();
    llIIIIIIlIIlII[16] = 3 + 39 - -11 + 138 ^ (0xB7 ^ 0x9C) << " ".length() << " ".length();
    llIIIIIIlIIlII[17] = ((0xD4 ^ 0xC5) << " ".length() << " ".length() ^ 0xDF ^ 0x9E) << " ".length();
    llIIIIIIlIIlII[18] = 0xEE ^ 0xB1;
    llIIIIIIlIIlII[19] = (0x24 ^ 0x17) << " ".length() << " ".length() ^ 93 + 35 - 124 + 195;
    llIIIIIIlIIlII[20] = 0xAC ^ 0x9D;
    llIIIIIIlIIlII[21] = "   ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[22] = (0x6 ^ 0x1) << " ".length() << " ".length();
    llIIIIIIlIIlII[23] = 0x40 ^ 0x3 ^ (0x8D ^ 0xAA) << " ".length();
    llIIIIIIlIIlII[24] = (0xCE ^ 0x99) << " ".length() ^ 105 + 81 - 41 + 10;
    llIIIIIIlIIlII[25] = (0x1B ^ 0x1C) << " ".length();
    llIIIIIIlIIlII[26] = (" ".length() << " ".length() << " ".length() ^ 0x22 ^ 0x31) << " ".length() << " ".length();
    llIIIIIIlIIlII[27] = (0x6D ^ 0x58) << " ".length() ^ 0x61 ^ 0x4;
    llIIIIIIlIIlII[28] = (0x39 ^ 0x34) << " ".length() << " ".length();
    llIIIIIIlIIlII[29] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[30] = (0x1F ^ 0xE) << " ".length() << " ".length();
    llIIIIIIlIIlII[31] = (0xB5 ^ 0xB2) << " ".length() ^ 0xBC ^ 0xA3;
    llIIIIIIlIIlII[32] = (0xA3 ^ 0xB0) << " ".length();
    llIIIIIIlIIlII[33] = (0xB8 ^ 0xB1) << " ".length();
    llIIIIIIlIIlII[34] = (0x8A ^ 0x8F ^ (0x4B ^ 0x52) << " ".length()) << " ".length();
    llIIIIIIlIIlII[35] = (0x73 ^ 0x66) << " ".length() << " ".length();
    llIIIIIIlIIlII[36] = 0x62 ^ 0x5D;
    llIIIIIIlIIlII[37] = 0xA6 ^ 0xB3;
    llIIIIIIlIIlII[38] = 0x90 ^ 0x8B;
    llIIIIIIlIIlII[39] = (0x11 ^ 0x1A) << " ".length();
    llIIIIIIlIIlII[40] = (0x60 ^ 0x6F) << "   ".length() ^ 0x68 ^ 0x55;
    llIIIIIIlIIlII[41] = 0x66 ^ 0x63 ^ (0x1 ^ 0x8) << " ".length();
    llIIIIIIlIIlII[42] = "   ".length() << " ".length() << " ".length() ^ 0xEF ^ 0x8A;
    llIIIIIIlIIlII[43] = "   ".length() << "   ".length();
    llIIIIIIlIIlII[44] = (0x23 ^ 0x32) << " ".length();
    llIIIIIIlIIlII[45] = 0x36 ^ 0x2F;
    llIIIIIIlIIlII[46] = (0xB ^ 0x36) << " ".length() ^ 0x9B ^ 0xA2;
    llIIIIIIlIIlII[47] = ((0x93 ^ 0x94) << " ".length() ^ "   ".length()) << " ".length();
    llIIIIIIlIIlII[48] = 48 + 178 - 210 + 225 ^ (0x4F ^ 0x68) << " ".length() << " ".length();
    llIIIIIIlIIlII[49] = "   ".length() << "   ".length() ^ 0x7B ^ 0x2A;
    llIIIIIIlIIlII[50] = 0x81 ^ 0x94 ^ " ".length() << "   ".length();
    llIIIIIIlIIlII[51] = 0xD2 ^ 0xB5;
    llIIIIIIlIIlII[52] = (0xDE ^ 0x95 ^ (0x1D ^ 0xC) << " ".length() << " ".length()) << " ".length();
    llIIIIIIlIIlII[53] = (0x56 ^ 0x5F) << " ".length() ^ 0x64 ^ 0x69;
    llIIIIIIlIIlII[54] = (0x40 ^ 0x4F) << " ".length() << " ".length();
    llIIIIIIlIIlII[55] = " ".length() << ((0x6C ^ 0x37) << " ".length() ^ 177 + 154 - 165 + 13);
    llIIIIIIlIIlII[56] = (0xB1 ^ 0xA2) << " ".length() << " ".length() ^ 0x1C ^ 0x71;
    llIIIIIIlIIlII[57] = (0x4E ^ 0x23) << " ".length() ^ 7 + 52 - 1 + 79;
    llIIIIIIlIIlII[58] = (0xAC ^ 0xA9) << " ".length() << " ".length() ^ 0xA8 ^ 0x9F;
    llIIIIIIlIIlII[59] = 0x44 ^ 0x9;
    llIIIIIIlIIlII[60] = (0xBA ^ 0xA9) << " ".length() << " ".length() ^ 0x2B ^ 0x5A;
    llIIIIIIlIIlII[61] = (0x1 ^ 0x72) << " ".length() ^ 15 + 77 - -29 + 74;
    llIIIIIIlIIlII[62] = (0x6E ^ 0x75) << " ".length();
    llIIIIIIlIIlII[63] = "   ".length() << " ".length() ^ 0xA7 ^ 0x86;
    llIIIIIIlIIlII[64] = ((0x4F ^ 0x64) << " ".length() ^ 0x38 ^ 0x6B) << "   ".length();
    llIIIIIIlIIlII[65] = 95 + 228 - 265 + 181 ^ "   ".length() << "   ".length() << " ".length();
    llIIIIIIlIIlII[66] = 0x1B ^ 0x32;
    llIIIIIIlIIlII[67] = ("   ".length() << " ".length() << " ".length() << " ".length() ^ 0xB ^ 0x2E) << " ".length();
    llIIIIIIlIIlII[68] = 56 + 23 - 19 + 69 ^ (0xFD ^ 0xA8) << " ".length();
    llIIIIIIlIIlII[69] = ((0xA9 ^ 0x98) << " ".length() ^ 0xD ^ 0x64) << " ".length() << " ".length();
    llIIIIIIlIIlII[70] = (0x5F ^ 0x50) << "   ".length() ^ 0x7E ^ 0x2B;
    llIIIIIIlIIlII[71] = ((0xBB ^ 0xAC) << " ".length() ^ 0x1A ^ 0x23) << " ".length();
    llIIIIIIlIIlII[72] = "   ".length() << (0xBC ^ 0xB9);
    llIIIIIIlIIlII[73] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[74] = 127 + 125 - 67 + 34 ^ (0x56 ^ 0x5D) << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[75] = 0x15 ^ 0x48;
    llIIIIIIlIIlII[76] = (0x40 ^ 0x59) << " ".length();
    llIIIIIIlIIlII[77] = (0x4C ^ 0x49) << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[78] = 0xA0 ^ 0x93;
    llIIIIIIlIIlII[79] = ("   ".length() << " ".length() ^ 0xD ^ 0x26) << " ".length();
    llIIIIIIlIIlII[80] = 19 + 191 - 67 + 102 ^ (0xE ^ 0x7) << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[81] = ((0x6B ^ 0x3A) << " ".length() ^ 15 + 102 - 14 + 26) << " ".length();
    llIIIIIIlIIlII[82] = 0x6E ^ 0x59;
    llIIIIIIlIIlII[83] = (0x44 ^ 0x21 ^ (0x22 ^ 0x27) << " ".length() << " ".length() << " ".length()) << " ".length();
    llIIIIIIlIIlII[84] = ((0xB2 ^ 0x99) << " ".length() ^ 0x94 ^ 0xC5) << "   ".length();
    llIIIIIIlIIlII[85] = (0x94 ^ 0x8F) << " ".length() << " ".length() ^ 0x6D ^ 0x38;
    llIIIIIIlIIlII[86] = (0x0 ^ 0x1D) << " ".length();
    llIIIIIIlIIlII[87] = 0x96 ^ 0xAD;
    llIIIIIIlIIlII[88] = ((0x72 ^ 0x6D) << " ".length() ^ 0x6C ^ 0x5B) << "   ".length();
    llIIIIIIlIIlII[89] = (20 + 52 - -50 + 43 ^ (0xDC ^ 0x9B) << " ".length()) << " ".length();
    llIIIIIIlIIlII[90] = (0x90 ^ 0x8F) << " ".length();
    llIIIIIIlIIlII[91] = " ".length() << "   ".length() << " ".length();
    llIIIIIIlIIlII[92] = 0x87 ^ 0xC6 ^ (0xBC ^ 0xAB) & (0x2D ^ 0x3A ^ 0xFFFFFFFF) & ((0x3B ^ 0x1A) << " ".length() & ((0x91 ^ 0xB0) << " ".length() ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
    llIIIIIIlIIlII[93] = (172 + 146 - 205 + 60 ^ (0x2F ^ 0xC) << " ".length() << " ".length()) << " ".length();
    llIIIIIIlIIlII[94] = 23 + 71 - 37 + 70 << " ".length() ^ 118 + 65 - 80 + 72;
    llIIIIIIlIIlII[95] = (0xB ^ 0x38) << " ".length();
    llIIIIIIlIIlII[96] = (0x1A ^ 0x15) << " ".length() << " ".length() ^ 0x6B ^ 0x10;
    llIIIIIIlIIlII[97] = (0x8 ^ 0x2D) << " ".length();
    llIIIIIIlIIlII[98] = 4 + 20 - 17 + 186 ^ (0xEF ^ 0xAA) << " ".length();
    llIIIIIIlIIlII[99] = (0x39 ^ 0x32) << " ".length() ^ 0xF8 ^ 0x8F;
    llIIIIIIlIIlII[100] = (0x47 ^ 0x62 ^ " ".length() << " ".length()) << " ".length();
    llIIIIIIlIIlII[101] = 0xBD ^ 0xC4 ^ (0x9A ^ 0x81) << " ".length();
    llIIIIIIlIIlII[102] = ((0x82 ^ 0x93) << " ".length() << " ".length() ^ 0xCB ^ 0xA0) << " ".length();
    llIIIIIIlIIlII[103] = (0xC ^ 0x25) << " ".length();
    llIIIIIIlIIlII[104] = 0xFE ^ 0xA5;
    llIIIIIIlIIlII[105] = 0x2E ^ 0x1B ^ "   ".length() << (0x9F ^ 0x9A);
    llIIIIIIlIIlII[106] = (0xB9 ^ 0xB2) << " ".length() ^ 0xC9 ^ 0x88;
    llIIIIIIlIIlII[107] = ((0x28 ^ 0x3D) << " ".length() ^ 0xE0 ^ 0xC1) << "   ".length();
    llIIIIIIlIIlII[108] = 0x38 ^ 0x61;
    llIIIIIIlIIlII[109] = 0xB3 ^ 0xBA ^ (0x52 ^ 0x67) << " ".length();
    llIIIIIIlIIlII[110] = (0x5E ^ 0x6F) << " ".length();
    llIIIIIIlIIlII[111] = (0xFE ^ 0xA9 ^ (0x17 ^ 0x30) << " ".length()) << " ".length() << " ".length();
    llIIIIIIlIIlII[112] = (0x1F ^ 0x4) << " ".length() << " ".length();
    llIIIIIIlIIlII[113] = ((0xBA ^ 0xA5) << " ".length() << " ".length() ^ 0x75 ^ 0x4) << "   ".length();
    llIIIIIIlIIlII[114] = (0xF ^ 0x8) << " ".length() << " ".length() << " ".length();
    llIIIIIIlIIlII[115] = 210 + 152 - 255 + 114 ^ (0x29 ^ 0x2) << " ".length() << " ".length();
    llIIIIIIlIIlII[116] = (0xB ^ 0x32) << " ".length();
    llIIIIIIlIIlII[117] = (0x77 ^ 0x72) << " ".length() << " ".length() ^ 0xF5 ^ 0x92;
    llIIIIIIlIIlII[118] = ((0xE ^ 0x1) << "   ".length() ^ 0xCD ^ 0xA8) << " ".length() << " ".length();
    llIIIIIIlIIlII[119] = 0x70 ^ 0x5;
    llIIIIIIlIIlII[120] = ((0x79 ^ 0x6E) << " ".length() ^ 0x6C ^ 0x79) << " ".length();
    llIIIIIIlIIlII[121] = 0xAF ^ 0xC6 ^ (0x77 ^ 0x78) << " ".length();
    llIIIIIIlIIlII[122] = (0x72 ^ 0x7D) << "   ".length();
  }
  
  private static boolean lIIIIIIlIlIlIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlIlIIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlIlIlIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIlIlIIlIIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIIlIlIIIlII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIIlIlIIlIlI(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIIlIIllllII(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIIIlIlIIIIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIIlIlIIIIIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIIlIlIIllIl(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lIIIIIIlIlIIIlll(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static boolean lIIIIIIlIIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIIIlIlIIIlIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIIIlIlIIllII(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIIlIlIIlIll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIIlIlIIllll(float paramFloat1, float paramFloat2) {
    return paramFloat1 cmp paramFloat2;
  }
  
  private static int lIIIIIIlIlIlIIII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */