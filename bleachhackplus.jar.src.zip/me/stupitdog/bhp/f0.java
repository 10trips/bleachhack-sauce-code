package me.stupitdog.bhp;

import java.io.PrintStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Block;
import net.minecraft.block.BlockChest;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiScreenHorseInventory;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

public class f0 extends au {
  ao timer;
  
  public static final List<Block> shulkerList;
  
  private int chestSlot;
  
  private int stage;
  
  private int chest;
  
  private int maxChests;
  
  private GuiScreenHorseInventory entityChest;
  
  @EventHandler
  private Listener<f100> onPacketEventSend;
  
  private static String[] llIIIIIIlIllII;
  
  private static Class[] llIIIIIIlIllIl;
  
  private static final String[] llIIIIlIllIlll;
  
  private static String[] llIIIIlIlllIII;
  
  private static final int[] llIIIIlIlllIIl;
  
  public f0() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: aload_0
    //   42: new me/stupitdog/bhp/ao
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: <illegal opcode> 1 : (Lme/stupitdog/bhp/f0;Lme/stupitdog/bhp/ao;)V
    //   54: aload_0
    //   55: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   58: iconst_3
    //   59: iaload
    //   60: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0;I)V
    //   65: aload_0
    //   66: new me/zero/alpine/listener/Listener
    //   69: dup
    //   70: aload_0
    //   71: <illegal opcode> invoke : (Lme/stupitdog/bhp/f0;)Lme/zero/alpine/listener/EventHook;
    //   76: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   79: iconst_0
    //   80: iaload
    //   81: anewarray java/util/function/Predicate
    //   84: invokespecial <init> : (Lme/zero/alpine/listener/EventHook;[Ljava/util/function/Predicate;)V
    //   87: <illegal opcode> 3 : (Lme/stupitdog/bhp/f0;Lme/zero/alpine/listener/Listener;)V
    //   92: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	93	0	lllllllllllllllIllIllIIlIlllIIII	Lme/stupitdog/bhp/f0;
  }
  
  public void onEnable() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0;I)V
    //   11: aload_0
    //   12: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   15: iconst_0
    //   16: iaload
    //   17: <illegal opcode> 5 : (Lme/stupitdog/bhp/f0;I)V
    //   22: aload_0
    //   23: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   26: iconst_0
    //   27: iaload
    //   28: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0;I)V
    //   33: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: istore_1
    //   39: iload_1
    //   40: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   43: iconst_4
    //   44: iaload
    //   45: invokestatic lIIIIIlIlIlllIll : (II)Z
    //   48: ifeq -> 134
    //   51: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   56: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   61: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   66: iload_1
    //   67: <illegal opcode> 10 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   72: <illegal opcode> 11 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   77: astore_2
    //   78: aload_2
    //   79: instanceof net/minecraft/item/ItemBlock
    //   82: invokestatic lIIIIIlIlIllllII : (I)Z
    //   85: ifeq -> 115
    //   88: aload_2
    //   89: checkcast net/minecraft/item/ItemBlock
    //   92: <illegal opcode> 12 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   97: <illegal opcode> 13 : ()Lnet/minecraft/block/BlockChest;
    //   102: invokestatic lIIIIIlIlIllllIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   105: ifeq -> 115
    //   108: aload_0
    //   109: iload_1
    //   110: <illegal opcode> 2 : (Lme/stupitdog/bhp/f0;I)V
    //   115: iinc #1, 1
    //   118: ldc ''
    //   120: invokevirtual length : ()I
    //   123: pop
    //   124: ldc ' '
    //   126: invokevirtual length : ()I
    //   129: ineg
    //   130: iflt -> 39
    //   133: return
    //   134: <illegal opcode> 14 : ()Ljava/io/PrintStream;
    //   139: aload_0
    //   140: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0;)I
    //   145: <illegal opcode> 16 : (Ljava/io/PrintStream;I)V
    //   150: aload_0
    //   151: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0;)I
    //   156: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   159: iconst_3
    //   160: iaload
    //   161: invokestatic lIIIIIlIlIlllllI : (II)Z
    //   164: ifeq -> 188
    //   167: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   170: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   173: iconst_5
    //   174: iaload
    //   175: aaload
    //   176: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   181: aload_0
    //   182: <illegal opcode> 18 : (Lme/stupitdog/bhp/f0;)V
    //   187: return
    //   188: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   191: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   194: bipush #6
    //   196: iaload
    //   197: aaload
    //   198: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   203: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   78	37	2	lllllllllllllllIllIllIIlIllIllll	Lnet/minecraft/item/Item;
    //   39	95	1	lllllllllllllllIllIllIIlIllIlllI	I
    //   0	204	0	lllllllllllllllIllIllIIlIllIllIl	Lme/stupitdog/bhp/f0;
  }
  
  public void update() {
    // Byte code:
    //   0: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   3: iconst_1
    //   4: iaload
    //   5: <illegal opcode> 19 : (I)Z
    //   10: invokestatic lIIIIIlIlIllllII : (I)Z
    //   13: ifeq -> 23
    //   16: aload_0
    //   17: <illegal opcode> 18 : (Lme/stupitdog/bhp/f0;)V
    //   22: return
    //   23: aload_0
    //   24: <illegal opcode> 20 : (Lme/stupitdog/bhp/f0;)Lme/stupitdog/bhp/ao;
    //   29: ldc2_w 1000
    //   32: <illegal opcode> 21 : (Lme/stupitdog/bhp/ao;J)Z
    //   37: invokestatic lIIIIIlIlIllllII : (I)Z
    //   40: ifeq -> 965
    //   43: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   48: <illegal opcode> 22 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/WorldClient;
    //   53: <illegal opcode> 23 : (Lnet/minecraft/client/multiplayer/WorldClient;)Ljava/util/List;
    //   58: <illegal opcode> 24 : (Ljava/util/List;)Ljava/util/stream/Stream;
    //   63: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   68: <illegal opcode> 25 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   73: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   78: <illegal opcode> 25 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   83: <illegal opcode> test : ()Ljava/util/function/Predicate;
    //   88: <illegal opcode> 25 : (Ljava/util/stream/Stream;Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   93: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   98: <illegal opcode> 26 : (Ljava/util/stream/Stream;Ljava/util/function/Function;)Ljava/util/stream/Stream;
    //   103: <illegal opcode> apply : ()Ljava/util/function/Function;
    //   108: <illegal opcode> 27 : (Ljava/util/function/Function;)Ljava/util/Comparator;
    //   113: <illegal opcode> 28 : (Ljava/util/stream/Stream;Ljava/util/Comparator;)Ljava/util/Optional;
    //   118: aconst_null
    //   119: <illegal opcode> 29 : (Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;
    //   124: checkcast net/minecraft/entity/Entity
    //   127: astore_1
    //   128: aload_1
    //   129: invokestatic lIIIIIlIlIllllll : (Ljava/lang/Object;)Z
    //   132: ifeq -> 954
    //   135: aload_0
    //   136: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0;)I
    //   141: invokestatic lIIIIIlIllIIIIII : (I)Z
    //   144: ifeq -> 260
    //   147: aload_1
    //   148: instanceof net/minecraft/entity/passive/AbstractChestHorse
    //   151: invokestatic lIIIIIlIlIllllII : (I)Z
    //   154: ifeq -> 248
    //   157: aload_1
    //   158: checkcast net/minecraft/entity/passive/AbstractChestHorse
    //   161: <illegal opcode> 31 : (Lnet/minecraft/entity/passive/AbstractChestHorse;)Z
    //   166: invokestatic lIIIIIlIllIIIIII : (I)Z
    //   169: ifeq -> 248
    //   172: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   177: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   182: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   187: aload_0
    //   188: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0;)I
    //   193: putfield field_70461_c : I
    //   196: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   201: <illegal opcode> 32 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   206: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   211: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   216: aload_1
    //   217: <illegal opcode> 33 : ()Lnet/minecraft/util/EnumHand;
    //   222: <illegal opcode> 34 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   227: ldc ''
    //   229: invokevirtual length : ()I
    //   232: pop2
    //   233: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   236: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   239: bipush #7
    //   241: iaload
    //   242: aaload
    //   243: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   248: aload_0
    //   249: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   252: iconst_1
    //   253: iaload
    //   254: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0;I)V
    //   259: return
    //   260: aload_0
    //   261: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0;)I
    //   266: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   269: iconst_1
    //   270: iaload
    //   271: invokestatic lIIIIIlIlIlllllI : (II)Z
    //   274: ifeq -> 371
    //   277: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   282: <illegal opcode> 32 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   287: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   292: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   297: aload_1
    //   298: <illegal opcode> 33 : ()Lnet/minecraft/util/EnumHand;
    //   303: <illegal opcode> 34 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   308: ldc ''
    //   310: invokevirtual length : ()I
    //   313: pop2
    //   314: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   317: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   320: bipush #8
    //   322: iaload
    //   323: aaload
    //   324: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   329: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   334: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   339: <illegal opcode> 35 : (Lnet/minecraft/client/entity/EntityPlayerSP;)V
    //   344: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   347: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   350: bipush #9
    //   352: iaload
    //   353: aaload
    //   354: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   359: aload_0
    //   360: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   363: iconst_2
    //   364: iaload
    //   365: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0;I)V
    //   370: return
    //   371: aload_0
    //   372: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0;)I
    //   377: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   380: iconst_2
    //   381: iaload
    //   382: invokestatic lIIIIIlIlIlllllI : (II)Z
    //   385: ifeq -> 822
    //   388: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   393: <illegal opcode> 36 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/gui/GuiScreen;
    //   398: instanceof net/minecraft/client/gui/inventory/GuiScreenHorseInventory
    //   401: invokestatic lIIIIIlIlIllllII : (I)Z
    //   404: ifeq -> 768
    //   407: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   410: iconst_2
    //   411: iaload
    //   412: istore_2
    //   413: iload_2
    //   414: aload_0
    //   415: <illegal opcode> 37 : (Lme/stupitdog/bhp/f0;)Lnet/minecraft/client/gui/inventory/GuiScreenHorseInventory;
    //   420: <illegal opcode> 38 : (Lnet/minecraft/client/gui/inventory/GuiScreenHorseInventory;)Lnet/minecraft/inventory/IInventory;
    //   425: <illegal opcode> 39 : (Lnet/minecraft/inventory/IInventory;)I
    //   430: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   433: iconst_1
    //   434: iaload
    //   435: iadd
    //   436: invokestatic lIIIIIlIlIlllIll : (II)Z
    //   439: ifeq -> 768
    //   442: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   445: iconst_4
    //   446: iaload
    //   447: istore_3
    //   448: iload_3
    //   449: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   454: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   459: <illegal opcode> 40 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/inventory/Container;
    //   464: <illegal opcode> 41 : (Lnet/minecraft/inventory/Container;)Ljava/util/List;
    //   469: <illegal opcode> 42 : (Ljava/util/List;)I
    //   474: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   477: iconst_1
    //   478: iaload
    //   479: isub
    //   480: invokestatic lIIIIIlIlIlllIll : (II)Z
    //   483: ifeq -> 663
    //   486: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   491: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   496: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   501: iload_2
    //   502: <illegal opcode> 10 : (Lnet/minecraft/entity/player/InventoryPlayer;I)Lnet/minecraft/item/ItemStack;
    //   507: astore #4
    //   509: aload #4
    //   511: <illegal opcode> 43 : ()Lnet/minecraft/item/ItemStack;
    //   516: invokestatic lIIIIIlIllIIIIIl : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   519: ifeq -> 639
    //   522: aload #4
    //   524: <illegal opcode> 11 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   529: instanceof net/minecraft/item/ItemBlock
    //   532: invokestatic lIIIIIlIllIIIIII : (I)Z
    //   535: ifeq -> 571
    //   538: ldc ''
    //   540: invokevirtual length : ()I
    //   543: pop
    //   544: ldc ' '
    //   546: invokevirtual length : ()I
    //   549: ineg
    //   550: ldc ' '
    //   552: invokevirtual length : ()I
    //   555: ldc ' '
    //   557: invokevirtual length : ()I
    //   560: ldc ' '
    //   562: invokevirtual length : ()I
    //   565: ishl
    //   566: ishl
    //   567: if_icmple -> 639
    //   570: return
    //   571: aload #4
    //   573: <illegal opcode> 11 : (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item;
    //   578: checkcast net/minecraft/item/ItemBlock
    //   581: <illegal opcode> 12 : (Lnet/minecraft/item/ItemBlock;)Lnet/minecraft/block/Block;
    //   586: astore #5
    //   588: <illegal opcode> 44 : ()Ljava/util/List;
    //   593: aload #5
    //   595: <illegal opcode> 45 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   600: invokestatic lIIIIIlIlIllllII : (I)Z
    //   603: ifeq -> 639
    //   606: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   609: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   612: bipush #10
    //   614: iaload
    //   615: aaload
    //   616: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   621: aload_0
    //   622: dup
    //   623: <illegal opcode> 46 : (Lme/stupitdog/bhp/f0;)I
    //   628: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   631: iconst_1
    //   632: iaload
    //   633: iadd
    //   634: <illegal opcode> 6 : (Lme/stupitdog/bhp/f0;I)V
    //   639: iinc #3, 1
    //   642: ldc ''
    //   644: invokevirtual length : ()I
    //   647: pop
    //   648: ldc_w '   '
    //   651: invokevirtual length : ()I
    //   654: ldc ' '
    //   656: invokevirtual length : ()I
    //   659: if_icmpge -> 448
    //   662: return
    //   663: iinc #2, 1
    //   666: ldc ''
    //   668: invokevirtual length : ()I
    //   671: pop
    //   672: bipush #39
    //   674: bipush #32
    //   676: ixor
    //   677: ldc ' '
    //   679: invokevirtual length : ()I
    //   682: ldc ' '
    //   684: invokevirtual length : ()I
    //   687: ldc ' '
    //   689: invokevirtual length : ()I
    //   692: ishl
    //   693: ishl
    //   694: ishl
    //   695: bipush #56
    //   697: bipush #77
    //   699: ixor
    //   700: ixor
    //   701: ldc ' '
    //   703: invokevirtual length : ()I
    //   706: ldc ' '
    //   708: invokevirtual length : ()I
    //   711: ldc ' '
    //   713: invokevirtual length : ()I
    //   716: ishl
    //   717: ishl
    //   718: ishl
    //   719: sipush #188
    //   722: sipush #131
    //   725: ixor
    //   726: bipush #104
    //   728: bipush #117
    //   730: ixor
    //   731: ldc ' '
    //   733: invokevirtual length : ()I
    //   736: ishl
    //   737: ixor
    //   738: ldc ' '
    //   740: invokevirtual length : ()I
    //   743: ldc ' '
    //   745: invokevirtual length : ()I
    //   748: ldc ' '
    //   750: invokevirtual length : ()I
    //   753: ishl
    //   754: ishl
    //   755: ishl
    //   756: ldc ' '
    //   758: invokevirtual length : ()I
    //   761: ineg
    //   762: ixor
    //   763: iand
    //   764: ifeq -> 413
    //   767: return
    //   768: new java/lang/StringBuilder
    //   771: dup
    //   772: invokespecial <init> : ()V
    //   775: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   778: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   781: iconst_4
    //   782: iaload
    //   783: aaload
    //   784: <illegal opcode> 47 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   789: aload_0
    //   790: <illegal opcode> 46 : (Lme/stupitdog/bhp/f0;)I
    //   795: <illegal opcode> 48 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
    //   800: <illegal opcode> 49 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   805: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   810: aload_0
    //   811: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   814: iconst_5
    //   815: iaload
    //   816: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0;I)V
    //   821: return
    //   822: aload_0
    //   823: <illegal opcode> 30 : (Lme/stupitdog/bhp/f0;)I
    //   828: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   831: bipush #6
    //   833: iaload
    //   834: invokestatic lIIIIIlIlIlllllI : (II)Z
    //   837: ifeq -> 954
    //   840: getstatic me/stupitdog/bhp/f0.llIIIIlIllIlll : [Ljava/lang/String;
    //   843: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   846: bipush #11
    //   848: iaload
    //   849: aaload
    //   850: <illegal opcode> 17 : (Ljava/lang/String;)V
    //   855: aload_1
    //   856: instanceof net/minecraft/entity/passive/AbstractChestHorse
    //   859: invokestatic lIIIIIlIlIllllII : (I)Z
    //   862: ifeq -> 941
    //   865: aload_1
    //   866: checkcast net/minecraft/entity/passive/AbstractChestHorse
    //   869: <illegal opcode> 31 : (Lnet/minecraft/entity/passive/AbstractChestHorse;)Z
    //   874: invokestatic lIIIIIlIllIIIIII : (I)Z
    //   877: ifeq -> 941
    //   880: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   885: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   890: <illegal opcode> 9 : (Lnet/minecraft/client/entity/EntityPlayerSP;)Lnet/minecraft/entity/player/InventoryPlayer;
    //   895: aload_0
    //   896: <illegal opcode> 15 : (Lme/stupitdog/bhp/f0;)I
    //   901: putfield field_70461_c : I
    //   904: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   909: <illegal opcode> 32 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/multiplayer/PlayerControllerMP;
    //   914: <illegal opcode> 7 : ()Lnet/minecraft/client/Minecraft;
    //   919: <illegal opcode> 8 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   924: aload_1
    //   925: <illegal opcode> 33 : ()Lnet/minecraft/util/EnumHand;
    //   930: <illegal opcode> 34 : (Lnet/minecraft/client/multiplayer/PlayerControllerMP;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
    //   935: ldc ''
    //   937: invokevirtual length : ()I
    //   940: pop2
    //   941: aload_0
    //   942: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   945: bipush #6
    //   947: iaload
    //   948: <illegal opcode> 4 : (Lme/stupitdog/bhp/f0;I)V
    //   953: return
    //   954: aload_0
    //   955: <illegal opcode> 20 : (Lme/stupitdog/bhp/f0;)Lme/stupitdog/bhp/ao;
    //   960: <illegal opcode> 50 : (Lme/stupitdog/bhp/ao;)V
    //   965: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   509	130	4	lllllllllllllllIllIllIIlIllIllII	Lnet/minecraft/item/ItemStack;
    //   588	51	5	lllllllllllllllIllIllIIlIllIlIll	Lnet/minecraft/block/Block;
    //   448	215	3	lllllllllllllllIllIllIIlIllIlIlI	I
    //   413	355	2	lllllllllllllllIllIllIIlIllIlIIl	I
    //   128	837	1	lllllllllllllllIllIllIIlIllIlIII	Lnet/minecraft/entity/Entity;
    //   0	966	0	lllllllllllllllIllIllIIlIllIIlll	Lme/stupitdog/bhp/f0;
  }
  
  static {
    // Byte code:
    //   0: invokestatic lIIIIIlIlIlllIlI : ()V
    //   3: invokestatic lIIIIIlIlIlllIII : ()V
    //   6: invokestatic lIIIIIlIlIllIlll : ()V
    //   9: invokestatic lIIIIIlIlIllIIll : ()V
    //   12: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   15: bipush #12
    //   17: iaload
    //   18: anewarray net/minecraft/block/Block
    //   21: dup
    //   22: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   25: iconst_0
    //   26: iaload
    //   27: <illegal opcode> 59 : ()Lnet/minecraft/block/Block;
    //   32: aastore
    //   33: dup
    //   34: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   37: iconst_1
    //   38: iaload
    //   39: <illegal opcode> 60 : ()Lnet/minecraft/block/Block;
    //   44: aastore
    //   45: dup
    //   46: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   49: iconst_2
    //   50: iaload
    //   51: <illegal opcode> 61 : ()Lnet/minecraft/block/Block;
    //   56: aastore
    //   57: dup
    //   58: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   61: iconst_5
    //   62: iaload
    //   63: <illegal opcode> 62 : ()Lnet/minecraft/block/Block;
    //   68: aastore
    //   69: dup
    //   70: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   73: bipush #6
    //   75: iaload
    //   76: <illegal opcode> 63 : ()Lnet/minecraft/block/Block;
    //   81: aastore
    //   82: dup
    //   83: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   86: bipush #7
    //   88: iaload
    //   89: <illegal opcode> 64 : ()Lnet/minecraft/block/Block;
    //   94: aastore
    //   95: dup
    //   96: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   99: bipush #8
    //   101: iaload
    //   102: <illegal opcode> 65 : ()Lnet/minecraft/block/Block;
    //   107: aastore
    //   108: dup
    //   109: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   112: bipush #9
    //   114: iaload
    //   115: <illegal opcode> 66 : ()Lnet/minecraft/block/Block;
    //   120: aastore
    //   121: dup
    //   122: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   125: bipush #10
    //   127: iaload
    //   128: <illegal opcode> 67 : ()Lnet/minecraft/block/Block;
    //   133: aastore
    //   134: dup
    //   135: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   138: iconst_4
    //   139: iaload
    //   140: <illegal opcode> 68 : ()Lnet/minecraft/block/Block;
    //   145: aastore
    //   146: dup
    //   147: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   150: bipush #11
    //   152: iaload
    //   153: <illegal opcode> 69 : ()Lnet/minecraft/block/Block;
    //   158: aastore
    //   159: dup
    //   160: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   163: bipush #13
    //   165: iaload
    //   166: <illegal opcode> 70 : ()Lnet/minecraft/block/Block;
    //   171: aastore
    //   172: dup
    //   173: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   176: bipush #14
    //   178: iaload
    //   179: <illegal opcode> 71 : ()Lnet/minecraft/block/Block;
    //   184: aastore
    //   185: dup
    //   186: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   189: bipush #15
    //   191: iaload
    //   192: <illegal opcode> 72 : ()Lnet/minecraft/block/Block;
    //   197: aastore
    //   198: dup
    //   199: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   202: bipush #16
    //   204: iaload
    //   205: <illegal opcode> 73 : ()Lnet/minecraft/block/Block;
    //   210: aastore
    //   211: dup
    //   212: getstatic me/stupitdog/bhp/f0.llIIIIlIlllIIl : [I
    //   215: bipush #17
    //   217: iaload
    //   218: <illegal opcode> 74 : ()Lnet/minecraft/block/Block;
    //   223: aastore
    //   224: <illegal opcode> 75 : ([Ljava/lang/Object;)Ljava/util/List;
    //   229: putstatic me/stupitdog/bhp/f0.shulkerList : Ljava/util/List;
    //   232: return
  }
  
  private static CallSite lIIIIIIlIlIIlllI(MethodHandles.Lookup lllllllllllllllIllIllIIlIlIlIllI, String lllllllllllllllIllIllIIlIlIlIlIl, MethodType lllllllllllllllIllIllIIlIlIlIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIllIIlIlIlllII = llIIIIIIlIllII[Integer.parseInt(lllllllllllllllIllIllIIlIlIlIlIl)].split(llIIIIlIllIlll[llIIIIlIlllIIl[13]]);
      Class<?> lllllllllllllllIllIllIIlIlIllIll = Class.forName(lllllllllllllllIllIllIIlIlIlllII[llIIIIlIlllIIl[0]]);
      String lllllllllllllllIllIllIIlIlIllIlI = lllllllllllllllIllIllIIlIlIlllII[llIIIIlIlllIIl[1]];
      MethodHandle lllllllllllllllIllIllIIlIlIllIIl = null;
      int lllllllllllllllIllIllIIlIlIllIII = lllllllllllllllIllIllIIlIlIlllII[llIIIIlIlllIIl[5]].length();
      if (lIIIIIlIllIIIlII(lllllllllllllllIllIllIIlIlIllIII, llIIIIlIlllIIl[2])) {
        MethodType lllllllllllllllIllIllIIlIlIllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIlIlIlllII[llIIIIlIlllIIl[2]], f0.class.getClassLoader());
        if (lIIIIIlIlIlllllI(lllllllllllllllIllIllIIlIlIllIII, llIIIIlIlllIIl[2])) {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findVirtual(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIllllI);
          "".length();
          if (-" ".length() > -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findStatic(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIllllI);
        } 
        "".length();
        if ((((0x4C ^ 0x4B) << " ".length() << " ".length() ^ " ".length()) << " ".length() & ((81 + 156 - 72 + 22 ^ (0x0 ^ 0x53) << " ".length()) << " ".length() ^ -" ".length())) < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIllIIlIlIlllIl = llIIIIIIlIllIl[Integer.parseInt(lllllllllllllllIllIllIIlIlIlllII[llIIIIlIlllIIl[2]])];
        if (lIIIIIlIlIlllllI(lllllllllllllllIllIllIIlIlIllIII, llIIIIlIlllIIl[5])) {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findGetter(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIlllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIIlIlIlllllI(lllllllllllllllIllIllIIlIlIllIII, llIIIIlIlllIIl[6])) {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findStaticGetter(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIlllIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() < -" ".length())
            return null; 
        } else if (lIIIIIlIlIlllllI(lllllllllllllllIllIllIIlIlIllIII, llIIIIlIlllIIl[7])) {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findSetter(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIlllIl);
          "".length();
          if ("   ".length() <= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIllIIlIlIllIIl = lllllllllllllllIllIllIIlIlIlIllI.findStaticSetter(lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIlllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIllIIlIlIllIIl);
    } catch (Exception lllllllllllllllIllIllIIlIlIlIlll) {
      lllllllllllllllIllIllIIlIlIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlIllIIll() {
    llIIIIIIlIllII = new String[llIIIIlIlllIIl[18]];
    llIIIIIIlIllII[llIIIIlIlllIIl[19]] = llIIIIlIllIlll[llIIIIlIlllIIl[14]];
    llIIIIIIlIllII[llIIIIlIlllIIl[20]] = llIIIIlIllIlll[llIIIIlIlllIIl[15]];
    llIIIIIIlIllII[llIIIIlIlllIIl[21]] = llIIIIlIllIlll[llIIIIlIlllIIl[16]];
    llIIIIIIlIllII[llIIIIlIlllIIl[7]] = llIIIIlIllIlll[llIIIIlIlllIIl[17]];
    llIIIIIIlIllII[llIIIIlIlllIIl[1]] = llIIIIlIllIlll[llIIIIlIlllIIl[12]];
    llIIIIIIlIllII[llIIIIlIlllIIl[22]] = llIIIIlIllIlll[llIIIIlIlllIIl[22]];
    llIIIIIIlIllII[llIIIIlIlllIIl[23]] = llIIIIlIllIlll[llIIIIlIlllIIl[24]];
    llIIIIIIlIllII[llIIIIlIlllIIl[13]] = llIIIIlIllIlll[llIIIIlIlllIIl[25]];
    llIIIIIIlIllII[llIIIIlIlllIIl[26]] = llIIIIlIllIlll[llIIIIlIlllIIl[27]];
    llIIIIIIlIllII[llIIIIlIlllIIl[28]] = llIIIIlIllIlll[llIIIIlIlllIIl[29]];
    llIIIIIIlIllII[llIIIIlIlllIIl[27]] = llIIIIlIllIlll[llIIIIlIlllIIl[30]];
    llIIIIIIlIllII[llIIIIlIlllIIl[12]] = llIIIIlIllIlll[llIIIIlIlllIIl[31]];
    llIIIIIIlIllII[llIIIIlIlllIIl[10]] = llIIIIlIllIlll[llIIIIlIlllIIl[32]];
    llIIIIIIlIllII[llIIIIlIlllIIl[33]] = llIIIIlIllIlll[llIIIIlIlllIIl[34]];
    llIIIIIIlIllII[llIIIIlIlllIIl[35]] = llIIIIlIllIlll[llIIIIlIlllIIl[36]];
    llIIIIIIlIllII[llIIIIlIlllIIl[37]] = llIIIIlIllIlll[llIIIIlIlllIIl[38]];
    llIIIIIIlIllII[llIIIIlIlllIIl[39]] = llIIIIlIllIlll[llIIIIlIlllIIl[40]];
    llIIIIIIlIllII[llIIIIlIlllIIl[29]] = llIIIIlIllIlll[llIIIIlIlllIIl[41]];
    llIIIIIIlIllII[llIIIIlIlllIIl[42]] = llIIIIlIllIlll[llIIIIlIlllIIl[43]];
    llIIIIIIlIllII[llIIIIlIlllIIl[44]] = llIIIIlIllIlll[llIIIIlIlllIIl[23]];
    llIIIIIIlIllII[llIIIIlIlllIIl[45]] = llIIIIlIllIlll[llIIIIlIlllIIl[46]];
    llIIIIIIlIllII[llIIIIlIlllIIl[47]] = llIIIIlIllIlll[llIIIIlIlllIIl[26]];
    llIIIIIIlIllII[llIIIIlIlllIIl[48]] = llIIIIlIllIlll[llIIIIlIlllIIl[49]];
    llIIIIIIlIllII[llIIIIlIlllIIl[50]] = llIIIIlIllIlll[llIIIIlIlllIIl[51]];
    llIIIIIIlIllII[llIIIIlIlllIIl[9]] = llIIIIlIllIlll[llIIIIlIlllIIl[52]];
    llIIIIIIlIllII[llIIIIlIlllIIl[52]] = llIIIIlIllIlll[llIIIIlIlllIIl[53]];
    llIIIIIIlIllII[llIIIIlIlllIIl[54]] = llIIIIlIllIlll[llIIIIlIlllIIl[55]];
    llIIIIIIlIllII[llIIIIlIlllIIl[56]] = llIIIIlIllIlll[llIIIIlIlllIIl[35]];
    llIIIIIIlIllII[llIIIIlIlllIIl[57]] = llIIIIlIllIlll[llIIIIlIlllIIl[58]];
    llIIIIIIlIllII[llIIIIlIlllIIl[53]] = llIIIIlIllIlll[llIIIIlIlllIIl[59]];
    llIIIIIIlIllII[llIIIIlIlllIIl[58]] = llIIIIlIllIlll[llIIIIlIlllIIl[44]];
    llIIIIIIlIllII[llIIIIlIlllIIl[11]] = llIIIIlIllIlll[llIIIIlIlllIIl[45]];
    llIIIIIIlIllII[llIIIIlIlllIIl[60]] = llIIIIlIllIlll[llIIIIlIlllIIl[57]];
    llIIIIIIlIllII[llIIIIlIlllIIl[61]] = llIIIIlIllIlll[llIIIIlIlllIIl[37]];
    llIIIIIIlIllII[llIIIIlIlllIIl[62]] = llIIIIlIllIlll[llIIIIlIlllIIl[28]];
    llIIIIIIlIllII[llIIIIlIlllIIl[46]] = llIIIIlIllIlll[llIIIIlIlllIIl[20]];
    llIIIIIIlIllII[llIIIIlIlllIIl[63]] = llIIIIlIllIlll[llIIIIlIlllIIl[64]];
    llIIIIIIlIllII[llIIIIlIlllIIl[17]] = llIIIIlIllIlll[llIIIIlIlllIIl[54]];
    llIIIIIIlIllII[llIIIIlIlllIIl[34]] = llIIIIlIllIlll[llIIIIlIlllIIl[65]];
    llIIIIIIlIllII[llIIIIlIlllIIl[66]] = llIIIIlIllIlll[llIIIIlIlllIIl[67]];
    llIIIIIIlIllII[llIIIIlIlllIIl[8]] = llIIIIlIllIlll[llIIIIlIlllIIl[66]];
    llIIIIIIlIllII[llIIIIlIlllIIl[43]] = llIIIIlIllIlll[llIIIIlIlllIIl[21]];
    llIIIIIIlIllII[llIIIIlIlllIIl[65]] = llIIIIlIllIlll[llIIIIlIlllIIl[50]];
    llIIIIIIlIllII[llIIIIlIlllIIl[16]] = llIIIIlIllIlll[llIIIIlIlllIIl[33]];
    llIIIIIIlIllII[llIIIIlIlllIIl[68]] = llIIIIlIllIlll[llIIIIlIlllIIl[69]];
    llIIIIIIlIllII[llIIIIlIlllIIl[59]] = llIIIIlIllIlll[llIIIIlIlllIIl[48]];
    llIIIIIIlIllII[llIIIIlIlllIIl[51]] = llIIIIlIllIlll[llIIIIlIlllIIl[70]];
    llIIIIIIlIllII[llIIIIlIlllIIl[4]] = llIIIIlIllIlll[llIIIIlIlllIIl[19]];
    llIIIIIIlIllII[llIIIIlIlllIIl[64]] = llIIIIlIllIlll[llIIIIlIlllIIl[71]];
    llIIIIIIlIllII[llIIIIlIlllIIl[72]] = llIIIIlIllIlll[llIIIIlIlllIIl[39]];
    llIIIIIIlIllII[llIIIIlIlllIIl[73]] = llIIIIlIllIlll[llIIIIlIlllIIl[60]];
    llIIIIIIlIllII[llIIIIlIlllIIl[49]] = llIIIIlIllIlll[llIIIIlIlllIIl[63]];
    llIIIIIIlIllII[llIIIIlIlllIIl[67]] = llIIIIlIllIlll[llIIIIlIlllIIl[74]];
    llIIIIIIlIllII[llIIIIlIlllIIl[0]] = llIIIIlIllIlll[llIIIIlIlllIIl[72]];
    llIIIIIIlIllII[llIIIIlIlllIIl[71]] = llIIIIlIllIlll[llIIIIlIlllIIl[42]];
    llIIIIIIlIllII[llIIIIlIlllIIl[41]] = llIIIIlIllIlll[llIIIIlIlllIIl[56]];
    llIIIIIIlIllII[llIIIIlIlllIIl[31]] = llIIIIlIllIlll[llIIIIlIlllIIl[47]];
    llIIIIIIlIllII[llIIIIlIlllIIl[15]] = llIIIIlIllIlll[llIIIIlIlllIIl[62]];
    llIIIIIIlIllII[llIIIIlIlllIIl[75]] = llIIIIlIllIlll[llIIIIlIlllIIl[68]];
    llIIIIIIlIllII[llIIIIlIlllIIl[14]] = llIIIIlIllIlll[llIIIIlIlllIIl[75]];
    llIIIIIIlIllII[llIIIIlIlllIIl[36]] = llIIIIlIllIlll[llIIIIlIlllIIl[76]];
    llIIIIIIlIllII[llIIIIlIlllIIl[38]] = llIIIIlIllIlll[llIIIIlIlllIIl[73]];
    llIIIIIIlIllII[llIIIIlIlllIIl[76]] = llIIIIlIllIlll[llIIIIlIlllIIl[77]];
    llIIIIIIlIllII[llIIIIlIlllIIl[5]] = llIIIIlIllIlll[llIIIIlIlllIIl[61]];
    llIIIIIIlIllII[llIIIIlIlllIIl[70]] = llIIIIlIllIlll[llIIIIlIlllIIl[18]];
    llIIIIIIlIllII[llIIIIlIlllIIl[32]] = llIIIIlIllIlll[llIIIIlIlllIIl[78]];
    llIIIIIIlIllII[llIIIIlIlllIIl[69]] = llIIIIlIllIlll[llIIIIlIlllIIl[79]];
    llIIIIIIlIllII[llIIIIlIlllIIl[25]] = llIIIIlIllIlll[llIIIIlIlllIIl[80]];
    llIIIIIIlIllII[llIIIIlIlllIIl[30]] = llIIIIlIllIlll[llIIIIlIlllIIl[81]];
    llIIIIIIlIllII[llIIIIlIlllIIl[55]] = llIIIIlIllIlll[llIIIIlIlllIIl[82]];
    llIIIIIIlIllII[llIIIIlIlllIIl[2]] = llIIIIlIllIlll[llIIIIlIlllIIl[83]];
    llIIIIIIlIllII[llIIIIlIlllIIl[24]] = llIIIIlIllIlll[llIIIIlIlllIIl[84]];
    llIIIIIIlIllII[llIIIIlIlllIIl[40]] = llIIIIlIllIlll[llIIIIlIlllIIl[85]];
    llIIIIIIlIllII[llIIIIlIlllIIl[77]] = llIIIIlIllIlll[llIIIIlIlllIIl[86]];
    llIIIIIIlIllII[llIIIIlIlllIIl[6]] = llIIIIlIllIlll[llIIIIlIlllIIl[87]];
    llIIIIIIlIllII[llIIIIlIlllIIl[74]] = llIIIIlIllIlll[llIIIIlIlllIIl[88]];
    llIIIIIIlIllIl = new Class[llIIIIlIlllIIl[27]];
    llIIIIIIlIllIl[llIIIIlIlllIIl[25]] = Block.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[2]] = int.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[22]] = ItemStack.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[5]] = Listener.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[7]] = EntityPlayerSP.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[9]] = BlockChest.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[15]] = GuiScreen.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[16]] = GuiScreenHorseInventory.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[13]] = PlayerControllerMP.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[24]] = CPacketUseEntity.Action.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[4]] = WorldClient.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[10]] = PrintStream.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[6]] = Minecraft.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[17]] = IInventory.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[0]] = f13.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[11]] = List.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[12]] = Container.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[8]] = InventoryPlayer.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[1]] = ao.class;
    llIIIIIIlIllIl[llIIIIlIlllIIl[14]] = EnumHand.class;
  }
  
  private static void lIIIIIlIlIllIlll() {
    llIIIIlIllIlll = new String[llIIIIlIlllIIl[89]];
    llIIIIlIllIlll[llIIIIlIlllIIl[0]] = lIIIIIlIlIllIlII(llIIIIlIlllIII[llIIIIlIlllIIl[0]], llIIIIlIlllIII[llIIIIlIlllIIl[1]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[1]] = lIIIIIlIlIllIlIl(llIIIIlIlllIII[llIIIIlIlllIIl[2]], llIIIIlIlllIII[llIIIIlIlllIIl[5]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[2]] = lIIIIIlIlIllIlII(llIIIIlIlllIII[llIIIIlIlllIIl[6]], llIIIIlIlllIII[llIIIIlIlllIIl[7]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[5]] = lIIIIIlIlIllIlII(llIIIIlIlllIII[llIIIIlIlllIIl[8]], llIIIIlIlllIII[llIIIIlIlllIIl[9]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[6]] = lIIIIIlIlIllIlIl(llIIIIlIlllIII[llIIIIlIlllIIl[10]], llIIIIlIlllIII[llIIIIlIlllIIl[4]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[7]] = lIIIIIlIlIllIllI(llIIIIlIlllIII[llIIIIlIlllIIl[11]], llIIIIlIlllIII[llIIIIlIlllIIl[13]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[8]] = lIIIIIlIlIllIllI(llIIIIlIlllIII[llIIIIlIlllIIl[14]], llIIIIlIlllIII[llIIIIlIlllIIl[15]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[9]] = lIIIIIlIlIllIlIl(llIIIIlIlllIII[llIIIIlIlllIIl[16]], llIIIIlIlllIII[llIIIIlIlllIIl[17]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[10]] = lIIIIIlIlIllIlIl(llIIIIlIlllIII[llIIIIlIlllIIl[12]], llIIIIlIlllIII[llIIIIlIlllIIl[22]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[4]] = lIIIIIlIlIllIlIl(llIIIIlIlllIII[llIIIIlIlllIIl[24]], llIIIIlIlllIII[llIIIIlIlllIIl[25]]);
    llIIIIlIllIlll[llIIIIlIlllIIl[11]] = lIIIIIlIlIllIlII("ka7Ms71eX5E7CRehMNGoblSK4a1jppy2y5fWwoW0aMmysB5EuEDkhGctuA/2j5Cp", "SBzzJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[13]] = lIIIIIlIlIllIlIl("bw==", "UnLOm");
    llIIIIlIllIlll[llIIIIlIlllIIl[14]] = lIIIIIlIlIllIlII("zo5YUgc7IKNFsQ4j0HBR4/VlsQJcyxKM58H75VmCJQ3IAKJgCl3yF5LHDYZdlA9qDTV8GXy5GyY=", "EwMmt");
    llIIIIlIllIlll[llIIIIlIlllIIl[15]] = lIIIIIlIlIllIlIl("EDcYOUwWNwA/TCkiHDEMHRQbMQ4eMxxiAwomCzYGQH4iMgMMN0E0AxQxQQsWCD8AP1lTGgQ5FBt5AjkMHXk9LBATOAkaFxM6Cj0QQWxOeA==", "zVnXb");
    llIIIIlIllIlll[llIIIIlIlllIIl[16]] = lIIIIIlIlIllIllI("/heJjd8bSTYyaJX9ai5sOtbJIfDuqWoeaMwj2jSiikNLOhJO2pT6DwaSklpzclUlI3B696ygJKlkWkDzwhTuA7tdJlEhEUZKbBY4uLKNwnrYuSoz6k7zmT6V0LlGkXZoiNOvXit4WBV1AkOSQvI/SyEIXmk+k6DiaOdbZ4Snk1N0eJkGLUDDog==", "yqIaJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[17]] = lIIIIIlIlIllIlIl("GwZ5GSQDEz4eNBkEeQg4Bk0xWmoVCzIZJExRbUpwVkN3", "vcWjP");
    llIIIIlIllIlll[llIIIIlIlllIIl[12]] = lIIIIIlIlIllIllI("9zCbtX/gE+WrGFzhBWeUUM8y6YNxV3oYFo0299FUTQ0qBy2WBTM56Q==", "WWqrD");
    llIIIIlIllIlll[llIIIIlIlllIIl[22]] = lIIIIIlIlIllIllI("N8Kotl3KraQzbtO98yRmJiMIQcau1s5LKGXdb/F+ZEt5ed7TdrdSK2OVlFbDf+To6vN9eoEPmp8wTEp1RTrIFg==", "VqAmh");
    llIIIIlIllIlll[llIIIIlIlllIIl[24]] = lIIIIIlIlIllIlIl("ARIzSykGGSIGNg4RM0shAQMuET1BByYWNwYBIksFDQQzFyUMAwQNIRwDDwo2HBJ9AzEBFBhUfV9BflAbCx99TW01TWdF", "owGeD");
    llIIIIlIllIlll[llIIIIlIlllIIl[25]] = lIIIIIlIlIllIlII("LzPpmQw5Hxjn5COlQYFN2wpePOKZKAL1k7IhQHlZM4D23IcFFwfLqjYH1wybFNkxX3FNWu37NLFl/8QRy3xHAxTetUt/3FSxfFKf5hQazm8=", "WluFT");
    llIIIIlIllIlll[llIIIIlIlllIIl[27]] = lIIIIIlIlIllIlII("RAOvWH7hkfFzic75CTtA1YNWuGStNa+/y/1eXyOzf+6V101xaG9mjDD1UyHU89b5", "pwXbz");
    llIIIIlIllIlll[llIIIIlIlllIIl[29]] = lIIIIIlIlIllIllI("v6MVlSVrqqe/VO8bs8sat7IIgPXqshEdYCXzND2JuxAyCt/hDtS6jw==", "hJgtb");
    llIIIIlIllIlll[llIIIIlIlllIIl[30]] = lIIIIIlIlIllIlIl("GTNJFQ0BJg4SHRsxSQQRBHgBVkMAPwoDC05nXUZZVA==", "tVgfy");
    llIIIIlIllIlll[llIIIIlIlllIIl[31]] = lIIIIIlIlIllIllI("Ioyp1O01rKSxSZBWbTSucHmXDqAM7T60OS0dBpom7wBXeZyxzip1Pg==", "PCHYl");
    llIIIIlIllIlll[llIIIIlIlllIIl[32]] = lIIIIIlIlIllIlIl("PA8kYD47BDUtITMMJGAwPgM1ICd8JzkgNjEYMSgnaAw5Kz82NWd/Z2FTDylpZ1BwbnM=", "RjPNS");
    llIIIIlIllIlll[llIIIIlIlllIIl[34]] = lIIIIIlIlIllIlII("+P24HigJf7zgJUwwvidrogV/GV1k/60h6z0cWKwIVGO65zIe1RH7XQ==", "UiYSy");
    llIIIIlIllIlll[llIIIIlIlllIIl[36]] = lIIIIIlIlIllIlII("77aoSvz+Y6Qcn19rck0wJsYAMFpeBgPmyFBeKsm610X5R9P+7xvNuOrvFohJOIqyVRjcVEEey9E=", "LzvYB");
    llIIIIlIllIlll[llIIIIlIlllIIl[38]] = lIIIIIlIlIllIlII("+3NcfW1KAaL/c58oWmodQc9WSk0VjhogS5iS2ZD6UnQ1FXP2n9Ji8WypUhJ1JcnofyxcvAGqNPM=", "lOIZw");
    llIIIIlIllIlll[llIIIIlIlllIIl[40]] = lIIIIIlIlIllIlII("FGCatF1D58bzKX5aFCEme8OWSDP0xaMLjKzojyk40hZCtCTvazxQpJL62Ga7JlHevoO3C4IuxIA=", "xMBoQ");
    llIIIIlIllIlll[llIIIIlIlllIIl[41]] = lIIIIIlIlIllIlIl("PQhAGjYlHQcdJj8KQAsqIEMPBng4DB07JzEOBgwmakUkQBhqTU4=", "PmniB");
    llIIIIlIllIlll[llIIIIlIlllIIl[43]] = lIIIIIlIlIllIlIl("JQ4ReQoiBQA0FSoNEXkOJQIReSUnBAY8FHENDDILLzRUbldyU1EIAzhRVG5da0tFdw==", "KkeWg");
    llIIIIlIllIlll[llIIIIlIlllIIl[23]] = lIIIIIlIlIllIlII("tc9TC9rRRkoui8CmEgIpdtHJXfb1qNOabgJih2bFX+Q=", "jnwcV");
    llIIIIlIllIlll[llIIIIlIlllIIl[46]] = lIIIIIlIlIllIllI("6CdXN0ezvb4fWAWDmu2CVvEsTlC3Abo9Eq7mhOuqCULAAsmU7cgJgQbDaye04za9ZpJFXwal0RE=", "eMvpC");
    llIIIIlIllIlll[llIIIIlIlllIIl[26]] = lIIIIIlIlIllIlIl("DyEjZicIKjIrOAAiI2YjDy0jZggNKzQjOVsiPi0mBRtmcXpYfGEXLhR+ZnFwQWR3aA==", "aDWHJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[49]] = lIIIIIlIlIllIllI("i/5zIL+8Ghf5lamAscxVC83AvpizwkcoLSgRAcYcraFvynTbIXGG29zWJaWQCjWY", "vZwcD");
    llIIIIlIllIlll[llIIIIlIlllIIl[51]] = lIIIIIlIlIllIlII("+tAV1yUYq7cdtbSccxyb10P82F7JeqGyI+uOot8PLRxy6rTmAH0nbs1DeBqiJO8/8ySaQEfiiXyr8zNDfTTyre8uGHOF8/symwltCDI6+mg=", "TSAnh");
    llIIIIlIllIlll[llIIIIlIlllIIl[52]] = lIIIIIlIlIllIlII("mlsSRT6oE2BLBSRZPMLw8i3rC6D0I1fiSxBngzbUcu4=", "uYuoO");
    llIIIIlIllIlll[llIIIIlIlllIIl[53]] = lIIIIIlIlIllIllI("P13Tck5AaZThPNMK8iWRoNQtfr/tfDcHtF1BFIoyGsMnGmDa5VswyBjlFvFyKvS3JjKNuptIdm4=", "aSseK");
    llIIIIlIllIlll[llIIIIlIlllIIl[55]] = lIIIIIlIlIllIllI("FkFPpRBt07zWjQtSf/tmnHbG8qB/pucjUglxIyw66YdbKK1BCMmExPYG+ho0orTm1bq+a6hRR+reNc7h+6HU7Q==", "bcykJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[35]] = lIIIIIlIlIllIlII("HLf/2Dxe6FfL7vQOyW+SGka2+qVzoxwsWcLUKyAWSgSVkc3Z0m+NhzgWetanAS1GTfGNOgsHms8=", "fNySG");
    llIIIIlIllIlll[llIIIIlIlllIIl[58]] = lIIIIIlIlIllIlII("Fc7uSKSStH3pPGRwGzpuwGFPRwe+6t1z6kii3gL1h1Lvb/pzKXbh5w==", "cIlSD");
    llIIIIlIllIlll[llIIIIlIlllIIl[59]] = lIIIIIlIlIllIllI("XWVEyBqduO0kZlsnjJJnEO1XG+T3tVNZCn4FqH/BqQ8T3ndtlGgCgA==", "wqvFw");
    llIIIIlIllIlll[llIIIIlIlllIIl[44]] = lIIIIIlIlIllIllI("b6C3/LSxCUqFI9toWHhjvapiK3xe0Ab5xbophDyjuHiTCmuKXCgnP/WXL36u7H8i/1p7nutHtF4I7TscSgZj5eFUufVpLZqV", "cXnGN");
    llIIIIlIllIlll[llIIIIlIlllIIl[45]] = lIIIIIlIlIllIllI("CCjyg+eqBT4k5jyTjvVfCbWtAM7UhApSewp+rA7MlCoKuUZ6B6kbi0PhGmnJ0wGEX+dJb8lFw3NKlgleYg5SO8CU4gBKOWT4NBlMA2H+enhownTnhjTBHahC247frPdz", "OqLVm");
    llIIIIlIllIlll[llIIIIlIlllIIl[57]] = lIIIIIlIlIllIllI("hi3mDtUH39uSMQLqaJ6No16Pk1Zh0R23o5gVSfYnju0KfxfWVXtrVuz4mY9ZNW2339HHlw+jUHA=", "SsoCO");
    llIIIIlIllIlll[llIIIIlIlllIIl[37]] = lIIIIIlIlIllIlII("TXkTEkvE66TnvweWEwSEqBnA92rf2gKB+8yxKtiYDZatyNJOqGFAmpw3ZDc7mbMGDn+5hCYbLlGk5W+hYuQZCg==", "dFnVp");
    llIIIIlIllIlll[llIIIIlIlllIIl[28]] = lIIIIIlIlIllIlIl("PQgNVAw6AxwZEzILDVQIPQQNVCM/AhoREmkLEB8NNzJIQ1FqVU4lBSVXSENbc01ZWg==", "Smyza");
    llIIIIlIllIlll[llIIIIlIlllIIl[20]] = lIIIIIlIlIllIlII("4en8hmlPSD+4+JiPLzBh2GBrsoygBOM90UNd0GWcf9smTImG8lOmzuLG5WHlDmmD6MhWmRWWD14=", "nlbTw");
    llIIIIlIllIlll[llIIIIlIlllIIl[64]] = lIIIIIlIlIllIlIl("GCw2fjQfJyczKxcvNn4wGCA2fhsaJiE7KkwvKzU1EhZzaWlPcXMPPQZzc2ljVmlicA==", "vIBPY");
    llIIIIlIllIlll[llIIIIlIlllIIl[54]] = lIIIIIlIlIllIllI("oKaRn4HtQ4uG2En9+aUJvfCwSoO0rL4gL0+hsM0adtAeWI2p+xtEaQ==", "SLhsN");
    llIIIIlIllIlll[llIIIIlIlllIIl[65]] = lIIIIIlIlIllIllI("s9bHXeFRRDcA83GglUcLD6ua8ZUjEqhaBzNP1qK6ILDGq2rE/0zLIFh8odfOAQoqdaeRmMoAu9OF2qVJJ3R4k6uo1HdkyD9FNH+PPbwUA38m+xKRYmU+MabLOEU1hoyV", "pGbMm");
    llIIIIlIllIlll[llIIIIlIlllIIl[67]] = lIIIIIlIlIllIlII("v4tg65DkMfRoaMnBi/Csma71H+5ELyjBAvhID5/H3dhNM7bS8zIdPBmsSYVERBz/AVepvxhAe2XcmnBoBB0IEhgIvAehwrROhoL4m8nAS7WC/FySJqKj3a6WHvSoCK5pIyq5A604vGLeuE83647ZaEB8Wv3r4spbHHiwrowZp5g=", "OuUcr");
    llIIIIlIllIlll[llIIIIlIlllIIl[66]] = lIIIIIlIlIllIlII("ghJse7hM8qVFOg97UuJB3UwSREym/9HeaK5Zyckvd13NA1jG0APguw==", "cyemx");
    llIIIIlIllIlll[llIIIIlIlllIIl[21]] = lIIIIIlIlIllIllI("Q/AdxiF8V/5L0mYAaLX/LvzDMgLVGotjTL05Woh3lpA=", "EWczJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[50]] = lIIIIIlIlIllIlIl("LjNpEQ02Ji4WHSwxaQARM3gmDUMxMzQHDXl+bjRDY3Y=", "CVGby");
    llIIIIlIllIlll[llIIIIlIlllIIl[33]] = lIIIIIlIlIllIllI("8d+zCd1il0XknkzoUYVbVAkDY0Oi/2ETfY6T1gpAlc0=", "guhby");
    llIIIIlIllIlll[llIIIIlIlllIIl[69]] = lIIIIIlIlIllIlII("sJyx0ITcMjZd7PC1ApyfzpzWyrHkzuY4nPLUoVqLAm9mI3IBR5J/5845c3Ii2US+59ECS/cAj7w=", "FneFW");
    llIIIIlIllIlll[llIIIIlIlllIIl[48]] = lIIIIIlIlIllIlII("E54zUGI+GUDAQWHsdthQ2lvFaJVK6el5mgiYplZ07vyGKPJ39GdvS0rl/wNA7KcVmdojIiBOXVg=", "BvVKt");
    llIIIIlIllIlll[llIIIIlIlllIIl[70]] = lIIIIIlIlIllIlII("Mido0QVJ8BDZw+whX8kpEm33ohJliya9JzwK4eux5kXblA02rkTMoB8LBv1GucNZZH9F1zS+Vpz2Bw3toIh0qg==", "BKNlP");
    llIIIIlIllIlll[llIIIIlIlllIIl[19]] = lIIIIIlIlIllIllI("LOm9TwD8/EJII+dyhtEcFWi/VsAO3TprsFyCi3jTBpmFONoHR0cLUurKu2O/XYj2O1BklCOQtsu3v+4VZ88jdA==", "BBsKJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[71]] = lIIIIIlIlIllIllI("mb2bXyWYx1BRbzvcUV6z5V6yYTR11aciCA+XvvdtCHSqQOMa+L3TAFLVOHqSd7hnbko7pot9TAq/UYsgnhcgQg==", "AKyiU");
    llIIIIlIllIlll[llIIIIlIlllIIl[39]] = lIIIIIlIlIllIlII("4o+H94h4srB0rafE+7vbHojF/Qm7Kdw0EvkURcUagS3VD0UNFork9zlSbKhqk39F/4JXYok8BVA=", "PLZsp");
    llIIIIlIllIlll[llIIIIlIlllIIl[60]] = lIIIIIlIlIllIllI("NeVAg+UQJ/9F4r23TAYSRIxQmmcFAjUb5jy/Mzabr0V9i6EWyZjB6V0iiz9yjyzghIZoqINuA34=", "CwtqU");
    llIIIIlIllIlll[llIIIIlIlllIIl[63]] = lIIIIIlIlIllIllI("zxhN/TqMscLY/b79qlewH4q1Vt+mEIljOj4yKNt/E9V9+OY8yK96dqq549F3eGTmhf4zkViJnJQnZ+K8SecebARY5o1FWFVUhLaLFikOz4Sfwfif6OPZox7ngFdzbW/lRD60Tr7e6QxdsXMphaV/Nay7fgkKKSkJJBesJUubgcFEyjVy043+5OlTFMkLXSwWHsju3HbBrH6YQY7+fklcSfWVxZYAVf4yzVfPhMPgxl0G1TsLmp9dlMXRlUGpSOwsw+VarTdSY8sQTjg5vGiLKE8gHeZ4d4st", "xWjHy");
    llIIIIlIllIlll[llIIIIlIlllIIl[74]] = lIIIIIlIlIllIlII("9ugVbwn1vz+4gIpbNtz2Rgc++vUMYfb9X2Md+kTCHsVBSWAcx5/pz1HAPwJgJrcdR8dc4ag+qsK9vIdLN5aqSNnP16YFmqZ7", "Scjvp");
    llIIIIlIllIlll[llIIIIlIlllIIl[72]] = lIIIIIlIlIllIlII("sS/HH8TWzxxsurcuGudAKWBEhQnUrperWPfmhqKcLoeQjFeLeGmdsw==", "eRbyX");
    llIIIIlIllIlll[llIIIIlIlllIIl[42]] = lIIIIIlIlIllIlIl("LyItZSwoKTwoMyAhLWUoLy4tZQMtKDogMnshMC4tJRhocnF4cGEUJSx9aHJ7YWd5aw==", "AGYKA");
    llIIIIlIllIlll[llIIIIlIlllIIl[56]] = lIIIIIlIlIllIllI("UBK1xnCpwzVZGbNjDspZoaWWo9Nnqsp5uyY/RefmeUpP7/NJKUd5+9TUIOimo5U5D2jrq1r1W1FtD33516XxkIM2rZIR6ROM", "kXSoM");
    llIIIIlIllIlll[llIIIIlIlllIIl[47]] = lIIIIIlIlIllIlIl("DC8TYzQLJAIuKwMsE2M6DiMCIy1MJxIhLQs6CywgBzhJGjYQJgMONQsvCTljBCMCIT09fVV0YFQVAXdoUnBHbXk=", "bJgMY");
    llIIIIlIllIlll[llIIIIlIlllIIl[62]] = lIIIIIlIlIllIlIl("JQoTdyUiAQI6OioJE3chJQYTdwonAAQyO3EJDjwkLzBWbHh/V1EGKS5VUGNoa09H", "KogYH");
    llIIIIlIllIlll[llIIIIlIlllIIl[68]] = lIIIIIlIlIllIlII("mYsyKk3TV3L45UONgfKcOyLRzwuq2U2SyqR9rtwewp47n4awRSMpm55xBlbHFnbTNMhk9iifTpM=", "guKlM");
    llIIIIlIllIlll[llIIIIlIlllIIl[75]] = lIIIIIlIlIllIlII("c5iSbt1X2zSHEY3Sa6a9gQRzVmzIby2BELM4Q9hLqcAc+tmLvb/zOB76Q/EDifWFBSXP7R8HherAaTqnqcjEokylmonVdaeNOz1lm98P+Zo=", "IXKAJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[76]] = lIIIIIlIlIllIlII("LkcdCXAybjxc9uCUTYWYaM9kohi+vxR/zgtssECib5iUGralQv6qtqMXVLSHrJyWCpvShlz0E5soPDp0CMpZyddP4Zdpk3Z3C7dR/THaMrjMxevgnrCOlw==", "klGXg");
    llIIIIlIllIlll[llIIIIlIlllIIl[73]] = lIIIIIlIlIllIlII("56LW0L0qQ1nu38P9hKFQmCkgpoX9jOuB5HpQrhNr52zvhJkfVVenzUcCREX022ynxdjX8hIF/w+zRNlPT6h/nmDJQEIGRQWsTXVIpAJRSwzV+idQjdjOIQ==", "uIrwF");
    llIIIIlIllIlll[llIIIIlIlllIIl[77]] = lIIIIIlIlIllIlII("Zpo8cwRKWGiXELrcym3JYzEfTDEIFzoMkV78C8IRqAYchD9fGq2XBAvarOjjc/hLMes0bECMIiM=", "OEFto");
    llIIIIlIllIlll[llIIIIlIlllIIl[61]] = lIIIIIlIlIllIlIl("OxxHFzYjCQAQJjkeRwYqJlcPVHg5FzkFIT0cHSE0MxcdNyc4HVNXeHZZSURi", "VyidB");
    llIIIIlIllIlll[llIIIIlIlllIIl[18]] = lIIIIIlIlIllIllI("2LjzjE10S0s01cgZ/bifO/cKeRYAQT+B43rpcdJU8m3caGeWd6Ut1ZPOzdDzhTqakXWDTPQjhxsL/M4kCmkUO5P2SMHC9lY3eSeCZ1IjWyyTd8GIhj8GvsG2kegsGMUV", "fEkYp");
    llIIIIlIllIlll[llIIIIlIlllIIl[78]] = lIIIIIlIlIllIlIl("CDkvKF0XLDAlXS4xKj1JESwrLBIPYnFgPwg5LyhcFywwJVwRLCssEg93Cj0BBzk0cklCeA==", "bXYIs");
    llIIIIlIllIlll[llIIIIlIlllIIl[79]] = lIIIIIlIlIllIlIl("DAMseTkLCD00JgMALHk3Dg89OSBMAzYjPRYfdhI6Fg8sLgQOByEyJjE2YjEhDAUHYGRSVWoIMFhOFDkxFkk1PjoHBSo2MhZJPTkgCxIheBEMEjEjLVlPHm10Qg==", "bfXWT");
    llIIIIlIllIlll[llIIIIlIlllIIl[80]] = lIIIIIlIlIllIlIl("ABwtXjsYBC0ceQYAOgUjQSUvCTUADzgUbQYdARUuKwE9Hm1HJ2MqbU8=", "onJpW");
    llIIIIlIllIlll[llIIIIlIlllIIl[81]] = lIIIIIlIlIllIllI("5HV67dwcV2SUcuWqKJ5brux+7v/bcac8WI2znt8iVE4cZbhldnVwY9WZYKlXHf5NfWP7KrYc9V0=", "vAQEh");
    llIIIIlIllIlll[llIIIIlIlllIIl[82]] = lIIIIIlIlIllIlII("04T3YnH7E+wWUQ/R8vi3HqGZYhXPXcGjIxWaml7YqkPlGJd8JjnWQal2rielXVte/Yi0DsPWp3eWAe03NnfZHeUKubJc5J1dzi+pVi3H6xsPZRltaft0bg==", "yjseg");
    llIIIIlIllIlll[llIIIIlIlllIIl[83]] = lIIIIIlIlIllIlIl("DClJJCAUPA4jMA4rSTU8EWIBZ24CJAIkIDIgCCNuU3ZHd3RBbA==", "aLgWT");
    llIIIIlIllIlll[llIIIIlIlllIIl[84]] = lIIIIIlIlIllIlIl("CQlBKRERHAYuAQsLQTgNFEIJal8QAwg9CQFWR3MzXkxP", "dloZe");
    llIIIIlIllIlll[llIIIIlIlllIIl[85]] = lIIIIIlIlIllIlIl("GA4XCnkHGwgHeQEbEw42H0EyHyUXDgxROhsBW0MbGA4XCngHGwgHeDEADBs2AA4VBCVJRi0BNgQOTh4jGwNOJCcGBg4FNh5UW0t3", "roakW");
    llIIIIlIllIlll[llIIIIlIlllIIl[86]] = lIIIIIlIlIllIllI("n8DXVIjEOQ7aHNBNuLcKK8AA5dWN9lxkAmXIgBRWp9UzYusqrSU+IZly6jcDiahLAELw8oXxomU=", "pKaaM");
    llIIIIlIllIlll[llIIIIlIlllIIl[87]] = lIIIIIlIlIllIlII("CpxPDB2EhnUfsadF9OecxZ90Oz0jHqx0hQBPNqAg2DDBY9WHZg9ldw==", "MSQrJ");
    llIIIIlIllIlll[llIIIIlIlllIIl[88]] = lIIIIIlIlIllIllI("uJ01K0NZrkmH50ObA+aisZ97VAnoPsKDTzNWwFRrOAGPZXOWCbeHmyorHNJkpSKrn5JqiSnYrdY=", "egiIo");
    llIIIIlIlllIII = null;
  }
  
  private static void lIIIIIlIlIlllIII() {
    String str = (new Exception()).getStackTrace()[llIIIIlIlllIIl[0]].getFileName();
    llIIIIlIlllIII = str.substring(str.indexOf("ä") + llIIIIlIlllIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlIlIllIllI(String lllllllllllllllIllIllIIlIlIlIIII, String lllllllllllllllIllIllIIlIlIIllll) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIlIlIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIlIlIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIIlIlIlIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIIlIlIlIIlI.init(llIIIIlIlllIIl[2], lllllllllllllllIllIllIIlIlIlIIll);
      return new String(lllllllllllllllIllIllIIlIlIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIlIlIlIIIl) {
      lllllllllllllllIllIllIIlIlIlIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlIlIllIlIl(String lllllllllllllllIllIllIIlIlIIllIl, String lllllllllllllllIllIllIIlIlIIllII) {
    lllllllllllllllIllIllIIlIlIIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlIIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIIlIlIIlIll = new StringBuilder();
    char[] lllllllllllllllIllIllIIlIlIIlIlI = lllllllllllllllIllIllIIlIlIIllII.toCharArray();
    int lllllllllllllllIllIllIIlIlIIlIIl = llIIIIlIlllIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIllIIlIlIIllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIlIlllIIl[0];
    while (lIIIIIlIlIlllIll(j, i)) {
      char lllllllllllllllIllIllIIlIlIIlllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIIlIlIIlIIl++;
      j++;
      "".length();
      if (-" ".length() == " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIIlIlIIlIll);
  }
  
  private static String lIIIIIlIlIllIlII(String lllllllllllllllIllIllIIlIlIIIlIl, String lllllllllllllllIllIllIIlIlIIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllIllIIlIlIIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIlIlIIIlII.getBytes(StandardCharsets.UTF_8)), llIIIIlIlllIIl[10]), "DES");
      Cipher lllllllllllllllIllIllIIlIlIIIlll = Cipher.getInstance("DES");
      lllllllllllllllIllIllIIlIlIIIlll.init(llIIIIlIlllIIl[2], lllllllllllllllIllIllIIlIlIIlIII);
      return new String(lllllllllllllllIllIllIIlIlIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIlIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIIlIlIIIllI) {
      lllllllllllllllIllIllIIlIlIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlIlIlllIlI() {
    llIIIIlIlllIIl = new int[90];
    llIIIIlIlllIIl[0] = " ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ 0xFFFFFFFF);
    llIIIIlIlllIIl[1] = " ".length();
    llIIIIlIlllIIl[2] = " ".length() << " ".length();
    llIIIIlIlllIIl[3] = -" ".length();
    llIIIIlIlllIIl[4] = 0x44 ^ 0x43 ^ (0x2 ^ 0x5) << " ".length();
    llIIIIlIlllIIl[5] = "   ".length();
    llIIIIlIlllIIl[6] = " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[7] = (0xC7 ^ 0xC0) << " ".length() ^ 0x27 ^ 0x2C;
    llIIIIlIlllIIl[8] = "   ".length() << " ".length();
    llIIIIlIlllIIl[9] = 0x8D ^ 0x8A;
    llIIIIlIlllIIl[10] = " ".length() << "   ".length();
    llIIIIlIlllIIl[11] = ((0x30 ^ 0x77) << " ".length() ^ 43 + 37 - 41 + 100) << " ".length();
    llIIIIlIlllIIl[12] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[13] = (0xC8 ^ 0x8B) << " ".length() ^ 20 + 115 - -5 + 1;
    llIIIIlIlllIIl[14] = "   ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[15] = 0x0 ^ 0x63 ^ (0x16 ^ 0x21) << " ".length();
    llIIIIlIlllIIl[16] = (0x69 ^ 0x6E) << " ".length();
    llIIIIlIlllIIl[17] = 45 + 92 - -9 + 27 ^ (0x24 ^ 0x75) << " ".length();
    llIIIIlIlllIIl[18] = (0x2D ^ 0x3E) << " ".length() << " ".length();
    llIIIIlIlllIIl[19] = (0xAE ^ 0x91) << " ".length() ^ 0xCC ^ 0x89;
    llIIIIlIlllIIl[20] = 0xB7 ^ 0x98;
    llIIIIlIlllIIl[21] = 0x71 ^ 0x44;
    llIIIIlIlllIIl[22] = 0x72 ^ 0x63;
    llIIIIlIlllIIl[23] = (0xB7 ^ 0x9A) << " ".length() << " ".length() ^ 6 + 43 - -78 + 44;
    llIIIIlIlllIIl[24] = ((0xE ^ 0x33) << " ".length() ^ 0xE ^ 0x7D) << " ".length();
    llIIIIlIlllIIl[25] = 0x5A ^ 0x33 ^ (0x77 ^ 0x4A) << " ".length();
    llIIIIlIlllIIl[26] = 0x8 ^ 0x5B ^ (0x15 ^ 0x2C) << " ".length();
    llIIIIlIlllIIl[27] = (0xA3 ^ 0xA6) << " ".length() << " ".length();
    llIIIIlIlllIIl[28] = ((0x34 ^ 0x19) << " ".length() ^ 0xD6 ^ 0x9B) << " ".length();
    llIIIIlIlllIIl[29] = (0x8A ^ 0xC3) << " ".length() ^ 0 + 77 - 32 + 90;
    llIIIIlIlllIIl[30] = ((0x99 ^ 0x84) << " ".length() << " ".length() ^ 2 + 57 - -59 + 9) << " ".length();
    llIIIIlIlllIIl[31] = (0x39 ^ 0x20) << " ".length() << " ".length() ^ 0xCE ^ 0xBD;
    llIIIIlIlllIIl[32] = "   ".length() << "   ".length();
    llIIIIlIlllIIl[33] = (0x26 ^ 0x67) << " ".length() ^ 89 + 121 - 192 + 163;
    llIIIIlIlllIIl[34] = 0x67 ^ 0x5E ^ " ".length() << (0x98 ^ 0x9D);
    llIIIIlIlllIIl[35] = 0x70 ^ 0x57;
    llIIIIlIlllIIl[36] = ((0xA1 ^ 0xAA) << "   ".length() ^ 0xEB ^ 0xBE) << " ".length();
    llIIIIlIlllIIl[37] = 0x8A ^ 0xA7;
    llIIIIlIlllIIl[38] = 0xAE ^ 0xBF ^ (0x81 ^ 0x84) << " ".length();
    llIIIIlIlllIIl[39] = (0x70 ^ 0x61) << "   ".length() ^ 125 + 26 - 92 + 122;
    llIIIIlIlllIIl[40] = ((0xD9 ^ 0xC2) << " ".length() << " ".length() ^ 0x71 ^ 0x1A) << " ".length() << " ".length();
    llIIIIlIlllIIl[41] = (0x50 ^ 0x1B) << " ".length() ^ 1 + 117 - 74 + 95;
    llIIIIlIlllIIl[42] = ((0x94 ^ 0x9D) << "   ".length() ^ 0xF9 ^ 0x90) << " ".length();
    llIIIIlIlllIIl[43] = (0x5B ^ 0x54) << " ".length();
    llIIIIlIlllIIl[44] = (0x91 ^ 0x84) << " ".length();
    llIIIIlIlllIIl[45] = (0x46 ^ 0x6D) << " ".length() ^ 0x11 ^ 0x6C;
    llIIIIlIlllIIl[46] = " ".length() << (" ".length() << " ".length() << " ".length() << " ".length() ^ 0xAA ^ 0xBF);
    llIIIIlIlllIIl[47] = (0x9 ^ 0x18) << " ".length() << " ".length();
    llIIIIlIlllIIl[48] = 0x71 ^ 0x48;
    llIIIIlIlllIIl[49] = (0x5C ^ 0x4D) << " ".length();
    llIIIIlIlllIIl[50] = ("   ".length() ^ "   ".length() << "   ".length()) << " ".length();
    llIIIIlIlllIIl[51] = 0xA6 ^ 0x85;
    llIIIIlIlllIIl[52] = (0x70 ^ 0x79) << " ".length() << " ".length();
    llIIIIlIlllIIl[53] = 0x57 ^ 0x72;
    llIIIIlIlllIIl[54] = 64 + 29 - 31 + 125 ^ (0xD8 ^ 0x9D) << " ".length();
    llIIIIlIlllIIl[55] = ((0xA7 ^ 0x8C) << " ".length() ^ 0xC7 ^ 0x82) << " ".length();
    llIIIIlIlllIIl[56] = 0xE0 ^ 0x89 ^ (0x88 ^ 0x9D) << " ".length();
    llIIIIlIlllIIl[57] = (0x96 ^ 0xBF ^ (0x52 ^ 0x43) << " ".length()) << " ".length() << " ".length();
    llIIIIlIlllIIl[58] = (0x93 ^ 0x96) << "   ".length();
    llIIIIlIlllIIl[59] = 76 + 89 - 107 + 113 ^ (0x4F ^ 0xE) << " ".length();
    llIIIIlIlllIIl[60] = (0x1C ^ 0x3F ^ (0x58 ^ 0x57) << " ".length() << " ".length()) << " ".length();
    llIIIIlIlllIIl[61] = 0xB ^ 0x70 ^ "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[62] = 0x53 ^ 0x12 ^ " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[63] = (0x83 ^ 0x9C) << " ".length() << " ".length() ^ 0xC3 ^ 0x80;
    llIIIIlIlllIIl[64] = "   ".length() << " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[65] = ((0xFA ^ 0xB3) << " ".length() ^ 17 + 125 - 46 + 43) << " ".length();
    llIIIIlIlllIIl[66] = (" ".length() << " ".length() << " ".length() << " ".length() ^ 0x60 ^ 0x7D) << " ".length() << " ".length();
    llIIIIlIlllIIl[67] = 0x7A ^ 0x49;
    llIIIIlIlllIIl[68] = (0xB0 ^ 0x93) << " ".length();
    llIIIIlIlllIIl[69] = (0xCF ^ 0xAC ^ (0x6A ^ 0x73) << " ".length() << " ".length()) << "   ".length();
    llIIIIlIlllIIl[70] = (0xAC ^ 0xB1) << " ".length();
    llIIIIlIlllIIl[71] = (0x29 ^ 0x26) << " ".length() << " ".length();
    llIIIIlIlllIIl[72] = 0x97 ^ 0xA4 ^ (0xAE ^ 0x97) << " ".length();
    llIIIIlIlllIIl[73] = 0xD3 ^ 0x9A;
    llIIIIlIlllIIl[74] = " ".length() << "   ".length() << " ".length();
    llIIIIlIlllIIl[75] = 0xCB ^ 0x8C;
    llIIIIlIlllIIl[76] = (0x4A ^ 0x43) << "   ".length();
    llIIIIlIlllIIl[77] = (0x7E ^ 0x5B) << " ".length();
    llIIIIlIlllIIl[78] = 0xA ^ 0x47;
    llIIIIlIlllIIl[79] = (0x2A ^ 0xD) << " ".length();
    llIIIIlIlllIIl[80] = 0x54 ^ 0x1B;
    llIIIIlIlllIIl[81] = (0x3B ^ 0x7E ^ " ".length() << "   ".length() << " ".length()) << " ".length() << " ".length() << " ".length();
    llIIIIlIlllIIl[82] = 0xCE ^ 0x9F ^ (0x29 ^ 0x26) & (0x3B ^ 0x34 ^ 0xFFFFFFFF);
    llIIIIlIlllIIl[83] = (0xB9 ^ 0x90) << " ".length();
    llIIIIlIlllIIl[84] = (0x4B ^ 0x46) << " ".length() ^ 0x62 ^ 0x2B;
    llIIIIlIlllIIl[85] = (0xAF ^ 0xBA) << " ".length() << " ".length();
    llIIIIlIlllIIl[86] = (0x7F ^ 0x78) << "   ".length() ^ 0xE9 ^ 0x84;
    llIIIIlIlllIIl[87] = ((0x36 ^ 0x2B) << " ".length() << " ".length() ^ 0xD ^ 0x52) << " ".length();
    llIIIIlIlllIIl[88] = 0xB0 ^ 0xAB ^ (0x71 ^ 0x62) << " ".length() << " ".length();
    llIIIIlIlllIIl[89] = (0xB2 ^ 0xB9) << "   ".length();
  }
  
  private static boolean lIIIIIlIlIlllllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlIlIlllIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlIllIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlIllIIIIIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 != paramObject2);
  }
  
  private static boolean lIIIIIlIlIllllIl(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2);
  }
  
  private static boolean lIIIIIlIlIllllll(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean lIIIIIlIlIllllII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIlIllIIIIII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIIlIllIIIIll(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static int lIIIIIlIllIIIIlI(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */