package me.stupitdog.bhp;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class f0b extends au {
  private static String[] lIllllllIIlIII;
  
  private static Class[] lIllllllIIlIIl;
  
  private static final String[] lIllllllIIllll;
  
  private static String[] lIllllllIlIIlI;
  
  private static final int[] lIllllllIlIllI;
  
  public f0b() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic me/stupitdog/bhp/f0b.lIllllllIIllll : [Ljava/lang/String;
    //   4: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   7: iconst_0
    //   8: iaload
    //   9: aaload
    //   10: getstatic me/stupitdog/bhp/f0b.lIllllllIIllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   16: iconst_1
    //   17: iaload
    //   18: aaload
    //   19: getstatic me/stupitdog/bhp/f0b.lIllllllIIllll : [Ljava/lang/String;
    //   22: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   25: iconst_2
    //   26: iaload
    //   27: aaload
    //   28: <illegal opcode> 0 : ()Lme/stupitdog/bhp/f13;
    //   33: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lme/stupitdog/bhp/f13;I)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIlllIIIIIIIIlllll	Lme/stupitdog/bhp/f0b;
  }
  
  public void update() {
    // Byte code:
    //   0: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   5: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   10: getstatic me/stupitdog/bhp/f0b.lIllllllIIllll : [Ljava/lang/String;
    //   13: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   16: iconst_3
    //   17: iaload
    //   18: aaload
    //   19: <illegal opcode> 3 : (Ljava/lang/String;)Lnet/minecraft/potion/Potion;
    //   24: <illegal opcode> 4 : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: checkcast net/minecraft/potion/Potion
    //   32: <illegal opcode> 5 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Z
    //   37: invokestatic lIIIIIIIIlIlllll : (I)Z
    //   40: ifeq -> 78
    //   43: <illegal opcode> 1 : ()Lnet/minecraft/client/Minecraft;
    //   48: <illegal opcode> 2 : (Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/entity/EntityPlayerSP;
    //   53: getstatic me/stupitdog/bhp/f0b.lIllllllIIllll : [Ljava/lang/String;
    //   56: getstatic me/stupitdog/bhp/f0b.lIllllllIlIllI : [I
    //   59: iconst_4
    //   60: iaload
    //   61: aaload
    //   62: <illegal opcode> 3 : (Ljava/lang/String;)Lnet/minecraft/potion/Potion;
    //   67: <illegal opcode> 6 : (Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect;
    //   72: ldc ''
    //   74: invokevirtual length : ()I
    //   77: pop2
    //   78: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	79	0	lllllllllllllllIlllIIIIIIIIllllI	Lme/stupitdog/bhp/f0b;
  }
  
  static {
    lIIIIIIIIlIllllI();
    lIIIIIIIIlIlIIII();
    lIIIIIIIIlIIlllI();
    lIIIIIIIIlIIIllI();
  }
  
  private static CallSite lIIIIIIIIIllIlII(MethodHandles.Lookup lllllllllllllllIlllIIIIIIIIlIlIl, String lllllllllllllllIlllIIIIIIIIlIlII, MethodType lllllllllllllllIlllIIIIIIIIlIIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIIIIIIllIll = lIllllllIIlIII[Integer.parseInt(lllllllllllllllIlllIIIIIIIIlIlII)].split(lIllllllIIllll[lIllllllIlIllI[5]]);
      Class<?> lllllllllllllllIlllIIIIIIIIllIlI = Class.forName(lllllllllllllllIlllIIIIIIIIllIll[lIllllllIlIllI[0]]);
      String lllllllllllllllIlllIIIIIIIIllIIl = lllllllllllllllIlllIIIIIIIIllIll[lIllllllIlIllI[1]];
      MethodHandle lllllllllllllllIlllIIIIIIIIllIII = null;
      int lllllllllllllllIlllIIIIIIIIlIlll = lllllllllllllllIlllIIIIIIIIllIll[lIllllllIlIllI[3]].length();
      if (lIIIIIIIIllIIIII(lllllllllllllllIlllIIIIIIIIlIlll, lIllllllIlIllI[2])) {
        MethodType lllllllllllllllIlllIIIIIIIIlllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIIIIIIllIll[lIllllllIlIllI[2]], f0b.class.getClassLoader());
        if (lIIIIIIIIllIIIIl(lllllllllllllllIlllIIIIIIIIlIlll, lIllllllIlIllI[2])) {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findVirtual(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllIl);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findStatic(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllIl);
        } 
        "".length();
        if (" ".length() == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIIIIIIlllII = lIllllllIIlIIl[Integer.parseInt(lllllllllllllllIlllIIIIIIIIllIll[lIllllllIlIllI[2]])];
        if (lIIIIIIIIllIIIIl(lllllllllllllllIlllIIIIIIIIlIlll, lIllllllIlIllI[3])) {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findGetter(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllII);
          "".length();
          if ("   ".length() < 0)
            return null; 
        } else if (lIIIIIIIIllIIIIl(lllllllllllllllIlllIIIIIIIIlIlll, lIllllllIlIllI[4])) {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findStaticGetter(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllII);
          "".length();
          if (((0x8 ^ 0x3 ^ (0xBD ^ 0xAE) << " ".length()) & (0x4 ^ 0x67 ^ (0x81 ^ 0xA6) << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (lIIIIIIIIllIIIIl(lllllllllllllllIlllIIIIIIIIlIlll, lIllllllIlIllI[5])) {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findSetter(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllII);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIIIIIIllIII = lllllllllllllllIlllIIIIIIIIlIlIl.findStaticSetter(lllllllllllllllIlllIIIIIIIIllIlI, lllllllllllllllIlllIIIIIIIIllIIl, lllllllllllllllIlllIIIIIIIIlllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIIIIIIllIII);
    } catch (Exception lllllllllllllllIlllIIIIIIIIlIllI) {
      lllllllllllllllIlllIIIIIIIIlIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIlIIIllI() {
    lIllllllIIlIII = new String[lIllllllIlIllI[6]];
    lIllllllIIlIII[lIllllllIlIllI[1]] = lIllllllIIllll[lIllllllIlIllI[7]];
    lIllllllIIlIII[lIllllllIlIllI[3]] = lIllllllIIllll[lIllllllIlIllI[6]];
    lIllllllIIlIII[lIllllllIlIllI[5]] = lIllllllIIllll[lIllllllIlIllI[8]];
    lIllllllIIlIII[lIllllllIlIllI[7]] = lIllllllIIllll[lIllllllIlIllI[9]];
    lIllllllIIlIII[lIllllllIlIllI[2]] = lIllllllIIllll[lIllllllIlIllI[10]];
    lIllllllIIlIII[lIllllllIlIllI[0]] = lIllllllIIllll[lIllllllIlIllI[11]];
    lIllllllIIlIII[lIllllllIlIllI[4]] = lIllllllIIllll[lIllllllIlIllI[12]];
    lIllllllIIlIIl = new Class[lIllllllIlIllI[3]];
    lIllllllIIlIIl[lIllllllIlIllI[1]] = Minecraft.class;
    lIllllllIIlIIl[lIllllllIlIllI[2]] = EntityPlayerSP.class;
    lIllllllIIlIIl[lIllllllIlIllI[0]] = f13.class;
  }
  
  private static void lIIIIIIIIlIIlllI() {
    lIllllllIIllll = new String[lIllllllIlIllI[13]];
    lIllllllIIllll[lIllllllIlIllI[0]] = lIIIIIIIIlIIIlll(lIllllllIlIIlI[lIllllllIlIllI[0]], lIllllllIlIIlI[lIllllllIlIllI[1]]);
    lIllllllIIllll[lIllllllIlIllI[1]] = lIIIIIIIIlIIlIII(lIllllllIlIIlI[lIllllllIlIllI[2]], lIllllllIlIIlI[lIllllllIlIllI[3]]);
    lIllllllIIllll[lIllllllIlIllI[2]] = lIIIIIIIIlIIlIIl(lIllllllIlIIlI[lIllllllIlIllI[4]], lIllllllIlIIlI[lIllllllIlIllI[5]]);
    lIllllllIIllll[lIllllllIlIllI[3]] = lIIIIIIIIlIIlIII(lIllllllIlIIlI[lIllllllIlIllI[7]], lIllllllIlIIlI[lIllllllIlIllI[6]]);
    lIllllllIIllll[lIllllllIlIllI[4]] = lIIIIIIIIlIIlIIl(lIllllllIlIIlI[lIllllllIlIllI[8]], lIllllllIlIIlI[lIllllllIlIllI[9]]);
    lIllllllIIllll[lIllllllIlIllI[5]] = lIIIIIIIIlIIlIII(lIllllllIlIIlI[lIllllllIlIllI[10]], lIllllllIlIIlI[lIllllllIlIllI[11]]);
    lIllllllIIllll[lIllllllIlIllI[7]] = lIIIIIIIIlIIlIIl(lIllllllIlIIlI[lIllllllIlIllI[12]], lIllllllIlIIlI[lIllllllIlIllI[13]]);
    lIllllllIIllll[lIllllllIlIllI[6]] = lIIIIIIIIlIIlIIl(lIllllllIlIIlI[lIllllllIlIllI[14]], lIllllllIlIIlI[lIllllllIlIllI[15]]);
    lIllllllIIllll[lIllllllIlIllI[8]] = lIIIIIIIIlIIlIIl(lIllllllIlIIlI[lIllllllIlIllI[16]], lIllllllIlIIlI[lIllllllIlIllI[17]]);
    lIllllllIIllll[lIllllllIlIllI[9]] = lIIIIIIIIlIIlIII("iN2KFF9IWCInOccg5gdSDiwFxPrUab8KXAL8G33MpKcmEHjkbICR8mnIn1nzhXRr7KNBzobzmpztOLhq4Z9st635QPa5jS4mkfPfmASAqJhpEif+G8Z5J9VA1ryNZEAA3NL83WJmtDsXHAKLSkpp8aVihlm9v4xmmF2m/HYGh2o=", "zgrXe");
    lIllllllIIllll[lIllllllIlIllI[10]] = lIIIIIIIIlIIIlll("JTAnTxkiOzYCBiozJ08XJzw2DwBlGDoPESgnMgcAcTM6BBgvCmRQQHhsDAZOeW9zQVQ=", "KUSat");
    lIllllllIIllll[lIllllllIlIllI[11]] = lIIIIIIIIlIIlIII("C4GJmaRTxk+B9lxCavfbdndy5sUOsoLFqpW0It+yvS+Xsnr7SBfy+g==", "TxMox");
    lIllllllIIllll[lIllllllIlIllI[12]] = lIIIIIIIIlIIIlll("IQogLGQ+Hz8hZAQJPCgpPxhsPy86Hj8/LwUEOAM/JwdsZQYhCiAsZScKOCplBAk8KCk/UH8BICodN2ImKgUxYgUpATMuPnBRdg==", "KkVMJ");
    lIllllllIlIIlI = null;
  }
  
  private static void lIIIIIIIIlIlIIII() {
    String str = (new Exception()).getStackTrace()[lIllllllIlIllI[0]].getFileName();
    lIllllllIlIIlI = str.substring(str.indexOf("ä") + lIllllllIlIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIIIlIIlIII(String lllllllllllllllIlllIIIIIIIIIllll, String lllllllllllllllIlllIIIIIIIIIlllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIIIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIIIIlllI.getBytes(StandardCharsets.UTF_8)), lIllllllIlIllI[8]), "DES");
      Cipher lllllllllllllllIlllIIIIIIIIlIIIl = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIIIIIIlIIIl.init(lIllllllIlIllI[2], lllllllllllllllIlllIIIIIIIIlIIlI);
      return new String(lllllllllllllllIlllIIIIIIIIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIIIlIIII) {
      lllllllllllllllIlllIIIIIIIIlIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIIIlIIIlll(String lllllllllllllllIlllIIIIIIIIIllII, String lllllllllllllllIlllIIIIIIIIIlIll) {
    lllllllllllllllIlllIIIIIIIIIllII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIIIIIIIlIlI = new StringBuilder();
    char[] lllllllllllllllIlllIIIIIIIIIlIIl = lllllllllllllllIlllIIIIIIIIIlIll.toCharArray();
    int lllllllllllllllIlllIIIIIIIIIlIII = lIllllllIlIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIIIIIIIllII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllllIlIllI[0];
    while (lIIIIIIIIllIIIlI(j, i)) {
      char lllllllllllllllIlllIIIIIIIIIllIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIIIIIIIlIII++;
      j++;
      "".length();
      if (((0x6D ^ 0x74) << " ".length() & ((0xD8 ^ 0xC1) << " ".length() ^ 0xFFFFFFFF)) >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIIIIIIIlIlI);
  }
  
  private static String lIIIIIIIIlIIlIIl(String lllllllllllllllIlllIIIIIIIIIIlII, String lllllllllllllllIlllIIIIIIIIIIIll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIIIIIIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIIIIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIIIIIIIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIIIIIIIIllI.init(lIllllllIlIllI[2], lllllllllllllllIlllIIIIIIIIIIlll);
      return new String(lllllllllllllllIlllIIIIIIIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIIIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIIIIIIIIlIl) {
      lllllllllllllllIlllIIIIIIIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIIIlIllllI() {
    lIllllllIlIllI = new int[18];
    lIllllllIlIllI[0] = " ".length() << " ".length() & (" ".length() << " ".length() ^ -" ".length());
    lIllllllIlIllI[1] = " ".length();
    lIllllllIlIllI[2] = " ".length() << " ".length();
    lIllllllIlIllI[3] = "   ".length();
    lIllllllIlIllI[4] = " ".length() << " ".length() << " ".length();
    lIllllllIlIllI[5] = 0x50 ^ 0x55;
    lIllllllIlIllI[6] = 0xE ^ 0x9;
    lIllllllIlIllI[7] = "   ".length() << " ".length();
    lIllllllIlIllI[8] = " ".length() << "   ".length();
    lIllllllIlIllI[9] = 0x35 ^ 0x3C;
    lIllllllIlIllI[10] = (0xC3 ^ 0xC6) << " ".length();
    lIllllllIlIllI[11] = 0xBC ^ 0xC7 ^ (0xA ^ 0xD) << " ".length() << " ".length() << " ".length();
    lIllllllIlIllI[12] = "   ".length() << " ".length() << " ".length();
    lIllllllIlIllI[13] = 0x3C ^ 0x31;
    lIllllllIlIllI[14] = (0x9 ^ 0xE) << " ".length();
    lIllllllIlIllI[15] = " ".length() << "   ".length() ^ 0xA8 ^ 0xAF;
    lIllllllIlIllI[16] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllllIlIllI[17] = (0x75 ^ 0x38) << " ".length() ^ 76 + 42 - 11 + 32;
  }
  
  private static boolean lIIIIIIIIllIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIIIllIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIIIllIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIIIlIlllll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\me\stupitdog\bhp\f0b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */