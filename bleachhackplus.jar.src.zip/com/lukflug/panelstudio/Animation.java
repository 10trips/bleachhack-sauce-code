package com.lukflug.panelstudio;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class Animation {
  protected double value;
  
  protected double lastValue;
  
  protected long lastTime;
  
  private static String[] llIIlIIIIIIlIl;
  
  private static Class[] llIIlIIIIIIllI;
  
  private static final String[] llIIlIIIIIIlll;
  
  private static String[] llIIlIIIIIlIII;
  
  private static final int[] llIIlIIIIIlIIl;
  
  public Animation() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: <illegal opcode> 0 : ()J
    //   10: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Animation;J)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIllIIlllllIlllllI	Lcom/lukflug/panelstudio/Animation;
  }
  
  public void initValue(double lllllllllllllllIllIIlllllIllllII) {
    // Byte code:
    //   0: aload_0
    //   1: dload_1
    //   2: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   7: aload_0
    //   8: dload_1
    //   9: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   14: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	15	0	lllllllllllllllIllIIlllllIllllIl	Lcom/lukflug/panelstudio/Animation;
    //   0	15	1	lllllllllllllllIllIIlllllIllllII	D
  }
  
  public double getValue() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Animation;)I
    //   6: invokestatic lIIIIlIllllIllIl : (I)Z
    //   9: ifeq -> 19
    //   12: aload_0
    //   13: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;)D
    //   18: dreturn
    //   19: <illegal opcode> 0 : ()J
    //   24: aload_0
    //   25: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/Animation;)J
    //   30: lsub
    //   31: l2d
    //   32: aload_0
    //   33: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Animation;)I
    //   38: i2d
    //   39: ddiv
    //   40: dstore_1
    //   41: dload_1
    //   42: dconst_1
    //   43: invokestatic lIIIIlIllllIlIll : (DD)I
    //   46: invokestatic lIIIIlIllllIlllI : (I)Z
    //   49: ifeq -> 59
    //   52: aload_0
    //   53: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;)D
    //   58: dreturn
    //   59: dload_1
    //   60: dconst_0
    //   61: invokestatic lIIIIlIllllIllII : (DD)I
    //   64: invokestatic lIIIIlIllllIllll : (I)Z
    //   67: ifeq -> 77
    //   70: aload_0
    //   71: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Animation;)D
    //   76: dreturn
    //   77: aload_0
    //   78: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;)D
    //   83: dload_1
    //   84: dmul
    //   85: aload_0
    //   86: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Animation;)D
    //   91: dconst_1
    //   92: dload_1
    //   93: dsub
    //   94: dmul
    //   95: dadd
    //   96: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	97	0	lllllllllllllllIllIIlllllIlllIll	Lcom/lukflug/panelstudio/Animation;
    //   41	56	1	lllllllllllllllIllIIlllllIlllIlI	D
  }
  
  public double getTarget() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;)D
    //   6: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlllllIlllIIl	Lcom/lukflug/panelstudio/Animation;
  }
  
  public void setValue(double lllllllllllllllIllIIlllllIllIlll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/Animation;)D
    //   7: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   12: aload_0
    //   13: dload_1
    //   14: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   19: aload_0
    //   20: <illegal opcode> 0 : ()J
    //   25: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Animation;J)V
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIllIIlllllIlllIII	Lcom/lukflug/panelstudio/Animation;
    //   0	31	1	lllllllllllllllIllIIlllllIllIlll	D
  }
  
  protected abstract int getSpeed();
  
  static {
    lIIIIlIllllIlIlI();
    lIIIIlIllllIlIIl();
    lIIIIlIllllIlIII();
    lIIIIlIllllIIlII();
  }
  
  private static CallSite lIIIIlIllllIIIll(MethodHandles.Lookup lllllllllllllllIllIIlllllIlIlllI, String lllllllllllllllIllIIlllllIlIllIl, MethodType lllllllllllllllIllIIlllllIlIllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlllllIllIlII = llIIlIIIIIIlIl[Integer.parseInt(lllllllllllllllIllIIlllllIlIllIl)].split(llIIlIIIIIIlll[llIIlIIIIIlIIl[0]]);
      Class<?> lllllllllllllllIllIIlllllIllIIll = Class.forName(lllllllllllllllIllIIlllllIllIlII[llIIlIIIIIlIIl[0]]);
      String lllllllllllllllIllIIlllllIllIIlI = lllllllllllllllIllIIlllllIllIlII[llIIlIIIIIlIIl[1]];
      MethodHandle lllllllllllllllIllIIlllllIllIIIl = null;
      int lllllllllllllllIllIIlllllIllIIII = lllllllllllllllIllIIlllllIllIlII[llIIlIIIIIlIIl[2]].length();
      if (lIIIIlIlllllIIII(lllllllllllllllIllIIlllllIllIIII, llIIlIIIIIlIIl[3])) {
        MethodType lllllllllllllllIllIIlllllIllIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlllllIllIlII[llIIlIIIIIlIIl[3]], Animation.class.getClassLoader());
        if (lIIIIlIlllllIIIl(lllllllllllllllIllIIlllllIllIIII, llIIlIIIIIlIIl[3])) {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findVirtual(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIllI);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findStatic(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIllI);
        } 
        "".length();
        if (-" ".length() >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlllllIllIlIl = llIIlIIIIIIllI[Integer.parseInt(lllllllllllllllIllIIlllllIllIlII[llIIlIIIIIlIIl[3]])];
        if (lIIIIlIlllllIIIl(lllllllllllllllIllIIlllllIllIIII, llIIlIIIIIlIIl[2])) {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findGetter(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIlIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIlllllIIIl(lllllllllllllllIllIIlllllIllIIII, llIIlIIIIIlIIl[4])) {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findStaticGetter(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIlIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= -" ".length())
            return null; 
        } else if (lIIIIlIlllllIIIl(lllllllllllllllIllIIlllllIllIIII, llIIlIIIIIlIIl[5])) {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findSetter(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIlIl);
          "".length();
          if ("   ".length() != "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIlllllIllIIIl = lllllllllllllllIllIIlllllIlIlllI.findStaticSetter(lllllllllllllllIllIIlllllIllIIll, lllllllllllllllIllIIlllllIllIIlI, lllllllllllllllIllIIlllllIllIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlllllIllIIIl);
    } catch (Exception lllllllllllllllIllIIlllllIlIllll) {
      lllllllllllllllIllIIlllllIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllllIIlII() {
    llIIlIIIIIIlIl = new String[llIIlIIIIIlIIl[6]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[0]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[1]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[7]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[3]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[3]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[2]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[5]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[4]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[2]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[5]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[8]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[8]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[1]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[9]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[9]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[7]];
    llIIlIIIIIIlIl[llIIlIIIIIlIIl[4]] = llIIlIIIIIIlll[llIIlIIIIIlIIl[6]];
    llIIlIIIIIIllI = new Class[llIIlIIIIIlIIl[3]];
    llIIlIIIIIIllI[llIIlIIIIIlIIl[1]] = double.class;
    llIIlIIIIIIllI[llIIlIIIIIlIIl[0]] = long.class;
  }
  
  private static void lIIIIlIllllIlIII() {
    llIIlIIIIIIlll = new String[llIIlIIIIIlIIl[10]];
    llIIlIIIIIIlll[llIIlIIIIIlIIl[0]] = lIIIIlIllllIIlIl(llIIlIIIIIlIII[llIIlIIIIIlIIl[0]], llIIlIIIIIlIII[llIIlIIIIIlIIl[1]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[1]] = lIIIIlIllllIIllI(llIIlIIIIIlIII[llIIlIIIIIlIIl[3]], llIIlIIIIIlIII[llIIlIIIIIlIIl[2]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[3]] = lIIIIlIllllIIlIl(llIIlIIIIIlIII[llIIlIIIIIlIIl[4]], llIIlIIIIIlIII[llIIlIIIIIlIIl[5]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[2]] = lIIIIlIllllIIlll(llIIlIIIIIlIII[llIIlIIIIIlIIl[8]], llIIlIIIIIlIII[llIIlIIIIIlIIl[9]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[4]] = lIIIIlIllllIIlll(llIIlIIIIIlIII[llIIlIIIIIlIIl[7]], llIIlIIIIIlIII[llIIlIIIIIlIIl[6]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[5]] = lIIIIlIllllIIlll(llIIlIIIIIlIII[llIIlIIIIIlIIl[10]], llIIlIIIIIlIII[llIIlIIIIIlIIl[11]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[8]] = lIIIIlIllllIIlll(llIIlIIIIIlIII[llIIlIIIIIlIIl[12]], llIIlIIIIIlIII[llIIlIIIIIlIIl[13]]);
    llIIlIIIIIIlll[llIIlIIIIIlIIl[9]] = lIIIIlIllllIIlll("DjY6TQIYMjEPGwp3JwIACDUkFxsJMDhNLwMwOgIaBDY5WQIMKiM3BwA8bVNUTXl3Q04=", "mYWcn");
    llIIlIIIIIIlll[llIIlIIIIIlIIl[7]] = lIIIIlIllllIIlIl("ud+zJhbQhG+dNqJunAlEhRochFopiwAa604n4JBDtNx6CmtONXoRc6JbyX7E8LUKCJQ/fSfz7Gc=", "FZQZB");
    llIIlIIIIIIlll[llIIlIIIIIlIIl[6]] = lIIIIlIllllIIlIl("ZNqXxljBhSv++SnzRhwhlhVLi7to1v59XoLotRhaW8usKGrYHLO097RxSUL/g+dlt2QmpSI681w=", "HKaDt");
    llIIlIIIIIlIII = null;
  }
  
  private static void lIIIIlIllllIlIIl() {
    String str = (new Exception()).getStackTrace()[llIIlIIIIIlIIl[0]].getFileName();
    llIIlIIIIIlIII = str.substring(str.indexOf("ä") + llIIlIIIIIlIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIllllIIlll(String lllllllllllllllIllIIlllllIlIlIlI, String lllllllllllllllIllIIlllllIlIlIIl) {
    lllllllllllllllIllIIlllllIlIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIlIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlllllIlIlIII = new StringBuilder();
    char[] lllllllllllllllIllIIlllllIlIIlll = lllllllllllllllIllIIlllllIlIlIIl.toCharArray();
    int lllllllllllllllIllIIlllllIlIIllI = llIIlIIIIIlIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlllllIlIlIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIIIIlIIl[0];
    while (lIIIIlIlllllIIlI(j, i)) {
      char lllllllllllllllIllIIlllllIlIlIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlllllIlIIllI++;
      j++;
      "".length();
      if (" ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlllllIlIlIII);
  }
  
  private static String lIIIIlIllllIIllI(String lllllllllllllllIllIIlllllIlIIIlI, String lllllllllllllllIllIIlllllIlIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllllIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIlIIIIl.getBytes(StandardCharsets.UTF_8)), llIIlIIIIIlIIl[7]), "DES");
      Cipher lllllllllllllllIllIIlllllIlIIlII = Cipher.getInstance("DES");
      lllllllllllllllIllIIlllllIlIIlII.init(llIIlIIIIIlIIl[3], lllllllllllllllIllIIlllllIlIIlIl);
      return new String(lllllllllllllllIllIIlllllIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllllIlIIIll) {
      lllllllllllllllIllIIlllllIlIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIllllIIlIl(String lllllllllllllllIllIIlllllIIlllIl, String lllllllllllllllIllIIlllllIIlllII) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllllIlIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlllllIIlllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlllllIIlllll.init(llIIlIIIIIlIIl[3], lllllllllllllllIllIIlllllIlIIIII);
      return new String(lllllllllllllllIllIIlllllIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllllIIllllI) {
      lllllllllllllllIllIIlllllIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllllIlIlI() {
    llIIlIIIIIlIIl = new int[14];
    llIIlIIIIIlIIl[0] = (0x7F ^ 0x64 ^ (0x16 ^ 0x19) << " ".length()) << "   ".length() & ((" ".length() << (0x4E ^ 0x4B) ^ 0xAB ^ 0x8E) << "   ".length() ^ -" ".length());
    llIIlIIIIIlIIl[1] = " ".length();
    llIIlIIIIIlIIl[2] = "   ".length();
    llIIlIIIIIlIIl[3] = " ".length() << " ".length();
    llIIlIIIIIlIIl[4] = " ".length() << " ".length() << " ".length();
    llIIlIIIIIlIIl[5] = 0x62 ^ 0x67;
    llIIlIIIIIlIIl[6] = 0x5B ^ 0x52;
    llIIlIIIIIlIIl[7] = " ".length() << "   ".length();
    llIIlIIIIIlIIl[8] = "   ".length() << " ".length();
    llIIlIIIIIlIIl[9] = 0x6F ^ 0x68;
    llIIlIIIIIlIIl[10] = (0x1C ^ 0x9 ^ " ".length() << " ".length() << " ".length() << " ".length()) << " ".length();
    llIIlIIIIIlIIl[11] = 0x39 ^ 0x68 ^ (0x3B ^ 0x16) << " ".length();
    llIIlIIIIIlIIl[12] = "   ".length() << " ".length() << " ".length();
    llIIlIIIIIlIIl[13] = 0xC ^ 0x1;
  }
  
  private static boolean lIIIIlIlllllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIlllllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIlllllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIllllIllIl(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lIIIIlIllllIlllI(int paramInt) {
    return (paramInt >= 0);
  }
  
  private static boolean lIIIIlIllllIllll(int paramInt) {
    return (paramInt <= 0);
  }
  
  private static int lIIIIlIllllIlIll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIlIllllIllII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\Animation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */