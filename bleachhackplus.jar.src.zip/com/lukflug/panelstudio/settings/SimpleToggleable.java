package com.lukflug.panelstudio.settings;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class SimpleToggleable implements Toggleable {
  private boolean value;
  
  private static String[] llIIIIIlIlIlll;
  
  private static Class[] llIIIIIlIllIII;
  
  private static final String[] llIIIIIlIllIIl;
  
  private static String[] llIIIIIlIllIlI;
  
  private static final int[] llIIIIIlIlllII;
  
  public SimpleToggleable(boolean lllllllllllllllIllIlllIIIIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: iload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/SimpleToggleable;Z)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlllIIIIIIlIIl	Lcom/lukflug/panelstudio/settings/SimpleToggleable;
    //   0	12	1	lllllllllllllllIllIlllIIIIIIlIII	Z
  }
  
  public void toggle() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/SimpleToggleable;)Z
    //   7: invokestatic lIIIIIIlllIlIIlI : (I)Z
    //   10: ifeq -> 90
    //   13: getstatic com/lukflug/panelstudio/settings/SimpleToggleable.llIIIIIlIlllII : [I
    //   16: iconst_0
    //   17: iaload
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop
    //   24: bipush #18
    //   26: bipush #11
    //   28: ixor
    //   29: ldc ' '
    //   31: invokevirtual length : ()I
    //   34: ishl
    //   35: bipush #20
    //   37: bipush #13
    //   39: ixor
    //   40: ldc ' '
    //   42: invokevirtual length : ()I
    //   45: ishl
    //   46: iconst_m1
    //   47: ixor
    //   48: iand
    //   49: bipush #81
    //   51: bipush #90
    //   53: ixor
    //   54: ldc ' '
    //   56: invokevirtual length : ()I
    //   59: ldc ' '
    //   61: invokevirtual length : ()I
    //   64: ishl
    //   65: ishl
    //   66: bipush #85
    //   68: bipush #94
    //   70: ixor
    //   71: ldc ' '
    //   73: invokevirtual length : ()I
    //   76: ldc ' '
    //   78: invokevirtual length : ()I
    //   81: ishl
    //   82: ishl
    //   83: iconst_m1
    //   84: ixor
    //   85: iand
    //   86: if_icmpeq -> 95
    //   89: return
    //   90: getstatic com/lukflug/panelstudio/settings/SimpleToggleable.llIIIIIlIlllII : [I
    //   93: iconst_1
    //   94: iaload
    //   95: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/SimpleToggleable;Z)V
    //   100: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	101	0	lllllllllllllllIllIlllIIIIIIIlll	Lcom/lukflug/panelstudio/settings/SimpleToggleable;
  }
  
  public boolean isOn() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/SimpleToggleable;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlllIIIIIIIllI	Lcom/lukflug/panelstudio/settings/SimpleToggleable;
  }
  
  static {
    lIIIIIIlllIlIIIl();
    lIIIIIIlllIlIIII();
    lIIIIIIlllIIllll();
    lIIIIIIlllIIllII();
  }
  
  private static CallSite lIIIIIIlllIIlIll(MethodHandles.Lookup lllllllllllllllIllIllIllllllllIl, String lllllllllllllllIllIllIllllllllII, MethodType lllllllllllllllIllIllIlllllllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIIIIIIIIll = llIIIIIlIlIlll[Integer.parseInt(lllllllllllllllIllIllIllllllllII)].split(llIIIIIlIllIIl[llIIIIIlIlllII[1]]);
      Class<?> lllllllllllllllIllIlllIIIIIIIIlI = Class.forName(lllllllllllllllIllIlllIIIIIIIIll[llIIIIIlIlllII[1]]);
      String lllllllllllllllIllIlllIIIIIIIIIl = lllllllllllllllIllIlllIIIIIIIIll[llIIIIIlIlllII[0]];
      MethodHandle lllllllllllllllIllIlllIIIIIIIIII = null;
      int lllllllllllllllIllIllIllllllllll = lllllllllllllllIllIlllIIIIIIIIll[llIIIIIlIlllII[2]].length();
      if (lIIIIIIlllIlIIll(lllllllllllllllIllIllIllllllllll, llIIIIIlIlllII[3])) {
        MethodType lllllllllllllllIllIlllIIIIIIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIIIIIIIIll[llIIIIIlIlllII[3]], SimpleToggleable.class.getClassLoader());
        if (lIIIIIIlllIlIlII(lllllllllllllllIllIllIllllllllll, llIIIIIlIlllII[3])) {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findVirtual(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlIl);
          "".length();
          if (" ".length() << " ".length() <= " ".length())
            return null; 
        } else {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findStatic(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlIl);
        } 
        "".length();
        if ("   ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIIIIIIIlII = llIIIIIlIllIII[Integer.parseInt(lllllllllllllllIllIlllIIIIIIIIll[llIIIIIlIlllII[3]])];
        if (lIIIIIIlllIlIlII(lllllllllllllllIllIllIllllllllll, llIIIIIlIlllII[2])) {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findGetter(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlII);
          "".length();
          if (" ".length() << " ".length() < " ".length() << " ".length())
            return null; 
        } else if (lIIIIIIlllIlIlII(lllllllllllllllIllIllIllllllllll, llIIIIIlIlllII[4])) {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findStaticGetter(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlII);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else if (lIIIIIIlllIlIlII(lllllllllllllllIllIllIllllllllll, llIIIIIlIlllII[5])) {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findSetter(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllIlllIIIIIIIIII = lllllllllllllllIllIllIllllllllIl.findStaticSetter(lllllllllllllllIllIlllIIIIIIIIlI, lllllllllllllllIllIlllIIIIIIIIIl, lllllllllllllllIllIlllIIIIIIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIIIIIIIIII);
    } catch (Exception lllllllllllllllIllIllIlllllllllI) {
      lllllllllllllllIllIllIlllllllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlllIIllII() {
    llIIIIIlIlIlll = new String[llIIIIIlIlllII[3]];
    llIIIIIlIlIlll[llIIIIIlIlllII[1]] = llIIIIIlIllIIl[llIIIIIlIlllII[0]];
    llIIIIIlIlIlll[llIIIIIlIlllII[0]] = llIIIIIlIllIIl[llIIIIIlIlllII[3]];
    llIIIIIlIllIII = new Class[llIIIIIlIlllII[0]];
    llIIIIIlIllIII[llIIIIIlIlllII[1]] = boolean.class;
  }
  
  private static void lIIIIIIlllIIllll() {
    llIIIIIlIllIIl = new String[llIIIIIlIlllII[2]];
    llIIIIIlIllIIl[llIIIIIlIlllII[1]] = lIIIIIIlllIIllIl(llIIIIIlIllIlI[llIIIIIlIlllII[1]], llIIIIIlIllIlI[llIIIIIlIlllII[0]]);
    llIIIIIlIllIIl[llIIIIIlIlllII[0]] = lIIIIIIlllIIlllI(llIIIIIlIllIlI[llIIIIIlIlllII[3]], llIIIIIlIllIlI[llIIIIIlIlllII[2]]);
    llIIIIIlIllIIl[llIIIIIlIlllII[3]] = lIIIIIIlllIIlllI(llIIIIIlIllIlI[llIIIIIlIlllII[4]], llIIIIIlIllIlI[llIIIIIlIlllII[5]]);
    llIIIIIlIllIlI = null;
  }
  
  private static void lIIIIIIlllIlIIII() {
    String str = (new Exception()).getStackTrace()[llIIIIIlIlllII[1]].getFileName();
    llIIIIIlIllIlI = str.substring(str.indexOf("ä") + llIIIIIlIlllII[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlllIIllIl(String lllllllllllllllIllIllIlllllllIIl, String lllllllllllllllIllIllIlllllllIII) {
    lllllllllllllllIllIllIlllllllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIlllllllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIllIllllllIlll = new StringBuilder();
    char[] lllllllllllllllIllIllIllllllIllI = lllllllllllllllIllIllIlllllllIII.toCharArray();
    int lllllllllllllllIllIllIllllllIlIl = llIIIIIlIlllII[1];
    char[] arrayOfChar1 = lllllllllllllllIllIllIlllllllIIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIlIlllII[1];
    while (lIIIIIIlllIlIlIl(j, i)) {
      char lllllllllllllllIllIllIlllllllIlI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIllIllllllIlIl++;
      j++;
      "".length();
      if (((114 + 106 - 42 + 1 ^ (0x1E ^ 0x33) << " ".length() << " ".length()) << " ".length() & ((" ".length() << " ".length() << " ".length() << " ".length() ^ 0x5 ^ 0x12) << " ".length() ^ -" ".length())) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIllIllllllIlll);
  }
  
  private static String lIIIIIIlllIIlllI(String lllllllllllllllIllIllIllllllIIIl, String lllllllllllllllIllIllIllllllIIII) {
    try {
      SecretKeySpec lllllllllllllllIllIllIllllllIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIllllllIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllIllllllIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllIllllllIIll.init(llIIIIIlIlllII[3], lllllllllllllllIllIllIllllllIlII);
      return new String(lllllllllllllllIllIllIllllllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIllllllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIllIllllllIIlI) {
      lllllllllllllllIllIllIllllllIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlllIlIIIl() {
    llIIIIIlIlllII = new int[6];
    llIIIIIlIlllII[0] = " ".length();
    llIIIIIlIlllII[1] = (0xA2 ^ 0x83) & (0x3 ^ 0x22 ^ 0xFFFFFFFF);
    llIIIIIlIlllII[2] = "   ".length();
    llIIIIIlIlllII[3] = " ".length() << " ".length();
    llIIIIIlIlllII[4] = " ".length() << " ".length() << " ".length();
    llIIIIIlIlllII[5] = 146 + 62 - 168 + 121 ^ (0xA6 ^ 0x8F) << " ".length() << " ".length();
  }
  
  private static boolean lIIIIIIlllIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlllIlIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlllIlIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIIlllIlIIlI(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\SimpleToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */