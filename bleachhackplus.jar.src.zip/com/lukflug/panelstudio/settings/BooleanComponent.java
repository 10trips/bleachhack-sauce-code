package com.lukflug.panelstudio.settings;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.FocusableComponent;
import com.lukflug.panelstudio.theme.Renderer;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class BooleanComponent extends FocusableComponent {
  protected Toggleable setting;
  
  private static String[] lIllIllIIlIIll;
  
  private static Class[] lIllIllIIlIlII;
  
  private static final String[] lIllIllIIllllI;
  
  private static String[] lIllIllIIlllll;
  
  private static final int[] lIllIllIlIIIII;
  
  public BooleanComponent(String lllllllllllllllIllllIIllIIllIlIl, String lllllllllllllllIllllIIllIIllIlII, Renderer lllllllllllllllIllllIIllIIllIIll, Toggleable lllllllllllllllIllllIIllIIllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: aload_3
    //   4: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   7: aload_0
    //   8: aload #4
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIllllIIllIIllIllI	Lcom/lukflug/panelstudio/settings/BooleanComponent;
    //   0	16	1	lllllllllllllllIllllIIllIIllIlIl	Ljava/lang/String;
    //   0	16	2	lllllllllllllllIllllIIllIIllIlII	Ljava/lang/String;
    //   0	16	3	lllllllllllllllIllllIIllIIllIIll	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	16	4	lllllllllllllllIllllIIllIIllIIlI	Lcom/lukflug/panelstudio/settings/Toggleable;
  }
  
  public void render(Context lllllllllllllllIllllIIllIIllIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
    //   5: aload_0
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   11: aload_1
    //   12: aload_0
    //   13: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;)Ljava/lang/String;
    //   18: aload_0
    //   19: aload_1
    //   20: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;Lcom/lukflug/panelstudio/Context;)Z
    //   25: aload_0
    //   26: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   31: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   36: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
    //   41: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	42	0	lllllllllllllllIllllIIllIIllIIIl	Lcom/lukflug/panelstudio/settings/BooleanComponent;
    //   0	42	1	lllllllllllllllIllllIIllIIllIIII	Lcom/lukflug/panelstudio/Context;
  }
  
  public void handleButton(Context lllllllllllllllIllllIIllIIlIlllI, int lllllllllllllllIllllIIllIIlIllIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: invokespecial handleButton : (Lcom/lukflug/panelstudio/Context;I)V
    //   6: iload_2
    //   7: invokestatic llllIlIlIlIlIll : (I)Z
    //   10: ifeq -> 36
    //   13: aload_1
    //   14: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Z
    //   19: invokestatic llllIlIlIlIllII : (I)Z
    //   22: ifeq -> 36
    //   25: aload_0
    //   26: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/BooleanComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   31: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   36: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	37	0	lllllllllllllllIllllIIllIIlIllll	Lcom/lukflug/panelstudio/settings/BooleanComponent;
    //   0	37	1	lllllllllllllllIllllIIllIIlIlllI	Lcom/lukflug/panelstudio/Context;
    //   0	37	2	lllllllllllllllIllllIIllIIlIllIl	I
  }
  
  static {
    llllIlIlIlIlIlI();
    llllIlIlIlIlIII();
    llllIlIlIlIIllI();
    llllIlIlIIlIIII();
  }
  
  private static CallSite llllIlIIllllIll(MethodHandles.Lookup lllllllllllllllIllllIIllIIlIIlII, String lllllllllllllllIllllIIllIIlIIIll, MethodType lllllllllllllllIllllIIllIIlIIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIllIIlIlIlI = lIllIllIIlIIll[Integer.parseInt(lllllllllllllllIllllIIllIIlIIIll)].split(lIllIllIIllllI[lIllIllIlIIIII[0]]);
      Class<?> lllllllllllllllIllllIIllIIlIlIIl = Class.forName(lllllllllllllllIllllIIllIIlIlIlI[lIllIllIlIIIII[0]]);
      String lllllllllllllllIllllIIllIIlIlIII = lllllllllllllllIllllIIllIIlIlIlI[lIllIllIlIIIII[1]];
      MethodHandle lllllllllllllllIllllIIllIIlIIlll = null;
      int lllllllllllllllIllllIIllIIlIIllI = lllllllllllllllIllllIIllIIlIlIlI[lIllIllIlIIIII[2]].length();
      if (llllIlIlIlIllIl(lllllllllllllllIllllIIllIIlIIllI, lIllIllIlIIIII[3])) {
        MethodType lllllllllllllllIllllIIllIIlIllII = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIllIIlIlIlI[lIllIllIlIIIII[3]], BooleanComponent.class.getClassLoader());
        if (llllIlIlIlIlllI(lllllllllllllllIllllIIllIIlIIllI, lIllIllIlIIIII[3])) {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findVirtual(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIllII);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findStatic(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIllII);
        } 
        "".length();
        if (-"  ".length() >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIllIIlIlIll = lIllIllIIlIlII[Integer.parseInt(lllllllllllllllIllllIIllIIlIlIlI[lIllIllIlIIIII[3]])];
        if (llllIlIlIlIlllI(lllllllllllllllIllllIIllIIlIIllI, lIllIllIlIIIII[2])) {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findGetter(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIlIll);
          "".length();
          if (-((0x53 ^ 0x4) << " ".length() ^ (0x65 ^ 0x30) << " ".length()) > 0)
            return null; 
        } else if (llllIlIlIlIlllI(lllllllllllllllIllllIIllIIlIIllI, lIllIllIlIIIII[4])) {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findStaticGetter(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIlIll);
          "".length();
          if (" ".length() << " ".length() < -" ".length())
            return null; 
        } else if (llllIlIlIlIlllI(lllllllllllllllIllllIIllIIlIIllI, lIllIllIlIIIII[5])) {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findSetter(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIlIll);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIllIIlIIlll = lllllllllllllllIllllIIllIIlIIlII.findStaticSetter(lllllllllllllllIllllIIllIIlIlIIl, lllllllllllllllIllllIIllIIlIlIII, lllllllllllllllIllllIIllIIlIlIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIllIIlIIlll);
    } catch (Exception lllllllllllllllIllllIIllIIlIIlIl) {
      lllllllllllllllIllllIIllIIlIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIlIIlIIII() {
    lIllIllIIlIIll = new String[lIllIllIlIIIII[6]];
    lIllIllIIlIIll[lIllIllIlIIIII[5]] = lIllIllIIllllI[lIllIllIlIIIII[1]];
    lIllIllIIlIIll[lIllIllIlIIIII[3]] = lIllIllIIllllI[lIllIllIlIIIII[3]];
    lIllIllIIlIIll[lIllIllIlIIIII[7]] = lIllIllIIllllI[lIllIllIlIIIII[2]];
    lIllIllIIlIIll[lIllIllIlIIIII[8]] = lIllIllIIllllI[lIllIllIlIIIII[4]];
    lIllIllIIlIIll[lIllIllIlIIIII[9]] = lIllIllIIllllI[lIllIllIlIIIII[5]];
    lIllIllIIlIIll[lIllIllIlIIIII[0]] = lIllIllIIllllI[lIllIllIlIIIII[8]];
    lIllIllIIlIIll[lIllIllIlIIIII[4]] = lIllIllIIllllI[lIllIllIlIIIII[9]];
    lIllIllIIlIIll[lIllIllIlIIIII[2]] = lIllIllIIllllI[lIllIllIlIIIII[7]];
    lIllIllIIlIIll[lIllIllIlIIIII[1]] = lIllIllIIllllI[lIllIllIlIIIII[6]];
    lIllIllIIlIlII = new Class[lIllIllIlIIIII[2]];
    lIllIllIIlIlII[lIllIllIlIIIII[1]] = Renderer.class;
    lIllIllIIlIlII[lIllIllIlIIIII[3]] = String.class;
    lIllIllIIlIlII[lIllIllIlIIIII[0]] = Toggleable.class;
  }
  
  private static void llllIlIlIlIIllI() {
    lIllIllIIllllI = new String[lIllIllIlIIIII[10]];
    lIllIllIIllllI[lIllIllIlIIIII[0]] = llllIlIlIIlIIIl(lIllIllIIlllll[lIllIllIlIIIII[0]], lIllIllIIlllll[lIllIllIlIIIII[1]]);
    lIllIllIIllllI[lIllIllIlIIIII[1]] = llllIlIlIIlIIlI(lIllIllIIlllll[lIllIllIlIIIII[3]], lIllIllIIlllll[lIllIllIlIIIII[2]]);
    lIllIllIIllllI[lIllIllIlIIIII[3]] = llllIlIlIIlIIlI(lIllIllIIlllll[lIllIllIlIIIII[4]], lIllIllIIlllll[lIllIllIlIIIII[5]]);
    lIllIllIIllllI[lIllIllIlIIIII[2]] = llllIlIlIIlIIlI(lIllIllIIlllll[lIllIllIlIIIII[8]], lIllIllIIlllll[lIllIllIlIIIII[9]]);
    lIllIllIIllllI[lIllIllIlIIIII[4]] = llllIlIlIIlIIIl(lIllIllIIlllll[lIllIllIlIIIII[7]], lIllIllIIlllll[lIllIllIlIIIII[6]]);
    lIllIllIIllllI[lIllIllIlIIIII[5]] = llllIlIlIIlIIll("EC4KSDUGKgEKLBRvFwc3Fi0UEiwXKAhIGhwvEwMhB3sOFRofKAQNPBd7T08DSWFH", "sAgfY");
    lIllIllIIllllI[lIllIllIlIIIII[8]] = llllIlIlIIlIIlI("gklGPOCdpZHL+hgIt7qrsq2iaux+MbIVMzWsGgN1l6kAld3XIN0itK346ojsMCsQlnzHfio8obKQlO2f7Sy9Bvqn2t5F1t4j", "VDovq");
    lIllIllIIllllI[lIllIllIlIIIII[9]] = llllIlIlIIlIIlI("Wk8DnJoqQYijATvwr7rXzwuSvVpgcnxR8H+yX6EtYT2giH2UAH7dE3O36pcBZGTDhuG/qKMaAZowwoBrxx/6Rw==", "OLbsx");
    lIllIllIIllllI[lIllIllIlIIIII[7]] = llllIlIlIIlIIll("CTgkTCcfPC8OPg15OQMlDzs6Fj4OPiZMOA8jPQslDSRnICQFOywDJSk4JBIkBDInFnECNjokJAkiOlhjJjQmD2QGIiIEJx8wZhIqBDIlET8fMyANZCk4JxYuEiNySxFQd2k=", "jWIbK");
    lIllIllIIllllI[lIllIllIlIIIII[6]] = llllIlIlIIlIIll("Ox8UbB0tGx8uBD9eCSMfPRwKNgQ8GRZsAj0EDSsfPwNXAB43HBwjHxsfFDIeNhUXNksqFRcmFCoVC3hAYlBZYg==", "XpyBq");
    lIllIllIIlllll = null;
  }
  
  private static void llllIlIlIlIlIII() {
    String str = (new Exception()).getStackTrace()[lIllIllIlIIIII[0]].getFileName();
    lIllIllIIlllll = str.substring(str.indexOf("ä") + lIllIllIlIIIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIlIIlIIIl(String lllllllllllllllIllllIIllIIIllllI, String lllllllllllllllIllllIIllIIIlllIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIIllIIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIllIIIlllIl.getBytes(StandardCharsets.UTF_8)), lIllIllIlIIIII[7]), "DES");
      Cipher lllllllllllllllIllllIIllIIlIIIII = Cipher.getInstance("DES");
      lllllllllllllllIllllIIllIIlIIIII.init(lIllIllIlIIIII[3], lllllllllllllllIllllIIllIIlIIIIl);
      return new String(lllllllllllllllIllllIIllIIlIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIllIIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIllIIIlllll) {
      lllllllllllllllIllllIIllIIIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIlIIlIIlI(String lllllllllllllllIllllIIllIIIllIIl, String lllllllllllllllIllllIIllIIIllIII) {
    try {
      SecretKeySpec lllllllllllllllIllllIIllIIIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIllIIIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIllIIIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIllIIIllIll.init(lIllIllIlIIIII[3], lllllllllllllllIllllIIllIIIlllII);
      return new String(lllllllllllllllIllllIIllIIIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIllIIIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIllIIIllIlI) {
      lllllllllllllllIllllIIllIIIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIlIIlIIll(String lllllllllllllllIllllIIllIIIlIllI, String lllllllllllllllIllllIIllIIIlIlIl) {
    lllllllllllllllIllllIIllIIIlIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIllIIIlIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIllIIIlIlII = new StringBuilder();
    char[] lllllllllllllllIllllIIllIIIlIIll = lllllllllllllllIllllIIllIIIlIlIl.toCharArray();
    int lllllllllllllllIllllIIllIIIlIIlI = lIllIllIlIIIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIllIIIlIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllIlIIIII[0];
    while (llllIlIlIlIllll(j, i)) {
      char lllllllllllllllIllllIIllIIIlIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIllIIIlIIlI++;
      j++;
      "".length();
      if (-" ".length() >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIllIIIlIlII);
  }
  
  private static void llllIlIlIlIlIlI() {
    lIllIllIlIIIII = new int[11];
    lIllIllIlIIIII[0] = (0x66 ^ 0x4B) & (0x16 ^ 0x3B ^ 0xFFFFFFFF);
    lIllIllIlIIIII[1] = " ".length();
    lIllIllIlIIIII[2] = "   ".length();
    lIllIllIlIIIII[3] = " ".length() << " ".length();
    lIllIllIlIIIII[4] = " ".length() << " ".length() << " ".length();
    lIllIllIlIIIII[5] = " ".length() << " ".length() << " ".length() ^ " ".length();
    lIllIllIlIIIII[6] = 0x33 ^ 0x3A;
    lIllIllIlIIIII[7] = " ".length() << "   ".length();
    lIllIllIlIIIII[8] = "   ".length() << " ".length();
    lIllIllIlIIIII[9] = 0xB9 ^ 0xBE;
    lIllIllIlIIIII[10] = (84 + 46 - 129 + 166 ^ (0xF3 ^ 0xA2) << " ".length()) << " ".length();
  }
  
  private static boolean llllIlIlIlIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIlIlIllll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIlIlIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlIlIlIllII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllIlIlIlIlIll(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\BooleanComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */