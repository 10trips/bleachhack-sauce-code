package com.lukflug.panelstudio.settings;

import java.awt.Color;

public interface ColorSetting {
  Color getValue();
  
  void setValue(Color paramColor);
  
  Color getColor();
  
  boolean getRainbow();
  
  void setRainbow(boolean paramBoolean);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\ColorSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */