package com.lukflug.panelstudio.settings;

public interface KeybindSetting {
  int getKey();
  
  void setKey(int paramInt);
  
  String getKeyName();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\KeybindSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */