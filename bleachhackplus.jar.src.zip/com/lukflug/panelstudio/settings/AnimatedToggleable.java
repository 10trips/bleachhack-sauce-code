package com.lukflug.panelstudio.settings;

import com.lukflug.panelstudio.Animation;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class AnimatedToggleable implements Toggleable {
  private final Toggleable toggle;
  
  private final Animation animation;
  
  private static String[] lIllIIlIIlIIIl;
  
  private static Class[] lIllIIlIIlIIlI;
  
  private static final String[] lIllIIlIIlIIll;
  
  private static String[] lIllIIlIIlIlll;
  
  private static final int[] lIllIIlIlIIlII;
  
  public AnimatedToggleable(Toggleable lllllllllllllllIlllllIlIIIlIIllI, Animation lllllllllllllllIlllllIlIIIlIIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: putfield toggle : Lcom/lukflug/panelstudio/settings/Toggleable;
    //   9: aload_0
    //   10: aload_2
    //   11: putfield animation : Lcom/lukflug/panelstudio/Animation;
    //   14: aload_1
    //   15: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   20: invokestatic llllIIIIllIlIll : (I)Z
    //   23: ifeq -> 50
    //   26: aload_2
    //   27: dconst_1
    //   28: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   33: ldc ''
    //   35: invokevirtual length : ()I
    //   38: pop
    //   39: ldc '  '
    //   41: invokevirtual length : ()I
    //   44: ineg
    //   45: ifle -> 57
    //   48: aconst_null
    //   49: athrow
    //   50: aload_2
    //   51: dconst_0
    //   52: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   57: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	58	0	lllllllllllllllIlllllIlIIIlIIlll	Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   0	58	1	lllllllllllllllIlllllIlIIIlIIllI	Lcom/lukflug/panelstudio/settings/Toggleable;
    //   0	58	2	lllllllllllllllIlllllIlIIIlIIlIl	Lcom/lukflug/panelstudio/Animation;
  }
  
  public void toggle() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   11: aload_0
    //   12: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   17: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   22: invokestatic llllIIIIllIlIll : (I)Z
    //   25: ifeq -> 51
    //   28: aload_0
    //   29: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   34: dconst_1
    //   35: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   40: ldc ''
    //   42: invokevirtual length : ()I
    //   45: pop
    //   46: aconst_null
    //   47: ifnull -> 63
    //   50: return
    //   51: aload_0
    //   52: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   57: dconst_0
    //   58: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   63: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	64	0	lllllllllllllllIlllllIlIIIlIIlII	Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
  }
  
  public boolean isOn() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllllIlIIIlIIIll	Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
  }
  
  public double getValue() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   6: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/Animation;)D
    //   11: aload_0
    //   12: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   17: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   22: invokestatic llllIIIIllIlIll : (I)Z
    //   25: ifeq -> 50
    //   28: getstatic com/lukflug/panelstudio/settings/AnimatedToggleable.lIllIIlIlIIlII : [I
    //   31: iconst_0
    //   32: iaload
    //   33: ldc ''
    //   35: invokevirtual length : ()I
    //   38: pop
    //   39: ldc '  '
    //   41: invokevirtual length : ()I
    //   44: ineg
    //   45: ifle -> 55
    //   48: dconst_0
    //   49: dreturn
    //   50: getstatic com/lukflug/panelstudio/settings/AnimatedToggleable.lIllIIlIlIIlII : [I
    //   53: iconst_1
    //   54: iaload
    //   55: i2d
    //   56: invokestatic llllIIIIllIllII : (DD)I
    //   59: invokestatic llllIIIIllIlIll : (I)Z
    //   62: ifeq -> 128
    //   65: aload_0
    //   66: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   71: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   76: invokestatic llllIIIIllIlIll : (I)Z
    //   79: ifeq -> 116
    //   82: aload_0
    //   83: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   88: dconst_1
    //   89: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   94: ldc ''
    //   96: invokevirtual length : ()I
    //   99: pop
    //   100: ldc ' '
    //   102: invokevirtual length : ()I
    //   105: ldc ' '
    //   107: invokevirtual length : ()I
    //   110: ishl
    //   111: ifgt -> 128
    //   114: dconst_0
    //   115: dreturn
    //   116: aload_0
    //   117: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   122: dconst_0
    //   123: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   128: aload_0
    //   129: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Lcom/lukflug/panelstudio/Animation;
    //   134: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Animation;)D
    //   139: dreturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	140	0	lllllllllllllllIlllllIlIIIlIIIlI	Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
  }
  
  static {
    llllIIIIllIlIlI();
    llllIIIIlIllIlI();
    llllIIIIlIllIIl();
    llllIIIIlIlIIIl();
  }
  
  private static CallSite llllIIIIlIlIIII(MethodHandles.Lookup lllllllllllllllIlllllIlIIIIllIIl, String lllllllllllllllIlllllIlIIIIllIII, MethodType lllllllllllllllIlllllIlIIIIlIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllllIlIIIIlllll = lIllIIlIIlIIIl[Integer.parseInt(lllllllllllllllIlllllIlIIIIllIII)].split(lIllIIlIIlIIll[lIllIIlIlIIlII[1]]);
      Class<?> lllllllllllllllIlllllIlIIIIllllI = Class.forName(lllllllllllllllIlllllIlIIIIlllll[lIllIIlIlIIlII[1]]);
      String lllllllllllllllIlllllIlIIIIlllIl = lllllllllllllllIlllllIlIIIIlllll[lIllIIlIlIIlII[0]];
      MethodHandle lllllllllllllllIlllllIlIIIIlllII = null;
      int lllllllllllllllIlllllIlIIIIllIll = lllllllllllllllIlllllIlIIIIlllll[lIllIIlIlIIlII[2]].length();
      if (llllIIIIllIlllI(lllllllllllllllIlllllIlIIIIllIll, lIllIIlIlIIlII[3])) {
        MethodType lllllllllllllllIlllllIlIIIlIIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllllIlIIIIlllll[lIllIIlIlIIlII[3]], AnimatedToggleable.class.getClassLoader());
        if (llllIIIIllIllll(lllllllllllllllIlllllIlIIIIllIll, lIllIIlIlIIlII[3])) {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findVirtual(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findStatic(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIIl);
        } 
        "".length();
        if (((0xA9 ^ 0x82 ^ "   ".length() << " ".length() << " ".length()) & ((0x94 ^ 0xB5) << " ".length() ^ 0x7C ^ 0x19 ^ -" ".length())) >= " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllllIlIIIlIIIII = lIllIIlIIlIIlI[Integer.parseInt(lllllllllllllllIlllllIlIIIIlllll[lIllIIlIlIIlII[3]])];
        if (llllIIIIllIllll(lllllllllllllllIlllllIlIIIIllIll, lIllIIlIlIIlII[2])) {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findGetter(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIII);
          "".length();
          if (((0x36 ^ 0x63) << " ".length() ^ 135 + 140 - 186 + 86) == 0)
            return null; 
        } else if (llllIIIIllIllll(lllllllllllllllIlllllIlIIIIllIll, lIllIIlIlIIlII[4])) {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findStaticGetter(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIII);
          "".length();
          if (((0xCD ^ 0xB0 ^ (0x39 ^ 0x2E) << " ".length() << " ".length()) & ((0x27 ^ 0x34) << " ".length() << " ".length() ^ 0x36 ^ 0x5B ^ -" ".length())) != 0)
            return null; 
        } else if (llllIIIIllIllll(lllllllllllllllIlllllIlIIIIllIll, lIllIIlIlIIlII[5])) {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findSetter(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIII);
          "".length();
          if ((" ".length() << " ".length() << " ".length() ^ " ".length()) <= 0)
            return null; 
        } else {
          lllllllllllllllIlllllIlIIIIlllII = lllllllllllllllIlllllIlIIIIllIIl.findStaticSetter(lllllllllllllllIlllllIlIIIIllllI, lllllllllllllllIlllllIlIIIIlllIl, lllllllllllllllIlllllIlIIIlIIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllllIlIIIIlllII);
    } catch (Exception lllllllllllllllIlllllIlIIIIllIlI) {
      lllllllllllllllIlllllIlIIIIllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIIlIlIIIl() {
    lIllIIlIIlIIIl = new String[lIllIIlIlIIlII[6]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[5]] = lIllIIlIIlIIll[lIllIIlIlIIlII[0]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[4]] = lIllIIlIIlIIll[lIllIIlIlIIlII[3]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[0]] = lIllIIlIIlIIll[lIllIIlIlIIlII[2]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[7]] = lIllIIlIIlIIll[lIllIIlIlIIlII[4]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[3]] = lIllIIlIIlIIll[lIllIIlIlIIlII[5]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[1]] = lIllIIlIIlIIll[lIllIIlIlIIlII[8]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[8]] = lIllIIlIIlIIll[lIllIIlIlIIlII[7]];
    lIllIIlIIlIIIl[lIllIIlIlIIlII[2]] = lIllIIlIIlIIll[lIllIIlIlIIlII[6]];
    lIllIIlIIlIIlI = new Class[lIllIIlIlIIlII[3]];
    lIllIIlIIlIIlI[lIllIIlIlIIlII[0]] = Animation.class;
    lIllIIlIIlIIlI[lIllIIlIlIIlII[1]] = Toggleable.class;
  }
  
  private static void llllIIIIlIllIIl() {
    lIllIIlIIlIIll = new String[lIllIIlIlIIlII[9]];
    lIllIIlIIlIIll[lIllIIlIlIIlII[1]] = llllIIIIlIlIIlI(lIllIIlIIlIlll[lIllIIlIlIIlII[1]], lIllIIlIIlIlll[lIllIIlIlIIlII[0]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[0]] = llllIIIIlIlIIll(lIllIIlIIlIlll[lIllIIlIlIIlII[3]], lIllIIlIIlIlll[lIllIIlIlIIlII[2]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[3]] = llllIIIIlIlIlII(lIllIIlIIlIlll[lIllIIlIlIIlII[4]], lIllIIlIIlIlll[lIllIIlIlIIlII[5]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[2]] = llllIIIIlIlIIlI(lIllIIlIIlIlll[lIllIIlIlIIlII[8]], lIllIIlIIlIlll[lIllIIlIlIIlII[7]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[4]] = llllIIIIlIlIIlI(lIllIIlIIlIlll[lIllIIlIlIIlII[6]], lIllIIlIIlIlll[lIllIIlIlIIlII[9]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[5]] = llllIIIIlIlIIlI(lIllIIlIIlIlll[lIllIIlIlIIlII[10]], lIllIIlIIlIlll[lIllIIlIlIIlII[11]]);
    lIllIIlIIlIIll[lIllIIlIlIIlII[8]] = llllIIIIlIlIlII("yZdy4CcmuCsB8KLU7DSJmywd7mTPmppvqGwYHznutWLpXJY/1oxRcsJi55PGhAJ9jXx5dnxfkjg=", "YytKv");
    lIllIIlIIlIIll[lIllIIlIlIIlII[7]] = llllIIIIlIlIIlI("0xbrRk1kK2HqHS3ojibWRpUKtroupxg9NrcQwfvO9BuPd+vsx6DacJaHhJOb0b2Fmmo+V2abk2Y=", "LKqFU");
    lIllIIlIIlIIll[lIllIIlIlIIlII[6]] = llllIIIIlIlIIll("LAcDSQk6AwgLEChGHgYLKgQdExArAQFJFiocGg4LKBtAMwooDwICBC0EC10RIA8JCwB1QEcxX29I", "Ohnge");
    lIllIIlIIlIlll = null;
  }
  
  private static void llllIIIIlIllIlI() {
    String str = (new Exception()).getStackTrace()[lIllIIlIlIIlII[1]].getFileName();
    lIllIIlIIlIlll = str.substring(str.indexOf("ä") + lIllIIlIlIIlII[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIIIIlIlIIlI(String lllllllllllllllIlllllIlIIIIlIIll, String lllllllllllllllIlllllIlIIIIlIIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllllIlIIIIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIlIIIIlIIlI.getBytes(StandardCharsets.UTF_8)), lIllIIlIlIIlII[6]), "DES");
      Cipher lllllllllllllllIlllllIlIIIIlIlIl = Cipher.getInstance("DES");
      lllllllllllllllIlllllIlIIIIlIlIl.init(lIllIIlIlIIlII[3], lllllllllllllllIlllllIlIIIIlIllI);
      return new String(lllllllllllllllIlllllIlIIIIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIlIIIIlIlII) {
      lllllllllllllllIlllllIlIIIIlIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIIIIlIlIIll(String lllllllllllllllIlllllIlIIIIlIIII, String lllllllllllllllIlllllIlIIIIIllll) {
    lllllllllllllllIlllllIlIIIIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIIIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIlIIIIIlllI = new StringBuilder();
    char[] lllllllllllllllIlllllIlIIIIIllIl = lllllllllllllllIlllllIlIIIIIllll.toCharArray();
    int lllllllllllllllIlllllIlIIIIIllII = lIllIIlIlIIlII[1];
    char[] arrayOfChar1 = lllllllllllllllIlllllIlIIIIlIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIIlIlIIlII[1];
    while (llllIIIIlllIIII(j, i)) {
      char lllllllllllllllIlllllIlIIIIlIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllllIlIIIIIllII++;
      j++;
      "".length();
      if (((0xA ^ 0x33) & (0x6 ^ 0x3F ^ 0xFFFFFFFF)) >= " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllllIlIIIIIlllI);
  }
  
  private static String llllIIIIlIlIlII(String lllllllllllllllIlllllIlIIIIIlIII, String lllllllllllllllIlllllIlIIIIIIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllllIlIIIIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIlIIIIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIlIIIIIlIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIlIIIIIlIlI.init(lIllIIlIlIIlII[3], lllllllllllllllIlllllIlIIIIIlIll);
      return new String(lllllllllllllllIlllllIlIIIIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllllIlIIIIIlIIl) {
      lllllllllllllllIlllllIlIIIIIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIIIIllIlIlI() {
    lIllIIlIlIIlII = new int[12];
    lIllIIlIlIIlII[0] = " ".length();
    lIllIIlIlIIlII[1] = (0x73 ^ 0x28 ^ (0x19 ^ 0x10) << "   ".length()) << " ".length() & (((0xB ^ 0x3E) << " ".length() ^ 0x44 ^ 0x3D) << " ".length() ^ -" ".length());
    lIllIIlIlIIlII[2] = "   ".length();
    lIllIIlIlIIlII[3] = " ".length() << " ".length();
    lIllIIlIlIIlII[4] = " ".length() << " ".length() << " ".length();
    lIllIIlIlIIlII[5] = (0x7B ^ 0x7E) << " ".length() << " ".length() << " ".length() ^ 0xF4 ^ 0xA1;
    lIllIIlIlIIlII[6] = " ".length() << "   ".length();
    lIllIIlIlIIlII[7] = 0x41 ^ 0x46;
    lIllIIlIlIIlII[8] = "   ".length() << " ".length();
    lIllIIlIlIIlII[9] = 0x60 ^ 0x69;
    lIllIIlIlIIlII[10] = (0x71 ^ 0x2A ^ (0xF ^ 0x20) << " ".length()) << " ".length();
    lIllIIlIlIIlII[11] = 0x2B ^ 0x20;
  }
  
  private static boolean llllIIIIllIllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIIIIlllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIIIIllIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIIIIllIlIll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static int llllIIIIllIllII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\AnimatedToggleable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */