package com.lukflug.panelstudio.settings;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.CollapsibleContainer;
import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.FocusableComponent;
import com.lukflug.panelstudio.Slider;
import com.lukflug.panelstudio.theme.ColorScheme;
import com.lukflug.panelstudio.theme.Renderer;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ColorComponent extends CollapsibleContainer {
  protected ColorSetting setting;
  
  protected final boolean alpha;
  
  protected final boolean rainbow;
  
  protected ColorScheme scheme;
  
  protected ColorScheme overrideScheme;
  
  protected Toggleable colorModel;
  
  private static String[] lIlllIIIIIlIII;
  
  private static Class[] lIlllIIIIIlIIl;
  
  private static final String[] lIlllIIIIIllII;
  
  private static String[] lIlllIIIIIllIl;
  
  private static final int[] lIlllIIIIIlllI;
  
  public ColorComponent(String lllllllllllllllIllllIIIIIlllllII, String lllllllllllllllIllllIIIIIllllIll, Renderer lllllllllllllllIllllIIIIIllllIlI, Animation lllllllllllllllIllllIIIIIllllIIl, Renderer lllllllllllllllIllllIIIIIllllIII, ColorSetting lllllllllllllllIllllIIIIIlllIlll, boolean lllllllllllllllIllllIIIIIlllIllI, boolean lllllllllllllllIllllIIIIIlllIlIl, Toggleable lllllllllllllllIllllIIIIIlllIlII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: aload_3
    //   4: new com/lukflug/panelstudio/settings/SimpleToggleable
    //   7: dup
    //   8: getstatic com/lukflug/panelstudio/settings/ColorComponent.lIlllIIIIIlllI : [I
    //   11: iconst_0
    //   12: iaload
    //   13: invokespecial <init> : (Z)V
    //   16: aload #4
    //   18: aconst_null
    //   19: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;Lcom/lukflug/panelstudio/Animation;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   22: aload_0
    //   23: aload #6
    //   25: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/settings/ColorSetting;)V
    //   30: aload_0
    //   31: iload #7
    //   33: putfield alpha : Z
    //   36: aload_0
    //   37: iload #8
    //   39: putfield rainbow : Z
    //   42: aload_0
    //   43: new com/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme
    //   46: dup
    //   47: aload_0
    //   48: aload_3
    //   49: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   52: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   57: aload_0
    //   58: new com/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme
    //   61: dup
    //   62: aload_0
    //   63: aload #5
    //   65: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   68: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   73: aload_0
    //   74: aload #9
    //   76: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   81: iload #8
    //   83: invokestatic llllIlllIIlllll : (I)Z
    //   86: ifeq -> 105
    //   89: aload_0
    //   90: new com/lukflug/panelstudio/settings/ColorComponent$ColorButton
    //   93: dup
    //   94: aload_0
    //   95: aload #5
    //   97: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   100: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/Component;)V
    //   105: aload_0
    //   106: new com/lukflug/panelstudio/settings/ColorComponent$ColorSlider
    //   109: dup
    //   110: aload_0
    //   111: aload #5
    //   113: getstatic com/lukflug/panelstudio/settings/ColorComponent.lIlllIIIIIlllI : [I
    //   116: iconst_0
    //   117: iaload
    //   118: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;I)V
    //   121: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/Component;)V
    //   126: aload_0
    //   127: new com/lukflug/panelstudio/settings/ColorComponent$ColorSlider
    //   130: dup
    //   131: aload_0
    //   132: aload #5
    //   134: getstatic com/lukflug/panelstudio/settings/ColorComponent.lIlllIIIIIlllI : [I
    //   137: iconst_1
    //   138: iaload
    //   139: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;I)V
    //   142: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/Component;)V
    //   147: aload_0
    //   148: new com/lukflug/panelstudio/settings/ColorComponent$ColorSlider
    //   151: dup
    //   152: aload_0
    //   153: aload #5
    //   155: getstatic com/lukflug/panelstudio/settings/ColorComponent.lIlllIIIIIlllI : [I
    //   158: iconst_2
    //   159: iaload
    //   160: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;I)V
    //   163: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/Component;)V
    //   168: iload #7
    //   170: invokestatic llllIlllIIlllll : (I)Z
    //   173: ifeq -> 197
    //   176: aload_0
    //   177: new com/lukflug/panelstudio/settings/ColorComponent$ColorSlider
    //   180: dup
    //   181: aload_0
    //   182: aload #5
    //   184: getstatic com/lukflug/panelstudio/settings/ColorComponent.lIlllIIIIIlllI : [I
    //   187: iconst_3
    //   188: iaload
    //   189: invokespecial <init> : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/theme/Renderer;I)V
    //   192: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent;Lcom/lukflug/panelstudio/Component;)V
    //   197: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	198	0	lllllllllllllllIllllIIIIIlllllIl	Lcom/lukflug/panelstudio/settings/ColorComponent;
    //   0	198	1	lllllllllllllllIllllIIIIIlllllII	Ljava/lang/String;
    //   0	198	2	lllllllllllllllIllllIIIIIllllIll	Ljava/lang/String;
    //   0	198	3	lllllllllllllllIllllIIIIIllllIlI	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	198	4	lllllllllllllllIllllIIIIIllllIIl	Lcom/lukflug/panelstudio/Animation;
    //   0	198	5	lllllllllllllllIllllIIIIIllllIII	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	198	6	lllllllllllllllIllllIIIIIlllIlll	Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   0	198	7	lllllllllllllllIllllIIIIIlllIllI	Z
    //   0	198	8	lllllllllllllllIllllIIIIIlllIlIl	Z
    //   0	198	9	lllllllllllllllIllllIIIIIlllIlII	Lcom/lukflug/panelstudio/settings/Toggleable;
  }
  
  public void render(Context lllllllllllllllIllllIIIIIlllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_0
    //   7: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   12: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   17: aload_0
    //   18: aload_1
    //   19: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
    //   22: aload_0
    //   23: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   28: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   33: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	34	0	lllllllllllllllIllllIIIIIlllIIll	Lcom/lukflug/panelstudio/settings/ColorComponent;
    //   0	34	1	lllllllllllllllIllllIIIIIlllIIlI	Lcom/lukflug/panelstudio/Context;
  }
  
  static {
    llllIlllIIllllI();
    llllIlllIIlllIl();
    llllIlllIIlllII();
    llllIlllIIllIII();
  }
  
  private static CallSite llllIlllIIlIllI(MethodHandles.Lookup lllllllllllllllIllllIIIIIllIlIIl, String lllllllllllllllIllllIIIIIllIlIII, MethodType lllllllllllllllIllllIIIIIllIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIIIIllIllll = lIlllIIIIIlIII[Integer.parseInt(lllllllllllllllIllllIIIIIllIlIII)].split(lIlllIIIIIllII[lIlllIIIIIlllI[0]]);
      Class<?> lllllllllllllllIllllIIIIIllIlllI = Class.forName(lllllllllllllllIllllIIIIIllIllll[lIlllIIIIIlllI[0]]);
      String lllllllllllllllIllllIIIIIllIllIl = lllllllllllllllIllllIIIIIllIllll[lIlllIIIIIlllI[1]];
      MethodHandle lllllllllllllllIllllIIIIIllIllII = null;
      int lllllllllllllllIllllIIIIIllIlIll = lllllllllllllllIllllIIIIIllIllll[lIlllIIIIIlllI[3]].length();
      if (llllIlllIlIIIII(lllllllllllllllIllllIIIIIllIlIll, lIlllIIIIIlllI[2])) {
        MethodType lllllllllllllllIllllIIIIIlllIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIIIIllIllll[lIlllIIIIIlllI[2]], ColorComponent.class.getClassLoader());
        if (llllIlllIlIIIIl(lllllllllllllllIllllIIIIIllIlIll, lIlllIIIIIlllI[2])) {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findVirtual(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIIl);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findStatic(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIIl);
        } 
        "".length();
        if (" ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIIIIlllIIII = lIlllIIIIIlIIl[Integer.parseInt(lllllllllllllllIllllIIIIIllIllll[lIlllIIIIIlllI[2]])];
        if (llllIlllIlIIIIl(lllllllllllllllIllllIIIIIllIlIll, lIlllIIIIIlllI[3])) {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findGetter(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIII);
          "".length();
          if (-" ".length() > " ".length() << " ".length())
            return null; 
        } else if (llllIlllIlIIIIl(lllllllllllllllIllllIIIIIllIlIll, lIlllIIIIIlllI[4])) {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findStaticGetter(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIII);
          "".length();
          if (-(0x93 ^ 0x97) >= 0)
            return null; 
        } else if (llllIlllIlIIIIl(lllllllllllllllIllllIIIIIllIlIll, lIlllIIIIIlllI[5])) {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findSetter(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < -" ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIIIIllIllII = lllllllllllllllIllllIIIIIllIlIIl.findStaticSetter(lllllllllllllllIllllIIIIIllIlllI, lllllllllllllllIllllIIIIIllIllIl, lllllllllllllllIllllIIIIIlllIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIIIIllIllII);
    } catch (Exception lllllllllllllllIllllIIIIIllIlIlI) {
      lllllllllllllllIllllIIIIIllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlllIIllIII() {
    lIlllIIIIIlIII = new String[lIlllIIIIIlllI[6]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[4]] = lIlllIIIIIllII[lIlllIIIIIlllI[1]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[2]] = lIlllIIIIIllII[lIlllIIIIIlllI[2]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[7]] = lIlllIIIIIllII[lIlllIIIIIlllI[3]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[8]] = lIlllIIIIIllII[lIlllIIIIIlllI[4]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[9]] = lIlllIIIIIllII[lIlllIIIIIlllI[5]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[5]] = lIlllIIIIIllII[lIlllIIIIIlllI[9]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[0]] = lIlllIIIIIllII[lIlllIIIIIlllI[7]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[3]] = lIlllIIIIIllII[lIlllIIIIIlllI[8]];
    lIlllIIIIIlIII[lIlllIIIIIlllI[1]] = lIlllIIIIIllII[lIlllIIIIIlllI[6]];
    lIlllIIIIIlIIl = new Class[lIlllIIIIIlllI[5]];
    lIlllIIIIIlIIl[lIlllIIIIIlllI[2]] = ColorScheme.class;
    lIlllIIIIIlIIl[lIlllIIIIIlllI[3]] = Toggleable.class;
    lIlllIIIIIlIIl[lIlllIIIIIlllI[4]] = Renderer.class;
    lIlllIIIIIlIIl[lIlllIIIIIlllI[0]] = ColorSetting.class;
    lIlllIIIIIlIIl[lIlllIIIIIlllI[1]] = boolean.class;
  }
  
  private static void llllIlllIIlllII() {
    lIlllIIIIIllII = new String[lIlllIIIIIlllI[10]];
    lIlllIIIIIllII[lIlllIIIIIlllI[0]] = llllIlllIIllIIl(lIlllIIIIIllIl[lIlllIIIIIlllI[0]], lIlllIIIIIllIl[lIlllIIIIIlllI[1]]);
    lIlllIIIIIllII[lIlllIIIIIlllI[1]] = llllIlllIIllIlI(lIlllIIIIIllIl[lIlllIIIIIlllI[2]], lIlllIIIIIllIl[lIlllIIIIIlllI[3]]);
    lIlllIIIIIllII[lIlllIIIIIlllI[2]] = llllIlllIIllIll(lIlllIIIIIllIl[lIlllIIIIIlllI[4]], lIlllIIIIIllIl[lIlllIIIIIlllI[5]]);
    lIlllIIIIIllII[lIlllIIIIIlllI[3]] = llllIlllIIllIlI(lIlllIIIIIllIl[lIlllIIIIIlllI[9]], lIlllIIIIIllIl[lIlllIIIIIlllI[7]]);
    lIlllIIIIIllII[lIlllIIIIIlllI[4]] = llllIlllIIllIlI("nauUcoXzyeALH/PHBCE+UacPWzPuVsFzvVxRyFUEUTRAsptTcrP6EZU6FebfdhtGdQ+OVajAK3eKy6Qhfgemg5Q0V0opuoEI", "KQYcV");
    lIlllIIIIIllII[lIlllIIIIIlllI[5]] = llllIlllIIllIIl("pO5OcJlUV+aCHH5psH14HTCSlO2UrGsRwMvINEBSd0qa7TMa3qstfl2AOabx8dioyOlKQzU9p5TIgTUXwKlJxg==", "cgcPg");
    lIlllIIIIIllII[lIlllIIIIIlllI[9]] = llllIlllIIllIlI("BSU0FkGQxYVgCQxsWCcoLFT5ng3lM2Z2NKWk77Y9g5fHDutByOyo4hvXMlksN2Iw006Y7V4QApkL3FRYY/ofTg==", "BMFSU");
    lIlllIIIIIllII[lIlllIIIIIlllI[7]] = llllIlllIIllIlI("wImWg2A6RvKeNRxW9iFF2T79i8kKJl1GA3AZQeGxaIcd8AnzKDfQdrJPkpe93/soW+Mya6w7YNzXzYaDvM7PyQ==", "NOtmf");
    lIlllIIIIIllII[lIlllIIIIIlllI[8]] = llllIlllIIllIlI("WM3MmB+rgu5/OwPW40sgtClt+pEwgorQ/X+70WPsW7Tt+rVDBfMDgArn+o8Mskg4cCprAtI25Gn3zjdlI1sNWqWMGoFzW7He", "lUnvl");
    lIlllIIIIIllII[lIlllIIIIIlllI[6]] = llllIlllIIllIlI("OFy/gjgQny9oAjlWKyY19c2FBrbvWeUGH5U1WWVkxR4WcNQb/AOUcVXtDe3U8lD7QVLBdPl/EKniDhtDJv6LXQ==", "shcng");
    lIlllIIIIIllIl = null;
  }
  
  private static void llllIlllIIlllIl() {
    String str = (new Exception()).getStackTrace()[lIlllIIIIIlllI[0]].getFileName();
    lIlllIIIIIllIl = str.substring(str.indexOf("ä") + lIlllIIIIIlllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlllIIllIlI(String lllllllllllllllIllllIIIIIllIIIll, String lllllllllllllllIllllIIIIIllIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIIIllIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIIllIIIlI.getBytes(StandardCharsets.UTF_8)), lIlllIIIIIlllI[8]), "DES");
      Cipher lllllllllllllllIllllIIIIIllIIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllllIIIIIllIIlIl.init(lIlllIIIIIlllI[2], lllllllllllllllIllllIIIIIllIIllI);
      return new String(lllllllllllllllIllllIIIIIllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIIllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIIIllIIlII) {
      lllllllllllllllIllllIIIIIllIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlllIIllIIl(String lllllllllllllllIllllIIIIIlIllllI, String lllllllllllllllIllllIIIIIlIlllIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIIIIIllIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIIlIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIIIIllIIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIIIIllIIIII.init(lIlllIIIIIlllI[2], lllllllllllllllIllllIIIIIllIIIIl);
      return new String(lllllllllllllllIllllIIIIIllIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIIlIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIIIIlIlllll) {
      lllllllllllllllIllllIIIIIlIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlllIIllIll(String lllllllllllllllIllllIIIIIlIllIll, String lllllllllllllllIllllIIIIIlIllIlI) {
    lllllllllllllllIllllIIIIIlIllIll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIIIlIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIIIIlIllIIl = new StringBuilder();
    char[] lllllllllllllllIllllIIIIIlIllIII = lllllllllllllllIllllIIIIIlIllIlI.toCharArray();
    int lllllllllllllllIllllIIIIIlIlIlll = lIlllIIIIIlllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIIIIlIllIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllIIIIIlllI[0];
    while (llllIlllIlIIIlI(j, i)) {
      char lllllllllllllllIllllIIIIIlIlllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIIIIlIlIlll++;
      j++;
      "".length();
      if ((" ".length() & (" ".length() ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIIIIlIllIIl);
  }
  
  private static void llllIlllIIllllI() {
    lIlllIIIIIlllI = new int[11];
    lIlllIIIIIlllI[0] = ((0x73 ^ 0x3A) << " ".length() ^ 22 + 77 - 40 + 90) << "   ".length() & ((0xB ^ 0x10 ^ (0x33 ^ 0x34) << " ".length() << " ".length()) << "   ".length() ^ -" ".length());
    lIlllIIIIIlllI[1] = " ".length();
    lIlllIIIIIlllI[2] = " ".length() << " ".length();
    lIlllIIIIIlllI[3] = "   ".length();
    lIlllIIIIIlllI[4] = " ".length() << " ".length() << " ".length();
    lIlllIIIIIlllI[5] = 0x6B ^ 0x6E;
    lIlllIIIIIlllI[6] = 0x73 ^ 0x7A;
    lIlllIIIIIlllI[7] = 0x1 ^ 0x6;
    lIlllIIIIIlllI[8] = " ".length() << "   ".length();
    lIlllIIIIIlllI[9] = "   ".length() << " ".length();
    lIlllIIIIIlllI[10] = ((0x1B ^ 0x2E) << " ".length() ^ 0x5F ^ 0x30) << " ".length();
  }
  
  private static boolean llllIlllIlIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlllIlIIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlllIlIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllIlllIIlllll(int paramInt) {
    return (paramInt != 0);
  }
  
  protected class ColorSettingScheme implements ColorScheme {
    ColorScheme scheme;
    
    private static String[] lIllIlIIlIllII;
    
    private static Class[] lIllIlIIlIllIl;
    
    private static final String[] lIllIlIIlIlllI;
    
    private static String[] lIllIlIIllIIIl;
    
    private static final int[] lIllIlIIllIIlI;
    
    public ColorSettingScheme(ColorComponent lllllllllllllllIllllIllIlIIlIlll, Renderer lllllllllllllllIllllIllIlIIlIllI) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: putfield this$0 : Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   5: aload_0
      //   6: invokespecial <init> : ()V
      //   9: aload_0
      //   10: aload_2
      //   11: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/Renderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   16: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
      //   21: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	lllllllllllllllIllllIllIlIIllIII	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
      //   0	22	1	lllllllllllllllIllllIllIlIIlIlll	Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   0	22	2	lllllllllllllllIllllIllIlIIlIllI	Lcom/lukflug/panelstudio/theme/Renderer;
    }
    
    public Color getActiveColor() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   6: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   11: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   16: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	17	0	lllllllllllllllIllllIllIlIIlIlIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    public Color getInactiveColor() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllllIllIlIIlIlII	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    public Color getBackgroundColor() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllllIllIlIIlIIll	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    public Color getOutlineColor() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllllIllIlIIlIIlI	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    public Color getFontColor() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllllIllIlIIlIIIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    public int getOpacity() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)I
      //   11: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllllIllIlIIlIIII	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSettingScheme;
    }
    
    static {
      llllIIllIIIIIlI();
      llllIIlIlllllII();
      llllIIlIllllIll();
      llllIIlIlllIlIl();
    }
    
    private static CallSite llllIIlIlllIIll(MethodHandles.Lookup lllllllllllllllIllllIllIlIIIIlll, String lllllllllllllllIllllIllIlIIIIllI, MethodType lllllllllllllllIllllIllIlIIIIlIl) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllllIllIlIIIllIl = lIllIlIIlIllII[Integer.parseInt(lllllllllllllllIllllIllIlIIIIllI)].split(lIllIlIIlIlllI[lIllIlIIllIIlI[0]]);
        Class<?> lllllllllllllllIllllIllIlIIIllII = Class.forName(lllllllllllllllIllllIllIlIIIllIl[lIllIlIIllIIlI[0]]);
        String lllllllllllllllIllllIllIlIIIlIll = lllllllllllllllIllllIllIlIIIllIl[lIllIlIIllIIlI[1]];
        MethodHandle lllllllllllllllIllllIllIlIIIlIlI = null;
        int lllllllllllllllIllllIllIlIIIlIIl = lllllllllllllllIllllIllIlIIIllIl[lIllIlIIllIIlI[2]].length();
        if (llllIIllIIIIIll(lllllllllllllllIllllIllIlIIIlIIl, lIllIlIIllIIlI[3])) {
          MethodType lllllllllllllllIllllIllIlIIIllll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIllIlIIIllIl[lIllIlIIllIIlI[3]], ColorSettingScheme.class.getClassLoader());
          if (llllIIllIIIIlII(lllllllllllllllIllllIllIlIIIlIIl, lIllIlIIllIIlI[3])) {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findVirtual(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIllll);
            "".length();
            if (" ".length() <= 0)
              return null; 
          } else {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findStatic(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIllll);
          } 
          "".length();
          if ("   ".length() == -" ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIllllIllIlIIIlllI = lIllIlIIlIllIl[Integer.parseInt(lllllllllllllllIllllIllIlIIIllIl[lIllIlIIllIIlI[3]])];
          if (llllIIllIIIIlII(lllllllllllllllIllllIllIlIIIlIIl, lIllIlIIllIIlI[2])) {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findGetter(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIlllI);
            "".length();
            if (-" ".length() != -" ".length())
              return null; 
          } else if (llllIIllIIIIlII(lllllllllllllllIllllIllIlIIIlIIl, lIllIlIIllIIlI[4])) {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findStaticGetter(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIlllI);
            "".length();
            if ("   ".length() <= 0)
              return null; 
          } else if (llllIIllIIIIlII(lllllllllllllllIllllIllIlIIIlIIl, lIllIlIIllIIlI[5])) {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findSetter(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIlllI);
            "".length();
            if (" ".length() > " ".length())
              return null; 
          } else {
            lllllllllllllllIllllIllIlIIIlIlI = lllllllllllllllIllllIllIlIIIIlll.findStaticSetter(lllllllllllllllIllllIllIlIIIllII, lllllllllllllllIllllIllIlIIIlIll, lllllllllllllllIllllIllIlIIIlllI);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllllIllIlIIIlIlI);
      } catch (Exception lllllllllllllllIllllIllIlIIIlIII) {
        lllllllllllllllIllllIllIlIIIlIII.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIlIlllIlIl() {
      lIllIlIIlIllII = new String[lIllIlIIllIIlI[6]];
      lIllIlIIlIllII[lIllIlIIllIIlI[1]] = lIllIlIIlIlllI[lIllIlIIllIIlI[1]];
      lIllIlIIlIllII[lIllIlIIllIIlI[7]] = lIllIlIIlIlllI[lIllIlIIllIIlI[3]];
      lIllIlIIlIllII[lIllIlIIllIIlI[4]] = lIllIlIIlIlllI[lIllIlIIllIIlI[2]];
      lIllIlIIlIllII[lIllIlIIllIIlI[8]] = lIllIlIIlIlllI[lIllIlIIllIIlI[4]];
      lIllIlIIlIllII[lIllIlIIllIIlI[9]] = lIllIlIIlIlllI[lIllIlIIllIIlI[5]];
      lIllIlIIlIllII[lIllIlIIllIIlI[10]] = lIllIlIIlIlllI[lIllIlIIllIIlI[9]];
      lIllIlIIlIllII[lIllIlIIllIIlI[0]] = lIllIlIIlIlllI[lIllIlIIllIIlI[11]];
      lIllIlIIlIllII[lIllIlIIllIIlI[2]] = lIllIlIIlIlllI[lIllIlIIllIIlI[8]];
      lIllIlIIlIllII[lIllIlIIllIIlI[3]] = lIllIlIIlIlllI[lIllIlIIllIIlI[10]];
      lIllIlIIlIllII[lIllIlIIllIIlI[5]] = lIllIlIIlIlllI[lIllIlIIllIIlI[7]];
      lIllIlIIlIllII[lIllIlIIllIIlI[11]] = lIllIlIIlIlllI[lIllIlIIllIIlI[6]];
      lIllIlIIlIllIl = new Class[lIllIlIIllIIlI[2]];
      lIllIlIIlIllIl[lIllIlIIllIIlI[0]] = ColorComponent.class;
      lIllIlIIlIllIl[lIllIlIIllIIlI[1]] = ColorScheme.class;
      lIllIlIIlIllIl[lIllIlIIllIIlI[3]] = ColorSetting.class;
    }
    
    private static void llllIIlIllllIll() {
      lIllIlIIlIlllI = new String[lIllIlIIllIIlI[12]];
      lIllIlIIlIlllI[lIllIlIIllIIlI[0]] = llllIIlIlllIllI(lIllIlIIllIIIl[lIllIlIIllIIlI[0]], lIllIlIIllIIIl[lIllIlIIllIIlI[1]]);
      lIllIlIIlIlllI[lIllIlIIllIIlI[1]] = llllIIlIlllIllI(lIllIlIIllIIIl[lIllIlIIllIIlI[3]], lIllIlIIllIIIl[lIllIlIIllIIlI[2]]);
      lIllIlIIlIlllI[lIllIlIIllIIlI[3]] = llllIIlIllllIIl(lIllIlIIllIIIl[lIllIlIIllIIlI[4]], lIllIlIIllIIIl[lIllIlIIllIIlI[5]]);
      lIllIlIIlIlllI[lIllIlIIllIIlI[2]] = llllIIlIlllIllI(lIllIlIIllIIIl[lIllIlIIllIIlI[9]], lIllIlIIllIIIl[lIllIlIIllIIlI[11]]);
      lIllIlIIlIlllI[lIllIlIIllIIlI[4]] = llllIIlIlllIllI(lIllIlIIllIIIl[lIllIlIIllIIlI[8]], lIllIlIIllIIIl[lIllIlIIllIIlI[10]]);
      lIllIlIIlIlllI[lIllIlIIllIIlI[5]] = llllIIlIllllIlI("Rj2kZCVEtOwPKqYJ9EBGOYKot62821cCKv5sC5WYDPOwOVa+KSmoXNA2touXW7MjJM6GY6VChQA9JiqfpyKbWRRJr7X6WKYHHW+/BbtXquH5Vedgg9sm7Q==", "txBqs");
      lIllIlIIlIlllI[lIllIlIIllIIlI[9]] = llllIIlIllllIlI("1wnFZ4DD/460UeKsDIiqyjzStKLvlZpBl3lrTvFwEXMBl1/E/FfjfhiYyIxLoBARbJV/7EFsRZ+bKjEjOgzjWgwfc0ymhVSkR4j7h1Di1MM=", "dEEaz");
      lIllIlIIlIlllI[lIllIlIIllIIlI[11]] = llllIIlIllllIlI("wON77kcsBxqTUQ2zyLxML1EUdwkvrc4rCw+EAGdJ4O73WXen48SX9EfHTiMF67fTK+mEqVnOTLxuUM9tBoUluKLMDS7cYDTRKv0Nj4kAQglZwW5SG84t2P043NRBeiqijv3GGakc2rKebL9S2YKfEQ==", "jzGeC");
      lIllIlIIlIlllI[lIllIlIIllIIlI[8]] = llllIIlIlllIllI("3Eu/z50xnijzzFf64b99USyldj+PjsisoU6yZNfoHtTFEXGczHi2K/CuhEOXwOyaXrAeUvdr5MIfA3iFzswSAw==", "FDxqV");
      lIllIlIIlIlllI[lIllIlIIllIIlI[10]] = llllIIlIllllIlI("6WUxhtEf9KEXk5RuDfqAU7SistwPJjK6uV7ddqvgmtsTVQ3VhNvcW4q625X4puzRx7eDIpj6HoA4pmhY0qzm5NF4yUd6xwIqiudR5wz/ffM=", "NRXLa");
      lIllIlIIlIlllI[lIllIlIIllIIlI[7]] = llllIIlIllllIIl("EQApeAAHBCI6GRVBNDcCFwM3IhkWBit4HxcbMD8CFRxqFQMeADYVAx8fKzgJHBtgFQMeADYFCQYbLTgLIQwsMwEXVTc1BBcCIWxdSE9kdg==", "roDVl");
      lIllIlIIlIlllI[lIllIlIIllIIlI[6]] = llllIIlIlllIllI("EnLf+l1jtmyTFCUYAnMcPxKXMrs+INnQlVqxrGL6gmnbF6IMJmtsqLDBk9xeCTPHYunTmuG7S38iAaR2upo+zwBAVzKGgOFF92S5XQXjCh2zVh3h6wLsOQ==", "kodPC");
      lIllIlIIllIIIl = null;
    }
    
    private static void llllIIlIlllllII() {
      String str = (new Exception()).getStackTrace()[lIllIlIIllIIlI[0]].getFileName();
      lIllIlIIllIIIl = str.substring(str.indexOf("ä") + lIllIlIIllIIlI[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String llllIIlIllllIlI(String lllllllllllllllIllllIllIlIIIIIIl, String lllllllllllllllIllllIllIlIIIIIII) {
      try {
        SecretKeySpec lllllllllllllllIllllIllIlIIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIlIIIIIII.getBytes(StandardCharsets.UTF_8)), lIllIlIIllIIlI[8]), "DES");
        Cipher lllllllllllllllIllllIllIlIIIIIll = Cipher.getInstance("DES");
        lllllllllllllllIllllIllIlIIIIIll.init(lIllIlIIllIIlI[3], lllllllllllllllIllllIllIlIIIIlII);
        return new String(lllllllllllllllIllllIllIlIIIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIlIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllllIllIlIIIIIlI) {
        lllllllllllllllIllllIllIlIIIIIlI.printStackTrace();
        return null;
      } 
    }
    
    private static String llllIIlIllllIIl(String lllllllllllllllIllllIllIIllllllI, String lllllllllllllllIllllIllIIlllllIl) {
      lllllllllllllllIllllIllIIllllllI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIllIIllllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllllIllIIlllllII = new StringBuilder();
      char[] lllllllllllllllIllllIllIIllllIll = lllllllllllllllIllllIllIIlllllIl.toCharArray();
      int lllllllllllllllIllllIllIIllllIlI = lIllIlIIllIIlI[0];
      char[] arrayOfChar1 = lllllllllllllllIllllIllIIllllllI.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIllIlIIllIIlI[0];
      while (llllIIllIIIIlIl(j, i)) {
        char lllllllllllllllIllllIllIIlllllll = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllllIllIIllllIlI++;
        j++;
        "".length();
        if (((" ".length() << (0x9F ^ 0x9A) ^ 0x8C ^ 0xA9) << "   ".length() & (((0x85 ^ 0x98) << " ".length() ^ 0x8F ^ 0xB0) << "   ".length() ^ -" ".length())) == " ".length() << " ".length())
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllllIllIIlllllII);
    }
    
    private static String llllIIlIlllIllI(String lllllllllllllllIllllIllIIlllIllI, String lllllllllllllllIllllIllIIlllIlIl) {
      try {
        SecretKeySpec lllllllllllllllIllllIllIIllllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIllIIlllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllllIllIIllllIII = Cipher.getInstance("Blowfish");
        lllllllllllllllIllllIllIIllllIII.init(lIllIlIIllIIlI[3], lllllllllllllllIllllIllIIllllIIl);
        return new String(lllllllllllllllIllllIllIIllllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIllIIlllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllllIllIIlllIlll) {
        lllllllllllllllIllllIllIIlllIlll.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIllIIIIIlI() {
      lIllIlIIllIIlI = new int[13];
      lIllIlIIllIIlI[0] = ((0x65 ^ 0x54) << " ".length() ^ 0xFC ^ 0xAF) << " ".length() & (((0xBD ^ 0xA8) << "   ".length() ^ 56 + 111 - 164 + 150) << " ".length() ^ -" ".length());
      lIllIlIIllIIlI[1] = " ".length();
      lIllIlIIllIIlI[2] = "   ".length();
      lIllIlIIllIIlI[3] = " ".length() << " ".length();
      lIllIlIIllIIlI[4] = " ".length() << " ".length() << " ".length();
      lIllIlIIllIIlI[5] = 0xAB ^ 0xAE;
      lIllIlIIllIIlI[6] = (0x92 ^ 0x81) << " ".length() << " ".length() ^ 0xC4 ^ 0x83;
      lIllIlIIllIIlI[7] = ((0x63 ^ 0x72) << " ".length() ^ 0xE5 ^ 0xC2) << " ".length();
      lIllIlIIllIIlI[8] = " ".length() << "   ".length();
      lIllIlIIllIIlI[9] = "   ".length() << " ".length();
      lIllIlIIllIIlI[10] = 0xCB ^ 0xC2;
      lIllIlIIllIIlI[11] = 0x23 ^ 0x24;
      lIllIlIIllIIlI[12] = "   ".length() << " ".length() << " ".length();
    }
    
    private static boolean llllIIllIIIIlII(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean llllIIllIIIIlIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean llllIIllIIIIIll(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
  }
  
  protected class ColorSlider extends Slider {
    private final int value;
    
    private static String[] llIIIIlIIlllll;
    
    private static Class[] llIIIIlIlIIIII;
    
    private static final String[] llIIIIlIlIllII;
    
    private static String[] llIIIIlIlIllIl;
    
    private static final int[] llIIIIlIlIlllI;
    
    public ColorSlider(Renderer lllllllllllllllIllIllIIlllIllIll, int lllllllllllllllIllIllIIlllIllIlI) {
      super(llIIIIlIlIllII[llIIIIlIlIlllI[0]], null, lllllllllllllllIllIllIIlllIllIll);
      this.value = lllllllllllllllIllIllIIlllIllIlI;
    }
    
    public void render(Context lllllllllllllllIllIllIIlllIllIII) {
      // Byte code:
      //   0: aload_0
      //   1: new java/lang/StringBuilder
      //   4: dup
      //   5: invokespecial <init> : ()V
      //   8: aload_0
      //   9: aload_0
      //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   15: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;I)Ljava/lang/String;
      //   20: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   25: aload_0
      //   26: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   31: i2d
      //   32: aload_0
      //   33: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)D
      //   38: dmul
      //   39: d2i
      //   40: <illegal opcode> 5 : (Ljava/lang/StringBuilder;I)Ljava/lang/StringBuilder;
      //   45: <illegal opcode> 6 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
      //   50: putfield title : Ljava/lang/String;
      //   53: aload_0
      //   54: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   59: aload_0
      //   60: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   65: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   70: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
      //   75: aload_0
      //   76: aload_1
      //   77: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
      //   80: aload_0
      //   81: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   86: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/Renderer;)V
      //   91: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	92	0	lllllllllllllllIllIllIIlllIllIIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;
      //   0	92	1	lllllllllllllllIllIllIIlllIllIII	Lcom/lukflug/panelstudio/Context;
    }
    
    protected double getValue() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   6: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   11: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   16: astore_1
      //   17: aload_0
      //   18: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   23: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   26: iconst_1
      //   27: iaload
      //   28: invokestatic lIIIIIlIlIIlIIIl : (II)Z
      //   31: ifeq -> 156
      //   34: aload_0
      //   35: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   40: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   45: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   50: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   53: ifeq -> 89
      //   56: aload_1
      //   57: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   62: aload_1
      //   63: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   68: aload_1
      //   69: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   74: aconst_null
      //   75: <illegal opcode> 19 : (III[F)[F
      //   80: aload_0
      //   81: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   86: faload
      //   87: f2d
      //   88: dreturn
      //   89: aload_0
      //   90: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   95: tableswitch default -> 156, 0 -> 120, 1 -> 132, 2 -> 144
      //   120: aload_1
      //   121: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   126: i2d
      //   127: ldc2_w 255.0
      //   130: ddiv
      //   131: dreturn
      //   132: aload_1
      //   133: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   138: i2d
      //   139: ldc2_w 255.0
      //   142: ddiv
      //   143: dreturn
      //   144: aload_1
      //   145: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   150: i2d
      //   151: ldc2_w 255.0
      //   154: ddiv
      //   155: dreturn
      //   156: aload_1
      //   157: <illegal opcode> 20 : (Ljava/awt/Color;)I
      //   162: i2d
      //   163: ldc2_w 255.0
      //   166: ddiv
      //   167: dreturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	168	0	lllllllllllllllIllIllIIlllIlIlll	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;
      //   17	151	1	lllllllllllllllIllIllIIlllIlIllI	Ljava/awt/Color;
    }
    
    protected void setValue(double lllllllllllllllIllIllIIlllIlIlII) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   6: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   11: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   16: astore_3
      //   17: aload_3
      //   18: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   23: aload_3
      //   24: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   29: aload_3
      //   30: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   35: aconst_null
      //   36: <illegal opcode> 19 : (III[F)[F
      //   41: astore #4
      //   43: aload_0
      //   44: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   49: tableswitch default -> 831, 0 -> 80, 1 -> 305, 2 -> 559, 3 -> 784
      //   80: aload_0
      //   81: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   86: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   91: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   96: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   99: ifeq -> 161
      //   102: dload_1
      //   103: d2f
      //   104: aload #4
      //   106: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   109: iconst_2
      //   110: iaload
      //   111: faload
      //   112: aload #4
      //   114: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   117: iconst_3
      //   118: iaload
      //   119: faload
      //   120: <illegal opcode> 21 : (FFF)Ljava/awt/Color;
      //   125: astore_3
      //   126: ldc ''
      //   128: invokevirtual length : ()I
      //   131: pop
      //   132: bipush #99
      //   134: bipush #102
      //   136: ixor
      //   137: ldc '   '
      //   139: invokevirtual length : ()I
      //   142: ishl
      //   143: bipush #117
      //   145: bipush #112
      //   147: ixor
      //   148: ldc '   '
      //   150: invokevirtual length : ()I
      //   153: ishl
      //   154: iconst_m1
      //   155: ixor
      //   156: iand
      //   157: ifge -> 187
      //   160: return
      //   161: new java/awt/Color
      //   164: dup
      //   165: ldc2_w 255.0
      //   168: dload_1
      //   169: dmul
      //   170: d2i
      //   171: aload_3
      //   172: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   177: aload_3
      //   178: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   183: invokespecial <init> : (III)V
      //   186: astore_3
      //   187: aload_0
      //   188: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   193: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Z
      //   198: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   201: ifeq -> 277
      //   204: aload_0
      //   205: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   210: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   215: new java/awt/Color
      //   218: dup
      //   219: aload_3
      //   220: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   225: aload_3
      //   226: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   231: aload_3
      //   232: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   237: aload_0
      //   238: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   243: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   248: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   253: <illegal opcode> 20 : (Ljava/awt/Color;)I
      //   258: invokespecial <init> : (IIII)V
      //   261: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   266: ldc ''
      //   268: invokevirtual length : ()I
      //   271: pop
      //   272: aconst_null
      //   273: ifnull -> 831
      //   276: return
      //   277: aload_0
      //   278: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   283: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   288: aload_3
      //   289: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   294: ldc ''
      //   296: invokevirtual length : ()I
      //   299: pop
      //   300: aconst_null
      //   301: ifnull -> 831
      //   304: return
      //   305: aload_0
      //   306: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   311: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   316: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   321: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   324: ifeq -> 371
      //   327: aload #4
      //   329: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   332: iconst_0
      //   333: iaload
      //   334: faload
      //   335: dload_1
      //   336: d2f
      //   337: aload #4
      //   339: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   342: iconst_3
      //   343: iaload
      //   344: faload
      //   345: <illegal opcode> 21 : (FFF)Ljava/awt/Color;
      //   350: astore_3
      //   351: ldc ''
      //   353: invokevirtual length : ()I
      //   356: pop
      //   357: ldc ' '
      //   359: invokevirtual length : ()I
      //   362: ldc ' '
      //   364: invokevirtual length : ()I
      //   367: if_icmple -> 397
      //   370: return
      //   371: new java/awt/Color
      //   374: dup
      //   375: aload_3
      //   376: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   381: ldc2_w 255.0
      //   384: dload_1
      //   385: dmul
      //   386: d2i
      //   387: aload_3
      //   388: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   393: invokespecial <init> : (III)V
      //   396: astore_3
      //   397: aload_0
      //   398: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   403: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Z
      //   408: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   411: ifeq -> 508
      //   414: aload_0
      //   415: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   420: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   425: new java/awt/Color
      //   428: dup
      //   429: aload_3
      //   430: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   435: aload_3
      //   436: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   441: aload_3
      //   442: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   447: aload_0
      //   448: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   453: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   458: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   463: <illegal opcode> 20 : (Ljava/awt/Color;)I
      //   468: invokespecial <init> : (IIII)V
      //   471: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   476: ldc ''
      //   478: invokevirtual length : ()I
      //   481: pop
      //   482: ldc ' '
      //   484: invokevirtual length : ()I
      //   487: ldc ' '
      //   489: invokevirtual length : ()I
      //   492: ldc ' '
      //   494: invokevirtual length : ()I
      //   497: ldc ' '
      //   499: invokevirtual length : ()I
      //   502: ishl
      //   503: ishl
      //   504: if_icmplt -> 831
      //   507: return
      //   508: aload_0
      //   509: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   514: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   519: aload_3
      //   520: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   525: ldc ''
      //   527: invokevirtual length : ()I
      //   530: pop
      //   531: bipush #76
      //   533: bipush #95
      //   535: ixor
      //   536: bipush #100
      //   538: bipush #119
      //   540: ixor
      //   541: iconst_m1
      //   542: ixor
      //   543: iand
      //   544: ldc ' '
      //   546: invokevirtual length : ()I
      //   549: ldc ' '
      //   551: invokevirtual length : ()I
      //   554: ishl
      //   555: if_icmplt -> 831
      //   558: return
      //   559: aload_0
      //   560: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   565: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   570: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   575: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   578: ifeq -> 625
      //   581: aload #4
      //   583: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   586: iconst_0
      //   587: iaload
      //   588: faload
      //   589: aload #4
      //   591: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   594: iconst_2
      //   595: iaload
      //   596: faload
      //   597: dload_1
      //   598: d2f
      //   599: <illegal opcode> 21 : (FFF)Ljava/awt/Color;
      //   604: astore_3
      //   605: ldc ''
      //   607: invokevirtual length : ()I
      //   610: pop
      //   611: ldc ' '
      //   613: invokevirtual length : ()I
      //   616: ldc ' '
      //   618: invokevirtual length : ()I
      //   621: if_icmple -> 651
      //   624: return
      //   625: new java/awt/Color
      //   628: dup
      //   629: aload_3
      //   630: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   635: aload_3
      //   636: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   641: ldc2_w 255.0
      //   644: dload_1
      //   645: dmul
      //   646: d2i
      //   647: invokespecial <init> : (III)V
      //   650: astore_3
      //   651: aload_0
      //   652: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   657: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Z
      //   662: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   665: ifeq -> 745
      //   668: aload_0
      //   669: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   674: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   679: new java/awt/Color
      //   682: dup
      //   683: aload_3
      //   684: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   689: aload_3
      //   690: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   695: aload_3
      //   696: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   701: aload_0
      //   702: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   707: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   712: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
      //   717: <illegal opcode> 20 : (Ljava/awt/Color;)I
      //   722: invokespecial <init> : (IIII)V
      //   725: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   730: ldc ''
      //   732: invokevirtual length : ()I
      //   735: pop
      //   736: ldc ' '
      //   738: invokevirtual length : ()I
      //   741: ifne -> 831
      //   744: return
      //   745: aload_0
      //   746: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   751: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   756: aload_3
      //   757: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   762: ldc ''
      //   764: invokevirtual length : ()I
      //   767: pop
      //   768: ldc ' '
      //   770: invokevirtual length : ()I
      //   773: ineg
      //   774: ldc ' '
      //   776: invokevirtual length : ()I
      //   779: ineg
      //   780: if_icmpeq -> 831
      //   783: return
      //   784: aload_0
      //   785: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   790: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   795: new java/awt/Color
      //   798: dup
      //   799: aload_3
      //   800: <illegal opcode> 16 : (Ljava/awt/Color;)I
      //   805: aload_3
      //   806: <illegal opcode> 17 : (Ljava/awt/Color;)I
      //   811: aload_3
      //   812: <illegal opcode> 18 : (Ljava/awt/Color;)I
      //   817: ldc2_w 255.0
      //   820: dload_1
      //   821: dmul
      //   822: d2i
      //   823: invokespecial <init> : (IIII)V
      //   826: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Ljava/awt/Color;)V
      //   831: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	832	0	lllllllllllllllIllIllIIlllIlIlIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;
      //   0	832	1	lllllllllllllllIllIllIIlllIlIlII	D
      //   17	815	3	lllllllllllllllIllIllIIlllIlIIll	Ljava/awt/Color;
      //   43	789	4	lllllllllllllllIllIllIIlllIlIIlI	[F
    }
    
    protected String getTitle(int lllllllllllllllIllIllIIlllIlIIII) {
      // Byte code:
      //   0: iload_1
      //   1: tableswitch default -> 367, 0 -> 32, 1 -> 155, 2 -> 245, 3 -> 356
      //   32: new java/lang/StringBuilder
      //   35: dup
      //   36: invokespecial <init> : ()V
      //   39: aload_0
      //   40: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   45: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   50: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   55: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   58: ifeq -> 121
      //   61: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   64: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   67: iconst_2
      //   68: iaload
      //   69: aaload
      //   70: ldc ''
      //   72: invokevirtual length : ()I
      //   75: pop
      //   76: ldc ' '
      //   78: invokevirtual length : ()I
      //   81: ldc ' '
      //   83: invokevirtual length : ()I
      //   86: ishl
      //   87: sipush #189
      //   90: sipush #182
      //   93: ixor
      //   94: ldc '   '
      //   96: invokevirtual length : ()I
      //   99: ishl
      //   100: sipush #146
      //   103: sipush #153
      //   106: ixor
      //   107: ldc '   '
      //   109: invokevirtual length : ()I
      //   112: ishl
      //   113: iconst_m1
      //   114: ixor
      //   115: iand
      //   116: if_icmpge -> 130
      //   119: aconst_null
      //   120: areturn
      //   121: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   124: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   127: iconst_3
      //   128: iaload
      //   129: aaload
      //   130: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   135: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   138: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   141: iconst_1
      //   142: iaload
      //   143: aaload
      //   144: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   149: <illegal opcode> 6 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
      //   154: areturn
      //   155: new java/lang/StringBuilder
      //   158: dup
      //   159: invokespecial <init> : ()V
      //   162: aload_0
      //   163: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   168: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   173: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   178: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   181: ifeq -> 210
      //   184: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   187: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   190: iconst_4
      //   191: iaload
      //   192: aaload
      //   193: ldc ''
      //   195: invokevirtual length : ()I
      //   198: pop
      //   199: ldc '  '
      //   201: invokevirtual length : ()I
      //   204: ineg
      //   205: iflt -> 219
      //   208: aconst_null
      //   209: areturn
      //   210: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   213: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   216: iconst_5
      //   217: iaload
      //   218: aaload
      //   219: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   224: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   227: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   230: bipush #6
      //   232: iaload
      //   233: aaload
      //   234: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   239: <illegal opcode> 6 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
      //   244: areturn
      //   245: new java/lang/StringBuilder
      //   248: dup
      //   249: invokespecial <init> : ()V
      //   252: aload_0
      //   253: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   258: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   263: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   268: invokestatic lIIIIIlIlIIlIIlI : (I)Z
      //   271: ifeq -> 320
      //   274: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   277: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   280: bipush #7
      //   282: iaload
      //   283: aaload
      //   284: ldc ''
      //   286: invokevirtual length : ()I
      //   289: pop
      //   290: ldc ' '
      //   292: invokevirtual length : ()I
      //   295: ldc '   '
      //   297: invokevirtual length : ()I
      //   300: ishl
      //   301: ldc ' '
      //   303: invokevirtual length : ()I
      //   306: ldc '   '
      //   308: invokevirtual length : ()I
      //   311: ishl
      //   312: iconst_m1
      //   313: ixor
      //   314: iand
      //   315: ifeq -> 330
      //   318: aconst_null
      //   319: areturn
      //   320: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   323: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   326: bipush #8
      //   328: iaload
      //   329: aaload
      //   330: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   335: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   338: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   341: bipush #9
      //   343: iaload
      //   344: aaload
      //   345: <illegal opcode> 2 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   350: <illegal opcode> 6 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
      //   355: areturn
      //   356: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   359: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   362: bipush #10
      //   364: iaload
      //   365: aaload
      //   366: areturn
      //   367: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIllII : [Ljava/lang/String;
      //   370: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   373: bipush #11
      //   375: iaload
      //   376: aaload
      //   377: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	378	0	lllllllllllllllIllIllIIlllIlIIIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;
      //   0	378	1	lllllllllllllllIllIllIIlllIlIIII	I
    }
    
    protected int getMax() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   6: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   11: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   16: invokestatic lIIIIIlIlIIlIIll : (I)Z
      //   19: ifeq -> 29
      //   22: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   25: bipush #12
      //   27: iaload
      //   28: ireturn
      //   29: aload_0
      //   30: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   35: invokestatic lIIIIIlIlIIlIIll : (I)Z
      //   38: ifeq -> 48
      //   41: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   44: bipush #13
      //   46: iaload
      //   47: ireturn
      //   48: aload_0
      //   49: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;)I
      //   54: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   57: iconst_1
      //   58: iaload
      //   59: invokestatic lIIIIIlIlIIlIIIl : (II)Z
      //   62: ifeq -> 72
      //   65: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   68: bipush #14
      //   70: iaload
      //   71: ireturn
      //   72: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorSlider.llIIIIlIlIlllI : [I
      //   75: bipush #12
      //   77: iaload
      //   78: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	79	0	lllllllllllllllIllIllIIlllIIllll	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorSlider;
    }
    
    static {
      lIIIIIlIlIIlIIII();
      lIIIIIlIlIIIllll();
      lIIIIIlIlIIIlllI();
      lIIIIIlIlIIIlIlI();
    }
    
    private static CallSite lIIIIIlIIllllIlI(MethodHandles.Lookup lllllllllllllllIllIllIIlllIIIllI, String lllllllllllllllIllIllIIlllIIIlIl, MethodType lllllllllllllllIllIllIIlllIIIlII) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllIllIIlllIIllII = llIIIIlIIlllll[Integer.parseInt(lllllllllllllllIllIllIIlllIIIlIl)].split(llIIIIlIlIllII[llIIIIlIlIlllI[15]]);
        Class<?> lllllllllllllllIllIllIIlllIIlIll = Class.forName(lllllllllllllllIllIllIIlllIIllII[llIIIIlIlIlllI[0]]);
        String lllllllllllllllIllIllIIlllIIlIlI = lllllllllllllllIllIllIIlllIIllII[llIIIIlIlIlllI[2]];
        MethodHandle lllllllllllllllIllIllIIlllIIlIIl = null;
        int lllllllllllllllIllIllIIlllIIlIII = lllllllllllllllIllIllIIlllIIllII[llIIIIlIlIlllI[1]].length();
        if (lIIIIIlIlIIlIlII(lllllllllllllllIllIllIIlllIIlIII, llIIIIlIlIlllI[3])) {
          MethodType lllllllllllllllIllIllIIlllIIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIIlllIIllII[llIIIIlIlIlllI[3]], ColorSlider.class.getClassLoader());
          if (lIIIIIlIlIIlIlIl(lllllllllllllllIllIllIIlllIIlIII, llIIIIlIlIlllI[3])) {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findVirtual(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIlllI);
            "".length();
            if (-" ".length() >= " ".length())
              return null; 
          } else {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findStatic(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIlllI);
          } 
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIllIllIIlllIIllIl = llIIIIlIlIIIII[Integer.parseInt(lllllllllllllllIllIllIIlllIIllII[llIIIIlIlIlllI[3]])];
          if (lIIIIIlIlIIlIlIl(lllllllllllllllIllIllIIlllIIlIII, llIIIIlIlIlllI[1])) {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findGetter(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIllIl);
            "".length();
            if (-((0x13 ^ 0x8) << " ".length() << " ".length() ^ (0x62 ^ 0x6F) << "   ".length()) >= 0)
              return null; 
          } else if (lIIIIIlIlIIlIlIl(lllllllllllllllIllIllIIlllIIlIII, llIIIIlIlIlllI[4])) {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findStaticGetter(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIllIl);
            "".length();
            if (" ".length() << " ".length() << " ".length() < 0)
              return null; 
          } else if (lIIIIIlIlIIlIlIl(lllllllllllllllIllIllIIlllIIlIII, llIIIIlIlIlllI[5])) {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findSetter(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIllIl);
            "".length();
            if (((0x10 ^ 0x37) << " ".length() & ((0x22 ^ 0x5) << " ".length() ^ 0xFFFFFFFF)) >= "   ".length())
              return null; 
          } else {
            lllllllllllllllIllIllIIlllIIlIIl = lllllllllllllllIllIllIIlllIIIllI.findStaticSetter(lllllllllllllllIllIllIIlllIIlIll, lllllllllllllllIllIllIIlllIIlIlI, lllllllllllllllIllIllIIlllIIllIl);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllIllIIlllIIlIIl);
      } catch (Exception lllllllllllllllIllIllIIlllIIIlll) {
        lllllllllllllllIllIllIIlllIIIlll.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIIlIlIIIlIlI() {
      llIIIIlIIlllll = new String[llIIIIlIlIlllI[16]];
      llIIIIlIIlllll[llIIIIlIlIlllI[4]] = llIIIIlIlIllII[llIIIIlIlIlllI[17]];
      llIIIIlIIlllll[llIIIIlIlIlllI[18]] = llIIIIlIlIllII[llIIIIlIlIlllI[19]];
      llIIIIlIIlllll[llIIIIlIlIlllI[5]] = llIIIIlIlIllII[llIIIIlIlIlllI[18]];
      llIIIIlIIlllll[llIIIIlIlIlllI[20]] = llIIIIlIlIllII[llIIIIlIlIlllI[21]];
      llIIIIlIIlllll[llIIIIlIlIlllI[0]] = llIIIIlIlIllII[llIIIIlIlIlllI[22]];
      llIIIIlIIlllll[llIIIIlIlIlllI[23]] = llIIIIlIlIllII[llIIIIlIlIlllI[24]];
      llIIIIlIIlllll[llIIIIlIlIlllI[25]] = llIIIIlIlIllII[llIIIIlIlIlllI[20]];
      llIIIIlIIlllll[llIIIIlIlIlllI[22]] = llIIIIlIlIllII[llIIIIlIlIlllI[25]];
      llIIIIlIIlllll[llIIIIlIlIlllI[10]] = llIIIIlIlIllII[llIIIIlIlIlllI[26]];
      llIIIIlIIlllll[llIIIIlIlIlllI[19]] = llIIIIlIlIllII[llIIIIlIlIlllI[23]];
      llIIIIlIIlllll[llIIIIlIlIlllI[6]] = llIIIIlIlIllII[llIIIIlIlIlllI[27]];
      llIIIIlIIlllll[llIIIIlIlIlllI[8]] = llIIIIlIlIllII[llIIIIlIlIlllI[16]];
      llIIIIlIIlllll[llIIIIlIlIlllI[2]] = llIIIIlIlIllII[llIIIIlIlIlllI[28]];
      llIIIIlIIlllll[llIIIIlIlIlllI[7]] = llIIIIlIlIllII[llIIIIlIlIlllI[29]];
      llIIIIlIIlllll[llIIIIlIlIlllI[11]] = llIIIIlIlIllII[llIIIIlIlIlllI[30]];
      llIIIIlIIlllll[llIIIIlIlIlllI[1]] = llIIIIlIlIllII[llIIIIlIlIlllI[31]];
      llIIIIlIIlllll[llIIIIlIlIlllI[24]] = llIIIIlIlIllII[llIIIIlIlIlllI[32]];
      llIIIIlIIlllll[llIIIIlIlIlllI[3]] = llIIIIlIlIllII[llIIIIlIlIlllI[33]];
      llIIIIlIIlllll[llIIIIlIlIlllI[21]] = llIIIIlIlIllII[llIIIIlIlIlllI[34]];
      llIIIIlIIlllll[llIIIIlIlIlllI[9]] = llIIIIlIlIllII[llIIIIlIlIlllI[35]];
      llIIIIlIIlllll[llIIIIlIlIlllI[27]] = llIIIIlIlIllII[llIIIIlIlIlllI[36]];
      llIIIIlIIlllll[llIIIIlIlIlllI[26]] = llIIIIlIlIllII[llIIIIlIlIlllI[37]];
      llIIIIlIIlllll[llIIIIlIlIlllI[17]] = llIIIIlIlIllII[llIIIIlIlIlllI[38]];
      llIIIIlIIlllll[llIIIIlIlIlllI[15]] = llIIIIlIlIllII[llIIIIlIlIlllI[39]];
      llIIIIlIlIIIII = new Class[llIIIIlIlIlllI[8]];
      llIIIIlIlIIIII[llIIIIlIlIlllI[7]] = boolean.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[3]] = String.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[6]] = Toggleable.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[2]] = int.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[0]] = ColorComponent.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[5]] = ColorSetting.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[1]] = Renderer.class;
      llIIIIlIlIIIII[llIIIIlIlIlllI[4]] = ColorScheme.class;
    }
    
    private static void lIIIIIlIlIIIlllI() {
      llIIIIlIlIllII = new String[llIIIIlIlIlllI[40]];
      llIIIIlIlIllII[llIIIIlIlIlllI[0]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[0]], llIIIIlIlIllIl[llIIIIlIlIlllI[2]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[2]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[3]], llIIIIlIlIllIl[llIIIIlIlIlllI[1]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[3]] = lIIIIIlIlIIIllII(llIIIIlIlIllIl[llIIIIlIlIlllI[4]], llIIIIlIlIllIl[llIIIIlIlIlllI[5]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[1]] = lIIIIIlIlIIIllII(llIIIIlIlIllIl[llIIIIlIlIlllI[6]], llIIIIlIlIllIl[llIIIIlIlIlllI[7]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[4]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[8]], llIIIIlIlIllIl[llIIIIlIlIlllI[9]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[5]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[10]], llIIIIlIlIllIl[llIIIIlIlIlllI[11]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[6]] = lIIIIIlIlIIIllII(llIIIIlIlIllIl[llIIIIlIlIlllI[15]], llIIIIlIlIllIl[llIIIIlIlIlllI[17]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[7]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[19]], llIIIIlIlIllIl[llIIIIlIlIlllI[18]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[8]] = lIIIIIlIlIIIllIl(llIIIIlIlIllIl[llIIIIlIlIlllI[21]], llIIIIlIlIllIl[llIIIIlIlIlllI[22]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[9]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[24]], llIIIIlIlIllIl[llIIIIlIlIlllI[20]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[10]] = lIIIIIlIlIIIllII(llIIIIlIlIllIl[llIIIIlIlIlllI[25]], llIIIIlIlIllIl[llIIIIlIlIlllI[26]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[11]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[23]], llIIIIlIlIllIl[llIIIIlIlIlllI[27]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[15]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[16]], llIIIIlIlIllIl[llIIIIlIlIlllI[28]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[17]] = lIIIIIlIlIIIlIll(llIIIIlIlIllIl[llIIIIlIlIlllI[29]], llIIIIlIlIllIl[llIIIIlIlIlllI[30]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[19]] = lIIIIIlIlIIIllIl(llIIIIlIlIllIl[llIIIIlIlIlllI[31]], llIIIIlIlIllIl[llIIIIlIlIlllI[32]]);
      llIIIIlIlIllII[llIIIIlIlIlllI[18]] = lIIIIIlIlIIIllII("IBEXLkEmEQ8oQRkEEyYBLTIUJgMuFRN1DjoABCELcFgoZiMgERcuQCYRDyhAGQQTJgEtMhQmAy4VE3RValA=", "JpaOo");
      llIIIIlIlIllII[llIIIIlIlIlllI[21]] = lIIIIIlIlIIIlIll("S4kCboTOa58Oy0GzC4rgtdg+y8y7Y0bOhxnIF1vlbFOUmOUcDwtlyw==", "ZNDoF");
      llIIIIlIlIllII[llIIIIlIlIlllI[22]] = lIIIIIlIlIIIlIll("J1NUMG1VFdT7JQt8QWoNC2CNsN5Jom0laaA9Sx3WAbpNMkIkTGU+NfLKPuupuA3ExUMU+UZ+sbosIsxbM2svzgy7/dIqyLOf", "AWNao");
      llIIIIlIlIllII[llIIIIlIlIlllI[24]] = lIIIIIlIlIIIllIl("9J01j9onSdP4tet3vRgSRVf+MVMjTwlXrMABThB8fmcfUPgEpfYWIR2TbID2vR8GnQtX5Q/hco3fBDT5PIEs1w==", "YvrUd");
      llIIIIlIlIllII[llIIIIlIlIlllI[20]] = lIIIIIlIlIIIlIll("VsYTJN/cXZIfdyS8dxaGQdbcBVgdxm6namUq6WgS4HE=", "XTHnH");
      llIIIIlIlIllII[llIIIIlIlIlllI[25]] = lIIIIIlIlIIIlIll("ZrFmSPosCnWiTOZmP4H/e+03nXgcUDgqyRhRP0RwMQg=", "wokrO");
      llIIIIlIlIllII[llIIIIlIlIlllI[26]] = lIIIIIlIlIIIllIl("URv5WCHizXazyxL1g20UQxQqafwvXkhVq8Mh3tyN2oZddNGYgSKRYrJewMGoxuKfOK+A2oIIoISFWNkq1ArLv0+6+/nfUVy5svMelY3lSa855Ou8mYTUkfM4UzaluJLm7YUIZM7JUXgrGXfQd2uPSA==", "PONuW");
      llIIIIlIlIllII[llIIIIlIlIlllI[23]] = lIIIIIlIlIIIllII("EhcLSwQEEwAJHRZWFgQGFBQVER0VEQlLGxQMEgwGFgtIJgcdFxQmBxwICQsNHwxcBgcdFxQoBxUdCl9eS1hGRQ==", "qxfeh");
      llIIIIlIlIllII[llIIIIlIlIlllI[27]] = lIIIIIlIlIIIllII("PwQCD345BBoJfgYRBgc+MicBBzwxAAZUJDo2ABw5OwJORnkZDxUYMXoJFQA3ejYAHDk7Ak9UcHU=", "UetnP");
      llIIIIlIlIllII[llIIIIlIlIlllI[16]] = lIIIIIlIlIIIlIll("a1JUOLkj7TKKfmZMYzUDUk2eV8WZu6ufHqtQYYhVXEXYznSziN3wBABOnXXWANuVJCCBN3SHMdj3ihV6Dn+OsSd/FHujK1T3t90/Fi9S7Gk=", "iSGFK");
      llIIIIlIlIllII[llIIIIlIlIlllI[28]] = lIIIIIlIlIIIllIl("sCDseASz9qfkySDlh95iRgmymNCzuQXXrq4rIkbSwzXn7xjNieElyTXUg4j8q7Fp2nQ9oo3AOLCVEpvLJ6jDNIC04Iy9iGcZLqiABsojIduGg0hCQHVsQkQJZ6AkvVXE", "YUdUG");
      llIIIIlIlIllII[llIIIIlIlIlllI[29]] = lIIIIIlIlIIIllII("KQMaWAo/BxEaEy1CBxcILwAEAhMuBRhYFS8YAx8ILR9ZNQkmAwU1CSccGBgDJBhTNQkmAwUlCiMIEgRcOAkZEgM4CQVMVXBMV1Y=", "Jlwvf");
      llIIIIlIlIllII[llIIIIlIlIlllI[30]] = lIIIIIlIlIIIllII("Bxo6dA8RHjE2FgNbJzsNARkkLhYAHDh0FwwQOj9NNhA5PgYWECVgEQEGIzURATY4NgwWJjQyBgkQbXJKMk93eg==", "duWZc");
      llIIIIlIlIllII[llIIIIlIlIlllI[31]] = lIIIIIlIlIIIllIl("t3/iibVe4qmArExsfJnT1k577w8TC0SM7jxgwz6G9q/DsNaOLBGZJluWk9VV+xPgwMJNnwcS2HWbS1H6YFD43gMB8wxPIWWKhDSkcsPa0VA=", "pmLyT");
      llIIIIlIlIllII[llIIIIlIlIlllI[32]] = lIIIIIlIlIIIlIll("YO+F5K5OeVcK2hYJPrSw+1LHiz/yRpTDqsxeLWIhv2w=", "xsOqz");
      llIIIIlIlIllII[llIIIIlIlIlllI[33]] = lIIIIIlIlIIIlIll("kgnnK+apZwg9hJhleHNhvuHQxZsqHYegwqJtQUO9rY0L/pxZEIJttL6pQOECu7XDGjHcrTahUwNtt8AJ6d6UrPCT/RAL9fnKA4o2wezUV6E=", "efZGv");
      llIIIIlIlIllII[llIIIIlIlIlllI[34]] = lIIIIIlIlIIIlIll("HYR36wOQ8QwI1uw3XB+KDltipj7kWFJ2yCXGXs/vpMA=", "fNgoH");
      llIIIIlIlIllII[llIIIIlIlIlllI[35]] = lIIIIIlIlIIIllII("CAshWz0eDyoZJAxKPBQ/Dgg/ASQPDSNbIg4QOBw/DBdiNj4HCz42PgYUIxs0BRB2GicOFj4cNQ43Lx00BgF2QWtLRGw=", "kdLuQ");
      llIIIIlIlIllII[llIIIIlIlIlllI[36]] = lIIIIIlIlIIIllII("MiAoXwgkJCMdETZhNRAKNCM2BRE1JipfFzQ7MRgKNjxrMgs9IDciASU7LB8DazwgBTIwIzAUXnkDLxASMGAkBhB+DCodCyN0bCdecW8=", "QOEqd");
      llIIIIlIlIllII[llIIIIlIlIlllI[37]] = lIIIIIlIlIIIllIl("Kl9M/iDMUn9Xye7EmlUOAVhnbxCwhCT/UiN3n+xmApivfLaisCfX0CgHsZD7P2f8IrBUZfCvkxY=", "kShBp");
      llIIIIlIlIllII[llIIIIlIlIlllI[38]] = lIIIIIlIlIIIllII("NRcvXiojEyQcMzFWMhEoMxQxBDMyES1eNTMMNhkoMQtsMyk6FzAjIyIMKx4hbB8nBAU5FC0CfH5RDhonIBltETEiVwEfKjkKeUpmdg==", "VxBpF");
      llIIIIlIlIllII[llIIIIlIlIlllI[39]] = lIIIIIlIlIIIllII("NjYYQhogMhMAAzJ3BQ0YMDUGGAMxMBpCBTAtAQUYMipbLxk5NgcvGTgpGgITOy1PHxMhLRwCEW9sT0xWdQ==", "UYulv");
      llIIIIlIlIllIl = null;
    }
    
    private static void lIIIIIlIlIIIllll() {
      String str = (new Exception()).getStackTrace()[llIIIIlIlIlllI[0]].getFileName();
      llIIIIlIlIllIl = str.substring(str.indexOf("ä") + llIIIIlIlIlllI[2], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lIIIIIlIlIIIlIll(String lllllllllllllllIllIllIIlllIIIIII, String lllllllllllllllIllIllIIllIllllll) {
      try {
        SecretKeySpec lllllllllllllllIllIllIIlllIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIllIllllll.getBytes(StandardCharsets.UTF_8)), llIIIIlIlIlllI[8]), "DES");
        Cipher lllllllllllllllIllIllIIlllIIIIlI = Cipher.getInstance("DES");
        lllllllllllllllIllIllIIlllIIIIlI.init(llIIIIlIlIlllI[3], lllllllllllllllIllIllIIlllIIIIll);
        return new String(lllllllllllllllIllIllIIlllIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIlllIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIllIIlllIIIIIl) {
        lllllllllllllllIllIllIIlllIIIIIl.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIIlIlIIIllIl(String lllllllllllllllIllIllIIllIlllIll, String lllllllllllllllIllIllIIllIlllIlI) {
      try {
        SecretKeySpec lllllllllllllllIllIllIIllIlllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIllIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIllIIllIllllIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIllIIllIllllIl.init(llIIIIlIlIlllI[3], lllllllllllllllIllIllIIllIlllllI);
        return new String(lllllllllllllllIllIllIIllIllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIllIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIllIIllIllllII) {
        lllllllllllllllIllIllIIllIllllII.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIIlIlIIIllII(String lllllllllllllllIllIllIIllIlllIII, String lllllllllllllllIllIllIIllIllIlll) {
      lllllllllllllllIllIllIIllIlllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIllIlllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIllIIllIllIllI = new StringBuilder();
      char[] lllllllllllllllIllIllIIllIllIlIl = lllllllllllllllIllIllIIllIllIlll.toCharArray();
      int lllllllllllllllIllIllIIllIllIlII = llIIIIlIlIlllI[0];
      char[] arrayOfChar1 = lllllllllllllllIllIllIIllIlllIII.toCharArray();
      int i = arrayOfChar1.length;
      int j = llIIIIlIlIlllI[0];
      while (lIIIIIlIlIIlIIIl(j, i)) {
        char lllllllllllllllIllIllIIllIlllIIl = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllIllIIllIllIlII++;
        j++;
        "".length();
        if (" ".length() << " ".length() << " ".length() == 0)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllIllIIllIllIllI);
    }
    
    private static void lIIIIIlIlIIlIIII() {
      llIIIIlIlIlllI = new int[41];
      llIIIIlIlIlllI[0] = ((0xC ^ 0x39) << " ".length() ^ 0x6D ^ 0x66) & (0x5F ^ 0x2A ^ (0x48 ^ 0x4D) << " ".length() << " ".length() ^ -" ".length());
      llIIIIlIlIlllI[1] = "   ".length();
      llIIIIlIlIlllI[2] = " ".length();
      llIIIIlIlIlllI[3] = " ".length() << " ".length();
      llIIIIlIlIlllI[4] = " ".length() << " ".length() << " ".length();
      llIIIIlIlIlllI[5] = " ".length() << (0x7 ^ 0x0) ^ 69 + 17 - -45 + 2;
      llIIIIlIlIlllI[6] = "   ".length() << " ".length();
      llIIIIlIlIlllI[7] = (0x1D ^ 0x48) << " ".length() ^ 143 + 60 - 71 + 41;
      llIIIIlIlIlllI[8] = " ".length() << "   ".length();
      llIIIIlIlIlllI[9] = (0x80 ^ 0x9F) << " ".length() ^ 0x41 ^ 0x76;
      llIIIIlIlIlllI[10] = ((0xB3 ^ 0xBA) << " ".length() << " ".length() << " ".length() ^ 98 + 7 - 59 + 103) << " ".length();
      llIIIIlIlIlllI[11] = 123 + 160 - 133 + 11 ^ (0x3B ^ 0x6E) << " ".length();
      llIIIIlIlIlllI[12] = 9 + 213 - 179 + 212;
      llIIIIlIlIlllI[13] = (0x1A ^ 0x37) << "   ".length();
      llIIIIlIlIlllI[14] = (0x1 ^ 0x18) << " ".length() << " ".length();
      llIIIIlIlIlllI[15] = "   ".length() << " ".length() << " ".length();
      llIIIIlIlIlllI[16] = "   ".length() << "   ".length();
      llIIIIlIlIlllI[17] = (0xBF ^ 0xB6) << " ".length() << " ".length() << " ".length() ^ 133 + 68 - 73 + 29;
      llIIIIlIlIlllI[18] = 0x90 ^ 0xA5 ^ (0xA4 ^ 0xB9) << " ".length();
      llIIIIlIlIlllI[19] = (0x6E ^ 0x69) << " ".length();
      llIIIIlIlIlllI[20] = 0xE ^ 0x1D;
      llIIIIlIlIlllI[21] = " ".length() << " ".length() << " ".length() << " ".length();
      llIIIIlIlIlllI[22] = "   ".length() << " ".length() << " ".length() << " ".length() ^ 0xA9 ^ 0x88;
      llIIIIlIlIlllI[23] = (" ".length() << "   ".length() ^ "   ".length()) << " ".length();
      llIIIIlIlIlllI[24] = (0x62 ^ 0x57 ^ (0xE ^ 0x1) << " ".length() << " ".length()) << " ".length();
      llIIIIlIlIlllI[25] = (0xC1 ^ 0x98 ^ (0x38 ^ 0x2F) << " ".length() << " ".length()) << " ".length() << " ".length();
      llIIIIlIlIlllI[26] = 0x69 ^ 0x2E ^ (0x2 ^ 0x2B) << " ".length();
      llIIIIlIlIlllI[27] = 0xE5 ^ 0x86 ^ (0x8D ^ 0x90) << " ".length() << " ".length();
      llIIIIlIlIlllI[28] = 0x77 ^ 0x6E;
      llIIIIlIlIlllI[29] = (0x93 ^ 0x9E) << " ".length();
      llIIIIlIlIlllI[30] = 0x82 ^ 0x99;
      llIIIIlIlIlllI[31] = (0x8B ^ 0xC2 ^ (0xF ^ 0x28) << " ".length()) << " ".length() << " ".length();
      llIIIIlIlIlllI[32] = 0x3C ^ 0x21;
      llIIIIlIlIlllI[33] = (0x34 ^ 0x3B) << " ".length();
      llIIIIlIlIlllI[34] = 0x27 ^ 0x38;
      llIIIIlIlIlllI[35] = " ".length() << (0xB1 ^ 0xB4);
      llIIIIlIlIlllI[36] = 0xAE ^ 0x89 ^ "   ".length() << " ".length();
      llIIIIlIlIlllI[37] = (0x9D ^ 0x8C) << " ".length();
      llIIIIlIlIlllI[38] = 0x18 ^ 0x2F ^ (0x4F ^ 0x4A) << " ".length() << " ".length();
      llIIIIlIlIlllI[39] = (0x9A ^ 0x93) << " ".length() << " ".length();
      llIIIIlIlIlllI[40] = 0x5 ^ 0x20;
    }
    
    private static boolean lIIIIIlIlIIlIlIl(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lIIIIIlIlIIlIIIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lIIIIIlIlIIlIlII(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean lIIIIIlIlIIlIIlI(int param1Int) {
      return (param1Int != 0);
    }
    
    private static boolean lIIIIIlIlIIlIIll(int param1Int) {
      return (param1Int == 0);
    }
  }
  
  protected class ColorButton extends FocusableComponent {
    private static String[] lIlllIlIlIIlll;
    
    private static Class[] lIlllIlIlIlIII;
    
    private static final String[] lIlllIlIlIlllI;
    
    private static String[] lIlllIlIllIIIl;
    
    private static final int[] lIlllIlIllIIlI;
    
    public ColorButton(Renderer lllllllllllllllIlllIlIlIIlIlIlII) {
      super(lIlllIlIlIlllI[lIlllIlIllIIlI[0]], null, lllllllllllllllIlllIlIlIIlIlIlII);
    }
    
    public void render(Context lllllllllllllllIlllIlIlIIlIlIIlI) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
      //   5: aload_0
      //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   11: aload_0
      //   12: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   17: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   22: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
      //   27: aload_0
      //   28: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   33: aload_1
      //   34: aload_0
      //   35: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Ljava/lang/String;
      //   40: aload_0
      //   41: aload_1
      //   42: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;Lcom/lukflug/panelstudio/Context;)Z
      //   47: aload_0
      //   48: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   53: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   58: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Z
      //   63: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
      //   68: aload_0
      //   69: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   74: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/theme/Renderer;)V
      //   79: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	80	0	lllllllllllllllIlllIlIlIIlIlIIll	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;
      //   0	80	1	lllllllllllllllIlllIlIlIIlIlIIlI	Lcom/lukflug/panelstudio/Context;
    }
    
    public void handleButton(Context lllllllllllllllIlllIlIlIIlIlIIII, int lllllllllllllllIlllIlIlIIlIIllll) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: iload_2
      //   3: invokespecial handleButton : (Lcom/lukflug/panelstudio/Context;I)V
      //   6: iload_2
      //   7: invokestatic lllllIlIlIIlIll : (I)Z
      //   10: ifeq -> 100
      //   13: aload_1
      //   14: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Context;)Z
      //   19: invokestatic lllllIlIlIIllII : (I)Z
      //   22: ifeq -> 100
      //   25: aload_0
      //   26: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   31: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   36: aload_0
      //   37: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;)Lcom/lukflug/panelstudio/settings/ColorComponent;
      //   42: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/settings/ColorComponent;)Lcom/lukflug/panelstudio/settings/ColorSetting;
      //   47: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Z
      //   52: invokestatic lllllIlIlIIlIll : (I)Z
      //   55: ifeq -> 90
      //   58: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorButton.lIlllIlIllIIlI : [I
      //   61: iconst_1
      //   62: iaload
      //   63: ldc ''
      //   65: invokevirtual length : ()I
      //   68: pop
      //   69: ldc ' '
      //   71: invokevirtual length : ()I
      //   74: ldc ' '
      //   76: invokevirtual length : ()I
      //   79: ldc ' '
      //   81: invokevirtual length : ()I
      //   84: ishl
      //   85: ishl
      //   86: ifgt -> 95
      //   89: return
      //   90: getstatic com/lukflug/panelstudio/settings/ColorComponent$ColorButton.lIlllIlIllIIlI : [I
      //   93: iconst_0
      //   94: iaload
      //   95: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/settings/ColorSetting;Z)V
      //   100: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	101	0	lllllllllllllllIlllIlIlIIlIlIIIl	Lcom/lukflug/panelstudio/settings/ColorComponent$ColorButton;
      //   0	101	1	lllllllllllllllIlllIlIlIIlIlIIII	Lcom/lukflug/panelstudio/Context;
      //   0	101	2	lllllllllllllllIlllIlIlIIlIIllll	I
    }
    
    static {
      lllllIlIlIIlIlI();
      lllllIlIlIIlIII();
      lllllIlIlIIIlll();
      lllllIlIlIIIIlI();
    }
    
    private static CallSite lllllIlIIllIlIl(MethodHandles.Lookup lllllllllllllllIlllIlIlIIlIIIllI, String lllllllllllllllIlllIlIlIIlIIIlIl, MethodType lllllllllllllllIlllIlIlIIlIIIlII) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIlllIlIlIIlIIllII = lIlllIlIlIIlll[Integer.parseInt(lllllllllllllllIlllIlIlIIlIIIlIl)].split(lIlllIlIlIlllI[lIlllIlIllIIlI[1]]);
        Class<?> lllllllllllllllIlllIlIlIIlIIlIll = Class.forName(lllllllllllllllIlllIlIlIIlIIllII[lIlllIlIllIIlI[0]]);
        String lllllllllllllllIlllIlIlIIlIIlIlI = lllllllllllllllIlllIlIlIIlIIllII[lIlllIlIllIIlI[1]];
        MethodHandle lllllllllllllllIlllIlIlIIlIIlIIl = null;
        int lllllllllllllllIlllIlIlIIlIIlIII = lllllllllllllllIlllIlIlIIlIIllII[lIlllIlIllIIlI[2]].length();
        if (lllllIlIlIIllIl(lllllllllllllllIlllIlIlIIlIIlIII, lIlllIlIllIIlI[3])) {
          MethodType lllllllllllllllIlllIlIlIIlIIlllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIlIIlIIllII[lIlllIlIllIIlI[3]], ColorButton.class.getClassLoader());
          if (lllllIlIlIIlllI(lllllllllllllllIlllIlIlIIlIIlIII, lIlllIlIllIIlI[3])) {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findVirtual(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIlllI);
            "".length();
            if (" ".length() << " ".length() << " ".length() < 0)
              return null; 
          } else {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findStatic(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIlllI);
          } 
          "".length();
          if (" ".length() << " ".length() >= "   ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIlllIlIlIIlIIllIl = lIlllIlIlIlIII[Integer.parseInt(lllllllllllllllIlllIlIlIIlIIllII[lIlllIlIllIIlI[3]])];
          if (lllllIlIlIIlllI(lllllllllllllllIlllIlIlIIlIIlIII, lIlllIlIllIIlI[2])) {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findGetter(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIllIl);
            "".length();
            if (" ".length() << " ".length() != " ".length() << " ".length())
              return null; 
          } else if (lllllIlIlIIlllI(lllllllllllllllIlllIlIlIIlIIlIII, lIlllIlIllIIlI[4])) {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findStaticGetter(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIllIl);
            "".length();
            if (" ".length() != " ".length())
              return null; 
          } else if (lllllIlIlIIlllI(lllllllllllllllIlllIlIlIIlIIlIII, lIlllIlIllIIlI[5])) {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findSetter(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIllIl);
            "".length();
            if ((0x20 ^ 0x25) == 0)
              return null; 
          } else {
            lllllllllllllllIlllIlIlIIlIIlIIl = lllllllllllllllIlllIlIlIIlIIIllI.findStaticSetter(lllllllllllllllIlllIlIlIIlIIlIll, lllllllllllllllIlllIlIlIIlIIlIlI, lllllllllllllllIlllIlIlIIlIIllIl);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIlllIlIlIIlIIlIIl);
      } catch (Exception lllllllllllllllIlllIlIlIIlIIIlll) {
        lllllllllllllllIlllIlIlIIlIIIlll.printStackTrace();
        return null;
      } 
    }
    
    private static void lllllIlIlIIIIlI() {
      lIlllIlIlIIlll = new String[lIlllIlIllIIlI[6]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[7]] = lIlllIlIlIlllI[lIlllIlIllIIlI[3]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[8]] = lIlllIlIlIlllI[lIlllIlIllIIlI[2]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[0]] = lIlllIlIlIlllI[lIlllIlIllIIlI[4]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[9]] = lIlllIlIlIlllI[lIlllIlIllIIlI[5]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[2]] = lIlllIlIlIlllI[lIlllIlIllIIlI[10]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[11]] = lIlllIlIlIlllI[lIlllIlIllIIlI[9]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[10]] = lIlllIlIlIlllI[lIlllIlIllIIlI[7]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[5]] = lIlllIlIlIlllI[lIlllIlIllIIlI[8]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[12]] = lIlllIlIlIlllI[lIlllIlIllIIlI[11]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[3]] = lIlllIlIlIlllI[lIlllIlIllIIlI[12]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[1]] = lIlllIlIlIlllI[lIlllIlIllIIlI[6]];
      lIlllIlIlIIlll[lIlllIlIllIIlI[4]] = lIlllIlIlIlllI[lIlllIlIllIIlI[13]];
      lIlllIlIlIlIII = new Class[lIlllIlIllIIlI[5]];
      lIlllIlIlIlIII[lIlllIlIllIIlI[3]] = ColorScheme.class;
      lIlllIlIlIlIII[lIlllIlIllIIlI[4]] = ColorSetting.class;
      lIlllIlIlIlIII[lIlllIlIllIIlI[0]] = ColorComponent.class;
      lIlllIlIlIlIII[lIlllIlIllIIlI[2]] = String.class;
      lIlllIlIlIlIII[lIlllIlIllIIlI[1]] = Renderer.class;
    }
    
    private static void lllllIlIlIIIlll() {
      lIlllIlIlIlllI = new String[lIlllIlIllIIlI[14]];
      lIlllIlIlIlllI[lIlllIlIllIIlI[0]] = lllllIlIlIIIIll(lIlllIlIllIIIl[lIlllIlIllIIlI[0]], lIlllIlIllIIIl[lIlllIlIllIIlI[1]]);
      lIlllIlIlIlllI[lIlllIlIllIIlI[1]] = lllllIlIlIIIlII(lIlllIlIllIIIl[lIlllIlIllIIlI[3]], lIlllIlIllIIIl[lIlllIlIllIIlI[2]]);
      lIlllIlIlIlllI[lIlllIlIllIIlI[3]] = lllllIlIlIIIlIl(lIlllIlIllIIIl[lIlllIlIllIIlI[4]], lIlllIlIllIIIl[lIlllIlIllIIlI[5]]);
      lIlllIlIlIlllI[lIlllIlIllIIlI[2]] = lllllIlIlIIIlIl(lIlllIlIllIIIl[lIlllIlIllIIlI[10]], lIlllIlIllIIIl[lIlllIlIllIIlI[9]]);
      lIlllIlIlIlllI[lIlllIlIllIIlI[4]] = lllllIlIlIIIlIl(lIlllIlIllIIIl[lIlllIlIllIIlI[7]], lIlllIlIllIIIl[lIlllIlIllIIlI[8]]);
      lIlllIlIlIlllI[lIlllIlIllIIlI[5]] = lllllIlIlIIIlIl("HQCBO48TLeEdW7HEy3SOJGQrqiLli4jaOpIYXTX8FuZE/aM7GbIs0MY2I5ykCzzy3B4SZj/joFmXPbhHjSgp6Q==", "HRMwD");
      lIlllIlIlIlllI[lIlllIlIllIIlI[10]] = lllllIlIlIIIIll("IgQobyM0ACMtOiZFNSAhJAc2NTolAipvOykOKCRhEw4rJSozDjd7IDcONzMmJQ4GLiMuGRYiJyQGIHtnDQgqLGAtHi4nIzQMajEuLw4pMjs0DywuYDUDICwqbigqLSAzOCYpKiwOfmgZe0tl", "AkEAO");
      lIlllIlIlIlllI[lIlllIlIllIIlI[9]] = lllllIlIlIIIlIl("oqik5d1UaoQDkk6aw4vMih/FImOOUQmYvQenIes9nGO0CPlQjkAEbJIbchpoqpVtRIXI7N9DPHM=", "SpGxF");
      lIlllIlIlIlllI[lIlllIlIllIIlI[7]] = lllllIlIlIIIlII("4MbHShQtYNTYRJ/an4mJ2DLwhl7YfDOZFw8nPC127SVnLm2I+GQ+3gSTf9wNKWfIN7nJ80BfNNpAuiQ42yFePg==", "jHGQJ");
      lIlllIlIlIlllI[lIlllIlIllIIlI[8]] = lllllIlIlIIIIll("DCo3XQ4aLjwfFwhrKhIMCikpBxcLLDVdEQoxLhoMCDZ0MA0DKigwDQI1NR0HATF+MA0DKigxFxsxNR1YByQpNQ0MMClJSiMmNR5NAzAxFQ4aInUDAwEgNgAWGiEzHE0sKjQHBxcxYVo4VWV6", "oEZsb");
      lIlllIlIlIlllI[lIlllIlIllIIlI[11]] = lllllIlIlIIIlII("5dKFzhO+BhQoFtP6Y9NpaAbliujFGGQPbHfC9BYTB+2cGWWvNxRD/GEOmGN8H3KU0G/HkIUrTlxDQ9CMA6Dss3dADEF8hljU", "TKISf");
      lIlllIlIlIlllI[lIlllIlIllIIlI[12]] = lllllIlIlIIIlII("Sf93tzJilId36Lk7IfHjgxlvM5lp/2Uzl/QsA+pchmeQlHYBL8HVJxrysO8HNvMCvApRIj+V6JR7vBsMySuP4LIEIvOIVl1L", "LqAsH");
      lIlllIlIlIlllI[lIlllIlIllIIlI[6]] = lllllIlIlIIIlIl("vnQeeBvvGblyeH5JvoZaR1LjjO7RDDvY9WcL0+U9P7pgguqvVIxOXd8QK0PocMloNK0bZHAM4hxMdQUNlLWuowinbB3A/UnJB3rYq+Cp4Ro=", "DEkzl");
      lIlllIlIlIlllI[lIlllIlIllIIlI[13]] = lllllIlIlIIIlIl("Uzev5cdcBeTLni/PoG5htSH6MWrKH3z5pq85T/zV9dRNQAUZsmsR8808xLtVfhf2rr5ZKbbXaEXnXgfV0op3A0o6w/7gVIUc", "WbBpC");
      lIlllIlIllIIIl = null;
    }
    
    private static void lllllIlIlIIlIII() {
      String str = (new Exception()).getStackTrace()[lIlllIlIllIIlI[0]].getFileName();
      lIlllIlIllIIIl = str.substring(str.indexOf("ä") + lIlllIlIllIIlI[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lllllIlIlIIIIll(String lllllllllllllllIlllIlIlIIlIIIIlI, String lllllllllllllllIlllIlIlIIlIIIIIl) {
      lllllllllllllllIlllIlIlIIlIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlllIlIlIIlIIIIII = new StringBuilder();
      char[] lllllllllllllllIlllIlIlIIIllllll = lllllllllllllllIlllIlIlIIlIIIIIl.toCharArray();
      int lllllllllllllllIlllIlIlIIIlllllI = lIlllIlIllIIlI[0];
      char[] arrayOfChar1 = lllllllllllllllIlllIlIlIIlIIIIlI.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIlllIlIllIIlI[0];
      while (lllllIlIlIIllll(j, i)) {
        char lllllllllllllllIlllIlIlIIlIIIIll = arrayOfChar1[j];
        "".length();
        lllllllllllllllIlllIlIlIIIlllllI++;
        j++;
        "".length();
        if (" ".length() << " ".length() << " ".length() <= " ".length())
          return null; 
      } 
      return String.valueOf(lllllllllllllllIlllIlIlIIlIIIIII);
    }
    
    private static String lllllIlIlIIIlIl(String lllllllllllllllIlllIlIlIIIlllIlI, String lllllllllllllllIlllIlIlIIIlllIIl) {
      try {
        SecretKeySpec lllllllllllllllIlllIlIlIIIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIIIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlllIlIlIIIllllII = Cipher.getInstance("Blowfish");
        lllllllllllllllIlllIlIlIIIllllII.init(lIlllIlIllIIlI[3], lllllllllllllllIlllIlIlIIIllllIl);
        return new String(lllllllllllllllIlllIlIlIIIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIlIlIIIlllIll) {
        lllllllllllllllIlllIlIlIIIlllIll.printStackTrace();
        return null;
      } 
    }
    
    private static String lllllIlIlIIIlII(String lllllllllllllllIlllIlIlIIIllIlIl, String lllllllllllllllIlllIlIlIIIllIlII) {
      try {
        SecretKeySpec lllllllllllllllIlllIlIlIIIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIlIIIllIlII.getBytes(StandardCharsets.UTF_8)), lIlllIlIllIIlI[7]), "DES");
        Cipher lllllllllllllllIlllIlIlIIIllIlll = Cipher.getInstance("DES");
        lllllllllllllllIlllIlIlIIIllIlll.init(lIlllIlIllIIlI[3], lllllllllllllllIlllIlIlIIIlllIII);
        return new String(lllllllllllllllIlllIlIlIIIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIlIIIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIlIlIIIllIllI) {
        lllllllllllllllIlllIlIlIIIllIllI.printStackTrace();
        return null;
      } 
    }
    
    private static void lllllIlIlIIlIlI() {
      lIlllIlIllIIlI = new int[15];
      lIlllIlIllIIlI[0] = ((0x53 ^ 0x60) << " ".length() ^ 0x23 ^ 0x66) << " ".length() & ((0xEC ^ 0xAB ^ (0x88 ^ 0x91) << " ".length() << " ".length()) << " ".length() ^ -" ".length());
      lIlllIlIllIIlI[1] = " ".length();
      lIlllIlIllIIlI[2] = "   ".length();
      lIlllIlIllIIlI[3] = " ".length() << " ".length();
      lIlllIlIllIIlI[4] = " ".length() << " ".length() << " ".length();
      lIlllIlIllIIlI[5] = (0xC8 ^ 0xC3) << "   ".length() ^ 0x67 ^ 0x3A;
      lIlllIlIllIIlI[6] = "   ".length() << " ".length() << " ".length();
      lIlllIlIllIIlI[7] = " ".length() << "   ".length();
      lIlllIlIllIIlI[8] = 77 + 160 - 171 + 115 ^ (0x66 ^ 0x49) << " ".length() << " ".length();
      lIlllIlIllIIlI[9] = 0xA4 ^ 0xA3;
      lIlllIlIllIIlI[10] = "   ".length() << " ".length();
      lIlllIlIllIIlI[11] = (0x5B ^ 0x4C ^ (0x6E ^ 0x67) << " ".length()) << " ".length();
      lIlllIlIllIIlI[12] = (0xBA ^ 0xA7) << " ".length() << " ".length() ^ 41 + 15 - -33 + 38;
      lIlllIlIllIIlI[13] = (0x54 ^ 0x4F) << " ".length() << " ".length() ^ 0xA5 ^ 0xC4;
      lIlllIlIllIIlI[14] = ((0x73 ^ 0x78) << " ".length() << " ".length() << " ".length() ^ 173 + 148 - 228 + 90) << " ".length();
    }
    
    private static boolean lllllIlIlIIlllI(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lllllIlIlIIllll(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lllllIlIlIIllIl(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean lllllIlIlIIllII(int param1Int) {
      return (param1Int != 0);
    }
    
    private static boolean lllllIlIlIIlIll(int param1Int) {
      return (param1Int == 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\ColorComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */