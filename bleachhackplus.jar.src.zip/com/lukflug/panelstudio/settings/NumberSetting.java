package com.lukflug.panelstudio.settings;

public interface NumberSetting {
  double getNumber();
  
  void setNumber(double paramDouble);
  
  double getMaximumValue();
  
  double getMinimumValue();
  
  int getPrecision();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\NumberSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */