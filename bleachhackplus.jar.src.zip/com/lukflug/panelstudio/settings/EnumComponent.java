package com.lukflug.panelstudio.settings;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.FocusableComponent;
import com.lukflug.panelstudio.theme.Renderer;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EnumComponent extends FocusableComponent {
  protected EnumSetting setting;
  
  private static String[] llIIIlIIIlIIIl;
  
  private static Class[] llIIIlIIIlIIlI;
  
  private static final String[] llIIIlIIIlIllI;
  
  private static String[] llIIIlIIIlIlll;
  
  private static final int[] llIIIlIIIllIIl;
  
  public EnumComponent(String lllllllllllllllIllIlIllIlllIIlll, String lllllllllllllllIllIlIllIlllIIllI, Renderer lllllllllllllllIllIlIllIlllIIlIl, EnumSetting lllllllllllllllIllIlIllIlllIIlII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: aload_3
    //   4: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   7: aload_0
    //   8: aload #4
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/settings/EnumComponent;Lcom/lukflug/panelstudio/settings/EnumSetting;)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIllIlIllIlllIlIII	Lcom/lukflug/panelstudio/settings/EnumComponent;
    //   0	16	1	lllllllllllllllIllIlIllIlllIIlll	Ljava/lang/String;
    //   0	16	2	lllllllllllllllIllIlIllIlllIIllI	Ljava/lang/String;
    //   0	16	3	lllllllllllllllIllIlIllIlllIIlIl	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	16	4	lllllllllllllllIllIlIllIlllIIlII	Lcom/lukflug/panelstudio/settings/EnumSetting;
  }
  
  public void render(Context lllllllllllllllIllIlIllIlllIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial render : (Lcom/lukflug/panelstudio/Context;)V
    //   5: aload_0
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/EnumComponent;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   11: aload_1
    //   12: new java/lang/StringBuilder
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: aload_0
    //   20: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/settings/EnumComponent;)Ljava/lang/String;
    //   25: <illegal opcode> 3 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: getstatic com/lukflug/panelstudio/settings/EnumComponent.llIIIlIIIlIllI : [Ljava/lang/String;
    //   33: getstatic com/lukflug/panelstudio/settings/EnumComponent.llIIIlIIIllIIl : [I
    //   36: iconst_0
    //   37: iaload
    //   38: aaload
    //   39: <illegal opcode> 3 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: aload_0
    //   45: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/EnumComponent;)Lcom/lukflug/panelstudio/settings/EnumSetting;
    //   50: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/EnumSetting;)Ljava/lang/String;
    //   55: <illegal opcode> 3 : (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: <illegal opcode> 6 : (Ljava/lang/StringBuilder;)Ljava/lang/String;
    //   65: aload_0
    //   66: aload_1
    //   67: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/EnumComponent;Lcom/lukflug/panelstudio/Context;)Z
    //   72: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;Z)V
    //   77: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	78	0	lllllllllllllllIllIlIllIlllIIIll	Lcom/lukflug/panelstudio/settings/EnumComponent;
    //   0	78	1	lllllllllllllllIllIlIllIlllIIIlI	Lcom/lukflug/panelstudio/Context;
  }
  
  public void handleButton(Context lllllllllllllllIllIlIllIlllIIIII, int lllllllllllllllIllIlIllIllIlllll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: iload_2
    //   3: invokespecial handleButton : (Lcom/lukflug/panelstudio/Context;I)V
    //   6: iload_2
    //   7: invokestatic lIIIIIlllIllIIIl : (I)Z
    //   10: ifeq -> 36
    //   13: aload_1
    //   14: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/Context;)Z
    //   19: invokestatic lIIIIIlllIllIIlI : (I)Z
    //   22: ifeq -> 36
    //   25: aload_0
    //   26: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/EnumComponent;)Lcom/lukflug/panelstudio/settings/EnumSetting;
    //   31: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/settings/EnumSetting;)V
    //   36: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	37	0	lllllllllllllllIllIlIllIlllIIIIl	Lcom/lukflug/panelstudio/settings/EnumComponent;
    //   0	37	1	lllllllllllllllIllIlIllIlllIIIII	Lcom/lukflug/panelstudio/Context;
    //   0	37	2	lllllllllllllllIllIlIllIllIlllll	I
  }
  
  static {
    lIIIIIlllIllIIII();
    lIIIIIlllIlIlIll();
    lIIIIIlllIlIlIlI();
    lIIIIIlllIlIIllI();
  }
  
  private static CallSite lIIIIIlllIlIIlII(MethodHandles.Lookup lllllllllllllllIllIlIllIllIlIllI, String lllllllllllllllIllIlIllIllIlIlIl, MethodType lllllllllllllllIllIlIllIllIlIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIllIllIlllII = llIIIlIIIlIIIl[Integer.parseInt(lllllllllllllllIllIlIllIllIlIlIl)].split(llIIIlIIIlIllI[llIIIlIIIllIIl[1]]);
      Class<?> lllllllllllllllIllIlIllIllIllIll = Class.forName(lllllllllllllllIllIlIllIllIlllII[llIIIlIIIllIIl[0]]);
      String lllllllllllllllIllIlIllIllIllIlI = lllllllllllllllIllIlIllIllIlllII[llIIIlIIIllIIl[1]];
      MethodHandle lllllllllllllllIllIlIllIllIllIIl = null;
      int lllllllllllllllIllIlIllIllIllIII = lllllllllllllllIllIlIllIllIlllII[llIIIlIIIllIIl[2]].length();
      if (lIIIIIlllIllIIll(lllllllllllllllIllIlIllIllIllIII, llIIIlIIIllIIl[3])) {
        MethodType lllllllllllllllIllIlIllIllIllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIllIllIlllII[llIIIlIIIllIIl[3]], EnumComponent.class.getClassLoader());
        if (lIIIIIlllIllIlII(lllllllllllllllIllIlIllIllIllIII, llIIIlIIIllIIl[3])) {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findVirtual(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIllllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findStatic(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIllllI);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIllIllIlllIl = llIIIlIIIlIIlI[Integer.parseInt(lllllllllllllllIllIlIllIllIlllII[llIIIlIIIllIIl[3]])];
        if (lIIIIIlllIllIlII(lllllllllllllllIllIlIllIllIllIII, llIIIlIIIllIIl[2])) {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findGetter(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIlllIl);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIIlllIllIlII(lllllllllllllllIllIlIllIllIllIII, llIIIlIIIllIIl[4])) {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findStaticGetter(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIlllIl);
          "".length();
          if (-"  ".length() >= 0)
            return null; 
        } else if (lIIIIIlllIllIlII(lllllllllllllllIllIlIllIllIllIII, llIIIlIIIllIIl[5])) {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findSetter(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIlllIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIllIllIllIIl = lllllllllllllllIllIlIllIllIlIllI.findStaticSetter(lllllllllllllllIllIlIllIllIllIll, lllllllllllllllIllIlIllIllIllIlI, lllllllllllllllIllIlIllIllIlllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIllIllIllIIl);
    } catch (Exception lllllllllllllllIllIlIllIllIlIlll) {
      lllllllllllllllIllIlIllIllIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlllIlIIllI() {
    llIIIlIIIlIIIl = new String[llIIIlIIIllIIl[6]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[7]] = llIIIlIIIlIllI[llIIIlIIIllIIl[3]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[8]] = llIIIlIIIlIllI[llIIIlIIIllIIl[2]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[9]] = llIIIlIIIlIllI[llIIIlIIIllIIl[4]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[2]] = llIIIlIIIlIllI[llIIIlIIIllIIl[5]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[0]] = llIIIlIIIlIllI[llIIIlIIIllIIl[10]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[1]] = llIIIlIIIlIllI[llIIIlIIIllIIl[11]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[3]] = llIIIlIIIlIllI[llIIIlIIIllIIl[9]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[10]] = llIIIlIIIlIllI[llIIIlIIIllIIl[8]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[4]] = llIIIlIIIlIllI[llIIIlIIIllIIl[7]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[5]] = llIIIlIIIlIllI[llIIIlIIIllIIl[6]];
    llIIIlIIIlIIIl[llIIIlIIIllIIl[11]] = llIIIlIIIlIllI[llIIIlIIIllIIl[12]];
    llIIIlIIIlIIlI = new Class[llIIIlIIIllIIl[2]];
    llIIIlIIIlIIlI[llIIIlIIIllIIl[0]] = EnumSetting.class;
    llIIIlIIIlIIlI[llIIIlIIIllIIl[1]] = Renderer.class;
    llIIIlIIIlIIlI[llIIIlIIIllIIl[3]] = String.class;
  }
  
  private static void lIIIIIlllIlIlIlI() {
    llIIIlIIIlIllI = new String[llIIIlIIIllIIl[13]];
    llIIIlIIIlIllI[llIIIlIIIllIIl[0]] = lIIIIIlllIlIIlll(llIIIlIIIlIlll[llIIIlIIIllIIl[0]], llIIIlIIIlIlll[llIIIlIIIllIIl[1]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[1]] = lIIIIIlllIlIlIII(llIIIlIIIlIlll[llIIIlIIIllIIl[3]], llIIIlIIIlIlll[llIIIlIIIllIIl[2]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[3]] = lIIIIIlllIlIlIIl(llIIIlIIIlIlll[llIIIlIIIllIIl[4]], llIIIlIIIlIlll[llIIIlIIIllIIl[5]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[2]] = lIIIIIlllIlIlIII(llIIIlIIIlIlll[llIIIlIIIllIIl[10]], llIIIlIIIlIlll[llIIIlIIIllIIl[11]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[4]] = lIIIIIlllIlIlIIl(llIIIlIIIlIlll[llIIIlIIIllIIl[9]], llIIIlIIIlIlll[llIIIlIIIllIIl[8]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[5]] = lIIIIIlllIlIlIII(llIIIlIIIlIlll[llIIIlIIIllIIl[7]], llIIIlIIIlIlll[llIIIlIIIllIIl[6]]);
    llIIIlIIIlIllI[llIIIlIIIllIIl[10]] = lIIIIIlllIlIlIIl("KQgKbCE/DAEuOC1JFyMjLwsUNjguDghsPi8TEysjLRRJByM/CiQtIDoICScjPl0UJzk+Dgkld3pdR2Jtakc=", "JggBM");
    llIIIlIIIlIllI[llIIIlIIIllIIl[11]] = lIIIIIlllIlIlIIl("IBc/TDw2EzQOJSRWIgM+JhQhFiUnET1MIyYMJgs+JAt8Jz42FRENPTMXPAc+N0IgBz4nHSAHInlJaEJwYw==", "CxRbP");
    llIIIlIIIlIllI[llIIIlIIIllIIl[9]] = lIIIIIlllIlIIlll("6do8LoXLQyg6FpqgnAP70E91ewNtJCzeVqVBw8cMbGfv7AuF6cYkCR6VzqIW8FMpafRZ3tKLLfiIuJmGuOwJ0Q==", "wkdwH");
    llIIIlIIIlIllI[llIIIlIIIllIIl[8]] = lIIIIIlllIlIlIII("dbEPdwK2LXGjQwLrgcuGopyHRBJUeIlzEtfF3txRiJVojxmvHGBKXmiK3f/mqT/TpXOO8H9s1+xuxhf8YNYkMA==", "MaxIp");
    llIIIlIIIlIllI[llIIIlIIIllIIl[7]] = lIIIIIlllIlIlIIl("CCM3QT4eJzwDJwxiKg48DiApGycPJTVBIQ44LgY8DD90KjweIRkAPxsjNAo8H3YpCiYfJTQIaFt2ek9y", "kLZoR");
    llIIIlIIIlIllI[llIIIlIIIllIIl[6]] = lIIIIIlllIlIlIII("AGnFFyMY+i/MHEaeeTV3NC8eTXIjWiNdtVzLG9lrMonxlOkHBTFB9KvHvxv2xOzSbMu8hvVHk+iMx4ZCdp3c3/6C3CwJU71MMMvEeZ8elDGkKGXty2TqXQ==", "dsTCB");
    llIIIlIIIlIllI[llIIIlIIIllIIl[12]] = lIIIIIlllIlIlIIl("OQsPZgYvDwQkHz1KEikEPwgRPB8+DQ1mGT8QFiEEPRdMDQQvCSEnByoLDC0ELl4KKRkcCwE9GWBMLisFN0sOPQE8CBcvRSoFDC0GKRAXLAM1SyEnBC4BGjxRcz5YaEo=", "ZdbHj");
    llIIIlIIIlIlll = null;
  }
  
  private static void lIIIIIlllIlIlIll() {
    String str = (new Exception()).getStackTrace()[llIIIlIIIllIIl[0]].getFileName();
    llIIIlIIIlIlll = str.substring(str.indexOf("ä") + llIIIlIIIllIIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIlllIlIlIIl(String lllllllllllllllIllIlIllIllIlIIlI, String lllllllllllllllIllIlIllIllIlIIIl) {
    lllllllllllllllIllIlIllIllIlIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIllIllIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIllIllIlIIII = new StringBuilder();
    char[] lllllllllllllllIllIlIllIllIIllll = lllllllllllllllIllIlIllIllIlIIIl.toCharArray();
    int lllllllllllllllIllIlIllIllIIlllI = llIIIlIIIllIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIllIllIlIIlI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIIIllIIl[0];
    while (lIIIIIlllIllIlIl(j, i)) {
      char lllllllllllllllIllIlIllIllIlIIll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIllIllIIlllI++;
      j++;
      "".length();
      if (-(0x3A ^ 0x1F ^ " ".length() << (0x85 ^ 0x80)) >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIllIllIlIIII);
  }
  
  private static String lIIIIIlllIlIIlll(String lllllllllllllllIllIlIllIllIIlIlI, String lllllllllllllllIllIlIllIllIIlIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIllIllIIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIllIllIIlIIl.getBytes(StandardCharsets.UTF_8)), llIIIlIIIllIIl[9]), "DES");
      Cipher lllllllllllllllIllIlIllIllIIllII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIllIllIIllII.init(llIIIlIIIllIIl[3], lllllllllllllllIllIlIllIllIIllIl);
      return new String(lllllllllllllllIllIlIllIllIIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIllIllIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIllIllIIlIll) {
      lllllllllllllllIllIlIllIllIIlIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIlllIlIlIII(String lllllllllllllllIllIlIllIllIIIlIl, String lllllllllllllllIllIlIllIllIIIlII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIllIllIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIllIllIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIllIllIIIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIllIllIIIlll.init(llIIIlIIIllIIl[3], lllllllllllllllIllIlIllIllIIlIII);
      return new String(lllllllllllllllIllIlIllIllIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIllIllIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIllIllIIIllI) {
      lllllllllllllllIllIlIllIllIIIllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIlllIllIIII() {
    llIIIlIIIllIIl = new int[14];
    llIIIlIIIllIIl[0] = ((0x98 ^ 0xBD) << " ".length() ^ 0x26 ^ 0x4B) << " ".length() & (((0x7E ^ 0x57) & (0x70 ^ 0x59 ^ 0xFFFFFFFF) ^ 0x83 ^ 0xA4) << " ".length() ^ -" ".length());
    llIIIlIIIllIIl[1] = " ".length();
    llIIIlIIIllIIl[2] = "   ".length();
    llIIIlIIIllIIl[3] = " ".length() << " ".length();
    llIIIlIIIllIIl[4] = " ".length() << " ".length() << " ".length();
    llIIIlIIIllIIl[5] = 0x9B ^ 0x9E;
    llIIIlIIIllIIl[6] = 0x21 ^ 0x48 ^ (0x6C ^ 0x5D) << " ".length();
    llIIIlIIIllIIl[7] = ((0x4C ^ 0x1D) << " ".length() ^ 53 + 111 - 142 + 145) << " ".length();
    llIIIlIIIllIIl[8] = 0xA7 ^ 0xAE;
    llIIIlIIIllIIl[9] = " ".length() << "   ".length();
    llIIIlIIIllIIl[10] = "   ".length() << " ".length();
    llIIIlIIIllIIl[11] = 0xCD ^ 0xA4 ^ (0x10 ^ 0x27) << " ".length();
    llIIIlIIIllIIl[12] = "   ".length() << " ".length() << " ".length();
    llIIIlIIIllIIl[13] = (0x86 ^ 0xB1) << " ".length() ^ 0xF8 ^ 0x9B;
  }
  
  private static boolean lIIIIIlllIllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIlllIllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIlllIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIIlllIllIIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIIlllIllIIIl(int paramInt) {
    return (paramInt == 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\EnumComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */