package com.lukflug.panelstudio.settings;

public interface EnumSetting {
  void increment();
  
  String getValueName();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\settings\EnumSetting.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */