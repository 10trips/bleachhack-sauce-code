package com.lukflug.panelstudio;

import com.lukflug.panelstudio.settings.Toggleable;

public interface PanelManager {
  void showComponent(FixedComponent paramFixedComponent);
  
  void hideComponent(FixedComponent paramFixedComponent);
  
  Toggleable getComponentToggleable(FixedComponent paramFixedComponent);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\PanelManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */