package com.lukflug.panelstudio;

import java.awt.Point;

public interface PanelConfig {
  void savePositon(Point paramPoint);
  
  Point loadPosition();
  
  void saveState(boolean paramBoolean);
  
  boolean loadState();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\PanelConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */