package com.lukflug.panelstudio;

public interface Component {
  String getTitle();
  
  void render(Context paramContext);
  
  void handleButton(Context paramContext, int paramInt);
  
  void handleKey(Context paramContext, int paramInt);
  
  void handleScroll(Context paramContext, int paramInt);
  
  void getHeight(Context paramContext);
  
  void enter(Context paramContext);
  
  void exit(Context paramContext);
  
  void releaseFocus();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\Component.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */