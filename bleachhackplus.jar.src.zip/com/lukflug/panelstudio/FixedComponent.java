package com.lukflug.panelstudio;

import java.awt.Point;

public interface FixedComponent extends Component {
  Point getPosition(Interface paramInterface);
  
  void setPosition(Interface paramInterface, Point paramPoint);
  
  int getWidth(Interface paramInterface);
  
  void saveConfig(Interface paramInterface, PanelConfig paramPanelConfig);
  
  void loadConfig(Interface paramInterface, PanelConfig paramPanelConfig);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\FixedComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */