package com.lukflug.panelstudio;

public interface ConfigList {
  void begin(boolean paramBoolean);
  
  void end(boolean paramBoolean);
  
  PanelConfig addPanel(String paramString);
  
  PanelConfig getPanel(String paramString);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\ConfigList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */