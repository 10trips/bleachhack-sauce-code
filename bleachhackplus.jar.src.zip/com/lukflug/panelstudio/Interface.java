package com.lukflug.panelstudio;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;

public interface Interface {
  public static final int LBUTTON = ((0x79 ^ 0x76) << "   ".length() ^ 0x18 ^ 0x27) & (0x29 ^ 0x50 ^ (0x13 ^ 0xC) << " ".length() ^ -" ".length());
  
  public static final int RBUTTON = " ".length();
  
  Point getMouse();
  
  boolean getButton(int paramInt);
  
  void drawString(Point paramPoint, String paramString, Color paramColor);
  
  int getFontWidth(String paramString);
  
  int getFontHeight();
  
  void fillTriangle(Point paramPoint1, Point paramPoint2, Point paramPoint3, Color paramColor1, Color paramColor2, Color paramColor3);
  
  void drawLine(Point paramPoint1, Point paramPoint2, Color paramColor1, Color paramColor2);
  
  void fillRect(Rectangle paramRectangle, Color paramColor1, Color paramColor2, Color paramColor3, Color paramColor4);
  
  void drawRect(Rectangle paramRectangle, Color paramColor1, Color paramColor2, Color paramColor3, Color paramColor4);
  
  int loadImage(String paramString);
  
  void drawImage(Rectangle paramRectangle, int paramInt1, boolean paramBoolean, int paramInt2);
  
  void window(Rectangle paramRectangle);
  
  void restore();
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\Interface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */