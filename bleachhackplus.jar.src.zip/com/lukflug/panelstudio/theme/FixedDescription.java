package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class FixedDescription implements DescriptionRenderer {
  protected Point pos;
  
  private static String[] llIIlIlllIllIl;
  
  private static Class[] llIIlIlllIlllI;
  
  private static final String[] llIIlIlllIllll;
  
  private static String[] llIIlIllllIIII;
  
  private static final int[] llIIlIllllIIIl;
  
  public FixedDescription(Point lllllllllllllllIllIIIlllIllIlIll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/FixedDescription;Ljava/awt/Point;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIIIlllIllIllII	Lcom/lukflug/panelstudio/theme/FixedDescription;
    //   0	12	1	lllllllllllllllIllIIIlllIllIlIll	Ljava/awt/Point;
  }
  
  public void renderDescription(Context lllllllllllllllIllIIIlllIllIIllI) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   6: invokestatic lIIIlIIIIllIIIlI : (Ljava/lang/Object;)Z
    //   9: ifeq -> 169
    //   12: new java/awt/Rectangle
    //   15: dup
    //   16: aload_0
    //   17: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/FixedDescription;)Ljava/awt/Point;
    //   22: new java/awt/Dimension
    //   25: dup
    //   26: aload_1
    //   27: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   32: aload_1
    //   33: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   38: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/lang/String;)I
    //   43: aload_1
    //   44: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   49: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Interface;)I
    //   54: invokespecial <init> : (II)V
    //   57: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
    //   60: astore_2
    //   61: new java/awt/Color
    //   64: dup
    //   65: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   68: iconst_0
    //   69: iaload
    //   70: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   73: iconst_0
    //   74: iaload
    //   75: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   78: iconst_0
    //   79: iaload
    //   80: invokespecial <init> : (III)V
    //   83: astore_3
    //   84: aload_1
    //   85: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   90: aload_2
    //   91: aload_3
    //   92: aload_3
    //   93: aload_3
    //   94: aload_3
    //   95: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   100: new java/awt/Color
    //   103: dup
    //   104: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   107: iconst_1
    //   108: iaload
    //   109: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   112: iconst_1
    //   113: iaload
    //   114: getstatic com/lukflug/panelstudio/theme/FixedDescription.llIIlIllllIIIl : [I
    //   117: iconst_1
    //   118: iaload
    //   119: invokespecial <init> : (III)V
    //   122: astore #4
    //   124: aload_1
    //   125: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   130: aload_2
    //   131: aload #4
    //   133: aload #4
    //   135: aload #4
    //   137: aload #4
    //   139: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   144: aload_1
    //   145: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   150: aload_0
    //   151: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/FixedDescription;)Ljava/awt/Point;
    //   156: aload_1
    //   157: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   162: aload #4
    //   164: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
    //   169: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   61	108	2	lllllllllllllllIllIIIlllIllIlIlI	Ljava/awt/Rectangle;
    //   84	85	3	lllllllllllllllIllIIIlllIllIlIIl	Ljava/awt/Color;
    //   124	45	4	lllllllllllllllIllIIIlllIllIlIII	Ljava/awt/Color;
    //   0	170	0	lllllllllllllllIllIIIlllIllIIlll	Lcom/lukflug/panelstudio/theme/FixedDescription;
    //   0	170	1	lllllllllllllllIllIIIlllIllIIllI	Lcom/lukflug/panelstudio/Context;
  }
  
  static {
    lIIIlIIIIllIIIIl();
    lIIIlIIIIllIIIII();
    lIIIlIIIIlIlllll();
    lIIIlIIIIlIlllII();
  }
  
  private static CallSite lIIIlIIIIlIllIll(MethodHandles.Lookup lllllllllllllllIllIIIlllIlIlllIl, String lllllllllllllllIllIIIlllIlIlllII, MethodType lllllllllllllllIllIIIlllIlIllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIlllIllIIIll = llIIlIlllIllIl[Integer.parseInt(lllllllllllllllIllIIIlllIlIlllII)].split(llIIlIlllIllll[llIIlIllllIIIl[0]]);
      Class<?> lllllllllllllllIllIIIlllIllIIIlI = Class.forName(lllllllllllllllIllIIIlllIllIIIll[llIIlIllllIIIl[0]]);
      String lllllllllllllllIllIIIlllIllIIIIl = lllllllllllllllIllIIIlllIllIIIll[llIIlIllllIIIl[2]];
      MethodHandle lllllllllllllllIllIIIlllIllIIIII = null;
      int lllllllllllllllIllIIIlllIlIlllll = lllllllllllllllIllIIIlllIllIIIll[llIIlIllllIIIl[3]].length();
      if (lIIIlIIIIllIIIll(lllllllllllllllIllIIIlllIlIlllll, llIIlIllllIIIl[4])) {
        MethodType lllllllllllllllIllIIIlllIllIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIlllIllIIIll[llIIlIllllIIIl[4]], FixedDescription.class.getClassLoader());
        if (lIIIlIIIIllIIlII(lllllllllllllllIllIIIlllIlIlllll, llIIlIllllIIIl[4])) {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findVirtual(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlIl);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findStatic(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlIl);
        } 
        "".length();
        if (((0x6F ^ 0x7C) << " ".length() << " ".length() & ((0x37 ^ 0x24) << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIlllIllIIlII = llIIlIlllIlllI[Integer.parseInt(lllllllllllllllIllIIIlllIllIIIll[llIIlIllllIIIl[4]])];
        if (lIIIlIIIIllIIlII(lllllllllllllllIllIIIlllIlIlllll, llIIlIllllIIIl[3])) {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findGetter(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlII);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= "   ".length())
            return null; 
        } else if (lIIIlIIIIllIIlII(lllllllllllllllIllIIIlllIlIlllll, llIIlIllllIIIl[5])) {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findStaticGetter(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIlIIIIllIIlII(lllllllllllllllIllIIIlllIlIlllll, llIIlIllllIIIl[6])) {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findSetter(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlII);
          "".length();
          if (("   ".length() << " ".length() << " ".length() & ("   ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)) > "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIlllIllIIIII = lllllllllllllllIllIIIlllIlIlllIl.findStaticSetter(lllllllllllllllIllIIIlllIllIIIlI, lllllllllllllllIllIIIlllIllIIIIl, lllllllllllllllIllIIIlllIllIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIlllIllIIIII);
    } catch (Exception lllllllllllllllIllIIIlllIlIllllI) {
      lllllllllllllllIllIIIlllIlIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIlIlllII() {
    llIIlIlllIllIl = new String[llIIlIllllIIIl[7]];
    llIIlIlllIllIl[llIIlIllllIIIl[4]] = llIIlIlllIllll[llIIlIllllIIIl[2]];
    llIIlIlllIllIl[llIIlIllllIIIl[8]] = llIIlIlllIllll[llIIlIllllIIIl[4]];
    llIIlIlllIllIl[llIIlIllllIIIl[2]] = llIIlIlllIllll[llIIlIllllIIIl[3]];
    llIIlIlllIllIl[llIIlIllllIIIl[3]] = llIIlIlllIllll[llIIlIllllIIIl[5]];
    llIIlIlllIllIl[llIIlIllllIIIl[6]] = llIIlIlllIllll[llIIlIllllIIIl[6]];
    llIIlIlllIllIl[llIIlIllllIIIl[9]] = llIIlIlllIllll[llIIlIllllIIIl[8]];
    llIIlIlllIllIl[llIIlIllllIIIl[10]] = llIIlIlllIllll[llIIlIllllIIIl[10]];
    llIIlIlllIllIl[llIIlIllllIIIl[5]] = llIIlIlllIllll[llIIlIllllIIIl[9]];
    llIIlIlllIllIl[llIIlIllllIIIl[0]] = llIIlIlllIllll[llIIlIllllIIIl[7]];
    llIIlIlllIlllI = new Class[llIIlIllllIIIl[2]];
    llIIlIlllIlllI[llIIlIllllIIIl[0]] = Point.class;
  }
  
  private static void lIIIlIIIIlIlllll() {
    llIIlIlllIllll = new String[llIIlIllllIIIl[11]];
    llIIlIlllIllll[llIIlIllllIIIl[0]] = lIIIlIIIIlIlllIl(llIIlIllllIIII[llIIlIllllIIIl[0]], llIIlIllllIIII[llIIlIllllIIIl[2]]);
    llIIlIlllIllll[llIIlIllllIIIl[2]] = lIIIlIIIIlIlllIl(llIIlIllllIIII[llIIlIllllIIIl[4]], llIIlIllllIIII[llIIlIllllIIIl[3]]);
    llIIlIlllIllll[llIIlIllllIIIl[4]] = lIIIlIIIIlIllllI(llIIlIllllIIII[llIIlIllllIIIl[5]], llIIlIllllIIII[llIIlIllllIIIl[6]]);
    llIIlIlllIllll[llIIlIllllIIIl[3]] = lIIIlIIIIlIlllIl(llIIlIllllIIII[llIIlIllllIIIl[8]], llIIlIllllIIII[llIIlIllllIIIl[10]]);
    llIIlIlllIllll[llIIlIllllIIIl[5]] = lIIIlIIIIlIlllIl("hoHt663pm69JTji3orf94v1YS4qzeS3WCfXtWmY38uM+big4SFby6z43kcVt03ArpaqV5z/HlIazTA6eC1eH+j/152HZXHQweLNUU0t5uN0WPPu9zChukg==", "GsWee");
    llIIlIlllIllll[llIIlIllllIIIl[6]] = lIIIlIIIIlIlllIl("Uail9YEjjCcB4m0Wew7X0BqeCDeg6TQxymju612rBykEkSFjR8Ej8ZZLG2C6OSlPhpKhWOMWNcE=", "JYUgH");
    llIIlIlllIllll[llIIlIllllIIIl[8]] = lIIIlIIIIlIlllIl("xscWLysHrGzqvnhjEGqca7a5D9U4UVrSkmiLZZzbYVBKm27M51mp6gmiXLSnRmazdiO1ymOfZzfLM54sO/U7Y0CbPIoqrAuFfmuKTYpF8BmNJyhJKW6aTJviJiOeKPaiEahjHyppCJ0=", "DdPvB");
    llIIlIlllIllll[llIIlIllllIIIl[10]] = lIIIlIIIIlIlllIl("Ej2lDUXq+UgAvKZRIBL1WObaBVgMN0X6C1z/X8ckvMkEOXZf9GUvbCSxrPDB6tqsORlw3a/suCg3/6j1xQYXoaOWvwjvkONon86S1gVZldajlr8I75DjaJ/OktYFWZXWo5a/CO+Q42ifzpLWBVmV1qOWvwjvkONon86S1gVZldZvgUV4J9e6sw==", "RyoKt");
    llIIlIlllIllll[llIIlIllllIIIl[9]] = lIIIlIIIIlIlllIl("ByKDl+EvaAlvOfOIFiy9fWPF2J5A8B6obQ803OvYvi7EXCpeetfroDkduXwTDqBTPJV+4hc0XhyBKrFxlozlpBnH1f78NfaS", "WjHbu");
    llIIlIlllIllll[llIIlIllllIIIl[7]] = lIIIlIIIIlIlllIl("t6f2zFDiaxYFqGtk1lGA3Idbc0bhpQPiQvw+w62mzi0GQSd3YWczogoDFsd4RR4UATQnruVCYOkuU3ZWJ7GeOA==", "tcWSz");
    llIIlIllllIIII = null;
  }
  
  private static void lIIIlIIIIllIIIII() {
    String str = (new Exception()).getStackTrace()[llIIlIllllIIIl[0]].getFileName();
    llIIlIllllIIII = str.substring(str.indexOf("ä") + llIIlIllllIIIl[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIIlIlllIl(String lllllllllllllllIllIIIlllIlIlIlll, String lllllllllllllllIllIIIlllIlIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIlIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIlIlIllI.getBytes(StandardCharsets.UTF_8)), llIIlIllllIIIl[9]), "DES");
      Cipher lllllllllllllllIllIIIlllIlIllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIIlllIlIllIIl.init(llIIlIllllIIIl[4], lllllllllllllllIllIIIlllIlIllIlI);
      return new String(lllllllllllllllIllIIIlllIlIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIlIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIlIllIII) {
      lllllllllllllllIllIIIlllIlIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIlIllllI(String lllllllllllllllIllIIIlllIlIlIIlI, String lllllllllllllllIllIIIlllIlIlIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIlIlIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIlIlIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIlllIlIlIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIlllIlIlIlII.init(llIIlIllllIIIl[4], lllllllllllllllIllIIIlllIlIlIlIl);
      return new String(lllllllllllllllIllIIIlllIlIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIlIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIlIlIIll) {
      lllllllllllllllIllIIIlllIlIlIIll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIllIIIIl() {
    llIIlIllllIIIl = new int[12];
    llIIlIllllIIIl[0] = (0x57 ^ 0x34) & (0x2D ^ 0x4E ^ 0xFFFFFFFF);
    llIIlIllllIIIl[1] = 117 + 8 - 96 + 226;
    llIIlIllllIIIl[2] = " ".length();
    llIIlIllllIIIl[3] = "   ".length();
    llIIlIllllIIIl[4] = " ".length() << " ".length();
    llIIlIllllIIIl[5] = " ".length() << " ".length() << " ".length();
    llIIlIllllIIIl[6] = 0x91 ^ 0x94;
    llIIlIllllIIIl[7] = 0x23 ^ 0x2A;
    llIIlIllllIIIl[8] = "   ".length() << " ".length();
    llIIlIllllIIIl[9] = " ".length() << "   ".length();
    llIIlIllllIIIl[10] = 0x1B ^ 0x1C;
    llIIlIllllIIIl[11] = (0xA4 ^ 0xA1) << " ".length();
  }
  
  private static boolean lIIIlIIIIllIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIIllIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIIIllIIIlI(Object paramObject) {
    return (paramObject != null);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\FixedDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */