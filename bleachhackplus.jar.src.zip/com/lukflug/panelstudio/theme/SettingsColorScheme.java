package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.settings.ColorSetting;
import com.lukflug.panelstudio.settings.NumberSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class SettingsColorScheme implements ColorScheme {
  protected final ColorSetting activeColor;
  
  protected final ColorSetting inactiveColor;
  
  protected final ColorSetting backgroundColor;
  
  protected final ColorSetting outlineColor;
  
  protected final ColorSetting fontColor;
  
  protected final NumberSetting opacity;
  
  private static String[] lIllllIIlIlIIl;
  
  private static Class[] lIllllIIlIlIlI;
  
  private static final String[] lIllllIIlIlIll;
  
  private static String[] lIllllIIlIllII;
  
  private static final int[] lIllllIIlIllIl;
  
  public SettingsColorScheme(ColorSetting lllllllllllllllIlllIIllIIIllIIlI, ColorSetting lllllllllllllllIlllIIllIIIllIIIl, ColorSetting lllllllllllllllIlllIIllIIIllIIII, ColorSetting lllllllllllllllIlllIIllIIIlIllll, ColorSetting lllllllllllllllIlllIIllIIIlIlllI, NumberSetting lllllllllllllllIlllIIllIIIlIllIl) {
    this.activeColor = lllllllllllllllIlllIIllIIIllIIlI;
    this.inactiveColor = lllllllllllllllIlllIIllIIIllIIIl;
    this.backgroundColor = lllllllllllllllIlllIIllIIIllIIII;
    this.outlineColor = lllllllllllllllIlllIIllIIIlIllll;
    this.fontColor = lllllllllllllllIlllIIllIIIlIlllI;
    this.opacity = lllllllllllllllIlllIIllIIIlIllIl;
  }
  
  public Color getActiveColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIIIlIllII	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  public Color getInactiveColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIIIlIlIll	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  public Color getBackgroundColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIIIlIlIlI	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  public Color getOutlineColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIIIlIlIIl	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  public Color getFontColor() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/ColorSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/ColorSetting;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIIIlIlIII	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  public int getOpacity() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/SettingsColorScheme;)Lcom/lukflug/panelstudio/settings/NumberSetting;
    //   6: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/settings/NumberSetting;)D
    //   11: d2i
    //   12: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIlllIIllIIIlIIlll	Lcom/lukflug/panelstudio/theme/SettingsColorScheme;
  }
  
  static {
    llllllIlIlIIllI();
    llllllIlIlIIlIl();
    llllllIlIlIIlII();
    llllllIlIlIIIII();
  }
  
  private static CallSite llllllIlIIlllll(MethodHandles.Lookup lllllllllllllllIlllIIllIIIIllllI, String lllllllllllllllIlllIIllIIIIlllIl, MethodType lllllllllllllllIlllIIllIIIIlllII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIllIIIlIIlII = lIllllIIlIlIIl[Integer.parseInt(lllllllllllllllIlllIIllIIIIlllIl)].split(lIllllIIlIlIll[lIllllIIlIllIl[0]]);
      Class<?> lllllllllllllllIlllIIllIIIlIIIll = Class.forName(lllllllllllllllIlllIIllIIIlIIlII[lIllllIIlIllIl[0]]);
      String lllllllllllllllIlllIIllIIIlIIIlI = lllllllllllllllIlllIIllIIIlIIlII[lIllllIIlIllIl[1]];
      MethodHandle lllllllllllllllIlllIIllIIIlIIIIl = null;
      int lllllllllllllllIlllIIllIIIlIIIII = lllllllllllllllIlllIIllIIIlIIlII[lIllllIIlIllIl[2]].length();
      if (llllllIlIlIIlll(lllllllllllllllIlllIIllIIIlIIIII, lIllllIIlIllIl[3])) {
        MethodType lllllllllllllllIlllIIllIIIlIIllI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIllIIIlIIlII[lIllllIIlIllIl[3]], SettingsColorScheme.class.getClassLoader());
        if (llllllIlIlIlIII(lllllllllllllllIlllIIllIIIlIIIII, lIllllIIlIllIl[3])) {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findVirtual(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIllI);
          "".length();
          if ((((0x4F ^ 0x18) << " ".length() ^ 76 + 26 - 99 + 186) << " ".length() & ((0x1D ^ 0x50 ^ (0x91 ^ 0xBE) << " ".length()) << " ".length() ^ -" ".length())) == " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findStatic(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIllI);
        } 
        "".length();
        if ("   ".length() > "   ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIllIIIlIIlIl = lIllllIIlIlIlI[Integer.parseInt(lllllllllllllllIlllIIllIIIlIIlII[lIllllIIlIllIl[3]])];
        if (llllllIlIlIlIII(lllllllllllllllIlllIIllIIIlIIIII, lIllllIIlIllIl[2])) {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findGetter(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIlIl);
          "".length();
          if (null != null)
            return null; 
        } else if (llllllIlIlIlIII(lllllllllllllllIlllIIllIIIlIIIII, lIllllIIlIllIl[4])) {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findStaticGetter(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIlIl);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (llllllIlIlIlIII(lllllllllllllllIlllIIllIIIlIIIII, lIllllIIlIllIl[5])) {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findSetter(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIlIl);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIIllIIIlIIIIl = lllllllllllllllIlllIIllIIIIllllI.findStaticSetter(lllllllllllllllIlllIIllIIIlIIIll, lllllllllllllllIlllIIllIIIlIIIlI, lllllllllllllllIlllIIllIIIlIIlIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIllIIIlIIIIl);
    } catch (Exception lllllllllllllllIlllIIllIIIIlllll) {
      lllllllllllllllIlllIIllIIIIlllll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIlIlIIIII() {
    lIllllIIlIlIIl = new String[lIllllIIlIllIl[6]];
    lIllllIIlIlIIl[lIllllIIlIllIl[7]] = lIllllIIlIlIll[lIllllIIlIllIl[1]];
    lIllllIIlIlIIl[lIllllIIlIllIl[3]] = lIllllIIlIlIll[lIllllIIlIllIl[3]];
    lIllllIIlIlIIl[lIllllIIlIllIl[8]] = lIllllIIlIlIll[lIllllIIlIllIl[2]];
    lIllllIIlIlIIl[lIllllIIlIllIl[5]] = lIllllIIlIlIll[lIllllIIlIllIl[4]];
    lIllllIIlIlIIl[lIllllIIlIllIl[2]] = lIllllIIlIlIll[lIllllIIlIllIl[5]];
    lIllllIIlIlIIl[lIllllIIlIllIl[4]] = lIllllIIlIlIll[lIllllIIlIllIl[7]];
    lIllllIIlIlIIl[lIllllIIlIllIl[0]] = lIllllIIlIlIll[lIllllIIlIllIl[8]];
    lIllllIIlIlIIl[lIllllIIlIllIl[1]] = lIllllIIlIlIll[lIllllIIlIllIl[6]];
    lIllllIIlIlIlI = new Class[lIllllIIlIllIl[3]];
    lIllllIIlIlIlI[lIllllIIlIllIl[1]] = NumberSetting.class;
    lIllllIIlIlIlI[lIllllIIlIllIl[0]] = ColorSetting.class;
  }
  
  private static void llllllIlIlIIlII() {
    lIllllIIlIlIll = new String[lIllllIIlIllIl[9]];
    lIllllIIlIlIll[lIllllIIlIllIl[0]] = llllllIlIlIIIIl(lIllllIIlIllII[lIllllIIlIllIl[0]], lIllllIIlIllII[lIllllIIlIllIl[1]]);
    lIllllIIlIlIll[lIllllIIlIllIl[1]] = llllllIlIlIIIIl(lIllllIIlIllII[lIllllIIlIllIl[3]], lIllllIIlIllII[lIllllIIlIllIl[2]]);
    lIllllIIlIlIll[lIllllIIlIllIl[3]] = llllllIlIlIIIlI(lIllllIIlIllII[lIllllIIlIllIl[4]], lIllllIIlIllII[lIllllIIlIllIl[5]]);
    lIllllIIlIlIll[lIllllIIlIllIl[2]] = llllllIlIlIIIll(lIllllIIlIllII[lIllllIIlIllIl[7]], lIllllIIlIllII[lIllllIIlIllIl[8]]);
    lIllllIIlIlIll[lIllllIIlIllIl[4]] = llllllIlIlIIIlI(lIllllIIlIllII[lIllllIIlIllIl[6]], lIllllIIlIllII[lIllllIIlIllIl[9]]);
    lIllllIIlIlIll[lIllllIIlIllIl[5]] = llllllIlIlIIIIl("5QlRuc2U0D/r/ieb8NLzQDi+Zm8Mdo4PUAdQXuXfJw+61CiuWD9Q4oPy1uGuzweoe+zrQCBQeokR/Khfm/cB5MOPbue3aM9E", "ILpcX");
    lIllllIIlIlIll[lIllllIIlIllIl[7]] = llllllIlIlIIIIl("zpe0+jsmLK6hd7VXgOR5+PHbtkBhTKLOESw+5zqyoVfemN9mnZ/XgjE0MQwmCj3Sw2S25KKKWeg2QTgz0dOb0v2Y9Si0Bq+m", "aSPnr");
    lIllllIIlIlIll[lIllllIIlIllIl[8]] = llllllIlIlIIIIl("PwcavmTrFuFPV94JJFnjeSlJwulGlzbw15ChHblXidGV46qu+8BfAorQ6spDqEg++X4LTOp41wpIfLNt7D6apErzhK7TzoP/", "XWmSC");
    lIllllIIlIlIll[lIllllIIlIllIl[6]] = llllllIlIlIIIll("KAkifwM+DSk9GixIPzABLgo8JRovDyB/HC4SOzgBLBVhEgAnCT0CCj8SJj8IcQEqJTkqCjo0VWNPAzsOPQdgMBg/SQw+AyQUdGtPaw==", "KfOQo");
    lIllllIIlIllII = null;
  }
  
  private static void llllllIlIlIIlIl() {
    String str = (new Exception()).getStackTrace()[lIllllIIlIllIl[0]].getFileName();
    lIllllIIlIllII = str.substring(str.indexOf("ä") + lIllllIIlIllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIlIlIIIlI(String lllllllllllllllIlllIIllIIIIllIII, String lllllllllllllllIlllIIllIIIIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIIIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIIIlIlll.getBytes(StandardCharsets.UTF_8)), lIllllIIlIllIl[6]), "DES");
      Cipher lllllllllllllllIlllIIllIIIIllIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIIllIIIIllIlI.init(lIllllIIlIllIl[3], lllllllllllllllIlllIIllIIIIllIll);
      return new String(lllllllllllllllIlllIIllIIIIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIIIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIIIllIIl) {
      lllllllllllllllIlllIIllIIIIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlIlIIIIl(String lllllllllllllllIlllIIllIIIIlIIll, String lllllllllllllllIlllIIllIIIIlIIlI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIIIlIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIIIlIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIllIIIIlIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIllIIIIlIlIl.init(lIllllIIlIllIl[3], lllllllllllllllIlllIIllIIIIlIllI);
      return new String(lllllllllllllllIlllIIllIIIIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIIIlIlII) {
      lllllllllllllllIlllIIllIIIIlIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIlIlIIIll(String lllllllllllllllIlllIIllIIIIlIIII, String lllllllllllllllIlllIIllIIIIIllll) {
    lllllllllllllllIlllIIllIIIIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIIIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIllIIIIIlllI = new StringBuilder();
    char[] lllllllllllllllIlllIIllIIIIIllIl = lllllllllllllllIlllIIllIIIIIllll.toCharArray();
    int lllllllllllllllIlllIIllIIIIIllII = lIllllIIlIllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIllIIIIlIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIlIllIl[0];
    while (llllllIlIlIlIIl(j, i)) {
      char lllllllllllllllIlllIIllIIIIlIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIllIIIIIllII++;
      j++;
      "".length();
      if ((" ".length() << "   ".length() << " ".length() & (" ".length() << "   ".length() << " ".length() ^ 0xFFFFFFFF)) != ((0xB8 ^ 0x99) << " ".length() & ((0x90 ^ 0xB1) << " ".length() ^ 0xFFFFFFFF)))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIllIIIIIlllI);
  }
  
  private static void llllllIlIlIIllI() {
    lIllllIIlIllIl = new int[10];
    lIllllIIlIllIl[0] = (0x8A ^ 0x9B) << " ".length() & ((0x41 ^ 0x50) << " ".length() ^ 0xFFFFFFFF);
    lIllllIIlIllIl[1] = " ".length();
    lIllllIIlIllIl[2] = "   ".length();
    lIllllIIlIllIl[3] = " ".length() << " ".length();
    lIllllIIlIllIl[4] = " ".length() << " ".length() << " ".length();
    lIllllIIlIllIl[5] = (0x45 ^ 0x52) << " ".length() << " ".length() ^ 0x24 ^ 0x7D;
    lIllllIIlIllIl[6] = " ".length() << "   ".length();
    lIllllIIlIllIl[7] = "   ".length() << " ".length();
    lIllllIIlIllIl[8] = 0x70 ^ 0x77;
    lIllllIIlIllIl[9] = 0x5B ^ 0x52;
  }
  
  private static boolean llllllIlIlIlIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIlIlIlIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIlIlIIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\SettingsColorScheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */