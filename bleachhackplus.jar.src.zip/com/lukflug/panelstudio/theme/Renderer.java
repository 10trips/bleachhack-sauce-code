package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Color;
import java.awt.Rectangle;

public interface Renderer {
  int getHeight(boolean paramBoolean);
  
  int getOffset();
  
  int getBorder();
  
  int getBottomBorder();
  
  int getLeftBorder(boolean paramBoolean);
  
  int getRightBorder(boolean paramBoolean);
  
  void renderTitle(Context paramContext, String paramString, boolean paramBoolean);
  
  void renderTitle(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  void renderTitle(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  void renderRect(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2, Rectangle paramRectangle, boolean paramBoolean3);
  
  void renderBackground(Context paramContext, boolean paramBoolean);
  
  void renderBorder(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  int renderScrollBar(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt1, int paramInt2);
  
  Color getMainColor(boolean paramBoolean1, boolean paramBoolean2);
  
  Color getBackgroundColor(boolean paramBoolean);
  
  Color getFontColor(boolean paramBoolean);
  
  ColorScheme getDefaultColorScheme();
  
  void overrideColorScheme(ColorScheme paramColorScheme);
  
  void restoreColorScheme();
  
  static Color brighter(Color lllllllllllllllIllIIIlllIlIlIIII) {
    int lllllllllllllllIllIIIlllIlIIllll = lllllllllllllllIllIIIlllIlIlIIII.getRed();
    int lllllllllllllllIllIIIlllIlIIlllI = lllllllllllllllIllIIIlllIlIlIIII.getGreen();
    int lllllllllllllllIllIIIlllIlIIllIl = lllllllllllllllIllIIIlllIlIlIIII.getBlue();
    lllllllllllllllIllIIIlllIlIIllll += 64;
    lllllllllllllllIllIIIlllIlIIlllI += 64;
    lllllllllllllllIllIIIlllIlIIllIl += 64;
    if (lIIIlIIIIllIIlIl(lllllllllllllllIllIIIlllIlIIllll, 25 + 35 - 44 + 113 + ((0xBB ^ 0xA8) << " ".length()) - ((0x7F ^ 0x78) << " ".length() << " ".length() << " ".length()) + ((0x66 ^ 0x7F) << "   ".length())))
      lllllllllllllllIllIIIlllIlIIllll = 114 + 98 - 97 + 38 + 9 + 114 - -46 + 10 - 19 + 81 - -78 + 57 + ((0x5C ^ 0x13) << " ".length()); 
    if (lIIIlIIIIllIIlIl(lllllllllllllllIllIIIlllIlIIlllI, 184 + 31 - 159 + 199))
      lllllllllllllllIllIIIlllIlIIlllI = 184 + 28 - 50 + 93; 
    if (lIIIlIIIIllIIlIl(lllllllllllllllIllIIIlllIlIIllIl, 159 + 19 - 129 + 206))
      lllllllllllllllIllIIIlllIlIIllIl = 232 + 66 - 152 + 109; 
    return new Color(lllllllllllllllIllIIIlllIlIIllll, lllllllllllllllIllIIIlllIlIIlllI, lllllllllllllllIllIIIlllIlIIllIl, lllllllllllllllIllIIIlllIlIlIIII.getAlpha());
  }
  
  static Color darker(Color lllllllllllllllIllIIIlllIlIIllII) {
    int lllllllllllllllIllIIIlllIlIIlIll = lllllllllllllllIllIIIlllIlIIllII.getRed();
    int lllllllllllllllIllIIIlllIlIIlIlI = lllllllllllllllIllIIIlllIlIIllII.getGreen();
    int lllllllllllllllIllIIIlllIlIIlIIl = lllllllllllllllIllIIIlllIlIIllII.getBlue();
    lllllllllllllllIllIIIlllIlIIlIll -= 64;
    lllllllllllllllIllIIIlllIlIIlIlI -= 64;
    lllllllllllllllIllIIIlllIlIIlIIl -= 64;
    if (lIIIlIIIIllIIllI(lllllllllllllllIllIIIlllIlIIlIll))
      lllllllllllllllIllIIIlllIlIIlIll = (0x6D ^ 0x6A) << " ".length() << " ".length() & ((0x3B ^ 0x3C) << " ".length() << " ".length() ^ 0xFFFFFFFF); 
    if (lIIIlIIIIllIIllI(lllllllllllllllIllIIIlllIlIIlIlI))
      lllllllllllllllIllIIIlllIlIIlIlI = (0x93 ^ 0x98) & (0x8A ^ 0x81 ^ 0xFFFFFFFF); 
    if (lIIIlIIIIllIIllI(lllllllllllllllIllIIIlllIlIIlIIl))
      lllllllllllllllIllIIIlllIlIIlIIl = (0xA ^ 0xD ^ (0x19 ^ 0xE) << " ".length()) & (0x5A ^ 0x1D ^ (0x0 ^ 0x37) << " ".length() ^ -" ".length()); 
    return new Color(lllllllllllllllIllIIIlllIlIIlIll, lllllllllllllllIllIIIlllIlIIlIlI, lllllllllllllllIllIIIlllIlIIlIIl, lllllllllllllllIllIIIlllIlIIllII.getAlpha());
  }
  
  static {
  
  }
  
  private static boolean lIIIlIIIIllIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 > paramInt2);
  }
  
  private static boolean lIIIlIIIIllIIllI(int paramInt) {
    return (paramInt < 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\Renderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */