package com.lukflug.panelstudio.theme;

import java.awt.Color;

public interface ColorScheme {
  Color getActiveColor();
  
  Color getInactiveColor();
  
  Color getBackgroundColor();
  
  Color getOutlineColor();
  
  Color getFontColor();
  
  int getOpacity();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\ColorScheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */