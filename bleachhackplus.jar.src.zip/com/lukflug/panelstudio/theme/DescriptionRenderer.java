package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;

public interface DescriptionRenderer {
  void renderDescription(Context paramContext);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\DescriptionRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */