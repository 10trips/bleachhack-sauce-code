package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class RendererBase implements Renderer {
  protected final int height;
  
  protected final int offset;
  
  protected final int border;
  
  protected final int left;
  
  protected final int right;
  
  protected ColorScheme scheme;
  
  private static String[] llIIlIIIlIIIIl;
  
  private static Class[] llIIlIIIlIIIlI;
  
  private static final String[] llIIlIIIlIIIll;
  
  private static String[] llIIlIIIlIIlII;
  
  private static final int[] llIIlIIIlIIlIl;
  
  public RendererBase(int lllllllllllllllIllIIlllIlllIlIII, int lllllllllllllllIllIIlllIlllIIlll, int lllllllllllllllIllIIlllIlllIIllI, int lllllllllllllllIllIIlllIlllIIlIl, int lllllllllllllllIllIIlllIlllIIlII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aconst_null
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   11: aload_0
    //   12: iload_1
    //   13: putfield height : I
    //   16: aload_0
    //   17: iload_2
    //   18: putfield offset : I
    //   21: aload_0
    //   22: iload_3
    //   23: putfield border : I
    //   26: aload_0
    //   27: iload #4
    //   29: putfield left : I
    //   32: aload_0
    //   33: iload #5
    //   35: putfield right : I
    //   38: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	39	0	lllllllllllllllIllIIlllIlllIlIIl	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	39	1	lllllllllllllllIllIIlllIlllIlIII	I
    //   0	39	2	lllllllllllllllIllIIlllIlllIIlll	I
    //   0	39	3	lllllllllllllllIllIIlllIlllIIllI	I
    //   0	39	4	lllllllllllllllIllIIlllIlllIIlIl	I
    //   0	39	5	lllllllllllllllIllIIlllIlllIIlII	I
  }
  
  public int getHeight(boolean lllllllllllllllIllIIlllIlllIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/RendererBase;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlllIlllIIIll	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	7	1	lllllllllllllllIllIIlllIlllIIIlI	Z
  }
  
  public int getOffset() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/RendererBase;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlllIlllIIIIl	Lcom/lukflug/panelstudio/theme/RendererBase;
  }
  
  public int getBorder() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/RendererBase;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIlllIlllIIIII	Lcom/lukflug/panelstudio/theme/RendererBase;
  }
  
  public int getBottomBorder() {
    return llIIlIIIlIIlIl[0];
  }
  
  public int getLeftBorder(boolean lllllllllllllllIllIIlllIllIlllIl) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic lIIIIllIIIlIllll : (I)Z
    //   4: ifeq -> 14
    //   7: aload_0
    //   8: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/RendererBase;)I
    //   13: ireturn
    //   14: getstatic com/lukflug/panelstudio/theme/RendererBase.llIIlIIIlIIlIl : [I
    //   17: iconst_0
    //   18: iaload
    //   19: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIIlllIllIllllI	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	20	1	lllllllllllllllIllIIlllIllIlllIl	Z
  }
  
  public int getRightBorder(boolean lllllllllllllllIllIIlllIllIllIll) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic lIIIIllIIIlIllll : (I)Z
    //   4: ifeq -> 14
    //   7: aload_0
    //   8: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/RendererBase;)I
    //   13: ireturn
    //   14: getstatic com/lukflug/panelstudio/theme/RendererBase.llIIlIIIlIIlIl : [I
    //   17: iconst_0
    //   18: iaload
    //   19: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIllIIlllIllIlllII	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	20	1	lllllllllllllllIllIIlllIllIllIll	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIIlllIllIllIIl, String lllllllllllllllIllIIlllIllIllIII, boolean lllllllllllllllIllIIlllIllIlIlll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: getstatic com/lukflug/panelstudio/theme/RendererBase.llIIlIIIlIIlIl : [I
    //   7: iconst_0
    //   8: iaload
    //   9: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
    //   14: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	15	0	lllllllllllllllIllIIlllIllIllIlI	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	15	1	lllllllllllllllIllIIlllIllIllIIl	Lcom/lukflug/panelstudio/Context;
    //   0	15	2	lllllllllllllllIllIIlllIllIllIII	Ljava/lang/String;
    //   0	15	3	lllllllllllllllIllIIlllIllIlIlll	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIIlllIllIlIlIl, String lllllllllllllllIllIIlllIllIlIlII, boolean lllllllllllllllIllIIlllIllIlIIll, boolean lllllllllllllllIllIIlllIllIlIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: iload #4
    //   6: aload_1
    //   7: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
    //   12: getstatic com/lukflug/panelstudio/theme/RendererBase.llIIlIIIlIIlIl : [I
    //   15: iconst_1
    //   16: iaload
    //   17: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZLjava/awt/Rectangle;Z)V
    //   22: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	23	0	lllllllllllllllIllIIlllIllIlIllI	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	23	1	lllllllllllllllIllIIlllIllIlIlIl	Lcom/lukflug/panelstudio/Context;
    //   0	23	2	lllllllllllllllIllIIlllIllIlIlII	Ljava/lang/String;
    //   0	23	3	lllllllllllllllIllIIlllIllIlIIll	Z
    //   0	23	4	lllllllllllllllIllIIlllIllIlIIlI	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIIlllIllIlIIII, String lllllllllllllllIllIIlllIllIIllll, boolean lllllllllllllllIllIIlllIllIIlllI, boolean lllllllllllllllIllIIlllIllIIllIl, boolean lllllllllllllllIllIIlllIllIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: iload #4
    //   6: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIIlllIllIlIIIl	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	12	1	lllllllllllllllIllIIlllIllIlIIII	Lcom/lukflug/panelstudio/Context;
    //   0	12	2	lllllllllllllllIllIIlllIllIIllll	Ljava/lang/String;
    //   0	12	3	lllllllllllllllIllIIlllIllIIlllI	Z
    //   0	12	4	lllllllllllllllIllIIlllIllIIllIl	Z
    //   0	12	5	lllllllllllllllIllIIlllIllIIllII	Z
  }
  
  public int renderScrollBar(Context lllllllllllllllIllIIlllIllIIlIlI, boolean lllllllllllllllIllIIlllIllIIlIIl, boolean lllllllllllllllIllIIlllIllIIlIII, boolean lllllllllllllllIllIIlllIllIIIlll, int lllllllllllllllIllIIlllIllIIIllI, int lllllllllllllllIllIIlllIllIIIlIl) {
    return lllllllllllllllIllIIlllIllIIIlIl;
  }
  
  public Color getFontColor(boolean lllllllllllllllIllIIlllIllIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/theme/RendererBase;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   6: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIIlllIllIIIlII	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	12	1	lllllllllllllllIllIIlllIllIIIIll	Z
  }
  
  public void overrideColorScheme(ColorScheme lllllllllllllllIllIIlllIllIIIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlllIllIIIIlI	Lcom/lukflug/panelstudio/theme/RendererBase;
    //   0	8	1	lllllllllllllllIllIIlllIllIIIIIl	Lcom/lukflug/panelstudio/theme/ColorScheme;
  }
  
  public void restoreColorScheme() {
    // Byte code:
    //   0: aload_0
    //   1: aconst_null
    //   2: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererBase;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIllIIlllIllIIIIII	Lcom/lukflug/panelstudio/theme/RendererBase;
  }
  
  protected ColorScheme getColorScheme() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/RendererBase;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   6: invokestatic lIIIIllIIIllIIII : (Ljava/lang/Object;)Z
    //   9: ifeq -> 19
    //   12: aload_0
    //   13: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/RendererBase;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   18: areturn
    //   19: aload_0
    //   20: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/RendererBase;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   25: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	26	0	lllllllllllllllIllIIlllIlIllllll	Lcom/lukflug/panelstudio/theme/RendererBase;
  }
  
  static {
    lIIIIllIIIlIlllI();
    lIIIIllIIIlIllIl();
    lIIIIllIIIlIllII();
    lIIIIllIIIlIlIII();
  }
  
  private static CallSite lIIIIllIIIlIIlll(MethodHandles.Lookup lllllllllllllllIllIIlllIlIllIllI, String lllllllllllllllIllIIlllIlIllIlIl, MethodType lllllllllllllllIllIIlllIlIllIlII) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIlllIlIllllII = llIIlIIIlIIIIl[Integer.parseInt(lllllllllllllllIllIIlllIlIllIlIl)].split(llIIlIIIlIIIll[llIIlIIIlIIlIl[0]]);
      Class<?> lllllllllllllllIllIIlllIlIlllIll = Class.forName(lllllllllllllllIllIIlllIlIllllII[llIIlIIIlIIlIl[0]]);
      String lllllllllllllllIllIIlllIlIlllIlI = lllllllllllllllIllIIlllIlIllllII[llIIlIIIlIIlIl[1]];
      MethodHandle lllllllllllllllIllIIlllIlIlllIIl = null;
      int lllllllllllllllIllIIlllIlIlllIII = lllllllllllllllIllIIlllIlIllllII[llIIlIIIlIIlIl[2]].length();
      if (lIIIIllIIIllIIIl(lllllllllllllllIllIIlllIlIlllIII, llIIlIIIlIIlIl[3])) {
        MethodType lllllllllllllllIllIIlllIlIlllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIlllIlIllllII[llIIlIIIlIIlIl[3]], RendererBase.class.getClassLoader());
        if (lIIIIllIIIllIIlI(lllllllllllllllIllIIlllIlIlllIII, llIIlIIIlIIlIl[3])) {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findVirtual(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIlllllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findStatic(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIlllllI);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIlllIlIllllIl = llIIlIIIlIIIlI[Integer.parseInt(lllllllllllllllIllIIlllIlIllllII[llIIlIIIlIIlIl[3]])];
        if (lIIIIllIIIllIIlI(lllllllllllllllIllIIlllIlIlllIII, llIIlIIIlIIlIl[2])) {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findGetter(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIllllIl);
          "".length();
          if (" ".length() << " ".length() == 0)
            return null; 
        } else if (lIIIIllIIIllIIlI(lllllllllllllllIllIIlllIlIlllIII, llIIlIIIlIIlIl[4])) {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findStaticGetter(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIllllIl);
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else if (lIIIIllIIIllIIlI(lllllllllllllllIllIIlllIlIlllIII, llIIlIIIlIIlIl[5])) {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findSetter(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIllllIl);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIIlllIlIlllIIl = lllllllllllllllIllIIlllIlIllIllI.findStaticSetter(lllllllllllllllIllIIlllIlIlllIll, lllllllllllllllIllIIlllIlIlllIlI, lllllllllllllllIllIIlllIlIllllIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIlllIlIlllIIl);
    } catch (Exception lllllllllllllllIllIIlllIlIllIlll) {
      lllllllllllllllIllIIlllIlIllIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIIlIlIII() {
    llIIlIIIlIIIIl = new String[llIIlIIIlIIlIl[6]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[5]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[1]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[7]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[3]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[0]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[2]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[8]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[4]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[9]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[5]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[10]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[9]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[2]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[10]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[4]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[8]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[3]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[11]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[12]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[12]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[13]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[13]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[1]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[7]];
    llIIlIIIlIIIIl[llIIlIIIlIIlIl[11]] = llIIlIIIlIIIll[llIIlIIIlIIlIl[6]];
    llIIlIIIlIIIlI = new Class[llIIlIIIlIIlIl[3]];
    llIIlIIIlIIIlI[llIIlIIIlIIlIl[1]] = int.class;
    llIIlIIIlIIIlI[llIIlIIIlIIlIl[0]] = ColorScheme.class;
  }
  
  private static void lIIIIllIIIlIllII() {
    llIIlIIIlIIIll = new String[llIIlIIIlIIlIl[14]];
    llIIlIIIlIIIll[llIIlIIIlIIlIl[0]] = lIIIIllIIIlIlIIl(llIIlIIIlIIlII[llIIlIIIlIIlIl[0]], llIIlIIIlIIlII[llIIlIIIlIIlIl[1]]);
    llIIlIIIlIIIll[llIIlIIIlIIlIl[1]] = lIIIIllIIIlIlIIl(llIIlIIIlIIlII[llIIlIIIlIIlIl[3]], llIIlIIIlIIlII[llIIlIIIlIIlIl[2]]);
    llIIlIIIlIIIll[llIIlIIIlIIlIl[3]] = lIIIIllIIIlIlIlI(llIIlIIIlIIlII[llIIlIIIlIIlIl[4]], llIIlIIIlIIlII[llIIlIIIlIIlIl[5]]);
    llIIlIIIlIIIll[llIIlIIIlIIlIl[2]] = lIIIIllIIIlIlIIl(llIIlIIIlIIlII[llIIlIIIlIIlIl[9]], llIIlIIIlIIlII[llIIlIIIlIIlIl[10]]);
    llIIlIIIlIIIll[llIIlIIIlIIlIl[4]] = lIIIIllIIIlIlIIl("MSciTxsnIykNAjVmPwAZNyQ8FQI2ISBPAzotIgRZAC0hBRIgLT0jFiEtdRMSPCwqEyU3KztbXx4rIAxYPj0kBxsnL2ARFjwtIxIDJywmDlgRJyEVEio8dC0dMz4uThszJihOJCY6Jg8QaRIVLR0zPi5OFiU8YDMSMTwuDxA+LXQ7XgRyb0E=", "RHOaw");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[5]] = lIIIIllIIIlIlIlI("3brrdVrv9+JvqYK/jrPr3LsViB9vpqof9wNjlpfpdyqgpyLpZb8LLccZ71T3Q5OkjGzr2skXdkkxY/5Wb7trRl0ncE72Yu6voxJqkLgX9uCpRKlywhPghni+5n6bPZFq2VYtmWABZazwdz1iNvQDELZupuAC/nkz", "EUQjh");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[9]] = lIIIIllIIIlIlIIl("GSYGYykPIg0hMB1nGywrHyUYOTAeIARjBhUnHyg9DnMMKDEoLAg5f1JgJyckDChELDIOZjkoJg4oBSopH3JRbWU=", "zIkME");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[10]] = lIIIIllIIIlIlIIl("ACQYQz4WIBMBJwRlBQw8BicGGScHIhpDJgsuGAh8MS4bCTcRLgcvMxAuTw89ES8QH2hScVVNcg==", "cKumR");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[8]] = lIIIIllIIIlIlIlI("Iz8y1mA3MchxcLnuFadZH7sMc/z3V3aWP3z4pmn//w9e4zGMa6RNinYY8DXfURJcCxzaaEToDFQ=", "VmWKF");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[11]] = lIIIIllIIIlIlIlI("b6S/S9SwDbYhjjcuXzTpu7Vrs3GupF9dhhxQHLfJJONfCEzKtY2gzWWdM8kC0TNp6vz3shDRS0Q=", "uAUVn");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[12]] = lIIIIllIIIlIlIll("bQrg0+Gj4WND3WmxES4kjex9zsSD6ZJ+cGN1cUrq1E2OGM0jmDYOjA1yXdIG8NPDWqmM5EyeO2qIdtFMzd8y6oI/2C6bv6SRcxBjDmJgSck=", "ZDnCH");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[13]] = lIIIIllIIIlIlIll("QXdS9BdmlrCimL1DVsi5as1uFQMfyGFnmwqnG46nOkuUzanXZc1cQzjj1XGHNujblAyUqapYvzQ=", "mqNAb");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[7]] = lIIIIllIIIlIlIll("YEGuaroOM0ZfB8YFavWf8FI5ba0YqvRVaU8GFpM62EHTzvJNuUuM9cSq+ed7OirHHYcdaRP5u78=", "fivUw");
    llIIlIIIlIIIll[llIIlIIIlIIlIl[6]] = lIIIIllIIIlIlIIl("ICMObR42JwUvByRiEyIcJiAQNwcnJQxtBispDiZcESkNJxcxKREBEzApWSQXNw8MLx0xHwArFy4pWWtbDy8MLl0vOQglHjYrTDMTLSkPMAY2KAosXTckBi4XbA8MLx0xHwArFy4pWHlSYw==", "CLcCr");
    llIIlIIIlIIlII = null;
  }
  
  private static void lIIIIllIIIlIllIl() {
    String str = (new Exception()).getStackTrace()[llIIlIIIlIIlIl[0]].getFileName();
    llIIlIIIlIIlII = str.substring(str.indexOf("ä") + llIIlIIIlIIlIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIIIlIlIll(String lllllllllllllllIllIIlllIlIllIIII, String lllllllllllllllIllIIlllIlIlIllll) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllIlIllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllIlIlIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlllIlIllIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlllIlIllIIlI.init(llIIlIIIlIIlIl[3], lllllllllllllllIllIIlllIlIllIIll);
      return new String(lllllllllllllllIllIIlllIlIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllIlIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllIlIllIIIl) {
      lllllllllllllllIllIIlllIlIllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIIIlIlIlI(String lllllllllllllllIllIIlllIlIlIlIll, String lllllllllllllllIllIIlllIlIlIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIlllIlIlIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllIlIlIlIlI.getBytes(StandardCharsets.UTF_8)), llIIlIIIlIIlIl[8]), "DES");
      Cipher lllllllllllllllIllIIlllIlIlIllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlllIlIlIllIl.init(llIIlIIIlIIlIl[3], lllllllllllllllIllIIlllIlIlIlllI);
      return new String(lllllllllllllllIllIIlllIlIlIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllIlIlIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIlllIlIlIllII) {
      lllllllllllllllIllIIlllIlIlIllII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIIIlIlIIl(String lllllllllllllllIllIIlllIlIlIlIII, String lllllllllllllllIllIIlllIlIlIIlll) {
    lllllllllllllllIllIIlllIlIlIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlllIlIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlllIlIlIIllI = new StringBuilder();
    char[] lllllllllllllllIllIIlllIlIlIIlIl = lllllllllllllllIllIIlllIlIlIIlll.toCharArray();
    int lllllllllllllllIllIIlllIlIlIIlII = llIIlIIIlIIlIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIlllIlIlIlIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIIlIIlIl[0];
    while (lIIIIllIIIllIIll(j, i)) {
      char lllllllllllllllIllIIlllIlIlIlIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIlllIlIlIIlII++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIlllIlIlIIllI);
  }
  
  private static void lIIIIllIIIlIlllI() {
    llIIlIIIlIIlIl = new int[15];
    llIIlIIIlIIlIl[0] = " ".length() << " ".length() << " ".length() & (" ".length() << " ".length() << " ".length() ^ -" ".length());
    llIIlIIIlIIlIl[1] = " ".length();
    llIIlIIIlIIlIl[2] = "   ".length();
    llIIlIIIlIIlIl[3] = " ".length() << " ".length();
    llIIlIIIlIIlIl[4] = " ".length() << " ".length() << " ".length();
    llIIlIIIlIIlIl[5] = 0xA0 ^ 0xA5;
    llIIlIIIlIIlIl[6] = (0x44 ^ 0x1) << " ".length() ^ 3 + 117 - 24 + 39;
    llIIlIIIlIIlIl[7] = "   ".length() << " ".length() << " ".length();
    llIIlIIIlIIlIl[8] = " ".length() << "   ".length();
    llIIlIIIlIIlIl[9] = "   ".length() << " ".length();
    llIIlIIIlIIlIl[10] = (0x5A ^ 0x4B) << " ".length() ^ 0xA3 ^ 0x86;
    llIIlIIIlIIlIl[11] = (0x38 ^ 0x2D) << " ".length() << " ".length() ^ 0x24 ^ 0x79;
    llIIlIIIlIIlIl[12] = ((0x98 ^ 0x9D) << (0x25 ^ 0x20) ^ 120 + 67 - 81 + 59) << " ".length();
    llIIlIIIlIIlIl[13] = 91 + 128 - 100 + 62 ^ (0x14 ^ 0x4B) << " ".length();
    llIIlIIIlIIlIl[14] = (127 + 69 - 46 + 43 ^ (0xC3 ^ 0xA0) << " ".length()) << " ".length();
  }
  
  private static boolean lIIIIllIIIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIIIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIIIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIIIllIIII(Object paramObject) {
    return (paramObject == null);
  }
  
  private static boolean lIIIIllIIIlIllll(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\RendererBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */