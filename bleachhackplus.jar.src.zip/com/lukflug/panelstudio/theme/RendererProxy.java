package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Color;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class RendererProxy implements Renderer {
  private static String[] llIIIlIllIlIll;
  
  private static Class[] llIIIlIllIllII;
  
  private static final String[] llIIIlIllIllIl;
  
  private static String[] llIIIlIlllIIII;
  
  private static final int[] llIIIlIlllIIlI;
  
  public int getHeight(boolean lllllllllllllllIllIlIlIIlIIIllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   12: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIlIIlIIII	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIlIIIllll	Z
  }
  
  public int getOffset() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIlIIlIIIlllI	Lcom/lukflug/panelstudio/theme/RendererProxy;
  }
  
  public int getBorder() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIlIIlIIIllIl	Lcom/lukflug/panelstudio/theme/RendererProxy;
  }
  
  public int getBottomBorder() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIlIIlIIIllII	Lcom/lukflug/panelstudio/theme/RendererProxy;
  }
  
  public int getLeftBorder(boolean lllllllllllllllIllIlIlIIlIIIlIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   12: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIlIIIlIll	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIlIIIlIlI	Z
  }
  
  public int getRightBorder(boolean lllllllllllllllIllIlIlIIlIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   12: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIlIIIlIIl	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIlIIIlIII	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIlIlIIlIIIIllI, String lllllllllllllllIllIlIlIIlIIIIlIl, boolean lllllllllllllllIllIlIlIIlIIIIlII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: aload_2
    //   8: iload_3
    //   9: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;Z)V
    //   14: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	15	0	lllllllllllllllIllIlIlIIlIIIIlll	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	15	1	lllllllllllllllIllIlIlIIlIIIIllI	Lcom/lukflug/panelstudio/Context;
    //   0	15	2	lllllllllllllllIllIlIlIIlIIIIlIl	Ljava/lang/String;
    //   0	15	3	lllllllllllllllIllIlIlIIlIIIIlII	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIlIlIIlIIIIIlI, String lllllllllllllllIllIlIlIIlIIIIIIl, boolean lllllllllllllllIllIlIlIIlIIIIIII, boolean lllllllllllllllIllIlIlIIIlllllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: aload_2
    //   8: iload_3
    //   9: iload #4
    //   11: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
    //   16: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIllIlIlIIlIIIIIll	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	17	1	lllllllllllllllIllIlIlIIlIIIIIlI	Lcom/lukflug/panelstudio/Context;
    //   0	17	2	lllllllllllllllIllIlIlIIlIIIIIIl	Ljava/lang/String;
    //   0	17	3	lllllllllllllllIllIlIlIIlIIIIIII	Z
    //   0	17	4	lllllllllllllllIllIlIlIIIlllllll	Z
  }
  
  public void renderTitle(Context lllllllllllllllIllIlIlIIIlllllIl, String lllllllllllllllIllIlIlIIIlllllII, boolean lllllllllllllllIllIlIlIIIllllIll, boolean lllllllllllllllIllIlIlIIIllllIlI, boolean lllllllllllllllIllIlIlIIIllllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: aload_2
    //   8: iload_3
    //   9: iload #4
    //   11: iload #5
    //   13: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZZ)V
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIllIlIlIIIllllllI	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	19	1	lllllllllllllllIllIlIlIIIlllllIl	Lcom/lukflug/panelstudio/Context;
    //   0	19	2	lllllllllllllllIllIlIlIIIlllllII	Ljava/lang/String;
    //   0	19	3	lllllllllllllllIllIlIlIIIllllIll	Z
    //   0	19	4	lllllllllllllllIllIlIlIIIllllIlI	Z
    //   0	19	5	lllllllllllllllIllIlIlIIIllllIIl	Z
  }
  
  public void renderRect(Context lllllllllllllllIllIlIlIIIlllIlll, String lllllllllllllllIllIlIlIIIlllIllI, boolean lllllllllllllllIllIlIlIIIlllIlIl, boolean lllllllllllllllIllIlIlIIIlllIlII, Rectangle lllllllllllllllIllIlIlIIIlllIIll, boolean lllllllllllllllIllIlIlIIIlllIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: aload_2
    //   8: iload_3
    //   9: iload #4
    //   11: aload #5
    //   13: iload #6
    //   15: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZLjava/awt/Rectangle;Z)V
    //   20: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	21	0	lllllllllllllllIllIlIlIIIllllIII	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	21	1	lllllllllllllllIllIlIlIIIlllIlll	Lcom/lukflug/panelstudio/Context;
    //   0	21	2	lllllllllllllllIllIlIlIIIlllIllI	Ljava/lang/String;
    //   0	21	3	lllllllllllllllIllIlIlIIIlllIlIl	Z
    //   0	21	4	lllllllllllllllIllIlIlIIIlllIlII	Z
    //   0	21	5	lllllllllllllllIllIlIlIIIlllIIll	Ljava/awt/Rectangle;
    //   0	21	6	lllllllllllllllIllIlIlIIIlllIIlI	Z
  }
  
  public void renderBackground(Context lllllllllllllllIllIlIlIIIlllIIII, boolean lllllllllllllllIllIlIlIIIllIllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: iload_2
    //   8: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Z)V
    //   13: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIllIlIlIIIlllIIIl	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	14	1	lllllllllllllllIllIlIlIIIlllIIII	Lcom/lukflug/panelstudio/Context;
    //   0	14	2	lllllllllllllllIllIlIlIIIllIllll	Z
  }
  
  public void renderBorder(Context lllllllllllllllIllIlIlIIIllIllIl, boolean lllllllllllllllIllIlIlIIIllIllII, boolean lllllllllllllllIllIlIlIIIllIlIll, boolean lllllllllllllllIllIlIlIIIllIlIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: iload #4
    //   11: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;ZZZ)V
    //   16: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIllIlIlIIIllIlllI	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	17	1	lllllllllllllllIllIlIlIIIllIllIl	Lcom/lukflug/panelstudio/Context;
    //   0	17	2	lllllllllllllllIllIlIlIIIllIllII	Z
    //   0	17	3	lllllllllllllllIllIlIlIIIllIlIll	Z
    //   0	17	4	lllllllllllllllIllIlIlIIIllIlIlI	Z
  }
  
  public int renderScrollBar(Context lllllllllllllllIllIlIlIIIllIlIII, boolean lllllllllllllllIllIlIlIIIllIIlll, boolean lllllllllllllllIllIlIlIIIllIIllI, boolean lllllllllllllllIllIlIlIIIllIIlIl, int lllllllllllllllIllIlIlIIIllIIlII, int lllllllllllllllIllIlIlIIIllIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: iload #4
    //   11: iload #5
    //   13: iload #6
    //   15: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;ZZZII)I
    //   20: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	21	0	lllllllllllllllIllIlIlIIIllIlIIl	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	21	1	lllllllllllllllIllIlIlIIIllIlIII	Lcom/lukflug/panelstudio/Context;
    //   0	21	2	lllllllllllllllIllIlIlIIIllIIlll	Z
    //   0	21	3	lllllllllllllllIllIlIlIIIllIIllI	Z
    //   0	21	4	lllllllllllllllIllIlIlIIIllIIlIl	Z
    //   0	21	5	lllllllllllllllIllIlIlIIIllIIlII	I
    //   0	21	6	lllllllllllllllIllIlIlIIIllIIIll	I
  }
  
  public Color getMainColor(boolean lllllllllllllllIllIlIlIIIllIIIIl, boolean lllllllllllllllIllIlIlIIIllIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: iload_2
    //   8: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/theme/Renderer;ZZ)Ljava/awt/Color;
    //   13: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIllIlIlIIIllIIIlI	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	14	1	lllllllllllllllIllIlIlIIIllIIIIl	Z
    //   0	14	2	lllllllllllllllIllIlIlIIIllIIIII	Z
  }
  
  public Color getBackgroundColor(boolean lllllllllllllllIllIlIlIIIlIllllI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)Ljava/awt/Color;
    //   12: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIIlIlllll	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIIlIllllI	Z
  }
  
  public Color getFontColor(boolean lllllllllllllllIllIlIlIIIlIlllII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: iload_1
    //   7: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)Ljava/awt/Color;
    //   12: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIIlIlllIl	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIIlIlllII	Z
  }
  
  public ColorScheme getDefaultColorScheme() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/Renderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   11: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIlIIIlIllIll	Lcom/lukflug/panelstudio/theme/RendererProxy;
  }
  
  public void overrideColorScheme(ColorScheme lllllllllllllllIllIlIlIIIlIllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: aload_1
    //   7: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   12: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllIlIlIIIlIllIlI	Lcom/lukflug/panelstudio/theme/RendererProxy;
    //   0	13	1	lllllllllllllllIllIlIlIIIlIllIIl	Lcom/lukflug/panelstudio/theme/ColorScheme;
  }
  
  public void restoreColorScheme() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/RendererProxy;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIlIIIlIllIII	Lcom/lukflug/panelstudio/theme/RendererProxy;
  }
  
  protected abstract Renderer getRenderer();
  
  static {
    lIIIIlIIlIIIIIlI();
    lIIIIlIIIlllllIl();
    lIIIIlIIIlllllII();
    lIIIIlIIIlllIlll();
  }
  
  private static CallSite lIIIIlIIIlllIllI(MethodHandles.Lookup lllllllllllllllIllIlIlIIIlIIllll, String lllllllllllllllIllIlIlIIIlIIlllI, MethodType lllllllllllllllIllIlIlIIIlIIllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlIIIlIlIlIl = llIIIlIllIlIll[Integer.parseInt(lllllllllllllllIllIlIlIIIlIIlllI)].split(llIIIlIllIllIl[llIIIlIlllIIlI[0]]);
      Class<?> lllllllllllllllIllIlIlIIIlIlIlII = Class.forName(lllllllllllllllIllIlIlIIIlIlIlIl[llIIIlIlllIIlI[0]]);
      String lllllllllllllllIllIlIlIIIlIlIIll = lllllllllllllllIllIlIlIIIlIlIlIl[llIIIlIlllIIlI[1]];
      MethodHandle lllllllllllllllIllIlIlIIIlIlIIlI = null;
      int lllllllllllllllIllIlIlIIIlIlIIIl = lllllllllllllllIllIlIlIIIlIlIlIl[llIIIlIlllIIlI[2]].length();
      if (lIIIIlIIlIIIIIll(lllllllllllllllIllIlIlIIIlIlIIIl, llIIIlIlllIIlI[3])) {
        MethodType lllllllllllllllIllIlIlIIIlIlIlll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlIIIlIlIlIl[llIIIlIlllIIlI[3]], RendererProxy.class.getClassLoader());
        if (lIIIIlIIlIIIIlII(lllllllllllllllIllIlIlIIIlIlIIIl, llIIIlIlllIIlI[3])) {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findVirtual(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIlll);
          "".length();
          if (-((0x81 ^ 0x98) << " ".length() << " ".length() ^ "   ".length() << (0x62 ^ 0x67)) >= 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findStatic(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIlll);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlIIIlIlIllI = llIIIlIllIllII[Integer.parseInt(lllllllllllllllIllIlIlIIIlIlIlIl[llIIIlIlllIIlI[3]])];
        if (lIIIIlIIlIIIIlII(lllllllllllllllIllIlIlIIIlIlIIIl, llIIIlIlllIIlI[2])) {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findGetter(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIllI);
          "".length();
          if (-" ".length() > ((29 + 182 - 14 + 18 ^ (0x40 ^ 0x1B) << " ".length()) & (0x17 ^ 0x24 ^ (0xE ^ 0x27) << " ".length() ^ -" ".length()) & ((0x3F ^ 0x76 ^ (0x63 ^ 0x64) << " ".length()) & (55 + 192 - 64 + 28 ^ (0xF ^ 0x2A) << " ".length() << " ".length() ^ -" ".length()) ^ -" ".length())))
            return null; 
        } else if (lIIIIlIIlIIIIlII(lllllllllllllllIllIlIlIIIlIlIIIl, llIIIlIlllIIlI[4])) {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findStaticGetter(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIllI);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (lIIIIlIIlIIIIlII(lllllllllllllllIllIlIlIIIlIlIIIl, llIIIlIlllIIlI[5])) {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findSetter(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIllI);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIlIIIlIlIIlI = lllllllllllllllIllIlIlIIIlIIllll.findStaticSetter(lllllllllllllllIllIlIlIIIlIlIlII, lllllllllllllllIllIlIlIIIlIlIIll, lllllllllllllllIllIlIlIIIlIlIllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlIIIlIlIIlI);
    } catch (Exception lllllllllllllllIllIlIlIIIlIlIIII) {
      lllllllllllllllIllIlIlIIIlIlIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIIlllIlll() {
    llIIIlIllIlIll = new String[llIIIlIlllIIlI[6]];
    llIIIlIllIlIll[llIIIlIlllIIlI[1]] = llIIIlIllIllIl[llIIIlIlllIIlI[1]];
    llIIIlIllIlIll[llIIIlIlllIIlI[7]] = llIIIlIllIllIl[llIIIlIlllIIlI[3]];
    llIIIlIllIlIll[llIIIlIlllIIlI[5]] = llIIIlIllIllIl[llIIIlIlllIIlI[2]];
    llIIIlIllIlIll[llIIIlIlllIIlI[0]] = llIIIlIllIllIl[llIIIlIlllIIlI[4]];
    llIIIlIllIlIll[llIIIlIlllIIlI[8]] = llIIIlIllIllIl[llIIIlIlllIIlI[5]];
    llIIIlIllIlIll[llIIIlIlllIIlI[9]] = llIIIlIllIllIl[llIIIlIlllIIlI[10]];
    llIIIlIllIlIll[llIIIlIlllIIlI[11]] = llIIIlIllIllIl[llIIIlIlllIIlI[12]];
    llIIIlIllIlIll[llIIIlIlllIIlI[13]] = llIIIlIllIllIl[llIIIlIlllIIlI[8]];
    llIIIlIllIlIll[llIIIlIlllIIlI[4]] = llIIIlIllIllIl[llIIIlIlllIIlI[13]];
    llIIIlIllIlIll[llIIIlIlllIIlI[14]] = llIIIlIllIllIl[llIIIlIlllIIlI[7]];
    llIIIlIllIlIll[llIIIlIlllIIlI[2]] = llIIIlIllIllIl[llIIIlIlllIIlI[9]];
    llIIIlIllIlIll[llIIIlIlllIIlI[15]] = llIIIlIllIllIl[llIIIlIlllIIlI[16]];
    llIIIlIllIlIll[llIIIlIlllIIlI[17]] = llIIIlIllIllIl[llIIIlIlllIIlI[14]];
    llIIIlIllIlIll[llIIIlIlllIIlI[18]] = llIIIlIllIllIl[llIIIlIlllIIlI[18]];
    llIIIlIllIlIll[llIIIlIlllIIlI[12]] = llIIIlIllIllIl[llIIIlIlllIIlI[15]];
    llIIIlIllIlIll[llIIIlIlllIIlI[3]] = llIIIlIllIllIl[llIIIlIlllIIlI[19]];
    llIIIlIllIlIll[llIIIlIlllIIlI[16]] = llIIIlIllIllIl[llIIIlIlllIIlI[17]];
    llIIIlIllIlIll[llIIIlIlllIIlI[20]] = llIIIlIllIllIl[llIIIlIlllIIlI[20]];
    llIIIlIllIlIll[llIIIlIlllIIlI[19]] = llIIIlIllIllIl[llIIIlIlllIIlI[11]];
    llIIIlIllIlIll[llIIIlIlllIIlI[10]] = llIIIlIllIllIl[llIIIlIlllIIlI[6]];
    llIIIlIllIllII = new Class[llIIIlIlllIIlI[0]];
  }
  
  private static void lIIIIlIIIlllllII() {
    llIIIlIllIllIl = new String[llIIIlIlllIIlI[21]];
    llIIIlIllIllIl[llIIIlIlllIIlI[0]] = lIIIIlIIIllllIII(llIIIlIlllIIII[llIIIlIlllIIlI[0]], llIIIlIlllIIII[llIIIlIlllIIlI[1]]);
    llIIIlIllIllIl[llIIIlIlllIIlI[1]] = lIIIIlIIIllllIII(llIIIlIlllIIII[llIIIlIlllIIlI[3]], llIIIlIlllIIII[llIIIlIlllIIlI[2]]);
    llIIIlIllIllIl[llIIIlIlllIIlI[3]] = lIIIIlIIIllllIlI(llIIIlIlllIIII[llIIIlIlllIIlI[4]], llIIIlIlllIIII[llIIIlIlllIIlI[5]]);
    llIIIlIllIllIl[llIIIlIlllIIlI[2]] = lIIIIlIIIllllIII(llIIIlIlllIIII[llIIIlIlllIIlI[10]], llIIIlIlllIIII[llIIIlIlllIIlI[12]]);
    llIIIlIllIllIl[llIIIlIlllIIlI[4]] = lIIIIlIIIllllIll("0tFsHykwVVZY/zqUwAl1T0uMbRJ0SEElzJLCollmUt3ZkTItCF/gJCuIam0oIhJ+aEYHwS3hcP8YeA5R6zAVJ/PqS0mnNnO4yyJencv5A8NUnN1Ek8eM2J/D+pwOxIDLJukwDMmO3Qg=", "NnVPc");
    llIIIlIllIllIl[llIIIlIlllIIlI[5]] = lIIIIlIIIllllIII("G2sRGDnpuOBU3/nlixmBaUIXifXThA3+4ymsBcZvip4/NVgwoHj6iU9nsDfhZ6fvleIBMq+XKoAb9JHJwnir0VeKBQer0yX6At/Ln8Ymi+uV/a2FahJ14lu+IvspC2HLgEsbGFbwTSICa/7lOCXxgg==", "ZwBQP");
    llIIIlIllIllIl[llIIIlIlllIIlI[10]] = lIIIIlIIIllllIII("ZsQPCX3sYj3f4E3c+0BIF+MgcTASsr/iXftc2TT9QKHH4VBlIrHREii1+9aURIBe4ByaHt5eOB32IYftXpnwZbQtud66xO5aA9/NpXkdjqDKbHcnW91FjGrRZXkq+xFH3Ds4WuaIjeY=", "wwVaK");
    llIIIlIllIllIl[llIIIlIlllIIlI[12]] = lIIIIlIIIllllIll("51sz49938q1fPezeZIOQ/nahaDCUZ9u3eE2K4aadOtJNZghEodq7rB+iwwrbWPQAVQ34R+Mn2tYUkByOmr+81um3A7wCpzal", "RpjNl");
    llIIIlIllIllIl[llIIIlIlllIIlI[8]] = lIIIIlIIIllllIII("PICCaU5BtzW6mAOlLluh0dELRT9qqJRDyG/m2J+5lRLTqYOtpZ2I+h63Suk+Y8UiHnhYVTY4nqAzx88z3Jx/LQPA2+fL+003AiDZmQoiOnWH29eBt+YSEHjuAGtx2Yj3GTLSeumI0mHJ/MJoSdmycw==", "gxYSB");
    llIIIlIllIllIl[llIIIlIlllIIlI[13]] = lIIIIlIIIllllIll("Z2z3pL2ohSAhsZtB2um2WVxinf1P74RBBhNJ35aIeJg7LmfSNp16BDBIIBryKzX2nhd7nHEjP0njVJE7wPYJWA==", "qcSav");
    llIIIlIllIllIl[llIIIlIlllIIlI[7]] = lIIIIlIIIllllIll("0b7Ni4VV63DjFjPbrhiSnorjdZFqL/rHbzFUEJZKmqxg1oG7PzrIo2gSGRcur3ZZspHU3NY/NEte2bYtQ/Oe3Fg1LevjF+E8VIY2znJjuUloxeIXhvMgHMQotPwkkPYVkQMiDbZOblw=", "wKnHA");
    llIIIlIllIllIl[llIIIlIlllIIlI[9]] = lIIIIlIIIllllIII("E0L2tZDMuWcLddC7jxvtZ6HeuqeYj6bKjM4HKij87BkNApuO6uNd45KUL2DbjIzUrBdlZNV7ML4=", "mSodE");
    llIIIlIllIllIl[llIIIlIlllIIlI[16]] = lIIIIlIIIllllIlI("GQEATyAPBQsNOR1AHQAiHwIeFTkeBwJPOBILAARiKAsDBSkICx9bKx8aLwAvEQkfDjkUCi4OIBUcV0kWUyIHADobQQwWOFUtAg0jCFVXQWw=", "znmaL");
    llIIIlIllIllIl[llIIIlIlllIIlI[14]] = lIIIIlIIIllllIll("0A5p6vmULZxmYYvfnCQJnMHxHUhKU0nYRSk1Dz3DoRY0zCKL5lSE+el8wQaUGoJ8iFLzCTfblylX8hmoO0z5eHCre0bSMl1kLfqDdrlRvol1dQsS0z69Tl97wLK21x4VJwNpMxX/MDJAT400KTmcLw==", "CAltv");
    llIIIlIllIllIl[llIIIlIlllIIlI[18]] = lIIIIlIIIllllIll("wCqeN1uhuC5upvVAJK1FoBDVasCWHmmEYN7cMR/qPzm1x8LS80+2UgihzsiLivuVaL31nUWqtq/wt4XJjuFhNRZwTPS9+9zn4bkkRXr3/4g=", "swcXO");
    llIIIlIllIllIl[llIIIlIlllIIlI[15]] = lIIIIlIIIllllIlI("Ox4GQAItGg0CGz9fGw8APR0YGhs8GARAGjAUBgtAChQFCgsqFBlUHD0fDwscDBgfAgtiWScNATVeBxsFPh0eCUEoEAULAisFHgoHN14oAQAsFBMaVRQbChgPdx0KAAl3Ih8cBzYWUDRHDktLTg==", "Xqknn");
    llIIIlIllIllIl[llIIIlIlllIIlI[19]] = lIIIIlIIIllllIII("mkrK/RI/IxYfCuS3Bi/Gg6nFZFG5bcaieFfn3fK/eT2jU0PWhAu6UKsiXnNO2UiCNN10nYYAF5c=", "PxoXn");
    llIIIlIllIllIl[llIIIlIlllIIlI[17]] = lIIIIlIIIllllIll("eT2omkGq3T48g4LyvXFP8iFcIqYjCW4rvK10UDea4nn+/usnjiuhEqbzAR2S2KyqKYeY3DqLiOaFstn4/etMnNE0mMuaQk546KUQc0pgOUlUS1X7ShXEFZRSL3rAJK+u", "lzPZb");
    llIIIlIllIllIl[llIIIlIlllIIlI[20]] = lIIIIlIIIllllIII("V9Lrd+uoEy6garI5D4fOjQrUo57ZBvZQeFDgOCRl6GV5E8trjpF1hcFs55SqxyWUbpO9wRlOdt9feRO3jq9nh6tP/1dqvBDuQxbWWHoUMrip46Q3lNctrNC8thUrHore6yMMCk4WrMhXl1AQC4xAoQ==", "Sgbsq");
    llIIIlIllIllIl[llIIIlIlllIIlI[11]] = lIIIIlIIIllllIll("h7e1MWsEBQ0PpXURtLPOgQFC2n8uDwMfA+Fz2xoUPEM/uqxMBAH23P5VHbWse62S8xqggI/ZihU4MDwDEqRUgYmvpXKVNH7lrGfQw3hJXmo=", "vfWfA");
    llIIIlIllIllIl[llIIIlIlllIIlI[6]] = lIIIIlIIIllllIll("FLw4AlKAQ4/5cgtySNzGjVwsb761gUGoknWgL02YDNoX/kIEfI6ukKzdoQ8iRBmXvu2iJBDsgbbOV78A3PZIGg==", "NyFNg");
    llIIIlIlllIIII = null;
  }
  
  private static void lIIIIlIIIlllllIl() {
    String str = (new Exception()).getStackTrace()[llIIIlIlllIIlI[0]].getFileName();
    llIIIlIlllIIII = str.substring(str.indexOf("ä") + llIIIlIlllIIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIIllllIll(String lllllllllllllllIllIlIlIIIlIIlIIl, String lllllllllllllllIllIlIlIIIlIIlIII) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIIIlIIllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIIlIIlIII.getBytes(StandardCharsets.UTF_8)), llIIIlIlllIIlI[8]), "DES");
      Cipher lllllllllllllllIllIlIlIIIlIIlIll = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlIIIlIIlIll.init(llIIIlIlllIIlI[3], lllllllllllllllIllIlIlIIIlIIllII);
      return new String(lllllllllllllllIllIlIlIIIlIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIlIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIIIlIIlIlI) {
      lllllllllllllllIllIlIlIIIlIIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIIllllIlI(String lllllllllllllllIllIlIlIIIlIIIllI, String lllllllllllllllIllIlIlIIIlIIIlIl) {
    lllllllllllllllIllIlIlIIIlIIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIlIIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlIIIlIIIlII = new StringBuilder();
    char[] lllllllllllllllIllIlIlIIIlIIIIll = lllllllllllllllIllIlIlIIIlIIIlIl.toCharArray();
    int lllllllllllllllIllIlIlIIIlIIIIlI = llIIIlIlllIIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIlIIIlIIIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIlllIIlI[0];
    while (lIIIIlIIlIIIIllI(j, i)) {
      char lllllllllllllllIllIlIlIIIlIIIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIlIIIlIIIIlI++;
      j++;
      "".length();
      if (-"   ".length() >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlIIIlIIIlII);
  }
  
  private static String lIIIIlIIIllllIII(String lllllllllllllllIllIlIlIIIIlllllI, String lllllllllllllllIllIlIlIIIIllllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIIIlIIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIIIllllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlIIIlIIIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlIIIlIIIIII.init(llIIIlIlllIIlI[3], lllllllllllllllIllIlIlIIIlIIIIIl);
      return new String(lllllllllllllllIllIlIlIIIlIIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIIlllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIIIIllllll) {
      lllllllllllllllIllIlIlIIIIllllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIlIIIIIlI() {
    llIIIlIlllIIlI = new int[22];
    llIIIlIlllIIlI[0] = (74 + 13 - 74 + 118 ^ (0x3C ^ 0x2B) << "   ".length()) & (5 + 115 - -38 + 25 ^ (0x3 ^ 0x20) << " ".length() << " ".length() ^ -" ".length());
    llIIIlIlllIIlI[1] = " ".length();
    llIIIlIlllIIlI[2] = "   ".length();
    llIIIlIlllIIlI[3] = " ".length() << " ".length();
    llIIIlIlllIIlI[4] = " ".length() << " ".length() << " ".length();
    llIIIlIlllIIlI[5] = (0x97 ^ 0xBC) << " ".length() << " ".length() ^ 157 + 89 - 232 + 155;
    llIIIlIlllIIlI[6] = ((0x41 ^ 0x16) << " ".length() ^ 88 + 126 - 212 + 169) << " ".length() << " ".length();
    llIIIlIlllIIlI[7] = (26 + 44 - -36 + 29 ^ (0x21 ^ 0x60) << " ".length()) << " ".length();
    llIIIlIlllIIlI[8] = " ".length() << "   ".length();
    llIIIlIlllIIlI[9] = 0x23 ^ 0x28;
    llIIIlIlllIIlI[10] = "   ".length() << " ".length();
    llIIIlIlllIIlI[11] = 0x30 ^ 0x69 ^ (0x5F ^ 0x7A) << " ".length();
    llIIIlIlllIIlI[12] = 0x49 ^ 0x4E;
    llIIIlIlllIIlI[13] = 0x74 ^ 0x7D;
    llIIIlIlllIIlI[14] = 0xAA ^ 0x81 ^ (0x89 ^ 0x9A) << " ".length();
    llIIIlIlllIIlI[15] = 0x1A ^ 0x15;
    llIIIlIlllIIlI[16] = "   ".length() << " ".length() << " ".length();
    llIIIlIlllIIlI[17] = 0xBE ^ 0xAF;
    llIIIlIlllIIlI[18] = ((0x74 ^ 0x71) << " ".length() ^ 0x70 ^ 0x7D) << " ".length();
    llIIIlIlllIIlI[19] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIIlIlllIIlI[20] = ((0x9C ^ 0x87) << " ".length() ^ 0xBD ^ 0x82) << " ".length();
    llIIIlIlllIIlI[21] = (0xF0 ^ 0xB3) << " ".length() ^ 121 + 48 - 123 + 101;
  }
  
  private static boolean lIIIIlIIlIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIlIIIIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIlIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\RendererProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */