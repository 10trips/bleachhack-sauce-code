package com.lukflug.panelstudio.theme;

public interface Theme {
  Renderer getPanelRenderer();
  
  Renderer getContainerRenderer();
  
  Renderer getComponentRenderer();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\Theme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */