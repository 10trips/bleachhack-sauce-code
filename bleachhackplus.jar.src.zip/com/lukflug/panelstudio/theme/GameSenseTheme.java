package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Color;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class GameSenseTheme implements Theme {
  protected ColorScheme scheme;
  
  protected Renderer componentRenderer;
  
  protected Renderer containerRenderer;
  
  protected Renderer panelRenderer;
  
  private static String[] lIllIllIIIlIII;
  
  private static Class[] lIllIllIIIlIIl;
  
  private static final String[] lIllIllIIIlIlI;
  
  private static String[] lIllIllIIIlIll;
  
  private static final int[] lIllIllIIIllII;
  
  public GameSenseTheme(ColorScheme lllllllllllllllIllllIIllllllIlll, int lllllllllllllllIllllIIllllllIllI, int lllllllllllllllIllllIIllllllIlIl, int lllllllllllllllIllllIIllllllIlII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   11: aload_0
    //   12: new com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer
    //   15: dup
    //   16: aload_0
    //   17: getstatic com/lukflug/panelstudio/theme/GameSenseTheme.lIllIllIIIllII : [I
    //   20: iconst_0
    //   21: iaload
    //   22: iload_2
    //   23: iload_3
    //   24: iload #4
    //   26: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;IIII)V
    //   29: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   34: aload_0
    //   35: new com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer
    //   38: dup
    //   39: aload_0
    //   40: getstatic com/lukflug/panelstudio/theme/GameSenseTheme.lIllIllIIIllII : [I
    //   43: iconst_1
    //   44: iaload
    //   45: iload_2
    //   46: iload_3
    //   47: iload #4
    //   49: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;IIII)V
    //   52: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   57: aload_0
    //   58: new com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer
    //   61: dup
    //   62: aload_0
    //   63: getstatic com/lukflug/panelstudio/theme/GameSenseTheme.lIllIllIIIllII : [I
    //   66: iconst_2
    //   67: iaload
    //   68: iload_2
    //   69: iload_3
    //   70: iload #4
    //   72: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;IIII)V
    //   75: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   80: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	81	0	lllllllllllllllIllllIIlllllllIII	Lcom/lukflug/panelstudio/theme/GameSenseTheme;
    //   0	81	1	lllllllllllllllIllllIIllllllIlll	Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   0	81	2	lllllllllllllllIllllIIllllllIllI	I
    //   0	81	3	lllllllllllllllIllllIIllllllIlIl	I
    //   0	81	4	lllllllllllllllIllllIIllllllIlII	I
  }
  
  public Renderer getPanelRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIllllllIIll	Lcom/lukflug/panelstudio/theme/GameSenseTheme;
  }
  
  public Renderer getContainerRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIllllllIIlI	Lcom/lukflug/panelstudio/theme/GameSenseTheme;
  }
  
  public Renderer getComponentRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllllIIllllllIIIl	Lcom/lukflug/panelstudio/theme/GameSenseTheme;
  }
  
  static {
    llllIlIIllIlIIl();
    llllIlIIllIlIII();
    llllIlIIllIIlll();
    llllIlIIllIIIll();
  }
  
  private static CallSite llllIlIIllIIIlI(MethodHandles.Lookup lllllllllllllllIllllIIlllllIlIII, String lllllllllllllllIllllIIlllllIIlll, MethodType lllllllllllllllIllllIIlllllIIllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIlllllIlllI = lIllIllIIIlIII[Integer.parseInt(lllllllllllllllIllllIIlllllIIlll)].split(lIllIllIIIlIlI[lIllIllIIIllII[0]]);
      Class<?> lllllllllllllllIllllIIlllllIllIl = Class.forName(lllllllllllllllIllllIIlllllIlllI[lIllIllIIIllII[0]]);
      String lllllllllllllllIllllIIlllllIllII = lllllllllllllllIllllIIlllllIlllI[lIllIllIIIllII[1]];
      MethodHandle lllllllllllllllIllllIIlllllIlIll = null;
      int lllllllllllllllIllllIIlllllIlIlI = lllllllllllllllIllllIIlllllIlllI[lIllIllIIIllII[3]].length();
      if (llllIlIIllIlIlI(lllllllllllllllIllllIIlllllIlIlI, lIllIllIIIllII[2])) {
        MethodType lllllllllllllllIllllIIllllllIIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIlllllIlllI[lIllIllIIIllII[2]], GameSenseTheme.class.getClassLoader());
        if (llllIlIIllIlIll(lllllllllllllllIllllIIlllllIlIlI, lIllIllIIIllII[2])) {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findVirtual(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIllllllIIII);
          "".length();
          if ("   ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findStatic(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIllllllIIII);
        } 
        "".length();
        if (-"  ".length() >= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIlllllIllll = lIllIllIIIlIIl[Integer.parseInt(lllllllllllllllIllllIIlllllIlllI[lIllIllIIIllII[2]])];
        if (llllIlIIllIlIll(lllllllllllllllIllllIIlllllIlIlI, lIllIllIIIllII[3])) {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findGetter(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIlllllIllll);
          "".length();
          if ("   ".length() < -" ".length())
            return null; 
        } else if (llllIlIIllIlIll(lllllllllllllllIllllIIlllllIlIlI, lIllIllIIIllII[4])) {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findStaticGetter(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIlllllIllll);
          "".length();
          if (null != null)
            return null; 
        } else if (llllIlIIllIlIll(lllllllllllllllIllllIIlllllIlIlI, lIllIllIIIllII[5])) {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findSetter(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIlllllIllll);
          "".length();
          if (" ".length() << " ".length() << " ".length() != " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIlllllIlIll = lllllllllllllllIllllIIlllllIlIII.findStaticSetter(lllllllllllllllIllllIIlllllIllIl, lllllllllllllllIllllIIlllllIllII, lllllllllllllllIllllIIlllllIllll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIlllllIlIll);
    } catch (Exception lllllllllllllllIllllIIlllllIlIIl) {
      lllllllllllllllIllllIIlllllIlIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIllIIIll() {
    lIllIllIIIlIII = new String[lIllIllIIIllII[6]];
    lIllIllIIIlIII[lIllIllIIIllII[4]] = lIllIllIIIlIlI[lIllIllIIIllII[1]];
    lIllIllIIIlIII[lIllIllIIIllII[0]] = lIllIllIIIlIlI[lIllIllIIIllII[2]];
    lIllIllIIIlIII[lIllIllIIIllII[5]] = lIllIllIIIlIlI[lIllIllIIIllII[3]];
    lIllIllIIIlIII[lIllIllIIIllII[2]] = lIllIllIIIlIlI[lIllIllIIIllII[4]];
    lIllIllIIIlIII[lIllIllIIIllII[3]] = lIllIllIIIlIlI[lIllIllIIIllII[5]];
    lIllIllIIIlIII[lIllIllIIIllII[7]] = lIllIllIIIlIlI[lIllIllIIIllII[7]];
    lIllIllIIIlIII[lIllIllIIIllII[1]] = lIllIllIIIlIlI[lIllIllIIIllII[6]];
    lIllIllIIIlIIl = new Class[lIllIllIIIllII[2]];
    lIllIllIIIlIIl[lIllIllIIIllII[0]] = ColorScheme.class;
    lIllIllIIIlIIl[lIllIllIIIllII[1]] = Renderer.class;
  }
  
  private static void llllIlIIllIIlll() {
    lIllIllIIIlIlI = new String[lIllIllIIIllII[8]];
    lIllIllIIIlIlI[lIllIllIIIllII[0]] = llllIlIIllIIlII(lIllIllIIIlIll[lIllIllIIIllII[0]], lIllIllIIIlIll[lIllIllIIIllII[1]]);
    lIllIllIIIlIlI[lIllIllIIIllII[1]] = llllIlIIllIIlII(lIllIllIIIlIll[lIllIllIIIllII[2]], lIllIllIIIlIll[lIllIllIIIllII[3]]);
    lIllIllIIIlIlI[lIllIllIIIllII[2]] = llllIlIIllIIlIl(lIllIllIIIlIll[lIllIllIIIllII[4]], lIllIllIIIlIll[lIllIllIIIllII[5]]);
    lIllIllIIIlIlI[lIllIllIIIllII[3]] = llllIlIIllIIllI(lIllIllIIIlIll[lIllIllIIIllII[7]], lIllIllIIIlIll[lIllIllIIIllII[6]]);
    lIllIllIIIlIlI[lIllIllIIIllII[4]] = llllIlIIllIIlIl(lIllIllIIIlIll[lIllIllIIIllII[8]], lIllIllIIIlIll[lIllIllIIIllII[9]]);
    lIllIllIIIlIlI[lIllIllIIIllII[5]] = llllIlIIllIIllI("Tk7WTdNqtmkPRKLeS1GCTQoN5G2ixvGnz4Jpc21b2wfQ3UyWuAwta4XukMdedGzWo43NQgguAXJBVdWSmQ5TgpNkfzPJBUOV", "eHmMc");
    lIllIllIIIlIlI[lIllIllIIIllII[7]] = llllIlIIllIIlII("r6LZtzRvipc53sdItnmn8ov0fY2oF3sZQGrhWhpt93MRNUl578lW28T7robYSSOVPoTzseED2FZVSCqsF96htvnIlrLBDMR5", "iDalB");
    lIllIllIIIlIlI[lIllIllIIIllII[6]] = llllIlIIllIIlII("vzqlgyp9sSkL1oKc55eiEtxu7klIOfW0NcfDlQ3sTnJ9qECQkGk63xAs9vsLnPq2PWJMQgPaQTzF5Zn5jH0+YaF24AuqFAwg", "iqlbW");
    lIllIllIIIlIll = null;
  }
  
  private static void llllIlIIllIlIII() {
    String str = (new Exception()).getStackTrace()[lIllIllIIIllII[0]].getFileName();
    lIllIllIIIlIll = str.substring(str.indexOf("ä") + lIllIllIIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIIllIIlII(String lllllllllllllllIllllIIlllllIIIlI, String lllllllllllllllIllllIIlllllIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlllllIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlllllIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIlllllIIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIlllllIIlII.init(lIllIllIIIllII[2], lllllllllllllllIllllIIlllllIIlIl);
      return new String(lllllllllllllllIllllIIlllllIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlllllIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlllllIIIll) {
      lllllllllllllllIllllIIlllllIIIll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIIllIIlIl(String lllllllllllllllIllllIIllllIlllll, String lllllllllllllllIllllIIllllIllllI) {
    lllllllllllllllIllllIIllllIlllll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIllllIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIllllIlllIl = new StringBuilder();
    char[] lllllllllllllllIllllIIllllIlllII = lllllllllllllllIllllIIllllIllllI.toCharArray();
    int lllllllllllllllIllllIIllllIllIll = lIllIllIIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIllllIlllll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllIIIllII[0];
    while (llllIlIIllIllII(j, i)) {
      char lllllllllllllllIllllIIlllllIIIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIllllIllIll++;
      j++;
      "".length();
      if (((111 + 45 - 115 + 132 ^ (0x6D ^ 0x38) << " ".length()) << "   ".length() & (("   ".length() << " ".length() << " ".length() ^ 0x7D ^ 0x76) << "   ".length() ^ -" ".length())) != (((0x36 ^ 0x27) << "   ".length() ^ 90 + 92 - 153 + 104) << " ".length() & (((0x6 ^ 0x4D) << " ".length() ^ 25 + 9 - -73 + 48) << " ".length() ^ -" ".length())))
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIllllIlllIl);
  }
  
  private static String llllIlIIllIIllI(String lllllllllllllllIllllIIllllIlIlll, String lllllllllllllllIllllIIllllIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllllIIllllIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIllllIlIllI.getBytes(StandardCharsets.UTF_8)), lIllIllIIIllII[8]), "DES");
      Cipher lllllllllllllllIllllIIllllIllIIl = Cipher.getInstance("DES");
      lllllllllllllllIllllIIllllIllIIl.init(lIllIllIIIllII[2], lllllllllllllllIllllIIllllIllIlI);
      return new String(lllllllllllllllIllllIIllllIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIllllIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIllllIllIII) {
      lllllllllllllllIllllIIllllIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIIllIlIIl() {
    lIllIllIIIllII = new int[10];
    lIllIllIIIllII[0] = ((0x66 ^ 0x61) << " ".length() << " ".length() ^ 0xA2 ^ 0xB7) & (0xCF ^ 0x8E ^ (0x55 ^ 0x5C) << "   ".length() ^ -" ".length());
    lIllIllIIIllII[1] = " ".length();
    lIllIllIIIllII[2] = " ".length() << " ".length();
    lIllIllIIIllII[3] = "   ".length();
    lIllIllIIIllII[4] = " ".length() << " ".length() << " ".length();
    lIllIllIIIllII[5] = 0xBA ^ 0xBF;
    lIllIllIIIllII[6] = 0xFB ^ 0xBC ^ " ".length() << "   ".length() << " ".length();
    lIllIllIIIllII[7] = "   ".length() << " ".length();
    lIllIllIIIllII[8] = " ".length() << "   ".length();
    lIllIllIIIllII[9] = 0x59 ^ 0x50;
  }
  
  private static boolean llllIlIIllIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIIllIllII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIIllIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  protected class ComponentRenderer extends RendererBase {
    protected final int level;
    
    protected final int border;
    
    private static String[] llIIIIlllIllll;
    
    private static Class[] llIIIIllllIIII;
    
    private static final String[] llIIIlIlIlIlII;
    
    private static String[] llIIIlIlIlIlIl;
    
    private static final int[] llIIIlIlIlIllI;
    
    public ComponentRenderer(int lllllllllllllllIllIlIlIlIllIIlll, int lllllllllllllllIllIlIlIlIllIIllI, int lllllllllllllllIllIlIlIlIllIIlIl, int lllllllllllllllIllIlIlIlIllIIlII) {
      super(lllllllllllllllIllIlIlIlIllIIllI + llIIIlIlIlIllI[0] * lllllllllllllllIllIlIlIlIllIIlIl, llIIIlIlIlIllI[1], llIIIlIlIlIllI[1], llIIIlIlIlIllI[1], lllllllllllllllIllIlIlIlIllIIlII);
      this.level = lllllllllllllllIllIlIlIlIllIIlll;
      this.border = lllllllllllllllIllIlIlIlIllIIlIl;
    }
    
    public void renderRect(Context lllllllllllllllIllIlIlIlIllIIIII, String lllllllllllllllIllIlIlIlIlIlllll, boolean lllllllllllllllIllIlIlIlIlIllllI, boolean lllllllllllllllIllIlIlIlIlIlllIl, Rectangle lllllllllllllllIllIlIlIlIlIlllII, boolean lllllllllllllllIllIlIlIlIlIllIll) {
      // Byte code:
      //   0: aload_0
      //   1: iload_3
      //   2: iload #4
      //   4: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;ZZ)Ljava/awt/Color;
      //   9: astore #7
      //   11: aload_1
      //   12: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   17: aload #5
      //   19: aload #7
      //   21: aload #7
      //   23: aload #7
      //   25: aload #7
      //   27: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   32: iload #6
      //   34: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   37: ifeq -> 156
      //   40: aload_1
      //   41: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Z
      //   46: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   49: ifeq -> 102
      //   52: new java/awt/Color
      //   55: dup
      //   56: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   59: iconst_2
      //   60: iaload
      //   61: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   64: iconst_2
      //   65: iaload
      //   66: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   69: iconst_2
      //   70: iaload
      //   71: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   74: iconst_3
      //   75: iaload
      //   76: invokespecial <init> : (IIII)V
      //   79: astore #8
      //   81: ldc ''
      //   83: invokevirtual length : ()I
      //   86: pop
      //   87: ldc '   '
      //   89: invokevirtual length : ()I
      //   92: ldc ' '
      //   94: invokevirtual length : ()I
      //   97: ineg
      //   98: if_icmpgt -> 131
      //   101: return
      //   102: new java/awt/Color
      //   105: dup
      //   106: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   109: iconst_2
      //   110: iaload
      //   111: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   114: iconst_2
      //   115: iaload
      //   116: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   119: iconst_2
      //   120: iaload
      //   121: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   124: iconst_1
      //   125: iaload
      //   126: invokespecial <init> : (IIII)V
      //   129: astore #8
      //   131: aload_1
      //   132: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   137: aload_1
      //   138: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
      //   143: aload #8
      //   145: aload #8
      //   147: aload #8
      //   149: aload #8
      //   151: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   156: new java/awt/Point
      //   159: dup
      //   160: aload #5
      //   162: <illegal opcode> 5 : (Ljava/awt/Rectangle;)Ljava/awt/Point;
      //   167: invokespecial <init> : (Ljava/awt/Point;)V
      //   170: astore #8
      //   172: aload #8
      //   174: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   177: iconst_1
      //   178: iaload
      //   179: aload_0
      //   180: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)I
      //   185: <illegal opcode> 7 : (Ljava/awt/Point;II)V
      //   190: aload_1
      //   191: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   196: aload #8
      //   198: aload_2
      //   199: aload_0
      //   200: iload_3
      //   201: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   206: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
      //   211: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   81	21	8	lllllllllllllllIllIlIlIlIllIIIll	Ljava/awt/Color;
      //   131	25	8	lllllllllllllllIllIlIlIlIllIIIlI	Ljava/awt/Color;
      //   0	212	0	lllllllllllllllIllIlIlIlIllIIIIl	Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;
      //   0	212	1	lllllllllllllllIllIlIlIlIllIIIII	Lcom/lukflug/panelstudio/Context;
      //   0	212	2	lllllllllllllllIllIlIlIlIlIlllll	Ljava/lang/String;
      //   0	212	3	lllllllllllllllIllIlIlIlIlIllllI	Z
      //   0	212	4	lllllllllllllllIllIlIlIlIlIlllIl	Z
      //   0	212	5	lllllllllllllllIllIlIlIlIlIlllII	Ljava/awt/Rectangle;
      //   0	212	6	lllllllllllllllIllIlIlIlIlIllIll	Z
      //   11	201	7	lllllllllllllllIllIlIlIlIlIllIlI	Ljava/awt/Color;
      //   172	40	8	lllllllllllllllIllIlIlIlIlIllIIl	Ljava/awt/Point;
    }
    
    public void renderBackground(Context lllllllllllllllIllIlIlIlIlIlIlll, boolean lllllllllllllllIllIlIlIlIlIlIllI) {}
    
    public void renderBorder(Context lllllllllllllllIllIlIlIlIlIlIlII, boolean lllllllllllllllIllIlIlIlIlIlIIll, boolean lllllllllllllllIllIlIlIlIlIlIIlI, boolean lllllllllllllllIllIlIlIlIlIlIIIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: astore #5
      //   13: aload_0
      //   14: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)I
      //   19: invokestatic lIIIIlIIIIlllIlI : (I)Z
      //   22: ifeq -> 231
      //   25: aload_1
      //   26: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   31: new java/awt/Rectangle
      //   34: dup
      //   35: aload_1
      //   36: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   41: new java/awt/Dimension
      //   44: dup
      //   45: aload_1
      //   46: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   51: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   56: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   59: iconst_4
      //   60: iaload
      //   61: invokespecial <init> : (II)V
      //   64: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   67: aload #5
      //   69: aload #5
      //   71: aload #5
      //   73: aload #5
      //   75: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   80: aload_1
      //   81: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   86: new java/awt/Rectangle
      //   89: dup
      //   90: aload_1
      //   91: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   96: new java/awt/Dimension
      //   99: dup
      //   100: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   103: iconst_4
      //   104: iaload
      //   105: aload_1
      //   106: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   111: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   116: invokespecial <init> : (II)V
      //   119: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   122: aload #5
      //   124: aload #5
      //   126: aload #5
      //   128: aload #5
      //   130: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   135: aload_1
      //   136: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   141: new java/awt/Rectangle
      //   144: dup
      //   145: new java/awt/Point
      //   148: dup
      //   149: aload_1
      //   150: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   155: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   160: aload_1
      //   161: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   166: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   171: iadd
      //   172: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   175: iconst_4
      //   176: iaload
      //   177: isub
      //   178: aload_1
      //   179: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   184: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   189: invokespecial <init> : (II)V
      //   192: new java/awt/Dimension
      //   195: dup
      //   196: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   199: iconst_4
      //   200: iaload
      //   201: aload_1
      //   202: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   207: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   212: invokespecial <init> : (II)V
      //   215: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   218: aload #5
      //   220: aload #5
      //   222: aload #5
      //   224: aload #5
      //   226: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   231: aload_0
      //   232: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)I
      //   237: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   240: ifeq -> 251
      //   243: iload #4
      //   245: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   248: ifeq -> 440
      //   251: aload_1
      //   252: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   257: new java/awt/Rectangle
      //   260: dup
      //   261: new java/awt/Point
      //   264: dup
      //   265: aload_1
      //   266: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   271: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   276: aload_1
      //   277: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   282: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   287: aload_1
      //   288: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   293: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   298: iadd
      //   299: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   302: iconst_4
      //   303: iaload
      //   304: isub
      //   305: invokespecial <init> : (II)V
      //   308: new java/awt/Dimension
      //   311: dup
      //   312: aload_1
      //   313: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   318: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   323: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   326: iconst_4
      //   327: iaload
      //   328: invokespecial <init> : (II)V
      //   331: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   334: aload #5
      //   336: aload #5
      //   338: aload #5
      //   340: aload #5
      //   342: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   347: aload_1
      //   348: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   353: new java/awt/Rectangle
      //   356: dup
      //   357: new java/awt/Point
      //   360: dup
      //   361: aload_1
      //   362: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   367: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   372: aload_1
      //   373: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   378: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   383: aload_0
      //   384: iload #4
      //   386: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   391: iadd
      //   392: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   395: iconst_4
      //   396: iaload
      //   397: isub
      //   398: invokespecial <init> : (II)V
      //   401: new java/awt/Dimension
      //   404: dup
      //   405: aload_1
      //   406: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   411: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   416: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   419: iconst_4
      //   420: iaload
      //   421: invokespecial <init> : (II)V
      //   424: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   427: aload #5
      //   429: aload #5
      //   431: aload #5
      //   433: aload #5
      //   435: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   440: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	441	0	lllllllllllllllIllIlIlIlIlIlIlIl	Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;
      //   0	441	1	lllllllllllllllIllIlIlIlIlIlIlII	Lcom/lukflug/panelstudio/Context;
      //   0	441	2	lllllllllllllllIllIlIlIlIlIlIIll	Z
      //   0	441	3	lllllllllllllllIllIlIlIlIlIlIIlI	Z
      //   0	441	4	lllllllllllllllIllIlIlIlIlIlIIIl	Z
      //   13	428	5	lllllllllllllllIllIlIlIlIlIlIIII	Ljava/awt/Color;
    }
    
    public int renderScrollBar(Context lllllllllllllllIllIlIlIlIlIIlIII, boolean lllllllllllllllIllIlIlIlIlIIIlll, boolean lllllllllllllllIllIlIlIlIlIIIllI, boolean lllllllllllllllIllIlIlIlIlIIIlIl, int lllllllllllllllIllIlIlIlIlIIIlII, int lllllllllllllllIllIlIlIlIlIIIIll) {
      // Byte code:
      //   0: iload #4
      //   2: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   5: ifeq -> 730
      //   8: aload_1
      //   9: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   14: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   19: aload_0
      //   20: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   23: iconst_4
      //   24: iaload
      //   25: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   30: isub
      //   31: istore #7
      //   33: iload #6
      //   35: i2d
      //   36: iload #5
      //   38: i2d
      //   39: ddiv
      //   40: iload #7
      //   42: i2d
      //   43: dmul
      //   44: d2i
      //   45: istore #8
      //   47: iload #6
      //   49: iload #7
      //   51: iadd
      //   52: i2d
      //   53: iload #5
      //   55: i2d
      //   56: ddiv
      //   57: iload #7
      //   59: i2d
      //   60: dmul
      //   61: d2i
      //   62: istore #9
      //   64: aload_0
      //   65: iload_2
      //   66: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   69: iconst_1
      //   70: iaload
      //   71: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;ZZ)Ljava/awt/Color;
      //   76: astore #10
      //   78: aload_0
      //   79: iload_2
      //   80: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   83: iconst_4
      //   84: iaload
      //   85: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;ZZ)Ljava/awt/Color;
      //   90: astore #11
      //   92: aload_1
      //   93: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   98: new java/awt/Rectangle
      //   101: dup
      //   102: new java/awt/Point
      //   105: dup
      //   106: aload_1
      //   107: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   112: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   117: aload_1
      //   118: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   123: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   128: iadd
      //   129: aload_0
      //   130: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   133: iconst_4
      //   134: iaload
      //   135: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   140: isub
      //   141: aload_1
      //   142: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   147: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   152: aload_0
      //   153: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   156: iconst_4
      //   157: iaload
      //   158: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   163: iadd
      //   164: invokespecial <init> : (II)V
      //   167: new java/awt/Dimension
      //   170: dup
      //   171: aload_0
      //   172: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   175: iconst_4
      //   176: iaload
      //   177: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   182: iload #8
      //   184: invokespecial <init> : (II)V
      //   187: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   190: aload #10
      //   192: aload #10
      //   194: aload #10
      //   196: aload #10
      //   198: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   203: aload_1
      //   204: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   209: new java/awt/Rectangle
      //   212: dup
      //   213: new java/awt/Point
      //   216: dup
      //   217: aload_1
      //   218: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   223: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   228: aload_1
      //   229: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   234: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   239: iadd
      //   240: aload_0
      //   241: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   244: iconst_4
      //   245: iaload
      //   246: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   251: isub
      //   252: aload_1
      //   253: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   258: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   263: aload_0
      //   264: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   267: iconst_4
      //   268: iaload
      //   269: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   274: iadd
      //   275: iload #8
      //   277: iadd
      //   278: invokespecial <init> : (II)V
      //   281: new java/awt/Dimension
      //   284: dup
      //   285: aload_0
      //   286: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   289: iconst_4
      //   290: iaload
      //   291: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   296: iload #9
      //   298: iload #8
      //   300: isub
      //   301: invokespecial <init> : (II)V
      //   304: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   307: aload #11
      //   309: aload #11
      //   311: aload #11
      //   313: aload #11
      //   315: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   320: aload_1
      //   321: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   326: new java/awt/Rectangle
      //   329: dup
      //   330: new java/awt/Point
      //   333: dup
      //   334: aload_1
      //   335: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   340: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   345: aload_1
      //   346: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   351: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   356: iadd
      //   357: aload_0
      //   358: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   361: iconst_4
      //   362: iaload
      //   363: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   368: isub
      //   369: aload_1
      //   370: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   375: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   380: aload_0
      //   381: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   384: iconst_4
      //   385: iaload
      //   386: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   391: iadd
      //   392: iload #9
      //   394: iadd
      //   395: invokespecial <init> : (II)V
      //   398: new java/awt/Dimension
      //   401: dup
      //   402: aload_0
      //   403: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   406: iconst_4
      //   407: iaload
      //   408: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   413: aload_1
      //   414: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   419: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   424: aload_0
      //   425: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   428: iconst_4
      //   429: iaload
      //   430: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   435: isub
      //   436: iload #9
      //   438: isub
      //   439: invokespecial <init> : (II)V
      //   442: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   445: aload #10
      //   447: aload #10
      //   449: aload #10
      //   451: aload #10
      //   453: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   458: aload_0
      //   459: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   464: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   469: astore #12
      //   471: aload_1
      //   472: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   477: new java/awt/Rectangle
      //   480: dup
      //   481: new java/awt/Point
      //   484: dup
      //   485: aload_1
      //   486: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   491: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   496: aload_1
      //   497: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   502: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   507: iadd
      //   508: aload_0
      //   509: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   512: iconst_4
      //   513: iaload
      //   514: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   519: isub
      //   520: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   523: iconst_4
      //   524: iaload
      //   525: isub
      //   526: aload_1
      //   527: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   532: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   537: aload_0
      //   538: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   541: iconst_4
      //   542: iaload
      //   543: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   548: iadd
      //   549: invokespecial <init> : (II)V
      //   552: new java/awt/Dimension
      //   555: dup
      //   556: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   559: iconst_4
      //   560: iaload
      //   561: aload_1
      //   562: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   567: <illegal opcode> 16 : (Ljava/awt/Dimension;)I
      //   572: aload_0
      //   573: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   576: iconst_4
      //   577: iaload
      //   578: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   583: isub
      //   584: invokespecial <init> : (II)V
      //   587: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
      //   590: aload #12
      //   592: aload #12
      //   594: aload #12
      //   596: aload #12
      //   598: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   603: aload_1
      //   604: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/Context;)Z
      //   609: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   612: ifeq -> 730
      //   615: aload_1
      //   616: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   621: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
      //   626: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   631: aload_1
      //   632: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   637: <illegal opcode> 17 : (Ljava/awt/Point;)I
      //   642: aload_1
      //   643: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   648: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   653: iadd
      //   654: aload_0
      //   655: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   658: iconst_4
      //   659: iaload
      //   660: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   665: isub
      //   666: invokestatic lIIIIlIIIIlllIll : (II)Z
      //   669: ifeq -> 730
      //   672: aload_1
      //   673: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   678: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
      //   683: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   688: aload_1
      //   689: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   694: <illegal opcode> 18 : (Ljava/awt/Point;)I
      //   699: isub
      //   700: aload_0
      //   701: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   704: iconst_4
      //   705: iaload
      //   706: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;Z)I
      //   711: isub
      //   712: iload #5
      //   714: imul
      //   715: i2d
      //   716: iload #7
      //   718: i2d
      //   719: ddiv
      //   720: iload #7
      //   722: i2d
      //   723: ldc2_w 2.0
      //   726: ddiv
      //   727: dsub
      //   728: d2i
      //   729: ireturn
      //   730: iload #6
      //   732: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   33	697	7	lllllllllllllllIllIlIlIlIlIIllll	I
      //   47	683	8	lllllllllllllllIllIlIlIlIlIIlllI	I
      //   64	666	9	lllllllllllllllIllIlIlIlIlIIllIl	I
      //   78	652	10	lllllllllllllllIllIlIlIlIlIIllII	Ljava/awt/Color;
      //   92	638	11	lllllllllllllllIllIlIlIlIlIIlIll	Ljava/awt/Color;
      //   471	259	12	lllllllllllllllIllIlIlIlIlIIlIlI	Ljava/awt/Color;
      //   0	733	0	lllllllllllllllIllIlIlIlIlIIlIIl	Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;
      //   0	733	1	lllllllllllllllIllIlIlIlIlIIlIII	Lcom/lukflug/panelstudio/Context;
      //   0	733	2	lllllllllllllllIllIlIlIlIlIIIlll	Z
      //   0	733	3	lllllllllllllllIllIlIlIlIlIIIllI	Z
      //   0	733	4	lllllllllllllllIllIlIlIlIlIIIlIl	Z
      //   0	733	5	lllllllllllllllIllIlIlIlIlIIIlII	I
      //   0	733	6	lllllllllllllllIllIlIlIlIlIIIIll	I
    }
    
    public Color getMainColor(boolean lllllllllllllllIllIlIlIlIlIIIIII, boolean lllllllllllllllIllIlIlIlIIllllll) {
      // Byte code:
      //   0: iload_2
      //   1: invokestatic lIIIIlIIIIlllIIl : (I)Z
      //   4: ifeq -> 36
      //   7: aload_0
      //   8: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   13: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   18: astore_3
      //   19: ldc ''
      //   21: invokevirtual length : ()I
      //   24: pop
      //   25: ldc '  '
      //   27: invokevirtual length : ()I
      //   30: ineg
      //   31: iflt -> 48
      //   34: aconst_null
      //   35: areturn
      //   36: aload_0
      //   37: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   42: <illegal opcode> 25 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   47: astore_3
      //   48: iload_2
      //   49: invokestatic lIIIIlIIIIlllIlI : (I)Z
      //   52: ifeq -> 84
      //   55: aload_0
      //   56: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)I
      //   61: getstatic com/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer.llIIIlIlIlIllI : [I
      //   64: iconst_0
      //   65: iaload
      //   66: invokestatic lIIIIlIIIIllllII : (II)Z
      //   69: ifeq -> 84
      //   72: aload_0
      //   73: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   78: <illegal opcode> 26 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   83: astore_3
      //   84: new java/awt/Color
      //   87: dup
      //   88: aload_3
      //   89: <illegal opcode> 27 : (Ljava/awt/Color;)I
      //   94: aload_3
      //   95: <illegal opcode> 28 : (Ljava/awt/Color;)I
      //   100: aload_3
      //   101: <illegal opcode> 29 : (Ljava/awt/Color;)I
      //   106: aload_0
      //   107: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   112: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)I
      //   117: invokespecial <init> : (IIII)V
      //   120: astore_3
      //   121: aload_3
      //   122: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   19	17	3	lllllllllllllllIllIlIlIlIlIIIIlI	Ljava/awt/Color;
      //   0	123	0	lllllllllllllllIllIlIlIlIlIIIIIl	Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;
      //   0	123	1	lllllllllllllllIllIlIlIlIlIIIIII	Z
      //   0	123	2	lllllllllllllllIllIlIlIlIIllllll	Z
      //   48	75	3	lllllllllllllllIllIlIlIlIIlllllI	Ljava/awt/Color;
    }
    
    public Color getBackgroundColor(boolean lllllllllllllllIllIlIlIlIIllllII) {
      return new Color(llIIIlIlIlIllI[1], llIIIlIlIlIllI[1], llIIIlIlIlIllI[1], llIIIlIlIlIllI[1]);
    }
    
    public ColorScheme getDefaultColorScheme() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 31 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/GameSenseTheme;
      //   6: <illegal opcode> 32 : (Lcom/lukflug/panelstudio/theme/GameSenseTheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIllIlIlIlIIlllIll	Lcom/lukflug/panelstudio/theme/GameSenseTheme$ComponentRenderer;
    }
    
    static {
      lIIIIlIIIIlllIII();
      lIIIIlIIIIllIlll();
      lIIIIlIIIIllIllI();
      lIIIIlIIIIllIIlI();
    }
    
    private static CallSite lIIIIIllIlIllIII(MethodHandles.Lookup lllllllllllllllIllIlIlIlIIllIIlI, String lllllllllllllllIllIlIlIlIIllIIIl, MethodType lllllllllllllllIllIlIlIlIIllIIII) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllIlIlIlIIlllIII = llIIIIlllIllll[Integer.parseInt(lllllllllllllllIllIlIlIlIIllIIIl)].split(llIIIlIlIlIlII[llIIIlIlIlIllI[1]]);
        Class<?> lllllllllllllllIllIlIlIlIIllIlll = Class.forName(lllllllllllllllIllIlIlIlIIlllIII[llIIIlIlIlIllI[1]]);
        String lllllllllllllllIllIlIlIlIIllIllI = lllllllllllllllIllIlIlIlIIlllIII[llIIIlIlIlIllI[4]];
        MethodHandle lllllllllllllllIllIlIlIlIIllIlIl = null;
        int lllllllllllllllIllIlIlIlIIllIlII = lllllllllllllllIllIlIlIlIIlllIII[llIIIlIlIlIllI[5]].length();
        if (lIIIIlIIIIllllIl(lllllllllllllllIllIlIlIlIIllIlII, llIIIlIlIlIllI[0])) {
          MethodType lllllllllllllllIllIlIlIlIIlllIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlIlIIlllIII[llIIIlIlIlIllI[0]], ComponentRenderer.class.getClassLoader());
          if (lIIIIlIIIIlllllI(lllllllllllllllIllIlIlIlIIllIlII, llIIIlIlIlIllI[0])) {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findVirtual(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIlI);
            "".length();
            if (-" ".length() > 0)
              return null; 
          } else {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findStatic(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIlI);
          } 
          "".length();
          if (-(0x5 ^ 0x1) >= 0)
            return null; 
        } else {
          Class<?> lllllllllllllllIllIlIlIlIIlllIIl = llIIIIllllIIII[Integer.parseInt(lllllllllllllllIllIlIlIlIIlllIII[llIIIlIlIlIllI[0]])];
          if (lIIIIlIIIIlllllI(lllllllllllllllIllIlIlIlIIllIlII, llIIIlIlIlIllI[5])) {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findGetter(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIIl);
            "".length();
            if (" ".length() << " ".length() <= " ".length())
              return null; 
          } else if (lIIIIlIIIIlllllI(lllllllllllllllIllIlIlIlIIllIlII, llIIIlIlIlIllI[6])) {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findStaticGetter(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIIl);
            "".length();
            if (null != null)
              return null; 
          } else if (lIIIIlIIIIlllllI(lllllllllllllllIllIlIlIlIIllIlII, llIIIlIlIlIllI[7])) {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findSetter(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIIl);
            "".length();
            if (-" ".length() < -" ".length())
              return null; 
          } else {
            lllllllllllllllIllIlIlIlIIllIlIl = lllllllllllllllIllIlIlIlIIllIIlI.findStaticSetter(lllllllllllllllIllIlIlIlIIllIlll, lllllllllllllllIllIlIlIlIIllIllI, lllllllllllllllIllIlIlIlIIlllIIl);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllIlIlIlIIllIlIl);
      } catch (Exception lllllllllllllllIllIlIlIlIIllIIll) {
        lllllllllllllllIllIlIlIlIIllIIll.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIlIIIIllIIlI() {
      llIIIIlllIllll = new String[llIIIlIlIlIllI[8]];
      llIIIIlllIllll[llIIIlIlIlIllI[9]] = llIIIlIlIlIlII[llIIIlIlIlIllI[4]];
      llIIIIlllIllll[llIIIlIlIlIllI[10]] = llIIIlIlIlIlII[llIIIlIlIlIllI[0]];
      llIIIIlllIllll[llIIIlIlIlIllI[11]] = llIIIlIlIlIlII[llIIIlIlIlIllI[5]];
      llIIIIlllIllll[llIIIlIlIlIllI[12]] = llIIIlIlIlIlII[llIIIlIlIlIllI[6]];
      llIIIIlllIllll[llIIIlIlIlIllI[13]] = llIIIlIlIlIlII[llIIIlIlIlIllI[7]];
      llIIIIlllIllll[llIIIlIlIlIllI[14]] = llIIIlIlIlIlII[llIIIlIlIlIllI[15]];
      llIIIIlllIllll[llIIIlIlIlIllI[16]] = llIIIlIlIlIlII[llIIIlIlIlIllI[17]];
      llIIIIlllIllll[llIIIlIlIlIllI[7]] = llIIIlIlIlIlII[llIIIlIlIlIllI[18]];
      llIIIIlllIllll[llIIIlIlIlIllI[19]] = llIIIlIlIlIlII[llIIIlIlIlIllI[20]];
      llIIIIlllIllll[llIIIlIlIlIllI[21]] = llIIIlIlIlIlII[llIIIlIlIlIllI[16]];
      llIIIIlllIllll[llIIIlIlIlIllI[20]] = llIIIlIlIlIlII[llIIIlIlIlIllI[22]];
      llIIIIlllIllll[llIIIlIlIlIllI[23]] = llIIIlIlIlIlII[llIIIlIlIlIllI[14]];
      llIIIIlllIllll[llIIIlIlIlIllI[24]] = llIIIlIlIlIlII[llIIIlIlIlIllI[13]];
      llIIIIlllIllll[llIIIlIlIlIllI[1]] = llIIIlIlIlIlII[llIIIlIlIlIllI[25]];
      llIIIIlllIllll[llIIIlIlIlIllI[4]] = llIIIlIlIlIlII[llIIIlIlIlIllI[10]];
      llIIIIlllIllll[llIIIlIlIlIllI[26]] = llIIIlIlIlIlII[llIIIlIlIlIllI[27]];
      llIIIIlllIllll[llIIIlIlIlIllI[18]] = llIIIlIlIlIlII[llIIIlIlIlIllI[23]];
      llIIIIlllIllll[llIIIlIlIlIllI[28]] = llIIIlIlIlIlII[llIIIlIlIlIllI[29]];
      llIIIIlllIllll[llIIIlIlIlIllI[30]] = llIIIlIlIlIlII[llIIIlIlIlIllI[31]];
      llIIIIlllIllll[llIIIlIlIlIllI[6]] = llIIIlIlIlIlII[llIIIlIlIlIllI[32]];
      llIIIIlllIllll[llIIIlIlIlIllI[22]] = llIIIlIlIlIlII[llIIIlIlIlIllI[21]];
      llIIIIlllIllll[llIIIlIlIlIllI[29]] = llIIIlIlIlIlII[llIIIlIlIlIllI[26]];
      llIIIIlllIllll[llIIIlIlIlIllI[5]] = llIIIlIlIlIlII[llIIIlIlIlIllI[30]];
      llIIIIlllIllll[llIIIlIlIlIllI[15]] = llIIIlIlIlIlII[llIIIlIlIlIllI[33]];
      llIIIIlllIllll[llIIIlIlIlIllI[25]] = llIIIlIlIlIlII[llIIIlIlIlIllI[19]];
      llIIIIlllIllll[llIIIlIlIlIllI[0]] = llIIIlIlIlIlII[llIIIlIlIlIllI[34]];
      llIIIIlllIllll[llIIIlIlIlIllI[32]] = llIIIlIlIlIlII[llIIIlIlIlIllI[35]];
      llIIIIlllIllll[llIIIlIlIlIllI[31]] = llIIIlIlIlIlII[llIIIlIlIlIllI[12]];
      llIIIIlllIllll[llIIIlIlIlIllI[33]] = llIIIlIlIlIlII[llIIIlIlIlIllI[24]];
      llIIIIlllIllll[llIIIlIlIlIllI[34]] = llIIIlIlIlIlII[llIIIlIlIlIllI[28]];
      llIIIIlllIllll[llIIIlIlIlIllI[35]] = llIIIlIlIlIlII[llIIIlIlIlIllI[9]];
      llIIIIlllIllll[llIIIlIlIlIllI[17]] = llIIIlIlIlIlII[llIIIlIlIlIllI[11]];
      llIIIIlllIllll[llIIIlIlIlIllI[27]] = llIIIlIlIlIlII[llIIIlIlIlIllI[8]];
      llIIIIllllIIII = new Class[llIIIlIlIlIllI[5]];
      llIIIIllllIIII[llIIIlIlIlIllI[4]] = int.class;
      llIIIIllllIIII[llIIIlIlIlIllI[1]] = GameSenseTheme.class;
      llIIIIllllIIII[llIIIlIlIlIllI[0]] = ColorScheme.class;
    }
    
    private static void lIIIIlIIIIllIllI() {
      llIIIlIlIlIlII = new String[llIIIlIlIlIllI[36]];
      llIIIlIlIlIlII[llIIIlIlIlIllI[1]] = lIIIIlIIIIllIIll(llIIIlIlIlIlIl[llIIIlIlIlIllI[1]], llIIIlIlIlIlIl[llIIIlIlIlIllI[4]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[4]] = lIIIIlIIIIllIlII(llIIIlIlIlIlIl[llIIIlIlIlIllI[0]], llIIIlIlIlIlIl[llIIIlIlIlIllI[5]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[0]] = lIIIIlIIIIllIlIl(llIIIlIlIlIlIl[llIIIlIlIlIllI[6]], llIIIlIlIlIlIl[llIIIlIlIlIllI[7]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[5]] = lIIIIlIIIIllIlII(llIIIlIlIlIlIl[llIIIlIlIlIllI[15]], llIIIlIlIlIlIl[llIIIlIlIlIllI[17]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[6]] = lIIIIlIIIIllIlII(llIIIlIlIlIlIl[llIIIlIlIlIllI[18]], llIIIlIlIlIlIl[llIIIlIlIlIllI[20]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[7]] = lIIIIlIIIIllIlII(llIIIlIlIlIlIl[llIIIlIlIlIllI[16]], llIIIlIlIlIlIl[llIIIlIlIlIllI[22]]);
      llIIIlIlIlIlII[llIIIlIlIlIllI[15]] = lIIIIlIIIIllIIll("ZxhiljGqX9TXX3Fz5hwXFMe5tcaJ1aHBD2c3SfZcxMut1UeIbo7gFEb10Kr0T2qQkxSn0sYr8Wa59mRrW5T122BH+X8chTZrqcDqutJF4o0=", "AIvcH");
      llIIIlIlIlIlII[llIIIlIlIlIllI[17]] = lIIIIlIIIIllIIll("XsuZ6yxgWRGM7Egt89xLqXlfexik+rZr4s7VIW6rnzG87LTyrb6tTT1czdf+PPOrjnJf2rw/LvXMojz+L9U3KGvU6EKvvUV66m7CPiAiPG4QrZ8t6GVntwXb5Wn316x3ZZFgQELDJdfndlJ+hxcp07k7KNCX2oFuz/cEVgyQ1wsYF7tbu31OVw==", "trGJO");
      llIIIlIlIlIlII[llIIIlIlIlIllI[18]] = lIIIIlIIIIllIlIl("BS8MOXsOOQ52BwotDjk7CCIfYjIKOjY3Ng46Ezc7VWZTFD8OOBt3NBg6VQg6BiAOY29Pbg==", "oNzXU");
      llIIIlIlIlIlII[llIIIlIlIlIllI[20]] = lIIIIlIIIIllIlII("vjx5Xl22v6nMcFEm8qVAaLBqfpf1TBd8Exdc3/5xJY3T4aS2zFJGkKvqIba8APdZq+Cee7NGtEQiog1KBMsEf/e5fW4tDNBUQi7+C+dV5ZLriFMnPee4hw==", "vbEHn");
      llIIIlIlIlIlII[llIIIlIlIlIllI[16]] = lIIIIlIIIIllIlIl("IgwjRyI0CCgFOyZNPgggJA89HTslCiFHDS4NOgw2NVknGg0tCi0CKyVZZkAUe0Nu", "AcNiN");
      llIIIlIlIlIlII[llIIIlIlIlIllI[22]] = lIIIIlIIIIllIIll("82Ish9xM8PP5LaJYpxYrPZLOsZMwnFo1n+QiV0bX/FZEXXkIMgYZSMoAJQKGDcebBixD7LGypLMTi0JaeKjD/6xG32te73QcGNgCSVmdkTUlWps7ungTdEUlJhhudFX7a0wO2jHyX1k=", "XjPAk");
      llIIIlIlIlIlII[llIIIlIlIlIllI[14]] = lIIIIlIIIIllIlIl("AyMuB2wINSxIEgYrNhJ4EXhpXGJJYg==", "iBXfB");
      llIIIlIlIlIlII[llIIIlIlIlIllI[13]] = lIIIIlIIIIllIIll("9EU9EqUgmj30C8OP5ioRqewtBO5JpKCdpdy1hZivIJA=", "qpbTh");
      llIIIlIlIlIlII[llIIIlIlIlIllI[25]] = lIIIIlIIIIllIlIl("DRg8fyAbHDc9OQlZITAiCxsiJTkKHj5/OAYSPDRiKRY8NB8LGSI0GAYSPDRoLRg8ISMAEj8lHgsZNTQ+CwVrNikaOjA4Ii0YPT4+VF8LC2UiHTAnLUEWJiVjLRg9Pj5VTXFx", "nwQQL");
      llIIIlIlIlIlII[llIIIlIlIlIllI[10]] = lIIIIlIIIIllIIll("WzsGKV83gj1o3q1bGZWIEWYepziRzHS9+VqoiH8Y6pdEprKkc7g2ezm5/wBfa8IxE7zLmORAkv3mE6rajdyXJxkhjVsxFer11pYpA1gs6yewPOmnlgbTVg==", "Llxbv");
      llIIIlIlIlIlII[llIIIlIlIlIllI[27]] = lIIIIlIIIIllIIll("3AtzASTO95ckfFCLyuQiq+Ptd2l7KfjUH7K8vA6+fFBo04Ver9PEV2JPRepvIIKA2Qwh/86RAYDaxTRQzKVia0VtOIHum8D5", "qvHws");
      llIIIlIlIlIlII[llIIIlIlIlIllI[23]] = lIIIIlIIIIllIIll("fMV75f7v9sNvGucVh4qsS6DEOoSAHPR902hRCviVxrlIxY5DsCxxIVClFVyx2TSA6NIcexLLpbFl5dPS4Wm6uZ/Aeflp/uZA2UQf4TSctrSunin3awwPl51RaBArzeQlbySGSOYwGh8=", "NBTMP");
      llIIIlIlIlIlII[llIIIlIlIlIllI[29]] = lIIIIlIIIIllIlII("n19/S+DHxfPO+nkVXJE+gmSinkJdAWQr6fs71MDWm93oLugkX8R92punyn4+L6aMbNbRt0iej95mjVSb4Wn4gA==", "GyPBF");
      llIIIlIlIlIlII[llIIIlIlIlIllI[31]] = lIIIIlIIIIllIlIl("BgcmSBoQAy0KAwJGOwcYAAQ4EgMBASRIAg0NJgNYIgkmAyUABjgDIg0NJgNSJgcmFhkLDSUSJAAGLwMEABpxARMRKyQKGRc7KA4TCA1xTl8pCyQLWQkdIAAaEA9kFhcLDScVAhAMIglZEQAuCxNKKyQKGRc7KA4TCA1wXFZF", "ehKfv");
      llIIIlIlIlIlII[llIIIlIlIlIllI[32]] = lIIIIlIIIIllIlIl("DykjegoZLSg4EwtoPjUICSo9IBMILyF6JQMoOjEeGHwpMRI+Iy0gXERvAj4HGidhNREYaRwxBRgnIDMKCX10dEY=", "lFNTf");
      llIIIlIlIlIlII[llIIIlIlIlIllI[21]] = lIIIIlIIIIllIlIl("AjcHRj0UMwwEJAZ2Ggk/BDQZHCQFMQVGJQk9Bw1/IjcGByMyOwINPARiDQ0lLi0eBDgPPSkHPQ4qUEB4LTILHjBOOR0cfiI3BgcjWmJKSA==", "aXjhQ");
      llIIIlIlIlIlII[llIIIlIlIlIllI[26]] = lIIIIlIIIIllIlII("SNnCc8WWMI9E0f/eQsi9BYc65INGDXYu", "gDoPA");
      llIIIlIlIlIlII[llIIIlIlIlIllI[30]] = lIIIIlIIIIllIIll("IBNj0lw9w/pJ/Y+Gy3E6H7FPAtdreMMpH1+WwfdVj0oINnQP0x7grv/y/ZQ6k74+9Euyl+omBrc=", "FHvaS");
      llIIIlIlIlIlII[llIIIlIlIlIllI[33]] = lIIIIlIIIIllIlIl("BgQvWi0QACQYNAJFMhUvAAcxADQBAi1aNQ0OLxFvIgovERIABTERFQ0OLxFlJgQvBC4LDiwAEwAFJhEzABl4Fi4XDycGe1RRYlRh", "ekBtA");
      llIIIlIlIlIlII[llIIIlIlIlIllI[19]] = lIIIIlIIIIllIlII("EhGkFztcI59G4Y/QtIJyZFV0bORIqiVfmdRRHzNjlSSHH63jmHbe/EsHIYyRY+fS4Tn/tOdUAv/B+HM4YjSSp0mkzqveZ89D", "EtRXv");
      llIIIlIlIlIlII[llIIIlIlIlIllI[34]] = lIIIIlIIIIllIIll("lUDt8MGLUfbm0wd1LZNdyHFLmg1lj9ftf9j6LC9sEM63+9iVDJoEW149MswteEnsufLPDBDnr48pe6Q3nVcb7RWdnXr7biwP3cFeD0mSgDIVnZ16+24sD93BXg9JkoAyFZ2devtuLA/dwV4PSZKAMhWdnXr7biwP3cFeD0mSgDJzedjbbdHBXQ==", "AudSn");
      llIIIlIlIlIlII[llIIIlIlIlIllI[35]] = lIIIIlIIIIllIlII("8StOD8obMM+M4j4fMWvtdclAVfRpRlX/7K+WGkx2Z/DZ5OI7g/0qv3HRWHG1ODYGt9fI9PrH5tGAeXVG2uGtmJY++vuPWBeQUZfYz4wtZad7Gsc5qiNl4g==", "fpkDL");
      llIIIlIlIlIlII[llIIIlIlIlIllI[12]] = lIIIIlIIIIllIlII("VkN/B6bSPGTp/5iSnbowAKaPX1EgPC6z6HtJ3DdFbIHt1545Mo5pBvNhLG3Sct5RqNk6Xqxwe+RcybRhTXGRX7gNip/VOoQXFx7x2a4rGbw1f4ZWeNB5tQ==", "MtxVn");
      llIIIlIlIlIlII[llIIIlIlIlIllI[24]] = lIIIIlIIIIllIlII("BODBX09HLGVQBBht9cmfkCqe3WzgKMc7T10DgW04SWBT49nDMvsekJhgEK1B8vwKlA7TG64yYBJin30vhXAULSz9WIfQNF0/Y4VdDQ2dmhA=", "oKDKE");
      llIIIlIlIlIlII[llIIIlIlIlIllI[28]] = lIIIIlIIIIllIIll("u8nULSjcgqsJ8JwSZLeV6yJp6SKxbvV5OgfItf2tCCtzwpwFs+cKQgXIOvIVMOvnPZeQ+L5oWU3Nt+wSiydOYhhhIQQZdTMniG8KcF+yk4Q3yVpPqmh3Nw==", "ZwRbr");
      llIIIlIlIlIlII[llIIIlIlIlIllI[9]] = lIIIIlIIIIllIlIl("Ay0jCnYIOyFFGwYgOhliDikhOT0Ndn1CEVNsdQ==", "iLUkX");
      llIIIlIlIlIlII[llIIIlIlIlIllI[11]] = lIIIIlIIIIllIlII("Cz4/JT56jgDbqC4DFaHCMtuQTy9XXcxu69wjEt5xSnNU5llE1tHx5g==", "vPDXg");
      llIIIlIlIlIlII[llIIIlIlIlIllI[8]] = lIIIIlIIIIllIIll("PbFeSIwAsJdWuLy6+wlsucJJFQEkLlNl5+ybwvD3MzA=", "rAAGw");
      llIIIlIlIlIlIl = null;
    }
    
    private static void lIIIIlIIIIllIlll() {
      String str = (new Exception()).getStackTrace()[llIIIlIlIlIllI[1]].getFileName();
      llIIIlIlIlIlIl = str.substring(str.indexOf("ä") + llIIIlIlIlIllI[4], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lIIIIlIIIIllIlIl(String lllllllllllllllIllIlIlIlIIlIlllI, String lllllllllllllllIllIlIlIlIIlIllIl) {
      lllllllllllllllIllIlIlIlIIlIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIlIlIlIIlIllII = new StringBuilder();
      char[] lllllllllllllllIllIlIlIlIIlIlIll = lllllllllllllllIllIlIlIlIIlIllIl.toCharArray();
      int lllllllllllllllIllIlIlIlIIlIlIlI = llIIIlIlIlIllI[1];
      char[] arrayOfChar1 = lllllllllllllllIllIlIlIlIIlIlllI.toCharArray();
      int i = arrayOfChar1.length;
      int j = llIIIlIlIlIllI[1];
      while (lIIIIlIIIIllllII(j, i)) {
        char lllllllllllllllIllIlIlIlIIlIllll = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllIlIlIlIIlIlIlI++;
        j++;
        "".length();
        if (null != null)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllIlIlIlIIlIllII);
    }
    
    private static String lIIIIlIIIIllIlII(String lllllllllllllllIllIlIlIlIIlIIllI, String lllllllllllllllIllIlIlIlIIlIIlIl) {
      try {
        SecretKeySpec lllllllllllllllIllIlIlIlIIlIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIlIIlIIlIl.getBytes(StandardCharsets.UTF_8)), llIIIlIlIlIllI[18]), "DES");
        Cipher lllllllllllllllIllIlIlIlIIlIlIII = Cipher.getInstance("DES");
        lllllllllllllllIllIlIlIlIIlIlIII.init(llIIIlIlIlIllI[0], lllllllllllllllIllIlIlIlIIlIlIIl);
        return new String(lllllllllllllllIllIlIlIlIIlIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIIlIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIlIlIIlIIlll) {
        lllllllllllllllIllIlIlIlIIlIIlll.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIlIIIIllIIll(String lllllllllllllllIllIlIlIlIIlIIIIl, String lllllllllllllllIllIlIlIlIIlIIIII) {
      try {
        SecretKeySpec lllllllllllllllIllIlIlIlIIlIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIlIIlIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIlIlIlIIlIIIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIlIlIlIIlIIIll.init(llIIIlIlIlIllI[0], lllllllllllllllIllIlIlIlIIlIIlII);
        return new String(lllllllllllllllIllIlIlIlIIlIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIlIlIIlIIIlI) {
        lllllllllllllllIllIlIlIlIIlIIIlI.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIlIIIIlllIII() {
      llIIIlIlIlIllI = new int[37];
      llIIIlIlIlIllI[0] = " ".length() << " ".length();
      llIIIlIlIlIllI[1] = ((0xC0 ^ 0x8D) << " ".length() ^ 122 + 96 - 133 + 58) & ((0xCD ^ 0xA6) << " ".length() ^ 160 + 124 - 159 + 70 ^ -" ".length());
      llIIIlIlIlIllI[2] = (0x78 ^ 0x9) + ((0x6A ^ 0x47) << " ".length() << " ".length()) - ((0x2B ^ 0x10) << " ".length()) + ((0xB7 ^ 0xB2) << " ".length() << " ".length() << " ".length());
      llIIIlIlIlIllI[3] = " ".length() << "   ".length() << " ".length();
      llIIIlIlIlIllI[4] = " ".length();
      llIIIlIlIlIllI[5] = "   ".length();
      llIIIlIlIlIllI[6] = " ".length() << " ".length() << " ".length();
      llIIIlIlIlIllI[7] = 115 + 0 - 102 + 158 ^ (0x30 ^ 0x67) << " ".length();
      llIIIlIlIlIllI[8] = 0x4 ^ 0x25;
      llIIIlIlIlIllI[9] = 0x85 ^ 0x9A;
      llIIIlIlIlIllI[10] = 0xA3 ^ 0xAC;
      llIIIlIlIlIllI[11] = " ".length() << ((0x44 ^ 0x75) << " ".length() ^ 0xE9 ^ 0x8E);
      llIIIlIlIlIllI[12] = ((0x90 ^ 0xA1) << " ".length() ^ 0x4E ^ 0x2B) << " ".length() << " ".length();
      llIIIlIlIlIllI[13] = 0x81 ^ 0x8C;
      llIIIlIlIlIllI[14] = "   ".length() << " ".length() << " ".length();
      llIIIlIlIlIllI[15] = "   ".length() << " ".length();
      llIIIlIlIlIllI[16] = (0xB5 ^ 0xB0) << " ".length();
      llIIIlIlIlIllI[17] = 0x8D ^ 0x94 ^ (0x21 ^ 0x2E) << " ".length();
      llIIIlIlIlIllI[18] = " ".length() << "   ".length();
      llIIIlIlIlIllI[19] = 0x4F ^ 0x56;
      llIIIlIlIlIllI[20] = 0x68 ^ 0x61;
      llIIIlIlIlIllI[21] = 6 + 139 - -3 + 41 ^ (0xD ^ 0x18) << "   ".length();
      llIIIlIlIlIllI[22] = (0xC9 ^ 0x80) << " ".length() ^ 66 + 93 - 135 + 129;
      llIIIlIlIlIllI[23] = 0x3F ^ 0x0 ^ (0xB9 ^ 0xAE) << " ".length();
      llIIIlIlIlIllI[24] = 0x6D ^ 0x22 ^ (0x59 ^ 0x70) << " ".length();
      llIIIlIlIlIllI[25] = (0xC1 ^ 0xC6) << " ".length();
      llIIIlIlIlIllI[26] = (0x65 ^ 0x6E) << " ".length();
      llIIIlIlIlIllI[27] = " ".length() << " ".length() << " ".length() << " ".length();
      llIIIlIlIlIllI[28] = (0x23 ^ 0x16 ^ (0x94 ^ 0x89) << " ".length()) << " ".length();
      llIIIlIlIlIllI[29] = (0x4B ^ 0xA ^ (0xA6 ^ 0xAF) << "   ".length()) << " ".length();
      llIIIlIlIlIllI[30] = (0x16 ^ 0x1F) << " ".length() << " ".length() << " ".length() ^ 78 + 62 - 82 + 77;
      llIIIlIlIlIllI[31] = 0xF6 ^ 0xAF ^ (0x11 ^ 0x34) << " ".length();
      llIIIlIlIlIllI[32] = (0x91 ^ 0x94) << " ".length() << " ".length();
      llIIIlIlIlIllI[33] = "   ".length() << "   ".length();
      llIIIlIlIlIllI[34] = ((0x45 ^ 0x6E) << " ".length() ^ 0xDE ^ 0x85) << " ".length();
      llIIIlIlIlIllI[35] = 0x93 ^ 0x88;
      llIIIlIlIlIllI[36] = (0xBB ^ 0xAA) << " ".length();
    }
    
    private static boolean lIIIIlIIIIlllllI(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lIIIIlIIIIlllIll(int param1Int1, int param1Int2) {
      return (param1Int1 >= param1Int2);
    }
    
    private static boolean lIIIIlIIIIllllII(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lIIIIlIIIIllllIl(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean lIIIIlIIIIlllIIl(int param1Int) {
      return (param1Int != 0);
    }
    
    private static boolean lIIIIlIIIIlllIlI(int param1Int) {
      return (param1Int == 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\GameSenseTheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */