package com.lukflug.panelstudio.theme;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class ThemeMultiplexer implements Theme {
  protected final Renderer panelRenderer = new PanelRenderer();
  
  protected final Renderer containerRenderer = new ContainerRenderer();
  
  protected final Renderer componentRenderer = new ComponentRenderer();
  
  private static String[] llIIlIlllIIllI;
  
  private static Class[] llIIlIlllIIlll;
  
  private static final String[] llIIlIlllIlIII;
  
  private static String[] llIIlIlllIlIlI;
  
  private static final int[] llIIlIlllIllII;
  
  public Renderer getPanelRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllllIIllIlI	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
  }
  
  public Renderer getContainerRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllllIIllIIl	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
  }
  
  public Renderer getComponentRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllllIIllIII	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
  }
  
  protected abstract Theme getTheme();
  
  static {
    lIIIlIIIIlIlIllI();
    lIIIlIIIIlIlIIIl();
    lIIIlIIIIlIlIIII();
    lIIIlIIIIlIIlIlI();
  }
  
  private static CallSite lIIIlIIIIlIIlIII(MethodHandles.Lookup lllllllllllllllIllIIIlllIlllllll, String lllllllllllllllIllIIIlllIllllllI, MethodType lllllllllllllllIllIIIlllIlllllIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIllllIIIlIll = llIIlIlllIIllI[Integer.parseInt(lllllllllllllllIllIIIlllIllllllI)].split(llIIlIlllIlIII[llIIlIlllIllII[0]]);
      Class<?> lllllllllllllllIllIIIllllIIIlIIl = Class.forName(lllllllllllllllIllIIIllllIIIlIll[llIIlIlllIllII[0]]);
      String lllllllllllllllIllIIIllllIIIIlll = lllllllllllllllIllIIIllllIIIlIll[llIIlIlllIllII[1]];
      MethodHandle lllllllllllllllIllIIIllllIIIIlIl = null;
      int lllllllllllllllIllIIIllllIIIIIll = lllllllllllllllIllIIIllllIIIlIll[llIIlIlllIllII[2]].length();
      if (lIIIlIIIIlIllIII(lllllllllllllllIllIIIllllIIIIIll, llIIlIlllIllII[3])) {
        MethodType lllllllllllllllIllIIIllllIIIllIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIllllIIIlIll[llIIlIlllIllII[3]], ThemeMultiplexer.class.getClassLoader());
        if (lIIIlIIIIlIllIIl(lllllllllllllllIllIIIllllIIIIIll, llIIlIlllIllII[3])) {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findVirtual(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllIl);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findStatic(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllIl);
        } 
        "".length();
        if (-"  ".length() > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIllllIIIllII = llIIlIlllIIlll[Integer.parseInt(lllllllllllllllIllIIIllllIIIlIll[llIIlIlllIllII[3]])];
        if (lIIIlIIIIlIllIIl(lllllllllllllllIllIIIllllIIIIIll, llIIlIlllIllII[2])) {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findGetter(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllII);
          "".length();
          if (" ".length() == 0)
            return null; 
        } else if (lIIIlIIIIlIllIIl(lllllllllllllllIllIIIllllIIIIIll, llIIlIlllIllII[4])) {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findStaticGetter(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllII);
          "".length();
          if ((((0x96 ^ 0x91) << " ".length() << " ".length() << " ".length() ^ 0x2B ^ 0x4C) << " ".length() & ((0x3 ^ 0x54 ^ " ".length() << "   ".length() << " ".length()) << " ".length() ^ -" ".length())) != 0)
            return null; 
        } else if (lIIIlIIIIlIllIIl(lllllllllllllllIllIIIllllIIIIIll, llIIlIlllIllII[5])) {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findSetter(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllII);
          "".length();
          if (" ".length() << " ".length() <= 0)
            return null; 
        } else {
          lllllllllllllllIllIIIllllIIIIlIl = lllllllllllllllIllIIIlllIlllllll.findStaticSetter(lllllllllllllllIllIIIllllIIIlIIl, lllllllllllllllIllIIIllllIIIIlll, lllllllllllllllIllIIIllllIIIllII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIllllIIIIlIl);
    } catch (Exception lllllllllllllllIllIIIllllIIIIIIl) {
      lllllllllllllllIllIIIllllIIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIlIIlIlI() {
    llIIlIlllIIllI = new String[llIIlIlllIllII[2]];
    llIIlIlllIIllI[llIIlIlllIllII[0]] = llIIlIlllIlIII[llIIlIlllIllII[1]];
    llIIlIlllIIllI[llIIlIlllIllII[1]] = llIIlIlllIlIII[llIIlIlllIllII[3]];
    llIIlIlllIIllI[llIIlIlllIllII[3]] = llIIlIlllIlIII[llIIlIlllIllII[2]];
    llIIlIlllIIlll = new Class[llIIlIlllIllII[1]];
    llIIlIlllIIlll[llIIlIlllIllII[0]] = Renderer.class;
  }
  
  private static void lIIIlIIIIlIlIIII() {
    llIIlIlllIlIII = new String[llIIlIlllIllII[4]];
    llIIlIlllIlIII[llIIlIlllIllII[0]] = lIIIlIIIIlIIlIll(llIIlIlllIlIlI[llIIlIlllIllII[0]], llIIlIlllIlIlI[llIIlIlllIllII[1]]);
    llIIlIlllIlIII[llIIlIlllIllII[1]] = lIIIlIIIIlIIllII(llIIlIlllIlIlI[llIIlIlllIllII[3]], llIIlIlllIlIlI[llIIlIlllIllII[2]]);
    llIIlIlllIlIII[llIIlIlllIllII[3]] = lIIIlIIIIlIIlIll(llIIlIlllIlIlI[llIIlIlllIllII[4]], llIIlIlllIlIlI[llIIlIlllIllII[5]]);
    llIIlIlllIlIII[llIIlIlllIllII[2]] = lIIIlIIIIlIIllIl(llIIlIlllIlIlI[llIIlIlllIllII[6]], llIIlIlllIlIlI[llIIlIlllIllII[7]]);
    llIIlIlllIlIlI = null;
  }
  
  private static void lIIIlIIIIlIlIIIl() {
    String str = (new Exception()).getStackTrace()[llIIlIlllIllII[0]].getFileName();
    llIIlIlllIlIlI = str.substring(str.indexOf("ä") + llIIlIlllIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIIlIIllII(String lllllllllllllllIllIIIlllIllllIIl, String lllllllllllllllIllIIIlllIllllIII) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIlllllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIllllIII.getBytes(StandardCharsets.UTF_8)), llIIlIlllIllII[8]), "DES");
      Cipher lllllllllllllllIllIIIlllIllllIll = Cipher.getInstance("DES");
      lllllllllllllllIllIIIlllIllllIll.init(llIIlIlllIllII[3], lllllllllllllllIllIIIlllIlllllII);
      return new String(lllllllllllllllIllIIIlllIllllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIllllIlI) {
      lllllllllllllllIllIIIlllIllllIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIIlIIlIll(String lllllllllllllllIllIIIlllIlllIllI, String lllllllllllllllIllIIIlllIlllIlIl) {
    lllllllllllllllIllIIIlllIlllIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIlllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIlllIlllIlII = new StringBuilder();
    char[] lllllllllllllllIllIIIlllIlllIIll = lllllllllllllllIllIIIlllIlllIlIl.toCharArray();
    int lllllllllllllllIllIIIlllIlllIIlI = llIIlIlllIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIlllIlllIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIlllIllII[0];
    while (lIIIlIIIIlIllIlI(j, i)) {
      char lllllllllllllllIllIIIlllIlllIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIlllIlllIIlI++;
      j++;
      "".length();
      if (" ".length() << " ".length() != " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIlllIlllIlII);
  }
  
  private static String lIIIlIIIIlIIllIl(String lllllllllllllllIllIIIlllIllIlllI, String lllllllllllllllIllIIIlllIllIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIlllIlllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIlllIllIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIlllIlllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIlllIlllIIII.init(llIIlIlllIllII[3], lllllllllllllllIllIIIlllIlllIIIl);
      return new String(lllllllllllllllIllIIIlllIlllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIlllIllIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIlllIllIllll) {
      lllllllllllllllIllIIIlllIllIllll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIIlIlIllI() {
    llIIlIlllIllII = new int[9];
    llIIlIlllIllII[0] = ((0xC ^ 0x21) << " ".length() ^ 0x61 ^ 0x12) << " ".length() & (((0x9D ^ 0x90) << " ".length() << " ".length() & ((0x7A ^ 0x77) << " ".length() << " ".length() ^ 0xFFFFFFFF) ^ 0xC ^ 0x25) << " ".length() ^ -" ".length());
    llIIlIlllIllII[1] = " ".length();
    llIIlIlllIllII[2] = "   ".length();
    llIIlIlllIllII[3] = " ".length() << " ".length();
    llIIlIlllIllII[4] = " ".length() << " ".length() << " ".length();
    llIIlIlllIllII[5] = 0x6A ^ 0x6F;
    llIIlIlllIllII[6] = "   ".length() << " ".length();
    llIIlIlllIllII[7] = 0xB0 ^ 0xB7;
    llIIlIlllIllII[8] = " ".length() << "   ".length();
  }
  
  private static boolean lIIIlIIIIlIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIIlIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIIlIllIII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  protected class ComponentRenderer extends RendererProxy {
    private static String[] llIIIIllllllll;
    
    private static Class[] llIIIlIIIIIIII;
    
    private static final String[] llIIIlIIIIIIIl;
    
    private static String[] llIIIlIIIIIIll;
    
    private static final int[] llIIIlIIIIIllI;
    
    protected Renderer getRenderer() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
      //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Theme;
      //   11: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   16: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	17	0	lllllllllllllllIllIlIlllIlIIIlIl	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$ComponentRenderer;
    }
    
    static {
      lIIIIIlllIIIlllI();
      lIIIIIlllIIIIlIl();
      lIIIIIlllIIIIlII();
      lIIIIIllIlllIllI();
    }
    
    private static CallSite lIIIIIllIlllIlII(MethodHandles.Lookup lllllllllllllllIllIlIlllIIllllII, String lllllllllllllllIllIlIlllIIlllIll, MethodType lllllllllllllllIllIlIlllIIlllIlI) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllIlIlllIlIIIIlI = llIIIIllllllll[Integer.parseInt(lllllllllllllllIllIlIlllIIlllIll)].split(llIIIlIIIIIIIl[llIIIlIIIIIllI[0]]);
        Class<?> lllllllllllllllIllIlIlllIlIIIIIl = Class.forName(lllllllllllllllIllIlIlllIlIIIIlI[llIIIlIIIIIllI[0]]);
        String lllllllllllllllIllIlIlllIlIIIIII = lllllllllllllllIllIlIlllIlIIIIlI[llIIIlIIIIIllI[1]];
        MethodHandle lllllllllllllllIllIlIlllIIllllll = null;
        int lllllllllllllllIllIlIlllIIlllllI = lllllllllllllllIllIlIlllIlIIIIlI[llIIIlIIIIIllI[2]].length();
        if (lIIIIIlllIIIllll(lllllllllllllllIllIlIlllIIlllllI, llIIIlIIIIIllI[3])) {
          MethodType lllllllllllllllIllIlIlllIlIIIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlllIlIIIIlI[llIIIlIIIIIllI[3]], ComponentRenderer.class.getClassLoader());
          if (lIIIIIlllIIlIIII(lllllllllllllllIllIlIlllIIlllllI, llIIIlIIIIIllI[3])) {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findVirtual(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIlII);
            "".length();
            if (" ".length() != " ".length())
              return null; 
          } else {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findStatic(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIlII);
          } 
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else {
          Class<?> lllllllllllllllIllIlIlllIlIIIIll = llIIIlIIIIIIII[Integer.parseInt(lllllllllllllllIllIlIlllIlIIIIlI[llIIIlIIIIIllI[3]])];
          if (lIIIIIlllIIlIIII(lllllllllllllllIllIlIlllIIlllllI, llIIIlIIIIIllI[2])) {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findGetter(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIIll);
            "".length();
            if ("   ".length() < (((0x62 ^ 0x5F) << " ".length() ^ 123 + 119 - 190 + 75) & (0x72 ^ 0x55 ^ (0x8C ^ 0x9D) << " ".length() ^ -" ".length())))
              return null; 
          } else if (lIIIIIlllIIlIIII(lllllllllllllllIllIlIlllIIlllllI, llIIIlIIIIIllI[4])) {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findStaticGetter(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIIll);
            "".length();
            if (" ".length() <= 0)
              return null; 
          } else if (lIIIIIlllIIlIIII(lllllllllllllllIllIlIlllIIlllllI, llIIIlIIIIIllI[5])) {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findSetter(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIIll);
            "".length();
            if (((0x1 ^ 0x62 ^ (0xA3 ^ 0xA4) << " ".length() << " ".length() << " ".length()) & ((0x9F ^ 0x92) << " ".length() ^ 0x1D ^ 0x14 ^ -" ".length())) != 0)
              return null; 
          } else {
            lllllllllllllllIllIlIlllIIllllll = lllllllllllllllIllIlIlllIIllllII.findStaticSetter(lllllllllllllllIllIlIlllIlIIIIIl, lllllllllllllllIllIlIlllIlIIIIII, lllllllllllllllIllIlIlllIlIIIIll);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllIlIlllIIllllll);
      } catch (Exception lllllllllllllllIllIlIlllIIllllIl) {
        lllllllllllllllIllIlIlllIIllllIl.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIIllIlllIllI() {
      llIIIIllllllll = new String[llIIIlIIIIIllI[2]];
      llIIIIllllllll[llIIIlIIIIIllI[3]] = llIIIlIIIIIIIl[llIIIlIIIIIllI[1]];
      llIIIIllllllll[llIIIlIIIIIllI[1]] = llIIIlIIIIIIIl[llIIIlIIIIIllI[3]];
      llIIIIllllllll[llIIIlIIIIIllI[0]] = llIIIlIIIIIIIl[llIIIlIIIIIllI[2]];
      llIIIlIIIIIIII = new Class[llIIIlIIIIIllI[1]];
      llIIIlIIIIIIII[llIIIlIIIIIllI[0]] = ThemeMultiplexer.class;
    }
    
    private static void lIIIIIlllIIIIlII() {
      llIIIlIIIIIIIl = new String[llIIIlIIIIIllI[4]];
      llIIIlIIIIIIIl[llIIIlIIIIIllI[0]] = lIIIIIllIlllIlll(llIIIlIIIIIIll[llIIIlIIIIIllI[0]], llIIIlIIIIIIll[llIIIlIIIIIllI[1]]);
      llIIIlIIIIIIIl[llIIIlIIIIIllI[1]] = lIIIIIllIlllIlll(llIIIlIIIIIIll[llIIIlIIIIIllI[3]], llIIIlIIIIIIll[llIIIlIIIIIllI[2]]);
      llIIIlIIIIIIIl[llIIIlIIIIIllI[3]] = lIIIIIllIlllllll(llIIIlIIIIIIll[llIIIlIIIIIllI[4]], llIIIlIIIIIIll[llIIIlIIIIIllI[5]]);
      llIIIlIIIIIIIl[llIIIlIIIIIllI[2]] = lIIIIIlllIIIIIll(llIIIlIIIIIIll[llIIIlIIIIIllI[6]], llIIIlIIIIIIll[llIIIlIIIIIllI[7]]);
      llIIIlIIIIIIll = null;
    }
    
    private static void lIIIIIlllIIIIlIl() {
      String str = (new Exception()).getStackTrace()[llIIIlIIIIIllI[0]].getFileName();
      llIIIlIIIIIIll = str.substring(str.indexOf("ä") + llIIIlIIIIIllI[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lIIIIIlllIIIIIll(String lllllllllllllllIllIlIlllIIlllIII, String lllllllllllllllIllIlIlllIIllIlll) {
      lllllllllllllllIllIlIlllIIlllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIIlllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIlIlllIIllIllI = new StringBuilder();
      char[] lllllllllllllllIllIlIlllIIllIlIl = lllllllllllllllIllIlIlllIIllIlll.toCharArray();
      int lllllllllllllllIllIlIlllIIllIlII = llIIIlIIIIIllI[0];
      char[] arrayOfChar1 = lllllllllllllllIllIlIlllIIlllIII.toCharArray();
      int i = arrayOfChar1.length;
      int j = llIIIlIIIIIllI[0];
      while (lIIIIIlllIIlIIIl(j, i)) {
        char lllllllllllllllIllIlIlllIIlllIIl = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllIlIlllIIllIlII++;
        j++;
        "".length();
        if (((0x32 ^ 0x27) << " ".length() & ((0x2 ^ 0x17) << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length() << " ".length())
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllIlIlllIIllIllI);
    }
    
    private static String lIIIIIllIlllllll(String lllllllllllllllIllIlIlllIIllIIII, String lllllllllllllllIllIlIlllIIlIllll) {
      try {
        SecretKeySpec lllllllllllllllIllIlIlllIIllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIIlIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIlIlllIIllIIlI = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIlIlllIIllIIlI.init(llIIIlIIIIIllI[3], lllllllllllllllIllIlIlllIIllIIll);
        return new String(lllllllllllllllIllIlIlllIIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIlllIIllIIIl) {
        lllllllllllllllIllIlIlllIIllIIIl.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIIllIlllIlll(String lllllllllllllllIllIlIlllIIlIlIll, String lllllllllllllllIllIlIlllIIlIlIlI) {
      try {
        SecretKeySpec lllllllllllllllIllIlIlllIIlIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlllIIlIlIlI.getBytes(StandardCharsets.UTF_8)), llIIIlIIIIIllI[8]), "DES");
        Cipher lllllllllllllllIllIlIlllIIlIllIl = Cipher.getInstance("DES");
        lllllllllllllllIllIlIlllIIlIllIl.init(llIIIlIIIIIllI[3], lllllllllllllllIllIlIlllIIlIlllI);
        return new String(lllllllllllllllIllIlIlllIIlIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlllIIlIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIlIlllIIlIllII) {
        lllllllllllllllIllIlIlllIIlIllII.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIIlllIIIlllI() {
      llIIIlIIIIIllI = new int[9];
      llIIIlIIIIIllI[0] = (0x7E ^ 0x5F) << " ".length() & ((0xBB ^ 0x9A) << " ".length() ^ 0xFFFFFFFF);
      llIIIlIIIIIllI[1] = " ".length();
      llIIIlIIIIIllI[2] = "   ".length();
      llIIIlIIIIIllI[3] = " ".length() << " ".length();
      llIIIlIIIIIllI[4] = " ".length() << " ".length() << " ".length();
      llIIIlIIIIIllI[5] = " ".length() << " ".length() << " ".length() << " ".length() ^ 0x22 ^ 0x37;
      llIIIlIIIIIllI[6] = "   ".length() << " ".length();
      llIIIlIIIIIllI[7] = 0x96 ^ 0x91;
      llIIIlIIIIIllI[8] = " ".length() << "   ".length();
    }
    
    private static boolean lIIIIIlllIIlIIII(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lIIIIIlllIIlIIIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lIIIIIlllIIIllll(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
  }
  
  protected class ContainerRenderer extends RendererProxy {
    private static String[] llIIIIIlIlllIl;
    
    private static Class[] llIIIIIlIllllI;
    
    private static final String[] llIIIIIlIlllll;
    
    private static String[] llIIIIIllIIIII;
    
    private static final int[] llIIIIIllIIIIl;
    
    protected Renderer getRenderer() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$ContainerRenderer;)Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
      //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Theme;
      //   11: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   16: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	17	0	lllllllllllllllIllIllIlllIllllll	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$ContainerRenderer;
    }
    
    static {
      lIIIIIIllllIlIlI();
      lIIIIIIlllIlllII();
      lIIIIIIlllIllIll();
      lIIIIIIlllIlIlll();
    }
    
    private static CallSite lIIIIIIlllIlIllI(MethodHandles.Lookup lllllllllllllllIllIllIlllIllIllI, String lllllllllllllllIllIllIlllIllIlIl, MethodType lllllllllllllllIllIllIlllIllIlII) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllIllIlllIllllII = llIIIIIlIlllIl[Integer.parseInt(lllllllllllllllIllIllIlllIllIlIl)].split(llIIIIIlIlllll[llIIIIIllIIIIl[0]]);
        Class<?> lllllllllllllllIllIllIlllIlllIll = Class.forName(lllllllllllllllIllIllIlllIllllII[llIIIIIllIIIIl[0]]);
        String lllllllllllllllIllIllIlllIlllIlI = lllllllllllllllIllIllIlllIllllII[llIIIIIllIIIIl[1]];
        MethodHandle lllllllllllllllIllIllIlllIlllIIl = null;
        int lllllllllllllllIllIllIlllIlllIII = lllllllllllllllIllIllIlllIllllII[llIIIIIllIIIIl[2]].length();
        if (lIIIIIIllllIlIll(lllllllllllllllIllIllIlllIlllIII, llIIIIIllIIIIl[3])) {
          MethodType lllllllllllllllIllIllIlllIlllllI = MethodType.fromMethodDescriptorString(lllllllllllllllIllIllIlllIllllII[llIIIIIllIIIIl[3]], ContainerRenderer.class.getClassLoader());
          if (lIIIIIIllllIllII(lllllllllllllllIllIllIlllIlllIII, llIIIIIllIIIIl[3])) {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findVirtual(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIlllllI);
            "".length();
            if (-"   ".length() > 0)
              return null; 
          } else {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findStatic(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIlllllI);
          } 
          "".length();
          if (-" ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIllIllIlllIllllIl = llIIIIIlIllllI[Integer.parseInt(lllllllllllllllIllIllIlllIllllII[llIIIIIllIIIIl[3]])];
          if (lIIIIIIllllIllII(lllllllllllllllIllIllIlllIlllIII, llIIIIIllIIIIl[2])) {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findGetter(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIllllIl);
            "".length();
            if ("   ".length() == 0)
              return null; 
          } else if (lIIIIIIllllIllII(lllllllllllllllIllIllIlllIlllIII, llIIIIIllIIIIl[4])) {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findStaticGetter(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIllllIl);
            "".length();
            if (((0x6D ^ 0x4C) & (0xAB ^ 0x8A ^ 0xFFFFFFFF)) != 0)
              return null; 
          } else if (lIIIIIIllllIllII(lllllllllllllllIllIllIlllIlllIII, llIIIIIllIIIIl[5])) {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findSetter(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIllllIl);
            "".length();
            if (" ".length() << " ".length() == 0)
              return null; 
          } else {
            lllllllllllllllIllIllIlllIlllIIl = lllllllllllllllIllIllIlllIllIllI.findStaticSetter(lllllllllllllllIllIllIlllIlllIll, lllllllllllllllIllIllIlllIlllIlI, lllllllllllllllIllIllIlllIllllIl);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllIllIlllIlllIIl);
      } catch (Exception lllllllllllllllIllIllIlllIllIlll) {
        lllllllllllllllIllIllIlllIllIlll.printStackTrace();
        return null;
      } 
    }
    
    private static void lIIIIIIlllIlIlll() {
      llIIIIIlIlllIl = new String[llIIIIIllIIIIl[2]];
      llIIIIIlIlllIl[llIIIIIllIIIIl[1]] = llIIIIIlIlllll[llIIIIIllIIIIl[1]];
      llIIIIIlIlllIl[llIIIIIllIIIIl[0]] = llIIIIIlIlllll[llIIIIIllIIIIl[3]];
      llIIIIIlIlllIl[llIIIIIllIIIIl[3]] = llIIIIIlIlllll[llIIIIIllIIIIl[2]];
      llIIIIIlIllllI = new Class[llIIIIIllIIIIl[1]];
      llIIIIIlIllllI[llIIIIIllIIIIl[0]] = ThemeMultiplexer.class;
    }
    
    private static void lIIIIIIlllIllIll() {
      llIIIIIlIlllll = new String[llIIIIIllIIIIl[4]];
      llIIIIIlIlllll[llIIIIIllIIIIl[0]] = lIIIIIIlllIllIII(llIIIIIllIIIII[llIIIIIllIIIIl[0]], llIIIIIllIIIII[llIIIIIllIIIIl[1]]);
      llIIIIIlIlllll[llIIIIIllIIIIl[1]] = lIIIIIIlllIllIIl(llIIIIIllIIIII[llIIIIIllIIIIl[3]], llIIIIIllIIIII[llIIIIIllIIIIl[2]]);
      llIIIIIlIlllll[llIIIIIllIIIIl[3]] = lIIIIIIlllIllIlI(llIIIIIllIIIII[llIIIIIllIIIIl[4]], llIIIIIllIIIII[llIIIIIllIIIIl[5]]);
      llIIIIIlIlllll[llIIIIIllIIIIl[2]] = lIIIIIIlllIllIlI(llIIIIIllIIIII[llIIIIIllIIIIl[6]], llIIIIIllIIIII[llIIIIIllIIIIl[7]]);
      llIIIIIllIIIII = null;
    }
    
    private static void lIIIIIIlllIlllII() {
      String str = (new Exception()).getStackTrace()[llIIIIIllIIIIl[0]].getFileName();
      llIIIIIllIIIII = str.substring(str.indexOf("ä") + llIIIIIllIIIIl[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lIIIIIIlllIllIII(String lllllllllllllllIllIllIlllIllIIII, String lllllllllllllllIllIllIlllIlIllll) {
      try {
        SecretKeySpec lllllllllllllllIllIllIlllIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlllIlIllll.getBytes(StandardCharsets.UTF_8)), llIIIIIllIIIIl[8]), "DES");
        Cipher lllllllllllllllIllIllIlllIllIIlI = Cipher.getInstance("DES");
        lllllllllllllllIllIllIlllIllIIlI.init(llIIIIIllIIIIl[3], lllllllllllllllIllIllIlllIllIIll);
        return new String(lllllllllllllllIllIllIlllIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlllIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIllIlllIllIIIl) {
        lllllllllllllllIllIllIlllIllIIIl.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIIIlllIllIIl(String lllllllllllllllIllIllIlllIlIlIll, String lllllllllllllllIllIllIlllIlIlIlI) {
      try {
        SecretKeySpec lllllllllllllllIllIllIlllIlIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIlllIlIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIllIlllIlIllIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIllIlllIlIllIl.init(llIIIIIllIIIIl[3], lllllllllllllllIllIllIlllIlIlllI);
        return new String(lllllllllllllllIllIllIlllIlIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIlllIlIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllIllIlllIlIllII) {
        lllllllllllllllIllIllIlllIlIllII.printStackTrace();
        return null;
      } 
    }
    
    private static String lIIIIIIlllIllIlI(String lllllllllllllllIllIllIlllIlIlIII, String lllllllllllllllIllIllIlllIlIIlll) {
      lllllllllllllllIllIllIlllIlIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIlllIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIllIlllIlIIllI = new StringBuilder();
      char[] lllllllllllllllIllIllIlllIlIIlIl = lllllllllllllllIllIllIlllIlIIlll.toCharArray();
      int lllllllllllllllIllIllIlllIlIIlII = llIIIIIllIIIIl[0];
      char[] arrayOfChar1 = lllllllllllllllIllIllIlllIlIlIII.toCharArray();
      int i = arrayOfChar1.length;
      int j = llIIIIIllIIIIl[0];
      while (lIIIIIIllllIllIl(j, i)) {
        char lllllllllllllllIllIllIlllIlIlIIl = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllIllIlllIlIIlII++;
        j++;
        "".length();
        if (-((0x68 ^ 0x47) << " ".length() ^ (0xA4 ^ 0x89) << " ".length()) > 0)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllIllIlllIlIIllI);
    }
    
    private static void lIIIIIIllllIlIlI() {
      llIIIIIllIIIIl = new int[9];
      llIIIIIllIIIIl[0] = (0xBE ^ 0xAD) << " ".length() << " ".length() & ((0x5F ^ 0x4C) << " ".length() << " ".length() ^ 0xFFFFFFFF);
      llIIIIIllIIIIl[1] = " ".length();
      llIIIIIllIIIIl[2] = "   ".length();
      llIIIIIllIIIIl[3] = " ".length() << " ".length();
      llIIIIIllIIIIl[4] = " ".length() << " ".length() << " ".length();
      llIIIIIllIIIIl[5] = (0x8E ^ 0x85) << " ".length() << " ".length() ^ 0xB5 ^ 0x9C;
      llIIIIIllIIIIl[6] = "   ".length() << " ".length();
      llIIIIIllIIIIl[7] = 0x23 ^ 0x24;
      llIIIIIllIIIIl[8] = " ".length() << "   ".length();
    }
    
    private static boolean lIIIIIIllllIllII(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean lIIIIIIllllIllIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean lIIIIIIllllIlIll(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
  }
  
  protected class PanelRenderer extends RendererProxy {
    private static String[] lIllIlIIIIlIII;
    
    private static Class[] lIllIlIIIIlIIl;
    
    private static final String[] lIllIlIIIIlIlI;
    
    private static String[] lIllIlIIIIlIll;
    
    private static final int[] lIllIlIIIIllII;
    
    protected Renderer getRenderer() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$PanelRenderer;)Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;
      //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/ThemeMultiplexer;)Lcom/lukflug/panelstudio/theme/Theme;
      //   11: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/Theme;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   16: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	17	0	lllllllllllllllIllllIlllllIlllII	Lcom/lukflug/panelstudio/theme/ThemeMultiplexer$PanelRenderer;
    }
    
    static {
      llllIIlIIlIIlll();
      llllIIlIIlIIllI();
      llllIIlIIlIIlIl();
      llllIIlIIlIIIlI();
    }
    
    private static CallSite llllIIlIIlIIIIl(MethodHandles.Lookup lllllllllllllllIllllIlllllIlIIll, String lllllllllllllllIllllIlllllIlIIlI, MethodType lllllllllllllllIllllIlllllIlIIIl) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIllllIlllllIllIIl = lIllIlIIIIlIII[Integer.parseInt(lllllllllllllllIllllIlllllIlIIlI)].split(lIllIlIIIIlIlI[lIllIlIIIIllII[0]]);
        Class<?> lllllllllllllllIllllIlllllIllIII = Class.forName(lllllllllllllllIllllIlllllIllIIl[lIllIlIIIIllII[0]]);
        String lllllllllllllllIllllIlllllIlIlll = lllllllllllllllIllllIlllllIllIIl[lIllIlIIIIllII[1]];
        MethodHandle lllllllllllllllIllllIlllllIlIllI = null;
        int lllllllllllllllIllllIlllllIlIlIl = lllllllllllllllIllllIlllllIllIIl[lIllIlIIIIllII[2]].length();
        if (llllIIlIIlIlIII(lllllllllllllllIllllIlllllIlIlIl, lIllIlIIIIllII[3])) {
          MethodType lllllllllllllllIllllIlllllIllIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIlllllIllIIl[lIllIlIIIIllII[3]], PanelRenderer.class.getClassLoader());
          if (llllIIlIIlIlIIl(lllllllllllllllIllllIlllllIlIlIl, lIllIlIIIIllII[3])) {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findVirtual(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIll);
            "".length();
            if (" ".length() << " ".length() < ((0x9E ^ 0x9B) << " ".length() << " ".length() << " ".length() & ((0x36 ^ 0x33) << " ".length() << " ".length() << " ".length() ^ 0xFFFFFFFF)))
              return null; 
          } else {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findStatic(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIll);
          } 
          "".length();
          if (((91 + 12 - 71 + 107 ^ (0x3E ^ 0x35) << " ".length() << " ".length() << " ".length()) & (0xD2 ^ 0xBB ^ (0x8C ^ 0xA5) << " ".length() ^ -" ".length())) != (((0xE3 ^ 0xB6) << " ".length() ^ 40 + 143 - 85 + 81) << " ".length() & (((0x0 ^ 0x15) << " ".length() ^ 0x8D ^ 0xBE) << " ".length() ^ -" ".length())))
            return null; 
        } else {
          Class<?> lllllllllllllllIllllIlllllIllIlI = lIllIlIIIIlIIl[Integer.parseInt(lllllllllllllllIllllIlllllIllIIl[lIllIlIIIIllII[3]])];
          if (llllIIlIIlIlIIl(lllllllllllllllIllllIlllllIlIlIl, lIllIlIIIIllII[2])) {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findGetter(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIlI);
            "".length();
            if (((0x41 ^ 0x54) << " ".length() << " ".length() & ((0x2F ^ 0x3A) << " ".length() << " ".length() ^ 0xFFFFFFFF)) > " ".length() << " ".length() << " ".length())
              return null; 
          } else if (llllIIlIIlIlIIl(lllllllllllllllIllllIlllllIlIlIl, lIllIlIIIIllII[4])) {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findStaticGetter(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIlI);
            "".length();
            if (" ".length() << " ".length() << " ".length() == " ".length() << " ".length())
              return null; 
          } else if (llllIIlIIlIlIIl(lllllllllllllllIllllIlllllIlIlIl, lIllIlIIIIllII[5])) {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findSetter(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIlI);
            "".length();
            if ("   ".length() < 0)
              return null; 
          } else {
            lllllllllllllllIllllIlllllIlIllI = lllllllllllllllIllllIlllllIlIIll.findStaticSetter(lllllllllllllllIllllIlllllIllIII, lllllllllllllllIllllIlllllIlIlll, lllllllllllllllIllllIlllllIllIlI);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIllllIlllllIlIllI);
      } catch (Exception lllllllllllllllIllllIlllllIlIlII) {
        lllllllllllllllIllllIlllllIlIlII.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIlIIlIIIlI() {
      lIllIlIIIIlIII = new String[lIllIlIIIIllII[2]];
      lIllIlIIIIlIII[lIllIlIIIIllII[0]] = lIllIlIIIIlIlI[lIllIlIIIIllII[1]];
      lIllIlIIIIlIII[lIllIlIIIIllII[1]] = lIllIlIIIIlIlI[lIllIlIIIIllII[3]];
      lIllIlIIIIlIII[lIllIlIIIIllII[3]] = lIllIlIIIIlIlI[lIllIlIIIIllII[2]];
      lIllIlIIIIlIIl = new Class[lIllIlIIIIllII[1]];
      lIllIlIIIIlIIl[lIllIlIIIIllII[0]] = ThemeMultiplexer.class;
    }
    
    private static void llllIIlIIlIIlIl() {
      lIllIlIIIIlIlI = new String[lIllIlIIIIllII[4]];
      lIllIlIIIIlIlI[lIllIlIIIIllII[0]] = llllIIlIIlIIIll(lIllIlIIIIlIll[lIllIlIIIIllII[0]], lIllIlIIIIlIll[lIllIlIIIIllII[1]]);
      lIllIlIIIIlIlI[lIllIlIIIIllII[1]] = llllIIlIIlIIIll(lIllIlIIIIlIll[lIllIlIIIIllII[3]], lIllIlIIIIlIll[lIllIlIIIIllII[2]]);
      lIllIlIIIIlIlI[lIllIlIIIIllII[3]] = llllIIlIIlIIlII(lIllIlIIIIlIll[lIllIlIIIIllII[4]], lIllIlIIIIlIll[lIllIlIIIIllII[5]]);
      lIllIlIIIIlIlI[lIllIlIIIIllII[2]] = llllIIlIIlIIIll(lIllIlIIIIlIll[lIllIlIIIIllII[6]], lIllIlIIIIlIll[lIllIlIIIIllII[7]]);
      lIllIlIIIIlIll = null;
    }
    
    private static void llllIIlIIlIIllI() {
      String str = (new Exception()).getStackTrace()[lIllIlIIIIllII[0]].getFileName();
      lIllIlIIIIlIll = str.substring(str.indexOf("ä") + lIllIlIIIIllII[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String llllIIlIIlIIlII(String lllllllllllllllIllllIlllllIIllll, String lllllllllllllllIllllIlllllIIlllI) {
      lllllllllllllllIllllIlllllIIllll = new String(Base64.getDecoder().decode(lllllllllllllllIllllIlllllIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllllIlllllIIllIl = new StringBuilder();
      char[] lllllllllllllllIllllIlllllIIllII = lllllllllllllllIllllIlllllIIlllI.toCharArray();
      int lllllllllllllllIllllIlllllIIlIll = lIllIlIIIIllII[0];
      char[] arrayOfChar1 = lllllllllllllllIllllIlllllIIllll.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIllIlIIIIllII[0];
      while (llllIIlIIlIlIlI(j, i)) {
        char lllllllllllllllIllllIlllllIlIIII = arrayOfChar1[j];
        "".length();
        lllllllllllllllIllllIlllllIIlIll++;
        j++;
        "".length();
        if (-"   ".length() >= 0)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIllllIlllllIIllIl);
    }
    
    private static String llllIIlIIlIIIll(String lllllllllllllllIllllIlllllIIIlll, String lllllllllllllllIllllIlllllIIIllI) {
      try {
        SecretKeySpec lllllllllllllllIllllIlllllIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIlllllIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllllIlllllIIlIIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIllllIlllllIIlIIl.init(lIllIlIIIIllII[3], lllllllllllllllIllllIlllllIIlIlI);
        return new String(lllllllllllllllIllllIlllllIIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIlllllIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIllllIlllllIIlIII) {
        lllllllllllllllIllllIlllllIIlIII.printStackTrace();
        return null;
      } 
    }
    
    private static void llllIIlIIlIIlll() {
      lIllIlIIIIllII = new int[8];
      lIllIlIIIIllII[0] = ((0x50 ^ 0x49) << " ".length() ^ 0x49 ^ 0x6C) << " ".length() << " ".length() & (((0x7C ^ 0x3F) << " ".length() ^ 54 + 59 - 32 + 64) << " ".length() << " ".length() ^ -" ".length());
      lIllIlIIIIllII[1] = " ".length();
      lIllIlIIIIllII[2] = "   ".length();
      lIllIlIIIIllII[3] = " ".length() << " ".length();
      lIllIlIIIIllII[4] = " ".length() << " ".length() << " ".length();
      lIllIlIIIIllII[5] = 0x2F ^ 0x14 ^ (0x12 ^ 0xD) << " ".length();
      lIllIlIIIIllII[6] = "   ".length() << " ".length();
      lIllIlIIIIllII[7] = (0xBE ^ 0x99) << " ".length() << " ".length() ^ 18 + 85 - 21 + 73;
    }
    
    private static boolean llllIIlIIlIlIIl(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean llllIIlIIlIlIlI(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean llllIIlIIlIlIII(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\ThemeMultiplexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */