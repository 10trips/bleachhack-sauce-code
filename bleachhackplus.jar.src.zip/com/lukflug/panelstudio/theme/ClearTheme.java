package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Color;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ClearTheme implements Theme {
  protected ColorScheme scheme;
  
  protected Renderer componentRenderer;
  
  protected Renderer panelRenderer;
  
  protected final boolean gradient;
  
  private static String[] llIIIlIlIIllll;
  
  private static Class[] llIIIlIlIlIIII;
  
  private static final String[] llIIIlIlIlIIIl;
  
  private static String[] llIIIlIlIlIIlI;
  
  private static final int[] llIIIlIlIlIIll;
  
  public ClearTheme(ColorScheme lllllllllllllllIllIlIlIllIIIlIll, boolean lllllllllllllllIllIlIlIllIIIlIlI, int lllllllllllllllIllIlIlIllIIIlIIl, int lllllllllllllllIllIlIlIllIIIlIII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   11: aload_0
    //   12: iload_2
    //   13: putfield gradient : Z
    //   16: aload_0
    //   17: new com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer
    //   20: dup
    //   21: aload_0
    //   22: getstatic com/lukflug/panelstudio/theme/ClearTheme.llIIIlIlIlIIll : [I
    //   25: iconst_0
    //   26: iaload
    //   27: iload_3
    //   28: iload #4
    //   30: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/ClearTheme;ZII)V
    //   33: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/theme/ClearTheme;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   38: aload_0
    //   39: new com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer
    //   42: dup
    //   43: aload_0
    //   44: getstatic com/lukflug/panelstudio/theme/ClearTheme.llIIIlIlIlIIll : [I
    //   47: iconst_1
    //   48: iaload
    //   49: iload_3
    //   50: iload #4
    //   52: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/ClearTheme;ZII)V
    //   55: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/theme/ClearTheme;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   60: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	61	0	lllllllllllllllIllIlIlIllIIIllII	Lcom/lukflug/panelstudio/theme/ClearTheme;
    //   0	61	1	lllllllllllllllIllIlIlIllIIIlIll	Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   0	61	2	lllllllllllllllIllIlIlIllIIIlIlI	Z
    //   0	61	3	lllllllllllllllIllIlIlIllIIIlIIl	I
    //   0	61	4	lllllllllllllllIllIlIlIllIIIlIII	I
  }
  
  public Renderer getPanelRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/theme/ClearTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIlIllIIIIlll	Lcom/lukflug/panelstudio/theme/ClearTheme;
  }
  
  public Renderer getContainerRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/ClearTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIlIllIIIIllI	Lcom/lukflug/panelstudio/theme/ClearTheme;
  }
  
  public Renderer getComponentRenderer() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/ClearTheme;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlIlIllIIIIlIl	Lcom/lukflug/panelstudio/theme/ClearTheme;
  }
  
  static {
    lIIIIlIIIIlIlllI();
    lIIIIlIIIIlIllIl();
    lIIIIlIIIIlIllII();
    lIIIIlIIIIlIlIII();
  }
  
  private static CallSite lIIIIlIIIIlIIlll(MethodHandles.Lookup lllllllllllllllIllIlIlIlIlllllII, String lllllllllllllllIllIlIlIlIllllIll, MethodType lllllllllllllllIllIlIlIlIllllIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIlIllIIIIIlI = llIIIlIlIIllll[Integer.parseInt(lllllllllllllllIllIlIlIlIllllIll)].split(llIIIlIlIlIIIl[llIIIlIlIlIIll[1]]);
      Class<?> lllllllllllllllIllIlIlIllIIIIIIl = Class.forName(lllllllllllllllIllIlIlIllIIIIIlI[llIIIlIlIlIIll[1]]);
      String lllllllllllllllIllIlIlIllIIIIIII = lllllllllllllllIllIlIlIllIIIIIlI[llIIIlIlIlIIll[0]];
      MethodHandle lllllllllllllllIllIlIlIlIlllllll = null;
      int lllllllllllllllIllIlIlIlIllllllI = lllllllllllllllIllIlIlIllIIIIIlI[llIIIlIlIlIIll[2]].length();
      if (lIIIIlIIIIlIllll(lllllllllllllllIllIlIlIlIllllllI, llIIIlIlIlIIll[3])) {
        MethodType lllllllllllllllIllIlIlIllIIIIlII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIlIllIIIIIlI[llIIIlIlIlIIll[3]], ClearTheme.class.getClassLoader());
        if (lIIIIlIIIIllIIII(lllllllllllllllIllIlIlIlIllllllI, llIIIlIlIlIIll[3])) {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findVirtual(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIlII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findStatic(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIlII);
        } 
        "".length();
        if ("   ".length() == -" ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIlIllIIIIIll = llIIIlIlIlIIII[Integer.parseInt(lllllllllllllllIllIlIlIllIIIIIlI[llIIIlIlIlIIll[3]])];
        if (lIIIIlIIIIllIIII(lllllllllllllllIllIlIlIlIllllllI, llIIIlIlIlIIll[2])) {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findGetter(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIIll);
          "".length();
          if (" ".length() << " ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else if (lIIIIlIIIIllIIII(lllllllllllllllIllIlIlIlIllllllI, llIIIlIlIlIIll[4])) {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findStaticGetter(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIIll);
          "".length();
          if (" ".length() < 0)
            return null; 
        } else if (lIIIIlIIIIllIIII(lllllllllllllllIllIlIlIlIllllllI, llIIIlIlIlIIll[5])) {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findSetter(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIIll);
          "".length();
          if ((("   ".length() << "   ".length() ^ 0x8F ^ 0xC0) & (" ".length() << " ".length() ^ 0x24 ^ 0x71 ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIllIlIlIlIlllllll = lllllllllllllllIllIlIlIlIlllllII.findStaticSetter(lllllllllllllllIllIlIlIllIIIIIIl, lllllllllllllllIllIlIlIllIIIIIII, lllllllllllllllIllIlIlIllIIIIIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIlIlIlllllll);
    } catch (Exception lllllllllllllllIllIlIlIlIlllllIl) {
      lllllllllllllllIllIlIlIlIlllllIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIIIlIlIII() {
    llIIIlIlIIllll = new String[llIIIlIlIlIIll[5]];
    llIIIlIlIIllll[llIIIlIlIlIIll[0]] = llIIIlIlIlIIIl[llIIIlIlIlIIll[0]];
    llIIIlIlIIllll[llIIIlIlIlIIll[1]] = llIIIlIlIlIIIl[llIIIlIlIlIIll[3]];
    llIIIlIlIIllll[llIIIlIlIlIIll[2]] = llIIIlIlIlIIIl[llIIIlIlIlIIll[2]];
    llIIIlIlIIllll[llIIIlIlIlIIll[3]] = llIIIlIlIlIIIl[llIIIlIlIlIIll[4]];
    llIIIlIlIIllll[llIIIlIlIlIIll[4]] = llIIIlIlIlIIIl[llIIIlIlIlIIll[5]];
    llIIIlIlIlIIII = new Class[llIIIlIlIlIIll[2]];
    llIIIlIlIlIIII[llIIIlIlIlIIll[0]] = boolean.class;
    llIIIlIlIlIIII[llIIIlIlIlIIll[1]] = ColorScheme.class;
    llIIIlIlIlIIII[llIIIlIlIlIIll[3]] = Renderer.class;
  }
  
  private static void lIIIIlIIIIlIllII() {
    llIIIlIlIlIIIl = new String[llIIIlIlIlIIll[6]];
    llIIIlIlIlIIIl[llIIIlIlIlIIll[1]] = lIIIIlIIIIlIlIIl(llIIIlIlIlIIlI[llIIIlIlIlIIll[1]], llIIIlIlIlIIlI[llIIIlIlIlIIll[0]]);
    llIIIlIlIlIIIl[llIIIlIlIlIIll[0]] = lIIIIlIIIIlIlIIl(llIIIlIlIlIIlI[llIIIlIlIlIIll[3]], llIIIlIlIlIIlI[llIIIlIlIlIIll[2]]);
    llIIIlIlIlIIIl[llIIIlIlIlIIll[3]] = lIIIIlIIIIlIlIlI(llIIIlIlIlIIlI[llIIIlIlIlIIll[4]], llIIIlIlIlIIlI[llIIIlIlIlIIll[5]]);
    llIIIlIlIlIIIl[llIIIlIlIlIIll[2]] = lIIIIlIIIIlIlIlI(llIIIlIlIlIIlI[llIIIlIlIlIIll[6]], llIIIlIlIlIIlI[llIIIlIlIlIIll[7]]);
    llIIIlIlIlIIIl[llIIIlIlIlIIll[4]] = lIIIIlIIIIlIlIll(llIIIlIlIlIIlI[llIIIlIlIlIIll[8]], llIIIlIlIlIIlI[llIIIlIlIlIIll[9]]);
    llIIIlIlIlIIIl[llIIIlIlIlIIll[5]] = lIIIIlIIIIlIlIlI(llIIIlIlIlIIlI[llIIIlIlIlIIll[10]], llIIIlIlIlIIlI[llIIIlIlIlIIll[11]]);
    llIIIlIlIlIIlI = null;
  }
  
  private static void lIIIIlIIIIlIllIl() {
    String str = (new Exception()).getStackTrace()[llIIIlIlIlIIll[1]].getFileName();
    llIIIlIlIlIIlI = str.substring(str.indexOf("ä") + llIIIlIlIlIIll[0], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIIIIlIlIlI(String lllllllllllllllIllIlIlIlIllllIII, String lllllllllllllllIllIlIlIlIlllIlll) {
    lllllllllllllllIllIlIlIlIllllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIllllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlIlIlllIllI = new StringBuilder();
    char[] lllllllllllllllIllIlIlIlIlllIlIl = lllllllllllllllIllIlIlIlIlllIlll.toCharArray();
    int lllllllllllllllIllIlIlIlIlllIlII = llIIIlIlIlIIll[1];
    char[] arrayOfChar1 = lllllllllllllllIllIlIlIlIllllIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlIlIlIIll[1];
    while (lIIIIlIIIIllIIIl(j, i)) {
      char lllllllllllllllIllIlIlIlIllllIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIlIlIlllIlII++;
      j++;
      "".length();
      if (-" ".length() == " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIlIlIlllIllI);
  }
  
  private static String lIIIIlIIIIlIlIIl(String lllllllllllllllIllIlIlIlIlllIIII, String lllllllllllllllIllIlIlIlIllIllll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIlIlllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIlIllIllll.getBytes(StandardCharsets.UTF_8)), llIIIlIlIlIIll[8]), "DES");
      Cipher lllllllllllllllIllIlIlIlIlllIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlIlIlllIIlI.init(llIIIlIlIlIIll[3], lllllllllllllllIllIlIlIlIlllIIll);
      return new String(lllllllllllllllIllIlIlIlIlllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIlIlllIIIl) {
      lllllllllllllllIllIlIlIlIlllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIIIIlIlIll(String lllllllllllllllIllIlIlIlIllIlIll, String lllllllllllllllIllIlIlIlIllIlIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIlIlIllIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIlIllIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlIlIllIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlIlIllIllIl.init(llIIIlIlIlIIll[3], lllllllllllllllIllIlIlIlIllIlllI);
      return new String(lllllllllllllllIllIlIlIlIllIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIlIllIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIlIlIllIllII) {
      lllllllllllllllIllIlIlIlIllIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIIIIlIlllI() {
    llIIIlIlIlIIll = new int[12];
    llIIIlIlIlIIll[0] = " ".length();
    llIIIlIlIlIIll[1] = (0x21 ^ 0x2C) & (0xBE ^ 0xB3 ^ 0xFFFFFFFF);
    llIIIlIlIlIIll[2] = "   ".length();
    llIIIlIlIlIIll[3] = " ".length() << " ".length();
    llIIIlIlIlIIll[4] = " ".length() << " ".length() << " ".length();
    llIIIlIlIlIIll[5] = 0x4F ^ 0x4A;
    llIIIlIlIlIIll[6] = "   ".length() << " ".length();
    llIIIlIlIlIIll[7] = 0xA7 ^ 0xA0;
    llIIIlIlIlIIll[8] = " ".length() << "   ".length();
    llIIIlIlIlIIll[9] = 0x5F ^ 0x56;
    llIIIlIlIlIIll[10] = ((0x91 ^ 0x96) << "   ".length() ^ 0x19 ^ 0x24) << " ".length();
    llIIIlIlIlIIll[11] = 0x99 ^ 0x92;
  }
  
  private static boolean lIIIIlIIIIllIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIIIIllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIIIIlIllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  protected class ComponentRenderer extends RendererBase {
    protected final boolean panel;
    
    private static String[] lIlllIllIIIlIl;
    
    private static Class[] lIlllIllIIIllI;
    
    private static final String[] lIlllIlllIlIll;
    
    private static String[] lIlllIllllIIII;
    
    private static final int[] lIlllIllllIIIl;
    
    public ComponentRenderer(boolean lllllllllllllllIlllIlIIIIllIIlll, int lllllllllllllllIlllIlIIIIllIIllI, int lllllllllllllllIlllIlIIIIllIIlIl) {
      super(lllllllllllllllIlllIlIIIIllIIllI + lIlllIllllIIIl[0] * lllllllllllllllIlllIlIIIIllIIlIl, lllllllllllllllIlllIlIIIIllIIlIl, lIlllIllllIIIl[1], lIlllIllllIIIl[1], lIlllIllllIIIl[1]);
      this.panel = lllllllllllllllIlllIlIIIIllIIlll;
    }
    
    public void renderTitle(Context lllllllllllllllIlllIlIIIIlIlllll, String lllllllllllllllIlllIlIIIIlIllllI, boolean lllllllllllllllIlllIlIIIIlIlllIl, boolean lllllllllllllllIlllIlIIIIlIlllII) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   6: invokestatic lllllIlllllllll : (I)Z
      //   9: ifeq -> 41
      //   12: aload_0
      //   13: aload_1
      //   14: aload_2
      //   15: iload_3
      //   16: iload #4
      //   18: invokespecial renderTitle : (Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
      //   21: ldc ''
      //   23: invokevirtual length : ()I
      //   26: pop
      //   27: ldc ' '
      //   29: invokevirtual length : ()I
      //   32: ldc ' '
      //   34: invokevirtual length : ()I
      //   37: if_icmpge -> 231
      //   40: return
      //   41: aload_1
      //   42: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Z
      //   47: invokestatic lllllIlllllllll : (I)Z
      //   50: ifeq -> 97
      //   53: new java/awt/Color
      //   56: dup
      //   57: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   60: iconst_1
      //   61: iaload
      //   62: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   65: iconst_1
      //   66: iaload
      //   67: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   70: iconst_1
      //   71: iaload
      //   72: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   75: iconst_2
      //   76: iaload
      //   77: invokespecial <init> : (IIII)V
      //   80: astore #5
      //   82: ldc ''
      //   84: invokevirtual length : ()I
      //   87: pop
      //   88: ldc ' '
      //   90: invokevirtual length : ()I
      //   93: ifge -> 126
      //   96: return
      //   97: new java/awt/Color
      //   100: dup
      //   101: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   104: iconst_1
      //   105: iaload
      //   106: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   109: iconst_1
      //   110: iaload
      //   111: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   114: iconst_1
      //   115: iaload
      //   116: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   119: iconst_1
      //   120: iaload
      //   121: invokespecial <init> : (IIII)V
      //   124: astore #5
      //   126: aload_1
      //   127: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   132: aload_1
      //   133: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
      //   138: aload #5
      //   140: aload #5
      //   142: aload #5
      //   144: aload #5
      //   146: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   151: aload_0
      //   152: iload_3
      //   153: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   158: astore #6
      //   160: iload #4
      //   162: invokestatic lllllIlllllllll : (I)Z
      //   165: ifeq -> 182
      //   168: aload_0
      //   169: iload_3
      //   170: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   173: iconst_3
      //   174: iaload
      //   175: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;ZZ)Ljava/awt/Color;
      //   180: astore #6
      //   182: new java/awt/Point
      //   185: dup
      //   186: aload_1
      //   187: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   192: invokespecial <init> : (Ljava/awt/Point;)V
      //   195: astore #7
      //   197: aload #7
      //   199: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   202: iconst_1
      //   203: iaload
      //   204: aload_0
      //   205: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)I
      //   210: <illegal opcode> 9 : (Ljava/awt/Point;II)V
      //   215: aload_1
      //   216: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   221: aload #7
      //   223: aload_2
      //   224: aload #6
      //   226: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
      //   231: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   82	15	5	lllllllllllllllIlllIlIIIIllIIlII	Ljava/awt/Color;
      //   126	105	5	lllllllllllllllIlllIlIIIIllIIIll	Ljava/awt/Color;
      //   160	71	6	lllllllllllllllIlllIlIIIIllIIIlI	Ljava/awt/Color;
      //   197	34	7	lllllllllllllllIlllIlIIIIllIIIIl	Ljava/awt/Point;
      //   0	232	0	lllllllllllllllIlllIlIIIIllIIIII	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	232	1	lllllllllllllllIlllIlIIIIlIlllll	Lcom/lukflug/panelstudio/Context;
      //   0	232	2	lllllllllllllllIlllIlIIIIlIllllI	Ljava/lang/String;
      //   0	232	3	lllllllllllllllIlllIlIIIIlIlllIl	Z
      //   0	232	4	lllllllllllllllIlllIlIIIIlIlllII	Z
    }
    
    public void renderTitle(Context lllllllllllllllIlllIlIIIIlIlIIll, String lllllllllllllllIlllIlIIIIlIlIIlI, boolean lllllllllllllllIlllIlIIIIlIlIIIl, boolean lllllllllllllllIlllIlIIIIlIlIIII, boolean lllllllllllllllIlllIlIIIIlIIllll) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: aload_2
      //   3: iload_3
      //   4: iload #4
      //   6: iload #5
      //   8: invokespecial renderTitle : (Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZZ)V
      //   11: aload_0
      //   12: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   17: invokestatic llllllIIIIIIIII : (I)Z
      //   20: ifeq -> 547
      //   23: aload_0
      //   24: iload #4
      //   26: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   31: astore #6
      //   33: iload #5
      //   35: invokestatic lllllIlllllllll : (I)Z
      //   38: ifeq -> 287
      //   41: new java/awt/Point
      //   44: dup
      //   45: aload_1
      //   46: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   51: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   56: aload_1
      //   57: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   62: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   67: iadd
      //   68: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   71: iconst_0
      //   72: iaload
      //   73: isub
      //   74: aload_1
      //   75: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   80: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   85: aload_1
      //   86: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   91: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   96: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   99: iconst_4
      //   100: iaload
      //   101: idiv
      //   102: iadd
      //   103: invokespecial <init> : (II)V
      //   106: astore #9
      //   108: new java/awt/Point
      //   111: dup
      //   112: aload_1
      //   113: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   118: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   123: aload_1
      //   124: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   129: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   134: iadd
      //   135: aload_1
      //   136: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   141: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   146: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   149: iconst_0
      //   150: iaload
      //   151: idiv
      //   152: isub
      //   153: aload_1
      //   154: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   159: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   164: aload_1
      //   165: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   170: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   175: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   178: iconst_5
      //   179: iaload
      //   180: imul
      //   181: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   184: iconst_4
      //   185: iaload
      //   186: idiv
      //   187: iadd
      //   188: invokespecial <init> : (II)V
      //   191: astore #8
      //   193: new java/awt/Point
      //   196: dup
      //   197: aload_1
      //   198: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   203: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   208: aload_1
      //   209: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   214: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   219: iadd
      //   220: aload_1
      //   221: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   226: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   231: isub
      //   232: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   235: iconst_0
      //   236: iaload
      //   237: iadd
      //   238: aload_1
      //   239: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   244: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   249: aload_1
      //   250: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   255: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   260: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   263: iconst_4
      //   264: iaload
      //   265: idiv
      //   266: iadd
      //   267: invokespecial <init> : (II)V
      //   270: astore #7
      //   272: ldc ''
      //   274: invokevirtual length : ()I
      //   277: pop
      //   278: ldc '   '
      //   280: invokevirtual length : ()I
      //   283: ifgt -> 524
      //   286: return
      //   287: new java/awt/Point
      //   290: dup
      //   291: aload_1
      //   292: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   297: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   302: aload_1
      //   303: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   308: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   313: iadd
      //   314: aload_1
      //   315: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   320: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   325: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   328: iconst_5
      //   329: iaload
      //   330: imul
      //   331: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   334: iconst_4
      //   335: iaload
      //   336: idiv
      //   337: isub
      //   338: aload_1
      //   339: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   344: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   349: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   352: iconst_0
      //   353: iaload
      //   354: iadd
      //   355: invokespecial <init> : (II)V
      //   358: astore #9
      //   360: new java/awt/Point
      //   363: dup
      //   364: aload_1
      //   365: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   370: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   375: aload_1
      //   376: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   381: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   386: iadd
      //   387: aload_1
      //   388: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   393: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   398: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   401: iconst_4
      //   402: iaload
      //   403: idiv
      //   404: isub
      //   405: aload_1
      //   406: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   411: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   416: aload_1
      //   417: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   422: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   427: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   430: iconst_0
      //   431: iaload
      //   432: idiv
      //   433: iadd
      //   434: invokespecial <init> : (II)V
      //   437: astore #8
      //   439: new java/awt/Point
      //   442: dup
      //   443: aload_1
      //   444: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   449: <illegal opcode> 11 : (Ljava/awt/Point;)I
      //   454: aload_1
      //   455: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   460: <illegal opcode> 13 : (Ljava/awt/Dimension;)I
      //   465: iadd
      //   466: aload_1
      //   467: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   472: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   477: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   480: iconst_5
      //   481: iaload
      //   482: imul
      //   483: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   486: iconst_4
      //   487: iaload
      //   488: idiv
      //   489: isub
      //   490: aload_1
      //   491: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
      //   496: <illegal opcode> 14 : (Ljava/awt/Point;)I
      //   501: aload_1
      //   502: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
      //   507: <illegal opcode> 15 : (Ljava/awt/Dimension;)I
      //   512: iadd
      //   513: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   516: iconst_0
      //   517: iaload
      //   518: isub
      //   519: invokespecial <init> : (II)V
      //   522: astore #7
      //   524: aload_1
      //   525: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   530: aload #7
      //   532: aload #8
      //   534: aload #9
      //   536: aload #6
      //   538: aload #6
      //   540: aload #6
      //   542: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/awt/Point;Ljava/awt/Point;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   547: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   272	15	7	lllllllllllllllIlllIlIIIIlIllIll	Ljava/awt/Point;
      //   193	94	8	lllllllllllllllIlllIlIIIIlIllIlI	Ljava/awt/Point;
      //   108	179	9	lllllllllllllllIlllIlIIIIlIllIIl	Ljava/awt/Point;
      //   33	514	6	lllllllllllllllIlllIlIIIIlIllIII	Ljava/awt/Color;
      //   524	23	7	lllllllllllllllIlllIlIIIIlIlIlll	Ljava/awt/Point;
      //   439	108	8	lllllllllllllllIlllIlIIIIlIlIllI	Ljava/awt/Point;
      //   360	187	9	lllllllllllllllIlllIlIIIIlIlIlIl	Ljava/awt/Point;
      //   0	548	0	lllllllllllllllIlllIlIIIIlIlIlII	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	548	1	lllllllllllllllIlllIlIIIIlIlIIll	Lcom/lukflug/panelstudio/Context;
      //   0	548	2	lllllllllllllllIlllIlIIIIlIlIIlI	Ljava/lang/String;
      //   0	548	3	lllllllllllllllIlllIlIIIIlIlIIIl	Z
      //   0	548	4	lllllllllllllllIlllIlIIIIlIlIIII	Z
      //   0	548	5	lllllllllllllllIlllIlIIIIlIIllll	Z
    }
    
    public void renderRect(Context lllllllllllllllIlllIlIIIIlIIlIIl, String lllllllllllllllIlllIlIIIIlIIlIII, boolean lllllllllllllllIlllIlIIIIlIIIlll, boolean lllllllllllllllIlllIlIIIIlIIIllI, Rectangle lllllllllllllllIlllIlIIIIlIIIlIl, boolean lllllllllllllllIlllIlIIIIlIIIlII) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   6: invokestatic llllllIIIIIIIII : (I)Z
      //   9: ifeq -> 20
      //   12: iload #4
      //   14: invokestatic lllllIlllllllll : (I)Z
      //   17: ifeq -> 193
      //   20: aload_0
      //   21: iload_3
      //   22: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   25: iconst_3
      //   26: iaload
      //   27: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;ZZ)Ljava/awt/Color;
      //   32: astore #7
      //   34: aload_0
      //   35: iload_3
      //   36: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   41: astore #8
      //   43: aload_0
      //   44: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ClearTheme;
      //   49: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/ClearTheme;)Z
      //   54: invokestatic lllllIlllllllll : (I)Z
      //   57: ifeq -> 172
      //   60: aload_0
      //   61: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   66: invokestatic lllllIlllllllll : (I)Z
      //   69: ifeq -> 172
      //   72: aload_1
      //   73: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   78: aload #5
      //   80: aload #7
      //   82: aload #7
      //   84: aload #8
      //   86: aload #8
      //   88: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   93: ldc ''
      //   95: invokevirtual length : ()I
      //   98: pop
      //   99: sipush #251
      //   102: sipush #182
      //   105: ixor
      //   106: ldc ' '
      //   108: invokevirtual length : ()I
      //   111: ishl
      //   112: bipush #30
      //   114: bipush #85
      //   116: iadd
      //   117: bipush #96
      //   119: isub
      //   120: sipush #160
      //   123: iadd
      //   124: ixor
      //   125: ldc ' '
      //   127: invokevirtual length : ()I
      //   130: ishl
      //   131: bipush #74
      //   133: bipush #81
      //   135: ixor
      //   136: ldc ' '
      //   138: invokevirtual length : ()I
      //   141: ishl
      //   142: bipush #57
      //   144: bipush #38
      //   146: ixor
      //   147: ixor
      //   148: ldc ' '
      //   150: invokevirtual length : ()I
      //   153: ishl
      //   154: ldc ' '
      //   156: invokevirtual length : ()I
      //   159: ineg
      //   160: ixor
      //   161: iand
      //   162: ldc ' '
      //   164: invokevirtual length : ()I
      //   167: ineg
      //   168: if_icmpgt -> 193
      //   171: return
      //   172: aload_1
      //   173: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   178: aload #5
      //   180: aload #7
      //   182: aload #7
      //   184: aload #7
      //   186: aload #7
      //   188: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   193: aload_0
      //   194: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   199: invokestatic llllllIIIIIIIII : (I)Z
      //   202: ifeq -> 352
      //   205: iload #6
      //   207: invokestatic lllllIlllllllll : (I)Z
      //   210: ifeq -> 352
      //   213: aload_1
      //   214: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Z
      //   219: invokestatic lllllIlllllllll : (I)Z
      //   222: ifeq -> 298
      //   225: new java/awt/Color
      //   228: dup
      //   229: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   232: iconst_1
      //   233: iaload
      //   234: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   237: iconst_1
      //   238: iaload
      //   239: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   242: iconst_1
      //   243: iaload
      //   244: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   247: iconst_2
      //   248: iaload
      //   249: invokespecial <init> : (IIII)V
      //   252: astore #7
      //   254: ldc ''
      //   256: invokevirtual length : ()I
      //   259: pop
      //   260: ldc ' '
      //   262: invokevirtual length : ()I
      //   265: ldc ' '
      //   267: invokevirtual length : ()I
      //   270: ldc ' '
      //   272: invokevirtual length : ()I
      //   275: ishl
      //   276: ishl
      //   277: ldc ' '
      //   279: invokevirtual length : ()I
      //   282: ldc ' '
      //   284: invokevirtual length : ()I
      //   287: ldc ' '
      //   289: invokevirtual length : ()I
      //   292: ishl
      //   293: ishl
      //   294: if_icmpeq -> 327
      //   297: return
      //   298: new java/awt/Color
      //   301: dup
      //   302: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   305: iconst_1
      //   306: iaload
      //   307: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   310: iconst_1
      //   311: iaload
      //   312: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   315: iconst_1
      //   316: iaload
      //   317: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   320: iconst_1
      //   321: iaload
      //   322: invokespecial <init> : (IIII)V
      //   325: astore #7
      //   327: aload_1
      //   328: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   333: aload_1
      //   334: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
      //   339: aload #7
      //   341: aload #7
      //   343: aload #7
      //   345: aload #7
      //   347: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   352: new java/awt/Point
      //   355: dup
      //   356: aload #5
      //   358: <illegal opcode> 20 : (Ljava/awt/Rectangle;)Ljava/awt/Point;
      //   363: invokespecial <init> : (Ljava/awt/Point;)V
      //   366: astore #7
      //   368: aload #7
      //   370: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   373: iconst_1
      //   374: iaload
      //   375: aload_0
      //   376: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)I
      //   381: <illegal opcode> 9 : (Ljava/awt/Point;II)V
      //   386: aload_1
      //   387: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   392: aload #7
      //   394: aload_2
      //   395: aload_0
      //   396: iload_3
      //   397: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   402: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
      //   407: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   34	159	7	lllllllllllllllIlllIlIIIIlIIlllI	Ljava/awt/Color;
      //   43	150	8	lllllllllllllllIlllIlIIIIlIIllIl	Ljava/awt/Color;
      //   254	44	7	lllllllllllllllIlllIlIIIIlIIllII	Ljava/awt/Color;
      //   327	25	7	lllllllllllllllIlllIlIIIIlIIlIll	Ljava/awt/Color;
      //   0	408	0	lllllllllllllllIlllIlIIIIlIIlIlI	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	408	1	lllllllllllllllIlllIlIIIIlIIlIIl	Lcom/lukflug/panelstudio/Context;
      //   0	408	2	lllllllllllllllIlllIlIIIIlIIlIII	Ljava/lang/String;
      //   0	408	3	lllllllllllllllIlllIlIIIIlIIIlll	Z
      //   0	408	4	lllllllllllllllIlllIlIIIIlIIIllI	Z
      //   0	408	5	lllllllllllllllIlllIlIIIIlIIIlIl	Ljava/awt/Rectangle;
      //   0	408	6	lllllllllllllllIlllIlIIIIlIIIlII	Z
      //   368	40	7	lllllllllllllllIlllIlIIIIlIIIIll	Ljava/awt/Point;
    }
    
    public void renderBackground(Context lllllllllllllllIlllIlIIIIlIIIIII, boolean lllllllllllllllIlllIlIIIIIllllll) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Z
      //   6: invokestatic lllllIlllllllll : (I)Z
      //   9: ifeq -> 41
      //   12: aload_0
      //   13: iload_2
      //   14: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;Z)Ljava/awt/Color;
      //   19: astore_3
      //   20: aload_1
      //   21: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
      //   26: aload_1
      //   27: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
      //   32: aload_3
      //   33: aload_3
      //   34: aload_3
      //   35: aload_3
      //   36: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
      //   41: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   20	21	3	lllllllllllllllIlllIlIIIIlIIIIlI	Ljava/awt/Color;
      //   0	42	0	lllllllllllllllIlllIlIIIIlIIIIIl	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	42	1	lllllllllllllllIlllIlIIIIlIIIIII	Lcom/lukflug/panelstudio/Context;
      //   0	42	2	lllllllllllllllIlllIlIIIIIllllll	Z
    }
    
    public void renderBorder(Context lllllllllllllllIlllIlIIIIIllllIl, boolean lllllllllllllllIlllIlIIIIIllllII, boolean lllllllllllllllIlllIlIIIIIlllIll, boolean lllllllllllllllIlllIlIIIIIlllIlI) {}
    
    public Color getMainColor(boolean lllllllllllllllIlllIlIIIIIlllIII, boolean lllllllllllllllIlllIlIIIIIllIlll) {
      // Byte code:
      //   0: iload_2
      //   1: invokestatic lllllIlllllllll : (I)Z
      //   4: ifeq -> 19
      //   7: aload_0
      //   8: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   13: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   18: areturn
      //   19: new java/awt/Color
      //   22: dup
      //   23: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   26: iconst_1
      //   27: iaload
      //   28: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   31: iconst_1
      //   32: iaload
      //   33: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   36: iconst_1
      //   37: iaload
      //   38: getstatic com/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer.lIlllIllllIIIl : [I
      //   41: iconst_1
      //   42: iaload
      //   43: invokespecial <init> : (IIII)V
      //   46: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	47	0	lllllllllllllllIlllIlIIIIIlllIIl	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	47	1	lllllllllllllllIlllIlIIIIIlllIII	Z
      //   0	47	2	lllllllllllllllIlllIlIIIIIllIlll	Z
    }
    
    public Color getBackgroundColor(boolean lllllllllllllllIlllIlIIIIIllIlIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   6: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
      //   11: astore_2
      //   12: new java/awt/Color
      //   15: dup
      //   16: aload_2
      //   17: <illegal opcode> 24 : (Ljava/awt/Color;)I
      //   22: aload_2
      //   23: <illegal opcode> 25 : (Ljava/awt/Color;)I
      //   28: aload_2
      //   29: <illegal opcode> 26 : (Ljava/awt/Color;)I
      //   34: aload_0
      //   35: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   40: <illegal opcode> 27 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)I
      //   45: invokespecial <init> : (IIII)V
      //   48: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	49	0	lllllllllllllllIlllIlIIIIIllIllI	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
      //   0	49	1	lllllllllllllllIlllIlIIIIIllIlIl	Z
      //   12	37	2	lllllllllllllllIlllIlIIIIIllIlII	Ljava/awt/Color;
    }
    
    public ColorScheme getDefaultColorScheme() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;)Lcom/lukflug/panelstudio/theme/ClearTheme;
      //   6: <illegal opcode> 28 : (Lcom/lukflug/panelstudio/theme/ClearTheme;)Lcom/lukflug/panelstudio/theme/ColorScheme;
      //   11: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	lllllllllllllllIlllIlIIIIIllIIll	Lcom/lukflug/panelstudio/theme/ClearTheme$ComponentRenderer;
    }
    
    static {
      lllllIllllllllI();
      lllllIlllllIIIl();
      lllllIlllllIIII();
      lllllIllllIlIIl();
    }
    
    private static CallSite lllllIllIIIlIII(MethodHandles.Lookup lllllllllllllllIlllIlIIIIIlIlIlI, String lllllllllllllllIlllIlIIIIIlIlIIl, MethodType lllllllllllllllIlllIlIIIIIlIlIII) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIlllIlIIIIIllIIII = lIlllIllIIIlIl[Integer.parseInt(lllllllllllllllIlllIlIIIIIlIlIIl)].split(lIlllIlllIlIll[lIlllIllllIIIl[1]]);
        Class<?> lllllllllllllllIlllIlIIIIIlIllll = Class.forName(lllllllllllllllIlllIlIIIIIllIIII[lIlllIllllIIIl[1]]);
        String lllllllllllllllIlllIlIIIIIlIlllI = lllllllllllllllIlllIlIIIIIllIIII[lIlllIllllIIIl[3]];
        MethodHandle lllllllllllllllIlllIlIIIIIlIllIl = null;
        int lllllllllllllllIlllIlIIIIIlIllII = lllllllllllllllIlllIlIIIIIllIIII[lIlllIllllIIIl[5]].length();
        if (llllllIIIIIIIll(lllllllllllllllIlllIlIIIIIlIllII, lIlllIllllIIIl[0])) {
          MethodType lllllllllllllllIlllIlIIIIIllIIlI = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIlIIIIIllIIII[lIlllIllllIIIl[0]], ComponentRenderer.class.getClassLoader());
          if (llllllIIIIIIlII(lllllllllllllllIlllIlIIIIIlIllII, lIlllIllllIIIl[0])) {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findVirtual(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIlI);
            "".length();
            if (" ".length() << " ".length() << " ".length() == 0)
              return null; 
          } else {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findStatic(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIlI);
          } 
          "".length();
          if (" ".length() << " ".length() << " ".length() < " ".length())
            return null; 
        } else {
          Class<?> lllllllllllllllIlllIlIIIIIllIIIl = lIlllIllIIIllI[Integer.parseInt(lllllllllllllllIlllIlIIIIIllIIII[lIlllIllllIIIl[0]])];
          if (llllllIIIIIIlII(lllllllllllllllIlllIlIIIIIlIllII, lIlllIllllIIIl[5])) {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findGetter(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIIl);
            "".length();
            if ("   ".length() != "   ".length())
              return null; 
          } else if (llllllIIIIIIlII(lllllllllllllllIlllIlIIIIIlIllII, lIlllIllllIIIl[4])) {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findStaticGetter(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIIl);
            "".length();
            if (-"   ".length() >= 0)
              return null; 
          } else if (llllllIIIIIIlII(lllllllllllllllIlllIlIIIIIlIllII, lIlllIllllIIIl[6])) {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findSetter(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIIl);
            "".length();
            if (-" ".length() >= " ".length())
              return null; 
          } else {
            lllllllllllllllIlllIlIIIIIlIllIl = lllllllllllllllIlllIlIIIIIlIlIlI.findStaticSetter(lllllllllllllllIlllIlIIIIIlIllll, lllllllllllllllIlllIlIIIIIlIlllI, lllllllllllllllIlllIlIIIIIllIIIl);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIlllIlIIIIIlIllIl);
      } catch (Exception lllllllllllllllIlllIlIIIIIlIlIll) {
        lllllllllllllllIlllIlIIIIIlIlIll.printStackTrace();
        return null;
      } 
    }
    
    private static void lllllIllllIlIIl() {
      lIlllIllIIIlIl = new String[lIlllIllllIIIl[7]];
      lIlllIllIIIlIl[lIlllIllllIIIl[8]] = lIlllIlllIlIll[lIlllIllllIIIl[3]];
      lIlllIllIIIlIl[lIlllIllllIIIl[9]] = lIlllIlllIlIll[lIlllIllllIIIl[0]];
      lIlllIllIIIlIl[lIlllIllllIIIl[10]] = lIlllIlllIlIll[lIlllIllllIIIl[5]];
      lIlllIllIIIlIl[lIlllIllllIIIl[11]] = lIlllIlllIlIll[lIlllIllllIIIl[4]];
      lIlllIllIIIlIl[lIlllIllllIIIl[12]] = lIlllIlllIlIll[lIlllIllllIIIl[6]];
      lIlllIllIIIlIl[lIlllIllllIIIl[13]] = lIlllIlllIlIll[lIlllIllllIIIl[14]];
      lIlllIllIIIlIl[lIlllIllllIIIl[15]] = lIlllIlllIlIll[lIlllIllllIIIl[16]];
      lIlllIllIIIlIl[lIlllIllllIIIl[17]] = lIlllIlllIlIll[lIlllIllllIIIl[12]];
      lIlllIllIIIlIl[lIlllIllllIIIl[18]] = lIlllIlllIlIll[lIlllIllllIIIl[15]];
      lIlllIllIIIlIl[lIlllIllllIIIl[4]] = lIlllIlllIlIll[lIlllIllllIIIl[19]];
      lIlllIllIIIlIl[lIlllIllllIIIl[19]] = lIlllIlllIlIll[lIlllIllllIIIl[17]];
      lIlllIllIIIlIl[lIlllIllllIIIl[20]] = lIlllIlllIlIll[lIlllIllllIIIl[11]];
      lIlllIllIIIlIl[lIlllIllllIIIl[21]] = lIlllIlllIlIll[lIlllIllllIIIl[22]];
      lIlllIllIIIlIl[lIlllIllllIIIl[22]] = lIlllIlllIlIll[lIlllIllllIIIl[8]];
      lIlllIllIIIlIl[lIlllIllllIIIl[5]] = lIlllIlllIlIll[lIlllIllllIIIl[23]];
      lIlllIllIIIlIl[lIlllIllllIIIl[23]] = lIlllIlllIlIll[lIlllIllllIIIl[24]];
      lIlllIllIIIlIl[lIlllIllllIIIl[25]] = lIlllIlllIlIll[lIlllIllllIIIl[26]];
      lIlllIllIIIlIl[lIlllIllllIIIl[16]] = lIlllIlllIlIll[lIlllIllllIIIl[20]];
      lIlllIllIIIlIl[lIlllIllllIIIl[6]] = lIlllIlllIlIll[lIlllIllllIIIl[27]];
      lIlllIllIIIlIl[lIlllIllllIIIl[26]] = lIlllIlllIlIll[lIlllIllllIIIl[28]];
      lIlllIllIIIlIl[lIlllIllllIIIl[28]] = lIlllIlllIlIll[lIlllIllllIIIl[10]];
      lIlllIllIIIlIl[lIlllIllllIIIl[29]] = lIlllIlllIlIll[lIlllIllllIIIl[21]];
      lIlllIllIIIlIl[lIlllIllllIIIl[27]] = lIlllIlllIlIll[lIlllIllllIIIl[9]];
      lIlllIllIIIlIl[lIlllIllllIIIl[1]] = lIlllIlllIlIll[lIlllIllllIIIl[30]];
      lIlllIllIIIlIl[lIlllIllllIIIl[3]] = lIlllIlllIlIll[lIlllIllllIIIl[18]];
      lIlllIllIIIlIl[lIlllIllllIIIl[30]] = lIlllIlllIlIll[lIlllIllllIIIl[13]];
      lIlllIllIIIlIl[lIlllIllllIIIl[14]] = lIlllIlllIlIll[lIlllIllllIIIl[25]];
      lIlllIllIIIlIl[lIlllIllllIIIl[0]] = lIlllIlllIlIll[lIlllIllllIIIl[29]];
      lIlllIllIIIlIl[lIlllIllllIIIl[24]] = lIlllIlllIlIll[lIlllIllllIIIl[7]];
      lIlllIllIIIllI = new Class[lIlllIllllIIIl[4]];
      lIlllIllIIIllI[lIlllIllllIIIl[1]] = ClearTheme.class;
      lIlllIllIIIllI[lIlllIllllIIIl[3]] = boolean.class;
      lIlllIllIIIllI[lIlllIllllIIIl[5]] = ColorScheme.class;
      lIlllIllIIIllI[lIlllIllllIIIl[0]] = int.class;
    }
    
    private static void lllllIlllllIIII() {
      lIlllIlllIlIll = new String[lIlllIllllIIIl[31]];
      lIlllIlllIlIll[lIlllIllllIIIl[1]] = lllllIllllIlIlI(lIlllIllllIIII[lIlllIllllIIIl[1]], lIlllIllllIIII[lIlllIllllIIIl[3]]);
      lIlllIlllIlIll[lIlllIllllIIIl[3]] = lllllIllllIlIlI(lIlllIllllIIII[lIlllIllllIIIl[0]], lIlllIllllIIII[lIlllIllllIIIl[5]]);
      lIlllIlllIlIll[lIlllIllllIIIl[0]] = lllllIllllIlIll(lIlllIllllIIII[lIlllIllllIIIl[4]], lIlllIllllIIII[lIlllIllllIIIl[6]]);
      lIlllIlllIlIll[lIlllIllllIIIl[5]] = lllllIllllIllII(lIlllIllllIIII[lIlllIllllIIIl[14]], lIlllIllllIIII[lIlllIllllIIIl[16]]);
      lIlllIlllIlIll[lIlllIllllIIIl[4]] = lllllIllllIlIlI(lIlllIllllIIII[lIlllIllllIIIl[12]], lIlllIllllIIII[lIlllIllllIIIl[15]]);
      lIlllIlllIlIll[lIlllIllllIIIl[6]] = lllllIllllIlIlI("rQoAACE8Mjqb5Micqnmc5DBRVSMuSfmXPlTJDnaFyPb3A/sZDn50eiNcxKXaGRzpOY1F31yYZBcYeAfZJz6YaToqMnk2f2n6eqRtxmt+nh4=", "ncWUY");
      lIlllIlllIlIll[lIlllIllllIIIl[14]] = lllllIllllIlIll("BAgjLm0PHiFhAAEFOj15CQwhDS8bDG9naidTdW8=", "niUOC");
      lIlllIlllIlIll[lIlllIllllIIIl[16]] = lllllIllllIllII("WbDonllTLgsoWNXDvhfKarz8DtTjxNP1PwbF6oSUGgvwCJxw0PHs+A==", "ekTIo");
      lIlllIlllIlIll[lIlllIllllIIIl[12]] = lllllIllllIlIll("KSgbGEoiPhlXNCwgAw1eO3NfQ0RjaQ==", "CImyd");
      lIlllIlllIlIll[lIlllIllllIIIl[15]] = lllllIllllIlIll("GQc+LEwSETxjIRwKJz9YFAM8ChAWAyZ3Slovcm1C", "sfHMb");
      lIlllIlllIlIll[lIlllIllllIIIl[19]] = lllllIllllIlIlI("psK7cwHs3teaXP3SEFrzKG9/Y6qQKJ36wc6rKg16LqBBkJhLtyCGHElJHcEr7lNC87vnSM5xXGsKTp0+8nzhpFS9tHUhfXJJqCnUJmtW+7dUvbR1IX1ySagp1CZrVvu3VL20dSF9ckmoKdQma1b7t1S9tHUhfXJJqCnUJmtW+7eEkHbSJAoiHg==", "cqIrQ");
      lIlllIlllIlIll[lIlllIllllIIIl[17]] = lllllIllllIlIlI("dzTIHzC9qNJUFOYvw7AKCh7IiLcE3QyFR7iwRP0pS3DD0T43OEpHNLxo6dv6PsZsUurdxW+aBvAr9XT1H2T05S5YUxuH5OnJO63xuXIcHBPmQdWAUgt14rqOdd9j3xtgq7447/M9M/c=", "IifjF");
      lIlllIlllIlIll[lIlllIllllIIIl[11]] = lllllIllllIllII("gLLw0A0fkJwCKqpsJHtceY+H0goLnNfa4x0FkuVfUHptcrBPwM2x2Nq9A5KKWAnwyL+Qu2AXrhsto6R3Vl5yGk47+sHRA4Fv", "rEdhu");
      lIlllIlllIlIll[lIlllIllllIIIl[22]] = lllllIllllIlIlI("4D/nTYtun2uV1a69ZMRdtx49oXe3XGLYPKpqR2nub+QVZlJcMUjZGY/BwvO69izV7M5wQWcCiu4zPYonowycpfrLNQKaG4cpoBs+KuRUT3g=", "eLPNJ");
      lIlllIlllIlIll[lIlllIllllIIIl[8]] = lllllIllllIlIll("OTcHC2MyIQVECTo7FAQ+OjkfUDo6MgUCd2FsUUpt", "SVqjM");
      lIlllIlllIlIll[lIlllIllllIIIl[23]] = lllllIllllIlIlI("6fv1qNUUcNmy7JrMMlJBNKdx+Xn+Lm9mw7AN4XfuX732ghmhoHVeln2U29769A+/vB6Jii+9QXknKd/B8peDGJskoZdsn7aC", "lWuUi");
      lIlllIlllIlIll[lIlllIllllIIIl[24]] = lllllIllllIlIlI("QLkWEVgSgyiswmYwphLhe8u2Smi6oeO/j9lG5T6/SbA=", "kODFL");
      lIlllIlllIlIll[lIlllIllllIIIl[26]] = lllllIllllIlIlI("DxrtMQN7muTfb50978fu3XUz395WkYafDVOeK//xpTb66f7RGQbUW0cgH4t54nVoypl0O5Q6em+60NrgtsKUow==", "niyHL");
      lIlllIlllIlIll[lIlllIllllIIIl[20]] = lllllIllllIlIlI("nz1NMWUfML38HvRWfxLt1GSwa09uVxAxXOcZhwAhaLvhL//3Jmpj1Pc1u8oZvxBLWTNBmHF0Kb0Mu1eQvLkWvA==", "tcrLL");
      lIlllIlllIlIll[lIlllIllllIIIl[27]] = lllllIllllIlIll("EBgJSwoGHAIJExRZFAQIFhsXERMXHgtLEhsSCQBIMBsBBBQnHwEIA1c0CwgWHBkBCxIhEgoBAwESFl8BFgMiCggHNAsJCQFNTD9PPx0FEwdcFhMRSTAYCAoUSE1ERQ==", "swdef");
      lIlllIlllIlIll[lIlllIllllIIIl[28]] = lllllIllllIllII("yyJkZX3Aj2/NIKX/tBDSP1L8Mt/8IjVT3k3s7gxNoCMPFBw/1AxVu/7U8FW1TepiE1sOjXPUwsxAlF0XKjZKfLPBaH/QkTBqq4MpWa8S4ra7V1ECstwaHAZ32v67tUh8HdK9nkcaVoo=", "aEGPn");
      lIlllIlllIlIll[lIlllIllllIIIl[10]] = lllllIllllIlIlI("ZToWjayuvnxDH2JZI+Hkq4vVPfYq6NqoCKvXxoVWPWzVvpYpZNNrHSKHRrST3eOsAZoh+NxSMz4=", "jyeKZ");
      lIlllIlllIlIll[lIlllIllllIIIl[21]] = lllllIllllIllII("HFP2ePKOvNo/muj8mbDYBXjvD8dzHqEBu0oMlw65dGYYirdW1ygLgcMg+Y55knQ/TEIR5d4YWIM=", "uqqFV");
      lIlllIlllIlIll[lIlllIllllIIIl[9]] = lllllIllllIlIll("Cy41fi4dKj48Nw9vKDEsDS0rJDcMKDd+NgAkNTVsKy09MTA8KT09J1ImKjEmASQ2JHhZe3hwYg==", "hAXPB");
      lIlllIlllIlIll[lIlllIllllIIIl[30]] = lllllIllllIlIll("FTcgdAIDMys2GxF2PTsAEzQ+LhsSMSJ0Gh49ID9ANTQoOxwiMCg3C1IbIjceGTYoNBokPSM+CwQ9P2AeFzYoNlRHYm16Tg==", "vXMZn");
      lIlllIlllIlIll[lIlllIllllIIIl[18]] = lllllIllllIllII("8BnEpp7IEYDM1oVSBBHl7e2m+y8ZdJHsM7/+Z1Tk+7FeEyxIJdI8UkxITScqT/dBMauSOLwq8V8=", "aBWct");
      lIlllIlllIlIll[lIlllIllllIIIl[13]] = lllllIllllIllII("iOb7KWdmRWG9ArxVNHXxVUDm+aerGwUA9mngb6BrwAs=", "PgqZS");
      lIlllIlllIlIll[lIlllIllllIIIl[25]] = lllllIllllIlIlI("xpwGwsyvmUI/Och55Agcoov5SUNXd62aCWmv9xsmjbHvCeUc/MNXxdb+dcjOJspy/ndPGqWHTbvAgf3rwgElMjU0Wu5rfKnqfAqT9M2DTDOOaMDX4voiaSBKuACgRHTP", "heRvE");
      lIlllIlllIlIll[lIlllIllllIIIl[29]] = lllllIllllIlIlI("9hKwT+0RAERkR0iJ+pv2KugF0KbTTyglUoN6OHeu+lvkONEwhM8BrbzJbT3nLfN3wqe/+4SC2CSgWInXt6o/4742ltEIdu08J/Ir2DQv0M2AD2pBwLaYwQ==", "gJCct");
      lIlllIlllIlIll[lIlllIllllIIIl[7]] = lllllIllllIlIlI("VRBT7nzEy2DzNwKJsMZZRGKVUdoiHrkeZg5/jm9QsrvBY+TYYS0mVm0rphzVhoCS7vPhMeBKg/Xf7+jxTCstLO7z4THgSoP13+/o8UwrLSzu8+Ex4EqD9d/v6PFMKy0s7vPhMeBKg/Vw8oHrmLDUqe7z4THgSoP1cPKB65iw1Knu8+Ex4EqD9XDygeuYsNSppImIgvnG/1M=", "fnIHW");
      lIlllIllllIIII = null;
    }
    
    private static void lllllIlllllIIIl() {
      String str = (new Exception()).getStackTrace()[lIlllIllllIIIl[1]].getFileName();
      lIlllIllllIIII = str.substring(str.indexOf("ä") + lIlllIllllIIIl[3], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String lllllIllllIllII(String lllllllllllllllIlllIlIIIIIlIIlII, String lllllllllllllllIlllIlIIIIIlIIIll) {
      try {
        SecretKeySpec lllllllllllllllIlllIlIIIIIlIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIIIlIIIll.getBytes(StandardCharsets.UTF_8)), lIlllIllllIIIl[12]), "DES");
        Cipher lllllllllllllllIlllIlIIIIIlIIllI = Cipher.getInstance("DES");
        lllllllllllllllIlllIlIIIIIlIIllI.init(lIlllIllllIIIl[0], lllllllllllllllIlllIlIIIIIlIIlll);
        return new String(lllllllllllllllIlllIlIIIIIlIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIIIlIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIlIIIIIlIIlIl) {
        lllllllllllllllIlllIlIIIIIlIIlIl.printStackTrace();
        return null;
      } 
    }
    
    private static String lllllIllllIlIlI(String lllllllllllllllIlllIlIIIIIIlllll, String lllllllllllllllIlllIlIIIIIIllllI) {
      try {
        SecretKeySpec lllllllllllllllIlllIlIIIIIlIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlIIIIIIllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlllIlIIIIIlIIIIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIlllIlIIIIIlIIIIl.init(lIlllIllllIIIl[0], lllllllllllllllIlllIlIIIIIlIIIlI);
        return new String(lllllllllllllllIlllIlIIIIIlIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIIIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIlIIIIIlIIIII) {
        lllllllllllllllIlllIlIIIIIlIIIII.printStackTrace();
        return null;
      } 
    }
    
    private static String lllllIllllIlIll(String lllllllllllllllIlllIlIIIIIIlllII, String lllllllllllllllIlllIlIIIIIIllIll) {
      lllllllllllllllIlllIlIIIIIIlllII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIlIIIIIIlllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlllIlIIIIIIllIlI = new StringBuilder();
      char[] lllllllllllllllIlllIlIIIIIIllIIl = lllllllllllllllIlllIlIIIIIIllIll.toCharArray();
      int lllllllllllllllIlllIlIIIIIIllIII = lIlllIllllIIIl[1];
      char[] arrayOfChar1 = lllllllllllllllIlllIlIIIIIIlllII.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIlllIllllIIIl[1];
      while (llllllIIIIIIlIl(j, i)) {
        char lllllllllllllllIlllIlIIIIIIlllIl = arrayOfChar1[j];
        "".length();
        lllllllllllllllIlllIlIIIIIIllIII++;
        j++;
        "".length();
        if ("   ".length() <= " ".length() << " ".length())
          return null; 
      } 
      return String.valueOf(lllllllllllllllIlllIlIIIIIIllIlI);
    }
    
    private static void lllllIllllllllI() {
      lIlllIllllIIIl = new int[32];
      lIlllIllllIIIl[0] = " ".length() << " ".length();
      lIlllIllllIIIl[1] = ((0xE2 ^ 0xC3) << " ".length() << " ".length() ^ 34 + 13 - 24 + 120) << "   ".length() & (((0x5D ^ 0x4C) << " ".length() << " ".length() ^ 0x13 ^ 0x5C) << "   ".length() ^ -" ".length());
      lIlllIllllIIIl[2] = " ".length() << "   ".length() << " ".length();
      lIlllIllllIIIl[3] = " ".length();
      lIlllIllllIIIl[4] = " ".length() << " ".length() << " ".length();
      lIlllIllllIIIl[5] = "   ".length();
      lIlllIllllIIIl[6] = 0x1B ^ 0x1E;
      lIlllIllllIIIl[7] = 0xEA ^ 0xBB ^ (0xD2 ^ 0xC1) << " ".length() << " ".length();
      lIlllIllllIIIl[8] = ((0xB4 ^ 0xA7) << " ".length() ^ 0x4C ^ 0x6D) << " ".length();
      lIlllIllllIIIl[9] = 0x8E ^ 0x99;
      lIlllIllllIIIl[10] = 0x7F ^ 0x6A;
      lIlllIllllIIIl[11] = "   ".length() << " ".length() << " ".length();
      lIlllIllllIIIl[12] = " ".length() << "   ".length();
      lIlllIllllIIIl[13] = ((0x11 ^ 0x3E) << " ".length() << " ".length() ^ 92 + 40 - -13 + 32) << " ".length();
      lIlllIllllIIIl[14] = "   ".length() << " ".length();
      lIlllIllllIIIl[15] = 8 + 153 - 135 + 149 ^ (0xDA ^ 0x89) << " ".length();
      lIlllIllllIIIl[16] = 46 + 64 - -11 + 46 ^ (0x8D ^ 0x88) << (0x27 ^ 0x22);
      lIlllIllllIIIl[17] = 0xCB ^ 0xC0;
      lIlllIllllIIIl[18] = 0x43 ^ 0x5A;
      lIlllIllllIIIl[19] = (0x66 ^ 0x63) << " ".length();
      lIlllIllllIIIl[20] = (78 + 72 - 105 + 128 ^ (0x48 ^ 0x61) << " ".length() << " ".length()) << " ".length();
      lIlllIllllIIIl[21] = ((0x20 ^ 0x35) << "   ".length() ^ 41 + 26 - 11 + 107) << " ".length();
      lIlllIllllIIIl[22] = (0xF1 ^ 0xC0) << " ".length() ^ 0x38 ^ 0x57;
      lIlllIllllIIIl[23] = (0xBC ^ 0x8B) << " ".length() ^ 0x51 ^ 0x30;
      lIlllIllllIIIl[24] = " ".length() << " ".length() << " ".length() << " ".length();
      lIlllIllllIIIl[25] = 54 + 143 - 92 + 56 ^ (0x38 ^ 0x65) << " ".length();
      lIlllIllllIIIl[26] = 0x1C ^ 0xD;
      lIlllIllllIIIl[27] = 0x1D ^ 0x50 ^ (0x4F ^ 0x60) << " ".length();
      lIlllIllllIIIl[28] = (0x7 ^ 0x2) << " ".length() << " ".length();
      lIlllIllllIIIl[29] = (154 + 145 - 253 + 127 ^ (0x22 ^ 0x77) << " ".length()) << " ".length() << " ".length();
      lIlllIllllIIIl[30] = "   ".length() << "   ".length();
      lIlllIllllIIIl[31] = (2 + 159 - 31 + 39 ^ (0xCE ^ 0x9D) << " ".length()) << " ".length();
    }
    
    private static boolean llllllIIIIIIlII(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean llllllIIIIIIlIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean llllllIIIIIIIll(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean lllllIlllllllll(int param1Int) {
      return (param1Int != 0);
    }
    
    private static boolean llllllIIIIIIIII(int param1Int) {
      return (param1Int == 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\ClearTheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */