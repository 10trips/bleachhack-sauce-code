package com.lukflug.panelstudio.theme;

import com.lukflug.panelstudio.Context;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MouseDescription implements DescriptionRenderer {
  protected Point offset;
  
  private static String[] llIIIllllIlIlI;
  
  private static Class[] llIIIllllIlIll;
  
  private static final String[] llIIIllllIllll;
  
  private static String[] llIIIlllllIIII;
  
  private static final int[] llIIIlllllIIIl;
  
  public MouseDescription(Point lllllllllllllllIllIlIIIIIllllIII) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/theme/MouseDescription;Ljava/awt/Point;)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlIIIIIllllIIl	Lcom/lukflug/panelstudio/theme/MouseDescription;
    //   0	12	1	lllllllllllllllIllIlIIIIIllllIII	Ljava/awt/Point;
  }
  
  public void renderDescription(Context lllllllllllllllIllIlIIIIIlllIIlI) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   6: invokestatic lIIIIlIllIlIlIlI : (Ljava/lang/Object;)Z
    //   9: ifeq -> 204
    //   12: aload_1
    //   13: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
    //   23: astore_2
    //   24: aload_2
    //   25: aload_0
    //   26: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/MouseDescription;)Ljava/awt/Point;
    //   31: <illegal opcode> 5 : (Ljava/awt/Point;)I
    //   36: aload_0
    //   37: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/MouseDescription;)Ljava/awt/Point;
    //   42: <illegal opcode> 6 : (Ljava/awt/Point;)I
    //   47: <illegal opcode> 7 : (Ljava/awt/Point;II)V
    //   52: new java/awt/Rectangle
    //   55: dup
    //   56: aload_2
    //   57: new java/awt/Dimension
    //   60: dup
    //   61: aload_1
    //   62: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   67: aload_1
    //   68: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   73: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/Interface;Ljava/lang/String;)I
    //   78: aload_1
    //   79: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   84: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/Interface;)I
    //   89: invokespecial <init> : (II)V
    //   92: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
    //   95: astore_3
    //   96: new java/awt/Color
    //   99: dup
    //   100: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   103: iconst_0
    //   104: iaload
    //   105: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   108: iconst_0
    //   109: iaload
    //   110: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   113: iconst_0
    //   114: iaload
    //   115: invokespecial <init> : (III)V
    //   118: astore #4
    //   120: aload_1
    //   121: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   126: aload_3
    //   127: aload #4
    //   129: aload #4
    //   131: aload #4
    //   133: aload #4
    //   135: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   140: new java/awt/Color
    //   143: dup
    //   144: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   147: iconst_1
    //   148: iaload
    //   149: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   152: iconst_1
    //   153: iaload
    //   154: getstatic com/lukflug/panelstudio/theme/MouseDescription.llIIIlllllIIIl : [I
    //   157: iconst_1
    //   158: iaload
    //   159: invokespecial <init> : (III)V
    //   162: astore #5
    //   164: aload_1
    //   165: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   170: aload_3
    //   171: aload #5
    //   173: aload #5
    //   175: aload #5
    //   177: aload #5
    //   179: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   184: aload_1
    //   185: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   190: aload_2
    //   191: aload_1
    //   192: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   197: aload #5
    //   199: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
    //   204: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   24	180	2	lllllllllllllllIllIlIIIIIlllIlll	Ljava/awt/Point;
    //   96	108	3	lllllllllllllllIllIlIIIIIlllIllI	Ljava/awt/Rectangle;
    //   120	84	4	lllllllllllllllIllIlIIIIIlllIlIl	Ljava/awt/Color;
    //   164	40	5	lllllllllllllllIllIlIIIIIlllIlII	Ljava/awt/Color;
    //   0	205	0	lllllllllllllllIllIlIIIIIlllIIll	Lcom/lukflug/panelstudio/theme/MouseDescription;
    //   0	205	1	lllllllllllllllIllIlIIIIIlllIIlI	Lcom/lukflug/panelstudio/Context;
  }
  
  static {
    lIIIIlIllIlIlIIl();
    lIIIIlIllIlIlIII();
    lIIIIlIllIlIIlll();
    lIIIIlIllIlIIIll();
  }
  
  private static CallSite lIIIIlIllIlIIIIl(MethodHandles.Lookup lllllllllllllllIllIlIIIIIllIlIIl, String lllllllllllllllIllIlIIIIIllIlIII, MethodType lllllllllllllllIllIlIIIIIllIIlll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlIIIIIllIllll = llIIIllllIlIlI[Integer.parseInt(lllllllllllllllIllIlIIIIIllIlIII)].split(llIIIllllIllll[llIIIlllllIIIl[0]]);
      Class<?> lllllllllllllllIllIlIIIIIllIlllI = Class.forName(lllllllllllllllIllIlIIIIIllIllll[llIIIlllllIIIl[0]]);
      String lllllllllllllllIllIlIIIIIllIllIl = lllllllllllllllIllIlIIIIIllIllll[llIIIlllllIIIl[2]];
      MethodHandle lllllllllllllllIllIlIIIIIllIllII = null;
      int lllllllllllllllIllIlIIIIIllIlIll = lllllllllllllllIllIlIIIIIllIllll[llIIIlllllIIIl[3]].length();
      if (lIIIIlIllIlIlIll(lllllllllllllllIllIlIIIIIllIlIll, llIIIlllllIIIl[4])) {
        MethodType lllllllllllllllIllIlIIIIIlllIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlIIIIIllIllll[llIIIlllllIIIl[4]], MouseDescription.class.getClassLoader());
        if (lIIIIlIllIlIllII(lllllllllllllllIllIlIIIIIllIlIll, llIIIlllllIIIl[4])) {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findVirtual(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIIl);
          "".length();
          if (-" ".length() == (((0x75 ^ 0x7E) << "   ".length() ^ 0x59 ^ 0x16) << " ".length() << " ".length() & ((173 + 38 - 77 + 49 ^ (0x3 ^ 0x6) << (0x63 ^ 0x66)) << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findStatic(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIIl);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() > " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlIIIIIlllIIII = llIIIllllIlIll[Integer.parseInt(lllllllllllllllIllIlIIIIIllIllll[llIIIlllllIIIl[4]])];
        if (lIIIIlIllIlIllII(lllllllllllllllIllIlIIIIIllIlIll, llIIIlllllIIIl[3])) {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findGetter(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIII);
          "".length();
          if (" ".length() << " ".length() << " ".length() < 0)
            return null; 
        } else if (lIIIIlIllIlIllII(lllllllllllllllIllIlIIIIIllIlIll, llIIIlllllIIIl[5])) {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findStaticGetter(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIII);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIIlIllIlIllII(lllllllllllllllIllIlIIIIIllIlIll, llIIIlllllIIIl[6])) {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findSetter(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIII);
          "".length();
          if (-" ".length() >= "   ".length())
            return null; 
        } else {
          lllllllllllllllIllIlIIIIIllIllII = lllllllllllllllIllIlIIIIIllIlIIl.findStaticSetter(lllllllllllllllIllIlIIIIIllIlllI, lllllllllllllllIllIlIIIIIllIllIl, lllllllllllllllIllIlIIIIIlllIIII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlIIIIIllIllII);
    } catch (Exception lllllllllllllllIllIlIIIIIllIlIlI) {
      lllllllllllllllIllIlIIIIIllIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllIlIIIll() {
    llIIIllllIlIlI = new String[llIIIlllllIIIl[7]];
    llIIIllllIlIlI[llIIIlllllIIIl[3]] = llIIIllllIllll[llIIIlllllIIIl[2]];
    llIIIllllIlIlI[llIIIlllllIIIl[8]] = llIIIllllIllll[llIIIlllllIIIl[4]];
    llIIIllllIlIlI[llIIIlllllIIIl[9]] = llIIIllllIllll[llIIIlllllIIIl[3]];
    llIIIllllIlIlI[llIIIlllllIIIl[10]] = llIIIllllIllll[llIIIlllllIIIl[5]];
    llIIIllllIlIlI[llIIIlllllIIIl[2]] = llIIIllllIllll[llIIIlllllIIIl[6]];
    llIIIllllIlIlI[llIIIlllllIIIl[11]] = llIIIllllIllll[llIIIlllllIIIl[10]];
    llIIIllllIlIlI[llIIIlllllIIIl[5]] = llIIIllllIllll[llIIIlllllIIIl[8]];
    llIIIllllIlIlI[llIIIlllllIIIl[12]] = llIIIllllIllll[llIIIlllllIIIl[13]];
    llIIIllllIlIlI[llIIIlllllIIIl[13]] = llIIIllllIllll[llIIIlllllIIIl[14]];
    llIIIllllIlIlI[llIIIlllllIIIl[4]] = llIIIllllIllll[llIIIlllllIIIl[9]];
    llIIIllllIlIlI[llIIIlllllIIIl[6]] = llIIIllllIllll[llIIIlllllIIIl[12]];
    llIIIllllIlIlI[llIIIlllllIIIl[14]] = llIIIllllIllll[llIIIlllllIIIl[11]];
    llIIIllllIlIlI[llIIIlllllIIIl[0]] = llIIIllllIllll[llIIIlllllIIIl[7]];
    llIIIllllIlIll = new Class[llIIIlllllIIIl[4]];
    llIIIllllIlIll[llIIIlllllIIIl[2]] = int.class;
    llIIIllllIlIll[llIIIlllllIIIl[0]] = Point.class;
  }
  
  private static void lIIIIlIllIlIIlll() {
    llIIIllllIllll = new String[llIIIlllllIIIl[15]];
    llIIIllllIllll[llIIIlllllIIIl[0]] = lIIIIlIllIlIIlII(llIIIlllllIIII[llIIIlllllIIIl[0]], llIIIlllllIIII[llIIIlllllIIIl[2]]);
    llIIIllllIllll[llIIIlllllIIIl[2]] = lIIIIlIllIlIIlIl(llIIIlllllIIII[llIIIlllllIIIl[4]], llIIIlllllIIII[llIIIlllllIIIl[3]]);
    llIIIllllIllll[llIIIlllllIIIl[4]] = lIIIIlIllIlIIlII(llIIIlllllIIII[llIIIlllllIIIl[5]], llIIIlllllIIII[llIIIlllllIIIl[6]]);
    llIIIllllIllll[llIIIlllllIIIl[3]] = lIIIIlIllIlIIlII(llIIIlllllIIII[llIIIlllllIIIl[10]], llIIIlllllIIII[llIIIlllllIIIl[8]]);
    llIIIllllIllll[llIIIlllllIIIl[5]] = lIIIIlIllIlIIllI(llIIIlllllIIII[llIIIlllllIIIl[13]], llIIIlllllIIII[llIIIlllllIIIl[14]]);
    llIIIllllIllll[llIIIlllllIIIl[6]] = lIIIIlIllIlIIlII(llIIIlllllIIII[llIIIlllllIIIl[9]], llIIIlllllIIII[llIIIlllllIIIl[12]]);
    llIIIllllIllll[llIIIlllllIIIl[10]] = lIIIIlIllIlIIlIl("dkpcEBQ67dttYY8QrRnwqUbNmr1T/J7468r64pe9kwS6lwVr4l798x93EzcblNmCbJhM5jHnLiD9FWzgdBBTOuhw/i85FYSzfPGvgQjAY+qJ2TxbR6KM9Kd8fc39zMFeqsF4pKfnvaI=", "xeLtb");
    llIIIllllIllll[llIIIlllllIIIl[8]] = lIIIIlIllIlIIllI("XJc0WWv1fV4igvJC5vwgI/KXz5z9vqIZ8bNtozE3+Vub4WOBXLMEaCo2qFlZG44cEnwPUsJXPGJKmmCwVFb6Xg==", "KyHpV");
    llIIIllllIllll[llIIIlllllIIIl[13]] = lIIIIlIllIlIIllI("E6ycGguD48qtftl/ZQFzT8OhimknuXAur4XC8Rq2Pr592NA1Z4s28+KZO9fg9sbMq5su9iOh+tmLGpWP6DHh2LDpimFe4oO65+NKubLrnJiw6YphXuKDuufjSrmy65yYsOmKYV7ig7rn40q5suucmLDpimFe4oO65+NKubLrnJg6LddxWTX29w==", "wCOLZ");
    llIIIllllIllll[llIIIlllllIIIl[14]] = lIIIIlIllIlIIlIl("6YFakmWQVUGcvuz2cK7pGHTBHzyz0m5hBd61vWIq09WsFNuuz2sK5XR3F1AdOb0YGC7sc1wShFyfK6JBpBt34MmHcI7KjBCA", "kcMYD");
    llIIIllllIllll[llIIIlllllIIIl[9]] = lIIIIlIllIlIIlIl("6LEuwKv14fJIvaLr644UpvKD/TdcwfH52a+qHdCQSrZ93iUFhhkMDlvn5G5QEC+My0XNAvJ3ZTzECH/ODZo63a6KAXAQrj0ANsY54A+fyTt687OBGm6tuA==", "yVBub");
    llIIIllllIllll[llIIIlllllIIIl[12]] = lIIIIlIllIlIIllI("1EDlQze5eQGn9MsqVK3df4Ju9hRwgmA1", "xnQVL");
    llIIIllllIllll[llIIIlllllIIIl[11]] = lIIIIlIllIlIIlII("CSIXaCIfJhwqOw1jCicgDyEJMjsOJBVoBwQ5HzQoCy4ffCkPOTwpIB4FHy8pAjlAbmcjd1pm", "jMzFN");
    llIIIllllIllll[llIIIlllllIIIl[7]] = lIIIIlIllIlIIlII("CT8uSy4fOyUJNw1+MwQsDzwwETcOOSxLNgI1LgBsJz82FicuNTAGMAMgNwwtBGosAyQZNTdfclBwY0ViSg==", "jPCeB");
    llIIIlllllIIII = null;
  }
  
  private static void lIIIIlIllIlIlIII() {
    String str = (new Exception()).getStackTrace()[llIIIlllllIIIl[0]].getFileName();
    llIIIlllllIIII = str.substring(str.indexOf("ä") + llIIIlllllIIIl[2], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIlIllIlIIlIl(String lllllllllllllllIllIlIIIIIllIIIll, String lllllllllllllllIllIlIIIIIllIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIIllIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIIllIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIIIllIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIIIllIIlIl.init(llIIIlllllIIIl[4], lllllllllllllllIllIlIIIIIllIIllI);
      return new String(lllllllllllllllIllIlIIIIIllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIIllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIIllIIlII) {
      lllllllllllllllIllIlIIIIIllIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIlIllIlIIlII(String lllllllllllllllIllIlIIIIIllIIIII, String lllllllllllllllIllIlIIIIIlIlllll) {
    lllllllllllllllIllIlIIIIIllIIIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIIllIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIIIIlIllllI = new StringBuilder();
    char[] lllllllllllllllIllIlIIIIIlIlllIl = lllllllllllllllIllIlIIIIIlIlllll.toCharArray();
    int lllllllllllllllIllIlIIIIIlIlllII = llIIIlllllIIIl[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlIIIIIllIIIII.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIlllllIIIl[0];
    while (lIIIIlIllIlIllIl(j, i)) {
      char lllllllllllllllIllIlIIIIIllIIIIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlIIIIIlIlllII++;
      j++;
      "".length();
      if (" ".length() << " ".length() << " ".length() < 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlIIIIIlIllllI);
  }
  
  private static String lIIIIlIllIlIIllI(String lllllllllllllllIllIlIIIIIlIllIII, String lllllllllllllllIllIlIIIIIlIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIllIlIIIIIlIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIIlIlIlll.getBytes(StandardCharsets.UTF_8)), llIIIlllllIIIl[13]), "DES");
      Cipher lllllllllllllllIllIlIIIIIlIllIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIIlIllIlI.init(llIIIlllllIIIl[4], lllllllllllllllIllIlIIIIIlIllIll);
      return new String(lllllllllllllllIllIlIIIIIlIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIIlIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlIIIIIlIllIIl) {
      lllllllllllllllIllIlIIIIIlIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIlIllIlIlIIl() {
    llIIIlllllIIIl = new int[16];
    llIIIlllllIIIl[0] = ((0xCB ^ 0xC2) << " ".length() ^ 0x11 ^ 0x4) & ((0x1F ^ 0xE) << " ".length() ^ 0x47 ^ 0x62 ^ -" ".length());
    llIIIlllllIIIl[1] = 46 + 90 - 111 + 230;
    llIIIlllllIIIl[2] = " ".length();
    llIIIlllllIIIl[3] = "   ".length();
    llIIIlllllIIIl[4] = " ".length() << " ".length();
    llIIIlllllIIIl[5] = " ".length() << " ".length() << " ".length();
    llIIIlllllIIIl[6] = (0x35 ^ 0x32) << "   ".length() ^ 0x88 ^ 0xB5;
    llIIIlllllIIIl[7] = 0xBD ^ 0xB0;
    llIIIlllllIIIl[8] = 129 + 76 - 138 + 64 ^ (0x29 ^ 0x8) << " ".length() << " ".length();
    llIIIlllllIIIl[9] = (0x4 ^ 0x57 ^ (0x81 ^ 0xAA) << " ".length()) << " ".length();
    llIIIlllllIIIl[10] = "   ".length() << " ".length();
    llIIIlllllIIIl[11] = "   ".length() << " ".length() << " ".length();
    llIIIlllllIIIl[12] = 0xA ^ 0x29 ^ (0xC4 ^ 0xC1) << "   ".length();
    llIIIlllllIIIl[13] = " ".length() << "   ".length();
    llIIIlllllIIIl[14] = (0xB ^ 0x12) << " ".length() << " ".length() ^ 0x1C ^ 0x71;
    llIIIlllllIIIl[15] = (0xB5 ^ 0xB2) << " ".length();
  }
  
  private static boolean lIIIIlIllIlIllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIlIllIlIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIlIllIlIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIlIllIlIlIlI(Object paramObject) {
    return (paramObject != null);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\theme\MouseDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */