package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.Context;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class TabGUIContainer implements TabGUIComponent {
  protected String title;
  
  protected TabGUIRenderer renderer;
  
  protected List<TabGUIComponent> components;
  
  protected boolean childOpen;
  
  protected int selected;
  
  protected Animation selectedAnimation;
  
  private static String[] lIllllIIIIllIl;
  
  private static Class[] lIllllIIIIlllI;
  
  private static final String[] lIllllIIIlIIII;
  
  private static String[] lIllllIIIlIIll;
  
  private static final int[] lIllllIIIlIlII;
  
  public TabGUIContainer(String lllllllllllllllIlllIIllIllIlllII, TabGUIRenderer lllllllllllllllIlllIIllIllIllIll, Animation lllllllllllllllIlllIIllIllIllIlI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Z)V
    //   15: aload_0
    //   16: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   19: iconst_0
    //   20: iaload
    //   21: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;I)V
    //   26: aload_0
    //   27: aconst_null
    //   28: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Animation;)V
    //   33: aload_0
    //   34: aload_1
    //   35: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Ljava/lang/String;)V
    //   40: aload_0
    //   41: aload_2
    //   42: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)V
    //   47: aload_0
    //   48: new java/util/ArrayList
    //   51: dup
    //   52: invokespecial <init> : ()V
    //   55: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Ljava/util/List;)V
    //   60: aload_3
    //   61: invokestatic llllllIIlllIIII : (Ljava/lang/Object;)Z
    //   64: ifeq -> 87
    //   67: aload_3
    //   68: aload_0
    //   69: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   74: i2d
    //   75: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   80: aload_0
    //   81: aload_3
    //   82: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Animation;)V
    //   87: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	88	0	lllllllllllllllIlllIIllIllIlllIl	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	88	1	lllllllllllllllIlllIIllIllIlllII	Ljava/lang/String;
    //   0	88	2	lllllllllllllllIlllIIllIllIllIll	Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   0	88	3	lllllllllllllllIlllIIllIllIllIlI	Lcom/lukflug/panelstudio/Animation;
  }
  
  public void addComponent(TabGUIComponent lllllllllllllllIlllIIllIllIllIII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   6: aload_1
    //   7: <illegal opcode> 9 : (Ljava/util/List;Ljava/lang/Object;)Z
    //   12: ldc ''
    //   14: invokevirtual length : ()I
    //   17: pop2
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIlllIIllIllIllIIl	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	19	1	lllllllllllllllIlllIIllIllIllIII	Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;
  }
  
  public String getTitle() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIllIlIlll	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
  }
  
  public void render(Context lllllllllllllllIlllIIllIllIlIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: aload_0
    //   8: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   13: aload_0
    //   14: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   19: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   24: imul
    //   25: istore_2
    //   26: aload_0
    //   27: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   32: invokestatic llllllIIlllIIII : (Ljava/lang/Object;)Z
    //   35: ifeq -> 64
    //   38: aload_0
    //   39: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   44: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/Animation;)D
    //   49: aload_0
    //   50: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   55: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   60: i2d
    //   61: dmul
    //   62: d2i
    //   63: istore_2
    //   64: aload_0
    //   65: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   70: aload_1
    //   71: iload_2
    //   72: aload_0
    //   73: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   78: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   83: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;Lcom/lukflug/panelstudio/Context;II)V
    //   88: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   91: iconst_0
    //   92: iaload
    //   93: istore_3
    //   94: iload_3
    //   95: aload_0
    //   96: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   101: <illegal opcode> 17 : (Ljava/util/List;)I
    //   106: invokestatic llllllIIlllIIIl : (II)Z
    //   109: ifeq -> 190
    //   112: aload_0
    //   113: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   118: iload_3
    //   119: <illegal opcode> 18 : (Ljava/util/List;I)Ljava/lang/Object;
    //   124: checkcast com/lukflug/panelstudio/tabgui/TabGUIComponent
    //   127: astore #4
    //   129: aload_0
    //   130: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   135: aload_1
    //   136: aload #4
    //   138: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;)Ljava/lang/String;
    //   143: iload_3
    //   144: aload_0
    //   145: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   150: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   155: aload #4
    //   157: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;)Z
    //   162: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;IIZ)V
    //   167: iinc #3, 1
    //   170: ldc ''
    //   172: invokevirtual length : ()I
    //   175: pop
    //   176: ldc '   '
    //   178: invokevirtual length : ()I
    //   181: ldc '   '
    //   183: invokevirtual length : ()I
    //   186: if_icmpeq -> 94
    //   189: return
    //   190: aload_0
    //   191: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Z
    //   196: invokestatic llllllIIlllIIlI : (I)Z
    //   199: ifeq -> 234
    //   202: aload_0
    //   203: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   208: aload_0
    //   209: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   214: <illegal opcode> 18 : (Ljava/util/List;I)Ljava/lang/Object;
    //   219: checkcast com/lukflug/panelstudio/tabgui/TabGUIComponent
    //   222: aload_0
    //   223: aload_1
    //   224: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Context;
    //   229: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;Lcom/lukflug/panelstudio/Context;)V
    //   234: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   129	38	4	lllllllllllllllIlllIIllIllIlIllI	Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;
    //   94	96	3	lllllllllllllllIlllIIllIllIlIlIl	I
    //   0	235	0	lllllllllllllllIlllIIllIllIlIlII	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	235	1	lllllllllllllllIlllIIllIllIlIIll	Lcom/lukflug/panelstudio/Context;
    //   26	209	2	lllllllllllllllIlllIIllIllIlIIlI	I
  }
  
  public void handleButton(Context lllllllllllllllIlllIIllIllIlIIII, int lllllllllllllllIlllIIllIllIIllll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIllIllIlIIIl	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	8	1	lllllllllllllllIlllIIllIllIlIIII	Lcom/lukflug/panelstudio/Context;
    //   0	8	2	lllllllllllllllIlllIIllIllIIllll	I
  }
  
  public void handleKey(Context lllllllllllllllIlllIIllIllIIllIl, int lllllllllllllllIlllIIllIllIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: aload_0
    //   8: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   13: iload_2
    //   14: <illegal opcode> 25 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;I)Z
    //   19: invokestatic llllllIIlllIIlI : (I)Z
    //   22: ifeq -> 56
    //   25: aload_0
    //   26: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   29: iconst_0
    //   30: iaload
    //   31: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Z)V
    //   36: ldc ''
    //   38: invokevirtual length : ()I
    //   41: pop
    //   42: ldc '   '
    //   44: invokevirtual length : ()I
    //   47: ldc '   '
    //   49: invokevirtual length : ()I
    //   52: if_icmple -> 502
    //   55: return
    //   56: aload_0
    //   57: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Z
    //   62: invokestatic llllllIIlllIIll : (I)Z
    //   65: ifeq -> 469
    //   68: aload_0
    //   69: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   74: iload_2
    //   75: <illegal opcode> 26 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;I)Z
    //   80: invokestatic llllllIIlllIIlI : (I)Z
    //   83: ifeq -> 184
    //   86: aload_0
    //   87: dup
    //   88: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   93: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   96: iconst_1
    //   97: iaload
    //   98: isub
    //   99: dup_x1
    //   100: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;I)V
    //   105: invokestatic llllllIIlllIlII : (I)Z
    //   108: ifeq -> 134
    //   111: aload_0
    //   112: aload_0
    //   113: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   118: <illegal opcode> 17 : (Ljava/util/List;)I
    //   123: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   126: iconst_1
    //   127: iaload
    //   128: isub
    //   129: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;I)V
    //   134: aload_0
    //   135: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   140: invokestatic llllllIIlllIIII : (Ljava/lang/Object;)Z
    //   143: ifeq -> 502
    //   146: aload_0
    //   147: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   152: aload_0
    //   153: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   158: i2d
    //   159: <illegal opcode> 27 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   164: ldc ''
    //   166: invokevirtual length : ()I
    //   169: pop
    //   170: ldc '   '
    //   172: invokevirtual length : ()I
    //   175: ldc '   '
    //   177: invokevirtual length : ()I
    //   180: if_icmpeq -> 502
    //   183: return
    //   184: aload_0
    //   185: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   190: iload_2
    //   191: <illegal opcode> 28 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;I)Z
    //   196: invokestatic llllllIIlllIIlI : (I)Z
    //   199: ifeq -> 387
    //   202: aload_0
    //   203: dup
    //   204: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   209: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   212: iconst_1
    //   213: iaload
    //   214: iadd
    //   215: dup_x1
    //   216: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;I)V
    //   221: aload_0
    //   222: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   227: <illegal opcode> 17 : (Ljava/util/List;)I
    //   232: invokestatic llllllIIlllIlIl : (II)Z
    //   235: ifeq -> 249
    //   238: aload_0
    //   239: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   242: iconst_0
    //   243: iaload
    //   244: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;I)V
    //   249: aload_0
    //   250: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   255: invokestatic llllllIIlllIIII : (Ljava/lang/Object;)Z
    //   258: ifeq -> 502
    //   261: aload_0
    //   262: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/Animation;
    //   267: aload_0
    //   268: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   273: i2d
    //   274: <illegal opcode> 27 : (Lcom/lukflug/panelstudio/Animation;D)V
    //   279: ldc ''
    //   281: invokevirtual length : ()I
    //   284: pop
    //   285: ldc ' '
    //   287: invokevirtual length : ()I
    //   290: ldc ' '
    //   292: invokevirtual length : ()I
    //   295: ldc ' '
    //   297: invokevirtual length : ()I
    //   300: ishl
    //   301: ishl
    //   302: bipush #34
    //   304: bipush #53
    //   306: ixor
    //   307: ldc ' '
    //   309: invokevirtual length : ()I
    //   312: ishl
    //   313: sipush #180
    //   316: sipush #159
    //   319: ixor
    //   320: ixor
    //   321: ldc ' '
    //   323: invokevirtual length : ()I
    //   326: ldc ' '
    //   328: invokevirtual length : ()I
    //   331: ldc ' '
    //   333: invokevirtual length : ()I
    //   336: ishl
    //   337: ishl
    //   338: ishl
    //   339: bipush #26
    //   341: iconst_5
    //   342: ixor
    //   343: sipush #174
    //   346: sipush #163
    //   349: ixor
    //   350: ldc ' '
    //   352: invokevirtual length : ()I
    //   355: ishl
    //   356: ixor
    //   357: ldc ' '
    //   359: invokevirtual length : ()I
    //   362: ldc ' '
    //   364: invokevirtual length : ()I
    //   367: ldc ' '
    //   369: invokevirtual length : ()I
    //   372: ishl
    //   373: ishl
    //   374: ishl
    //   375: ldc ' '
    //   377: invokevirtual length : ()I
    //   380: ineg
    //   381: ixor
    //   382: iand
    //   383: if_icmpne -> 502
    //   386: return
    //   387: aload_0
    //   388: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   393: iload_2
    //   394: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;I)Z
    //   399: invokestatic llllllIIlllIIlI : (I)Z
    //   402: ifeq -> 502
    //   405: aload_0
    //   406: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   411: aload_0
    //   412: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   417: <illegal opcode> 18 : (Ljava/util/List;I)Ljava/lang/Object;
    //   422: checkcast com/lukflug/panelstudio/tabgui/TabGUIComponent
    //   425: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;)Z
    //   430: invokestatic llllllIIlllIIlI : (I)Z
    //   433: ifeq -> 502
    //   436: aload_0
    //   437: getstatic com/lukflug/panelstudio/tabgui/TabGUIContainer.lIllllIIIlIlII : [I
    //   440: iconst_1
    //   441: iaload
    //   442: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Z)V
    //   447: ldc ''
    //   449: invokevirtual length : ()I
    //   452: pop
    //   453: ldc ' '
    //   455: invokevirtual length : ()I
    //   458: ineg
    //   459: ldc ' '
    //   461: invokevirtual length : ()I
    //   464: ineg
    //   465: if_icmpge -> 502
    //   468: return
    //   469: aload_0
    //   470: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   475: aload_0
    //   476: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   481: <illegal opcode> 18 : (Ljava/util/List;I)Ljava/lang/Object;
    //   486: checkcast com/lukflug/panelstudio/tabgui/TabGUIComponent
    //   489: aload_0
    //   490: aload_1
    //   491: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Context;
    //   496: iload_2
    //   497: <illegal opcode> 31 : (Lcom/lukflug/panelstudio/tabgui/TabGUIComponent;Lcom/lukflug/panelstudio/Context;I)V
    //   502: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	503	0	lllllllllllllllIlllIIllIllIIlllI	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	503	1	lllllllllllllllIlllIIllIllIIllIl	Lcom/lukflug/panelstudio/Context;
    //   0	503	2	lllllllllllllllIlllIIllIllIIllII	I
  }
  
  public void handleScroll(Context lllllllllllllllIlllIIllIllIIlIlI, int lllllllllllllllIlllIIllIllIIlIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIllIllIIlIll	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	8	1	lllllllllllllllIlllIIllIllIIlIlI	Lcom/lukflug/panelstudio/Context;
    //   0	8	2	lllllllllllllllIlllIIllIllIIlIIl	I
  }
  
  public void getHeight(Context lllllllllllllllIlllIIllIllIIIlll) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   7: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   12: aload_0
    //   13: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Ljava/util/List;
    //   18: <illegal opcode> 17 : (Ljava/util/List;)I
    //   23: imul
    //   24: <illegal opcode> 32 : (Lcom/lukflug/panelstudio/Context;I)V
    //   29: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	30	0	lllllllllllllllIlllIIllIllIIlIII	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	30	1	lllllllllllllllIlllIIllIllIIIlll	Lcom/lukflug/panelstudio/Context;
  }
  
  public void enter(Context lllllllllllllllIlllIIllIllIIIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIllIllIIIllI	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	8	1	lllllllllllllllIlllIIllIllIIIlIl	Lcom/lukflug/panelstudio/Context;
  }
  
  public void exit(Context lllllllllllllllIlllIIllIllIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIllIllIIIlII	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	8	1	lllllllllllllllIlllIIllIllIIIIll	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean isActive() {
    return lIllllIIIlIlII[0];
  }
  
  public boolean select() {
    return lIllllIIIlIlII[1];
  }
  
  protected Context getSubContext(Context lllllllllllllllIlllIIllIlIllllll) {
    // Byte code:
    //   0: aload_1
    //   1: <illegal opcode> 33 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   6: astore_2
    //   7: aload_2
    //   8: aload_1
    //   9: <illegal opcode> 34 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   14: <illegal opcode> 35 : (Ljava/awt/Dimension;)I
    //   19: aload_0
    //   20: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   25: <illegal opcode> 36 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   30: iadd
    //   31: aload_0
    //   32: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)I
    //   37: aload_0
    //   38: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;)Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   43: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;)I
    //   48: imul
    //   49: <illegal opcode> 37 : (Ljava/awt/Point;II)V
    //   54: new com/lukflug/panelstudio/Context
    //   57: dup
    //   58: aload_1
    //   59: <illegal opcode> 38 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   64: aload_1
    //   65: <illegal opcode> 34 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   70: <illegal opcode> 35 : (Ljava/awt/Dimension;)I
    //   75: aload_2
    //   76: aload_1
    //   77: <illegal opcode> 39 : (Lcom/lukflug/panelstudio/Context;)Z
    //   82: aload_1
    //   83: <illegal opcode> 40 : (Lcom/lukflug/panelstudio/Context;)Z
    //   88: invokespecial <init> : (Lcom/lukflug/panelstudio/Interface;ILjava/awt/Point;ZZ)V
    //   91: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	92	0	lllllllllllllllIlllIIllIllIIIIII	Lcom/lukflug/panelstudio/tabgui/TabGUIContainer;
    //   0	92	1	lllllllllllllllIlllIIllIlIllllll	Lcom/lukflug/panelstudio/Context;
    //   7	85	2	lllllllllllllllIlllIIllIlIlllllI	Ljava/awt/Point;
  }
  
  public void releaseFocus() {}
  
  static {
    llllllIIllIllll();
    llllllIIllIlllI();
    llllllIIllIllIl();
    llllllIIlIlllIl();
  }
  
  private static CallSite llllllIIlIIlIIl(MethodHandles.Lookup lllllllllllllllIlllIIllIlIllIlII, String lllllllllllllllIlllIIllIlIllIIll, MethodType lllllllllllllllIlllIIllIlIllIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIllIlIlllIlI = lIllllIIIIllIl[Integer.parseInt(lllllllllllllllIlllIIllIlIllIIll)].split(lIllllIIIlIIII[lIllllIIIlIlII[0]]);
      Class<?> lllllllllllllllIlllIIllIlIlllIIl = Class.forName(lllllllllllllllIlllIIllIlIlllIlI[lIllllIIIlIlII[0]]);
      String lllllllllllllllIlllIIllIlIlllIII = lllllllllllllllIlllIIllIlIlllIlI[lIllllIIIlIlII[1]];
      MethodHandle lllllllllllllllIlllIIllIlIllIlll = null;
      int lllllllllllllllIlllIIllIlIllIllI = lllllllllllllllIlllIIllIlIlllIlI[lIllllIIIlIlII[2]].length();
      if (llllllIIlllIllI(lllllllllllllllIlllIIllIlIllIllI, lIllllIIIlIlII[3])) {
        MethodType lllllllllllllllIlllIIllIlIllllII = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIllIlIlllIlI[lIllllIIIlIlII[3]], TabGUIContainer.class.getClassLoader());
        if (llllllIIlllIlll(lllllllllllllllIlllIIllIlIllIllI, lIllllIIIlIlII[3])) {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findVirtual(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIllllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findStatic(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIllllII);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIllIlIlllIll = lIllllIIIIlllI[Integer.parseInt(lllllllllllllllIlllIIllIlIlllIlI[lIllllIIIlIlII[3]])];
        if (llllllIIlllIlll(lllllllllllllllIlllIIllIlIllIllI, lIllllIIIlIlII[2])) {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findGetter(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIlllIll);
          "".length();
          if (" ".length() <= 0)
            return null; 
        } else if (llllllIIlllIlll(lllllllllllllllIlllIIllIlIllIllI, lIllllIIIlIlII[4])) {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findStaticGetter(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIlllIll);
          "".length();
          if (" ".length() << " ".length() < -" ".length())
            return null; 
        } else if (llllllIIlllIlll(lllllllllllllllIlllIIllIlIllIllI, lIllllIIIlIlII[5])) {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findSetter(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIlllIll);
          "".length();
          if (((0x8D ^ 0xA0 ^ "   ".length() << " ".length() << " ".length()) & (0x5D ^ 0x1A ^ (0x10 ^ 0x23) << " ".length() ^ -" ".length())) > 0)
            return null; 
        } else {
          lllllllllllllllIlllIIllIlIllIlll = lllllllllllllllIlllIIllIlIllIlII.findStaticSetter(lllllllllllllllIlllIIllIlIlllIIl, lllllllllllllllIlllIIllIlIlllIII, lllllllllllllllIlllIIllIlIlllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIllIlIllIlll);
    } catch (Exception lllllllllllllllIlllIIllIlIllIlIl) {
      lllllllllllllllIlllIIllIlIllIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIlIlllIl() {
    lIllllIIIIllIl = new String[lIllllIIIlIlII[6]];
    lIllllIIIIllIl[lIllllIIIlIlII[7]] = lIllllIIIlIIII[lIllllIIIlIlII[1]];
    lIllllIIIIllIl[lIllllIIIlIlII[8]] = lIllllIIIlIIII[lIllllIIIlIlII[3]];
    lIllllIIIIllIl[lIllllIIIlIlII[9]] = lIllllIIIlIIII[lIllllIIIlIlII[2]];
    lIllllIIIIllIl[lIllllIIIlIlII[10]] = lIllllIIIlIIII[lIllllIIIlIlII[4]];
    lIllllIIIIllIl[lIllllIIIlIlII[11]] = lIllllIIIlIIII[lIllllIIIlIlII[5]];
    lIllllIIIIllIl[lIllllIIIlIlII[12]] = lIllllIIIlIIII[lIllllIIIlIlII[13]];
    lIllllIIIIllIl[lIllllIIIlIlII[14]] = lIllllIIIlIIII[lIllllIIIlIlII[15]];
    lIllllIIIIllIl[lIllllIIIlIlII[16]] = lIllllIIIlIIII[lIllllIIIlIlII[17]];
    lIllllIIIIllIl[lIllllIIIlIlII[18]] = lIllllIIIlIIII[lIllllIIIlIlII[16]];
    lIllllIIIIllIl[lIllllIIIlIlII[19]] = lIllllIIIlIIII[lIllllIIIlIlII[20]];
    lIllllIIIIllIl[lIllllIIIlIlII[3]] = lIllllIIIlIIII[lIllllIIIlIlII[21]];
    lIllllIIIIllIl[lIllllIIIlIlII[15]] = lIllllIIIlIIII[lIllllIIIlIlII[22]];
    lIllllIIIIllIl[lIllllIIIlIlII[23]] = lIllllIIIlIIII[lIllllIIIlIlII[24]];
    lIllllIIIIllIl[lIllllIIIlIlII[21]] = lIllllIIIlIIII[lIllllIIIlIlII[7]];
    lIllllIIIIllIl[lIllllIIIlIlII[25]] = lIllllIIIlIIII[lIllllIIIlIlII[18]];
    lIllllIIIIllIl[lIllllIIIlIlII[26]] = lIllllIIIlIIII[lIllllIIIlIlII[27]];
    lIllllIIIIllIl[lIllllIIIlIlII[28]] = lIllllIIIlIIII[lIllllIIIlIlII[29]];
    lIllllIIIIllIl[lIllllIIIlIlII[22]] = lIllllIIIlIIII[lIllllIIIlIlII[30]];
    lIllllIIIIllIl[lIllllIIIlIlII[27]] = lIllllIIIlIIII[lIllllIIIlIlII[14]];
    lIllllIIIIllIl[lIllllIIIlIlII[31]] = lIllllIIIlIIII[lIllllIIIlIlII[32]];
    lIllllIIIIllIl[lIllllIIIlIlII[17]] = lIllllIIIlIIII[lIllllIIIlIlII[26]];
    lIllllIIIIllIl[lIllllIIIlIlII[0]] = lIllllIIIlIIII[lIllllIIIlIlII[8]];
    lIllllIIIIllIl[lIllllIIIlIlII[33]] = lIllllIIIlIIII[lIllllIIIlIlII[23]];
    lIllllIIIIllIl[lIllllIIIlIlII[1]] = lIllllIIIlIIII[lIllllIIIlIlII[28]];
    lIllllIIIIllIl[lIllllIIIlIlII[32]] = lIllllIIIlIIII[lIllllIIIlIlII[34]];
    lIllllIIIIllIl[lIllllIIIlIlII[35]] = lIllllIIIlIIII[lIllllIIIlIlII[36]];
    lIllllIIIIllIl[lIllllIIIlIlII[37]] = lIllllIIIlIIII[lIllllIIIlIlII[31]];
    lIllllIIIIllIl[lIllllIIIlIlII[38]] = lIllllIIIlIIII[lIllllIIIlIlII[39]];
    lIllllIIIIllIl[lIllllIIIlIlII[30]] = lIllllIIIlIIII[lIllllIIIlIlII[10]];
    lIllllIIIIllIl[lIllllIIIlIlII[5]] = lIllllIIIlIIII[lIllllIIIlIlII[12]];
    lIllllIIIIllIl[lIllllIIIlIlII[39]] = lIllllIIIlIIII[lIllllIIIlIlII[19]];
    lIllllIIIIllIl[lIllllIIIlIlII[24]] = lIllllIIIlIIII[lIllllIIIlIlII[11]];
    lIllllIIIIllIl[lIllllIIIlIlII[4]] = lIllllIIIlIIII[lIllllIIIlIlII[9]];
    lIllllIIIIllIl[lIllllIIIlIlII[13]] = lIllllIIIlIIII[lIllllIIIlIlII[38]];
    lIllllIIIIllIl[lIllllIIIlIlII[29]] = lIllllIIIlIIII[lIllllIIIlIlII[35]];
    lIllllIIIIllIl[lIllllIIIlIlII[20]] = lIllllIIIlIIII[lIllllIIIlIlII[25]];
    lIllllIIIIllIl[lIllllIIIlIlII[34]] = lIllllIIIlIIII[lIllllIIIlIlII[37]];
    lIllllIIIIllIl[lIllllIIIlIlII[36]] = lIllllIIIlIIII[lIllllIIIlIlII[40]];
    lIllllIIIIllIl[lIllllIIIlIlII[40]] = lIllllIIIlIIII[lIllllIIIlIlII[41]];
    lIllllIIIIllIl[lIllllIIIlIlII[2]] = lIllllIIIlIIII[lIllllIIIlIlII[33]];
    lIllllIIIIllIl[lIllllIIIlIlII[41]] = lIllllIIIlIIII[lIllllIIIlIlII[6]];
    lIllllIIIIlllI = new Class[lIllllIIIlIlII[13]];
    lIllllIIIIlllI[lIllllIIIlIlII[2]] = String.class;
    lIllllIIIIlllI[lIllllIIIlIlII[0]] = boolean.class;
    lIllllIIIIlllI[lIllllIIIlIlII[3]] = Animation.class;
    lIllllIIIIlllI[lIllllIIIlIlII[1]] = int.class;
    lIllllIIIIlllI[lIllllIIIlIlII[5]] = List.class;
    lIllllIIIIlllI[lIllllIIIlIlII[4]] = TabGUIRenderer.class;
  }
  
  private static void llllllIIllIllIl() {
    lIllllIIIlIIII = new String[lIllllIIIlIlII[42]];
    lIllllIIIlIIII[lIllllIIIlIlII[0]] = llllllIIlIllllI(lIllllIIIlIIll[lIllllIIIlIlII[0]], lIllllIIIlIIll[lIllllIIIlIlII[1]]);
    lIllllIIIlIIII[lIllllIIIlIlII[1]] = llllllIIlIlllll(lIllllIIIlIIll[lIllllIIIlIlII[3]], lIllllIIIlIIll[lIllllIIIlIlII[2]]);
    lIllllIIIlIIII[lIllllIIIlIlII[3]] = llllllIIllIIIII(lIllllIIIlIIll[lIllllIIIlIlII[4]], lIllllIIIlIIll[lIllllIIIlIlII[5]]);
    lIllllIIIlIIII[lIllllIIIlIlII[2]] = llllllIIlIllllI(lIllllIIIlIIll[lIllllIIIlIlII[13]], lIllllIIIlIIll[lIllllIIIlIlII[15]]);
    lIllllIIIlIIII[lIllllIIIlIlII[4]] = llllllIIlIlllll(lIllllIIIlIIll[lIllllIIIlIlII[17]], lIllllIIIlIIll[lIllllIIIlIlII[16]]);
    lIllllIIIlIIII[lIllllIIIlIlII[5]] = llllllIIllIIIII(lIllllIIIlIIll[lIllllIIIlIlII[20]], lIllllIIIlIIll[lIllllIIIlIlII[21]]);
    lIllllIIIlIIII[lIllllIIIlIlII[13]] = llllllIIlIlllll("vb2LK7C7YcBK2F3QrNVYUrOuHUT2E8TxYaz/HBMuK3/DiknBrLcpCkv9wGITZqvbZznjorDajUg3zC1fPS7fcg==", "WLhsa");
    lIllllIIIlIIII[lIllllIIIlIlII[15]] = llllllIIllIIIII("ooU08vQbBgDIDKNvlS/SVC3lQt77tgwMX0TKs0tvCwT45TmWvS9T6QxtY9A/DC1gt8B8Z9hiDYxGapsrUudJu5WNUvi+PWOyCYXXUOdAcNc=", "kpXUb");
    lIllllIIIlIIII[lIllllIIIlIlII[17]] = llllllIIlIllllI("KwoSLEw0Hw0hTA0CFzlYIA8Ad0oNAQU7A24HBSMFbiQGJwciH19kOHtLRA==", "AkdMb");
    lIllllIIIlIIII[lIllllIIIlIlII[16]] = llllllIIlIlllll("iSzdVCiBMni2ySrZbVVOTuesgpaxBusQCNRp08sDXTX7snBCPeXi6Pb9nwWSuqRAH1zMx2qr/iY=", "dyBRn");
    lIllllIIIlIIII[lIllllIIIlIlII[20]] = llllllIIlIllllI("CC0VbCceKR4uPgxsCCMlDi4LNj4PKxdsPwogHzciRRYZIAw+CzstJhstFiclH3gQIyUPLh0JLhJ4UA4oBC9XLj4AJBQ3LEQyGSwuBzEMNy8CLVcBJAU2HTo/UAtRFHFLYg==", "kBxBK");
    lIllllIIIlIIII[lIllllIIIlIlII[21]] = llllllIIlIllllI("Gw4YeCYNChM6Px9PBTckHQ0GIj8cCBp4PhkDEiMjVjUUNA0tKDY5JAwAHDgvClsGMyYdAgEzLjkPHDsrDAgaOHBKW1V2alhB", "xauVJ");
    lIllllIIIlIIII[lIllllIIIlIlII[22]] = llllllIIllIIIII("Ggveo8vM3eriwWzDi9TGe0TTiwOYtIQC5JRmm2Pw8enVDPKzcAE0STuZpx1gifN0vjcW+cFEgMU=", "vHSZZ");
    lIllllIIIlIIII[lIllllIIIlIlII[24]] = llllllIIlIlllll("sqS2GxIswTnFi18vvDZpEst5saiaml3WC0EQ+/lzaeyE78Uy4J7IfjWsHCKMlPtgpYxT0lP7kWAnnT4HZkDboW910kPmYH1pqtF9E469OXt7WdfSx6PRTGoaI7rb8ep2YENNwQ88Ne9qJCyQ7dJK4dhCFSEAHSiDTThPRafb2Lq7A4upqUaXyg==", "yzycP");
    lIllllIIIlIIII[lIllllIIIlIlII[7]] = llllllIIlIlllll("7lxqnmkN8LDkyyemTyM+5By7EI1J8h3ZTJiIO7483Es+TkjtU/o32eHD8qB/KNnIuZfV1Q2qdnk3/xIHQJVrOl9JEymZ0ysqYabQNDvNguXq7qHNlCjol8yjtzqCSgwX6Eno8yWFuMQ=", "UBZGl");
    lIllllIIIlIIII[lIllllIIIlIlII[18]] = llllllIIllIIIII("SO8/ddzYFdmeUetjWRT2pcsGjR4Hr4qPApu+YvUMHtNJ3xKGQ1PrYT49aAR6UVEm0cY9o5bUL4jrT1cfURBcdA==", "HTqun");
    lIllllIIIlIIII[lIllllIIIlIlII[27]] = llllllIIlIllllI("JD0sdyYyOSc1PyB8MTgkIj4yLT8jOy53PiYwJiwjaQYgOw0SGxM8JCM3Mzw4fSAkNy4iIAI4OjM7Ljdwbx4iNidoPjQyLCsnJnY6JjwkNTkzJyUwJWgRLjc+Iio1YgYtMzc4ZSszLz5lFCYzMCQgaQgQEG4Ee3lq", "GRAYJ");
    lIllllIIIlIIII[lIllllIIIlIlII[29]] = llllllIIllIIIII("9l9uU+ht/gp2qqMrKpLO5qZ+kmEbAjendnh26J6fE2ipYlBebYNAc3WoEL/08/VlrnB1lIr98nEcdiaCHPBPc2ueKiGFVwhWO4rrVH1/K78m6QsAyXhU0lodD5taNrgl", "Maqcz");
    lIllllIIIlIIII[lIllllIIIlIlII[30]] = llllllIIlIlllll("aXq1GwGnOXjo5tzbty8s0VgRPvwEeAb469quT6wPVlMS8cZEPPidEE2FbFp6SJurgiwrCI4lh2vA6o+0+zMCoA==", "DoNaS");
    lIllllIIIlIIII[lIllllIIIlIlII[14]] = llllllIIlIllllI("BAAAQxsSBAsBAgBBHQwZAgMeGQIDBgJDAwYNChgeSTsMDzAyJj8IGQMKHwgFXR0IAxMCHS8MFAwIHwICCQtXRTsEAABCGxIECwECAEAdDBkCAx4ZAgMGAkI0CAEZCA8TVCQkXjFVTU0=", "gommw");
    lIllllIIIlIIII[lIllllIIIlIlII[32]] = llllllIIllIIIII("6ZPLUuCGoVDAvydufyu0hxGeSxDgp9YBRi3ExFzGjSO6UGFT/howWCyj8OrWqh1IwmMKjFtp7YA=", "yvlCm");
    lIllllIIIlIIII[lIllllIIIlIlII[26]] = llllllIIllIIIII("uDRRNse+j36HshwBxq1jo0tKfjCfToedU3uwp+WQMlSGlMdSDnAoTfmZ+H76VaRTv5PPBkr6FI0AtjFkjXi+ew==", "HMjbA");
    lIllllIIIlIIII[lIllllIIIlIlII[8]] = llllllIIllIIIII("RQ2xrB/t8bo5lbH8kBaT4h6naoXmEzshWmNRXGzpcj6HHZILGP4hFuHcjtNEWUxyONs9vxO8ZTcENFR67RAU696a3yo8wobJ", "AgXMH");
    lIllllIIIlIIII[lIllllIIIlIlII[23]] = llllllIIlIlllll("xfCqpwYFob1oPKySXTfdwayPsoZZgZbPA42EFjFPhkO64/Ne60HSrv+xvJxMbFwe", "FeWSX");
    lIllllIIIlIIII[lIllllIIIlIlII[28]] = llllllIIlIllllI("IjolSw80Pi4JFiZ7OAQNJDk7ERYlPCdLFyA3LxAKbwEpByQUHAsKDTU0IQsGM287AA8kNjwAB3tkckVDYXVo", "AUHec");
    lIllllIIIlIIII[lIllllIIIlIlII[34]] = llllllIIllIIIII("evLSMudw5FuNkm/jLj+9ongiiqBWtANpWlS6kH0MO25vGSIP9HzUoS4ONiIBRQgPT95xhpllkdysPLyEB3RBHA==", "sIUwo");
    lIllllIIIlIIII[lIllllIIIlIlII[36]] = llllllIIllIIIII("8PmlSNciRymZxR8q0iMdJ3zmLAgpxld3MoUOIP3o7kM=", "CliHd");
    lIllllIIIlIIII[lIllllIIIlIlII[31]] = llllllIIllIIIII("vP8KR7sVpAo+YPfQZScb15NaGmdQ4s2YwPm/5/qb9qrMd8r40pI4rQ==", "Yyekv");
    lIllllIIIlIIII[lIllllIIIlIlII[39]] = llllllIIllIIIII("PjFWWnbYQoip3JGlNxEqfaGI7EV1vi+yKbjgIh3kEgh4INkETgf+aeceyi8bqNBwssbc3zzbbRCE4uqhwH9PSjg3cB9RI6xZ", "bHSQI");
    lIllllIIIlIIII[lIllllIIIlIlII[10]] = llllllIIllIIIII("PumYXGU138qXtXCGkKyV1Dy3gusTfCOcjUXKuzvKRE0nE7lYFfNd1M4k6/blnXSQ", "dAsfV");
    lIllllIIIlIIII[lIllllIIIlIlII[12]] = llllllIIlIlllll("dvmHLYd2c72k5ZCf1QY3rPLHkFvAUadyPBJ1HCASxEirf2LZ91qmzJV3ct/wFDGHG4SVL/as1fPoPmR/TitqPkqGX2IAmg5B", "CAsGC");
    lIllllIIIlIIII[lIllllIIIlIlII[19]] = llllllIIlIllllI("CgcrTzYcAyANLw5GNgA0DAQ1FS8NASlPLggKIRQzRzwnAx08IRQENA0NNAQoUwE1JTUeBg0EI1NAD0gAU0hm", "ihFaZ");
    lIllllIIIlIIII[lIllllIIIlIlII[11]] = llllllIIlIlllll("Q0WJFeZx7Pr6SBUVDsBy15gojcJLF0r3HWfE+nqBXr8BO7rtkUdAU58+ZAwMLo+yY5zEnnODDzcp1gqy2NsYlA==", "znTet");
    lIllllIIIlIIII[lIllllIIIlIlII[9]] = llllllIIlIlllll("QKW0H4D114aTWuo/QCA+Iwrryd1Fu+mGg59PRD3ONXmMWwDo6JxYmvr/UUm7fT0ZlKOa2YjeX5287Le8jdBYFw==", "PutAb");
    lIllllIIIlIIII[lIllllIIIlIlII[38]] = llllllIIlIllllI("IhwiXBU0GCkeDCZdPxMXJB88BgwlGiBcDSARKAcQbycuED4UOgwdFzUSJhwcM0k8FxUkEDsXHXtCdVJZYQ==", "AsOry");
    lIllllIIIlIIII[lIllllIIIlIlII[35]] = llllllIIlIlllll("fsnlhWLzTHlSqFUcbmmqtWWfpdYN5+CS4meQfuV3tO0=", "TdCSg");
    lIllllIIIlIIII[lIllllIIIlIlII[25]] = llllllIIllIIIII("GzJPxFzhXFFQRmv88+vjiJfIK2aFxZzdy1TdLyDV5PoPL9uC1690smHd8bvKbDKKN/o61ABkWKuFJ2vfwaLG8Q==", "YDxRO");
    lIllllIIIlIIII[lIllllIIIlIlII[37]] = llllllIIlIlllll("Ipk/R9mqJa5D/d/YtZchckMJvYTAunt8uPYo/fyy3WvTnBlCB45WDw2rcGCg5Sk70RRcgifmc1wFOTwoOsQG2DFSDhAbujIj", "IWhLF");
    lIllllIIIlIIII[lIllllIIIlIlII[40]] = llllllIIlIllllI("DzYLSAgZMgAKEQt3FgcKCTUVEhEIMAlIEA07ARMNQg0HBCM5EDQDCgg8FAMWVjAVMxQnPB9cTCVwPFxETA==", "lYffd");
    lIllllIIIlIIII[lIllllIIIlIlII[41]] = llllllIIllIIIII("qTIQS+CetotPqZznoatpdsJ7nWU1CjwJ9CUPIX7IIHmTtpCAWJDyXtay7eNkUX/0dwYz4E9gQAGWkwAvSea7IzX+/SAZ7gNZMeMAs4uUlPOfZ8J/+Csg4Q==", "jCLtk");
    lIllllIIIlIIII[lIllllIIIlIlII[33]] = llllllIIlIlllll("NCqxHhI+zG/0+8ulTK5beIuZld280numK2tHNhwRH6W9xCvEz57XK/UvOWaCb9oaYrUUCEOkYFit4Q7N6mHT1g==", "enJac");
    lIllllIIIlIIII[lIllllIIIlIlII[6]] = llllllIIlIlllll("7eq9tGO45AC6kKw9Ag16PPc7j0KCOAVfEM1pkt00kSBuOVboaHEp4kw6C3FBqbjH", "UxdGn");
    lIllllIIIlIIll = null;
  }
  
  private static void llllllIIllIlllI() {
    String str = (new Exception()).getStackTrace()[lIllllIIIlIlII[0]].getFileName();
    lIllllIIIlIIll = str.substring(str.indexOf("ä") + lIllllIIIlIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIIllIIIII(String lllllllllllllllIlllIIllIlIlIlllI, String lllllllllllllllIlllIIllIlIlIllIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIlIllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIlIlIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIllIlIllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIllIlIllIIII.init(lIllllIIIlIlII[3], lllllllllllllllIlllIIllIlIllIIIl);
      return new String(lllllllllllllllIlllIIllIlIllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIlIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIlIlIllll) {
      lllllllllllllllIlllIIllIlIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIlIlllll(String lllllllllllllllIlllIIllIlIlIlIIl, String lllllllllllllllIlllIIllIlIlIlIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIlIlIllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIlIlIlIII.getBytes(StandardCharsets.UTF_8)), lIllllIIIlIlII[17]), "DES");
      Cipher lllllllllllllllIlllIIllIlIlIlIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIllIlIlIlIll.init(lIllllIIIlIlII[3], lllllllllllllllIlllIIllIlIlIllII);
      return new String(lllllllllllllllIlllIIllIlIlIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIlIlIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIlIlIlIlI) {
      lllllllllllllllIlllIIllIlIlIlIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIlIllllI(String lllllllllllllllIlllIIllIlIlIIllI, String lllllllllllllllIlllIIllIlIlIIlIl) {
    lllllllllllllllIlllIIllIlIlIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllIlIlIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIllIlIlIIlII = new StringBuilder();
    char[] lllllllllllllllIlllIIllIlIlIIIll = lllllllllllllllIlllIIllIlIlIIlIl.toCharArray();
    int lllllllllllllllIlllIIllIlIlIIIlI = lIllllIIIlIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIllIlIlIIllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIIlIlII[0];
    while (llllllIIlllIIIl(j, i)) {
      char lllllllllllllllIlllIIllIlIlIIlll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIllIlIlIIIlI++;
      j++;
      "".length();
      if (-(0xB0 ^ 0xAF ^ 0x56 ^ 0x4D) >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIllIlIlIIlII);
  }
  
  private static void llllllIIllIllll() {
    lIllllIIIlIlII = new int[43];
    lIllllIIIlIlII[0] = (0xC3 ^ 0x94 ^ (0xB7 ^ 0xA4) << " ".length() << " ".length()) << " ".length() & (((0xA ^ 0xF) << "   ".length() ^ 0x4B ^ 0x78) << " ".length() ^ -" ".length());
    lIllllIIIlIlII[1] = " ".length();
    lIllllIIIlIlII[2] = "   ".length();
    lIllllIIIlIlII[3] = " ".length() << " ".length();
    lIllllIIIlIlII[4] = " ".length() << " ".length() << " ".length();
    lIllllIIIlIlII[5] = (0x91 ^ 0x86) << "   ".length() ^ 145 + 18 - 73 + 99;
    lIllllIIIlIlII[6] = (0x70 ^ 0x55) << " ".length() ^ 0x5F ^ 0x3C;
    lIllllIIIlIlII[7] = (0xA5 ^ 0xA2) << " ".length();
    lIllllIIIlIlII[8] = (20 + 158 - 57 + 62 ^ (0x8A ^ 0xA5) << " ".length() << " ".length()) << " ".length();
    lIllllIIIlIlII[9] = 0x62 ^ 0x43;
    lIllllIIIlIlII[10] = 0x17 ^ 0xA;
    lIllllIIIlIlII[11] = " ".length() << (0xBB ^ 0xBE);
    lIllllIIIlIlII[12] = (0x52 ^ 0x5D) << " ".length();
    lIllllIIIlIlII[13] = "   ".length() << " ".length();
    lIllllIIIlIlII[14] = 0x26 ^ 0x19 ^ (0x64 ^ 0x6F) << " ".length() << " ".length();
    lIllllIIIlIlII[15] = (0x27 ^ 0x2C) << "   ".length() ^ 0x43 ^ 0x1C;
    lIllllIIIlIlII[16] = 0x4D ^ 0x44;
    lIllllIIIlIlII[17] = " ".length() << "   ".length();
    lIllllIIIlIlII[18] = (0x64 ^ 0x25) << " ".length() ^ 111 + 43 - 50 + 37;
    lIllllIIIlIlII[19] = 0x4C ^ 0x53;
    lIllllIIIlIlII[20] = (0xB2 ^ 0xB7) << " ".length();
    lIllllIIIlIlII[21] = 0x5B ^ 0x50;
    lIllllIIIlIlII[22] = "   ".length() << " ".length() << " ".length();
    lIllllIIIlIlII[23] = 0x28 ^ 0x3F;
    lIllllIIIlIlII[24] = 116 + 157 - 252 + 144 ^ (0x37 ^ 0x22) << "   ".length();
    lIllllIIIlIlII[25] = (0x56 ^ 0x5F) << " ".length() << " ".length();
    lIllllIIIlIlII[26] = 0x27 ^ 0x32;
    lIllllIIIlIlII[27] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIIlIlII[28] = "   ".length() << "   ".length();
    lIllllIIIlIlII[29] = 0xD4 ^ 0xC5;
    lIllllIIIlIlII[30] = (0x3 ^ 0xA) << " ".length();
    lIllllIIIlIlII[31] = 0x95 ^ 0x8E;
    lIllllIIIlIlII[32] = ((0x16 ^ 0x3F) << " ".length() << " ".length() ^ 12 + 54 - -52 + 43) << " ".length() << " ".length();
    lIllllIIIlIlII[33] = (0x3F ^ 0x3A) << "   ".length();
    lIllllIIIlIlII[34] = 0x12 ^ 0xB;
    lIllllIIIlIlII[35] = 0x72 ^ 0x17 ^ (0x15 ^ 0x36) << " ".length();
    lIllllIIIlIlII[36] = (0x1B ^ 0x16) << " ".length();
    lIllllIIIlIlII[37] = 0xAC ^ 0x89;
    lIllllIIIlIlII[38] = (0x3D ^ 0x2C) << " ".length();
    lIllllIIIlIlII[39] = (0xC2 ^ 0xC5) << " ".length() << " ".length();
    lIllllIIIlIlII[40] = (0x5 ^ 0x16) << " ".length();
    lIllllIIIlIlII[41] = 0x28 ^ 0xF;
    lIllllIIIlIlII[42] = (0x12 ^ 0x7) << " ".length();
  }
  
  private static boolean llllllIIlllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIIlllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 >= paramInt2);
  }
  
  private static boolean llllllIIlllIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIIlllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllIIlllIIII(Object paramObject) {
    return (paramObject != null);
  }
  
  private static boolean llllllIIlllIIlI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean llllllIIlllIIll(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean llllllIIlllIlII(int paramInt) {
    return (paramInt < 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\TabGUIContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */