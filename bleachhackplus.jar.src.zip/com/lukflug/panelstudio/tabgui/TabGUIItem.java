package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.settings.Toggleable;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class TabGUIItem implements TabGUIComponent {
  protected String title;
  
  protected Toggleable toggle;
  
  private static String[] llIIIIIIlIIlll;
  
  private static Class[] llIIIIIIlIlIII;
  
  private static final String[] llIIIIIIlIlIIl;
  
  private static String[] llIIIIIIlIlIlI;
  
  private static final int[] llIIIIIIlIlllI;
  
  public TabGUIItem(String lllllllllllllllIllIlllIlllIIIIII, Toggleable lllllllllllllllIllIlllIllIllllll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUIItem;Ljava/lang/String;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUIItem;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   18: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	19	0	lllllllllllllllIllIlllIlllIIIIIl	Lcom/lukflug/panelstudio/tabgui/TabGUIItem;
    //   0	19	1	lllllllllllllllIllIlllIlllIIIIII	Ljava/lang/String;
    //   0	19	2	lllllllllllllllIllIlllIllIllllll	Lcom/lukflug/panelstudio/settings/Toggleable;
  }
  
  public String getTitle() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/TabGUIItem;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIlllIllIlllllI	Lcom/lukflug/panelstudio/tabgui/TabGUIItem;
  }
  
  public void render(Context lllllllllllllllIllIlllIllIllllII) {}
  
  public void handleButton(Context lllllllllllllllIllIlllIllIlllIII, int lllllllllllllllIllIlllIllIllIlIl) {}
  
  public void handleKey(Context lllllllllllllllIllIlllIllIllIIlI, int lllllllllllllllIllIlllIllIllIIII) {}
  
  public void handleScroll(Context lllllllllllllllIllIlllIllIlIlIll, int lllllllllllllllIllIlllIllIlIlIlI) {}
  
  public void getHeight(Context lllllllllllllllIllIlllIllIlIlIII) {}
  
  public void enter(Context lllllllllllllllIllIlllIllIlIIllI) {}
  
  public void exit(Context lllllllllllllllIllIlllIllIlIIlII) {}
  
  public boolean isActive() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/tabgui/TabGUIItem;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   11: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIllIlllIllIlIIIll	Lcom/lukflug/panelstudio/tabgui/TabGUIItem;
  }
  
  public boolean select() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/tabgui/TabGUIItem;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   11: getstatic com/lukflug/panelstudio/tabgui/TabGUIItem.llIIIIIIlIlllI : [I
    //   14: iconst_0
    //   15: iaload
    //   16: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	17	0	lllllllllllllllIllIlllIllIlIIIlI	Lcom/lukflug/panelstudio/tabgui/TabGUIItem;
  }
  
  public void releaseFocus() {}
  
  static {
    lIIIIIIlIlIlIIll();
    lIIIIIIlIIlllIlI();
    lIIIIIIlIIlllIIl();
    lIIIIIIlIIllIlIl();
  }
  
  private static CallSite lIIIIIIlIIllIlII(MethodHandles.Lookup lllllllllllllllIllIlllIllIIlIIIl, String lllllllllllllllIllIlllIllIIlIIII, MethodType lllllllllllllllIllIlllIllIIIllll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIlllIllIIlIlll = llIIIIIIlIIlll[Integer.parseInt(lllllllllllllllIllIlllIllIIlIIII)].split(llIIIIIIlIlIIl[llIIIIIIlIlllI[0]]);
      Class<?> lllllllllllllllIllIlllIllIIlIllI = Class.forName(lllllllllllllllIllIlllIllIIlIlll[llIIIIIIlIlllI[0]]);
      String lllllllllllllllIllIlllIllIIlIlIl = lllllllllllllllIllIlllIllIIlIlll[llIIIIIIlIlllI[1]];
      MethodHandle lllllllllllllllIllIlllIllIIlIlII = null;
      int lllllllllllllllIllIlllIllIIlIIll = lllllllllllllllIllIlllIllIIlIlll[llIIIIIIlIlllI[2]].length();
      if (lIIIIIIlIlIlIlII(lllllllllllllllIllIlllIllIIlIIll, llIIIIIIlIlllI[3])) {
        MethodType lllllllllllllllIllIlllIllIIllIll = MethodType.fromMethodDescriptorString(lllllllllllllllIllIlllIllIIlIlll[llIIIIIIlIlllI[3]], TabGUIItem.class.getClassLoader());
        if (lIIIIIIlIlIlIlIl(lllllllllllllllIllIlllIllIIlIIll, llIIIIIIlIlllI[3])) {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findVirtual(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIll);
          "".length();
          if (((0x5C ^ 0xF) & (0x1F ^ 0x4C ^ 0xFFFFFFFF)) != ((0x11 ^ 0x1A) << " ".length() & ((0x5C ^ 0x57) << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findStatic(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIll);
        } 
        "".length();
        if (" ".length() << " ".length() != " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIlllIllIIllIIl = llIIIIIIlIlIII[Integer.parseInt(lllllllllllllllIllIlllIllIIlIlll[llIIIIIIlIlllI[3]])];
        if (lIIIIIIlIlIlIlIl(lllllllllllllllIllIlllIllIIlIIll, llIIIIIIlIlllI[2])) {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findGetter(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIIl);
          "".length();
          if ("   ".length() <= " ".length())
            return null; 
        } else if (lIIIIIIlIlIlIlIl(lllllllllllllllIllIlllIllIIlIIll, llIIIIIIlIlllI[4])) {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findStaticGetter(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIIl);
          "".length();
          if (((0xF2 ^ 0xA3) & (0x7B ^ 0x2A ^ 0xFFFFFFFF)) > 0)
            return null; 
        } else if (lIIIIIIlIlIlIlIl(lllllllllllllllIllIlllIllIIlIIll, llIIIIIIlIlllI[5])) {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findSetter(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIIl);
          "".length();
          if (((0x11 ^ 0x16 ^ (0x46 ^ 0x43) << "   ".length()) << " ".length() & ((0xC ^ 0x1D ^ (0xA1 ^ 0xBE) << " ".length()) << " ".length() ^ -" ".length())) != (" ".length() << (0x65 ^ 0x6C ^ "   ".length() << " ".length() << " ".length()) & (" ".length() << ((0xFA ^ 0xB7) << " ".length() ^ 48 + 80 - 87 + 118) ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllIlllIllIIlIlII = lllllllllllllllIllIlllIllIIlIIIl.findStaticSetter(lllllllllllllllIllIlllIllIIlIllI, lllllllllllllllIllIlllIllIIlIlIl, lllllllllllllllIllIlllIllIIllIIl);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIlllIllIIlIlII);
    } catch (Exception lllllllllllllllIllIlllIllIIlIIlI) {
      lllllllllllllllIllIlllIllIIlIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIIllIlIl() {
    llIIIIIIlIIlll = new String[llIIIIIIlIlllI[6]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[3]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[1]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[1]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[3]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[4]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[2]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[0]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[4]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[5]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[5]];
    llIIIIIIlIIlll[llIIIIIIlIlllI[2]] = llIIIIIIlIlIIl[llIIIIIIlIlllI[6]];
    llIIIIIIlIlIII = new Class[llIIIIIIlIlllI[3]];
    llIIIIIIlIlIII[llIIIIIIlIlllI[1]] = Toggleable.class;
    llIIIIIIlIlIII[llIIIIIIlIlllI[0]] = String.class;
  }
  
  private static void lIIIIIIlIIlllIIl() {
    llIIIIIIlIlIIl = new String[llIIIIIIlIlllI[7]];
    llIIIIIIlIlIIl[llIIIIIIlIlllI[0]] = lIIIIIIlIIllIllI(llIIIIIIlIlIlI[llIIIIIIlIlllI[0]], llIIIIIIlIlIlI[llIIIIIIlIlllI[1]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[1]] = lIIIIIIlIIllIlll(llIIIIIIlIlIlI[llIIIIIIlIlllI[3]], llIIIIIIlIlIlI[llIIIIIIlIlllI[2]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[3]] = lIIIIIIlIIllIlll(llIIIIIIlIlIlI[llIIIIIIlIlllI[4]], llIIIIIIlIlIlI[llIIIIIIlIlllI[5]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[2]] = lIIIIIIlIIlllIII(llIIIIIIlIlIlI[llIIIIIIlIlllI[6]], llIIIIIIlIlIlI[llIIIIIIlIlllI[7]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[4]] = lIIIIIIlIIllIllI(llIIIIIIlIlIlI[llIIIIIIlIlllI[8]], llIIIIIIlIlIlI[llIIIIIIlIlllI[9]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[5]] = lIIIIIIlIIlllIII(llIIIIIIlIlIlI[llIIIIIIlIlllI[10]], llIIIIIIlIlIlI[llIIIIIIlIlllI[11]]);
    llIIIIIIlIlIIl[llIIIIIIlIlllI[6]] = lIIIIIIlIIllIllI("sUB1v+u0tQwsYrm6OVSaowlhudYWU5li2B78aTXgHZIaC3MbJk/HQyErtH5YlhcJIWw40GpEKQs=", "RcQhW");
    llIIIIIIlIlIlI = null;
  }
  
  private static void lIIIIIIlIIlllIlI() {
    String str = (new Exception()).getStackTrace()[llIIIIIIlIlllI[0]].getFileName();
    llIIIIIIlIlIlI = str.substring(str.indexOf("ä") + llIIIIIIlIlllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIIIlIIllIllI(String lllllllllllllllIllIlllIllIIIIIll, String lllllllllllllllIllIlllIllIIIIIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIllIIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIllIIIIIIl.getBytes(StandardCharsets.UTF_8)), llIIIIIIlIlllI[8]), "DES");
      Cipher lllllllllllllllIllIlllIllIIIIlll = Cipher.getInstance("DES");
      lllllllllllllllIllIlllIllIIIIlll.init(llIIIIIIlIlllI[3], lllllllllllllllIllIlllIllIIIlIIl);
      return new String(lllllllllllllllIllIlllIllIIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIllIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIllIIIIlIl) {
      lllllllllllllllIllIlllIllIIIIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIIIlIIlllIII(String lllllllllllllllIllIlllIlIllllllI, String lllllllllllllllIllIlllIlIlllllIl) {
    lllllllllllllllIllIlllIlIllllllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIllllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlllIlIlllllII = new StringBuilder();
    char[] lllllllllllllllIllIlllIlIllllIll = lllllllllllllllIllIlllIlIlllllIl.toCharArray();
    int lllllllllllllllIllIlllIlIllllIlI = llIIIIIIlIlllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIlllIlIllllllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIIIIIlIlllI[0];
    while (lIIIIIIlIlIlIllI(j, i)) {
      char lllllllllllllllIllIlllIlIlllllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIlllIlIllllIlI++;
      j++;
      "".length();
      if (((0x34 ^ 0x55) & (0x6E ^ 0xF ^ 0xFFFFFFFF)) >= " ".length() << " ".length() << " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIlllIlIlllllII);
  }
  
  private static String lIIIIIIlIIllIlll(String lllllllllllllllIllIlllIlIlllIllI, String lllllllllllllllIllIlllIlIlllIlIl) {
    try {
      SecretKeySpec lllllllllllllllIllIlllIlIllllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlllIlIlllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlllIlIllllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlllIlIllllIII.init(llIIIIIIlIlllI[3], lllllllllllllllIllIlllIlIllllIIl);
      return new String(lllllllllllllllIllIlllIlIllllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlllIlIlllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIlllIlIlllIlll) {
      lllllllllllllllIllIlllIlIlllIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIIIlIlIlIIll() {
    llIIIIIIlIlllI = new int[12];
    llIIIIIIlIlllI[0] = (0x3F ^ 0x5A ^ (0x27 ^ 0x16) << " ".length()) & (0xF4 ^ 0x8F ^ (0x93 ^ 0x8C) << " ".length() << " ".length() ^ -" ".length());
    llIIIIIIlIlllI[1] = " ".length();
    llIIIIIIlIlllI[2] = "   ".length();
    llIIIIIIlIlllI[3] = " ".length() << " ".length();
    llIIIIIIlIlllI[4] = " ".length() << " ".length() << " ".length();
    llIIIIIIlIlllI[5] = 0x3F ^ 0x3A;
    llIIIIIIlIlllI[6] = "   ".length() << " ".length();
    llIIIIIIlIlllI[7] = 0x2C ^ 0x2B;
    llIIIIIIlIlllI[8] = " ".length() << "   ".length();
    llIIIIIIlIlllI[9] = 0xB6 ^ 0xBF;
    llIIIIIIlIlllI[10] = ((0x53 ^ 0x1A) << " ".length() ^ 132 + 57 - 67 + 29) << " ".length();
    llIIIIIIlIlllI[11] = 0x59 ^ 0x52;
  }
  
  private static boolean lIIIIIIlIlIlIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIIIlIlIlIllI(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIIIlIlIlIlII(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\TabGUIItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */