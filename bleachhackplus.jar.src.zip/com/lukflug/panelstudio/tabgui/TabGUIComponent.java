package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Component;

public interface TabGUIComponent extends Component {
  boolean isActive();
  
  boolean select();
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\TabGUIComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */