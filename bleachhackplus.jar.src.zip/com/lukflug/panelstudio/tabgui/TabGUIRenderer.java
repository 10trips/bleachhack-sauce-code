package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.theme.ColorScheme;

public interface TabGUIRenderer {
  int getHeight();
  
  int getBorder();
  
  void renderBackground(Context paramContext, int paramInt1, int paramInt2);
  
  void renderCaption(Context paramContext, String paramString, int paramInt1, int paramInt2, boolean paramBoolean);
  
  ColorScheme getColorScheme();
  
  boolean isUpKey(int paramInt);
  
  boolean isDownKey(int paramInt);
  
  boolean isSelectKey(int paramInt);
  
  boolean isEscapeKey(int paramInt);
  
  static {
  
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\TabGUIRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */