package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.FixedComponent;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.PanelConfig;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class TabGUI extends TabGUIContainer implements FixedComponent {
  protected Point position;
  
  protected int width;
  
  private static String[] lIlllllIIlIIIl;
  
  private static Class[] lIlllllIIlIIlI;
  
  private static final String[] lIlllllIIlIIll;
  
  private static String[] lIlllllIIlIllI;
  
  private static final int[] lIlllllIIllIlI;
  
  public TabGUI(String lllllllllllllllIlllIIIlIlllIIllI, TabGUIRenderer lllllllllllllllIlllIIIlIlllIIlIl, Animation lllllllllllllllIlllIIIlIlllIIlII, Point lllllllllllllllIlllIIIlIlllIIIll, int lllllllllllllllIlllIIIlIlllIIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: aload_3
    //   4: invokespecial <init> : (Ljava/lang/String;Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;Lcom/lukflug/panelstudio/Animation;)V
    //   7: aload_0
    //   8: aload #4
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;Ljava/awt/Point;)V
    //   15: aload_0
    //   16: iload #5
    //   18: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;I)V
    //   23: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	24	0	lllllllllllllllIlllIIIlIlllIIlll	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	24	1	lllllllllllllllIlllIIIlIlllIIllI	Ljava/lang/String;
    //   0	24	2	lllllllllllllllIlllIIIlIlllIIlIl	Lcom/lukflug/panelstudio/tabgui/TabGUIRenderer;
    //   0	24	3	lllllllllllllllIlllIIIlIlllIIlII	Lcom/lukflug/panelstudio/Animation;
    //   0	24	4	lllllllllllllllIlllIIIlIlllIIIll	Ljava/awt/Point;
    //   0	24	5	lllllllllllllllIlllIIIlIlllIIIlI	I
  }
  
  public Point getPosition(Interface lllllllllllllllIlllIIIlIlllIIIII) {
    // Byte code:
    //   0: new java/awt/Point
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;)Ljava/awt/Point;
    //   10: invokespecial <init> : (Ljava/awt/Point;)V
    //   13: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIlllIIIlIlllIIIIl	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	14	1	lllllllllllllllIlllIIIlIlllIIIII	Lcom/lukflug/panelstudio/Interface;
  }
  
  public void setPosition(Interface lllllllllllllllIlllIIIlIllIllllI, Point lllllllllllllllIlllIIIlIllIlllIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;Ljava/awt/Point;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIlIllIlllll	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	8	1	lllllllllllllllIlllIIIlIllIllllI	Lcom/lukflug/panelstudio/Interface;
    //   0	8	2	lllllllllllllllIlllIIIlIllIlllIl	Ljava/awt/Point;
  }
  
  public int getWidth(Interface lllllllllllllllIlllIIIlIllIllIll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIlIllIlllII	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	7	1	lllllllllllllllIlllIIIlIllIllIll	Lcom/lukflug/panelstudio/Interface;
  }
  
  public void saveConfig(Interface lllllllllllllllIlllIIIlIllIllIIl, PanelConfig lllllllllllllllIlllIIIlIllIllIII) {
    // Byte code:
    //   0: aload_2
    //   1: aload_0
    //   2: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;)Ljava/awt/Point;
    //   7: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/PanelConfig;Ljava/awt/Point;)V
    //   12: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIlllIIIlIllIllIlI	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	13	1	lllllllllllllllIlllIIIlIllIllIIl	Lcom/lukflug/panelstudio/Interface;
    //   0	13	2	lllllllllllllllIlllIIIlIllIllIII	Lcom/lukflug/panelstudio/PanelConfig;
  }
  
  public void loadConfig(Interface lllllllllllllllIlllIIIlIllIlIllI, PanelConfig lllllllllllllllIlllIIIlIllIlIlIl) {
    // Byte code:
    //   0: aload_2
    //   1: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/PanelConfig;)Ljava/awt/Point;
    //   6: astore_3
    //   7: aload_3
    //   8: invokestatic llllllllIllIIIl : (Ljava/lang/Object;)Z
    //   11: ifeq -> 21
    //   14: aload_0
    //   15: aload_3
    //   16: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/TabGUI;Ljava/awt/Point;)V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIlllIIIlIllIlIlll	Lcom/lukflug/panelstudio/tabgui/TabGUI;
    //   0	22	1	lllllllllllllllIlllIIIlIllIlIllI	Lcom/lukflug/panelstudio/Interface;
    //   0	22	2	lllllllllllllllIlllIIIlIllIlIlIl	Lcom/lukflug/panelstudio/PanelConfig;
    //   7	15	3	lllllllllllllllIlllIIIlIllIlIlII	Ljava/awt/Point;
  }
  
  static {
    llllllllIllIIII();
    llllllllIlIllII();
    llllllllIlIlIll();
    llllllllIlIIllI();
  }
  
  private static CallSite llllllllIlIIlIl(MethodHandles.Lookup lllllllllllllllIlllIIIlIllIIlIll, String lllllllllllllllIlllIIIlIllIIlIlI, MethodType lllllllllllllllIlllIIIlIllIIlIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIlIllIlIIIl = lIlllllIIlIIIl[Integer.parseInt(lllllllllllllllIlllIIIlIllIIlIlI)].split(lIlllllIIlIIll[lIlllllIIllIlI[0]]);
      Class<?> lllllllllllllllIlllIIIlIllIlIIII = Class.forName(lllllllllllllllIlllIIIlIllIlIIIl[lIlllllIIllIlI[0]]);
      String lllllllllllllllIlllIIIlIllIIllll = lllllllllllllllIlllIIIlIllIlIIIl[lIlllllIIllIlI[1]];
      MethodHandle lllllllllllllllIlllIIIlIllIIlllI = null;
      int lllllllllllllllIlllIIIlIllIIllIl = lllllllllllllllIlllIIIlIllIlIIIl[lIlllllIIllIlI[2]].length();
      if (llllllllIllIIlI(lllllllllllllllIlllIIIlIllIIllIl, lIlllllIIllIlI[3])) {
        MethodType lllllllllllllllIlllIIIlIllIlIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIlIllIlIIIl[lIlllllIIllIlI[3]], TabGUI.class.getClassLoader());
        if (llllllllIllIIll(lllllllllllllllIlllIIIlIllIIllIl, lIlllllIIllIlI[3])) {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findVirtual(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIll);
          "".length();
          if ((((0x7 ^ 0x2E) << " ".length() ^ 0x93 ^ 0xA0) & ((0x24 ^ 0x2B) << "   ".length() ^ 0xDE ^ 0xC7 ^ -" ".length())) != 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findStatic(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIll);
        } 
        "".length();
        if (null != null)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIlIllIlIIlI = lIlllllIIlIIlI[Integer.parseInt(lllllllllllllllIlllIIIlIllIlIIIl[lIlllllIIllIlI[3]])];
        if (llllllllIllIIll(lllllllllllllllIlllIIIlIllIIllIl, lIlllllIIllIlI[2])) {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findGetter(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() < ((0x1 ^ 0x3C ^ "   ".length() << " ".length() << " ".length() << " ".length()) << " ".length() << " ".length() & (((0x1F ^ 0x6) << "   ".length() ^ 126 + 94 - 42 + 19) << " ".length() << " ".length() ^ -" ".length())))
            return null; 
        } else if (llllllllIllIIll(lllllllllllllllIlllIIIlIllIIllIl, lIlllllIIllIlI[4])) {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findStaticGetter(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIlI);
          "".length();
          if ((" ".length() << (0x4F ^ 0x4A) & (" ".length() << (0x5 ^ 0x0) ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else if (llllllllIllIIll(lllllllllllllllIlllIIIlIllIIllIl, lIlllllIIllIlI[5])) {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findSetter(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIlI);
          "".length();
          if (" ".length() << " ".length() << " ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIlIllIIlllI = lllllllllllllllIlllIIIlIllIIlIll.findStaticSetter(lllllllllllllllIlllIIIlIllIlIIII, lllllllllllllllIlllIIIlIllIIllll, lllllllllllllllIlllIIIlIllIlIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIlIllIIlllI);
    } catch (Exception lllllllllllllllIlllIIIlIllIIllII) {
      lllllllllllllllIlllIIIlIllIIllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllllIlIIllI() {
    lIlllllIIlIIIl = new String[lIlllllIIllIlI[6]];
    lIlllllIIlIIIl[lIlllllIIllIlI[3]] = lIlllllIIlIIll[lIlllllIIllIlI[1]];
    lIlllllIIlIIIl[lIlllllIIllIlI[1]] = lIlllllIIlIIll[lIlllllIIllIlI[3]];
    lIlllllIIlIIIl[lIlllllIIllIlI[4]] = lIlllllIIlIIll[lIlllllIIllIlI[2]];
    lIlllllIIlIIIl[lIlllllIIllIlI[5]] = lIlllllIIlIIll[lIlllllIIllIlI[4]];
    lIlllllIIlIIIl[lIlllllIIllIlI[2]] = lIlllllIIlIIll[lIlllllIIllIlI[5]];
    lIlllllIIlIIIl[lIlllllIIllIlI[0]] = lIlllllIIlIIll[lIlllllIIllIlI[6]];
    lIlllllIIlIIlI = new Class[lIlllllIIllIlI[3]];
    lIlllllIIlIIlI[lIlllllIIllIlI[1]] = int.class;
    lIlllllIIlIIlI[lIlllllIIllIlI[0]] = Point.class;
  }
  
  private static void llllllllIlIlIll() {
    lIlllllIIlIIll = new String[lIlllllIIllIlI[7]];
    lIlllllIIlIIll[lIlllllIIllIlI[0]] = llllllllIlIIlll(lIlllllIIlIllI[lIlllllIIllIlI[0]], lIlllllIIlIllI[lIlllllIIllIlI[1]]);
    lIlllllIIlIIll[lIlllllIIllIlI[1]] = llllllllIlIlIII(lIlllllIIlIllI[lIlllllIIllIlI[3]], lIlllllIIlIllI[lIlllllIIllIlI[2]]);
    lIlllllIIlIIll[lIlllllIIllIlI[3]] = llllllllIlIlIIl(lIlllllIIlIllI[lIlllllIIllIlI[4]], lIlllllIIlIllI[lIlllllIIllIlI[5]]);
    lIlllllIIlIIll[lIlllllIIllIlI[2]] = llllllllIlIlIIl(lIlllllIIlIllI[lIlllllIIllIlI[6]], lIlllllIIlIllI[lIlllllIIllIlI[7]]);
    lIlllllIIlIIll[lIlllllIIllIlI[4]] = llllllllIlIlIII(lIlllllIIlIllI[lIlllllIIllIlI[8]], lIlllllIIlIllI[lIlllllIIllIlI[9]]);
    lIlllllIIlIIll[lIlllllIIllIlI[5]] = llllllllIlIlIIl(lIlllllIIlIllI[lIlllllIIllIlI[10]], lIlllllIIlIllI[lIlllllIIllIlI[11]]);
    lIlllllIIlIIll[lIlllllIIllIlI[6]] = llllllllIlIlIIl("dTdtaiO7d5jD3WJn/ai1tjdA0AqzlOOsWw5foXeUZLR3GWF216odEj0SpOIjU0f0KCBXx15vla4=", "FNsFp");
    lIlllllIIlIllI = null;
  }
  
  private static void llllllllIlIllII() {
    String str = (new Exception()).getStackTrace()[lIlllllIIllIlI[0]].getFileName();
    lIlllllIIlIllI = str.substring(str.indexOf("ä") + lIlllllIIllIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllllIlIIlll(String lllllllllllllllIlllIIIlIllIIIlll, String lllllllllllllllIlllIIIlIllIIIllI) {
    lllllllllllllllIlllIIIlIllIIIlll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIllIIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIlIllIIIlIl = new StringBuilder();
    char[] lllllllllllllllIlllIIIlIllIIIlII = lllllllllllllllIlllIIIlIllIIIllI.toCharArray();
    int lllllllllllllllIlllIIIlIllIIIIll = lIlllllIIllIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIlIllIIIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllIIllIlI[0];
    while (llllllllIllIlII(j, i)) {
      char lllllllllllllllIlllIIIlIllIIlIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIlIllIIIIll++;
      j++;
      "".length();
      if (((0x1D ^ 0x22) & (0x76 ^ 0x49 ^ 0xFFFFFFFF)) == " ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIlIllIIIlIl);
  }
  
  private static String llllllllIlIlIIl(String lllllllllllllllIlllIIIlIlIllllll, String lllllllllllllllIlllIIIlIlIlllllI) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIllIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIlIlllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIlIllIIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIlIllIIIIIl.init(lIlllllIIllIlI[3], lllllllllllllllIlllIIIlIllIIIIlI);
      return new String(lllllllllllllllIlllIIIlIllIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIlIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIllIIIIII) {
      lllllllllllllllIlllIIIlIllIIIIII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllllIlIlIII(String lllllllllllllllIlllIIIlIlIlllIlI, String lllllllllllllllIlllIIIlIlIlllIIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIlIllllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIlIlllIIl.getBytes(StandardCharsets.UTF_8)), lIlllllIIllIlI[8]), "DES");
      Cipher lllllllllllllllIlllIIIlIlIllllII = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIlIlIllllII.init(lIlllllIIllIlI[3], lllllllllllllllIlllIIIlIlIllllIl);
      return new String(lllllllllllllllIlllIIIlIlIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIlIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIlIlllIll) {
      lllllllllllllllIlllIIIlIlIlllIll.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllllIllIIII() {
    lIlllllIIllIlI = new int[12];
    lIlllllIIllIlI[0] = (0x11 ^ 0x3A ^ (0x2F ^ 0x24) << " ".length() << " ".length()) << " ".length() & ((0x25 ^ 0x74 ^ (0x70 ^ 0x5B) << " ".length()) << " ".length() ^ -" ".length());
    lIlllllIIllIlI[1] = " ".length();
    lIlllllIIllIlI[2] = "   ".length();
    lIlllllIIllIlI[3] = " ".length() << " ".length();
    lIlllllIIllIlI[4] = " ".length() << " ".length() << " ".length();
    lIlllllIIllIlI[5] = 134 + 151 - 166 + 64 ^ (0x59 ^ 0x0) << " ".length();
    lIlllllIIllIlI[6] = "   ".length() << " ".length();
    lIlllllIIllIlI[7] = 0x1D ^ 0x2 ^ "   ".length() << "   ".length();
    lIlllllIIllIlI[8] = " ".length() << "   ".length();
    lIlllllIIllIlI[9] = "   ".length() << " ".length() << " ".length() ^ 0x2A ^ 0x2F;
    lIlllllIIllIlI[10] = ((0x7E ^ 0x79) << "   ".length() ^ 0x17 ^ 0x2A) << " ".length();
    lIlllllIIllIlI[11] = 0xC ^ 0x7;
  }
  
  private static boolean llllllllIllIIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllllIllIlII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllllIllIIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllllIllIIIl(Object paramObject) {
    return (paramObject != null);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\TabGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */