package com.lukflug.panelstudio.tabgui;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.theme.ColorScheme;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class DefaultRenderer implements TabGUIRenderer {
  protected ColorScheme scheme;
  
  protected int height;
  
  protected int border;
  
  protected int up;
  
  protected int down;
  
  protected int left;
  
  protected int right;
  
  protected int enter;
  
  private static String[] llIIllIIIlIIII;
  
  private static Class[] llIIllIIIlIIIl;
  
  private static final String[] llIIllIIIlIlII;
  
  private static String[] llIIllIIIlIlll;
  
  private static final int[] llIIllIIIllIII;
  
  public DefaultRenderer(ColorScheme lllllllllllllllIllIIIllIIllIIIIl, int lllllllllllllllIllIIIllIIllIIIII, int lllllllllllllllIllIIIllIIlIlllll, int lllllllllllllllIllIIIllIIlIllllI, int lllllllllllllllIllIIIllIIlIlllIl, int lllllllllllllllIllIIIllIIlIlllII, int lllllllllllllllIllIIIllIIlIllIll, int lllllllllllllllIllIIIllIIlIllIlI) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;Lcom/lukflug/panelstudio/theme/ColorScheme;)V
    //   11: aload_0
    //   12: iload_3
    //   13: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   18: aload_0
    //   19: iload_2
    //   20: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   25: aload_0
    //   26: iload #4
    //   28: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   33: aload_0
    //   34: iload #5
    //   36: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   41: aload_0
    //   42: iload #6
    //   44: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   49: aload_0
    //   50: iload #7
    //   52: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   57: aload_0
    //   58: iload #8
    //   60: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;I)V
    //   65: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	66	0	lllllllllllllllIllIIIllIIllIIIlI	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	66	1	lllllllllllllllIllIIIllIIllIIIIl	Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   0	66	2	lllllllllllllllIllIIIllIIllIIIII	I
    //   0	66	3	lllllllllllllllIllIIIllIIlIlllll	I
    //   0	66	4	lllllllllllllllIllIIIllIIlIllllI	I
    //   0	66	5	lllllllllllllllIllIIIllIIlIlllIl	I
    //   0	66	6	lllllllllllllllIllIIIllIIlIlllII	I
    //   0	66	7	lllllllllllllllIllIIIllIIlIllIll	I
    //   0	66	8	lllllllllllllllIllIIIllIIlIllIlI	I
  }
  
  public int getHeight() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllIIlIllIIl	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
  }
  
  public int getBorder() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllIIlIllIII	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
  }
  
  public void renderBackground(Context lllllllllllllllIllIIIllIIlIlIllI, int lllllllllllllllIllIIIllIIlIlIlIl, int lllllllllllllllIllIIIllIIlIlIlII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   6: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   11: astore #4
    //   13: new java/awt/Color
    //   16: dup
    //   17: aload #4
    //   19: <illegal opcode> 12 : (Ljava/awt/Color;)I
    //   24: aload #4
    //   26: <illegal opcode> 13 : (Ljava/awt/Color;)I
    //   31: aload #4
    //   33: <illegal opcode> 14 : (Ljava/awt/Color;)I
    //   38: aload_0
    //   39: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   44: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)I
    //   49: invokespecial <init> : (IIII)V
    //   52: astore #4
    //   54: aload_0
    //   55: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   60: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   65: astore #5
    //   67: aload_0
    //   68: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   73: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   78: astore #6
    //   80: aload_1
    //   81: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   86: aload_1
    //   87: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
    //   92: aload #4
    //   94: aload #4
    //   96: aload #4
    //   98: aload #4
    //   100: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   105: aload_1
    //   106: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   111: aload_1
    //   112: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Rectangle;
    //   117: aload #5
    //   119: aload #5
    //   121: aload #5
    //   123: aload #5
    //   125: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   130: aload_1
    //   131: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   136: astore #7
    //   138: aload #7
    //   140: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   143: iconst_0
    //   144: iaload
    //   145: iload_2
    //   146: <illegal opcode> 23 : (Ljava/awt/Point;II)V
    //   151: new java/awt/Rectangle
    //   154: dup
    //   155: aload #7
    //   157: new java/awt/Dimension
    //   160: dup
    //   161: aload_1
    //   162: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   167: <illegal opcode> 25 : (Ljava/awt/Dimension;)I
    //   172: iload_3
    //   173: invokespecial <init> : (II)V
    //   176: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
    //   179: astore #8
    //   181: aload_1
    //   182: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   187: aload #8
    //   189: aload #6
    //   191: aload #6
    //   193: aload #6
    //   195: aload #6
    //   197: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   202: aload_1
    //   203: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   208: aload #8
    //   210: aload #5
    //   212: aload #5
    //   214: aload #5
    //   216: aload #5
    //   218: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Rectangle;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;)V
    //   223: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	224	0	lllllllllllllllIllIIIllIIlIlIlll	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	224	1	lllllllllllllllIllIIIllIIlIlIllI	Lcom/lukflug/panelstudio/Context;
    //   0	224	2	lllllllllllllllIllIIIllIIlIlIlIl	I
    //   0	224	3	lllllllllllllllIllIIIllIIlIlIlII	I
    //   13	211	4	lllllllllllllllIllIIIllIIlIlIIll	Ljava/awt/Color;
    //   67	157	5	lllllllllllllllIllIIIllIIlIlIIlI	Ljava/awt/Color;
    //   80	144	6	lllllllllllllllIllIIIllIIlIlIIIl	Ljava/awt/Color;
    //   138	86	7	lllllllllllllllIllIIIllIIlIlIIII	Ljava/awt/Point;
    //   181	43	8	lllllllllllllllIllIIIllIIlIIllll	Ljava/awt/Rectangle;
  }
  
  public void renderCaption(Context lllllllllllllllIllIIIllIIlIIllII, String lllllllllllllllIllIIIllIIlIIlIll, int lllllllllllllllIllIIIllIIlIIlIlI, int lllllllllllllllIllIIIllIIlIIlIIl, boolean lllllllllllllllIllIIIllIIlIIlIII) {
    // Byte code:
    //   0: iload #5
    //   2: invokestatic lIIIlIIIlIllIlII : (I)Z
    //   5: ifeq -> 37
    //   8: aload_0
    //   9: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   14: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   19: astore #6
    //   21: ldc ''
    //   23: invokevirtual length : ()I
    //   26: pop
    //   27: ldc ' '
    //   29: invokevirtual length : ()I
    //   32: ineg
    //   33: ifle -> 50
    //   36: return
    //   37: aload_0
    //   38: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   43: <illegal opcode> 26 : (Lcom/lukflug/panelstudio/theme/ColorScheme;)Ljava/awt/Color;
    //   48: astore #6
    //   50: aload_1
    //   51: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   56: astore #7
    //   58: aload #7
    //   60: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   63: iconst_0
    //   64: iaload
    //   65: iload_3
    //   66: iload #4
    //   68: imul
    //   69: <illegal opcode> 23 : (Ljava/awt/Point;II)V
    //   74: aload_1
    //   75: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   80: aload #7
    //   82: aload_2
    //   83: aload #6
    //   85: <illegal opcode> 27 : (Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;Ljava/lang/String;Ljava/awt/Color;)V
    //   90: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   21	16	6	lllllllllllllllIllIIIllIIlIIlllI	Ljava/awt/Color;
    //   0	91	0	lllllllllllllllIllIIIllIIlIIllIl	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	91	1	lllllllllllllllIllIIIllIIlIIllII	Lcom/lukflug/panelstudio/Context;
    //   0	91	2	lllllllllllllllIllIIIllIIlIIlIll	Ljava/lang/String;
    //   0	91	3	lllllllllllllllIllIIIllIIlIIlIlI	I
    //   0	91	4	lllllllllllllllIllIIIllIIlIIlIIl	I
    //   0	91	5	lllllllllllllllIllIIIllIIlIIlIII	Z
    //   50	41	6	lllllllllllllllIllIIIllIIlIIIlll	Ljava/awt/Color;
    //   58	33	7	lllllllllllllllIllIIIllIIlIIIllI	Ljava/awt/Point;
  }
  
  public ColorScheme getColorScheme() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)Lcom/lukflug/panelstudio/theme/ColorScheme;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIllIIIllIIlIIIlIl	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
  }
  
  public boolean isUpKey(int lllllllllllllllIllIIIllIIlIIIIll) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: <illegal opcode> 28 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   7: invokestatic lIIIlIIIlIllIlIl : (II)Z
    //   10: ifeq -> 171
    //   13: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop
    //   24: bipush #57
    //   26: bipush #54
    //   28: ixor
    //   29: sipush #140
    //   32: sipush #171
    //   35: ixor
    //   36: ldc ' '
    //   38: invokevirtual length : ()I
    //   41: ishl
    //   42: ixor
    //   43: bipush #112
    //   45: bipush #89
    //   47: ixor
    //   48: bipush #35
    //   50: bipush #46
    //   52: ixor
    //   53: ldc '   '
    //   55: invokevirtual length : ()I
    //   58: ishl
    //   59: ixor
    //   60: ldc ' '
    //   62: invokevirtual length : ()I
    //   65: ineg
    //   66: ixor
    //   67: iand
    //   68: ldc ' '
    //   70: invokevirtual length : ()I
    //   73: ldc ' '
    //   75: invokevirtual length : ()I
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ishl
    //   84: ishl
    //   85: if_icmpne -> 176
    //   88: bipush #49
    //   90: bipush #57
    //   92: iadd
    //   93: bipush #26
    //   95: isub
    //   96: bipush #57
    //   98: iadd
    //   99: sipush #254
    //   102: sipush #179
    //   105: ixor
    //   106: ldc ' '
    //   108: invokevirtual length : ()I
    //   111: ishl
    //   112: ixor
    //   113: ldc ' '
    //   115: invokevirtual length : ()I
    //   118: ldc ' '
    //   120: invokevirtual length : ()I
    //   123: ishl
    //   124: ishl
    //   125: bipush #54
    //   127: bipush #109
    //   129: ixor
    //   130: ldc ' '
    //   132: invokevirtual length : ()I
    //   135: ishl
    //   136: bipush #66
    //   138: bipush #127
    //   140: iadd
    //   141: sipush #156
    //   144: isub
    //   145: sipush #128
    //   148: iadd
    //   149: ixor
    //   150: ldc ' '
    //   152: invokevirtual length : ()I
    //   155: ldc ' '
    //   157: invokevirtual length : ()I
    //   160: ishl
    //   161: ishl
    //   162: ldc ' '
    //   164: invokevirtual length : ()I
    //   167: ineg
    //   168: ixor
    //   169: iand
    //   170: ireturn
    //   171: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   174: iconst_0
    //   175: iaload
    //   176: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	177	0	lllllllllllllllIllIIIllIIlIIIlII	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	177	1	lllllllllllllllIllIIIllIIlIIIIll	I
  }
  
  public boolean isDownKey(int lllllllllllllllIllIIIllIIlIIIIIl) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: <illegal opcode> 29 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   7: invokestatic lIIIlIIIlIllIlIl : (II)Z
    //   10: ifeq -> 105
    //   13: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop
    //   24: bipush #101
    //   26: bipush #122
    //   28: ixor
    //   29: ldc ' '
    //   31: invokevirtual length : ()I
    //   34: ishl
    //   35: bipush #102
    //   37: bipush #121
    //   39: ixor
    //   40: ldc ' '
    //   42: invokevirtual length : ()I
    //   45: ishl
    //   46: iconst_m1
    //   47: ixor
    //   48: iand
    //   49: ldc ' '
    //   51: invokevirtual length : ()I
    //   54: ldc ' '
    //   56: invokevirtual length : ()I
    //   59: iconst_m1
    //   60: ixor
    //   61: iand
    //   62: if_icmple -> 110
    //   65: bipush #112
    //   67: bipush #125
    //   69: ixor
    //   70: ldc ' '
    //   72: invokevirtual length : ()I
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ishl
    //   81: ishl
    //   82: sipush #155
    //   85: sipush #150
    //   88: ixor
    //   89: ldc ' '
    //   91: invokevirtual length : ()I
    //   94: ldc ' '
    //   96: invokevirtual length : ()I
    //   99: ishl
    //   100: ishl
    //   101: iconst_m1
    //   102: ixor
    //   103: iand
    //   104: ireturn
    //   105: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   108: iconst_0
    //   109: iaload
    //   110: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	111	0	lllllllllllllllIllIIIllIIlIIIIlI	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	111	1	lllllllllllllllIllIIIllIIlIIIIIl	I
  }
  
  public boolean isSelectKey(int lllllllllllllllIllIIIllIIIllllll) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: <illegal opcode> 30 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   7: invokestatic lIIIlIIIlIllIllI : (II)Z
    //   10: ifeq -> 26
    //   13: iload_1
    //   14: aload_0
    //   15: <illegal opcode> 31 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   20: invokestatic lIIIlIIIlIllIlIl : (II)Z
    //   23: ifeq -> 98
    //   26: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   29: iconst_1
    //   30: iaload
    //   31: ldc ''
    //   33: invokevirtual length : ()I
    //   36: pop
    //   37: ldc '   '
    //   39: invokevirtual length : ()I
    //   42: ifge -> 103
    //   45: sipush #181
    //   48: sipush #158
    //   51: ixor
    //   52: ldc ' '
    //   54: invokevirtual length : ()I
    //   57: ishl
    //   58: sipush #209
    //   61: sipush #198
    //   64: ixor
    //   65: ixor
    //   66: bipush #85
    //   68: bipush #68
    //   70: ixor
    //   71: ldc ' '
    //   73: invokevirtual length : ()I
    //   76: ldc ' '
    //   78: invokevirtual length : ()I
    //   81: ishl
    //   82: ishl
    //   83: bipush #110
    //   85: bipush #107
    //   87: ixor
    //   88: ixor
    //   89: ldc ' '
    //   91: invokevirtual length : ()I
    //   94: ineg
    //   95: ixor
    //   96: iand
    //   97: ireturn
    //   98: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   101: iconst_0
    //   102: iaload
    //   103: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	104	0	lllllllllllllllIllIIIllIIlIIIIII	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	104	1	lllllllllllllllIllIIIllIIIllllll	I
  }
  
  public boolean isEscapeKey(int lllllllllllllllIllIIIllIIIllllIl) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: <illegal opcode> 32 : (Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;)I
    //   7: invokestatic lIIIlIIIlIllIlIl : (II)Z
    //   10: ifeq -> 121
    //   13: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   16: iconst_1
    //   17: iaload
    //   18: ldc ''
    //   20: invokevirtual length : ()I
    //   23: pop
    //   24: ldc ' '
    //   26: invokevirtual length : ()I
    //   29: ineg
    //   30: ldc '   '
    //   32: invokevirtual length : ()I
    //   35: if_icmple -> 126
    //   38: sipush #229
    //   41: sipush #130
    //   44: ixor
    //   45: ldc ' '
    //   47: invokevirtual length : ()I
    //   50: ishl
    //   51: sipush #148
    //   54: bipush #127
    //   56: iadd
    //   57: sipush #215
    //   60: isub
    //   61: sipush #137
    //   64: iadd
    //   65: ixor
    //   66: ldc ' '
    //   68: invokevirtual length : ()I
    //   71: ldc ' '
    //   73: invokevirtual length : ()I
    //   76: ishl
    //   77: ishl
    //   78: bipush #99
    //   80: bipush #14
    //   82: iadd
    //   83: bipush #-32
    //   85: isub
    //   86: iconst_0
    //   87: iadd
    //   88: bipush #47
    //   90: bipush #98
    //   92: ixor
    //   93: ldc ' '
    //   95: invokevirtual length : ()I
    //   98: ishl
    //   99: ixor
    //   100: ldc ' '
    //   102: invokevirtual length : ()I
    //   105: ldc ' '
    //   107: invokevirtual length : ()I
    //   110: ishl
    //   111: ishl
    //   112: ldc ' '
    //   114: invokevirtual length : ()I
    //   117: ineg
    //   118: ixor
    //   119: iand
    //   120: ireturn
    //   121: getstatic com/lukflug/panelstudio/tabgui/DefaultRenderer.llIIllIIIllIII : [I
    //   124: iconst_0
    //   125: iaload
    //   126: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	127	0	lllllllllllllllIllIIIllIIIlllllI	Lcom/lukflug/panelstudio/tabgui/DefaultRenderer;
    //   0	127	1	lllllllllllllllIllIIIllIIIllllIl	I
  }
  
  static {
    lIIIlIIIlIllIIll();
    lIIIlIIIlIllIIlI();
    lIIIlIIIlIllIIIl();
    lIIIlIIIlIlIllII();
  }
  
  private static CallSite lIIIlIIIlIlIIIIl(MethodHandles.Lookup lllllllllllllllIllIIIllIIIllIlII, String lllllllllllllllIllIIIllIIIllIIll, MethodType lllllllllllllllIllIIIllIIIllIIlI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIIllIIIlllIlI = llIIllIIIlIIII[Integer.parseInt(lllllllllllllllIllIIIllIIIllIIll)].split(llIIllIIIlIlII[llIIllIIIllIII[0]]);
      Class<?> lllllllllllllllIllIIIllIIIlllIIl = Class.forName(lllllllllllllllIllIIIllIIIlllIlI[llIIllIIIllIII[0]]);
      String lllllllllllllllIllIIIllIIIlllIII = lllllllllllllllIllIIIllIIIlllIlI[llIIllIIIllIII[1]];
      MethodHandle lllllllllllllllIllIIIllIIIllIlll = null;
      int lllllllllllllllIllIIIllIIIllIllI = lllllllllllllllIllIIIllIIIlllIlI[llIIllIIIllIII[2]].length();
      if (lIIIlIIIlIllIlll(lllllllllllllllIllIIIllIIIllIllI, llIIllIIIllIII[3])) {
        MethodType lllllllllllllllIllIIIllIIIllllII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIIllIIIlllIlI[llIIllIIIllIII[3]], DefaultRenderer.class.getClassLoader());
        if (lIIIlIIIlIllIlIl(lllllllllllllllIllIIIllIIIllIllI, llIIllIIIllIII[3])) {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findVirtual(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIllllII);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findStatic(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIllllII);
        } 
        "".length();
        if ("   ".length() >= " ".length() << " ".length() << " ".length())
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIIllIIIlllIll = llIIllIIIlIIIl[Integer.parseInt(lllllllllllllllIllIIIllIIIlllIlI[llIIllIIIllIII[3]])];
        if (lIIIlIIIlIllIlIl(lllllllllllllllIllIIIllIIIllIllI, llIIllIIIllIII[2])) {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findGetter(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIlllIll);
          "".length();
          if (null != null)
            return null; 
        } else if (lIIIlIIIlIllIlIl(lllllllllllllllIllIIIllIIIllIllI, llIIllIIIllIII[4])) {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findStaticGetter(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIlllIll);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else if (lIIIlIIIlIllIlIl(lllllllllllllllIllIIIllIIIllIllI, llIIllIIIllIII[5])) {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findSetter(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIlllIll);
          "".length();
          if (((0x1E ^ 0x4B) & (0x5F ^ 0xA ^ 0xFFFFFFFF)) > " ".length() << " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIIIllIIIllIlll = lllllllllllllllIllIIIllIIIllIlII.findStaticSetter(lllllllllllllllIllIIIllIIIlllIIl, lllllllllllllllIllIIIllIIIlllIII, lllllllllllllllIllIIIllIIIlllIll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIIllIIIllIlll);
    } catch (Exception lllllllllllllllIllIIIllIIIllIlIl) {
      lllllllllllllllIllIIIllIIIllIlIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIlIlIllII() {
    llIIllIIIlIIII = new String[llIIllIIIllIII[6]];
    llIIllIIIlIIII[llIIllIIIllIII[7]] = llIIllIIIlIlII[llIIllIIIllIII[1]];
    llIIllIIIlIIII[llIIllIIIllIII[8]] = llIIllIIIlIlII[llIIllIIIllIII[3]];
    llIIllIIIlIIII[llIIllIIIllIII[9]] = llIIllIIIlIlII[llIIllIIIllIII[2]];
    llIIllIIIlIIII[llIIllIIIllIII[10]] = llIIllIIIlIlII[llIIllIIIllIII[4]];
    llIIllIIIlIIII[llIIllIIIllIII[5]] = llIIllIIIlIlII[llIIllIIIllIII[5]];
    llIIllIIIlIIII[llIIllIIIllIII[11]] = llIIllIIIlIlII[llIIllIIIllIII[12]];
    llIIllIIIlIIII[llIIllIIIllIII[13]] = llIIllIIIlIlII[llIIllIIIllIII[14]];
    llIIllIIIlIIII[llIIllIIIllIII[15]] = llIIllIIIlIlII[llIIllIIIllIII[16]];
    llIIllIIIlIIII[llIIllIIIllIII[17]] = llIIllIIIlIlII[llIIllIIIllIII[18]];
    llIIllIIIlIIII[llIIllIIIllIII[19]] = llIIllIIIlIlII[llIIllIIIllIII[10]];
    llIIllIIIlIIII[llIIllIIIllIII[20]] = llIIllIIIlIlII[llIIllIIIllIII[13]];
    llIIllIIIlIIII[llIIllIIIllIII[4]] = llIIllIIIlIlII[llIIllIIIllIII[8]];
    llIIllIIIlIIII[llIIllIIIllIII[12]] = llIIllIIIlIlII[llIIllIIIllIII[7]];
    llIIllIIIlIIII[llIIllIIIllIII[18]] = llIIllIIIlIlII[llIIllIIIllIII[21]];
    llIIllIIIlIIII[llIIllIIIllIII[22]] = llIIllIIIlIlII[llIIllIIIllIII[23]];
    llIIllIIIlIIII[llIIllIIIllIII[24]] = llIIllIIIlIlII[llIIllIIIllIII[25]];
    llIIllIIIlIIII[llIIllIIIllIII[2]] = llIIllIIIlIlII[llIIllIIIllIII[26]];
    llIIllIIIlIIII[llIIllIIIllIII[1]] = llIIllIIIlIlII[llIIllIIIllIII[9]];
    llIIllIIIlIIII[llIIllIIIllIII[23]] = llIIllIIIlIlII[llIIllIIIllIII[19]];
    llIIllIIIlIIII[llIIllIIIllIII[16]] = llIIllIIIlIlII[llIIllIIIllIII[27]];
    llIIllIIIlIIII[llIIllIIIllIII[28]] = llIIllIIIlIlII[llIIllIIIllIII[29]];
    llIIllIIIlIIII[llIIllIIIllIII[21]] = llIIllIIIlIlII[llIIllIIIllIII[30]];
    llIIllIIIlIIII[llIIllIIIllIII[31]] = llIIllIIIlIlII[llIIllIIIllIII[32]];
    llIIllIIIlIIII[llIIllIIIllIII[26]] = llIIllIIIlIlII[llIIllIIIllIII[31]];
    llIIllIIIlIIII[llIIllIIIllIII[29]] = llIIllIIIlIlII[llIIllIIIllIII[24]];
    llIIllIIIlIIII[llIIllIIIllIII[25]] = llIIllIIIlIlII[llIIllIIIllIII[11]];
    llIIllIIIlIIII[llIIllIIIllIII[27]] = llIIllIIIlIlII[llIIllIIIllIII[20]];
    llIIllIIIlIIII[llIIllIIIllIII[30]] = llIIllIIIlIlII[llIIllIIIllIII[28]];
    llIIllIIIlIIII[llIIllIIIllIII[32]] = llIIllIIIlIlII[llIIllIIIllIII[15]];
    llIIllIIIlIIII[llIIllIIIllIII[33]] = llIIllIIIlIlII[llIIllIIIllIII[33]];
    llIIllIIIlIIII[llIIllIIIllIII[14]] = llIIllIIIlIlII[llIIllIIIllIII[17]];
    llIIllIIIlIIII[llIIllIIIllIII[3]] = llIIllIIIlIlII[llIIllIIIllIII[22]];
    llIIllIIIlIIII[llIIllIIIllIII[0]] = llIIllIIIlIlII[llIIllIIIllIII[6]];
    llIIllIIIlIIIl = new Class[llIIllIIIllIII[3]];
    llIIllIIIlIIIl[llIIllIIIllIII[1]] = int.class;
    llIIllIIIlIIIl[llIIllIIIllIII[0]] = ColorScheme.class;
  }
  
  private static void lIIIlIIIlIllIIIl() {
    llIIllIIIlIlII = new String[llIIllIIIllIII[34]];
    llIIllIIIlIlII[llIIllIIIllIII[0]] = lIIIlIIIlIlIllIl(llIIllIIIlIlll[llIIllIIIllIII[0]], llIIllIIIlIlll[llIIllIIIllIII[1]]);
    llIIllIIIlIlII[llIIllIIIllIII[1]] = lIIIlIIIlIlIlllI(llIIllIIIlIlll[llIIllIIIllIII[3]], llIIllIIIlIlll[llIIllIIIllIII[2]]);
    llIIllIIIlIlII[llIIllIIIllIII[3]] = lIIIlIIIlIlIlllI(llIIllIIIlIlll[llIIllIIIllIII[4]], llIIllIIIlIlll[llIIllIIIllIII[5]]);
    llIIllIIIlIlII[llIIllIIIllIII[2]] = lIIIlIIIlIlIlllI(llIIllIIIlIlll[llIIllIIIllIII[12]], llIIllIIIlIlll[llIIllIIIllIII[14]]);
    llIIllIIIlIlII[llIIllIIIllIII[4]] = lIIIlIIIlIlIlllI(llIIllIIIlIlll[llIIllIIIllIII[16]], llIIllIIIlIlll[llIIllIIIllIII[18]]);
    llIIllIIIlIlII[llIIllIIIllIII[5]] = lIIIlIIIlIlIllIl(llIIllIIIlIlll[llIIllIIIllIII[10]], llIIllIIIlIlll[llIIllIIIllIII[13]]);
    llIIllIIIlIlII[llIIllIIIllIII[12]] = lIIIlIIIlIlIllIl("Qrnrit6Zp7guZIbX1UrbwPQ+KTtmgwRtOVTnUuK+yYRUS/cvs3e1tg3SAqQze0kTnfk5I4nvMcF6j/LHzf+Vk41YRQaKcSwe5g5ZU37O1So=", "rZkMk");
    llIIllIIIlIlII[llIIllIIIllIII[14]] = lIIIlIIIlIlIlllI("jTLCpgMPMuzEZRI9iMt5HCb9hM+YMypdHKH2UlOSYXOCGd7cVbNfQ7asl5KRar126Hhjm8f4NYhj+VT9DUz+OoUdwD4fNx1k98VZpH5jsSwdaD/bJU3LEA==", "bEfzd");
    llIIllIIIlIlII[llIIllIIIllIII[16]] = lIIIlIIIlIllIIII("FRgjRyIDHCgFOxFZPgggExs9HTsSHiFHOhcVKRwnWDMrDy8DGzo7KxgTKxsrBE0qBjkYTX9TblZX", "vwNiN");
    llIIllIIIlIlII[llIIllIIIllIII[18]] = lIIIlIIIlIlIlllI("/tFbPrkB1AVYH/HdqzWrq2xNyglyF9AHxtWtAD6eidzK4h+p0YYoBqVK2TeGQFyaQyJTg7GYQXMyPUCSCUyv/Q==", "SgiHh");
    llIIllIIIlIlII[llIIllIIIllIII[10]] = lIIIlIIIlIlIllIl("pd4xkhniQI0QbiopSbk+5al7HBdf5y13Dw7XnNjp7bsNdykr/v9RqxMl9Cz2WiMufk5uCQAaroQEQaPV5hKKJPNYZEM/w4aW", "FwqzJ");
    llIIllIIIlIlII[llIIllIIIllIII[13]] = lIIIlIIIlIllIIII("NRw7XgQjGDAcHTFdJhEGMx8lBB0yGjleITgHMwIONxAzSgwkEiEjHCQaOBdSfj88ER43XDcHHHkjORkGIkgaGgkgEnkcCTgUeSMcJBo4F1MaGTcGCXkSIQRHFRw6HxptWgBKSHY=", "VsVph");
    llIIllIIIlIlII[llIIllIIIllIII[8]] = lIIIlIIIlIlIlllI("b8gRlVaQ7n+wB6ELpeHORA9HS5//lsGcEG8GFMgneC1IviVzN3+MZT6clA7pvvNupfuOL2UIsppQWdoSbumbnw==", "ciISM");
    llIIllIIIlIlII[llIIllIIIllIII[7]] = lIIIlIIIlIllIIII("BxUOTxoREQUNAwNUEwAYARYQFQMAEwxPAgUYBBQfSj4GBxcRFhczEwoeBhMTFkARCBEMDllQTERaQ0FW", "dzcav");
    llIIllIIIlIlII[llIIllIIIllIII[21]] = lIIIlIIIlIllIIII("DjkdejsYPRY4Igp4ADU5CDoDICIJPx96Iww0FyE+QxIVMjYYOgQGMgMyFSYyH2wSOyUJMwJuZld2UHQ=", "mVpTW");
    llIIllIIIlIlII[llIIllIIIllIII[23]] = lIIIlIIIlIlIlllI("A4nO/XArASLym/EzL2CZZgEU4fL3bpqYbAOUw+IuWhNvvP2/YWQ/6qmrFgyGtTeC0orN2iwBwbR9BEqFPgMIDQ==", "enqzX");
    llIIllIIIlIlII[llIIllIIIllIII[25]] = lIIIlIIIlIllIIII("DQsmEVoGHSReMA4HNR4HDgU+SgMODiQYTlZQcFBU", "gjPpt");
    llIIllIIIlIlII[llIIllIIIllIII[26]] = lIIIlIIIlIllIIII("LyIVVyA5Jh4VOStjCBgiKSELDTkoJBdXOC0vHwwlYgkdHy05IQwrKSIpHQspPncNCXZ9d1hZbGxt", "LMxyL");
    llIIllIIIlIlII[llIIllIIIllIII[9]] = lIIIlIIIlIlIllIl("bED/1oxxuG2bok6D3jfwqdmm7WxWwHFRw0IJLg2/9QzNLrEflRLAqiYZHwivogeXi2jjFyM6lfk1ZwXmkyHGkw==", "LWZuC");
    llIIllIIIlIlII[llIIllIIIllIII[19]] = lIIIlIIIlIllIIII("LhcLdB44EwA2BypWFjscKBQVLgcpEQl0BiUdCz9cDhcKNQAeGw4/HyhCAT8GAggHORs5AVxyWwRCRno=", "MxfZr");
    llIIllIIIlIlII[llIIllIIIllIII[27]] = lIIIlIIIlIllIIII("OyYIaT4tIgMrJz9nFSY8PSUWMyc8IAppJjkrAjI7dg0AITMtJREVNzYtADU3KnMNIjs/IRF9Y2JpRWc=", "XIeGR");
    llIIllIIIlIlII[llIIllIIIllIII[29]] = lIIIlIIIlIlIllIl("KYLiIYXFtrTVoxJxPUy2XjmPeB/lUxUC2GILeIz6Iq6ndtTTzwenMJsPqdRTBrO8klBHdkSnodQ=", "syhlU");
    llIIllIIIlIlII[llIIllIIIllIII[30]] = lIIIlIIIlIllIIII("ATUOClYKIwxFOwQ4FxlCDDEMKRQeMUJDUSJuWEs=", "kTxkx");
    llIIllIIIlIlII[llIIllIIIllIII[32]] = lIIIlIIIlIlIlllI("wh4infSuTNJTugaAZKed59lm584NIZtnatTeIxl6DT5FOPIdvbBjGHWz0E9tC41i1VnCAC1N/9B2O7Zr8ek8ibkankwYaBRD", "jtmWV");
    llIIllIIIlIlII[llIIllIIIllIII[31]] = lIIIlIIIlIlIlllI("DVMZ27OJyna1+IfdF8zTFgtc5N/xLlk6AOCFikl6pmgRaBqUfs4nPVnGDD/ewbC3CoNpLsqpTIvjhcjMT67aanlvt/9AhNAC6QpgY4oPNrM=", "kYPAN");
    llIIllIIIlIlII[llIIllIIIllIII[24]] = lIIIlIIIlIlIlllI("ahWGMQpjO8uxIVlFnS2ktlAlTvXHbxFvbA88G689QDQjtII4Y7ufdeV9ZgKH2hzGisfiOuG6WfGU6optwayo5qpffyujVnf6O1cpT8gLbSmqX38ro1Z3+jtXKU/IC20pql9/K6NWd/o7VylPyAttKapffyujVnf6O1cpT8gLbSnULT48HmxXPA==", "WIPqk");
    llIIllIIIlIlII[llIIllIIIllIII[11]] = lIIIlIIIlIlIlllI("aHg5H0xFXgmNRWv5sDyXHDni5B0p/iyPazYgybNFXSya/1Hum8oJoDPce7s8CADeOSOo8etd/VVQMQQFLzC6TfYxaSQiwcsnhQiuoqnKEg8=", "ScziP");
    llIIllIIIlIlII[llIIllIIIllIII[20]] = lIIIlIIIlIlIllIl("87dfgXjGi1ZxWXaXfjib+9hY/AkNRjF0ndgC3fN3mA5HEJiuenehky1T1+R4S1bs8ztqftBivweWeYdmnD5qGz5x57eJsrAo1Ntq4EXUe0s+cee3ibKwKNTbauBF1HtLPnHnt4mysCjU22rgRdR7Sz5x57eJsrAo1Ntq4EXUe0vNjj3vxmgZmA==", "SubLH");
    llIIllIIIlIlII[llIIllIIIllIII[28]] = lIIIlIIIlIlIlllI("cRAa2nT+HNdryJf0lToANGnOKyhb17OccMOX6suKkJYmtFJKU1EAjLY/8ZvebQo3lfMYXVaMWmoXjgumK3VGWA==", "jDguM");
    llIIllIIIlIlII[llIIllIIIllIII[15]] = lIIIlIIIlIllIIII("HBkVAG8XDxdPERkRDRV7AgoCDzIaGRcEe14xKkgXTFhD", "vxcaA");
    llIIllIIIlIlII[llIIllIIIllIII[33]] = lIIIlIIIlIlIlllI("6ewFrebc8RyJLwRDTC1JDAn/c7MC0cqUzbaaUTyrjar+tWWq86988zTZcDmGPIa4i3YD0Kot1nCiUdtPqgXY+w==", "feGMY");
    llIIllIIIlIlII[llIIllIIIllIII[17]] = lIIIlIIIlIllIIII("KyQmZSA9IC0nOS9lOyoiLSc4PzksIiRlOCkpLD4lZg8uLS09Jz8ZKSYvLjkpOnEuJTgtOXF6dmhra2ts", "HKKKL");
    llIIllIIIlIlII[llIIllIIIllIII[22]] = lIIIlIIIlIlIllIl("GYgEkGjp63H4uzK/4fljKWFU5QDTLtSJo8xtMEUj6bPKy4L45SIGNE5o94OKmyzXgHTJG6qRRXY8p8Ui6j/z+A==", "cihWq");
    llIIllIIIlIlII[llIIllIIIllIII[6]] = lIIIlIIIlIllIIII("EAMkeAUGBy86HBRCOTcHFgA6IhwXBSZ4HRIOLiMAXSgsMAgGAD0EDB0ILCQMAVY6NQEWASxsWUlMaXZJUw==", "slIVi");
    llIIllIIIlIlll = null;
  }
  
  private static void lIIIlIIIlIllIIlI() {
    String str = (new Exception()).getStackTrace()[llIIllIIIllIII[0]].getFileName();
    llIIllIIIlIlll = str.substring(str.indexOf("ä") + llIIllIIIllIII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIlIIIlIlIllIl(String lllllllllllllllIllIIIllIIIlIlllI, String lllllllllllllllIllIIIllIIIlIllIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIIllIIIllIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIllIIIlIllIl.getBytes(StandardCharsets.UTF_8)), llIIllIIIllIII[16]), "DES");
      Cipher lllllllllllllllIllIIIllIIIllIIII = Cipher.getInstance("DES");
      lllllllllllllllIllIIIllIIIllIIII.init(llIIllIIIllIII[3], lllllllllllllllIllIIIllIIIllIIIl);
      return new String(lllllllllllllllIllIIIllIIIllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIllIIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIllIIIlIllll) {
      lllllllllllllllIllIIIllIIIlIllll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIlIIIlIllIIII(String lllllllllllllllIllIIIllIIIlIlIll, String lllllllllllllllIllIIIllIIIlIlIlI) {
    lllllllllllllllIllIIIllIIIlIlIll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIllIIIlIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIIllIIIlIlIIl = new StringBuilder();
    char[] lllllllllllllllIllIIIllIIIlIlIII = lllllllllllllllIllIIIllIIIlIlIlI.toCharArray();
    int lllllllllllllllIllIIIllIIIlIIlll = llIIllIIIllIII[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIIllIIIlIlIll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIllIIIllIII[0];
    while (lIIIlIIIlIlllIII(j, i)) {
      char lllllllllllllllIllIIIllIIIlIllII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIIllIIIlIIlll++;
      j++;
      "".length();
      if (-(" ".length() << "   ".length() ^ "   ".length() << " ".length() << " ".length()) >= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIIllIIIlIlIIl);
  }
  
  private static String lIIIlIIIlIlIlllI(String lllllllllllllllIllIIIllIIIlIIIll, String lllllllllllllllIllIIIllIIIlIIIlI) {
    try {
      SecretKeySpec lllllllllllllllIllIIIllIIIlIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIllIIIlIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIIllIIIlIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIIllIIIlIIlIl.init(llIIllIIIllIII[3], lllllllllllllllIllIIIllIIIlIIllI);
      return new String(lllllllllllllllIllIIIllIIIlIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIllIIIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIIllIIIlIIlII) {
      lllllllllllllllIllIIIllIIIlIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIlIIIlIllIIll() {
    llIIllIIIllIII = new int[35];
    llIIllIIIllIII[0] = (0x3A ^ 0x15) << " ".length() & ((0x7A ^ 0x55) << " ".length() ^ 0xFFFFFFFF);
    llIIllIIIllIII[1] = " ".length();
    llIIllIIIllIII[2] = "   ".length();
    llIIllIIIllIII[3] = " ".length() << " ".length();
    llIIllIIIllIII[4] = " ".length() << " ".length() << " ".length();
    llIIllIIIllIII[5] = " ".length() << "   ".length() ^ 0x69 ^ 0x64;
    llIIllIIIllIII[6] = 0x3E ^ 0x21 ^ (0x9A ^ 0x85) << " ".length();
    llIIllIIIllIII[7] = (0x35 ^ 0x60) << " ".length() ^ 34 + 102 - 118 + 149;
    llIIllIIIllIII[8] = "   ".length() << " ".length() << " ".length();
    llIIllIIIllIII[9] = (0xAA ^ 0xA3) << " ".length();
    llIIllIIIllIII[10] = ((0x89 ^ 0x86) << " ".length() << " ".length() ^ 0xA9 ^ 0x90) << " ".length();
    llIIllIIIllIII[11] = ((0x18 ^ 0x3) << " ".length() ^ 0xA9 ^ 0x92) << " ".length();
    llIIllIIIllIII[12] = "   ".length() << " ".length();
    llIIllIIIllIII[13] = 0xB5 ^ 0xBE;
    llIIllIIIllIII[14] = 0x94 ^ 0x93;
    llIIllIIIllIII[15] = 0x58 ^ 0x2B ^ (0x4B ^ 0x7C) << " ".length();
    llIIllIIIllIII[16] = " ".length() << "   ".length();
    llIIllIIIllIII[17] = 0x62 ^ 0x51 ^ (0xB0 ^ 0xBB) << " ".length() << " ".length();
    llIIllIIIllIII[18] = 0x59 ^ 0x50;
    llIIllIIIllIII[19] = (0x51 ^ 0x18) << " ".length() ^ 62 + 81 - 130 + 116;
    llIIllIIIllIII[20] = 0x5E ^ 0x45;
    llIIllIIIllIII[21] = (0x89 ^ 0x8E) << " ".length();
    llIIllIIIllIII[22] = " ".length() << (0xE6 ^ 0xA3 ^ " ".length() << "   ".length() << " ".length());
    llIIllIIIllIII[23] = 0x9B ^ 0x94;
    llIIllIIIllIII[24] = (0x1B ^ 0x36) << " ".length() ^ 0xED ^ 0xAE;
    llIIllIIIllIII[25] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIllIIIllIII[26] = 0x22 ^ 0x33;
    llIIllIIIllIII[27] = ((0xB ^ 0x6) << "   ".length() ^ 0x64 ^ 0x9) << " ".length() << " ".length();
    llIIllIIIllIII[28] = (0x2F ^ 0x28) << " ".length() << " ".length();
    llIIllIIIllIII[29] = (0xBB ^ 0x94) << " ".length() ^ 0x9 ^ 0x42;
    llIIllIIIllIII[30] = ((0x24 ^ 0x17) << " ".length() ^ 0x2F ^ 0x42) << " ".length();
    llIIllIIIllIII[31] = "   ".length() << "   ".length();
    llIIllIIIllIII[32] = 0x15 ^ 0x2;
    llIIllIIIllIII[33] = (0x68 ^ 0x67) << " ".length();
    llIIllIIIllIII[34] = (125 + 32 - 80 + 54 ^ (0x1F ^ 0x56) << " ".length()) << " ".length();
  }
  
  private static boolean lIIIlIIIlIllIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIlIIIlIlllIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIlIIIlIllIlll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIlIIIlIllIlII(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIlIIIlIllIllI(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\tabgui\DefaultRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */