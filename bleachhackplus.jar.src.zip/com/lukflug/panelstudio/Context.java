package com.lukflug.panelstudio;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class Context {
  private Interface inter;
  
  private Dimension size;
  
  private Point position;
  
  private boolean focus;
  
  private boolean onTop;
  
  private boolean focusRequested;
  
  private boolean focusOverride;
  
  private String description;
  
  private static String[] lIllllIIIlIlIl;
  
  private static Class[] lIllllIIIlIllI;
  
  private static final String[] lIllllIIIllIll;
  
  private static String[] lIllllIIIlllII;
  
  private static final int[] lIllllIIIlllIl;
  
  public Context(Context lllllllllllllllIlllIIllIlIlIIIII, int lllllllllllllllIlllIIllIlIIlllll, int lllllllllllllllIlllIIllIlIIllllI, int lllllllllllllllIlllIIllIlIIlllIl, boolean lllllllllllllllIlllIIllIlIIlllII, boolean lllllllllllllllIlllIIllIlIIllIll) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   15: aload_0
    //   16: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   19: iconst_0
    //   20: iaload
    //   21: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   26: aload_0
    //   27: aconst_null
    //   28: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;Ljava/lang/String;)V
    //   33: aload_0
    //   34: aload_1
    //   35: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   40: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Context;Lcom/lukflug/panelstudio/Interface;)V
    //   45: aload_0
    //   46: new java/awt/Dimension
    //   49: dup
    //   50: aload_1
    //   51: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   56: <illegal opcode> 6 : (Ljava/awt/Dimension;)I
    //   61: iload_2
    //   62: isub
    //   63: iload_3
    //   64: isub
    //   65: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   68: iconst_0
    //   69: iaload
    //   70: invokespecial <init> : (II)V
    //   73: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;Ljava/awt/Dimension;)V
    //   78: aload_0
    //   79: new java/awt/Point
    //   82: dup
    //   83: aload_1
    //   84: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   89: invokespecial <init> : (Ljava/awt/Point;)V
    //   92: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/Context;Ljava/awt/Point;)V
    //   97: aload_0
    //   98: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   103: iload_2
    //   104: iload #4
    //   106: <illegal opcode> 11 : (Ljava/awt/Point;II)V
    //   111: aload_0
    //   112: aload_1
    //   113: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/Context;)Z
    //   118: invokestatic llllllIlIIIIIlI : (I)Z
    //   121: ifeq -> 149
    //   124: iload #5
    //   126: invokestatic llllllIlIIIIIlI : (I)Z
    //   129: ifeq -> 149
    //   132: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   135: iconst_1
    //   136: iaload
    //   137: ldc ''
    //   139: invokevirtual length : ()I
    //   142: pop
    //   143: aconst_null
    //   144: ifnull -> 154
    //   147: aconst_null
    //   148: athrow
    //   149: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   152: iconst_0
    //   153: iaload
    //   154: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   159: aload_0
    //   160: aload_1
    //   161: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/Context;)Z
    //   166: invokestatic llllllIlIIIIIlI : (I)Z
    //   169: ifeq -> 206
    //   172: iload #6
    //   174: invokestatic llllllIlIIIIIlI : (I)Z
    //   177: ifeq -> 206
    //   180: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   183: iconst_1
    //   184: iaload
    //   185: ldc ''
    //   187: invokevirtual length : ()I
    //   190: pop
    //   191: ldc '   '
    //   193: invokevirtual length : ()I
    //   196: ldc '   '
    //   198: invokevirtual length : ()I
    //   201: if_icmpeq -> 211
    //   204: aconst_null
    //   205: athrow
    //   206: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   209: iconst_0
    //   210: iaload
    //   211: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   216: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	217	0	lllllllllllllllIlllIIllIlIlIIIIl	Lcom/lukflug/panelstudio/Context;
    //   0	217	1	lllllllllllllllIlllIIllIlIlIIIII	Lcom/lukflug/panelstudio/Context;
    //   0	217	2	lllllllllllllllIlllIIllIlIIlllll	I
    //   0	217	3	lllllllllllllllIlllIIllIlIIllllI	I
    //   0	217	4	lllllllllllllllIlllIIllIlIIlllIl	I
    //   0	217	5	lllllllllllllllIlllIIllIlIIlllII	Z
    //   0	217	6	lllllllllllllllIlllIIllIlIIllIll	Z
  }
  
  public Context(Interface lllllllllllllllIlllIIllIlIIllIIl, int lllllllllllllllIlllIIllIlIIllIII, Point lllllllllllllllIlllIIllIlIIlIlll, boolean lllllllllllllllIlllIIllIlIIlIllI, boolean lllllllllllllllIlllIIllIlIIlIlIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   15: aload_0
    //   16: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   19: iconst_0
    //   20: iaload
    //   21: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   26: aload_0
    //   27: aconst_null
    //   28: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;Ljava/lang/String;)V
    //   33: aload_0
    //   34: aload_1
    //   35: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/Context;Lcom/lukflug/panelstudio/Interface;)V
    //   40: aload_0
    //   41: new java/awt/Dimension
    //   44: dup
    //   45: iload_2
    //   46: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   49: iconst_0
    //   50: iaload
    //   51: invokespecial <init> : (II)V
    //   54: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/Context;Ljava/awt/Dimension;)V
    //   59: aload_0
    //   60: new java/awt/Point
    //   63: dup
    //   64: aload_3
    //   65: invokespecial <init> : (Ljava/awt/Point;)V
    //   68: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/Context;Ljava/awt/Point;)V
    //   73: aload_0
    //   74: iload #4
    //   76: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   81: aload_0
    //   82: iload #5
    //   84: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   89: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	90	0	lllllllllllllllIlllIIllIlIIllIlI	Lcom/lukflug/panelstudio/Context;
    //   0	90	1	lllllllllllllllIlllIIllIlIIllIIl	Lcom/lukflug/panelstudio/Interface;
    //   0	90	2	lllllllllllllllIlllIIllIlIIllIII	I
    //   0	90	3	lllllllllllllllIlllIIllIlIIlIlll	Ljava/awt/Point;
    //   0	90	4	lllllllllllllllIlllIIllIlIIlIllI	Z
    //   0	90	5	lllllllllllllllIlllIIllIlIIlIlIl	Z
  }
  
  public Interface getInterface() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIlIlII	Lcom/lukflug/panelstudio/Context;
  }
  
  public Dimension getSize() {
    // Byte code:
    //   0: new java/awt/Dimension
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   10: invokespecial <init> : (Ljava/awt/Dimension;)V
    //   13: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIlllIIllIlIIlIIll	Lcom/lukflug/panelstudio/Context;
  }
  
  public void setHeight(int lllllllllllllllIlllIIllIlIIlIIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   6: iload_1
    //   7: putfield height : I
    //   10: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	11	0	lllllllllllllllIlllIIllIlIIlIIlI	Lcom/lukflug/panelstudio/Context;
    //   0	11	1	lllllllllllllllIlllIIllIlIIlIIIl	I
  }
  
  public Point getPos() {
    // Byte code:
    //   0: new java/awt/Point
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   10: invokespecial <init> : (Ljava/awt/Point;)V
    //   13: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIlllIIllIlIIlIIII	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean hasFocus() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/Context;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIIllll	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean onTop() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/Context;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIIlllI	Lcom/lukflug/panelstudio/Context;
  }
  
  public void requestFocus() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   4: iconst_1
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   11: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	12	0	lllllllllllllllIlllIIllIlIIIllIl	Lcom/lukflug/panelstudio/Context;
  }
  
  public void releaseFocus() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   11: aload_0
    //   12: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   15: iconst_1
    //   16: iaload
    //   17: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/Context;Z)V
    //   22: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	23	0	lllllllllllllllIlllIIllIlIIIllII	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean foucsRequested() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/Context;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIIlIll	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean focusReleased() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/Context;)Z
    //   6: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIIlIlI	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean isHovered() {
    // Byte code:
    //   0: new java/awt/Rectangle
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   10: aload_0
    //   11: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   16: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
    //   19: aload_0
    //   20: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   25: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
    //   30: <illegal opcode> 23 : (Ljava/awt/Rectangle;Ljava/awt/Point;)Z
    //   35: invokestatic llllllIlIIIIIlI : (I)Z
    //   38: ifeq -> 123
    //   41: aload_0
    //   42: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/Context;)Z
    //   47: invokestatic llllllIlIIIIIlI : (I)Z
    //   50: ifeq -> 123
    //   53: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   56: iconst_1
    //   57: iaload
    //   58: ldc ''
    //   60: invokevirtual length : ()I
    //   63: pop
    //   64: ldc ' '
    //   66: invokevirtual length : ()I
    //   69: ldc ' '
    //   71: invokevirtual length : ()I
    //   74: ldc ' '
    //   76: invokevirtual length : ()I
    //   79: ishl
    //   80: ishl
    //   81: ldc ' '
    //   83: invokevirtual length : ()I
    //   86: ldc ' '
    //   88: invokevirtual length : ()I
    //   91: ishl
    //   92: if_icmpne -> 128
    //   95: sipush #169
    //   98: sipush #190
    //   101: ixor
    //   102: ldc ' '
    //   104: invokevirtual length : ()I
    //   107: ishl
    //   108: bipush #95
    //   110: bipush #72
    //   112: ixor
    //   113: ldc ' '
    //   115: invokevirtual length : ()I
    //   118: ishl
    //   119: iconst_m1
    //   120: ixor
    //   121: iand
    //   122: ireturn
    //   123: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   126: iconst_0
    //   127: iaload
    //   128: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	129	0	lllllllllllllllIlllIIllIlIIIlIIl	Lcom/lukflug/panelstudio/Context;
  }
  
  public boolean isClicked() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/Context;)Z
    //   6: invokestatic llllllIlIIIIIlI : (I)Z
    //   9: ifeq -> 116
    //   12: aload_0
    //   13: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/Context;)Lcom/lukflug/panelstudio/Interface;
    //   18: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   21: iconst_0
    //   22: iaload
    //   23: <illegal opcode> 25 : (Lcom/lukflug/panelstudio/Interface;I)Z
    //   28: invokestatic llllllIlIIIIIlI : (I)Z
    //   31: ifeq -> 116
    //   34: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   37: iconst_1
    //   38: iaload
    //   39: ldc ''
    //   41: invokevirtual length : ()I
    //   44: pop
    //   45: ldc '   '
    //   47: invokevirtual length : ()I
    //   50: ldc ' '
    //   52: invokevirtual length : ()I
    //   55: ldc ' '
    //   57: invokevirtual length : ()I
    //   60: ldc ' '
    //   62: invokevirtual length : ()I
    //   65: ldc ' '
    //   67: invokevirtual length : ()I
    //   70: ishl
    //   71: ishl
    //   72: ishl
    //   73: ldc ' '
    //   75: invokevirtual length : ()I
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ldc ' '
    //   85: invokevirtual length : ()I
    //   88: ldc ' '
    //   90: invokevirtual length : ()I
    //   93: ishl
    //   94: ishl
    //   95: ishl
    //   96: iconst_m1
    //   97: ixor
    //   98: iand
    //   99: if_icmpne -> 121
    //   102: bipush #55
    //   104: bipush #10
    //   106: ixor
    //   107: bipush #27
    //   109: bipush #38
    //   111: ixor
    //   112: iconst_m1
    //   113: ixor
    //   114: iand
    //   115: ireturn
    //   116: getstatic com/lukflug/panelstudio/Context.lIllllIIIlllIl : [I
    //   119: iconst_0
    //   120: iaload
    //   121: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	122	0	lllllllllllllllIlllIIllIlIIIlIII	Lcom/lukflug/panelstudio/Context;
  }
  
  public Rectangle getRect() {
    // Byte code:
    //   0: new java/awt/Rectangle
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Point;
    //   10: aload_0
    //   11: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/Context;)Ljava/awt/Dimension;
    //   16: invokespecial <init> : (Ljava/awt/Point;Ljava/awt/Dimension;)V
    //   19: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	20	0	lllllllllllllllIlllIIllIlIIIIlll	Lcom/lukflug/panelstudio/Context;
  }
  
  public String getDescription() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 26 : (Lcom/lukflug/panelstudio/Context;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIllIlIIIIllI	Lcom/lukflug/panelstudio/Context;
  }
  
  public void setDescription(String lllllllllllllllIlllIIllIlIIIIlII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/Context;Ljava/lang/String;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIllIlIIIIlIl	Lcom/lukflug/panelstudio/Context;
    //   0	8	1	lllllllllllllllIlllIIllIlIIIIlII	Ljava/lang/String;
  }
  
  static {
    llllllIlIIIIIIl();
    llllllIlIIIIIII();
    llllllIIlllllll();
    llllllIIllllIll();
  }
  
  private static CallSite llllllIIllllIII(MethodHandles.Lookup lllllllllllllllIlllIIllIIllllIll, String lllllllllllllllIlllIIllIIllllIlI, MethodType lllllllllllllllIlllIIllIIllllIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIllIlIIIIIIl = lIllllIIIlIlIl[Integer.parseInt(lllllllllllllllIlllIIllIIllllIlI)].split(lIllllIIIllIll[lIllllIIIlllIl[0]]);
      Class<?> lllllllllllllllIlllIIllIlIIIIIII = Class.forName(lllllllllllllllIlllIIllIlIIIIIIl[lIllllIIIlllIl[0]]);
      String lllllllllllllllIlllIIllIIlllllll = lllllllllllllllIlllIIllIlIIIIIIl[lIllllIIIlllIl[1]];
      MethodHandle lllllllllllllllIlllIIllIIllllllI = null;
      int lllllllllllllllIlllIIllIIlllllIl = lllllllllllllllIlllIIllIlIIIIIIl[lIllllIIIlllIl[2]].length();
      if (llllllIlIIIIIll(lllllllllllllllIlllIIllIIlllllIl, lIllllIIIlllIl[3])) {
        MethodType lllllllllllllllIlllIIllIlIIIIIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIllIlIIIIIIl[lIllllIIIlllIl[3]], Context.class.getClassLoader());
        if (llllllIlIIIIlII(lllllllllllllllIlllIIllIIlllllIl, lIllllIIIlllIl[3])) {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findVirtual(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIll);
          "".length();
          if (((107 + 8 - 21 + 53 ^ (0x42 ^ 0x51) << "   ".length()) << " ".length() << " ".length() & (((0x31 ^ 0x10) << " ".length() << " ".length() ^ 114 + 49 - 139 + 119) << " ".length() << " ".length() ^ -" ".length())) >= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findStatic(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIll);
        } 
        "".length();
        if (" ".length() <= 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIllIlIIIIIlI = lIllllIIIlIllI[Integer.parseInt(lllllllllllllllIlllIIllIlIIIIIIl[lIllllIIIlllIl[3]])];
        if (llllllIlIIIIlII(lllllllllllllllIlllIIllIIlllllIl, lIllllIIIlllIl[2])) {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findGetter(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIlI);
          "".length();
          if (" ".length() << " ".length() >= "   ".length())
            return null; 
        } else if (llllllIlIIIIlII(lllllllllllllllIlllIIllIIlllllIl, lIllllIIIlllIl[4])) {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findStaticGetter(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIlI);
          "".length();
          if (" ".length() << " ".length() <= " ".length())
            return null; 
        } else if (llllllIlIIIIlII(lllllllllllllllIlllIIllIIlllllIl, lIllllIIIlllIl[5])) {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findSetter(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIlI);
          "".length();
          if ("   ".length() <= " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIllIIllllllI = lllllllllllllllIlllIIllIIllllIll.findStaticSetter(lllllllllllllllIlllIIllIlIIIIIII, lllllllllllllllIlllIIllIIlllllll, lllllllllllllllIlllIIllIlIIIIIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIllIIllllllI);
    } catch (Exception lllllllllllllllIlllIIllIIlllllII) {
      lllllllllllllllIlllIIllIIlllllII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllIIllllIll() {
    lIllllIIIlIlIl = new String[lIllllIIIlllIl[6]];
    lIllllIIIlIlIl[lIllllIIIlllIl[7]] = lIllllIIIllIll[lIllllIIIlllIl[1]];
    lIllllIIIlIlIl[lIllllIIIlllIl[8]] = lIllllIIIllIll[lIllllIIIlllIl[3]];
    lIllllIIIlIlIl[lIllllIIIlllIl[9]] = lIllllIIIllIll[lIllllIIIlllIl[2]];
    lIllllIIIlIlIl[lIllllIIIlllIl[10]] = lIllllIIIllIll[lIllllIIIlllIl[4]];
    lIllllIIIlIlIl[lIllllIIIlllIl[11]] = lIllllIIIllIll[lIllllIIIlllIl[5]];
    lIllllIIIlIlIl[lIllllIIIlllIl[12]] = lIllllIIIllIll[lIllllIIIlllIl[13]];
    lIllllIIIlIlIl[lIllllIIIlllIl[14]] = lIllllIIIllIll[lIllllIIIlllIl[9]];
    lIllllIIIlIlIl[lIllllIIIlllIl[15]] = lIllllIIIllIll[lIllllIIIlllIl[14]];
    lIllllIIIlIlIl[lIllllIIIlllIl[4]] = lIllllIIIllIll[lIllllIIIlllIl[16]];
    lIllllIIIlIlIl[lIllllIIIlllIl[0]] = lIllllIIIllIll[lIllllIIIlllIl[10]];
    lIllllIIIlIlIl[lIllllIIIlllIl[17]] = lIllllIIIllIll[lIllllIIIlllIl[18]];
    lIllllIIIlIlIl[lIllllIIIlllIl[19]] = lIllllIIIllIll[lIllllIIIlllIl[20]];
    lIllllIIIlIlIl[lIllllIIIlllIl[21]] = lIllllIIIllIll[lIllllIIIlllIl[7]];
    lIllllIIIlIlIl[lIllllIIIlllIl[22]] = lIllllIIIllIll[lIllllIIIlllIl[11]];
    lIllllIIIlIlIl[lIllllIIIlllIl[5]] = lIllllIIIllIll[lIllllIIIlllIl[21]];
    lIllllIIIlIlIl[lIllllIIIlllIl[23]] = lIllllIIIllIll[lIllllIIIlllIl[17]];
    lIllllIIIlIlIl[lIllllIIIlllIl[2]] = lIllllIIIllIll[lIllllIIIlllIl[19]];
    lIllllIIIlIlIl[lIllllIIIlllIl[20]] = lIllllIIIllIll[lIllllIIIlllIl[12]];
    lIllllIIIlIlIl[lIllllIIIlllIl[13]] = lIllllIIIllIll[lIllllIIIlllIl[24]];
    lIllllIIIlIlIl[lIllllIIIlllIl[3]] = lIllllIIIllIll[lIllllIIIlllIl[15]];
    lIllllIIIlIlIl[lIllllIIIlllIl[24]] = lIllllIIIllIll[lIllllIIIlllIl[23]];
    lIllllIIIlIlIl[lIllllIIIlllIl[1]] = lIllllIIIllIll[lIllllIIIlllIl[25]];
    lIllllIIIlIlIl[lIllllIIIlllIl[26]] = lIllllIIIllIll[lIllllIIIlllIl[26]];
    lIllllIIIlIlIl[lIllllIIIlllIl[25]] = lIllllIIIllIll[lIllllIIIlllIl[8]];
    lIllllIIIlIlIl[lIllllIIIlllIl[18]] = lIllllIIIllIll[lIllllIIIlllIl[22]];
    lIllllIIIlIlIl[lIllllIIIlllIl[16]] = lIllllIIIllIll[lIllllIIIlllIl[27]];
    lIllllIIIlIlIl[lIllllIIIlllIl[27]] = lIllllIIIllIll[lIllllIIIlllIl[6]];
    lIllllIIIlIllI = new Class[lIllllIIIlllIl[13]];
    lIllllIIIlIllI[lIllllIIIlllIl[4]] = Dimension.class;
    lIllllIIIlIllI[lIllllIIIlllIl[2]] = int.class;
    lIllllIIIlIllI[lIllllIIIlllIl[3]] = Interface.class;
    lIllllIIIlIllI[lIllllIIIlllIl[0]] = boolean.class;
    lIllllIIIlIllI[lIllllIIIlllIl[1]] = String.class;
    lIllllIIIlIllI[lIllllIIIlllIl[5]] = Point.class;
  }
  
  private static void llllllIIlllllll() {
    lIllllIIIllIll = new String[lIllllIIIlllIl[28]];
    lIllllIIIllIll[lIllllIIIlllIl[0]] = llllllIIlllllII(lIllllIIIlllII[lIllllIIIlllIl[0]], lIllllIIIlllII[lIllllIIIlllIl[1]]);
    lIllllIIIllIll[lIllllIIIlllIl[1]] = llllllIIlllllIl(lIllllIIIlllII[lIllllIIIlllIl[3]], lIllllIIIlllII[lIllllIIIlllIl[2]]);
    lIllllIIIllIll[lIllllIIIlllIl[3]] = llllllIIlllllIl(lIllllIIIlllII[lIllllIIIlllIl[4]], lIllllIIIlllII[lIllllIIIlllIl[5]]);
    lIllllIIIllIll[lIllllIIIlllIl[2]] = llllllIIlllllIl(lIllllIIIlllII[lIllllIIIlllIl[13]], lIllllIIIlllII[lIllllIIIlllIl[9]]);
    lIllllIIIllIll[lIllllIIIlllIl[4]] = llllllIIlllllII(lIllllIIIlllII[lIllllIIIlllIl[14]], lIllllIIIlllII[lIllllIIIlllIl[16]]);
    lIllllIIIllIll[lIllllIIIlllIl[5]] = llllllIIllllllI(lIllllIIIlllII[lIllllIIIlllIl[10]], lIllllIIIlllII[lIllllIIIlllIl[18]]);
    lIllllIIIllIll[lIllllIIIlllIl[13]] = llllllIIlllllII(lIllllIIIlllII[lIllllIIIlllIl[20]], lIllllIIIlllII[lIllllIIIlllIl[7]]);
    lIllllIIIllIll[lIllllIIIlllIl[9]] = llllllIIlllllIl("3RCN2+S9erMu1HyVOZ2k/VlFMTHpQ6Y4HojoG9E0A55fcIEmIAPX8n0iOc6b6fZajKvsbQBUG4Qij7l5b6SwWw==", "fcQIB");
    lIllllIIIllIll[lIllllIIIlllIl[14]] = llllllIIlllllIl("OG7S83AAIdD4Khiwox0BT/i0SuBFT0IztA67DzagjfMJ/Bsb4h8NN7r8RgVeQ6M+IK5BxyQAMw4=", "ifQWq");
    lIllllIIIllIll[lIllllIIIlllIl[16]] = llllllIIllllllI("Igo4fTg0DjM/ISZLJTI6JAkmJyElDDp9Fy4LITYsNV88PSAkF29hbmFFdXN0", "AeUST");
    lIllllIIIllIll[lIllllIIIlllIl[10]] = llllllIIlllllIl("plZPfFkvjXw0QGX75yTCX3kn2dMa3DH7ySLTY0TfvXu4nsK9gReGQ4EvmaKw0tT9eVlEcDL/mvQ=", "YmcIK");
    lIllllIIIllIll[lIllllIIIlllIl[18]] = llllllIIlllllII("1Wq5W478e21GSgkY3In+oeYlmmzdw6a8TqrxGQPtt2bwKvbR0cGDm0IJpSqELYlu", "ZyHIV");
    lIllllIIIllIll[lIllllIIIlllIl[20]] = llllllIIllllllI("FS4OfRQDKgU/DRFvEzIWEy0QJw0SKAx9OxkvFzYAAnsQOgITe1dpWFZh", "vAcSx");
    lIllllIIIllIll[lIllllIIIlllIl[7]] = llllllIIlllllII("50SemYck9rX7z/UWY6HdMCe/gnhWUVQcozk0pR8QEz0d27yFXndhEHLoVemioBH+", "PUWaO");
    lIllllIIIllIll[lIllllIIIlllIl[11]] = llllllIIlllllIl("nyZ1rCbOpx/7u8RYyA33r2kYw3ZuuIZB9FurtvOlp2bhRM4N5+F9HSIioEDSC/G0KxUkamYiq9M=", "hAeVL");
    lIllllIIIllIll[lIllllIIIlllIl[21]] = llllllIIllllllI("KBkiRjU+HSkELCxYPwk3Lho8HCwvHyBGGiQYOw0hP0woDS0YHzUNY2NfAwI4PRdgCS4/WQsBNC4YPAE2JU11SHk=", "KvOhY");
    lIllllIIIllIll[lIllllIIIlllIl[17]] = llllllIIlllllIl("H2tUjZ8gJyTeoyd/UAqeIGyY+Gr7ntByiX5K/SlKpnleUHkjMQwXECsnCklJjgMimL3ZzyBrDOU=", "IThuM");
    lIllllIIIllIll[lIllllIIIlllIl[19]] = llllllIIlllllII("Kcs5OwdsGkPjsdTqj6NDiQCdMKWbEg8AjCYbviOxLBalJyGYqNTQBLZY409QVtlfQPPxxNSxUXZHw+E1azQKomQRI8dWu3jNMObev6LbtpVaBJT5zPOANQ==", "xBgfr");
    lIllllIIIllIll[lIllllIIIlllIl[12]] = llllllIIlllllII("TdoIQtKhZhspwYGE/YEsofGu/vYiGWXXwmh7TrSGqBAs/F553e+FS5zqtcSrc+nk", "VBakZ");
    lIllllIIIllIll[lIllllIIIlllIl[24]] = llllllIIlllllIl("f7LSddVG7W5IJim3i/mHwqqH0ql4qBE7PqcatdXwT7g=", "pUacP");
    lIllllIIIllIll[lIllllIIIlllIl[15]] = llllllIIlllllIl("Ic5cRpN/pOeUEeG9PvMPpc/ZZ1/w+eik5cDMHFujqqUe0/FbHcpvUNJm69FBqGLqY2/dajDtVMQ=", "NgTsf");
    lIllllIIIllIll[lIllllIIIlllIl[23]] = llllllIIlllllIl("LjpihGCCZbCloGDuN5qiknbF2lJGSlKH0RZXFwPqIOrjml/7jzc341OZvNIrMpXP", "TTWpR");
    lIllllIIIllIll[lIllllIIIlllIl[25]] = llllllIIlllllII("6h6iIfco8A7bC/aCnkbZWITMSKfEJO9EKjlcxavM7AbwJK9MDwqcSsO83bdZFwCjJ+RuTRUX22A=", "mWgCR");
    lIllllIIIllIll[lIllllIIIlllIl[26]] = llllllIIllllllI("PAQjOVo3EiF2JjMGITkaMQkwYhc5CyE5HTgWb3A4PAQjOVs3EiF3JDkMOyxPfz9veFQ=", "VeUXt");
    lIllllIIIllIll[lIllllIIIlllIl[8]] = llllllIIllllllI("OQ0cWgsvCRcYEj1MARUJPw4CABI+Cx5aLjQWFAYBOwEUTgA/FjwbEikHS1xOFggQAgZ1AwYASAoNGBoTYVhRVA==", "Zbqtg");
    lIllllIIIllIll[lIllllIIIlllIl[22]] = llllllIIlllllIl("HLX7iaZ9/Ma3mSc7jsNt/da5SQIUtHelzxbpPBrv8T9LnS5At+OXUA==", "fevZT");
    lIllllIIIllIll[lIllllIIIlllIl[27]] = llllllIIllllllI("CCQ1WwUeID4ZHAxlKBQHDicrARwPIjdbKgQlLBARH3EoGhoCPzEaB1F+YlVJS2t4", "kKXui");
    lIllllIIIllIll[lIllllIIIlllIl[6]] = llllllIIllllllI("DAAHWg8aBAwYFghBGhUNCgMZABYLBgVaIAABHhEbG1UOERAMHQMEFwYABE5SVU9KVA==", "oojtc");
    lIllllIIIlllII = null;
  }
  
  private static void llllllIlIIIIIII() {
    String str = (new Exception()).getStackTrace()[lIllllIIIlllIl[0]].getFileName();
    lIllllIIIlllII = str.substring(str.indexOf("ä") + lIllllIIIlllIl[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllIIlllllIl(String lllllllllllllllIlllIIllIIlllIlIl, String lllllllllllllllIlllIIllIIlllIlII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIllllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIlllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIllIIlllIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIllIIlllIlll.init(lIllllIIIlllIl[3], lllllllllllllllIlllIIllIIllllIII);
      return new String(lllllllllllllllIlllIIllIIlllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIlllIllI) {
      lllllllllllllllIlllIIllIIlllIllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIlllllII(String lllllllllllllllIlllIIllIIlllIIII, String lllllllllllllllIlllIIllIIllIllll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIllIIlllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIllIllll.getBytes(StandardCharsets.UTF_8)), lIllllIIIlllIl[14]), "DES");
      Cipher lllllllllllllllIlllIIllIIlllIIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIIllIIlllIIlI.init(lIllllIIIlllIl[3], lllllllllllllllIlllIIllIIlllIIll);
      return new String(lllllllllllllllIlllIIllIIlllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIllIIlllIIIl) {
      lllllllllllllllIlllIIllIIlllIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllIIllllllI(String lllllllllllllllIlllIIllIIllIllIl, String lllllllllllllllIlllIIllIIllIllII) {
    lllllllllllllllIlllIIllIIllIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIllIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIllIIllIlIll = new StringBuilder();
    char[] lllllllllllllllIlllIIllIIllIlIlI = lllllllllllllllIlllIIllIIllIllII.toCharArray();
    int lllllllllllllllIlllIIllIIllIlIIl = lIllllIIIlllIl[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIllIIllIllIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllllIIIlllIl[0];
    while (llllllIlIIIIlIl(j, i)) {
      char lllllllllllllllIlllIIllIIllIlllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIllIIllIlIIl++;
      j++;
      "".length();
      if (-" ".length() < -" ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIllIIllIlIll);
  }
  
  private static void llllllIlIIIIIIl() {
    lIllllIIIlllIl = new int[29];
    lIllllIIIlllIl[0] = (0xBA ^ 0xB3) << " ".length() & ((0x77 ^ 0x7E) << " ".length() ^ 0xFFFFFFFF);
    lIllllIIIlllIl[1] = " ".length();
    lIllllIIIlllIl[2] = "   ".length();
    lIllllIIIlllIl[3] = " ".length() << " ".length();
    lIllllIIIlllIl[4] = " ".length() << " ".length() << " ".length();
    lIllllIIIlllIl[5] = "   ".length() << " ".length() << " ".length() ^ 0x1F ^ 0x16;
    lIllllIIIlllIl[6] = 0x90 ^ 0x8B;
    lIllllIIIlllIl[7] = (0x56 ^ 0x1D) << " ".length() ^ 102 + 144 - 226 + 135;
    lIllllIIIlllIl[8] = "   ".length() << "   ".length();
    lIllllIIIlllIl[9] = 0xF8 ^ 0xB3 ^ (0x4E ^ 0x5D) << " ".length() << " ".length();
    lIllllIIIlllIl[10] = ((0x4E ^ 0x77) << " ".length() ^ 0xD7 ^ 0xA0) << " ".length();
    lIllllIIIlllIl[11] = (0x9C ^ 0xBB ^ " ".length() << (0xA7 ^ 0xA2)) << " ".length();
    lIllllIIIlllIl[12] = (0x76 ^ 0x7F) << " ".length();
    lIllllIIIlllIl[13] = "   ".length() << " ".length();
    lIllllIIIlllIl[14] = " ".length() << "   ".length();
    lIllllIIIlllIl[15] = (0x94 ^ 0x91) << " ".length() << " ".length();
    lIllllIIIlllIl[16] = 0xA4 ^ 0xAD;
    lIllllIIIlllIl[17] = " ".length() << " ".length() << " ".length() << " ".length();
    lIllllIIIlllIl[18] = " ".length() << "   ".length() ^ "   ".length();
    lIllllIIIlllIl[19] = 0x99 ^ 0x88;
    lIllllIIIlllIl[20] = "   ".length() << " ".length() << " ".length();
    lIllllIIIlllIl[21] = 158 + 38 - 12 + 5 ^ (0x1A ^ 0x43) << " ".length();
    lIllllIIIlllIl[22] = 0x8A ^ 0x93;
    lIllllIIIlllIl[23] = 0xBB ^ 0xAE;
    lIllllIIIlllIl[24] = 0xF ^ 0x28 ^ (0x72 ^ 0x7F) << " ".length() << " ".length();
    lIllllIIIlllIl[25] = (0x46 ^ 0x3B ^ (0xFA ^ 0xC1) << " ".length()) << " ".length();
    lIllllIIIlllIl[26] = 95 + 119 - 207 + 166 ^ (0x10 ^ 0x4D) << " ".length();
    lIllllIIIlllIl[27] = (0x18 ^ 0x15) << " ".length();
    lIllllIIIlllIl[28] = ((0x90 ^ 0x9D) << " ".length() ^ 0x71 ^ 0x6C) << " ".length() << " ".length();
  }
  
  private static boolean llllllIlIIIIlII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllIlIIIIlIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllIlIIIIIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllIlIIIIIlI(int paramInt) {
    return (paramInt != 0);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */