package com.lukflug.panelstudio.hud;

import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.FixedComponent;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.PanelConfig;
import com.lukflug.panelstudio.theme.Renderer;
import java.awt.Point;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class HUDComponent implements FixedComponent {
  protected String title;
  
  protected Renderer renderer;
  
  protected Point position;
  
  private static String[] lIlllllIIIlIII;
  
  private static Class[] lIlllllIIIlIIl;
  
  private static final String[] lIlllllIIIlIlI;
  
  private static String[] lIlllllIIIlIll;
  
  private static final int[] lIlllllIIIllII;
  
  public HUDComponent(String lllllllllllllllIlllIIIllIlIIlIll, Renderer lllllllllllllllIlllIIIllIlIIlIlI, Point lllllllllllllllIlllIIIllIlIIlIIl) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_1
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Ljava/lang/String;)V
    //   11: aload_0
    //   12: aload_2
    //   13: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/theme/Renderer;)V
    //   18: aload_0
    //   19: aload_3
    //   20: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Ljava/awt/Point;)V
    //   25: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	26	0	lllllllllllllllIlllIIIllIlIIllII	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	26	1	lllllllllllllllIlllIIIllIlIIlIll	Ljava/lang/String;
    //   0	26	2	lllllllllllllllIlllIIIllIlIIlIlI	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	26	3	lllllllllllllllIlllIIIllIlIIlIIl	Ljava/awt/Point;
  }
  
  public String getTitle() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDComponent;)Ljava/lang/String;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIllIlIIlIII	Lcom/lukflug/panelstudio/hud/HUDComponent;
  }
  
  public void render(Context lllllllllllllllIlllIIIllIlIIIllI) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIlIIIlll	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIlIIIllI	Lcom/lukflug/panelstudio/Context;
  }
  
  public void handleButton(Context lllllllllllllllIlllIIIllIlIIIlII, int lllllllllllllllIlllIIIllIlIIIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIlIIIlIl	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIlIIIlII	Lcom/lukflug/panelstudio/Context;
    //   0	8	2	lllllllllllllllIlllIIIllIlIIIIll	I
  }
  
  public void handleKey(Context lllllllllllllllIlllIIIllIlIIIIIl, int lllllllllllllllIlllIIIllIlIIIIII) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIlIIIIlI	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIlIIIIIl	Lcom/lukflug/panelstudio/Context;
    //   0	8	2	lllllllllllllllIlllIIIllIlIIIIII	I
  }
  
  public void handleScroll(Context lllllllllllllllIlllIIIllIIlllllI, int lllllllllllllllIlllIIIllIIllllIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIIllllll	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIIlllllI	Lcom/lukflug/panelstudio/Context;
    //   0	8	2	lllllllllllllllIlllIIIllIIllllIl	I
  }
  
  public void enter(Context lllllllllllllllIlllIIIllIIlllIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIIllllII	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIIlllIll	Lcom/lukflug/panelstudio/Context;
  }
  
  public void exit(Context lllllllllllllllIlllIIIllIIlllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Lcom/lukflug/panelstudio/Context;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIIlllIlI	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIIlllIIl	Lcom/lukflug/panelstudio/Context;
  }
  
  public void releaseFocus() {}
  
  public Point getPosition(Interface lllllllllllllllIlllIIIllIIllIllI) {
    // Byte code:
    //   0: new java/awt/Point
    //   3: dup
    //   4: aload_0
    //   5: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/hud/HUDComponent;)Ljava/awt/Point;
    //   10: invokespecial <init> : (Ljava/awt/Point;)V
    //   13: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	14	0	lllllllllllllllIlllIIIllIIllIlll	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	14	1	lllllllllllllllIlllIIIllIIllIllI	Lcom/lukflug/panelstudio/Interface;
  }
  
  public void setPosition(Interface lllllllllllllllIlllIIIllIIllIlII, Point lllllllllllllllIlllIIIllIIllIIll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Ljava/awt/Point;)V
    //   7: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	8	0	lllllllllllllllIlllIIIllIIllIlIl	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	8	1	lllllllllllllllIlllIIIllIIllIlII	Lcom/lukflug/panelstudio/Interface;
    //   0	8	2	lllllllllllllllIlllIIIllIIllIIll	Ljava/awt/Point;
  }
  
  public void saveConfig(Interface lllllllllllllllIlllIIIllIIllIIIl, PanelConfig lllllllllllllllIlllIIIllIIllIIII) {
    // Byte code:
    //   0: aload_2
    //   1: aload_0
    //   2: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/hud/HUDComponent;)Ljava/awt/Point;
    //   7: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/PanelConfig;Ljava/awt/Point;)V
    //   12: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIlllIIIllIIllIIlI	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	13	1	lllllllllllllllIlllIIIllIIllIIIl	Lcom/lukflug/panelstudio/Interface;
    //   0	13	2	lllllllllllllllIlllIIIllIIllIIII	Lcom/lukflug/panelstudio/PanelConfig;
  }
  
  public void loadConfig(Interface lllllllllllllllIlllIIIllIIlIlllI, PanelConfig lllllllllllllllIlllIIIllIIlIllIl) {
    // Byte code:
    //   0: aload_2
    //   1: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/PanelConfig;)Ljava/awt/Point;
    //   6: astore_3
    //   7: aload_3
    //   8: invokestatic llllllllIIIllIl : (Ljava/lang/Object;)Z
    //   11: ifeq -> 21
    //   14: aload_0
    //   15: aload_3
    //   16: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDComponent;Ljava/awt/Point;)V
    //   21: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	22	0	lllllllllllllllIlllIIIllIIlIllll	Lcom/lukflug/panelstudio/hud/HUDComponent;
    //   0	22	1	lllllllllllllllIlllIIIllIIlIlllI	Lcom/lukflug/panelstudio/Interface;
    //   0	22	2	lllllllllllllllIlllIIIllIIlIllIl	Lcom/lukflug/panelstudio/PanelConfig;
    //   7	15	3	lllllllllllllllIlllIIIllIIlIllII	Ljava/awt/Point;
  }
  
  static {
    llllllllIIIllII();
    llllllllIIIlIll();
    llllllllIIIlIlI();
    llllllllIIIIllI();
  }
  
  private static CallSite llllllllIIIIlIl(MethodHandles.Lookup lllllllllllllllIlllIIIllIIlIIIll, String lllllllllllllllIlllIIIllIIlIIIlI, MethodType lllllllllllllllIlllIIIllIIlIIIIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIllIIlIlIIl = lIlllllIIIlIII[Integer.parseInt(lllllllllllllllIlllIIIllIIlIIIlI)].split(lIlllllIIIlIlI[lIlllllIIIllII[0]]);
      Class<?> lllllllllllllllIlllIIIllIIlIlIII = Class.forName(lllllllllllllllIlllIIIllIIlIlIIl[lIlllllIIIllII[0]]);
      String lllllllllllllllIlllIIIllIIlIIlll = lllllllllllllllIlllIIIllIIlIlIIl[lIlllllIIIllII[1]];
      MethodHandle lllllllllllllllIlllIIIllIIlIIllI = null;
      int lllllllllllllllIlllIIIllIIlIIlIl = lllllllllllllllIlllIIIllIIlIlIIl[lIlllllIIIllII[2]].length();
      if (llllllllIIIlllI(lllllllllllllllIlllIIIllIIlIIlIl, lIlllllIIIllII[3])) {
        MethodType lllllllllllllllIlllIIIllIIlIlIll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIllIIlIlIIl[lIlllllIIIllII[3]], HUDComponent.class.getClassLoader());
        if (llllllllIIIllll(lllllllllllllllIlllIIIllIIlIIlIl, lIlllllIIIllII[3])) {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findVirtual(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIll);
          "".length();
          if (" ".length() << " ".length() < " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findStatic(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIll);
        } 
        "".length();
        if (((0x68 ^ 0x45) & (0x17 ^ 0x3A ^ 0xFFFFFFFF)) < 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIllIIlIlIlI = lIlllllIIIlIIl[Integer.parseInt(lllllllllllllllIlllIIIllIIlIlIIl[lIlllllIIIllII[3]])];
        if (llllllllIIIllll(lllllllllllllllIlllIIIllIIlIIlIl, lIlllllIIIllII[2])) {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findGetter(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIlI);
          "".length();
          if (-" ".length() != -" ".length())
            return null; 
        } else if (llllllllIIIllll(lllllllllllllllIlllIIIllIIlIIlIl, lIlllllIIIllII[4])) {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findStaticGetter(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIlI);
          "".length();
          if (null != null)
            return null; 
        } else if (llllllllIIIllll(lllllllllllllllIlllIIIllIIlIIlIl, lIlllllIIIllII[5])) {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findSetter(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIlI);
          "".length();
          if (-"   ".length() >= 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIllIIlIIllI = lllllllllllllllIlllIIIllIIlIIIll.findStaticSetter(lllllllllllllllIlllIIIllIIlIlIII, lllllllllllllllIlllIIIllIIlIIlll, lllllllllllllllIlllIIIllIIlIlIlI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIllIIlIIllI);
    } catch (Exception lllllllllllllllIlllIIIllIIlIIlII) {
      lllllllllllllllIlllIIIllIIlIIlII.printStackTrace();
      return null;
    } 
  }
  
  private static void llllllllIIIIllI() {
    lIlllllIIIlIII = new String[lIlllllIIIllII[6]];
    lIlllllIIIlIII[lIlllllIIIllII[1]] = lIlllllIIIlIlI[lIlllllIIIllII[1]];
    lIlllllIIIlIII[lIlllllIIIllII[7]] = lIlllllIIIlIlI[lIlllllIIIllII[3]];
    lIlllllIIIlIII[lIlllllIIIllII[3]] = lIlllllIIIlIlI[lIlllllIIIllII[2]];
    lIlllllIIIlIII[lIlllllIIIllII[8]] = lIlllllIIIlIlI[lIlllllIIIllII[4]];
    lIlllllIIIlIII[lIlllllIIIllII[2]] = lIlllllIIIlIlI[lIlllllIIIllII[5]];
    lIlllllIIIlIII[lIlllllIIIllII[4]] = lIlllllIIIlIlI[lIlllllIIIllII[8]];
    lIlllllIIIlIII[lIlllllIIIllII[5]] = lIlllllIIIlIlI[lIlllllIIIllII[7]];
    lIlllllIIIlIII[lIlllllIIIllII[0]] = lIlllllIIIlIlI[lIlllllIIIllII[6]];
    lIlllllIIIlIIl = new Class[lIlllllIIIllII[2]];
    lIlllllIIIlIIl[lIlllllIIIllII[0]] = String.class;
    lIlllllIIIlIIl[lIlllllIIIllII[1]] = Renderer.class;
    lIlllllIIIlIIl[lIlllllIIIllII[3]] = Point.class;
  }
  
  private static void llllllllIIIlIlI() {
    lIlllllIIIlIlI = new String[lIlllllIIIllII[9]];
    lIlllllIIIlIlI[lIlllllIIIllII[0]] = llllllllIIIIlll(lIlllllIIIlIll[lIlllllIIIllII[0]], lIlllllIIIlIll[lIlllllIIIllII[1]]);
    lIlllllIIIlIlI[lIlllllIIIllII[1]] = llllllllIIIlIII(lIlllllIIIlIll[lIlllllIIIllII[3]], lIlllllIIIlIll[lIlllllIIIllII[2]]);
    lIlllllIIIlIlI[lIlllllIIIllII[3]] = llllllllIIIIlll(lIlllllIIIlIll[lIlllllIIIllII[4]], lIlllllIIIlIll[lIlllllIIIllII[5]]);
    lIlllllIIIlIlI[lIlllllIIIllII[2]] = llllllllIIIlIIl(lIlllllIIIlIll[lIlllllIIIllII[8]], lIlllllIIIlIll[lIlllllIIIllII[7]]);
    lIlllllIIIlIlI[lIlllllIIIllII[4]] = llllllllIIIlIII(lIlllllIIIlIll[lIlllllIIIllII[6]], lIlllllIIIlIll[lIlllllIIIllII[9]]);
    lIlllllIIIlIlI[lIlllllIIIllII[5]] = llllllllIIIIlll(lIlllllIIIlIll[lIlllllIIIllII[10]], lIlllllIIIlIll[lIlllllIIIllII[11]]);
    lIlllllIIIlIlI[lIlllllIIIllII[8]] = llllllllIIIIlll("29QAeb92QlNuLpOPDVHN3R5YPb4xb/Y420u93hRynkf1Pk8pFuK+K79raLqWoXaXGFnlLAhTzMUh0sPa828O9QKQzQ4hzf/pS6SSbVjNmitWJXZcU+iNjXbjPrQSyBa6", "FJHbx");
    lIlllllIIIlIlI[lIlllllIIIllII[7]] = llllllllIIIIlll("gS24EM9n3nTPZZJfH4XHm5sJ16MuAIopyIh02f4RY0iASufcP0HzfFRjS1teo2DbVPNrL7EYAIk=", "wHMQU");
    lIlllllIIIlIlI[lIlllllIIIllII[6]] = llllllllIIIIlll("jpYz5N5m/yaSO/Pj+CFzSsFuTgZbl3ekjmcHNwT1L3CyUUVveyhx/SC4+TIu4fiO3WTZ8LMEKlU=", "nFoHM");
    lIlllllIIIlIll = null;
  }
  
  private static void llllllllIIIlIll() {
    String str = (new Exception()).getStackTrace()[lIlllllIIIllII[0]].getFileName();
    lIlllllIIIlIll = str.substring(str.indexOf("ä") + lIlllllIIIllII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllllllIIIlIII(String lllllllllllllllIlllIIIllIIIlllIl, String lllllllllllllllIlllIIIllIIIlllII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllIIlIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllIIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIllIIIlllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIllIIIlllll.init(lIlllllIIIllII[3], lllllllllllllllIlllIIIllIIlIIIII);
      return new String(lllllllllllllllIlllIIIllIIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllIIIllllI) {
      lllllllllllllllIlllIIIllIIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllllIIIIlll(String lllllllllllllllIlllIIIllIIIllIII, String lllllllllllllllIlllIIIllIIIlIlll) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIllIIIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIllIIIlIlll.getBytes(StandardCharsets.UTF_8)), lIlllllIIIllII[6]), "DES");
      Cipher lllllllllllllllIlllIIIllIIIllIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIllIIIllIlI.init(lIlllllIIIllII[3], lllllllllllllllIlllIIIllIIIllIll);
      return new String(lllllllllllllllIlllIIIllIIIllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIIIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIllIIIllIIl) {
      lllllllllllllllIlllIIIllIIIllIIl.printStackTrace();
      return null;
    } 
  }
  
  private static String llllllllIIIlIIl(String lllllllllllllllIlllIIIllIIIlIlIl, String lllllllllllllllIlllIIIllIIIlIlII) {
    lllllllllllllllIlllIIIllIIIlIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIllIIIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIllIIIlIIll = new StringBuilder();
    char[] lllllllllllllllIlllIIIllIIIlIIlI = lllllllllllllllIlllIIIllIIIlIlII.toCharArray();
    int lllllllllllllllIlllIIIllIIIlIIIl = lIlllllIIIllII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIllIIIlIlIl.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllIIIllII[0];
    while (llllllllIIlIIII(j, i)) {
      char lllllllllllllllIlllIIIllIIIlIllI = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIllIIIlIIIl++;
      j++;
      "".length();
      if (((0x1E ^ 0x23) & (0x6F ^ 0x52 ^ 0xFFFFFFFF)) != 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIllIIIlIIll);
  }
  
  private static void llllllllIIIllII() {
    lIlllllIIIllII = new int[12];
    lIlllllIIIllII[0] = (0x5B ^ 0x6A) << " ".length() & ((0x25 ^ 0x14) << " ".length() ^ 0xFFFFFFFF);
    lIlllllIIIllII[1] = " ".length();
    lIlllllIIIllII[2] = "   ".length();
    lIlllllIIIllII[3] = " ".length() << " ".length();
    lIlllllIIIllII[4] = " ".length() << " ".length() << " ".length();
    lIlllllIIIllII[5] = 0x8F ^ 0x8A;
    lIlllllIIIllII[6] = " ".length() << "   ".length();
    lIlllllIIIllII[7] = 0xA6 ^ 0xA1;
    lIlllllIIIllII[8] = "   ".length() << " ".length();
    lIlllllIIIllII[9] = 0x36 ^ 0x43 ^ (0x76 ^ 0x69) << " ".length() << " ".length();
    lIlllllIIIllII[10] = (0xAC ^ 0xA9) << " ".length();
    lIlllllIIIllII[11] = 23 + 79 - 59 + 86 ^ (0xCD ^ 0x88) << " ".length();
  }
  
  private static boolean llllllllIIIllll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllllllIIlIIII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllllllIIIlllI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean llllllllIIIllIl(Object paramObject) {
    return (paramObject != null);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\hud\HUDComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */