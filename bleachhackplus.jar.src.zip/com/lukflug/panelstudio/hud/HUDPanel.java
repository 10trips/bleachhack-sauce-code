package com.lukflug.panelstudio.hud;

import com.lukflug.panelstudio.Animation;
import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.DraggableContainer;
import com.lukflug.panelstudio.FixedComponent;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.PanelConfig;
import com.lukflug.panelstudio.settings.AnimatedToggleable;
import com.lukflug.panelstudio.settings.Toggleable;
import com.lukflug.panelstudio.theme.Renderer;
import com.lukflug.panelstudio.theme.RendererProxy;
import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class HUDPanel extends DraggableContainer {
  protected Toggleable guiOpen;
  
  protected FixedComponent component;
  
  private static String[] llIIlIIIlIllIl;
  
  private static Class[] llIIlIIIlIlllI;
  
  private static final String[] llIIlIIlIIlIII;
  
  private static String[] llIIlIIlIIlIIl;
  
  private static final int[] llIIlIIlIIlIlI;
  
  public HUDPanel(FixedComponent lllllllllllllllIllIIllIllIlIIlII, Renderer lllllllllllllllIllIIllIllIlIIIll, Toggleable lllllllllllllllIllIIllIllIlIIIlI, Animation lllllllllllllllIllIIllIllIlIIIIl, Toggleable lllllllllllllllIllIIllIllIlIIIII, int lllllllllllllllIllIIllIllIIlllll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/FixedComponent;)Ljava/lang/String;
    //   7: aconst_null
    //   8: new com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer
    //   11: dup
    //   12: aload_2
    //   13: aload #5
    //   15: iload #6
    //   17: invokespecial <init> : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;I)V
    //   20: aload_3
    //   21: aload #4
    //   23: aconst_null
    //   24: new java/awt/Point
    //   27: dup
    //   28: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   31: iconst_0
    //   32: iaload
    //   33: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   36: iconst_0
    //   37: iaload
    //   38: invokespecial <init> : (II)V
    //   41: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   44: iconst_0
    //   45: iaload
    //   46: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/settings/Toggleable;Lcom/lukflug/panelstudio/Animation;Lcom/lukflug/panelstudio/settings/Toggleable;Ljava/awt/Point;I)V
    //   49: aload_0
    //   50: aload_1
    //   51: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/hud/HUDPanel;Lcom/lukflug/panelstudio/Component;)V
    //   56: aload_0
    //   57: aload #5
    //   59: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDPanel;Lcom/lukflug/panelstudio/settings/Toggleable;)V
    //   64: aload_0
    //   65: aload_1
    //   66: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel;Lcom/lukflug/panelstudio/FixedComponent;)V
    //   71: aload_0
    //   72: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   75: iconst_1
    //   76: iaload
    //   77: putfield bodyDrag : Z
    //   80: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	81	0	lllllllllllllllIllIIllIllIlIIlIl	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	81	1	lllllllllllllllIllIIllIllIlIIlII	Lcom/lukflug/panelstudio/FixedComponent;
    //   0	81	2	lllllllllllllllIllIIllIllIlIIIll	Lcom/lukflug/panelstudio/theme/Renderer;
    //   0	81	3	lllllllllllllllIllIIllIllIlIIIlI	Lcom/lukflug/panelstudio/settings/Toggleable;
    //   0	81	4	lllllllllllllllIllIIllIllIlIIIIl	Lcom/lukflug/panelstudio/Animation;
    //   0	81	5	lllllllllllllllIllIIllIllIlIIIII	Lcom/lukflug/panelstudio/settings/Toggleable;
    //   0	81	6	lllllllllllllllIllIIllIllIIlllll	I
  }
  
  public void handleButton(Context lllllllllllllllIllIIllIllIIlllIl, int lllllllllllllllIllIIllIllIIlllII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   11: invokestatic lIIIIllIlIIIIllI : (I)Z
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: aload_1
    //   19: iload_2
    //   20: invokespecial handleButton : (Lcom/lukflug/panelstudio/Context;I)V
    //   23: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	24	0	lllllllllllllllIllIIllIllIIllllI	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	24	1	lllllllllllllllIllIIllIllIIlllIl	Lcom/lukflug/panelstudio/Context;
    //   0	24	2	lllllllllllllllIllIIllIllIIlllII	I
  }
  
  public void handleScroll(Context lllllllllllllllIllIIllIllIIllIlI, int lllllllllllllllIllIIllIllIIllIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/Toggleable;
    //   6: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
    //   11: invokestatic lIIIIllIlIIIIllI : (I)Z
    //   14: ifeq -> 23
    //   17: aload_0
    //   18: aload_1
    //   19: iload_2
    //   20: invokespecial handleScroll : (Lcom/lukflug/panelstudio/Context;I)V
    //   23: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	24	0	lllllllllllllllIllIIllIllIIllIll	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	24	1	lllllllllllllllIllIIllIllIIllIlI	Lcom/lukflug/panelstudio/Context;
    //   0	24	2	lllllllllllllllIllIIllIllIIllIIl	I
  }
  
  public Point getPosition(Interface lllllllllllllllIllIIllIllIIlIlll) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/FixedComponent;
    //   7: aload_1
    //   8: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/FixedComponent;Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
    //   13: putfield position : Ljava/awt/Point;
    //   16: aload_0
    //   17: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Ljava/awt/Point;
    //   22: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   25: iconst_0
    //   26: iaload
    //   27: aload_0
    //   28: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   33: aload_0
    //   34: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   39: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)D
    //   44: dconst_0
    //   45: invokestatic lIIIIllIlIIIIlll : (DD)I
    //   48: invokestatic lIIIIllIlIIIIllI : (I)Z
    //   51: ifeq -> 93
    //   54: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   57: iconst_1
    //   58: iaload
    //   59: ldc ''
    //   61: invokevirtual length : ()I
    //   64: pop
    //   65: ldc ' '
    //   67: invokevirtual length : ()I
    //   70: ldc ' '
    //   72: invokevirtual length : ()I
    //   75: ldc ' '
    //   77: invokevirtual length : ()I
    //   80: ishl
    //   81: ishl
    //   82: ldc ' '
    //   84: invokevirtual length : ()I
    //   87: ineg
    //   88: if_icmpge -> 98
    //   91: aconst_null
    //   92: areturn
    //   93: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   96: iconst_0
    //   97: iaload
    //   98: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   103: ineg
    //   104: aload_0
    //   105: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   110: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   115: isub
    //   116: <illegal opcode> 14 : (Ljava/awt/Point;II)V
    //   121: aload_0
    //   122: aload_1
    //   123: invokespecial getPosition : (Lcom/lukflug/panelstudio/Interface;)Ljava/awt/Point;
    //   126: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	127	0	lllllllllllllllIllIIllIllIIllIII	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	127	1	lllllllllllllllIllIIllIllIIlIlll	Lcom/lukflug/panelstudio/Interface;
  }
  
  public void setPosition(Interface lllllllllllllllIllIIllIllIIlIlIl, Point lllllllllllllllIllIIllIllIIlIlII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/FixedComponent;
    //   6: aload_1
    //   7: new java/awt/Point
    //   10: dup
    //   11: aload_2
    //   12: <illegal opcode> 15 : (Ljava/awt/Point;)I
    //   17: aload_2
    //   18: <illegal opcode> 16 : (Ljava/awt/Point;)I
    //   23: aload_0
    //   24: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   29: aload_0
    //   30: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   35: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)D
    //   40: dconst_0
    //   41: invokestatic lIIIIllIlIIIlIII : (DD)I
    //   44: invokestatic lIIIIllIlIIIIllI : (I)Z
    //   47: ifeq -> 93
    //   50: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   53: iconst_1
    //   54: iaload
    //   55: ldc ''
    //   57: invokevirtual length : ()I
    //   60: pop
    //   61: ldc ' '
    //   63: invokevirtual length : ()I
    //   66: ldc ' '
    //   68: invokevirtual length : ()I
    //   71: ldc ' '
    //   73: invokevirtual length : ()I
    //   76: ishl
    //   77: ishl
    //   78: ldc ' '
    //   80: invokevirtual length : ()I
    //   83: ldc ' '
    //   85: invokevirtual length : ()I
    //   88: ishl
    //   89: if_icmpgt -> 98
    //   92: return
    //   93: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   96: iconst_0
    //   97: iaload
    //   98: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   103: iadd
    //   104: aload_0
    //   105: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   110: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   115: iadd
    //   116: invokespecial <init> : (II)V
    //   119: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/FixedComponent;Lcom/lukflug/panelstudio/Interface;Ljava/awt/Point;)V
    //   124: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	125	0	lllllllllllllllIllIIllIllIIlIllI	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	125	1	lllllllllllllllIllIIllIllIIlIlIl	Lcom/lukflug/panelstudio/Interface;
    //   0	125	2	lllllllllllllllIllIIllIllIIlIlII	Ljava/awt/Point;
  }
  
  public int getWidth(Interface lllllllllllllllIllIIllIllIIlIIlI) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/FixedComponent;
    //   6: aload_1
    //   7: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/FixedComponent;Lcom/lukflug/panelstudio/Interface;)I
    //   12: aload_0
    //   13: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   18: <illegal opcode> 19 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
    //   23: getstatic com/lukflug/panelstudio/hud/HUDPanel.llIIlIIlIIlIlI : [I
    //   26: iconst_2
    //   27: iaload
    //   28: imul
    //   29: iadd
    //   30: aload_0
    //   31: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   36: aload_0
    //   37: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Z
    //   42: <illegal opcode> 21 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   47: iadd
    //   48: aload_0
    //   49: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/theme/Renderer;
    //   54: aload_0
    //   55: <illegal opcode> 20 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Z
    //   60: <illegal opcode> 22 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)I
    //   65: iadd
    //   66: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	67	0	lllllllllllllllIllIIllIllIIlIIll	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	67	1	lllllllllllllllIllIIllIllIIlIIlI	Lcom/lukflug/panelstudio/Interface;
  }
  
  protected Rectangle getClipRect(Context lllllllllllllllIllIIllIllIIlIIII, int lllllllllllllllIllIIllIllIIIllll) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   6: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)D
    //   11: dconst_1
    //   12: invokestatic lIIIIllIlIIIlIIl : (DD)I
    //   15: invokestatic lIIIIllIlIIIIllI : (I)Z
    //   18: ifeq -> 28
    //   21: aload_0
    //   22: aload_1
    //   23: iload_2
    //   24: invokespecial getClipRect : (Lcom/lukflug/panelstudio/Context;I)Ljava/awt/Rectangle;
    //   27: areturn
    //   28: aconst_null
    //   29: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	30	0	lllllllllllllllIllIIllIllIIlIIIl	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	30	1	lllllllllllllllIllIIllIllIIlIIII	Lcom/lukflug/panelstudio/Context;
    //   0	30	2	lllllllllllllllIllIIllIllIIIllll	I
  }
  
  public void saveConfig(Interface lllllllllllllllIllIIllIllIIIllIl, PanelConfig lllllllllllllllIllIIllIllIIIllII) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/FixedComponent;
    //   6: aload_1
    //   7: aload_2
    //   8: <illegal opcode> 23 : (Lcom/lukflug/panelstudio/FixedComponent;Lcom/lukflug/panelstudio/Interface;Lcom/lukflug/panelstudio/PanelConfig;)V
    //   13: aload_2
    //   14: aload_0
    //   15: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   20: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Z
    //   25: <illegal opcode> 25 : (Lcom/lukflug/panelstudio/PanelConfig;Z)V
    //   30: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	31	0	lllllllllllllllIllIIllIllIIIlllI	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	31	1	lllllllllllllllIllIIllIllIIIllIl	Lcom/lukflug/panelstudio/Interface;
    //   0	31	2	lllllllllllllllIllIIllIllIIIllII	Lcom/lukflug/panelstudio/PanelConfig;
  }
  
  public void loadConfig(Interface lllllllllllllllIllIIllIllIIIlIlI, PanelConfig lllllllllllllllIllIIllIllIIIlIIl) {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/FixedComponent;
    //   6: aload_1
    //   7: aload_2
    //   8: <illegal opcode> 26 : (Lcom/lukflug/panelstudio/FixedComponent;Lcom/lukflug/panelstudio/Interface;Lcom/lukflug/panelstudio/PanelConfig;)V
    //   13: aload_0
    //   14: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   19: <illegal opcode> 24 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)Z
    //   24: aload_2
    //   25: <illegal opcode> 27 : (Lcom/lukflug/panelstudio/PanelConfig;)Z
    //   30: invokestatic lIIIIllIlIIIlIlI : (II)Z
    //   33: ifeq -> 47
    //   36: aload_0
    //   37: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/hud/HUDPanel;)Lcom/lukflug/panelstudio/settings/AnimatedToggleable;
    //   42: <illegal opcode> 28 : (Lcom/lukflug/panelstudio/settings/AnimatedToggleable;)V
    //   47: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	48	0	lllllllllllllllIllIIllIllIIIlIll	Lcom/lukflug/panelstudio/hud/HUDPanel;
    //   0	48	1	lllllllllllllllIllIIllIllIIIlIlI	Lcom/lukflug/panelstudio/Interface;
    //   0	48	2	lllllllllllllllIllIIllIllIIIlIIl	Lcom/lukflug/panelstudio/PanelConfig;
  }
  
  static {
    lIIIIllIlIIIIlIl();
    lIIIIllIlIIIIlII();
    lIIIIllIlIIIIIll();
    lIIIIllIIlllllll();
  }
  
  private static CallSite lIIIIllIIlIIIIlI(MethodHandles.Lookup lllllllllllllllIllIIllIllIIIIIII, String lllllllllllllllIllIIllIlIlllllll, MethodType lllllllllllllllIllIIllIlIllllllI) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllIIllIllIIIIllI = llIIlIIIlIllIl[Integer.parseInt(lllllllllllllllIllIIllIlIlllllll)].split(llIIlIIlIIlIII[llIIlIIlIIlIlI[0]]);
      Class<?> lllllllllllllllIllIIllIllIIIIlIl = Class.forName(lllllllllllllllIllIIllIllIIIIllI[llIIlIIlIIlIlI[0]]);
      String lllllllllllllllIllIIllIllIIIIlII = lllllllllllllllIllIIllIllIIIIllI[llIIlIIlIIlIlI[1]];
      MethodHandle lllllllllllllllIllIIllIllIIIIIll = null;
      int lllllllllllllllIllIIllIllIIIIIlI = lllllllllllllllIllIIllIllIIIIllI[llIIlIIlIIlIlI[3]].length();
      if (lIIIIllIlIIIlIll(lllllllllllllllIllIIllIllIIIIIlI, llIIlIIlIIlIlI[2])) {
        MethodType lllllllllllllllIllIIllIllIIIlIII = MethodType.fromMethodDescriptorString(lllllllllllllllIllIIllIllIIIIllI[llIIlIIlIIlIlI[2]], HUDPanel.class.getClassLoader());
        if (lIIIIllIlIIIllII(lllllllllllllllIllIIllIllIIIIIlI, llIIlIIlIIlIlI[2])) {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findVirtual(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIlIII);
          "".length();
          if (" ".length() << " ".length() != " ".length() << " ".length())
            return null; 
        } else {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findStatic(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIlIII);
        } 
        "".length();
        if ("   ".length() == 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIllIIllIllIIIIlll = llIIlIIIlIlllI[Integer.parseInt(lllllllllllllllIllIIllIllIIIIllI[llIIlIIlIIlIlI[2]])];
        if (lIIIIllIlIIIllII(lllllllllllllllIllIIllIllIIIIIlI, llIIlIIlIIlIlI[3])) {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findGetter(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIIlll);
          "".length();
          if (" ".length() == -" ".length())
            return null; 
        } else if (lIIIIllIlIIIllII(lllllllllllllllIllIIllIllIIIIIlI, llIIlIIlIIlIlI[4])) {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findStaticGetter(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIIlll);
          "".length();
          if (-(0x2B ^ 0x1A ^ 0xBD ^ 0x88) >= 0)
            return null; 
        } else if (lIIIIllIlIIIllII(lllllllllllllllIllIIllIllIIIIIlI, llIIlIIlIIlIlI[5])) {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findSetter(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIIlll);
          "".length();
          if (null != null)
            return null; 
        } else {
          lllllllllllllllIllIIllIllIIIIIll = lllllllllllllllIllIIllIllIIIIIII.findStaticSetter(lllllllllllllllIllIIllIllIIIIlIl, lllllllllllllllIllIIllIllIIIIlII, lllllllllllllllIllIIllIllIIIIlll);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllIIllIllIIIIIll);
    } catch (Exception lllllllllllllllIllIIllIllIIIIIIl) {
      lllllllllllllllIllIIllIllIIIIIIl.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIIlllllll() {
    llIIlIIIlIllIl = new String[llIIlIIlIIlIlI[6]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[7]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[1]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[8]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[2]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[9]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[3]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[10]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[4]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[11]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[5]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[12]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[12]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[0]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[13]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[2]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[7]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[14]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[11]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[15]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[16]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[17]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[18]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[19]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[10]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[20]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[21]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[22]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[17]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[5]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[14]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[4]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[23]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[24]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[25]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[26]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[27]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[28]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[29]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[21]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[15]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[25]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[28]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[18]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[19]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[3]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[20]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[29]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[24]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[27]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[8]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[13]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[9]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[1]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[26]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[16]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[22]];
    llIIlIIIlIllIl[llIIlIIlIIlIlI[23]] = llIIlIIlIIlIII[llIIlIIlIIlIlI[6]];
    llIIlIIIlIlllI = new Class[llIIlIIlIIlIlI[13]];
    llIIlIIIlIlllI[llIIlIIlIIlIlI[1]] = FixedComponent.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[12]] = int.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[0]] = Toggleable.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[5]] = AnimatedToggleable.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[2]] = boolean.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[4]] = Renderer.class;
    llIIlIIIlIlllI[llIIlIIlIIlIlI[3]] = Point.class;
  }
  
  private static void lIIIIllIlIIIIIll() {
    llIIlIIlIIlIII = new String[llIIlIIlIIlIlI[30]];
    llIIlIIlIIlIII[llIIlIIlIIlIlI[0]] = lIIIIllIlIIIIIII(llIIlIIlIIlIIl[llIIlIIlIIlIlI[0]], llIIlIIlIIlIIl[llIIlIIlIIlIlI[1]]);
    llIIlIIlIIlIII[llIIlIIlIIlIlI[1]] = lIIIIllIlIIIIIIl(llIIlIIlIIlIIl[llIIlIIlIIlIlI[2]], llIIlIIlIIlIIl[llIIlIIlIIlIlI[3]]);
    llIIlIIlIIlIII[llIIlIIlIIlIlI[2]] = lIIIIllIlIIIIIlI(llIIlIIlIIlIIl[llIIlIIlIIlIlI[4]], llIIlIIlIIlIIl[llIIlIIlIIlIlI[5]]);
    llIIlIIlIIlIII[llIIlIIlIIlIlI[3]] = lIIIIllIlIIIIIIl(llIIlIIlIIlIIl[llIIlIIlIIlIlI[12]], llIIlIIlIIlIIl[llIIlIIlIIlIlI[13]]);
    llIIlIIlIIlIII[llIIlIIlIIlIlI[4]] = lIIIIllIlIIIIIlI(llIIlIIlIIlIIl[llIIlIIlIIlIlI[7]], llIIlIIlIIlIIl[llIIlIIlIIlIlI[11]]);
    llIIlIIlIIlIII[llIIlIIlIIlIlI[5]] = lIIIIllIlIIIIIIl("fW8TNnoSjb5XTySZ4CP7PoYJ3HrW+xdjFdtVTj93hY7DBT5iP5BRBJG9xGWHC7knfmnEzpaka/Q=", "JBvpM");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[12]] = lIIIIllIlIIIIIIl("OZFjdE5vJyVpH/jlQaPWAgF9pVCPb/twuyLqKssKIGESLKRVGwzhQJDcTXZLT6r10LU7Q0eJVwI=", "RTGDQ");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[13]] = lIIIIllIlIIIIIII("MQEEfzsnBQ89IjVAGTA5NwIaJSI2BwZ/ETsWDDUUPQMZPjk3AB1rMDcaPTgjPgtTeX4eBAgnNn0CCD8wfT0dIz48CVJrd3I=", "RniQW");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[7]] = lIIIIllIlIIIIIlI("FLnHr4D2uwVZJwX3g9qo/iE8C2cqXPtrLWzH73nSofQM3AkOU93fhpT1IgWxjBydcpTeuOOYXS4=", "dMabP");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[11]] = lIIIIllIlIIIIIII("Bjg0CkkNLjZFNwMwLB9dFGN0UUdMeQ==", "lYBkg");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[16]] = lIIIIllIlIIIIIII("JTojSwozPigJEyF7PgQIIzk9ERMiPCFLDjMxYC0zAgUvCwMqbz0GFCk5Il9UfHVuRQ==", "FUNef");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[18]] = lIIIIllIlIIIIIII("JwQEKGcsEgZnGSIMHD1zORcTJzohBAYsc2UsO2Afd0VS", "MerII");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[10]] = lIIIIllIlIIIIIII("FBsbawgCHxApERBaBiQKEhgFMRETHRlrEB8RGyBKJREYIQEFEQR/AxIAJCwDHwA0KhYTEQR/TC1dP39EVw==", "wtvEd");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[21]] = lIIIIllIlIIIIIlI("98qA31dCsSGpuXjA49wgO3n8ec1xxkxbV087fVqZ2JBDhMmljFt41FTvviaXKuYLFFPVwMVTUTWpXIt7GuOaDiyD3b8vObYONHnw+visZH1wjf6WN4r9d552mWKDcLCXedtGtkIzHYmPVQ23ATi6l2mSgU6PvH3DQ22Y0IKsDOplH+AC960XWA==", "zraYe");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[17]] = lIIIIllIlIIIIIII("JCUkZx8yIS8lBiBkOSgdIiY6PQYjIyZnACI+PSAdIDlnCB0uJyg9FiMeJi4UKy8oKx8icD0mFCAmLHNbbhxzaVM=", "GJIIs");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[14]] = lIIIIllIlIIIIIIl("eYDEZsKx8fd2ckRQIX65GL/ILqTjnV9IMCh0D767P+8zzo/bnC9SqDh7GxzF5z2hXH6IYRf0cLE=", "AIGnG");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[23]] = lIIIIllIlIIIIIII("LSIDXw87JggdFiljHhANKyEdBRYqJAFfCzspQDk2Ch0PHwYidwkECgE9Cx9ZfndOUUM=", "NMnqc");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[25]] = lIIIIllIlIIIIIIl("Y3yD5FVrIASEoLNO1WgsXrcmm61OrzHa04V9P/eUwADRuCKVy7Jqowxb//ncdyK1dUOFM8fZRHe79mumDEXYpw==", "lndoZ");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[27]] = lIIIIllIlIIIIIII("GSY9XQgPIjYfER1nIBIKHyUjBxEeID9dNBsnNR8nFSc2GgNAJT8SACk9MQcBQGF5KV5aaQ==", "zIPsd");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[29]] = lIIIIllIlIIIIIII("DyUXTx0ZIRwNBAtkCgAfCSYJFQQIIxVPBQQvFwRfPi8UBRQeLwhbFgk+NgQXGAgVExUJOEBJK0UDQEFR", "lJzaq");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[15]] = lIIIIllIlIIIIIIl("VnEIE4613MFRX1otov/4AL1Us4GXFRKvXXTsyCLcWL0eKRmpOFoV6qO0rola424d8KsrzNK3J5A=", "uGiSG");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[28]] = lIIIIllIlIIIIIIl("t5ZgqSC+7Lq/vPX0WxRU1PHKy47QxOcXWY1qjqOwubDLNllJvnSBGbN5YtDyJA3IG3YMbgoSHax8E4i7/fD8Sd265pzwdo9yevblQCQZG0Bwwe1IkCntHUhjVuoAxo1LURq/H62X0H+m2Y83T8a9+Q==", "NQnvM");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[19]] = lIIIIllIlIIIIIII("NR86ZjkjGzEkIDFeJyk7MxwkPCAyGThmJjMEIyE7MQN5CTs/HTY8MDIkOC8yOhU2KjkzSjAtIQAROz0wbFh+DG92UA==", "VpWHU");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[20]] = lIIIIllIlIIIIIIl("++m01lvVt8UqP5A7f7r4ewUJZvBXTpu1kLB7qvLRq6klhE1IoiQgpjqakj6BuWQT+EOvEBFT2iw=", "hqWTi");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[24]] = lIIIIllIlIIIIIII("FhoeYA4AHhUiFxJbAy8MEBkAOhcRHBxgFh0QHitMJxAdKgcHEAF0BRABMSEQERABdEpcPEluQg==", "uusNb");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[8]] = lIIIIllIlIIIIIlI("qaLI0zbC+FCQ0JUTohMkzt4VWOvr+QlYvoX0bK96/zFJtFyxZ21qDaMqJrOTJ/Nimppp23iaAqxhmyH6jrSlQ2w9dUapt7Tig8QdiAHXdEYPc88qTQOAZa0B/TQVL8Be", "hDHrA");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[9]] = lIIIIllIlIIIIIlI("EUIC4IFxviaSU/Q9sWBHGDBClJX8Zr3/RYJMMay+jZ7z5tBuFmBcrAWLnAswIJggEiFqDuVVDz/ipl4g2ICT7uVtrn1OFruUavp+V3zmMkqB7ziYsMJ96gUm700+Ec280TRVINgk2dPNQRCpbyEBmA==", "FxNQC");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[26]] = lIIIIllIlIIIIIII("JzkbfCgxPRA+MSN4BjMqIToFJjEgPxl8LDEyWBoRAAYXPCEobBc2IAc5GyIrKjMYJn5sGhU9KWs6AzkiKCMRfTQlOBM+NzAjEjsraxUZPzQrOBM8MH9/IGhkZA==", "DVvRD");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[22]] = lIIIIllIlIIIIIII("KQckbSo/Ay8vMy1GOSIoLwQ6NzMuASZtLj8MZwsTDjgoLSMmUiYzIyRSfHlmakg=", "JhICF");
    llIIlIIlIIlIII[llIIlIIlIIlIlI[6]] = lIIIIllIlIIIIIII("IhsCIGIpDQBvHCcTGjV2MUBCe2xoWg==", "HztAL");
    llIIlIIlIIlIIl = null;
  }
  
  private static void lIIIIllIlIIIIlII() {
    String str = (new Exception()).getStackTrace()[llIIlIIlIIlIlI[0]].getFileName();
    llIIlIIlIIlIIl = str.substring(str.indexOf("ä") + llIIlIIlIIlIlI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lIIIIllIlIIIIIlI(String lllllllllllllllIllIIllIlIllllIlI, String lllllllllllllllIllIIllIlIllllIIl) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlIlllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlIllllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIllIlIlllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIllIlIlllllII.init(llIIlIIlIIlIlI[2], lllllllllllllllIllIIllIlIlllllIl);
      return new String(lllllllllllllllIllIIllIlIlllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIlIllllIll) {
      lllllllllllllllIllIIllIlIllllIll.printStackTrace();
      return null;
    } 
  }
  
  private static String lIIIIllIlIIIIIII(String lllllllllllllllIllIIllIlIlllIlll, String lllllllllllllllIllIIllIlIlllIllI) {
    lllllllllllllllIllIIllIlIlllIlll = new String(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIlllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIllIlIlllIlIl = new StringBuilder();
    char[] lllllllllllllllIllIIllIlIlllIlII = lllllllllllllllIllIIllIlIlllIllI.toCharArray();
    int lllllllllllllllIllIIllIlIlllIIll = llIIlIIlIIlIlI[0];
    char[] arrayOfChar1 = lllllllllllllllIllIIllIlIlllIlll.toCharArray();
    int i = arrayOfChar1.length;
    int j = llIIlIIlIIlIlI[0];
    while (lIIIIllIlIIIllIl(j, i)) {
      char lllllllllllllllIllIIllIlIllllIII = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllIIllIlIlllIIll++;
      j++;
      "".length();
      if (" ".length() << " ".length() <= 0)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllIIllIlIlllIlIl);
  }
  
  private static String lIIIIllIlIIIIIIl(String lllllllllllllllIllIIllIlIllIllll, String lllllllllllllllIllIIllIlIllIlllI) {
    try {
      SecretKeySpec lllllllllllllllIllIIllIlIlllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlIllIlllI.getBytes(StandardCharsets.UTF_8)), llIIlIIlIIlIlI[7]), "DES");
      Cipher lllllllllllllllIllIIllIlIlllIIIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIlIlllIIIl.init(llIIlIIlIIlIlI[2], lllllllllllllllIllIIllIlIlllIIlI);
      return new String(lllllllllllllllIllIIllIlIlllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllIIllIlIlllIIII) {
      lllllllllllllllIllIIllIlIlllIIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lIIIIllIlIIIIlIl() {
    llIIlIIlIIlIlI = new int[31];
    llIIlIIlIIlIlI[0] = ((0x21 ^ 0x46) << " ".length() ^ 45 + 123 - 31 + 20) & (0x17 ^ 0x6E ^ (0xB7 ^ 0xA2) << " ".length() ^ -" ".length());
    llIIlIIlIIlIlI[1] = " ".length();
    llIIlIIlIIlIlI[2] = " ".length() << " ".length();
    llIIlIIlIIlIlI[3] = "   ".length();
    llIIlIIlIIlIlI[4] = " ".length() << " ".length() << " ".length();
    llIIlIIlIIlIlI[5] = (0x81 ^ 0x88) << " ".length() << " ".length() << " ".length() ^ 56 + 101 - 126 + 118;
    llIIlIIlIIlIlI[6] = 0xA5 ^ 0x94 ^ (0x87 ^ 0x8C) << " ".length() << " ".length();
    llIIlIIlIIlIlI[7] = " ".length() << "   ".length();
    llIIlIIlIIlIlI[8] = (0x6A ^ 0x51) << " ".length() ^ 0xF3 ^ 0x9C;
    llIIlIIlIIlIlI[9] = (0xCA ^ 0xC7) << " ".length();
    llIIlIIlIIlIlI[10] = "   ".length() << " ".length() << " ".length();
    llIIlIIlIIlIlI[11] = 0x21 ^ 0x28;
    llIIlIIlIIlIlI[12] = "   ".length() << " ".length();
    llIIlIIlIIlIlI[13] = 19 + 166 - 91 + 77 ^ (0xEC ^ 0xC7) << " ".length() << " ".length();
    llIIlIIlIIlIlI[14] = 0xB1 ^ 0xBE;
    llIIlIIlIIlIlI[15] = (163 + 25 - 159 + 146 ^ (0xFE ^ 0xAB) << " ".length()) << " ".length() << " ".length();
    llIIlIIlIIlIlI[16] = (0x64 ^ 0x61) << " ".length();
    llIIlIIlIIlIlI[17] = (0x2F ^ 0x28) << " ".length();
    llIIlIIlIIlIlI[18] = 0x5A ^ 0x51;
    llIIlIIlIIlIlI[19] = (0x29 ^ 0x22) << " ".length();
    llIIlIIlIIlIlI[20] = "   ".length() << " ".length() << " ".length() ^ 0x7C ^ 0x67;
    llIIlIIlIIlIlI[21] = 0x18 ^ 0x65 ^ (0xC6 ^ 0xC1) << " ".length() << " ".length() << " ".length();
    llIIlIIlIIlIlI[22] = (0x72 ^ 0x75) << " ".length() << " ".length();
    llIIlIIlIIlIlI[23] = " ".length() << " ".length() << " ".length() << " ".length();
    llIIlIIlIIlIlI[24] = "   ".length() << "   ".length();
    llIIlIIlIIlIlI[25] = 0x4 ^ 0x15;
    llIIlIIlIIlIlI[26] = 0x4E ^ 0x55;
    llIIlIIlIIlIlI[27] = (0x69 ^ 0x60) << " ".length();
    llIIlIIlIIlIlI[28] = 0x47 ^ 0x52;
    llIIlIIlIIlIlI[29] = 0x97 ^ 0x84;
    llIIlIIlIIlIlI[30] = ((0xB7 ^ 0x9A) << " ".length() << " ".length() ^ 174 + 14 - 39 + 38) << " ".length();
  }
  
  private static boolean lIIIIllIlIIIllII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lIIIIllIlIIIllIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lIIIIllIlIIIlIll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lIIIIllIlIIIIllI(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lIIIIllIlIIIlIlI(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
  
  private static int lIIIIllIlIIIIlll(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIllIlIIIlIII(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  private static int lIIIIllIlIIIlIIl(double paramDouble1, double paramDouble2) {
    return paramDouble1 cmp paramDouble2;
  }
  
  protected static class HUDRenderer extends RendererProxy {
    Renderer renderer;
    
    protected Toggleable guiOpen;
    
    protected int minBorder;
    
    private static String[] lIlllllIlIIlll;
    
    private static Class[] lIlllllIlIlIII;
    
    private static final String[] lIlllllIlIlIIl;
    
    private static String[] lIlllllIlIlIlI;
    
    private static final int[] lIlllllIlIllII;
    
    public HUDRenderer(Renderer lllllllllllllllIlllIIIlIIIIlIIll, Toggleable lllllllllllllllIlllIIIlIIIIlIIlI, int lllllllllllllllIlllIIIlIIIIlIIIl) {
      // Byte code:
      //   0: aload_0
      //   1: invokespecial <init> : ()V
      //   4: aload_0
      //   5: aload_1
      //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;Lcom/lukflug/panelstudio/theme/Renderer;)V
      //   11: aload_0
      //   12: aload_2
      //   13: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;Lcom/lukflug/panelstudio/settings/Toggleable;)V
      //   18: aload_0
      //   19: iload_3
      //   20: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;I)V
      //   25: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	26	0	lllllllllllllllIlllIIIlIIIIlIlII	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	26	1	lllllllllllllllIlllIIIlIIIIlIIll	Lcom/lukflug/panelstudio/theme/Renderer;
      //   0	26	2	lllllllllllllllIlllIIIlIIIIlIIlI	Lcom/lukflug/panelstudio/settings/Toggleable;
      //   0	26	3	lllllllllllllllIlllIIIlIIIIlIIIl	I
    }
    
    public int getOffset() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   6: <illegal opcode> 4 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
      //   11: aload_0
      //   12: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)I
      //   17: <illegal opcode> 6 : (II)I
      //   22: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	23	0	lllllllllllllllIlllIIIlIIIIlIIII	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
    }
    
    public int getBorder() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   6: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/theme/Renderer;)I
      //   11: aload_0
      //   12: <illegal opcode> 5 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)I
      //   17: <illegal opcode> 6 : (II)I
      //   22: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	23	0	lllllllllllllllIlllIIIlIIIIIllll	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
    }
    
    public void renderTitle(Context lllllllllllllllIlllIIIlIIIIIllIl, String lllllllllllllllIlllIIIlIIIIIllII, boolean lllllllllllllllIlllIIIlIIIIIlIll) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 31
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: aload_2
      //   25: iload_3
      //   26: <illegal opcode> 10 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;Z)V
      //   31: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	32	0	lllllllllllllllIlllIIIlIIIIIlllI	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	32	1	lllllllllllllllIlllIIIlIIIIIllIl	Lcom/lukflug/panelstudio/Context;
      //   0	32	2	lllllllllllllllIlllIIIlIIIIIllII	Ljava/lang/String;
      //   0	32	3	lllllllllllllllIlllIIIlIIIIIlIll	Z
    }
    
    public void renderTitle(Context lllllllllllllllIlllIIIlIIIIIlIIl, String lllllllllllllllIlllIIIlIIIIIlIII, boolean lllllllllllllllIlllIIIlIIIIIIlll, boolean lllllllllllllllIlllIIIlIIIIIIllI) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 33
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: aload_2
      //   25: iload_3
      //   26: iload #4
      //   28: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
      //   33: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	34	0	lllllllllllllllIlllIIIlIIIIIlIlI	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	34	1	lllllllllllllllIlllIIIlIIIIIlIIl	Lcom/lukflug/panelstudio/Context;
      //   0	34	2	lllllllllllllllIlllIIIlIIIIIlIII	Ljava/lang/String;
      //   0	34	3	lllllllllllllllIlllIIIlIIIIIIlll	Z
      //   0	34	4	lllllllllllllllIlllIIIlIIIIIIllI	Z
    }
    
    public void renderTitle(Context lllllllllllllllIlllIIIlIIIIIIlII, String lllllllllllllllIlllIIIlIIIIIIIll, boolean lllllllllllllllIlllIIIlIIIIIIIlI, boolean lllllllllllllllIlllIIIlIIIIIIIIl, boolean lllllllllllllllIlllIIIlIIIIIIIII) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 33
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: aload_2
      //   25: iload_3
      //   26: iload #5
      //   28: <illegal opcode> 11 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZ)V
      //   33: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	34	0	lllllllllllllllIlllIIIlIIIIIIlIl	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	34	1	lllllllllllllllIlllIIIlIIIIIIlII	Lcom/lukflug/panelstudio/Context;
      //   0	34	2	lllllllllllllllIlllIIIlIIIIIIIll	Ljava/lang/String;
      //   0	34	3	lllllllllllllllIlllIIIlIIIIIIIlI	Z
      //   0	34	4	lllllllllllllllIlllIIIlIIIIIIIIl	Z
      //   0	34	5	lllllllllllllllIlllIIIlIIIIIIIII	Z
    }
    
    public void renderRect(Context lllllllllllllllIlllIIIIllllllllI, String lllllllllllllllIlllIIIIlllllllIl, boolean lllllllllllllllIlllIIIIlllllllII, boolean lllllllllllllllIlllIIIIllllllIll, Rectangle lllllllllllllllIlllIIIIllllllIlI, boolean lllllllllllllllIlllIIIIllllllIIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 37
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: aload_2
      //   25: iload_3
      //   26: iload #4
      //   28: aload #5
      //   30: iload #6
      //   32: <illegal opcode> 12 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Ljava/lang/String;ZZLjava/awt/Rectangle;Z)V
      //   37: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	38	0	lllllllllllllllIlllIIIIlllllllll	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	38	1	lllllllllllllllIlllIIIIllllllllI	Lcom/lukflug/panelstudio/Context;
      //   0	38	2	lllllllllllllllIlllIIIIlllllllIl	Ljava/lang/String;
      //   0	38	3	lllllllllllllllIlllIIIIlllllllII	Z
      //   0	38	4	lllllllllllllllIlllIIIIllllllIll	Z
      //   0	38	5	lllllllllllllllIlllIIIIllllllIlI	Ljava/awt/Rectangle;
      //   0	38	6	lllllllllllllllIlllIIIIllllllIIl	Z
    }
    
    public void renderBackground(Context lllllllllllllllIlllIIIIlllllIlll, boolean lllllllllllllllIlllIIIIlllllIllI) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 30
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: iload_2
      //   25: <illegal opcode> 13 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;Z)V
      //   30: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	31	0	lllllllllllllllIlllIIIIllllllIII	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	31	1	lllllllllllllllIlllIIIIlllllIlll	Lcom/lukflug/panelstudio/Context;
      //   0	31	2	lllllllllllllllIlllIIIIlllllIllI	Z
    }
    
    public void renderBorder(Context lllllllllllllllIlllIIIIlllllIlII, boolean lllllllllllllllIlllIIIIlllllIIll, boolean lllllllllllllllIlllIIIIlllllIIlI, boolean lllllllllllllllIlllIIIIlllllIIIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 33
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: iload_2
      //   25: iload_3
      //   26: iload #4
      //   28: <illegal opcode> 14 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;ZZZ)V
      //   33: return
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	34	0	lllllllllllllllIlllIIIIlllllIlIl	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	34	1	lllllllllllllllIlllIIIIlllllIlII	Lcom/lukflug/panelstudio/Context;
      //   0	34	2	lllllllllllllllIlllIIIIlllllIIll	Z
      //   0	34	3	lllllllllllllllIlllIIIIlllllIIlI	Z
      //   0	34	4	lllllllllllllllIlllIIIIlllllIIIl	Z
    }
    
    public int renderScrollBar(Context lllllllllllllllIlllIIIIllllIllll, boolean lllllllllllllllIlllIIIIllllIlllI, boolean lllllllllllllllIlllIIIIllllIllIl, boolean lllllllllllllllIlllIIIIllllIllII, int lllllllllllllllIlllIIIIllllIlIll, int lllllllllllllllIlllIIIIllllIlIlI) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 38
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: aload_1
      //   24: iload_2
      //   25: iload_3
      //   26: iload #4
      //   28: iload #5
      //   30: iload #6
      //   32: <illegal opcode> 15 : (Lcom/lukflug/panelstudio/theme/Renderer;Lcom/lukflug/panelstudio/Context;ZZZII)I
      //   37: ireturn
      //   38: iload #6
      //   40: ireturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	41	0	lllllllllllllllIlllIIIIlllllIIII	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	41	1	lllllllllllllllIlllIIIIllllIllll	Lcom/lukflug/panelstudio/Context;
      //   0	41	2	lllllllllllllllIlllIIIIllllIlllI	Z
      //   0	41	3	lllllllllllllllIlllIIIIllllIllIl	Z
      //   0	41	4	lllllllllllllllIlllIIIIllllIllII	Z
      //   0	41	5	lllllllllllllllIlllIIIIllllIlIll	I
      //   0	41	6	lllllllllllllllIlllIIIIllllIlIlI	I
    }
    
    public Color getMainColor(boolean lllllllllllllllIlllIIIIllllIlIII, boolean lllllllllllllllIlllIIIIllllIIlll) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 31
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: iload_1
      //   24: iload_2
      //   25: <illegal opcode> 16 : (Lcom/lukflug/panelstudio/theme/Renderer;ZZ)Ljava/awt/Color;
      //   30: areturn
      //   31: new java/awt/Color
      //   34: dup
      //   35: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   38: iconst_0
      //   39: iaload
      //   40: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   43: iconst_0
      //   44: iaload
      //   45: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   48: iconst_0
      //   49: iaload
      //   50: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   53: iconst_0
      //   54: iaload
      //   55: invokespecial <init> : (IIII)V
      //   58: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	59	0	lllllllllllllllIlllIIIIllllIlIIl	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	59	1	lllllllllllllllIlllIIIIllllIlIII	Z
      //   0	59	2	lllllllllllllllIlllIIIIllllIIlll	Z
    }
    
    public Color getBackgroundColor(boolean lllllllllllllllIlllIIIIllllIIlIl) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 30
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: iload_1
      //   24: <illegal opcode> 17 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)Ljava/awt/Color;
      //   29: areturn
      //   30: new java/awt/Color
      //   33: dup
      //   34: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   37: iconst_0
      //   38: iaload
      //   39: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   42: iconst_0
      //   43: iaload
      //   44: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   47: iconst_0
      //   48: iaload
      //   49: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   52: iconst_0
      //   53: iaload
      //   54: invokespecial <init> : (IIII)V
      //   57: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	58	0	lllllllllllllllIlllIIIIllllIIllI	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	58	1	lllllllllllllllIlllIIIIllllIIlIl	Z
    }
    
    public Color getFontColor(boolean lllllllllllllllIlllIIIIllllIIIll) {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/settings/Toggleable;
      //   6: <illegal opcode> 9 : (Lcom/lukflug/panelstudio/settings/Toggleable;)Z
      //   11: invokestatic llllllllllIlIlI : (I)Z
      //   14: ifeq -> 30
      //   17: aload_0
      //   18: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   23: iload_1
      //   24: <illegal opcode> 18 : (Lcom/lukflug/panelstudio/theme/Renderer;Z)Ljava/awt/Color;
      //   29: areturn
      //   30: new java/awt/Color
      //   33: dup
      //   34: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   37: iconst_0
      //   38: iaload
      //   39: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   42: iconst_0
      //   43: iaload
      //   44: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   47: iconst_0
      //   48: iaload
      //   49: getstatic com/lukflug/panelstudio/hud/HUDPanel$HUDRenderer.lIlllllIlIllII : [I
      //   52: iconst_0
      //   53: iaload
      //   54: invokespecial <init> : (IIII)V
      //   57: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	58	0	lllllllllllllllIlllIIIIllllIIlII	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
      //   0	58	1	lllllllllllllllIlllIIIIllllIIIll	Z
    }
    
    protected Renderer getRenderer() {
      // Byte code:
      //   0: aload_0
      //   1: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;)Lcom/lukflug/panelstudio/theme/Renderer;
      //   6: areturn
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	7	0	lllllllllllllllIlllIIIIllllIIIlI	Lcom/lukflug/panelstudio/hud/HUDPanel$HUDRenderer;
    }
    
    static {
      llllllllllIlIIl();
      llllllllllIIlII();
      llllllllllIIIll();
      lllllllllIlllll();
    }
    
    private static CallSite lllllllllIllllI(MethodHandles.Lookup lllllllllllllllIlllIIIIlllIllIIl, String lllllllllllllllIlllIIIIlllIllIII, MethodType lllllllllllllllIlllIIIIlllIlIlll) throws NoSuchMethodException, IllegalAccessException {
      try {
        String[] lllllllllllllllIlllIIIIlllIlllll = lIlllllIlIIlll[Integer.parseInt(lllllllllllllllIlllIIIIlllIllIII)].split(lIlllllIlIlIIl[lIlllllIlIllII[0]]);
        Class<?> lllllllllllllllIlllIIIIlllIllllI = Class.forName(lllllllllllllllIlllIIIIlllIlllll[lIlllllIlIllII[0]]);
        String lllllllllllllllIlllIIIIlllIlllIl = lllllllllllllllIlllIIIIlllIlllll[lIlllllIlIllII[1]];
        MethodHandle lllllllllllllllIlllIIIIlllIlllII = null;
        int lllllllllllllllIlllIIIIlllIllIll = lllllllllllllllIlllIIIIlllIlllll[lIlllllIlIllII[2]].length();
        if (llllllllllIlIll(lllllllllllllllIlllIIIIlllIllIll, lIlllllIlIllII[3])) {
          MethodType lllllllllllllllIlllIIIIllllIIIIl = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIIlllIlllll[lIlllllIlIllII[3]], HUDRenderer.class.getClassLoader());
          if (llllllllllIllII(lllllllllllllllIlllIIIIlllIllIll, lIlllllIlIllII[3])) {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findVirtual(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIIl);
            "".length();
            if ((" ".length() << (0x4 ^ 0x4D ^ (0xBB ^ 0xA8) << " ".length() << " ".length()) & (" ".length() << ((0x1E ^ 0x33) << " ".length() ^ 0x7C ^ 0x23) ^ -" ".length())) == -" ".length())
              return null; 
          } else {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findStatic(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIIl);
          } 
          "".length();
          if ("   ".length() <= 0)
            return null; 
        } else {
          Class<?> lllllllllllllllIlllIIIIllllIIIII = lIlllllIlIlIII[Integer.parseInt(lllllllllllllllIlllIIIIlllIlllll[lIlllllIlIllII[3]])];
          if (llllllllllIllII(lllllllllllllllIlllIIIIlllIllIll, lIlllllIlIllII[2])) {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findGetter(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIII);
            "".length();
            if (" ".length() >= "   ".length())
              return null; 
          } else if (llllllllllIllII(lllllllllllllllIlllIIIIlllIllIll, lIlllllIlIllII[4])) {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findStaticGetter(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIII);
            "".length();
            if (" ".length() << " ".length() == 0)
              return null; 
          } else if (llllllllllIllII(lllllllllllllllIlllIIIIlllIllIll, lIlllllIlIllII[5])) {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findSetter(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIII);
            "".length();
            if (((82 + 136 - 47 + 4 ^ (0x69 ^ 0x40) << " ".length() << " ".length()) & ((0x79 ^ 0x1E) << " ".length() ^ 95 + 181 - 224 + 145 ^ -" ".length())) != 0)
              return null; 
          } else {
            lllllllllllllllIlllIIIIlllIlllII = lllllllllllllllIlllIIIIlllIllIIl.findStaticSetter(lllllllllllllllIlllIIIIlllIllllI, lllllllllllllllIlllIIIIlllIlllIl, lllllllllllllllIlllIIIIllllIIIII);
          } 
        } 
        return new ConstantCallSite(lllllllllllllllIlllIIIIlllIlllII);
      } catch (Exception lllllllllllllllIlllIIIIlllIllIlI) {
        lllllllllllllllIlllIIIIlllIllIlI.printStackTrace();
        return null;
      } 
    }
    
    private static void lllllllllIlllll() {
      lIlllllIlIIlll = new String[lIlllllIlIllII[6]];
      lIlllllIlIIlll[lIlllllIlIllII[7]] = lIlllllIlIlIIl[lIlllllIlIllII[1]];
      lIlllllIlIIlll[lIlllllIlIllII[8]] = lIlllllIlIlIIl[lIlllllIlIllII[3]];
      lIlllllIlIIlll[lIlllllIlIllII[9]] = lIlllllIlIlIIl[lIlllllIlIllII[2]];
      lIlllllIlIIlll[lIlllllIlIllII[4]] = lIlllllIlIlIIl[lIlllllIlIllII[4]];
      lIlllllIlIIlll[lIlllllIlIllII[10]] = lIlllllIlIlIIl[lIlllllIlIllII[5]];
      lIlllllIlIIlll[lIlllllIlIllII[11]] = lIlllllIlIlIIl[lIlllllIlIllII[12]];
      lIlllllIlIIlll[lIlllllIlIllII[13]] = lIlllllIlIlIIl[lIlllllIlIllII[9]];
      lIlllllIlIIlll[lIlllllIlIllII[14]] = lIlllllIlIlIIl[lIlllllIlIllII[15]];
      lIlllllIlIIlll[lIlllllIlIllII[0]] = lIlllllIlIlIIl[lIlllllIlIllII[7]];
      lIlllllIlIIlll[lIlllllIlIllII[1]] = lIlllllIlIlIIl[lIlllllIlIllII[8]];
      lIlllllIlIIlll[lIlllllIlIllII[3]] = lIlllllIlIlIIl[lIlllllIlIllII[16]];
      lIlllllIlIIlll[lIlllllIlIllII[15]] = lIlllllIlIlIIl[lIlllllIlIllII[14]];
      lIlllllIlIIlll[lIlllllIlIllII[12]] = lIlllllIlIlIIl[lIlllllIlIllII[17]];
      lIlllllIlIIlll[lIlllllIlIllII[17]] = lIlllllIlIlIIl[lIlllllIlIllII[18]];
      lIlllllIlIIlll[lIlllllIlIllII[5]] = lIlllllIlIlIIl[lIlllllIlIllII[19]];
      lIlllllIlIIlll[lIlllllIlIllII[19]] = lIlllllIlIlIIl[lIlllllIlIllII[11]];
      lIlllllIlIIlll[lIlllllIlIllII[18]] = lIlllllIlIlIIl[lIlllllIlIllII[13]];
      lIlllllIlIIlll[lIlllllIlIllII[16]] = lIlllllIlIlIIl[lIlllllIlIllII[10]];
      lIlllllIlIIlll[lIlllllIlIllII[2]] = lIlllllIlIlIIl[lIlllllIlIllII[6]];
      lIlllllIlIlIII = new Class[lIlllllIlIllII[2]];
      lIlllllIlIlIII[lIlllllIlIllII[0]] = Renderer.class;
      lIlllllIlIlIII[lIlllllIlIllII[3]] = int.class;
      lIlllllIlIlIII[lIlllllIlIllII[1]] = Toggleable.class;
    }
    
    private static void llllllllllIIIll() {
      lIlllllIlIlIIl = new String[lIlllllIlIllII[20]];
      lIlllllIlIlIIl[lIlllllIlIllII[0]] = llllllllllIIIII(lIlllllIlIlIlI[lIlllllIlIllII[0]], lIlllllIlIlIlI[lIlllllIlIllII[1]]);
      lIlllllIlIlIIl[lIlllllIlIllII[1]] = llllllllllIIIII(lIlllllIlIlIlI[lIlllllIlIllII[3]], lIlllllIlIlIlI[lIlllllIlIllII[2]]);
      lIlllllIlIlIIl[lIlllllIlIllII[3]] = llllllllllIIIIl(lIlllllIlIlIlI[lIlllllIlIllII[4]], lIlllllIlIlIlI[lIlllllIlIllII[5]]);
      lIlllllIlIlIIl[lIlllllIlIllII[2]] = llllllllllIIIlI(lIlllllIlIlIlI[lIlllllIlIllII[12]], lIlllllIlIlIlI[lIlllllIlIllII[9]]);
      lIlllllIlIlIIl[lIlllllIlIllII[4]] = llllllllllIIIlI(lIlllllIlIlIlI[lIlllllIlIllII[15]], lIlllllIlIlIlI[lIlllllIlIllII[7]]);
      lIlllllIlIlIIl[lIlllllIlIllII[5]] = llllllllllIIIII("7WPEMqrYP/eIBASeezT4IkBczBmuos/Nl4Jzk/pBKCnioWFeD/FUuSVY5WILfgnD8V2FvrEHo6XitAi96uhEtoN/fXPvrcindmhfzPfqIQ4=", "mCfel");
      lIlllllIlIlIIl[lIlllllIlIllII[12]] = llllllllllIIIlI("5NdBP8zH/tMQMnHVayjN4tf8In2NlYiAsyi2M0NJIWuOI8JZQLCBbbzHUsSwC5qJrq6OPY74RYayqFQK7T9wfE5wq80zq/ZhjusHxt8SXXA=", "ywMtH");
      lIlllllIlIlIIl[lIlllllIlIllII[9]] = llllllllllIIIII("mVWCN/N3bW4l5xmbU8FKYUU6PcwbsfXIRTiyn5Vi9dfa8diELHOBVTsZRP8Anrd6uliXEH1eMrszA20ERjUO2aVbaqNOOwOCnZYX7cyAWA5+TZY0MMO+6A==", "rCIsr");
      lIlllllIlIlIIl[lIlllllIlIllII[15]] = llllllllllIIIII("PGFeNeRIToTSAtvYi3/i7ie9K3sss5LnZPZOiGF1n6+GN6hbeUZuyXVDJm9qZ3N/hBXE/mrWz5l3NhE9ica4ZFr0M0NTmXq6EkfK/QWl80uk26y/xgGcHES47EZoy611roFiqzhCmfZ1LnbsOR1a4oAijUoPLwl7IEPZlUIWahhlTY1Fq1eLog==", "oIEPF");
      lIlllllIlIlIIl[lIlllllIlIllII[7]] = llllllllllIIIlI("ah405zNWVS2JMdiwftDpKhB4M96vKXcvtROkj1y9nUaGuUFoxbzAT0R8wEY93z81RXqKDpylcqvGDEkYj/pKjdyXkYwUbv6D", "dghlu");
      lIlllllIlIlIIl[lIlllllIlIllII[8]] = llllllllllIIIlI("7t+baoOeyhmmaJgeS1kNbn6EyG/LkT0yFm1IsW7yMFQji5hwpEnSbCGS57cgzhgAAdV+qbTwuON4MzIdLIWNdEK6Q7deMOXU", "JbYdM");
      lIlllllIlIlIIl[lIlllllIlIllII[16]] = llllllllllIIIII("omrQlciFWNhCnEE42k+7p2i5dVjOD5iBVYtYdmgVjzhh/45VSPJAgrra5x0U7SfdPSQfGsTv2Nc7vxJtLznrLDfFBWQI7KdB", "qOirE");
      lIlllllIlIlIIl[lIlllllIlIllII[14]] = llllllllllIIIII("pskb73ZJsL2EhqED0CpM71ZcBxU8vjmBjmI11l8RtOugiMgrwj6yd3x0hWcDxLhDIKs4LUkhNJ8ISgDMlmwCXQ==", "kFevD");
      lIlllllIlIlIIl[lIlllllIlIllII[17]] = llllllllllIIIlI("t2dIj9Tv4W4SV1mv2UwwPvBji1iQoLYPimItu0Qau54=", "niJBU");
      lIlllllIlIlIIl[lIlllllIlIllII[18]] = llllllllllIIIIl("ITc7Wxo3MzAZAyV2JhQYJzQlAQMmMTlbAio9OxBYED04ERMwPSRPBCc2MhAEADk1HhEwNyMbEnhwGhYZL3c6AB0kNCMSWTI5OBAaMSwjER8tdxUaGDY9LgFNGHEAT1Zi", "BXVuv");
      lIlllllIlIlIIl[lIlllllIlIllII[19]] = llllllllllIIIII("WAt1lbIYCZgQskGTA4E9ouYx0/jMDM9fi18T4Pykt5o4lRSCCX60lqyQE754L4xoeUFVLQJzopUPF14pGxwsLDxpcXHASk33", "SIVNs");
      lIlllllIlIlIIl[lIlllllIlIllII[11]] = llllllllllIIIlI("2OIHC2u7lhA5cwNIP1znNDDxNdlttyFR7JWwKMzlT8gIrgB9Fi5L8YVCb1X3xfJY6+4um2Cmqo84DhEOSNUhC90NLilzj3GKy9HZ5RWhtKNuU+ebaYzSjSUxFOBN8DHxnHQlpCUXSLA=", "SuMLu");
      lIlllllIlIlIIl[lIlllllIlIllII[13]] = llllllllllIIIlI("ES0y5E89URByRaWIk9IwOU29OcGApxLk/FJK0D0jbjl1/xLsRTVA11txn9K1jVRMJxxm5LOE2nrSeQYJxDtRmIDGp5cRJYWGpAbKmYqw1OvGI4C5SeSND0CdX8ldEyJT", "phOsb");
      lIlllllIlIlIIl[lIlllllIlIllII[10]] = llllllllllIIIII("/yAGxeQRvRCnF240MJY7DTtwGAx/3me/jJvMlwMOhSu2MQcn3PDuaDgEfSXy7nM8VQmTjDS3jOpIjQWoCmMBhc68ckjzuGqvlr/VugiZKFFwploQRV9FC1dMZckvd7xLxry5q5452HT8xqeqoii3yA==", "ddJUE");
      lIlllllIlIlIIl[lIlllllIlIllII[6]] = llllllllllIIIIl("JQAgSxgzBCsJASFBPQQaIwM+EQEiBiJLHDMLYy0hAj8sCxEqSwUwMBQKIwERNAo/XwYjASkABiMdd1VOZk9t", "FoMet");
      lIlllllIlIlIlI = null;
    }
    
    private static void llllllllllIIlII() {
      String str = (new Exception()).getStackTrace()[lIlllllIlIllII[0]].getFileName();
      lIlllllIlIlIlI = str.substring(str.indexOf("ä") + lIlllllIlIllII[1], str.lastIndexOf("ü")).split("ö");
    }
    
    private static String llllllllllIIIII(String lllllllllllllllIlllIIIIlllIlIIll, String lllllllllllllllIlllIIIIlllIlIIlI) {
      try {
        SecretKeySpec lllllllllllllllIlllIIIIlllIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIlllIlIIlI.getBytes(StandardCharsets.UTF_8)), lIlllllIlIllII[15]), "DES");
        Cipher lllllllllllllllIlllIIIIlllIlIlIl = Cipher.getInstance("DES");
        lllllllllllllllIlllIIIIlllIlIlIl.init(lIlllllIlIllII[3], lllllllllllllllIlllIIIIlllIlIllI);
        return new String(lllllllllllllllIlllIIIIlllIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIlllIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIIIIlllIlIlII) {
        lllllllllllllllIlllIIIIlllIlIlII.printStackTrace();
        return null;
      } 
    }
    
    private static String llllllllllIIIIl(String lllllllllllllllIlllIIIIlllIlIIII, String lllllllllllllllIlllIIIIlllIIllll) {
      lllllllllllllllIlllIIIIlllIlIIII = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIIlllIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlllIIIIlllIIlllI = new StringBuilder();
      char[] lllllllllllllllIlllIIIIlllIIllIl = lllllllllllllllIlllIIIIlllIIllll.toCharArray();
      int lllllllllllllllIlllIIIIlllIIllII = lIlllllIlIllII[0];
      char[] arrayOfChar1 = lllllllllllllllIlllIIIIlllIlIIII.toCharArray();
      int i = arrayOfChar1.length;
      int j = lIlllllIlIllII[0];
      while (llllllllllIllIl(j, i)) {
        char lllllllllllllllIlllIIIIlllIlIIIl = arrayOfChar1[j];
        "".length();
        lllllllllllllllIlllIIIIlllIIllII++;
        j++;
        "".length();
        if ((("   ".length() << " ".length() ^ 0x86 ^ 0x91) & ((0x4B ^ 0x1E) << " ".length() ^ 161 + 28 - 64 + 62 ^ -" ".length())) != 0)
          return null; 
      } 
      return String.valueOf(lllllllllllllllIlllIIIIlllIIlllI);
    }
    
    private static String llllllllllIIIlI(String lllllllllllllllIlllIIIIlllIIlIII, String lllllllllllllllIlllIIIIlllIIIlll) {
      try {
        SecretKeySpec lllllllllllllllIlllIIIIlllIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIlllIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlllIIIIlllIIlIlI = Cipher.getInstance("Blowfish");
        lllllllllllllllIlllIIIIlllIIlIlI.init(lIlllllIlIllII[3], lllllllllllllllIlllIIIIlllIIlIll);
        return new String(lllllllllllllllIlllIIIIlllIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIlllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      } catch (Exception lllllllllllllllIlllIIIIlllIIlIIl) {
        lllllllllllllllIlllIIIIlllIIlIIl.printStackTrace();
        return null;
      } 
    }
    
    private static void llllllllllIlIIl() {
      lIlllllIlIllII = new int[21];
      lIlllllIlIllII[0] = (0x15 ^ 0x2) << " ".length() & ((0x58 ^ 0x4F) << " ".length() ^ 0xFFFFFFFF);
      lIlllllIlIllII[1] = " ".length();
      lIlllllIlIllII[2] = "   ".length();
      lIlllllIlIllII[3] = " ".length() << " ".length();
      lIlllllIlIllII[4] = " ".length() << " ".length() << " ".length();
      lIlllllIlIllII[5] = 0x8A ^ 0x8F;
      lIlllllIlIllII[6] = 0x39 ^ 0x2A;
      lIlllllIlIllII[7] = 0x99 ^ 0x88 ^ "   ".length() << "   ".length();
      lIlllllIlIllII[8] = ((0x73 ^ 0x12) << " ".length() ^ 159 + 198 - 214 + 56) << " ".length();
      lIlllllIlIllII[9] = (0x63 ^ 0x4E) << " ".length() ^ 0xD0 ^ 0x8D;
      lIlllllIlIllII[10] = ((0x29 ^ 0x10) << " ".length() ^ 0x1B ^ 0x60) << " ".length();
      lIlllllIlIllII[11] = " ".length() << " ".length() << " ".length() << " ".length();
      lIlllllIlIllII[12] = "   ".length() << " ".length();
      lIlllllIlIllII[13] = 0x64 ^ 0x75;
      lIlllllIlIllII[14] = "   ".length() << " ".length() << " ".length();
      lIlllllIlIllII[15] = " ".length() << "   ".length();
      lIlllllIlIllII[16] = 0x93 ^ 0x98;
      lIlllllIlIllII[17] = 0x39 ^ 0x34;
      lIlllllIlIllII[18] = ("   ".length() << " ".length() << " ".length() << " ".length() ^ 0xA4 ^ 0x93) << " ".length();
      lIlllllIlIllII[19] = "   ".length() << "   ".length() ^ 0xAE ^ 0xB9;
      lIlllllIlIllII[20] = ((0xB5 ^ 0xBC) << " ".length() << " ".length() ^ 0xBA ^ 0x9B) << " ".length() << " ".length();
    }
    
    private static boolean llllllllllIllII(int param1Int1, int param1Int2) {
      return (param1Int1 == param1Int2);
    }
    
    private static boolean llllllllllIllIl(int param1Int1, int param1Int2) {
      return (param1Int1 < param1Int2);
    }
    
    private static boolean llllllllllIlIll(int param1Int1, int param1Int2) {
      return (param1Int1 <= param1Int2);
    }
    
    private static boolean llllllllllIlIlI(int param1Int) {
      return (param1Int != 0);
    }
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\hud\HUDPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */