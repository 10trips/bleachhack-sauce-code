package com.lukflug.panelstudio.mc12;

import com.lukflug.panelstudio.ClickGUI;
import com.lukflug.panelstudio.hud.HUDClickGUI;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class MinecraftHUDGUI extends MinecraftGUI {
  protected boolean hudEditor;
  
  private static String[] lIlllllIIlllll;
  
  private static Class[] lIlllllIlIIIII;
  
  private static final String[] lIlllllIlIIIIl;
  
  private static String[] lIlllllIlIIIlI;
  
  private static final int[] lIlllllIlIIlII;
  
  public MinecraftHUDGUI() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: getstatic com/lukflug/panelstudio/mc12/MinecraftHUDGUI.lIlllllIlIIlII : [I
    //   8: iconst_0
    //   9: iaload
    //   10: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;Z)V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIIIlIIIllIlll	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  public void enterGUI() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/lukflug/panelstudio/mc12/MinecraftHUDGUI.lIlllllIlIIlII : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;Z)V
    //   11: aload_0
    //   12: invokespecial enterGUI : ()V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIIIlIIIllIllI	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  public void exitGUI() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/lukflug/panelstudio/mc12/MinecraftHUDGUI.lIlllllIlIIlII : [I
    //   4: iconst_0
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;Z)V
    //   11: aload_0
    //   12: invokespecial exitGUI : ()V
    //   15: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	16	0	lllllllllllllllIlllIIIlIIIllIlIl	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  public void enterHUDEditor() {
    // Byte code:
    //   0: aload_0
    //   1: getstatic com/lukflug/panelstudio/mc12/MinecraftHUDGUI.lIlllllIlIIlII : [I
    //   4: iconst_1
    //   5: iaload
    //   6: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;Z)V
    //   11: aload_0
    //   12: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   17: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;)Z
    //   22: invokestatic lllllllllIlIlll : (I)Z
    //   25: ifeq -> 39
    //   28: aload_0
    //   29: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   34: <illegal opcode> 3 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;)V
    //   39: <illegal opcode> 4 : ()Lnet/minecraft/client/Minecraft;
    //   44: aload_0
    //   45: <illegal opcode> 5 : (Lnet/minecraft/client/Minecraft;Lnet/minecraft/client/gui/GuiScreen;)V
    //   50: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	51	0	lllllllllllllllIlllIIIlIIIllIlII	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  public void render() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   6: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;)Z
    //   11: invokestatic lllllllllIllIII : (I)Z
    //   14: ifeq -> 35
    //   17: aload_0
    //   18: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Z
    //   23: invokestatic lllllllllIllIII : (I)Z
    //   26: ifeq -> 35
    //   29: aload_0
    //   30: <illegal opcode> 7 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)V
    //   35: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	36	0	lllllllllllllllIlllIIIlIIIllIIll	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  public void handleKeyEvent(int lllllllllllllllIlllIIIlIIIllIIIl) {
    // Byte code:
    //   0: iload_1
    //   1: getstatic com/lukflug/panelstudio/mc12/MinecraftHUDGUI.lIlllllIlIIlII : [I
    //   4: iconst_1
    //   5: iaload
    //   6: invokestatic lllllllllIllIIl : (II)Z
    //   9: ifeq -> 53
    //   12: aload_0
    //   13: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   18: <illegal opcode> 2 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;)Z
    //   23: invokestatic lllllllllIllIII : (I)Z
    //   26: ifeq -> 53
    //   29: aload_0
    //   30: <illegal opcode> 6 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Z
    //   35: invokestatic lllllllllIllIII : (I)Z
    //   38: ifeq -> 53
    //   41: aload_0
    //   42: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   47: iload_1
    //   48: <illegal opcode> 8 : (Lcom/lukflug/panelstudio/hud/HUDClickGUI;I)V
    //   53: return
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	54	0	lllllllllllllllIlllIIIlIIIllIIlI	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
    //   0	54	1	lllllllllllllllIlllIIIlIIIllIIIl	I
  }
  
  protected abstract HUDClickGUI getHUDGUI();
  
  protected ClickGUI getGUI() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;)Lcom/lukflug/panelstudio/hud/HUDClickGUI;
    //   6: areturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	7	0	lllllllllllllllIlllIIIlIIIllIIII	Lcom/lukflug/panelstudio/mc12/MinecraftHUDGUI;
  }
  
  static {
    lllllllllIlIllI();
    lllllllllIlIlIl();
    lllllllllIlIlII();
    lllllllllIlIIII();
  }
  
  private static CallSite lllllllllIIllll(MethodHandles.Lookup lllllllllllllllIlllIIIlIIIlIIlll, String lllllllllllllllIlllIIIlIIIlIIllI, MethodType lllllllllllllllIlllIIIlIIIlIIlIl) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIlllIIIlIIIlIllIl = lIlllllIIlllll[Integer.parseInt(lllllllllllllllIlllIIIlIIIlIIllI)].split(lIlllllIlIIIIl[lIlllllIlIIlII[0]]);
      Class<?> lllllllllllllllIlllIIIlIIIlIllII = Class.forName(lllllllllllllllIlllIIIlIIIlIllIl[lIlllllIlIIlII[0]]);
      String lllllllllllllllIlllIIIlIIIlIlIll = lllllllllllllllIlllIIIlIIIlIllIl[lIlllllIlIIlII[1]];
      MethodHandle lllllllllllllllIlllIIIlIIIlIlIlI = null;
      int lllllllllllllllIlllIIIlIIIlIlIIl = lllllllllllllllIlllIIIlIIIlIllIl[lIlllllIlIIlII[2]].length();
      if (lllllllllIllIlI(lllllllllllllllIlllIIIlIIIlIlIIl, lIlllllIlIIlII[3])) {
        MethodType lllllllllllllllIlllIIIlIIIlIllll = MethodType.fromMethodDescriptorString(lllllllllllllllIlllIIIlIIIlIllIl[lIlllllIlIIlII[3]], MinecraftHUDGUI.class.getClassLoader());
        if (lllllllllIllIll(lllllllllllllllIlllIIIlIIIlIlIIl, lIlllllIlIIlII[3])) {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findVirtual(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIllll);
          "".length();
          if (("   ".length() << "   ".length() & ("   ".length() << "   ".length() ^ 0xFFFFFFFF)) != 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findStatic(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIllll);
        } 
        "".length();
        if (-" ".length() > 0)
          return null; 
      } else {
        Class<?> lllllllllllllllIlllIIIlIIIlIlllI = lIlllllIlIIIII[Integer.parseInt(lllllllllllllllIlllIIIlIIIlIllIl[lIlllllIlIIlII[3]])];
        if (lllllllllIllIll(lllllllllllllllIlllIIIlIIIlIlIIl, lIlllllIlIIlII[2])) {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findGetter(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIlllI);
          "".length();
          if (" ".length() << " ".length() << " ".length() == 0)
            return null; 
        } else if (lllllllllIllIll(lllllllllllllllIlllIIIlIIIlIlIIl, lIlllllIlIIlII[4])) {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findStaticGetter(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIlllI);
          "".length();
          if (" ".length() < ((0xA ^ 0xD) << " ".length() << " ".length() & ((0x91 ^ 0x96) << " ".length() << " ".length() ^ 0xFFFFFFFF)))
            return null; 
        } else if (lllllllllIllIll(lllllllllllllllIlllIIIlIIIlIlIIl, lIlllllIlIIlII[5])) {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findSetter(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIlllI);
          "".length();
          if (" ".length() << " ".length() < 0)
            return null; 
        } else {
          lllllllllllllllIlllIIIlIIIlIlIlI = lllllllllllllllIlllIIIlIIIlIIlll.findStaticSetter(lllllllllllllllIlllIIIlIIIlIllII, lllllllllllllllIlllIIIlIIIlIlIll, lllllllllllllllIlllIIIlIIIlIlllI);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIlllIIIlIIIlIlIlI);
    } catch (Exception lllllllllllllllIlllIIIlIIIlIlIII) {
      lllllllllllllllIlllIIIlIIIlIlIII.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllllIlIIII() {
    lIlllllIIlllll = new String[lIlllllIlIIlII[6]];
    lIlllllIIlllll[lIlllllIlIIlII[7]] = lIlllllIlIIIIl[lIlllllIlIIlII[1]];
    lIlllllIIlllll[lIlllllIlIIlII[3]] = lIlllllIlIIIIl[lIlllllIlIIlII[3]];
    lIlllllIIlllll[lIlllllIlIIlII[8]] = lIlllllIlIIIIl[lIlllllIlIIlII[2]];
    lIlllllIIlllll[lIlllllIlIIlII[4]] = lIlllllIlIIIIl[lIlllllIlIIlII[4]];
    lIlllllIIlllll[lIlllllIlIIlII[0]] = lIlllllIlIIIIl[lIlllllIlIIlII[5]];
    lIlllllIIlllll[lIlllllIlIIlII[2]] = lIlllllIlIIIIl[lIlllllIlIIlII[9]];
    lIlllllIIlllll[lIlllllIlIIlII[5]] = lIlllllIlIIIIl[lIlllllIlIIlII[7]];
    lIlllllIIlllll[lIlllllIlIIlII[1]] = lIlllllIlIIIIl[lIlllllIlIIlII[8]];
    lIlllllIIlllll[lIlllllIlIIlII[9]] = lIlllllIlIIIIl[lIlllllIlIIlII[6]];
    lIlllllIlIIIII = new Class[lIlllllIlIIlII[1]];
    lIlllllIlIIIII[lIlllllIlIIlII[0]] = boolean.class;
  }
  
  private static void lllllllllIlIlII() {
    lIlllllIlIIIIl = new String[lIlllllIlIIlII[10]];
    lIlllllIlIIIIl[lIlllllIlIIlII[0]] = lllllllllIlIIIl(lIlllllIlIIIlI[lIlllllIlIIlII[0]], lIlllllIlIIIlI[lIlllllIlIIlII[1]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[1]] = lllllllllIlIIlI(lIlllllIlIIIlI[lIlllllIlIIlII[3]], lIlllllIlIIIlI[lIlllllIlIIlII[2]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[3]] = lllllllllIlIIll(lIlllllIlIIIlI[lIlllllIlIIlII[4]], lIlllllIlIIIlI[lIlllllIlIIlII[5]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[2]] = lllllllllIlIIIl(lIlllllIlIIIlI[lIlllllIlIIlII[9]], lIlllllIlIIIlI[lIlllllIlIIlII[7]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[4]] = lllllllllIlIIll(lIlllllIlIIIlI[lIlllllIlIIlII[8]], lIlllllIlIIIlI[lIlllllIlIIlII[6]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[5]] = lllllllllIlIIll(lIlllllIlIIIlI[lIlllllIlIIlII[10]], lIlllllIlIIIlI[lIlllllIlIIlII[11]]);
    lIlllllIlIIIIl[lIlllllIlIIlII[9]] = lllllllllIlIIlI("ZGYLRU6cZR6UGNlgYuCqhlun6Pl1Rleu8ZXaAMr+SIFZmfPwsvGw8x1oRGP4cEsZR+dkC3PhD5w=", "MaxaB");
    lIlllllIlIIIIl[lIlllllIlIIlII[7]] = lllllllllIlIIlI("4xlRwAhDTaEw81uXl92MUgJuml+SbNZvtKko9naxesODUS4Ol/f00BamCuogKbh/GIsTusOnXgyZBCH9Q8M9xSrgdlmA9zTBS0DRVdML6+pyZOhSjyB1hA==", "cfGLv");
    lIlllllIlIIIIl[lIlllllIlIIlII[8]] = lllllllllIlIIIl("XWYIXFcuqi6xYIz9kFCj81q8g64aCbHVgGEXQG3J3TL1/pa9Icn7GSCjj7Lsf/kXaLHFVtMBUkJTni2fTz9YkBl6LHMq71VZyqO4Jzwtggu3YQNStsu3nKWfPYtbuYF74Fpp+hiB1IQ=", "LNitx");
    lIlllllIlIIIIl[lIlllllIlIIlII[6]] = lllllllllIlIIll("JTk4ZDgzPTMmISF4JSs6IzomPiEiPzpkOSVnZ2QZLzgwKSYnMCECAQIRAANuLiMxDzAvIjo4bnZsdWp0", "FVUJT");
    lIlllllIlIIIlI = null;
  }
  
  private static void lllllllllIlIlIl() {
    String str = (new Exception()).getStackTrace()[lIlllllIlIIlII[0]].getFileName();
    lIlllllIlIIIlI = str.substring(str.indexOf("ä") + lIlllllIlIIlII[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String lllllllllIlIIIl(String lllllllllllllllIlllIIIlIIIlIIIIl, String lllllllllllllllIlllIIIlIIIlIIIII) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIIIlIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIIIlIIIII.getBytes(StandardCharsets.UTF_8)), lIlllllIlIIlII[8]), "DES");
      Cipher lllllllllllllllIlllIIIlIIIlIIIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIIlIIIlIIIll.init(lIlllllIlIIlII[3], lllllllllllllllIlllIIIlIIIlIIlII);
      return new String(lllllllllllllllIlllIIIlIIIlIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIIIlIIIlI) {
      lllllllllllllllIlllIIIlIIIlIIIlI.printStackTrace();
      return null;
    } 
  }
  
  private static String lllllllllIlIIll(String lllllllllllllllIlllIIIlIIIIllllI, String lllllllllllllllIlllIIIlIIIIlllIl) {
    lllllllllllllllIlllIIIlIIIIllllI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIlIIIIlllII = new StringBuilder();
    char[] lllllllllllllllIlllIIIlIIIIllIll = lllllllllllllllIlllIIIlIIIIlllIl.toCharArray();
    int lllllllllllllllIlllIIIlIIIIllIlI = lIlllllIlIIlII[0];
    char[] arrayOfChar1 = lllllllllllllllIlllIIIlIIIIllllI.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIlllllIlIIlII[0];
    while (lllllllllIlllII(j, i)) {
      char lllllllllllllllIlllIIIlIIIIlllll = arrayOfChar1[j];
      "".length();
      lllllllllllllllIlllIIIlIIIIllIlI++;
      j++;
      "".length();
      if (null != null)
        return null; 
    } 
    return String.valueOf(lllllllllllllllIlllIIIlIIIIlllII);
  }
  
  private static String lllllllllIlIIlI(String lllllllllllllllIlllIIIlIIIIlIllI, String lllllllllllllllIlllIIIlIIIIlIlIl) {
    try {
      SecretKeySpec lllllllllllllllIlllIIIlIIIIllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIIIIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIlIIIIllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIlIIIIllIII.init(lIlllllIlIIlII[3], lllllllllllllllIlllIIIlIIIIllIIl);
      return new String(lllllllllllllllIlllIIIlIIIIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIlllIIIlIIIIlIlll) {
      lllllllllllllllIlllIIIlIIIIlIlll.printStackTrace();
      return null;
    } 
  }
  
  private static void lllllllllIlIllI() {
    lIlllllIlIIlII = new int[12];
    lIlllllIlIIlII[0] = (0x85 ^ 0xC4) & (0x81 ^ 0xC0 ^ 0xFFFFFFFF);
    lIlllllIlIIlII[1] = " ".length();
    lIlllllIlIIlII[2] = "   ".length();
    lIlllllIlIIlII[3] = " ".length() << " ".length();
    lIlllllIlIIlII[4] = " ".length() << " ".length() << " ".length();
    lIlllllIlIIlII[5] = 0xC4 ^ 0xC1;
    lIlllllIlIIlII[6] = 43 + 103 - 46 + 105 ^ (0x39 ^ 0x8) << " ".length() << " ".length();
    lIlllllIlIIlII[7] = 0x2B ^ 0x2C;
    lIlllllIlIIlII[8] = " ".length() << "   ".length();
    lIlllllIlIIlII[9] = "   ".length() << " ".length();
    lIlllllIlIIlII[10] = (0xB3 ^ 0xB6) << " ".length();
    lIlllllIlIIlII[11] = 0x34 ^ 0x3F;
  }
  
  private static boolean lllllllllIllIll(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean lllllllllIlllII(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean lllllllllIllIlI(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
  
  private static boolean lllllllllIlIlll(int paramInt) {
    return (paramInt != 0);
  }
  
  private static boolean lllllllllIllIII(int paramInt) {
    return (paramInt == 0);
  }
  
  private static boolean lllllllllIllIIl(int paramInt1, int paramInt2) {
    return (paramInt1 != paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\mc12\MinecraftHUDGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */