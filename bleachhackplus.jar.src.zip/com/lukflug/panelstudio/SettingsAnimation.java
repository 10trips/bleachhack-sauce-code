package com.lukflug.panelstudio;

import com.lukflug.panelstudio.settings.NumberSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class SettingsAnimation extends Animation {
  protected final NumberSetting speed;
  
  private static String[] lIllIllIllIIlI;
  
  private static Class[] lIllIllIllIIll;
  
  private static final String[] lIllIllIllIlII;
  
  private static String[] lIllIllIllIlIl;
  
  private static final int[] lIllIllIllIllI;
  
  public SettingsAnimation(NumberSetting lllllllllllllllIllllIIlIlIlIIlll) {
    this.speed = lllllllllllllllIllllIIlIlIlIIlll;
  }
  
  protected int getSpeed() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> 0 : (Lcom/lukflug/panelstudio/SettingsAnimation;)Lcom/lukflug/panelstudio/settings/NumberSetting;
    //   6: <illegal opcode> 1 : (Lcom/lukflug/panelstudio/settings/NumberSetting;)D
    //   11: d2i
    //   12: ireturn
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   0	13	0	lllllllllllllllIllllIIlIlIlIIllI	Lcom/lukflug/panelstudio/SettingsAnimation;
  }
  
  static {
    llllIlIllIllllI();
    llllIlIllIlllIl();
    llllIlIllIlllII();
    llllIlIllIllIIl();
  }
  
  private static CallSite llllIlIllIllIII(MethodHandles.Lookup lllllllllllllllIllllIIlIlIIlllIl, String lllllllllllllllIllllIIlIlIIlllII, MethodType lllllllllllllllIllllIIlIlIIllIll) throws NoSuchMethodException, IllegalAccessException {
    try {
      String[] lllllllllllllllIllllIIlIlIlIIIll = lIllIllIllIIlI[Integer.parseInt(lllllllllllllllIllllIIlIlIIlllII)].split(lIllIllIllIlII[lIllIllIllIllI[0]]);
      Class<?> lllllllllllllllIllllIIlIlIlIIIlI = Class.forName(lllllllllllllllIllllIIlIlIlIIIll[lIllIllIllIllI[0]]);
      String lllllllllllllllIllllIIlIlIlIIIIl = lllllllllllllllIllllIIlIlIlIIIll[lIllIllIllIllI[1]];
      MethodHandle lllllllllllllllIllllIIlIlIlIIIII = null;
      int lllllllllllllllIllllIIlIlIIlllll = lllllllllllllllIllllIIlIlIlIIIll[lIllIllIllIllI[2]].length();
      if (llllIlIllIlllll(lllllllllllllllIllllIIlIlIIlllll, lIllIllIllIllI[3])) {
        MethodType lllllllllllllllIllllIIlIlIlIIlIl = MethodType.fromMethodDescriptorString(lllllllllllllllIllllIIlIlIlIIIll[lIllIllIllIllI[3]], SettingsAnimation.class.getClassLoader());
        if (llllIlIlllIIIII(lllllllllllllllIllllIIlIlIIlllll, lIllIllIllIllI[3])) {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findVirtual(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlIl);
          "".length();
          if (((" ".length() << " ".length() << " ".length() ^ 0x37 ^ 0x12) & ((0xB9 ^ 0xA6) << " ".length() ^ 0x4C ^ 0x53 ^ -" ".length())) != (((0xF1 ^ 0xB4) << " ".length() ^ 122 + 158 - 119 + 10) & ((0xB0 ^ 0x97) << " ".length() << " ".length() ^ 171 + 161 - 205 + 62 ^ -" ".length())))
            return null; 
        } else {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findStatic(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlIl);
        } 
        "".length();
        if (" ".length() << " ".length() << " ".length() == (((0x8C ^ 0xC1) << " ".length() ^ 69 + 62 - 113 + 171) << " ".length() & ((0x99 ^ 0xA8 ^ (0x48 ^ 0x43) << " ".length()) << " ".length() ^ -" ".length())))
          return null; 
      } else {
        Class<?> lllllllllllllllIllllIIlIlIlIIlII = lIllIllIllIIll[Integer.parseInt(lllllllllllllllIllllIIlIlIlIIIll[lIllIllIllIllI[3]])];
        if (llllIlIlllIIIII(lllllllllllllllIllllIIlIlIIlllll, lIllIllIllIllI[2])) {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findGetter(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlII);
          "".length();
          if (" ".length() << " ".length() << " ".length() > " ".length() << " ".length() << " ".length())
            return null; 
        } else if (llllIlIlllIIIII(lllllllllllllllIllllIIlIlIIlllll, lIllIllIllIllI[4])) {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findStaticGetter(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlII);
          "".length();
          if ("   ".length() == 0)
            return null; 
        } else if (llllIlIlllIIIII(lllllllllllllllIllllIIlIlIIlllll, lIllIllIllIllI[5])) {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findSetter(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlII);
          "".length();
          if ("   ".length() <= -" ".length())
            return null; 
        } else {
          lllllllllllllllIllllIIlIlIlIIIII = lllllllllllllllIllllIIlIlIIlllIl.findStaticSetter(lllllllllllllllIllllIIlIlIlIIIlI, lllllllllllllllIllllIIlIlIlIIIIl, lllllllllllllllIllllIIlIlIlIIlII);
        } 
      } 
      return new ConstantCallSite(lllllllllllllllIllllIIlIlIlIIIII);
    } catch (Exception lllllllllllllllIllllIIlIlIIllllI) {
      lllllllllllllllIllllIIlIlIIllllI.printStackTrace();
      return null;
    } 
  }
  
  private static void llllIlIllIllIIl() {
    lIllIllIllIIlI = new String[lIllIllIllIllI[3]];
    lIllIllIllIIlI[lIllIllIllIllI[1]] = lIllIllIllIlII[lIllIllIllIllI[1]];
    lIllIllIllIIlI[lIllIllIllIllI[0]] = lIllIllIllIlII[lIllIllIllIllI[3]];
    lIllIllIllIIll = new Class[lIllIllIllIllI[1]];
    lIllIllIllIIll[lIllIllIllIllI[0]] = NumberSetting.class;
  }
  
  private static void llllIlIllIlllII() {
    lIllIllIllIlII = new String[lIllIllIllIllI[2]];
    lIllIllIllIlII[lIllIllIllIllI[0]] = llllIlIllIllIlI(lIllIllIllIlIl[lIllIllIllIllI[0]], lIllIllIllIlIl[lIllIllIllIllI[1]]);
    lIllIllIllIlII[lIllIllIllIllI[1]] = llllIlIllIllIlI(lIllIllIllIlIl[lIllIllIllIllI[3]], lIllIllIllIlIl[lIllIllIllIllI[2]]);
    lIllIllIllIlII[lIllIllIllIllI[3]] = llllIlIllIllIll(lIllIllIllIlIl[lIllIllIllIllI[4]], lIllIllIllIlIl[lIllIllIllIllI[5]]);
    lIllIllIllIlIl = null;
  }
  
  private static void llllIlIllIlllIl() {
    String str = (new Exception()).getStackTrace()[lIllIllIllIllI[0]].getFileName();
    lIllIllIllIlIl = str.substring(str.indexOf("ä") + lIllIllIllIllI[1], str.lastIndexOf("ü")).split("ö");
  }
  
  private static String llllIlIllIllIll(String lllllllllllllllIllllIIlIlIIlIlll, String lllllllllllllllIllllIIlIlIIlIllI) {
    try {
      SecretKeySpec lllllllllllllllIllllIIlIlIIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIlIlIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIlIlIIllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIlIlIIllIIl.init(lIllIllIllIllI[3], lllllllllllllllIllllIIlIlIIllIlI);
      return new String(lllllllllllllllIllllIIlIlIIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIlIlIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    } catch (Exception lllllllllllllllIllllIIlIlIIllIII) {
      lllllllllllllllIllllIIlIlIIllIII.printStackTrace();
      return null;
    } 
  }
  
  private static String llllIlIllIllIlI(String lllllllllllllllIllllIIlIlIIlIlII, String lllllllllllllllIllllIIlIlIIlIIll) {
    lllllllllllllllIllllIIlIlIIlIlII = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIlIlIIlIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIlIlIIlIIlI = new StringBuilder();
    char[] lllllllllllllllIllllIIlIlIIlIIIl = lllllllllllllllIllllIIlIlIIlIIll.toCharArray();
    int lllllllllllllllIllllIIlIlIIlIIII = lIllIllIllIllI[0];
    char[] arrayOfChar1 = lllllllllllllllIllllIIlIlIIlIlII.toCharArray();
    int i = arrayOfChar1.length;
    int j = lIllIllIllIllI[0];
    while (llllIlIlllIIIIl(j, i)) {
      char lllllllllllllllIllllIIlIlIIlIlIl = arrayOfChar1[j];
      "".length();
      lllllllllllllllIllllIIlIlIIlIIII++;
      j++;
      "".length();
      if (-" ".length() > "   ".length())
        return null; 
    } 
    return String.valueOf(lllllllllllllllIllllIIlIlIIlIIlI);
  }
  
  private static void llllIlIllIllllI() {
    lIllIllIllIllI = new int[6];
    lIllIllIllIllI[0] = (" ".length() ^ (0x4A ^ 0x6D) << " ".length()) & (104 + 168 - 128 + 83 ^ (0x93 ^ 0xB8) << " ".length() << " ".length() ^ -" ".length());
    lIllIllIllIllI[1] = " ".length();
    lIllIllIllIllI[2] = "   ".length();
    lIllIllIllIllI[3] = " ".length() << " ".length();
    lIllIllIllIllI[4] = " ".length() << " ".length() << " ".length();
    lIllIllIllIllI[5] = 0x7E ^ 0x7B;
  }
  
  private static boolean llllIlIlllIIIII(int paramInt1, int paramInt2) {
    return (paramInt1 == paramInt2);
  }
  
  private static boolean llllIlIlllIIIIl(int paramInt1, int paramInt2) {
    return (paramInt1 < paramInt2);
  }
  
  private static boolean llllIlIllIlllll(int paramInt1, int paramInt2) {
    return (paramInt1 <= paramInt2);
  }
}


/* Location:              C:\Users\ethan\Downloads\bleachhackplus.jar!\com\lukflug\panelstudio\SettingsAnimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */